"""Sinh danh bạ khách hàng GIẢ (~400 dòng, gom từ 5 nguồn) kèm bẫy thật + đáp án.

Chạy:  python -X utf8 sinh_du_lieu.py [hạt_giống] [thư_mục_ra]
Ra:    danh-ba-goc.xlsx, danh-ba-goc.csv   (cùng thư mục với script, hoặc <thư_mục_ra>)
       ../ket-qua/dap-an.json              (đáp án — KHÔNG đưa cho agent; hoặc <thư_mục_ra>/dap-an.json)
Không tham số: ra đúng bộ dữ liệu của bài (hạt giống 20261120). Có tham số: sinh một đợt mới (dùng ở bài 3).

100% GIẢ: tên là ghép ngẫu nhiên họ + đệm + tên phổ biến; SĐT dạng 0xx 555 0xxx (dãy "555" kiểu phim, quy ước
là số giả; không bảo đảm chưa từng có thật ở ngoài đời); email dùng tên miền dành riêng example.com/.org/.net;
địa chỉ là ghép ngẫu nhiên tên đường + số nhà. Hạt giống cố định => chạy lại ra đúng bản cũ.
"""
import random, json, unicodedata, re, csv, sys
from pathlib import Path
from collections import Counter

SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 20261120
rng = random.Random(SEED)
HERE = Path(__file__).resolve().parent
OUT_DIR = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else HERE
OUT_DIR.mkdir(parents=True, exist_ok=True)
OUT_ANS = (OUT_DIR / "dap-an.json") if len(sys.argv) > 2 else HERE.parent / "ket-qua" / "dap-an.json"

# ---------------------------------------------------------------- tiện ích chữ
def nfc(s): return unicodedata.normalize("NFC", s)
def strip_dia(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")
def key(s): return re.sub(r"\s+", " ", strip_dia(s).lower()).strip()
def title(s): return " ".join(w[:1].upper() + w[1:].lower() for w in s.split())

HO = ["Nguyễn","Nguyễn","Nguyễn","Trần","Trần","Lê","Lê","Phạm","Hoàng","Huỳnh","Phan","Vũ","Võ","Đặng","Bùi","Đỗ","Hồ","Ngô","Dương","Lý"]
DEM_NAM = ["Văn","Minh","Quốc","Hữu","Đức","Gia","Thanh","Anh","Công","Xuân"]
DEM_NU = ["Thị","Ngọc","Thu","Thanh","Hoài","Mỹ","Kim","Bích","Phương","Khánh"]
TEN_NAM = ["An","Bình","Cường","Dũng","Đạt","Hải","Hiếu","Hoàng","Hùng","Huy","Khánh","Khoa","Kiên","Long","Minh","Nam","Phát","Phong","Quân","Sơn","Tài","Thắng","Thành","Tiến","Toàn","Trung","Tuấn","Việt","Vinh","Đức","Hưng","Phúc","Thịnh","Lộc","Nghĩa","Quang","Tâm"]
TEN_NU = ["Anh","Chi","Dung","Giang","Hà","Hằng","Hoa","Hương","Lan","Linh","Loan","Mai","My","Ngân","Nhung","Oanh","Phượng","Quyên","Thảo","Thủy","Trang","Trinh","Vân","Yến","Hạnh","Thu","Ly","Nhi","Diệp","Hiền","Huyền"]
DUONG = ["Lê Lợi","Nguyễn Trãi","Trần Hưng Đạo","Hai Bà Trưng","Phạm Văn Đồng","Lý Thường Kiệt","Điện Biên Phủ","Cách Mạng Tháng Tám","Võ Thị Sáu","Hoàng Diệu","Nguyễn Huệ","Pasteur","Lạc Long Quân","Láng Hạ","Kim Mã","Cầu Giấy","Nguyễn Văn Linh","Ngô Quyền","Bạch Đằng","Quang Trung","Trường Chinh","Âu Cơ","Nguyễn Thị Minh Khai","Hoàng Hoa Thám"]
HCM = ("Thành phố Hồ Chí Minh", ["TP.HCM","TPHCM","Tp. HCM","HCM","TP HCM","TP. Hồ Chí Minh"])
NOI = [  # (phường, quận, thành phố chuẩn, các cách viết tắt thành phố)
    ("hcm", None, None),
]
HN_PQ = [("Dịch Vọng","Cầu Giấy"),("Láng Hạ","Đống Đa"),("Mỗ Lao","Hà Đông"),("Bách Khoa","Hai Bà Trưng"),("Thanh Xuân Bắc","Thanh Xuân")]
DN_PQ = [("Hải Châu 1","Hải Châu"),("An Hải Bắc","Sơn Trà"),("Hòa Minh","Liên Chiểu")]
CT_PQ = [("An Hòa","Ninh Kiều"),("Xuân Khánh","Ninh Kiều"),("Thới Bình","Ninh Kiều")]
HP_PQ = [("Máy Chai","Ngô Quyền"),("Lạch Tray","Ngô Quyền"),("Cát Dài","Lê Chân")]
NGUON = ["Zalo","Shopee","TikTok Shop","Sổ tay","Phần mềm bán hàng"]
GHI_CHU = ["khách quen","giao giờ hành chính","hay đổi trả","khách sỉ","nhắn Zalo trước khi giao","thanh toán chuyển khoản","","","","","","",""]
PREFIX = [32,33,34,35,36,37,38,39,70,76,77,78,79,81,82,83,84,85,86,88,89,90,91,93,94,96,97,98]

used_names, used_phones, used_emails = set(), set(), set()

def new_phone(kind="mobile"):
    while True:
        if kind == "mobile":
            p = f"0{rng.choice(PREFIX)}5550{rng.randint(0,999):03d}"
        elif kind == "landline":
            p = f"0{rng.choice([24,28])}5550{rng.randint(0,9999):04d}"
        elif kind == "old11":
            p = f"01{rng.choice([20,21,22,23,24,25,26,27,28,29,62,63,64,65,66,67,68,69])}5550{rng.randint(0,999):03d}"
            p = p[:11]
        if p not in used_phones and p[:-1] + str((int(p[-1]) + 1) % 10) not in used_phones:
            used_phones.add(p); return p

def new_name(gender=None, ten=None, ho=None):
    g = gender or rng.choice(["nam", "nu"])
    while True:
        h = ho or rng.choice(HO)
        d = rng.choice(DEM_NAM if g == "nam" else DEM_NU)
        t = ten or rng.choice(TEN_NAM if g == "nam" else TEN_NU)
        n = f"{h} {d} {t}"
        if key(n) not in used_names:
            used_names.add(key(n)); return n, g
        if ten and ho: raise RuntimeError("trùng tên cố định")

def new_address(city=None):
    c = city or rng.choice(["hcm","hcm","hcm","hn","hn","dn","ct","hp"])
    so = rng.choice([str(rng.randint(1, 240)), f"{rng.randint(1,120)}/{rng.randint(1,40)}", f"{rng.randint(1,90)}/{rng.randint(1,30)}/{rng.randint(1,9)}"])
    d = rng.choice(DUONG)
    if c == "hcm":
        return dict(c=c, so=so, duong=d, p=str(rng.randint(1, 14)), q=str(rng.randint(1, 12)), tp="Thành phố Hồ Chí Minh",
                    full=f"{so} {d}, Phường {{p}}, Quận {{q}}, Thành phố Hồ Chí Minh")
    pq = {"hn": HN_PQ, "dn": DN_PQ, "ct": CT_PQ, "hp": HP_PQ}[c]
    p, q = rng.choice(pq)
    tp = {"hn": "Hà Nội", "dn": "Đà Nẵng", "ct": "Cần Thơ", "hp": "Hải Phòng"}[c]
    return dict(c=c, so=so, duong=d, p=p, q=q, tp=tp, full="")

def addr_truth(a):
    if a["c"] == "hcm":
        return f'{a["so"]} {a["duong"]}, Phường {a["p"]}, Quận {a["q"]}, {a["tp"]}'
    return f'{a["so"]} {a["duong"]}, Phường {a["p"]}, Quận {a["q"]}, {a["tp"]}'

def addr_variant(a, src):
    """Trả (chuỗi_viết, nhãn_biến_thể)."""
    c = a["c"]
    tp_short = {"hcm": ["TP.HCM","TPHCM","Tp. HCM","HCM","TP HCM"], "hn": ["HN","Tp. Hà Nội","Hà Nội","TP.HN"],
                "dn": ["Đà Nẵng","TP Đà Nẵng","Đà nẵng","ĐN"], "ct": ["Cần Thơ","TP.Cần Thơ","CT"], "hp": ["Hải Phòng","HP","TP Hải Phòng"]}[c]
    num = a["p"].isdigit()
    v = rng.choice(["full", "abbr", "abbr", "abbr2", "lower", "upper_nodia", "so_duong"])
    so, d, p, q = a["so"], a["duong"], a["p"], a["q"]
    if src == "Shopee" and rng.random() < .5: v = "upper_nodia"
    if src == "Sổ tay" and rng.random() < .5: v = rng.choice(["lower", "abbr2"])
    if v == "full":
        return addr_truth(a), v
    if v == "abbr":
        return f"{so} {d}, P.{p}, Q.{q}, {rng.choice(tp_short)}", v
    if v == "abbr2":
        pp = f"p{p}" if num else f"p.{p}"; qq = f"q{q}" if q.isdigit() else f"q.{q}"
        return f"{so} đ.{d} {pp} {qq} {rng.choice(tp_short)}", v
    if v == "lower":
        return f"{so} {d.lower()}, phường {p.lower()}, quận {q.lower()}, {rng.choice(tp_short).lower()}", v
    if v == "so_duong":
        return f"Số {so} đường {d}, F{p}, Q{q}, {rng.choice(tp_short)}" if num else f"Số {so} đường {d}, P. {p}, Q. {q}, {rng.choice(tp_short)}", v
    return strip_dia(f"{so} {d}, P.{p}, Q.{q}, {rng.choice(tp_short)}").upper(), v

PHONE_W = {
    "Zalo": ["intl", "intl_sp", "plain", "sp34", "plus84"],
    "Shopee": ["plain", "n84", "plus84", "plain"],
    "TikTok Shop": ["plain", "n84", "plain", "plus84"],
    "Sổ tay": ["dots", "dash", "sp43", "sp34", "plain"],
    "Phần mềm bán hàng": ["plain", "plain", "plain", "numeric", "pad"],
}
def phone_fmt(nat, fmt):
    r = nat[1:]
    if fmt == "plain": return nat
    if fmt == "sp43": return f"{nat[:4]} {nat[4:7]} {nat[7:]}"
    if fmt == "sp34": return f"{nat[:3]} {nat[3:6]} {nat[6:]}"
    if fmt == "dots": return f"{nat[:4]}.{nat[4:7]}.{nat[7:]}"
    if fmt == "dash": return f"{nat[:3]}-{nat[3:6]}-{nat[6:]}"
    if fmt == "plus84": return "+84" + r
    if fmt == "intl": return "+84 " + f"{r[:3]} {r[3:6]} {r[6:]}"
    if fmt == "intl_sp": return "(+84) " + r
    if fmt == "n84": return "84" + r
    if fmt == "n0084": return "0084" + r
    if fmt == "pad": return f" {nat} "
    if fmt == "numeric": return int(nat)
    raise ValueError(fmt)

def pick_fmt(src, avoid=()):
    for _ in range(20):
        f = rng.choice(PHONE_W[src] + (["n0084"] if rng.random() < .08 else []))
        if f not in avoid: return f
    return f

# ---------------------------------------------------------------- tên
HON_NU = ["Chị", "Cô", "chị", "c"]
HON_NAM = ["Anh", "Chú", "Bác", "anh", "a"]
def name_variant(canon, v, gender=None):
    p = canon.split()
    if v == "same": s = canon
    elif v == "upper": s = canon.upper()
    elif v == "lower": s = canon.lower()
    elif v == "nodia": s = strip_dia(canon)
    elif v == "nodia_lower": s = strip_dia(canon).lower()
    elif v == "nodia_upper": s = strip_dia(canon).upper()
    elif v == "abbr": s = f"{p[0]} {p[1][0]}. {' '.join(p[2:])}"
    elif v == "messy": s = f"{p[0].lower()}  {p[1]} {' '.join(p[2:]).upper()} "
    elif v == "nfd": s = unicodedata.normalize("NFD", canon)
    elif v == "nfd_lower": s = unicodedata.normalize("NFD", canon.lower())
    else: raise ValueError(v)
    return s

def has_full_dia(v): return v in ("same", "upper", "lower", "messy", "nfd", "nfd_lower")

NAME_V = ["same"] * 4 + ["upper", "lower", "nodia", "nodia_lower", "nodia_upper", "messy", "nfd", "nfd_lower"]
def pick_nv(src, allow_abbr=False):
    if src == "Shopee": c = ["upper", "nodia_upper", "same", "nodia"]
    elif src == "Sổ tay": c = ["lower", "nodia_lower", "same", "nodia"]
    elif src == "Zalo": c = ["same", "nfd", "nfd_lower", "nodia", "messy"]
    elif src == "TikTok Shop": c = ["same", "upper", "nodia"]
    else: c = ["same", "upper", "same"]
    if allow_abbr: c = c + ["abbr", "abbr"]
    return rng.choice(c)

# ---------------------------------------------------------------- email
def new_email(canon):
    p = key(canon).split()
    while True:
        local = rng.choice([f"{p[-1]}.{p[0]}", f"{p[-1]}{p[0]}", f"{p[0]}.{p[-1]}", f"{p[-1]}{p[1]}"]) + rng.choice(["", "", str(rng.randint(70, 99)), str(rng.randint(1, 9))])
        e = f"{local}@{rng.choice(['example.com','example.com','example.org','example.net'])}"
        if e not in used_emails:
            used_emails.add(e); return e

def email_variant(e, kind):
    loc, dom = e.split("@")
    if kind == "same": return e, e
    if kind == "upper": return f"{loc.capitalize()}@{dom.capitalize()}", e
    if kind == "space": return f" {e} ", e
    if kind == "comma": return f"{loc}@{dom.replace('.', ',', 1)}", e
    if kind == "con": return f"{loc}@{dom[:-3]}con", None
    if kind == "noat": return f"{loc}{dom}", None
    if kind == "nodot": return f"{loc}@{dom.split('.')[0]}", None
    if kind == "space_in": return f"{loc[:len(loc)//2]} {loc[len(loc)//2:]}@{dom}", None
    if kind == "dbl_at": return f"{loc}@@{dom}", None
    raise ValueError(kind)

# ---------------------------------------------------------------- cấu trúc
rows = []      # mỗi dòng: dict raw + truth
entities = {}
groups_gop, pairs_quyet, pairs_khong = [], [], []
eid_counter = [0]

def new_entity(gender=None, ten=None, ho=None, phone=True, email=True, addr=True, landline=False, name=None):
    eid_counter[0] += 1
    if name: canon, g = name, (gender or "nam"); used_names.add(key(name))
    else: canon, g = new_name(gender, ten, ho)
    e = dict(id=f"E{eid_counter[0]:03d}", name=canon, gender=g,
             phones=[new_phone("landline" if landline else "mobile")] if phone else [],
             email=new_email(canon) if email else None, addr=new_address() if addr else None)
    entities[e["id"]] = e
    return e

def make_row(e, src, nv=None, pf=None, show_phone=True, show_email=True, show_addr=True, ev="same",
             honorific=None, name_override=None, tag=None, phone_idx=0, addr_obj=None):
    r = dict(entity=e["id"], src=src, tags=[], note="")
    # tên
    if name_override is not None:
        r["name_raw"], r["name_truth"], r["name_full_dia"] = name_override
    else:
        nv = nv or pick_nv(src)
        r["name_raw"] = name_variant(e["name"], nv)
        r["name_truth"] = {"same": e["name"], "upper": e["name"], "lower": e["name"], "messy": e["name"], "nfd": e["name"], "nfd_lower": e["name"],
                           "nodia": title(strip_dia(e["name"])), "nodia_lower": title(strip_dia(e["name"])), "nodia_upper": title(strip_dia(e["name"])),
                           "abbr": name_variant(e["name"], "abbr")}[nv]
        r["name_full_dia"] = has_full_dia(nv)
        if nv != "same": r["tags"].append("ten:" + nv)
    if honorific:
        r["name_raw"] = f"{honorific} {r['name_raw']}"; r["tags"].append("danh_xung")
    r["honorific"] = honorific
    # sdt
    r["phones_truth"], r["phone_invalid_raw"] = [], None
    r["phone_raw"] = ""
    if show_phone and e["phones"]:
        nat = e["phones"][phone_idx]
        f = pf or pick_fmt(src)
        r["phone_raw"] = phone_fmt(nat, f); r["phones_truth"] = [nat]
        if f != "plain": r["tags"].append("sdt:" + f)
    # email
    r["email_raw"], r["email_truth"], r["email_invalid_raw"] = "", None, None
    if show_email and e["email"]:
        raw, tr = email_variant(e["email"], ev)
        r["email_raw"] = raw; r["email_truth"] = tr
        if tr is None: r["email_invalid_raw"] = raw; r["tags"].append("email_sai:" + ev)
        elif ev != "same": r["tags"].append("email:" + ev)
    # địa chỉ
    r["addr_raw"], r["addr_truth"] = "", None
    if show_addr and e["addr"]:
        a = addr_obj or e["addr"]
        raw, v = addr_variant(a, src)
        r["addr_raw"] = raw; r["addr_truth"] = addr_truth(a)
        if v != "full": r["tags"].append("dia_chi:" + v)
    r["note"] = rng.choice(GHI_CHU)
    rows.append(r)
    return r

def srcs(k): return rng.sample(NGUON, k)

# ---- A: cùng SĐT, khác cách viết (gộp chắc) : 34 cặp + 2 bộ ba
for gi in range(36):
    g = rng.choice(["nam", "nu"])
    e = new_entity(g, email=rng.random() < .5, addr=rng.random() < .7)
    k = 3 if gi < 2 else 2
    ss = srcs(k); fm = []
    grp = []
    for j, s in enumerate(ss):
        f = pick_fmt(s, avoid=fm); fm.append(f)
        nv = pick_nv(s, allow_abbr=(j > 0 and gi % 3 == 0))
        hon = (rng.choice(HON_NU if g == "nu" else HON_NAM) if (s in ("Zalo", "Sổ tay") and rng.random() < .35) else None)
        if hon in ("c", "a") and nv in ("abbr",): hon = None
        # row đầu có đủ thông tin; các row sau có thể thiếu/ khác nơi
        grp.append(make_row(e, s, nv=nv, pf=f, honorific=hon,
                            show_email=(j == 0 and e["email"] is not None) or rng.random() < .4,
                            show_addr=(j == 0) or rng.random() < .4,
                            ev=rng.choice(["same", "same", "upper", "space", "comma"])))
    # đảm bảo có ít nhất một dòng đầy đủ tên có dấu hoặc chấp nhận không
    groups_gop.append(dict(loai="A", rows=grp))

# ---- A-chain: r1(P) r2(P,E) r3(Q,E)   -> gộp bắc cầu
for gi in range(4):
    g = rng.choice(["nam", "nu"])
    e = new_entity(g, email=True, addr=True)
    e["phones"].append(new_phone())
    s1, s2, s3 = srcs(3)
    r1 = make_row(e, s1, nv=pick_nv(s1), phone_idx=0, show_email=False, show_addr=False)
    r2 = make_row(e, s2, nv=pick_nv(s2), phone_idx=0, show_email=True, ev="same", pf=pick_fmt(s2, avoid=[r1["tags"][0][4:]] if r1["tags"] and r1["tags"][0].startswith("sdt:") else []))
    r3 = make_row(e, s3, nv=pick_nv(s3, allow_abbr=(gi % 2 == 0)), phone_idx=1, show_email=True, ev=rng.choice(["same", "upper", "space"]), show_addr=rng.random() < .5)
    groups_gop.append(dict(loai="A-chain", rows=[r1, r2, r3]))

# ---- B: cùng email, khác SĐT (gộp chắc)
for gi in range(12):
    g = rng.choice(["nam", "nu"])
    e = new_entity(g, email=True, addr=rng.random() < .5)
    e["phones"].append(new_phone())
    s1, s2 = srcs(2)
    r1 = make_row(e, s1, nv=pick_nv(s1), phone_idx=0, ev=rng.choice(["same", "upper"]))
    r2 = make_row(e, s2, nv=pick_nv(s2, allow_abbr=(gi % 3 == 0)), phone_idx=1, ev=rng.choice(["same", "space", "upper", "comma"]), show_addr=rng.random() < .4)
    groups_gop.append(dict(loai="B", rows=[r1, r2]))

# ---- H1: cùng SĐT, tên khác hẳn (dùng chung số) -> CẦN NGƯỜI QUYẾT
for gi in range(8):
    e1 = new_entity(rng.choice(["nam", "nu"]), email=rng.random() < .4, addr=True)
    e2 = new_entity(rng.choice(["nam", "nu"]), ho=e1["name"].split()[0] if gi % 2 == 0 else None, email=rng.random() < .3, addr=rng.random() < .6, phone=False)
    e2["phones"] = list(e1["phones"])
    s1, s2 = srcs(2)
    r1 = make_row(e1, s1, pf=pick_fmt(s1)); r2 = make_row(e2, s2, pf=pick_fmt(s2))
    pairs_quyet.append(dict(loai="H1", rows=[r1, r2], ly_do="cùng SĐT nhưng tên khác hẳn (có thể dùng chung số trong gia đình/cửa hàng)"))

# ---- H5: cùng SĐT, một dòng chỉ có tên gọi (vd "Chị Lan") -> CẦN NGƯỜI QUYẾT
for gi in range(5):
    g = "nu" if gi < 3 else "nam"
    e = new_entity(g, email=False, addr=rng.random() < .6)
    s1, s2 = srcs(2)
    r1 = make_row(e, s1, nv=pick_nv(s1))
    last = e["name"].split()[-1]
    hon = rng.choice(HON_NU if g == "nu" else HON_NAM)
    nm = (f"{last}", f"{last}", False) if rng.random() < .5 else (strip_dia(last), title(strip_dia(last)), False)
    r2 = make_row(e, s2, name_override=nm, honorific=hon, show_email=False, show_addr=False)
    r2["name_truth"] = nm[1]
    pairs_quyet.append(dict(loai="H5", rows=[r1, r2], ly_do="cùng SĐT, một dòng chỉ có tên gọi một từ, không đủ để chắc là cùng người"))

# ---- H2: cùng tên + cùng địa chỉ (viết khác), khác SĐT -> CẦN NGƯỜI QUYẾT
for gi in range(8):
    g = rng.choice(["nam", "nu"])
    e1 = new_entity(g, email=rng.random() < .4, addr=True)
    e2 = dict(e1); eid_counter[0] += 1; e2["id"] = f"E{eid_counter[0]:03d}"; e2["phones"] = [new_phone()]; e2["email"] = new_email(e1["name"]) if rng.random() < .3 else None
    entities[e2["id"]] = e2
    s1, s2 = srcs(2)
    r1 = make_row(e1, s1, nv=pick_nv(s1), show_addr=True); r2 = make_row(e2, s2, nv=pick_nv(s2), show_addr=True)
    r2["entity_note"] = "cùng tên+địa chỉ nhưng SĐT khác: chưa biết có phải cùng người"
    pairs_quyet.append(dict(loai="H2", rows=[r1, r2], ly_do="cùng tên và cùng địa chỉ nhưng SĐT (và email) khác nhau"))

# ---- H3: cùng tên + cùng địa chỉ, một dòng thiếu SĐT & email -> CẦN NGƯỜI QUYẾT
for gi in range(4):
    g = rng.choice(["nam", "nu"])
    e1 = new_entity(g, email=False, addr=True)
    e2 = dict(e1); eid_counter[0] += 1; e2["id"] = f"E{eid_counter[0]:03d}"; e2["phones"] = []; e2["email"] = None
    entities[e2["id"]] = e2
    s1, s2 = srcs(2)
    r1 = make_row(e1, s1, nv=pick_nv(s1)); r2 = make_row(e2, s2, nv=pick_nv(s2), show_phone=False, show_email=False)
    pairs_quyet.append(dict(loai="H3", rows=[r1, r2], ly_do="cùng tên và địa chỉ, một dòng không có SĐT/email để đối chiếu"))

# ---- T1: cùng tên (kể cả khác dấu thanh), khác SĐT khác địa chỉ -> KHÔNG GỘP
for gi in range(18):
    g = rng.choice(["nam", "nu"])
    e1 = new_entity(g, email=rng.random() < .4, addr=True)
    p = e1["name"].split()
    if gi < 4:  # khác dấu thanh ở tên: Hòa/Hoa, Thảo/Thao...
        t = p[-1]; alt = {"Hoa": "Hòa", "Hà": "Hạ", "Thảo": "Thao", "Tâm": "Tấm", "Hải": "Hai", "Thịnh": "Thinh"}
        if t not in alt: t = rng.choice(list(alt))
        nm2 = f"{p[0]} {p[1]} {alt[t]}"
        e1["name"] = f"{p[0]} {p[1]} {t}"; used_names.add(key(e1["name"]))
        e2 = new_entity(g, name=nm2, email=rng.random() < .3, addr=True)
        e2["name"] = nm2
    else:
        e2 = dict(e1); eid_counter[0] += 1; e2["id"] = f"E{eid_counter[0]:03d}"
        e2["phones"] = [new_phone()]; e2["email"] = new_email(e1["name"]) if rng.random() < .3 else None; e2["addr"] = new_address()
        while addr_truth(e2["addr"]) == addr_truth(e1["addr"]): e2["addr"] = new_address()
        entities[e2["id"]] = e2
    s1, s2 = srcs(2)
    r1 = make_row(e1, s1, nv=pick_nv(s1)); r2 = make_row(e2, s2, nv=pick_nv(s2))
    pairs_khong.append(dict(loai="T1", rows=[r1, r2], ly_do="trùng/giống tên nhưng khác SĐT, khác địa chỉ: người khác nhau"))

# ---- T3: tên gần giống (khác chữ, không chỉ dấu), SĐT liên tiếp -> KHÔNG GỘP
NEAR = [("Hùng", "Hưng"), ("Phúc", "Phước"), ("Hiếu", "Hiền"), ("Nhung", "Nhân"), ("Khánh", "Khang")]
for gi, (t1, t2) in enumerate(NEAR):
    g = "nu" if t1 in ("Nhung",) else "nam"
    ho = rng.choice(HO)
    e1 = new_entity(g, ten=t1, ho=ho, email=False, addr=True)
    d = e1["name"].split()[1]
    e2 = new_entity(g, ten=t2, ho=ho, email=False, addr=True, phone=False)
    e2["name"] = f"{ho} {d} {t2}"; used_names.add(key(e2["name"]))
    p1 = e1["phones"][0]; p2 = p1[:-1] + str((int(p1[-1]) + 1) % 10); used_phones.add(p2); e2["phones"] = [p2]
    s1, s2 = srcs(2)
    r1 = make_row(e1, s1, nv=pick_nv(s1)); r2 = make_row(e2, s2, nv=pick_nv(s2))
    pairs_khong.append(dict(loai="T3", rows=[r1, r2], ly_do="tên gần giống nhưng khác chữ, SĐT chỉ khác số cuối: người khác nhau"))

n_group_rows = len(rows)
# ---- đơn lẻ
N_TARGET = 400
while len(rows) < N_TARGET:
    g = rng.choice(["nam", "nu"])
    s = rng.choice(NGUON + ["Zalo", "Shopee", "Phần mềm bán hàng"])
    kind = rng.random()
    landline = kind < .04
    e = new_entity(g, phone=rng.random() > .07, email=rng.random() < .5, addr=rng.random() < .75, landline=landline)
    hon = rng.choice(HON_NU if g == "nu" else HON_NAM) if (s in ("Zalo", "Sổ tay") and rng.random() < .3) else None
    r = make_row(e, s, nv=pick_nv(s), honorific=hon,
                 ev=rng.choice(["same"] * 7 + ["upper", "space", "comma", "con", "noat", "nodot", "space_in", "dbl_at"]),
                 pf=(pick_fmt(s) if not landline else rng.choice(["plain", "sp43", "plus84", "n84"])))
    # SĐT sai kiểu
    if r["phones_truth"] and rng.random() < .09:
        nat = r["phones_truth"][0]; typ = rng.choice(["trunc", "mask", "old11", "short"])
        if typ == "trunc": raw = nat[:-1]
        elif typ == "mask": raw = f"{nat[:4]}***{nat[-3:]}" if s in ("Shopee", "TikTok Shop") else f"{nat[:4]} *** {nat[-3:]}"
        elif typ == "old11": raw = new_phone("old11")
        else: raw = nat[:6]
        r["phone_invalid_raw"] = raw; r["phone_raw"] = raw; r["phones_truth"] = []; r["tags"] = [t for t in r["tags"] if not t.startswith("sdt:")] + ["sdt_sai:" + typ]
        e["phones"] = []

# ---------------------------------------------------------------- lẫn lộn cột (mess)
single = [r for r in rows[n_group_rows:]]
rng.shuffle(single)
def take(pred, n):
    out = []
    for r in single:
        if len(out) >= n: break
        if "mess" in r["tags"]: continue
        if pred(r): out.append(r)
    return out
for r in take(lambda r: r["phones_truth"] and not r["email_raw"] and isinstance(r["phone_raw"], str), 4):   # L1 SĐT nằm ở cột Email
    r["email_raw"] = r["phone_raw"]; r["phone_raw"] = ""; r["tags"] += ["mess", "lan_cot:sdt_o_cot_email"]
for r in take(lambda r: r["email_truth"] and not r["phone_raw"] and not r["phones_truth"], 3):               # L2 email ở cột SĐT
    r["phone_raw"] = r["email_raw"]; r["email_raw"] = ""; r["tags"] += ["mess", "lan_cot:email_o_cot_sdt"]
for r in take(lambda r: r["addr_truth"] and not r["name_raw"].startswith(("Chị", "Anh")), 3):               # L3 tên <-> địa chỉ
    r["name_raw"], r["addr_raw"] = r["addr_raw"], r["name_raw"]; r["tags"] += ["mess", "lan_cot:ten_dia_chi_doi_cho"]
for r in take(lambda r: r["phones_truth"] and isinstance(r["phone_raw"], str) and r["phone_raw"], 4):       # L4 SĐT trong ghi chú
    r["note"] = f"SĐT: {r['phone_raw'].strip()}"; r["phone_raw"] = ""; r["tags"] += ["mess", "lan_cot:sdt_o_ghi_chu"]
for r in take(lambda r: r["phones_truth"] and isinstance(r["phone_raw"], str) and r["phone_raw"], 5):       # L5 hai SĐT một ô
    e = entities[r["entity"]]; p2 = new_phone(); e["phones"].append(p2)
    sep = rng.choice([" / ", "; ", " , ", " hoặc "])
    r["phone_raw"] = r["phone_raw"].strip() + sep + phone_fmt(p2, rng.choice(["plain", "sp43", "dots"]))
    r["phones_truth"] = [r["phones_truth"][0], p2]; r["tags"] += ["mess", "lan_cot:hai_sdt_mot_o"]
# trong nhóm A: vài dòng có SĐT bị chuyển sang ghi chú (dòng kia vẫn còn SĐT ở cột SĐT)
cnt = 0
for gr in groups_gop:
    if gr["loai"] == "A" and cnt < 3:
        r = gr["rows"][1]
        if r["phones_truth"] and isinstance(r["phone_raw"], str) and r["phone_raw"] and not gr["rows"][0]["tags"].count("mess"):
            r["note"] = f"liên hệ {r['phone_raw'].strip()}"; r["phone_raw"] = ""; r["tags"] += ["mess", "lan_cot:sdt_o_ghi_chu"]; cnt += 1

# ---------------------------------------------------------------- xuất
rng.shuffle(rows)
for i, r in enumerate(rows, 1): r["id"] = f"R{i:03d}"
HEAD = ["Mã dòng", "Nguồn", "Họ tên", "SĐT", "Email", "Địa chỉ", "Ghi chú"]
table = [[r["id"], r["src"], r["name_raw"], r["phone_raw"], r["email_raw"], r["addr_raw"], r["note"]] for r in rows]

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
wb = openpyxl.Workbook(); ws = wb.active; ws.title = "DanhBa"
ws.append(HEAD)
for t in table: ws.append(t)
for c in ws[1]: c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F3A68")
for col, w in zip("ABCDEFG", [9, 18, 30, 24, 34, 52, 34]): ws.column_dimensions[col].width = w
ws.freeze_panes = "A2"
for rr in ws.iter_rows(min_row=2):
    for c in rr:
        if c.column == 4 and isinstance(c.value, str): c.number_format = "@"
wb.save(OUT_DIR / "danh-ba-goc.xlsx")
with open(OUT_DIR / "danh-ba-goc.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(HEAD); w.writerows(table)

def rid(r): return r["id"]
ans = dict(
    meta=dict(seed=SEED, so_dong=len(rows), ghi_chu="Đáp án. KHÔNG đưa vào thư mục agent làm việc."),
    quy_tac=dict(
        sdt="Chỉ giữ chữ số; +84/84/0084 đầu -> 0; ô số bị mất số 0 đầu -> thêm 0. Hợp lệ: 10 số bắt đầu 03/05/07/08/09, hoặc 11 số bắt đầu 02 (bàn). Còn lại: không hợp lệ, không tự đoán.",
        email="Cắt khoảng trắng, hạ chữ thường, dấu phẩy trong tên miền -> dấu chấm. Còn sai cú pháp/ tên miền: không tự sửa, để trống cột email sạch và ghi vào nhật ký.",
        ten="Chuẩn Unicode NFC, Viết Hoa Chữ Đầu, bỏ danh xưng (anh/chị/cô/chú/bác, a/c). Không đoán dấu cho tên không dấu.",
    ),
    rows={rid(r): dict(entity=r["entity"], nguon=r["src"], ten_dong=r["name_truth"], ten_co_dau_day_du=r["name_full_dia"],
                       ten_chuan_thuc_the=entities[r["entity"]]["name"],
                       sdt_hop_le=r["phones_truth"], sdt_sai_goc=r["phone_invalid_raw"],
                       email_hop_le=r["email_truth"], email_sai_goc=r["email_invalid_raw"],
                       dia_chi_chuan=r["addr_truth"], danh_xung=r["honorific"], tags=r["tags"]) for r in rows},
    gop_chac=[dict(loai=g["loai"], rows=sorted(rid(r) for r in g["rows"])) for g in groups_gop],
    can_nguoi_quyet=[dict(loai=g["loai"], rows=sorted(rid(r) for r in g["rows"]), ly_do=g["ly_do"]) for g in pairs_quyet],
    khong_gop=[dict(loai=g["loai"], rows=sorted(rid(r) for r in g["rows"]), ly_do=g["ly_do"]) for g in pairs_khong],
)
cnt = Counter(t.split(":")[0] if t.startswith(("lan_cot", "sdt_sai", "email_sai")) else t for r in rows for t in r["tags"])
ans["thong_ke_loi"] = dict(
    so_dong=len(rows), so_khach_that=len({r["entity"] for r in rows}),
    nhom_gop_chac=len(groups_gop), cap_can_nguoi_quyet=len(pairs_quyet), cap_khong_gop=len(pairs_khong),
    dong_trong_sdt=sum(1 for r in rows if not r["phone_raw"]), dong_trong_email=sum(1 for r in rows if not r["email_raw"]),
    dong_trong_dia_chi=sum(1 for r in rows if not r["addr_raw"]),
    sdt_dinh_dang=dict(Counter(t for r in rows for t in r["tags"] if t.startswith("sdt:"))),
    sdt_sai=dict(Counter(t for r in rows for t in r["tags"] if t.startswith("sdt_sai:"))),
    email_sai=dict(Counter(t for r in rows for t in r["tags"] if t.startswith("email_sai:"))),
    email_sua_duoc=dict(Counter(t for r in rows for t in r["tags"] if t.startswith("email:"))),
    ten=dict(Counter(t for r in rows for t in r["tags"] if t.startswith("ten:"))),
    danh_xung=sum(1 for r in rows if r["honorific"]),
    lan_cot=dict(Counter(t for r in rows for t in r["tags"] if t.startswith("lan_cot:"))),
    dia_chi_viet_tat=dict(Counter(t for r in rows for t in r["tags"] if t.startswith("dia_chi:"))),
    theo_nguon=dict(Counter(r["src"] for r in rows)),
    loai_nhom={**Counter(g["loai"] for g in groups_gop), **Counter(g["loai"] for g in pairs_quyet), **Counter(g["loai"] for g in pairs_khong)},
)
OUT_ANS.parent.mkdir(parents=True, exist_ok=True)
OUT_ANS.write_text(json.dumps(ans, ensure_ascii=False, indent=1), encoding="utf-8")
print(json.dumps(ans["thong_ke_loi"], ensure_ascii=False, indent=1))
