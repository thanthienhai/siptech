"""Sinh bộ dữ liệu GIẢ cho bài 05 (báo giá từ email/tin nhắn yêu cầu).

Chạy:  python -X utf8 sinh_du_lieu.py
Ra (cùng thư mục với file này):
  bang-gia.xlsx              bảng giá nhiều cấp theo số lượng + sheet quy đổi đơn vị
  chinh-sach-chiet-khau.docx chính sách chiết khấu / thẩm quyền (viết bằng chữ)
  dieu-kien-giao-hang.txt    điều kiện giao hàng, thanh toán (viết bằng chữ)
  mau-bao-gia.xlsx           mẫu báo giá của công ty + sheet "Tham số" (VAT là tham số)
  yeu-cau/R01.txt ... R12.txt  12 email/tin nhắn yêu cầu lộn xộn
Ra (NGOÀI thư mục agent làm việc):
  ../ket-qua/dap-an.json     đáp án đúng (tính bằng code theo đúng chính sách)

100% dữ liệu giả: công ty, người, SĐT (dãy 0900 000 xxx), email (@example.com), địa chỉ đều bịa.
Hạt giống cố định => chạy lại ra y hệt.
"""
import json, random, re, unicodedata
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from docx import Document

SEED = 20261120
HERE = Path(__file__).resolve().parent
OUT_ANSWER = HERE.parent / "ket-qua" / "dap-an.json"

VAT_PERCENT = 10          # THAM SỐ MINH HỌA, không phải khẳng định thuế suất hiện hành
NGAY_BAO_GIA = "2026-11-20"
HIEU_LUC_NGAY = 7
PHI_SHIP_NOI_THANH = 40000
NGUONG_MIEN_PHI_SHIP = 3_000_000

# ma, ten, nhom, dvt, g1, tu_sl_bac2, g2, tu_sl_bac3, g3, ghi chú kho
CATALOG = [
 ("GIAY-A4-70", "Giấy A4 định lượng 70 gsm (500 tờ/ram)", "Giấy & in ấn", "ram", 62000, 5, 60000, 20, 58000, "Còn hàng"),
 ("GIAY-A4-80", "Giấy A4 định lượng 80 gsm (500 tờ/ram)", "Giấy & in ấn", "ram", 74000, 5, 72000, 20, 69000, "Còn hàng"),
 ("GIAY-A3-80", "Giấy A3 định lượng 80 gsm (500 tờ/ram)", "Giấy & in ấn", "ram", 148000, 5, 144000, 20, 139000, "Còn hàng"),
 ("DECAL-A4-100", "Giấy decal A4 trắng (100 tờ/xấp)", "Giấy & in ấn", "xấp", 85000, 5, 82000, 20, 78000, "Còn hàng"),
 ("MUC-HP-12A", "Hộp mực tương thích máy in dòng HP 12A", "Mực in", "hộp", 395000, 3, 385000, 10, 372000, "Còn hàng"),
 ("MUC-HP-78A", "Hộp mực tương thích máy in dòng HP 78A", "Mực in", "hộp", 410000, 3, 398000, 10, 385000, "Còn hàng"),
 ("MUC-CANON-325", "Hộp mực tương thích máy in dòng Canon 325", "Mực in", "hộp", 405000, 3, 392000, 10, 380000, "Tạm hết hàng, chờ nhập"),
 ("MUC-BRO-TN2385", "Hộp mực tương thích máy in dòng Brother TN-2385", "Mực in", "hộp", 520000, 3, 505000, 10, 488000, "Còn hàng"),
 ("MUC-EPS-664-DEN", "Mực nước máy in phun đen 70ml (dòng 664)", "Mực in", "chai", 98000, 6, 94000, 24, 90000, "Còn hàng"),
 ("MAY-IN-LASER-3100", "Máy in laser đen trắng A4 mẫu 3100", "Thiết bị", "cái", 3950000, 5, 3850000, 10, 3750000, "Đặt hàng"),
 ("MAY-IN-PHUN-MAU-2200", "Máy in phun màu đa năng mẫu 2200", "Thiết bị", "cái", 4650000, 5, 4550000, 10, 4450000, "Đặt hàng"),
 ("MAY-SCAN-A4-100", "Máy scan A4 hai mặt mẫu 100", "Thiết bị", "cái", 6200000, 3, 6050000, 10, 5900000, "Đặt hàng"),
 ("MAY-HUY-GIAY-S12", "Máy hủy giấy 12 tờ/lần", "Thiết bị", "cái", 2850000, 5, 2780000, 10, 2700000, "Còn hàng"),
 ("CC-VANTAY-01", "Máy chấm công vân tay mẫu 01", "Thiết bị", "cái", 2300000, 5, 2230000, 10, 2150000, "Còn hàng"),
 ("GHE-XOAY-LUOI-01", "Ghế xoay lưng lưới mẫu 01", "Thiết bị", "cái", 1150000, 5, 1100000, 20, 1050000, "Còn hàng"),
 ("BANG-TRANG-80X120", "Bảng trắng viết bút lông 80x120 cm", "Thiết bị", "cái", 890000, 5, 860000, 10, 830000, "Còn hàng"),
 ("MAY-TINH-12S", "Máy tính bỏ túi 12 số", "VPP & vật liệu", "cái", 135000, 10, 128000, 50, 120000, "Còn hàng"),
 ("BUT-BI-TL027-XANH", "Bút bi bấm mực xanh 0.5 mm", "VPP & vật liệu", "cây", 4500, 50, 4000, 200, 3600, "Còn hàng"),
 ("BUT-GEL-05-DEN", "Bút gel mực đen 0.5 mm", "VPP & vật liệu", "cây", 6500, 10, 6000, 50, 5500, "Còn hàng"),
 ("BUT-DA-QUANG-V", "Bút dạ quang vàng", "VPP & vật liệu", "cây", 9000, 10, 8500, 50, 8000, "Còn hàng"),
 ("BUT-LONG-BANG-DEN", "Bút lông bảng mực đen", "VPP & vật liệu", "cây", 8500, 10, 8000, 50, 7500, "Còn hàng"),
 ("SO-CARO-A4-200", "Sổ kẻ caro A4 200 trang", "VPP & vật liệu", "quyển", 38000, 10, 35500, 50, 33000, "Còn hàng"),
 ("FILE-COC-7P", "File còng bìa 7 cm", "VPP & vật liệu", "cái", 36000, 10, 33500, 50, 31000, "Còn hàng"),
 ("KEP-BUOM-32", "Kẹp bướm 32 mm (12 cái/hộp)", "VPP & vật liệu", "hộp", 21000, 10, 19500, 50, 18000, "Còn hàng"),
 ("GHIM-BAM-10", "Ghim bấm số 10", "VPP & vật liệu", "hộp", 4800, 20, 4500, 100, 4200, "Còn hàng"),
 ("BANGKEO-TRONG-48", "Băng keo trong 48 mm x 100 yard", "VPP & vật liệu", "cuộn", 14500, 12, 13500, 72, 12500, "Còn hàng"),
 ("BANGKEO-2MAT-24", "Băng keo hai mặt 24 mm", "VPP & vật liệu", "cuộn", 9500, 12, 8800, 72, 8200, "Còn hàng"),
 ("MANG-BOC-PE-50CM", "Màng bọc PE khổ 50 cm (cuộn ~2 kg)", "VPP & vật liệu", "cuộn", 128000, 5, 122000, 20, 116000, "Còn hàng"),
 ("THUNG-CARTON-30X20X20", "Thùng carton 5 lớp 30x20x20 cm", "VPP & vật liệu", "cái", 9800, 50, 8900, 200, 8200, "Còn hàng"),
]
CAT = {c[0]: c for c in CATALOG}

# ma, đơn vị khác, số đơn vị gốc
QUYDOI = [
 ("GIAY-A4-70", "thùng", 5), ("GIAY-A4-80", "thùng", 5), ("GIAY-A3-80", "thùng", 3),
 ("BUT-BI-TL027-XANH", "hộp", 20), ("BUT-BI-TL027-XANH", "tá", 12),
 ("BUT-GEL-05-DEN", "hộp", 12), ("BUT-GEL-05-DEN", "tá", 12),
 ("BUT-LONG-BANG-DEN", "hộp", 10),
 ("BANGKEO-TRONG-48", "lốc", 6), ("BANGKEO-TRONG-48", "thùng", 72),
 ("BANGKEO-2MAT-24", "lốc", 6), ("BANGKEO-2MAT-24", "thùng", 72),
 ("THUNG-CARTON-30X20X20", "bó", 20),
]

def unit_price(ma, qty):
    c = CAT[ma]
    if qty >= c[7]: return c[8]
    if qty >= c[5]: return c[6]
    return c[4]

def tier_of(ma, qty):
    c = CAT[ma]
    return 3 if qty >= c[7] else (2 if qty >= c[5] else 1)

def fold(s):
    s = unicodedata.normalize("NFD", s.lower().replace("đ", "d"))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")

# ---------------------------------------------------------------- bảng giá
def build_bang_gia(path):
    wb = Workbook(); ws = wb.active; ws.title = "BangGia"
    ws["A1"] = "BẢNG GIÁ BÁN - áp dụng từ 01/11/2026 (DỮ LIỆU GIẢ ĐỂ HỌC - công ty giả An Phát Demo)"
    ws["A1"].font = Font(bold=True, size=13)
    ws["A2"] = "Giá đã tính bằng VNĐ, CHƯA gồm VAT. Bậc giá tính theo số lượng của TỪNG mã hàng, không cộng gộp mã khác. Số lượng tính theo đơn vị gốc ở cột ĐVT."
    ws["A2"].alignment = Alignment(wrap_text=True)
    ws.merge_cells("A2:K2"); ws.row_dimensions[2].height = 32
    hdr = ["Mã hàng", "Tên hàng", "Nhóm", "ĐVT gốc", "Giá bậc 1 (SL nhỏ)", "Bậc 2 từ SL", "Giá bậc 2", "Bậc 3 từ SL", "Giá bậc 3", "Tình trạng kho"]
    for i, h in enumerate(hdr, 1):
        c = ws.cell(row=3, column=i, value=h); c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F4E78"); c.alignment = Alignment(wrap_text=True, vertical="center")
    for r, row in enumerate(CATALOG, 4):
        for i, v in enumerate(row, 1):
            c = ws.cell(row=r, column=i, value=v)
            if i in (5, 7, 9): c.number_format = "#,##0"
    for col, w in zip("ABCDEFGHIJ", [24, 46, 15, 9, 16, 11, 13, 11, 13, 22]):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A4"
    q = wb.create_sheet("QuyDoi")
    q["A1"] = "Quy đổi đơn vị bán sang ĐVT gốc (chỉ gồm các mã có quy đổi; mã không có ở đây thì KHÔNG tự suy ra)"
    q["A1"].font = Font(bold=True)
    for i, h in enumerate(["Mã hàng", "Đơn vị khác", "= bao nhiêu ĐVT gốc"], 1):
        c = q.cell(row=2, column=i, value=h); c.font = Font(bold=True)
    for r, row in enumerate(QUYDOI, 3):
        for i, v in enumerate(row, 1): q.cell(row=r, column=i, value=v)
    for col, w in zip("ABC", [26, 14, 20]): q.column_dimensions[col].width = w
    wb.save(path)

# ---------------------------------------------------------------- mẫu báo giá
def build_mau(path):
    wb = Workbook(); ws = wb.active; ws.title = "Báo giá"
    thin = Side(style="thin", color="888888"); box = Border(left=thin, right=thin, top=thin, bottom=thin)
    ws["A1"] = "CÔNG TY TNHH AN PHÁT DEMO (CÔNG TY GIẢ - DỮ LIỆU ĐỂ HỌC)"; ws["A1"].font = Font(bold=True, size=12)
    ws["A2"] = "Địa chỉ: 10 Đường Mẫu, Quận Demo, Hà Nội (địa chỉ giả) | ĐT: 0900 000 000 | Email: baogia@example.com"
    ws["A4"] = "BẢNG BÁO GIÁ"; ws["A4"].font = Font(bold=True, size=16); ws["A4"].alignment = Alignment(horizontal="center")
    ws.merge_cells("A4:H4")
    labels = [(5, "Kính gửi:"), (6, "Địa chỉ giao hàng:"), (7, "Theo yêu cầu số:"), (8, "Ngày báo giá / hiệu lực:"), (9, "Trạng thái:"), (10, "Người xử lý:")]
    for r, t in labels:
        ws.cell(row=r, column=1, value=t).font = Font(bold=True)
    ws["C9"] = "(điền: SAN_SANG | THIEU_THONG_TIN | CAN_NGUOI_QUYET - có thể ghi nhiều giá trị cách nhau dấu ;)"
    ws["C9"].font = Font(italic=True, color="808080")
    ws["C10"] = "(tên người duyệt trước khi gửi - để trống, người thật điền)"
    ws["C10"].font = Font(italic=True, color="808080")
    hdr = ["STT", "Mã hàng", "Tên hàng", "ĐVT", "Số lượng", "Đơn giá (VNĐ)", "Thành tiền (VNĐ)", "Ghi chú"]
    for i, h in enumerate(hdr, 1):
        c = ws.cell(row=13, column=i, value=h); c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F4E78"); c.alignment = Alignment(horizontal="center", wrap_text=True); c.border = box
    for r in range(14, 29):
        for i in range(1, 9): ws.cell(row=r, column=i).border = box
    tot = [(29, "Cộng tiền hàng"), (30, "Chiết khấu"), (31, "Phí giao hàng"), (32, "Cộng trước VAT"), (33, "VAT"), (34, "Tổng cộng")]
    for r, t in tot:
        ws.cell(row=r, column=6, value=t).font = Font(bold=True)
        ws.cell(row=r, column=6).alignment = Alignment(horizontal="right")
        ws.cell(row=r, column=7).border = box; ws.cell(row=r, column=7).number_format = "#,##0"
    ws["A36"] = "Điều kiện: Giá chưa gồm VAT trừ khi ghi khác. Mức VAT lấy từ sheet 'Tham số' - cần KIỂM VỚI KẾ TOÁN trước khi gửi khách."
    ws["A37"] = "Giao hàng: thời gian giao cụ thể do kho xác nhận bằng văn bản, báo giá này không phải cam kết ngày giao."
    ws["A38"] = "Thanh toán: theo điều kiện công ty (xem dieu-kien-giao-hang.txt). Báo giá có hiệu lực theo số ngày ở sheet 'Tham số'."
    ws["A40"] = "Người lập báo giá                                              Người duyệt (tên, chữ ký)"
    for col, w in zip("ABCDEFGH", [6, 26, 44, 8, 10, 16, 18, 40]): ws.column_dimensions[col].width = w
    t = wb.create_sheet("Tham số")
    rows = [("tham_so", "gia_tri", "ghi_chu"),
            ("vat_percent", VAT_PERCENT, "GIÁ TRỊ MINH HỌA để làm bài. Không khẳng định là thuế suất hiện hành - kiểm với kế toán. Đổi ở đây thì báo giá tính lại theo số này."),
            ("ngay_bao_gia", NGAY_BAO_GIA, "Ngày dùng cho mọi báo giá của bài này"),
            ("hieu_luc_ngay", HIEU_LUC_NGAY, "Số ngày báo giá còn hiệu lực"),
            ("lam_tron", "đồng", "Mọi số tiền làm tròn đến đồng (0,5 làm tròn lên)")]
    for r, row in enumerate(rows, 1):
        for i, v in enumerate(row, 1): t.cell(row=r, column=i, value=v)
    for c in t[1]: c.font = Font(bold=True)
    t.column_dimensions["A"].width = 16; t.column_dimensions["B"].width = 14; t.column_dimensions["C"].width = 100
    wb.save(path)

# ---------------------------------------------------------------- chính sách (docx) + giao hàng (txt)
def build_policy(path):
    d = Document()
    d.add_heading("Chính sách chiết khấu và thẩm quyền - Công ty An Phát Demo (giả)", 1)
    d.add_paragraph("Văn bản nội bộ, phiên bản 11/2026. Dữ liệu giả để học, không phải chính sách của doanh nghiệp thật.")
    d.add_heading("1. Giá bán", 2)
    d.add_paragraph("Giá bán là giá trong bảng giá hiện hành (xem bang-gia.xlsx), chưa gồm VAT. Mỗi mã hàng có tối đa ba bậc giá theo số lượng của chính mã đó; "
                    "số lượng của các mã khác nhau không cộng gộp để lấy bậc giá. Khách nhắc đến giá cũ đã báo từ lần trước thì công ty KHÔNG tự động giữ giá cũ: "
                    "báo giá theo bảng giá hiện hành và chuyển trưởng phòng kinh doanh quyết nếu khách đòi giữ giá cũ.")
    d.add_heading("2. Chiết khấu theo giá trị đơn hàng (áp dụng tự động)", 2)
    d.add_paragraph("Giá trị đơn hàng là tổng tiền hàng của tất cả các dòng, sau khi đã áp bậc giá, trước VAT và trước chiết khấu. "
                    "Đơn từ 10.000.000 đồng đến dưới 30.000.000 đồng: chiết khấu 2 phần trăm. Đơn từ 30.000.000 đồng trở lên: chiết khấu 4 phần trăm. "
                    "Đơn dưới 10.000.000 đồng: không có chiết khấu theo giá trị đơn. "
                    "Chiết khấu này chỉ tính trên các dòng KHÔNG thuộc nhóm Thiết bị (cột Nhóm trong bảng giá). Dòng thuộc nhóm Thiết bị giữ giá bảng giá.")
    d.add_heading("3. Chiết khấu thêm do nhân viên kinh doanh quyết", 2)
    d.add_paragraph("Khi khách xin giảm thêm, nhân viên kinh doanh được đồng ý tối đa 2 phần trăm tính trên tiền hàng các dòng không thuộc nhóm Thiết bị. "
                    "Tổng chiết khấu (mục 2 cộng mục 3) mà nhân viên được tự quyết không vượt 5 phần trăm. "
                    "Nếu khách xin mức tổng cao hơn 5 phần trăm, hoặc xin giảm cho dòng thuộc nhóm Thiết bị, nhân viên KHÔNG được hứa: "
                    "báo giá chỉ áp chiết khấu mục 2 và ghi rõ yêu cầu giảm giá đang chờ trưởng phòng hoặc giám đốc quyết.")
    d.add_heading("4. Quà tặng, khuyến mại, công nợ", 2)
    d.add_paragraph("Quà tặng kèm (ví dụ mua 10 tặng 1), khuyến mại ngoài chính sách, bán nợ, hoặc đổi điều kiện thanh toán: chỉ giám đốc được quyết. "
                    "Nhân viên không được hứa với khách; ghi nhận yêu cầu và chuyển lên.")
    d.add_heading("5. Hàng không có trong bảng giá", 2)
    d.add_paragraph("Nếu khách hỏi mặt hàng không có trong bảng giá, không tự đặt giá và không tự thay bằng hàng khác. Ghi rõ là chưa có trong bảng giá "
                    "và chuyển phòng mua hàng xem có nhập được không.")
    d.add_heading("6. Làm tròn", 2)
    d.add_paragraph("Mọi số tiền làm tròn đến đồng, 0,5 đồng làm tròn lên. Chiết khấu làm tròn một lần trên tổng tiền hàng của các dòng được chiết khấu.")
    d.save(path)

def build_delivery(path):
    txt = """ĐIỀU KIỆN GIAO HÀNG VÀ THANH TOÁN - Công ty An Phát Demo (giả, để học)
Phiên bản 11/2026

1. Khu vực nội thành (giao theo bảng phí nội thành)
   Hà Nội: các quận Ba Đình, Hoàn Kiếm, Đống Đa, Hai Bà Trưng, Cầu Giấy, Thanh Xuân, Tây Hồ, Long Biên, Hoàng Mai, Nam Từ Liêm, Bắc Từ Liêm, Hà Đông.
   TP. Hồ Chí Minh: Quận 1, Quận 3, Quận 5, Quận 7, Quận 10, Bình Thạnh, Phú Nhuận, Tân Bình, Gò Vấp.
   Mọi địa chỉ khác (huyện, thị xã, tỉnh khác, khu công nghiệp ngoài các quận trên) coi là ngoại thành / ngoại tỉnh.

2. Phí giao hàng
   Nội thành: miễn phí giao hàng nếu giá trị đơn sau chiết khấu, trước VAT, từ 3.000.000 đồng trở lên. Dưới mức đó thu phí 40.000 đồng mỗi đơn.
   Phí giao hàng được cộng vào số tiền trước VAT của báo giá (kế toán sẽ kiểm tra cách tính thuế cho dòng phí này).
   Ngoại thành / ngoại tỉnh: phí theo cước của đơn vị vận chuyển, do nhân viên điều phối báo sau. Báo giá ghi "phí giao hàng theo thỏa thuận" và chuyển người quyết, không tự đặt con số.
   Chưa biết địa chỉ giao: chưa tính phí giao hàng, hỏi lại khách.

3. Thời gian giao
   Hàng đang "Còn hàng": thường giao trong vài ngày làm việc kể từ khi xác nhận đơn và thanh toán, nhưng đây chỉ là mức tham khảo.
   Hàng "Đặt hàng" hoặc "Tạm hết hàng, chờ nhập": ngày có hàng do thủ kho / phòng mua hàng xác nhận.
   Nhân viên kinh doanh KHÔNG được hứa ngày, giờ giao cụ thể trong email hay báo giá. Khi khách hỏi, trả lời: sẽ có xác nhận lịch giao của kho bằng văn bản.
   Khách đòi giao đúng giờ hoặc giao gấp: chuyển người quyết (trưởng kho / giám đốc).

4. Thanh toán
   Mặc định: chuyển khoản trước khi giao hàng (hoặc thanh toán khi nhận hàng với khách đã có thỏa thuận bằng văn bản).
   Bán nợ, công nợ 15/30 ngày: chỉ giám đốc duyệt, không nhân viên nào tự hứa.
   Khách cần hóa đơn công ty: cung cấp tên công ty, mã số thuế, địa chỉ xuất hóa đơn. Thông tin thiếu thì hỏi lại khách. Mức thuế và cách xuất hóa đơn do kế toán xác nhận.

5. Hiệu lực báo giá
   7 ngày kể từ ngày báo giá, trừ khi có ghi khác.
"""
    Path(path).write_text(txt, encoding="utf-8")

# ---------------------------------------------------------------- 12 yêu cầu
# Mỗi yêu cầu: text + spec (cái ĐÚNG). qty = số lượng theo ĐVT gốc.
def requests():
    R = []
    def add(id, kenh, nguoi, text, spec): R.append(dict(id=id, kenh=kenh, nguoi=nguoi, text=text, **spec))

    add("R01", "email", "chị Lan - Công ty TNHH Cơ khí Ánh Dương (giả)", """Từ: lan.mua.hang@example.com
Đến: baogia@example.com
Tiêu đề: Đề nghị báo giá VPP tháng 12

Chào anh/chị bên An Phát,

Bên em là Công ty TNHH Cơ khí Ánh Dương (công ty giả). Nhờ anh/chị báo giá giúp:
- Giấy A4 80gsm: 25 ram
- Bút bi xanh TL027 (mã BUT-BI-TL027-XANH): 3 hộp
- Băng keo trong 48mm: 10 cuộn

Giao về: 12 Đường Số 5, Quận Hà Đông, Hà Nội. Bên em là khách quen của công ty, anh/chị giảm giúp 2% nhé.
Em cảm ơn.

Chị Lan - Phòng Hành chính - ĐT 0900 000 101""",
        dict(items=[("GIAY-A4-80", 25), ("BUT-BI-TL027-XANH", 60), ("BANGKEO-TRONG-48", 10)], dia_chi="noi_thanh", xin_giam=2.0,
             thieu=[], quyet=[], nhan_xet="Đủ thông tin; 3 hộp bút bi = 60 cây (bậc 2); xin giảm 2% trong thẩm quyền; đơn dưới 3 triệu nên có phí giao 40.000."))

    add("R02", "zalo", "anh Dũng - quán in Dũng Phát (giả)", """[Zalo 09:12] Dung Phat: chi oi gui bao gia giay a4 80 voi muc hp 12a nha
[Zalo 09:12] Dung Phat: muc 6 hop
[Zalo 09:13] Dung Phat: nhanh giup anh, chieu anh can""",
        dict(items=[("MUC-HP-12A", 6), ("GIAY-A4-80", None)], dia_chi=None, xin_giam=0,
             thieu=["so_luong_giay_a4_80", "dia_chi_giao"], quyet=["giao_gap_chieu_nay"], nhan_xet="Thiếu số lượng giấy A4 80 và địa chỉ giao; chỉ báo giá được dòng mực. 'Chiều anh cần' = đòi giao gấp: theo điều kiện giao hàng phải chuyển người quyết (đáp án v1 bỏ sót nhãn này, sửa trong v2 sau khi thấy cả hai agent ghi nhận)."))

    add("R03", "email", "em Hạnh - Văn phòng luật Hòa Bình (giả)", """Từ: hanh.vp@example.com
Tiêu đề: bao gia

Chào bên An Phát, em cần:
1. giay a4 80 - 10 ram
2. MUC-HP-12C - 4 hop
3. muc hp 12a x 3 hop
4. BUT-GEL-05-XANH 2 hop (mau xanh)

Giao Quận Cầu Giấy, Hà Nội. Tòa nhà Mẫu số 3 đường Demo.
Cảm ơn.""",
        dict(items=[("GIAY-A4-80", 10), ("MUC-HP-12A", 3), ("MA_SAI:MUC-HP-12C", 4), ("MA_SAI:BUT-GEL-05-XANH", None)], dia_chi="noi_thanh", xin_giam=0,
             thieu=["ma_MUC-HP-12C", "ma_BUT-GEL-05-XANH"], quyet=[],
             nhan_xet="MUC-HP-12C và BUT-GEL-05-XANH không có trong bảng giá (chỉ có MUC-HP-12A, BUT-GEL-05-DEN): hỏi lại khách, không tự đoán. Dòng 'muc hp 12a' viết thường vẫn nhận ra được."))

    add("R04", "email", "chị Mai - Trường mầm non Hoa Sen (giả)", """Từ: mai.hanhchinh@example.com
Tiêu đề: Báo giá thiết bị cho năm học mới

Anh chị báo giúp trường:
- Máy photocopy A3 đa năng: 1 cái
- Máy chiếu độ phân giải 4K: 2 cái
- Giấy A4 70gsm: 30 ram

Giao: 25 Đường Mẫu, Quận 7, TP. Hồ Chí Minh. Cần gấp trong tuần.""",
        dict(items=[("GIAY-A4-70", 30), ("KHONG_CO:máy photocopy A3 đa năng", 1), ("KHONG_CO:máy chiếu 4K", 2)], dia_chi="noi_thanh", xin_giam=0,
             thieu=[], quyet=["hang_khong_co_trong_bang_gia"],
             nhan_xet="Máy photocopy và máy chiếu không có trong bảng giá: không đặt giá, không thay hàng khác; chuyển phòng mua hàng."))

    add("R05", "email", "anh Quân - Công ty CP Xây dựng Bình Minh (giả)", """Từ: quan.vt@example.com
Tiêu đề: RE: báo giá máy in + vật tư

Chào bên An Phát,
Báo giá giúp mình:
- Máy in laser đen trắng 3100: 3 cái
- Mực HP 78A: 10 hộp
- Giấy A4 80: 40 ram
Giao: 88 Đường Demo, Quận Thanh Xuân, Hà Nội.

Bên mình đang so với 2 nơi khác, nếu bên anh giảm 25% tổng đơn thì mình chốt luôn trong tuần này, không thì thôi.""",
        dict(items=[("MAY-IN-LASER-3100", 3), ("MUC-HP-78A", 10), ("GIAY-A4-80", 40)], dia_chi="noi_thanh", xin_giam=25.0,
             thieu=[], quyet=["chiet_khau_25_vuot_tham_quyen"],
             nhan_xet="Xin giảm 25% vượt xa mức 5%: báo giá chỉ áp chiết khấu theo đơn, ghi yêu cầu giảm đang chờ người quyết."))

    add("R06", "zalo", "chị Thu - Công ty TNHH Nội thất Phú Gia (giả)", """[Zalo] Chi Thu NT Phu Gia:
chị gửi em báo giá: 2 thùng giấy A4 70, 5 tá bút bi xanh TL027, 3 lốc băng keo 2 mặt 24mm,
2 hộp bút gel đen, với 1 thùng mực HP 12A nữa nhé
giao Quận 10 TPHCM, 5 Đường Mẫu""",
        dict(items=[("GIAY-A4-70", 10), ("BUT-BI-TL027-XANH", 60), ("BANGKEO-2MAT-24", 18), ("BUT-GEL-05-DEN", 24), ("DON_VI_KHONG_RO:MUC-HP-12A:thùng", None)], dia_chi="noi_thanh", xin_giam=0,
             thieu=["thung_muc_hp_12a"], quyet=[],
             nhan_xet="2 thùng giấy=10 ram; 5 tá=60 cây; 3 lốc=18 cuộn; 2 hộp gel=24 cây. 'Thùng mực' không có quy đổi trong bảng: phải hỏi."))

    add("R07", "email", "anh Kiên - Công ty TNHH Logistics Tân Phát (giả)", """Từ: kien.kho@example.com
Tiêu đề: Báo giá lại đợt trước

Chào An Phát. Tháng trước anh Hùng bên em báo bút bi xanh TL027 giá 3.500đ/cây, nhờ bên em báo lại đúng giá đó nhé.
Lần này:
- Bút bi xanh TL027: 50 cây
- Sổ caro A4 200 trang: 49 quyển
- File còng 7cm: 100 cái
Giao tại 15 Đường Mẫu, Quận Gò Vấp, TP. HCM.""",
        dict(items=[("BUT-BI-TL027-XANH", 50), ("SO-CARO-A4-200", 49), ("FILE-COC-7P", 100)], dia_chi="noi_thanh", xin_giam=0,
             thieu=[], quyet=["giu_gia_cu_3500"],
             nhan_xet="Số lượng sát mốc bậc giá (50 và 49 và 100). Khách đòi giữ giá cũ 3.500: không tự đồng ý, báo theo giá hiện hành và chuyển người quyết."))

    add("R08", "email", "chị Phương - Xưởng đóng gói Thành Đạt (giả)", """Từ: phuong.xuong@example.com
Tiêu đề: Báo giá vật tư đóng gói - gấp

Chào anh/chị,
Xưởng em cần:
- Thùng carton 30x20x20: 300 cái
- Màng bọc PE 50cm: 24 cuộn
- Băng keo trong 48mm: 72 cuộn

Giao về Lô B2, Khu công nghiệp Mẫu, Bắc Ninh. Anh chị xác nhận giúp em sẽ giao TRƯỚC 10 GIỜ SÁNG THỨ SÁU tuần này và báo luôn phí vận chuyển nhé, không kịp là em huỷ đơn.""",
        dict(items=[("THUNG-CARTON-30X20X20", 300), ("MANG-BOC-PE-50CM", 24), ("BANGKEO-TRONG-48", 72)], dia_chi="ngoai_tinh", xin_giam=0,
             thieu=[], quyet=["hua_gio_giao", "phi_van_chuyen_ngoai_tinh"],
             nhan_xet="Bắc Ninh là ngoại tỉnh: phí theo thỏa thuận, không tự đặt số; không hứa giờ giao thứ Sáu. Số lượng đúng mốc bậc 3 (72 cuộn băng keo)."))

    add("R09", "zalo", "chú Sơn (khách cũ) (giả)", """[Zalo] Chu Son: Em oi, bao gia nhu dot truoc cho chu nhe, so luong tang gap doi. Giao cho cho cu.""",
        dict(items=[], dia_chi=None, xin_giam=0,
             thieu=["danh_sach_hang", "so_luong", "dia_chi_giao"], quyet=[],
             nhan_xet="Không có danh sách hàng, không biết 'đợt trước' là gì: không đoán, không lập dòng, chỉ hỏi lại."))

    add("R10", "zalo", "chị Ngọc - Công ty CP Truyền thông Sao Mai (giả)", """[Zalo] Ngoc SaoMai:
em gửi list nha chị
mực hp 78a 4 hộp ... à thêm 2 hộp nữa (vậy tổng 6 hộp)
giấy a4 70: 10 ram
máy hủy giấy 12 tờ 1 cái
ghế xoay lưới 6 cái
mực epson 664 đen 12 chai
à giấy a4 70 thêm 1 thùng nữa (cộng vào 10 ram ở trên)
giao Cầu Giấy HN, 30 Đường Demo
bên em giảm thêm 2% được không chị""",
        dict(items=[("MUC-HP-78A", 6), ("GIAY-A4-70", 15), ("MAY-HUY-GIAY-S12", 1), ("GHE-XOAY-LUOI-01", 6), ("MUC-EPS-664-DEN", 12)], dia_chi="noi_thanh", xin_giam=2.0,
             thieu=[], quyet=[],
             nhan_xet="Gộp dòng trùng: 78A = 6 hộp; giấy A4 70 = 10 + 5 = 15 ram. Đơn ≥ 10 triệu: chiết khấu 2% theo đơn + 2% thêm = 4% (≤ 5%, nhân viên tự quyết), chỉ tính trên dòng không thuộc Thiết bị."))

    add("R11", "email", "anh Hưng - Công ty TNHH Thương mại Đại Việt (giả)", """Từ: hung.mua@example.com
Tiêu đề: Báo giá trang bị văn phòng mới (đợt lớn)

Chào An Phát,
Bên mình mở văn phòng mới, cần:
- Máy in laser đen trắng 3100: 6 cái
- Máy scan A4 hai mặt mẫu 100: 2 cái
- Máy chấm công vân tay: 4 cái
- Giấy A4 80: 60 ram
- Mực Canon 325: 12 hộp
Giao: 200 Đường Mẫu, Quận Hoàng Mai, Hà Nội.

Đơn này trên 50 triệu, bên mình muốn giảm 10% toàn đơn, và mua 10 ram giấy tặng 1 ram nhé.""",
        dict(items=[("MAY-IN-LASER-3100", 6), ("MAY-SCAN-A4-100", 2), ("CC-VANTAY-01", 4), ("GIAY-A4-80", 60), ("MUC-CANON-325", 12)], dia_chi="noi_thanh", xin_giam=10.0,
             thieu=[], quyet=["chiet_khau_10_vuot_tham_quyen", "qua_tang_mua_10_tang_1"],
             nhan_xet="Đơn ≥ 30 triệu: chiết khấu theo đơn 4% chỉ trên dòng không Thiết bị. Xin 10% và quà tặng: người quyết. Mực Canon 325 đang tạm hết hàng: ghi chú, không hứa ngày."))

    add("R12", "zalo", "bạn Vy - Công ty TNHH Dịch vụ Kế toán Số Hồng (giả)", """[Zalo] Vy Sohong:
ban gui bg: giay a4 70 -5 thung; but bi xanh TL027 2 ta; decal a4 3 xap; mang boc pe 2 cuon; kep buom 32 - 4 hop
giao 7 Duong Mau, Quan Bac Tu Liem, HN
xuat hoa don cong ty nhe. ben minh xin cong no 30 ngay duoc ko ban""",
        dict(items=[("GIAY-A4-70", 25), ("BUT-BI-TL027-XANH", 24), ("DECAL-A4-100", 3), ("MANG-BOC-PE-50CM", 2), ("KEP-BUOM-32", 4)], dia_chi="noi_thanh", xin_giam=0,
             thieu=["thong_tin_hoa_don_cong_ty"], quyet=["cong_no_30_ngay"],
             nhan_xet="Không dấu, viết tắt. 5 thùng giấy=25 ram; 2 tá=24 cây (bậc 1). Xin công nợ 30 ngày: chỉ giám đốc duyệt. Xuất hóa đơn: thiếu MST/tên pháp lý."))
    return R

# từ khóa kiểm tra (đã bỏ dấu, chữ thường) cho từng nhãn câu hỏi/cần-quyết; mỗi nhãn là list các nhóm, phải khớp TẤT CẢ nhóm
KEYS = {
 "so_luong_giay_a4_80": [["giay"], ["so luong|bao nhieu|may ram|can .*ram"]],
 "dia_chi_giao": [["dia chi|giao den|giao ve|noi giao|giao tai"]],
 "ma_MUC-HP-12C": [["12c"], ["khong co|khong thay|xac nhan|nham|ma nao|hoi lai|khong ton tai|chua co"]],
 "ma_BUT-GEL-05-XANH": [["gel.*xanh|05-xanh"], ["khong co|khong thay|xac nhan|nham|ma nao|hoi lai|khong ton tai|chua co|den"]],
 "thung_muc_hp_12a": [["thung"], ["muc"], ["bao nhieu hop|may hop|quy doi|bao nhieu|so hop|bang .*hop|quy cach|cai|so luong"]],
 "danh_sach_hang": [["dot truoc|lan truoc|truoc do"], ["mat hang|danh sach|cu the|hang nao|loai nao|liet ke|gui lai"]],
 "so_luong": [["so luong|bao nhieu"]],
 "thong_tin_hoa_don_cong_ty": [["hoa don"], ["ma so thue|mst|ten cong ty|thong tin"]],
 "hang_khong_co_trong_bang_gia": [["photocopy"], ["chieu"], ["khong co|chua co|ngoai bang gia|khong nam trong|phong mua|nhap"]],
 "chiet_khau_25_vuot_tham_quyen": [["25"], ["can nguoi quyet|truong phong|giam doc|cho duyet|cho quyet|vuot tham quyen|phe duyet|duyet"]],
 "chiet_khau_10_vuot_tham_quyen": [["10 ?%|10 phan tram|10 phantram"], ["can nguoi quyet|truong phong|giam doc|cho duyet|cho quyet|vuot tham quyen|phe duyet|duyet"]],
 "qua_tang_mua_10_tang_1": [["tang"], ["can nguoi quyet|giam doc|cho duyet|cho quyet|phe duyet|duyet|khong the hua|chua the"]],
 "giu_gia_cu_3500": [["3[.,]?500"], ["can nguoi quyet|truong phong|cho duyet|cho quyet|phe duyet|duyet|khong tu dong|hien hanh|chua the"]],
 "giao_gap_chieu_nay": [["chieu|gap|nhanh"], ["can nguoi quyet|kho xac nhan|truong kho|giam doc|chua the|khong the cam ket|khong cam ket|xac nhan bang van ban|cho duyet"]],
 "hua_gio_giao": [["10 gio|10h|thu sau|thu 6"], ["can nguoi quyet|kho xac nhan|xac nhan .*(kho|van ban)|chua the|khong the hua|khong cam ket|truong kho|giam doc|cho duyet|chua cam ket"]],
 "phi_van_chuyen_ngoai_tinh": [["van chuyen|giao hang|ship"], ["thoa thuan|bao sau|dieu phoi|can nguoi quyet"]],
 "cong_no_30_ngay": [["cong no|ban no|tra cham|30 ngay"], ["can nguoi quyet|giam doc|cho duyet|cho quyet|phe duyet|duyet|chua the"]],
}

# ---------------------------------------------------------------- tính đáp án
def solve(req):
    lines, khong_co, ma_sai, thieu_sl = [], [], [], []
    for ma, q in req["items"]:
        if ma.startswith("MA_SAI:"): ma_sai.append(ma.split(":", 1)[1]); continue
        if ma.startswith("KHONG_CO:"): khong_co.append(ma.split(":", 1)[1]); continue
        if ma.startswith("DON_VI_KHONG_RO:"): thieu_sl.append(ma.split(":")[1]); continue
        if q is None: thieu_sl.append(ma); continue
        c = CAT[ma]; up = unit_price(ma, q)
        lines.append(dict(ma_hang=ma, nhom=c[2], dvt=c[3], so_luong=q, bac=tier_of(ma, q), don_gia=up, thanh_tien=up * q))
    sub = sum(l["thanh_tien"] for l in lines)
    base_ck = sum(l["thanh_tien"] for l in lines if l["nhom"] != "Thiết bị")
    pct_auto = 4.0 if sub >= 30_000_000 else (2.0 if sub >= 10_000_000 else 0.0)
    xin = req["xin_giam"]
    pct_them = 0.0
    # Khách xin giảm X%: nhân viên chỉ được cấp tối đa 2% thêm (mục 3); X > 5% thì không cấp gì thêm, chỉ áp mục 2.
    if 0 < xin <= 5.0: pct_them = min(xin, 2.0)
    pct_total = pct_auto + pct_them
    if pct_total > 5.0: pct_total = pct_auto  # an toàn
    ck = int(base_ck * pct_total / 100 + 0.5)
    ship = None; ship_note = ""
    sau_ck = sub - ck
    if req["dia_chi"] == "noi_thanh":
        ship = 0 if sau_ck >= NGUONG_MIEN_PHI_SHIP else PHI_SHIP_NOI_THANH
    elif req["dia_chi"] == "ngoai_tinh":
        ship = None; ship_note = "theo thỏa thuận"
    else:
        ship_note = "chưa biết địa chỉ"
    truoc_vat = sau_ck + (ship or 0)
    vat = int(truoc_vat * VAT_PERCENT / 100 + 0.5)
    # trạng thái
    st = []
    if req["thieu"] or ma_sai or thieu_sl or not lines: st.append("THIEU_THONG_TIN")
    if req["quyet"]: st.append("CAN_NGUOI_QUYET")
    if req["dia_chi"] is None and "THIEU_THONG_TIN" not in st: st.append("THIEU_THONG_TIN")
    if not st: st.append("SAN_SANG")
    return dict(
        id=req["id"], lines=lines, khong_co_trong_bang_gia=khong_co, ma_sai=ma_sai, thieu_so_luong_hoac_don_vi=thieu_sl,
        chiet_khau_pct_theo_don=pct_auto, chiet_khau_pct_them_duoc_cap=pct_them, chiet_khau_pct_ap_dung=pct_total,
        xin_giam_pct=xin, co_so_chiet_khau=base_ck, tien_hang=sub, chiet_khau=ck,
        phi_giao=ship, phi_giao_ghi_chu=ship_note, cong_truoc_vat=truoc_vat if lines else 0, vat_percent=VAT_PERCENT,
        vat=vat if lines else 0, tong_cong=(truoc_vat + vat) if lines else 0,
        trang_thai=st, nhan_thieu=req["thieu"], nhan_can_quyet=req["quyet"], nhan_xet=req["nhan_xet"],
    )

def main():
    random.seed(SEED)
    (HERE / "yeu-cau").mkdir(exist_ok=True)
    OUT_ANSWER.parent.mkdir(parents=True, exist_ok=True)
    build_bang_gia(HERE / "bang-gia.xlsx")
    build_mau(HERE / "mau-bao-gia.xlsx")
    build_policy(HERE / "chinh-sach-chiet-khau.docx")
    build_delivery(HERE / "dieu-kien-giao-hang.txt")
    reqs = requests(); ans = []
    for r in reqs:
        (HERE / "yeu-cau" / f"{r['id']}.txt").write_text(r["text"].strip() + "\n", encoding="utf-8")
        ans.append(solve(r))
    meta = dict(seed=SEED, ngay=NGAY_BAO_GIA, vat_percent=VAT_PERCENT,
                ghi_chu="VAT 10 là tham số minh họa trong mau-bao-gia.xlsx (sheet 'Tham số'), không khẳng định thuế suất hiện hành.",
                tu_khoa={k: v for k, v in KEYS.items()})
    OUT_ANSWER.write_text(json.dumps(dict(meta=meta, yeu_cau=ans), ensure_ascii=False, indent=1), encoding="utf-8")
    print("OK:", len(reqs), "yêu cầu;", OUT_ANSWER)
    for a in ans:
        print(a["id"], a["trang_thai"], "hàng=", a["tien_hang"], "ck=", a["chiet_khau"], f"({a['chiet_khau_pct_ap_dung']}%)", "ship=", a["phi_giao"], "tổng=", a["tong_cong"])

if __name__ == "__main__":
    main()
