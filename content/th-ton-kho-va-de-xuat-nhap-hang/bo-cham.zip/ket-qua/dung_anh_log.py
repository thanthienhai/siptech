"""Dung anh 'terminal' tu log THAT: python -X utf8 dung_anh_log.py <log.json> <tien_to_anh> <ten_hien_thi>"""
import json, sys, html, re
from pathlib import Path
import os
sys.path.insert(0, os.environ.get("AGENTLAB_DIR") or str(Path(__file__).resolve().parents[5] / "siptech-video" / "agentlab"))
from term import render_blocks, shot_html as _shot_html, CSS, scrub_text
def shot_html(h, *a, **k): return _shot_html(scrub_text(h), *a, **k)
log, pref, name = sys.argv[1:4]
ROOT = Path(__file__).resolve().parent.parent
t = json.loads(Path(log).read_text(encoding="utf-8"))
import re, copy
def clean(x):
    if isinstance(x, str): return re.sub(r"PC (197121)", r"user \1", scrub_text(x))   # ten nguoi dung Windows trong ket qua ls -la
    if isinstance(x, dict): return {k: clean(v) for k, v in x.items()}
    if isinstance(x, list): return [clean(v) for v in x]
    return x
t = clean(t)
NOISE = re.compile(r"profile\.ps1|OpenSpecCompletion|^Line \||^\s+3 \||~~~~|The term 'C|function, script file|that the path is correct|^Command output:|^Created At|^Completed At|^$")
for b in t["blocks"]:
    if b["kind"] == "tool" and b.get("output"):
        b["output"] = chr(10).join(l for l in b["output"].splitlines() if not NOISE.search(l.strip()) and not NOISE.search(l))
# 1) prompt day du
p = html.escape(t["prompt"])
h = (f'<!doctype html><meta charset="utf-8"><style>{CSS}</style><div style="padding:18px;width:1280px"><div class="win"><div class="bar"><span class="dot r"></span><span class="dot y"></span><span class="dot g"></span>'
     f'<span class="t">{scrub_text(name)} · prompt giao việc (nguyên văn, đã dùng cho cả hai agent)</span></div><div class="body" style="font-size:13.5px"><div class="u"><b>❯</b> {p}</div></div></div></div>')
shot_html(h, ROOT / f"anh/{pref}-prompt.png", 1320, ".win")
# 2) agent dang lam
bl = t["blocks"]
idx = (0, 12, 15, 49, 61, 93, 107) if t["agent"] == "agy" else (0, 1, 3, 7, 11, 12, 32)
sel = [bl[i] for i in idx if i < len(bl)]
shot_html(render_blocks(sel, f"{name} · agent làm việc (trích 7 bước từ log)", None, 6, 1280, False), ROOT / f"anh/{pref}-dang-lam.png", 1320, ".win")
# 3) ket qua cuoi
final = [b for b in bl if b["kind"] == "assistant"][-1:]
shot_html(render_blocks(final, f"{name} · lời tổng kết cuối của agent", None, 30, 1280, False), ROOT / f"anh/{pref}-ket-qua-cuoi.png", 1320, ".win")
print("ok")
