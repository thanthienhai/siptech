#!/usr/bin/env python3
"""Tự kiểm nhap_hang_loat.csv / nhap_hang_loat.xlsx so với thong_so.csv và quy_dinh_shop.md.

Chạy:  python kiem.py   (trong thư mục chứa các file). Thoát mã 0 nếu sạch, 1 nếu còn lỗi.

Các nhóm kiểm:
  1. Cấu trúc: đúng cột, đúng thứ tự, đủ 40 SKU, CSV khớp XLSX, CSV có BOM.
  2. Độ dài: tiêu đề, mô tả, từng gạch, từ khóa.
  3. Từ cấm (kể cả không dấu / viết hoa) ở mọi trường.
  4. Mọi con số trong tiêu đề, mô tả, gạch, từ khóa phải có trong bảng của ĐÚNG sản phẩm.
  5. Trạng thái + truong_can_bo_sung khớp với trường thật sự thiếu; cụm CẦN BỔ SUNG đặt đúng chỗ.
  6. Sự thật: giá trị trong bảng xuất hiện đúng trong mô tả; ghi_chu_noi_bo không rò rỉ;
     chỉ nói "đã có phiếu công bố" khi có số phiếu.
  7. Giọng thương hiệu: không emoji, không viết HOA nhấn mạnh, tối đa 1 dấu "!", không "quý khách"...
"""
import csv
import re
import sys
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = HERE / "thong_so.csv"
OUT_CSV = HERE / "nhap_hang_loat.csv"
OUT_XLSX = HERE / "nhap_hang_loat.xlsx"
BANNED = HERE / "tu_cam.txt"

HEAD = ["sku", "tieu_de", "mo_ta", "gach_1", "gach_2", "gach_3", "gach_4", "gach_5",
        "tu_khoa", "trang_thai", "truong_can_bo_sung"]
MISSING = {"", "?", "chưa rõ", "liên hệ ncc", "n/a", "chưa có"}
REQ = ["dung_tich", "thanh_phan_noi_bat", "xuat_xu", "han_su_dung",
       "cong_dung_tren_bao_bi", "cach_dung"]
NO_FACT_COLS = {"sku", "ghi_chu_noi_bo"}          # không dùng làm nguồn xác nhận con số
CAPS_OK = {"CẦN", "BỔ", "SUNG", "SPF", "PA", "UV", "DEMO"}
# Cụm nhạy cảm lấy từ ghi_chu_noi_bo: tuyệt đối không được lọt vào nội dung.
LEAK_TERMS = ["nhạy cảm", "bà bầu", "em bé", "cồn", "paraben", "fda", "nhập khẩu", "chính ngạch",
              "15 tháng", "15%", "bảo quản sau khi mở", "vip", "rẻ hơn", "khu vực", "thị trường",
              "viêm da", "kiểm nghiệm"]
PLACEHOLDER_RE = re.compile(r"CẦN BỔ SUNG: ([a-z_]+)")
NUM_RE = re.compile(r"\d+(?:[.,]\d+)?")
EMOJI_RE = re.compile("[\U0001F000-\U0001FFFF☀-➿️‍]")


def miss(v):
    return v is None or v.strip().lower() in MISSING


def fold(s):
    """Hạ chữ thường, bỏ dấu tiếng Việt."""
    s = unicodedata.normalize("NFC", s).lower().replace("đ", "d")
    s = unicodedata.normalize("NFD", s)
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def words_norm(s):
    return re.sub(r"[^\w%+]+", " ", fold(s)).strip()


def contains_phrase(text, phrase):
    """Tìm cụm cấm theo ranh giới từ, cả dạng có dấu và không dấu."""
    for t, p in ((unicodedata.normalize("NFC", text).lower(), unicodedata.normalize("NFC", phrase).lower()),
                 (fold(text), fold(phrase))):
        if re.search(r"(?<!\w)" + re.escape(p) + r"(?!\w)", t):
            return True
    return False


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def read_xlsx(path):
    from openpyxl import load_workbook
    ws = load_workbook(path).active
    rows = [["" if c is None else str(c) for c in r] for r in ws.iter_rows(values_only=True)]
    return rows[0], [dict(zip(rows[0], r)) for r in rows[1:]]


def kiem(spec_rows, out_rows, banned, head=None):
    """Trả về danh sách (sku, nhóm, mô tả lỗi)."""
    errs = []

    def err(sku, group, msg):
        errs.append((sku, group, msg))

    spec = {r["sku"]: r for r in spec_rows}
    if head is not None and head != HEAD:
        err("-", "cấu trúc", f"cột sai/thứ tự sai: {head}")
    skus = [r["sku"] for r in out_rows]
    if len(out_rows) != 40:
        err("-", "cấu trúc", f"số dòng = {len(out_rows)}, cần 40")
    if skus != [r["sku"] for r in spec_rows]:
        err("-", "cấu trúc", "danh sách/thứ tự SKU không khớp thong_so.csv")
    if len(set(skus)) != len(skus):
        err("-", "cấu trúc", "SKU trùng")

    for o in out_rows:
        sku = o["sku"]
        s = spec.get(sku)
        if s is None:
            err(sku, "cấu trúc", "SKU không có trong thong_so.csv")
            continue
        bullets = [o.get(f"gach_{i}", "") for i in range(1, 6)]
        kws = [k.strip() for k in o["tu_khoa"].split(";")] if o["tu_khoa"].strip() else []
        fields = {"tieu_de": o["tieu_de"], "mo_ta": o["mo_ta"], "tu_khoa": o["tu_khoa"]}
        fields.update({f"gach_{i+1}": b for i, b in enumerate(bullets)})
        all_text = " ".join(fields.values())

        # 2. độ dài
        if not 25 <= len(o["tieu_de"]) <= 100:
            err(sku, "độ dài", f"tieu_de {len(o['tieu_de'])} ký tự (cần 25-100)")
        if not 200 <= len(o["mo_ta"]) <= 1500:
            err(sku, "độ dài", f"mo_ta {len(o['mo_ta'])} ký tự (cần 200-1500)")
        for i, b in enumerate(bullets, 1):
            if not b.strip():
                err(sku, "gạch", f"gach_{i} trống (cần đúng 5 gạch)")
            elif len(b) > 120:
                err(sku, "độ dài", f"gach_{i} {len(b)} ký tự (tối đa 120)")
        if "gach_6" in o:
            err(sku, "gạch", "có gach_6")
        if not 6 <= len(kws) <= 10:
            err(sku, "độ dài", f"tu_khoa có {len(kws)} cụm (cần 6-10)")
        for k in kws:
            if not k or len(k) > 30:
                err(sku, "độ dài", f"cụm từ khóa rỗng/quá 30 ký tự: '{k}'")
        if len({k.lower() for k in kws}) != len(kws):
            err(sku, "độ dài", "từ khóa trùng nhau")

        # 3. từ cấm
        for name, text in fields.items():
            for b in banned:
                if contains_phrase(text, b):
                    err(sku, "từ cấm", f"{name} chứa '{b}'")

        # 4. con số phải có trong bảng của đúng sản phẩm
        allowed_text = " ".join(v for k, v in s.items() if k not in NO_FACT_COLS and not miss(v))
        allowed_nums = set(NUM_RE.findall(allowed_text))
        for name, text in fields.items():
            for n in NUM_RE.findall(text):
                if n not in allowed_nums:
                    err(sku, "con số", f"{name} có số '{n}' không có trong bảng của {sku}")

        # 5. trạng thái
        missing = [c for c in REQ if miss(s[c])]
        want_status = "CAN_BO_SUNG" if missing else "SAN_SANG"
        if o["trang_thai"] != want_status:
            err(sku, "trạng thái", f"trang_thai={o['trang_thai']} nhưng cần {want_status}")
        got_missing = [x for x in o["truong_can_bo_sung"].split(";") if x]
        if sorted(got_missing) != sorted(missing):
            err(sku, "trạng thái", f"truong_can_bo_sung={got_missing}, cần {missing}")
        if not missing and o["truong_can_bo_sung"].strip():
            err(sku, "trạng thái", "SAN_SANG nhưng truong_can_bo_sung không trống")
        used = set(PLACEHOLDER_RE.findall(all_text))
        if used - set(missing):
            err(sku, "trạng thái", f"đặt CẦN BỔ SUNG cho trường không thiếu: {sorted(used - set(missing))}")
        for c in missing:
            if f"CẦN BỔ SUNG: {c}" not in o["mo_ta"]:
                err(sku, "trạng thái", f"mo_ta thiếu cụm 'CẦN BỔ SUNG: {c}'")
        if "CẦN BỔ SUNG" in all_text and "CẦN BỔ SUNG" in o["tieu_de"] + o["tu_khoa"]:
            err(sku, "trạng thái", "CẦN BỔ SUNG nằm trong tiêu đề/từ khóa")
        for lit in ("N/A", "chưa rõ", "liên hệ NCC", "chưa có", "đang chờ duyệt"):
            if lit.lower() in all_text.lower():
                err(sku, "sự thật", f"nội dung chép nguyên giá trị 'thiếu': '{lit}'")
        if re.search(r"(?<![\w])\?(?![\w])", all_text):
            err(sku, "sự thật", "nội dung chứa dấu '?' (giá trị thiếu bị chép)")

        # 6. sự thật
        desc = o["mo_ta"]
        for c in REQ:
            if not miss(s[c]) and s[c].strip() not in desc:
                err(sku, "sự thật", f"mo_ta không chứa đúng giá trị {c} = '{s[c].strip()}'")
        if not miss(s["chi_so_chong_nang"]) and s["chi_so_chong_nang"].strip() not in desc:
            err(sku, "sự thật", "mo_ta thiếu chỉ số chống nắng")
        if miss(s["chi_so_chong_nang"]) and re.search(r"\bSPF\b|\bPA\+", all_text):
            err(sku, "sự thật", "nói chỉ số chống nắng khi bảng không có")
        # xuất xứ nêu trong từ khóa phải đúng bảng
        for k in kws:
            if k.lower().startswith("xuất xứ") and k[len("xuất xứ"):].strip() != s["xuat_xu"].strip():
                err(sku, "sự thật", f"từ khóa xuất xứ sai: '{k}'")
        # ghi chú nội bộ không được rò rỉ
        note = s.get("ghi_chu_noi_bo", "") or ""
        for t in LEAK_TERMS:
            # chỉ báo khi cụm đó không phải thông tin hợp lệ của chính hàng này trong bảng
            if contains_phrase(all_text, t) and not contains_phrase(allowed_text, t):
                err(sku, "ghi chú nội bộ", f"nội dung chứa '{t}' (chỉ có ở ghi chú/chưa kiểm chứng)")
        nw = words_norm(note).split()
        tw = words_norm(all_text)
        for i in range(len(nw) - 2):
            tri = " ".join(nw[i:i + 3])
            if tri in tw:
                err(sku, "ghi chú nội bộ", f"chép cụm từ ghi_chu_noi_bo: '{tri}'")
        # phiếu công bố
        phieu = (s["so_phieu_cong_bo"] or "").strip()
        has_phieu = not miss(phieu) and phieu.lower() != "đang chờ duyệt"
        says_published = contains_phrase(all_text, "phiếu công bố") or contains_phrase(all_text, "đã công bố")
        if says_published and not has_phieu:
            err(sku, "sự thật", "nói đã có phiếu công bố nhưng bảng không có số phiếu")
        if says_published and has_phieu and phieu not in desc:
            err(sku, "sự thật", f"nhắc phiếu công bố nhưng không kèm số '{phieu}'")
        if has_phieu and phieu not in all_text:
            err(sku, "sự thật", f"bảng có số phiếu {phieu} nhưng nội dung không nêu (nên nêu)")

        # 7. giọng thương hiệu
        if not o["tieu_de"].startswith("Vườn Nhỏ"):
            err(sku, "giọng", "tiêu đề không bắt đầu bằng 'Vườn Nhỏ'")
        if s["ten_san_pham"].strip() not in o["tieu_de"]:
            err(sku, "giọng", "tiêu đề không chứa đúng tên sản phẩm")
        if "Vườn Nhỏ" not in desc or not re.search(r"\bbạn\b", desc):
            err(sku, "giọng", "mô tả phải xưng 'Vườn Nhỏ' và gọi 'bạn'")
        for bad in ("quý khách", "chị em", "chúng tôi"):
            if bad in all_text.lower():
                err(sku, "giọng", f"dùng '{bad}'")
        if EMOJI_RE.search(all_text):
            err(sku, "giọng", "có emoji")
        if desc.count("!") > 1:
            err(sku, "giọng", f"mo_ta có {desc.count('!')} dấu '!' (tối đa 1)")
        if any(w for w in re.findall(r"[^\W\d_]{2,}", all_text) if w.isupper() and w not in CAPS_OK):
            bad = sorted({w for w in re.findall(r"[^\W\d_]{2,}", all_text) if w.isupper() and w not in CAPS_OK})
            err(sku, "giọng", f"viết HOA nhấn mạnh: {bad}")
        for name, text in fields.items():
            if re.search(r"\s{2,}", text) or text != text.strip():
                err(sku, "định dạng", f"{name} có khoảng trắng thừa")
    return errs


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    problems = []
    raw = OUT_CSV.read_bytes()
    if not raw.startswith(b"\xef\xbb\xbf"):
        problems.append(("-", "cấu trúc", "nhap_hang_loat.csv không có BOM UTF-8"))
    with open(OUT_CSV, encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        head = reader.fieldnames
        out_rows = list(reader)
    spec_rows = read_csv(SPEC)
    banned = [l.strip() for l in BANNED.read_text(encoding="utf-8-sig").splitlines() if l.strip()]
    problems += kiem(spec_rows, out_rows, banned, head)

    # CSV khớp XLSX
    try:
        xhead, xrows = read_xlsx(OUT_XLSX)
        if xhead != HEAD:
            problems.append(("-", "xlsx", f"cột xlsx sai: {xhead}"))
        if len(xrows) != len(out_rows):
            problems.append(("-", "xlsx", f"xlsx {len(xrows)} dòng, csv {len(out_rows)} dòng"))
        for a, b in zip(out_rows, xrows):
            diff = [k for k in HEAD if (a[k] or "") != (b.get(k) or "")]
            if diff:
                problems.append((a["sku"], "xlsx", f"csv và xlsx khác nhau ở: {diff}"))
    except Exception as e:  # noqa: BLE001
        problems.append(("-", "xlsx", f"không đọc được nhap_hang_loat.xlsx: {e}"))

    ready = sum(1 for r in out_rows if r["trang_thai"] == "SAN_SANG")
    need = sum(1 for r in out_rows if r["trang_thai"] == "CAN_BO_SUNG")
    print(f"Số dòng: {len(out_rows)} | SAN_SANG: {ready} | CAN_BO_SUNG: {need}")
    for r in out_rows:
        if r["trang_thai"] == "CAN_BO_SUNG":
            print(f"  {r['sku']}: thiếu {r['truong_can_bo_sung']}")
    if problems:
        print(f"\nCÒN {len(problems)} LỖI:")
        for sku, grp, msg in problems:
            print(f"  [{grp}] {sku}: {msg}")
        return 1
    print("\nSẠCH: 0 lỗi (cấu trúc, độ dài, từ cấm, con số, trạng thái, sự thật, giọng, CSV = XLSX).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
