import pandas as pd
import csv

# Let's inspect the exact numbers for the 2 interpretations
# Let's see:
# Total Ghi co = 130,898,650
# 1. cod_gop:
# 41577584: 4,220,000
# 90908337: 3,530,000
# Total cod_gop = 7,750,000

# 2. phi_lai_ngan_hang (Ghi co):
# 61395456: 18,650

# 3. Pure khong_ro_nguon (no order, no matching customer):
# 28058043 (TRA TIEN): 1,530,000
# 32051028 (CHUYEN KHOAN): 700,000
# 62820400 (TT HD 0087): 3,200,000
# 91910299 (PHAM QUOC TOAN CK): 2,440,000
# 72253631 (MUA HANG ZALO): 560,000
# 90546478 (LE TRUNG KIEN gui tien): 980,000
# Total pure khong_ro_nguon = 9,410,000

# 4. Conflicting cases (CAN NGUOI QUYET):
# 30136693 (DANG KIM MAI CK DH2610-054): 120,000
# 35586667 (LY THI LINH CK DH2610-015): 380,000
# 81794057 (DANG QUOC SON CK DH2610-108): 410,000
# Total conflicting = 910,000

pure_unmatched = 7750000 + 18650 + 9410000 # = 17,178,650
with_conflicting = pure_unmatched + 910000  # = 18,088,650

total_co = 130898650
print("Total Ghi co:", total_co)
print("pure_unmatched (cod_gop + lai + khong_ro_nguon):", pure_unmatched)
print("with_conflicting (+ 910k):", with_conflicting)
print("Remaining if pure_unmatched:", total_co - pure_unmatched)
print("Remaining if with_conflicting:", total_co - with_conflicting)
