# Quy định chấm công của Công ty giả (dùng cho bài thực hành)

> Đây là công ty GIẢ. Mọi ngưỡng dưới đây là THAM SỐ GIẢ ĐỊNH để làm bài, không phải quy định pháp luật.
> Quy định pháp luật về giờ làm thêm, nghỉ lễ, nghỉ phép: cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự. Bài này không trích điều luật.

## 1. Kỳ chấm công
Tháng 09/2026 (từ 2026-09-01 đến 2026-09-30). Tính theo ngày dương lịch của giờ quẹt, không có ca qua đêm.

## 2. Ca làm việc
| Ca | Giờ vào | Giờ ra | Ghi chú |
|----|---------|--------|---------|
| HC (hành chính) | 08:00 | 17:00 | Làm thứ Hai đến thứ Sáu. Nghỉ trưa 12:00-13:00 không tính công. Thứ Bảy, Chủ nhật là ngày nghỉ (OFF). |
| S (ca sáng, ca xoay) | 06:00 | 14:00 | Theo `lich_ca_xoay.csv`. Không trừ giờ nghỉ. |
| C (ca chiều, ca xoay) | 14:00 | 22:00 | Theo `lich_ca_xoay.csv`. Không trừ giờ nghỉ. |

- Nhân viên loại `HC` trong `nhan_vien.csv` theo ca HC. Nhân viên loại `XOAY` theo `lich_ca_xoay.csv` (giá trị S, C hoặc OFF = ngày nghỉ).
- Ngày lễ (công ty khai báo, giả định): 2026-09-01 và 2026-09-02. Ngày lễ là ngày nghỉ (LE) với mọi nhân viên, kể cả khi lịch xoay có ghi ca.
- Mọi so sánh giờ tính theo PHÚT: bỏ phần giây của giờ quẹt (08:05:59 xem là 08:05).

## 3. Máy chấm công
Hai máy: `MAY-A1` (chi nhánh A), `MAY-B1` (chi nhánh B). Mỗi nhân viên thuộc một chi nhánh (cột Chi nhánh trong `nhan_vien.csv`). Máy B xuất giờ dạng `dd/mm/yyyy hh:mm`, máy A xuất `yyyy-mm-dd hh:mm:ss`.

## 4. Tham số (giả định)
| Tham số | Giá trị |
|---------|---------|
| Dung sai đi trễ / về sớm | 5 phút (trễ hoặc sớm ĐÚNG 5 phút vẫn tính đủ; từ 6 phút trở lên là trễ/ sớm) |
| Quẹt trùng | hai quẹt CÙNG MÁY cách nhau <= 3 phút: giữ quẹt đầu, bỏ quẹt sau, ghi nhận QUET_TRUNG |
| Nghi quẹt hộ | cùng một mã NV có hai quẹt Ở HAI MÁY KHÁC NHAU cách nhau <= 10 phút trong cùng ngày |
| Làm thêm giờ | chỉ tính khi quẹt ra muộn hơn giờ ra của ca >= 30 phút; tính bằng số phút chênh (quẹt ra - giờ ra ca) |
| Ngưỡng làm thêm trong NGÀY | > 180 phút (3 giờ) thì cảnh báo OT_VUOT_NGUONG |
| Ngưỡng làm thêm trong THÁNG | tổng phút làm thêm của ngày làm việc thường > 2400 phút (40 giờ) thì cảnh báo OT_THANG_VUOT |
| Quẹt đơn lẻ (chỉ có một quẹt trong ngày) | quẹt <= giờ vào + 120 phút: coi là quẹt vào, THIEU_RA. quẹt >= giờ ra - 120 phút: coi là quẹt ra, THIEU_VAO. Còn lại: THIEU_KHONG_RO (không đoán) |

## 5. Cách tính một ngày làm việc
(Bản rút gọn: công ty chưa viết chi tiết. Bạn tự diễn giải hợp lý từ các mục trên, và GHI RÕ từng giả định bạn dùng vào bao_cao.md.)

## 6. Trạng thái ngày
OK (đã tính giờ; kể cả có trễ, sớm, làm thêm); PHEP; NGHI (ngày nghỉ không quẹt); CHO_XAC_NHAN (cần người quyết, chưa tính giờ).
Giá trị trạng thái chỉ là một trong 4 từ trên.

## 7. Mã bất thường (loai)
THIEU_RA, THIEU_VAO, THIEU_KHONG_RO, QUET_TRUNG, DI_TRE, VE_SOM, OT_VUOT_NGUONG, OT_THANG_VUOT, VANG_CHUA_GHI, LAM_NGAY_LE, LAM_NGAY_NGHI, NGHI_QUET_HO, CO_PHEP_NHUNG_QUET, DU_LIEU_LOI.
Cột `can_nguoi_quyet` = CO với mọi mã, trừ QUET_TRUNG, DI_TRE, VE_SOM (KHONG).
