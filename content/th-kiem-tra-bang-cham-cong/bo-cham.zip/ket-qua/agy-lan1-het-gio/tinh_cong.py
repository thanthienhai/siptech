import os
import csv
from datetime import datetime, timedelta
import pandas as pd

def parse_ts(val):
    if pd.isna(val):
        return None
    val = str(val).strip()
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M'):
        try:
            return datetime.strptime(val, fmt)
        except ValueError:
            pass
    return None

def main():
    # 1. Đọc dữ liệu nhân viên
    nv_df = pd.read_csv('nhan_vien.csv')
    valid_nv_set = set(nv_df['ma_nv'])
    nv_list = list(nv_df['ma_nv'])
    nv_map = nv_df.set_index('ma_nv').to_dict('index')

    # 2. Đọc lịch ca xoay
    lc_df = pd.read_csv('lich_ca_xoay.csv')
    lc_df['ngay_parsed'] = pd.to_datetime(lc_df['ngay'], format='%d/%m/%Y').dt.strftime('%Y-%m-%d')
    lich_map = lc_df.set_index(['ma_nv', 'ngay_parsed'])['ca'].to_dict()

    # 3. Đọc đơn nghỉ phép
    np_df = pd.read_csv('nghi_phep.csv')
    leave_map = {}
    for idx, r in np_df.iterrows():
        if str(r['trang_thai']).strip() == 'Đã duyệt':
            st = datetime.strptime(str(r['tu_ngay']).strip(), '%d/%m/%Y')
            en = datetime.strptime(str(r['den_ngay']).strip(), '%d/%m/%Y')
            cur = st
            while cur <= en:
                leave_map[(r['ma_nv'], cur.strftime('%Y-%m-%d'))] = r['loai']
                cur += timedelta(days=1)

    # 4. Đọc dữ liệu quẹt thẻ chấm công
    cc_df = pd.read_csv('cham_cong.csv')

    anomalies = []
    valid_swipes = []

    for idx, r in cc_df.iterrows():
        raw_time = str(r['thoi_gian'])
        dt = parse_ts(r['thoi_gian'])
        nv = str(r['ma_nv']).strip()
        mm = str(r['ma_may']).strip()

        # Kiểm tra mã NV không có trong nhan_vien.csv
        if nv not in valid_nv_set:
            d_str = dt.strftime('%Y-%m-%d') if dt else ''
            anomalies.append({
                'ma_nv': nv,
                'ngay': d_str,
                'loai': 'DU_LIEU_LOI',
                'chi_tiet': f'mã NV {nv} không tồn tại trong nhan_vien.csv (máy {mm}, {raw_time})',
                'can_nguoi_quyet': 'CO',
                'giai_thich': f'Mã nhân viên {nv} có phát sinh quẹt thẻ nhưng không có trong danh sách nhân viên công ty; cần quản lý kiểm tra lại hồ sơ nhân sự hoặc phân quyền máy chấm công.'
            })
            continue

        # Kiểm tra thời gian trống hoặc không hợp lệ
        if dt is None:
            anomalies.append({
                'ma_nv': nv,
                'ngay': '',
                'loai': 'DU_LIEU_LOI',
                'chi_tiet': f'thời gian trống hoặc không hợp lệ ({raw_time}) tại máy {mm}',
                'can_nguoi_quyet': 'CO',
                'giai_thich': f'Bản ghi chấm công của nhân viên {nv} có mốc thời gian không hợp lệ ({raw_time}); cần quản lý kiểm tra nhật ký thô của máy chấm công {mm}.'
            })
            continue

        # Bỏ phần giây theo quy định (mục 2)
        dt_min = dt.replace(second=0, microsecond=0)
        valid_swipes.append({
            'ma_nv': nv,
            'ma_may': mm,
            'dt': dt,
            'dt_min': dt_min,
            'ngay': dt_min.strftime('%Y-%m-%d'),
            'raw_time': raw_time
        })

    # Gom quẹt thẻ theo (ma_nv, ngay)
    swipes_by_nv_date = {}
    for s in valid_swipes:
        swipes_by_nv_date.setdefault((s['ma_nv'], s['ngay']), []).append(s)

    all_dates = [f'2026-09-{d:02d}' for d in range(1, 31)]
    daily_records = []

    # Xử lý từng ngày cho từng nhân viên
    for nv in nv_list:
        loai_ca = nv_map[nv]['loai_ca']
        for d in all_dates:
            dt_obj = datetime.strptime(d, '%Y-%m-%d')

            # Xác định loai_ngay
            if d in ['2026-09-01', '2026-09-02']:
                loai_ngay = 'LE'
            elif loai_ca == 'HC':
                loai_ngay = 'OFF' if dt_obj.weekday() in (5, 6) else 'HC'
            else:
                loai_ngay = lich_map.get((nv, d), 'OFF')

            raw_swipes = swipes_by_nv_date.get((nv, d), [])
            is_leave = (nv, d) in leave_map
            loai_phep = leave_map.get((nv, d), '')

            # Trường hợp KHÔNG CÓ QUẸT NÀO
            if not raw_swipes:
                if is_leave:
                    # Nếu là ngày làm việc theo lịch mà có đơn phép -> PHEP
                    # Nếu là ngày nghỉ (OFF/LE) theo lịch -> NGHI
                    trang_thai = 'PHEP' if loai_ngay in ['HC', 'S', 'C'] else 'NGHI'
                else:
                    if loai_ngay in ['HC', 'S', 'C']:
                        trang_thai = 'CHO_XAC_NHAN'
                        anomalies.append({
                            'ma_nv': nv,
                            'ngay': d,
                            'loai': 'VANG_CHUA_GHI',
                            'chi_tiet': f'vắng không quẹt thẻ ca {loai_ngay}, không có đơn nghỉ phép',
                            'can_nguoi_quyet': 'CO',
                            'giai_thich': f'Nhân viên {nv} có lịch ca {loai_ngay} nhưng không có dữ liệu quẹt thẻ và không có đơn xin nghỉ; cần quản lý kiểm tra xác nhận lý do vắng mặt.'
                        })
                    else:
                        trang_thai = 'NGHI'

                daily_records.append({
                    'ma_nv': nv, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': '', 'gio_ra': '', 'gio_cong': '',
                    'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': trang_thai
                })
                continue

            # Trường hợp CÓ QUẸT
            sorted_swipes = sorted(raw_swipes, key=lambda x: (x['dt_min'], x['dt']))

            # 1. Bỏ quẹt trùng (QUET_TRUNG): cùng máy cách nhau <= 3 phút
            kept = []
            has_dup = False
            for s in sorted_swipes:
                if not kept:
                    kept.append(s)
                else:
                    prev = kept[-1]
                    diff = (s['dt_min'] - prev['dt_min']).total_seconds() / 60.0
                    if s['ma_may'] == prev['ma_may'] and diff <= 3:
                        has_dup = True
                    else:
                        kept.append(s)

            if has_dup:
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'QUET_TRUNG',
                    'chi_tiet': 'có quẹt trùng <= 3 phút trên cùng máy',
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f'Nhân viên {nv} có các lần quẹt thẻ liên tiếp trên cùng một máy cách nhau <= 3 phút; hệ thống đã tự động giữ quẹt đầu và loại bỏ quẹt sau theo quy định.'
                })

            # 2. Kiểm tra nghi quẹt hộ (NGHI_QUET_HO): hai máy khác nhau cách nhau <= 10 phút
            has_nghi_quet_ho = False
            nghi_detail = ''
            for i in range(len(raw_swipes)):
                for j in range(i + 1, len(raw_swipes)):
                    s1, s2 = raw_swipes[i], raw_swipes[j]
                    if s1['ma_may'] != s2['ma_may']:
                        diff_m = abs((s2['dt_min'] - s1['dt_min']).total_seconds()) / 60.0
                        if diff_m <= 10:
                            has_nghi_quet_ho = True
                            m1, t1_s = s1['ma_may'], s1['dt_min'].strftime('%H:%M')
                            m2, t2_s = s2['ma_may'], s2['dt_min'].strftime('%H:%M')
                            nghi_detail = f'quẹt {m1} lúc {t1_s} và {m2} lúc {t2_s} cách nhau {int(diff_m)} phút'
                            break
                if has_nghi_quet_ho:
                    break

            if has_nghi_quet_ho:
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'NGHI_QUET_HO',
                    'chi_tiet': nghi_detail,
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f'Nhân viên {nv} có lượt quẹt thẻ tại 2 máy chi nhánh khác nhau cách nhau <= 10 phút, xuất hiện dấu hiệu bất thường về vị trí; đề nghị người có thẩm quyền xác minh thực tế, không tự ý tính giờ.'
                })
                daily_records.append({
                    'ma_nv': nv, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': '', 'gio_ra': '', 'gio_cong': '',
                    'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': 'CHO_XAC_NHAN'
                })
                continue

            # 3. Quẹt vào ngày lễ (LAM_NGAY_LE) hoặc ngày nghỉ (LAM_NGAY_NGHI)
            if loai_ngay == 'LE':
                v_str = kept[0]['dt_min'].strftime('%H:%M')
                r_str = kept[-1]['dt_min'].strftime('%H:%M') if len(kept) > 1 else ''
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'LAM_NGAY_LE',
                    'chi_tiet': f'quẹt lúc {v_str}' + (f', {r_str}' if r_str else '') + ' vào ngày lễ',
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f'Nhân viên {nv} phát sinh quẹt thẻ vào ngày nghỉ lễ; cần quản lý xác nhận phân công làm việc và kiểm với văn bản hiện hành hoặc chuyên gia nhân sự để tính công.'
                })
                daily_records.append({
                    'ma_nv': nv, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': v_str, 'gio_ra': r_str, 'gio_cong': '',
                    'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': 'CHO_XAC_NHAN'
                })
                continue

            if loai_ngay == 'OFF':
                v_str = kept[0]['dt_min'].strftime('%H:%M')
                r_str = kept[-1]['dt_min'].strftime('%H:%M') if len(kept) > 1 else ''
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'LAM_NGAY_NGHI',
                    'chi_tiet': f'quẹt lúc {v_str}' + (f', {r_str}' if r_str else '') + ' vào ngày nghỉ',
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f'Nhân viên {nv} phát sinh quẹt thẻ vào ngày nghỉ theo lịch; cần quản lý xác nhận phân công làm việc và kiểm với văn bản hiện hành hoặc chuyên gia nhân sự để tính công.'
                })
                daily_records.append({
                    'ma_nv': nv, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': v_str, 'gio_ra': r_str, 'gio_cong': '',
                    'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': 'CHO_XAC_NHAN'
                })
                continue

            # 4. Có đơn nghỉ phép mà vẫn có quẹt (CO_PHEP_NHUNG_QUET)
            if is_leave:
                v_str = kept[0]['dt_min'].strftime('%H:%M')
                r_str = kept[-1]['dt_min'].strftime('%H:%M') if len(kept) > 1 else ''
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'CO_PHEP_NHUNG_QUET',
                    'chi_tiet': f'có đơn {loai_phep} nhưng vẫn quẹt ' + (f'vào {v_str}, ra {r_str}' if r_str else f'lúc {v_str}'),
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f'Nhân viên {nv} đã có đơn xin nghỉ phép được duyệt nhưng vẫn quẹt thẻ; cần quản lý xác nhận nhân viên có đi làm thực tế hay hủy phép, không tự tính giờ.'
                })
                daily_records.append({
                    'ma_nv': nv, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': v_str, 'gio_ra': r_str, 'gio_cong': '',
                    'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': 'CHO_XAC_NHAN'
                })
                continue

            # 5. Ca làm việc bình thường: Xác định giờ vào/ra ca
            shift_start = datetime.strptime(d + (' 08:00' if loai_ngay == 'HC' else (' 06:00' if loai_ngay == 'S' else ' 14:00')), '%Y-%m-%d %H:%M')
            shift_end = datetime.strptime(d + (' 17:00' if loai_ngay == 'HC' else (' 14:00' if loai_ngay == 'S' else ' 22:00')), '%Y-%m-%d %H:%M')

            # Trường hợp chỉ có 1 quẹt trong ngày
            if len(kept) == 1:
                st = kept[0]['dt_min']
                st_str = st.strftime('%H:%M')
                if st <= shift_start + timedelta(minutes=120):
                    loai_a = 'THIEU_RA'
                    ct = f'vào lúc {st_str}, thiếu quẹt ra'
                    gt = f'Nhân viên {nv} có quẹt vào ca lúc {st_str} nhưng thiếu quẹt ra; cần quản lý xác nhận thời gian ra ca thực tế.'
                    gv, gr = st_str, ''
                elif st >= shift_end - timedelta(minutes=120):
                    loai_a = 'THIEU_VAO'
                    ct = f'ra lúc {st_str}, thiếu quẹt vào'
                    gt = f'Nhân viên {nv} có quẹt ra ca lúc {st_str} nhưng thiếu quẹt vào; cần quản lý xác nhận thời gian vào ca thực tế.'
                    gv, gr = '', st_str
                else:
                    loai_a = 'THIEU_KHONG_RO'
                    ct = f'quẹt lúc {st_str} (giữa ca), không rõ vào hay ra'
                    gt = f'Nhân viên {nv} chỉ có một lần quẹt thẻ lúc {st_str} giữa ca; cần quản lý kiểm tra xác minh thời gian làm việc thực tế.'
                    gv, gr = '', ''

                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': loai_a,
                    'chi_tiet': ct,
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': gt
                })
                daily_records.append({
                    'ma_nv': nv, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': gv, 'gio_ra': gr, 'gio_cong': '',
                    'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': 'CHO_XAC_NHAN'
                })
                continue

            # 6. Có từ 2 quẹt trở lên trên ngày làm việc thường
            in_time = kept[0]['dt_min']
            out_time = kept[-1]['dt_min']
            gv = in_time.strftime('%H:%M')
            gr = out_time.strftime('%H:%M')

            diff_tre = int((in_time - shift_start).total_seconds() / 60.0)
            diff_som = int((shift_end - out_time).total_seconds() / 60.0)

            phut_tre = diff_tre if diff_tre > 5 else 0
            phut_som = diff_som if diff_som > 5 else 0

            if phut_tre > 0:
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'DI_TRE',
                    'chi_tiet': f'vào {gv}, trễ {phut_tre} phút',
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f'Nhân viên {nv} quẹt vào lúc {gv}, muộn hơn giờ bắt đầu ca ({shift_start.strftime("%H:%M")}) vượt quá dung sai 5 phút; ghi nhận trễ {phut_tre} phút.'
                })

            if phut_som > 0:
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'VE_SOM',
                    'chi_tiet': f'ra {gr}, về sớm {phut_som} phút',
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f'Nhân viên {nv} quẹt ra lúc {gr}, sớm hơn giờ kết thúc ca ({shift_end.strftime("%H:%M")}) vượt quá dung sai 5 phút; ghi nhận về sớm {phut_som} phút.'
                })

            # Tính làm thêm giờ: chỉ tính khi ra muộn >= 30 phút
            diff_ot = int((out_time - shift_end).total_seconds() / 60.0)
            ot_phut = diff_ot if diff_ot >= 30 else 0
            if ot_phut > 180:
                anomalies.append({
                    'ma_nv': nv,
                    'ngay': d,
                    'loai': 'OT_VUOT_NGUONG',
                    'chi_tiet': f'làm thêm {ot_phut} phút ({ot_phut/60:.2f} giờ), vượt ngưỡng 180 phút/ngày',
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f'Nhân viên {nv} có thời gian làm thêm trong ngày vượt ngưỡng 180 phút; cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự và người có thẩm quyền phê duyệt.'
                })

            # Tính gio_cong
            t1 = shift_start if in_time <= shift_start + timedelta(minutes=5) else in_time
            t2 = shift_end if out_time >= shift_end - timedelta(minutes=5) else min(out_time, shift_end)
            if t1 < t2:
                tot_m = (t2 - t1).total_seconds() / 60.0
                if loai_ngay == 'HC':
                    l_st = datetime.strptime(d + ' 12:00', '%Y-%m-%d %H:%M')
                    l_en = datetime.strptime(d + ' 13:00', '%Y-%m-%d %H:%M')
                    i_st = max(t1, l_st)
                    i_en = min(t2, l_en)
                    if i_st < i_en:
                        tot_m -= (i_en - i_st).total_seconds() / 60.0
                gc = round(tot_m / 60.0, 2)
            else:
                gc = 0.00

            daily_records.append({
                'ma_nv': nv, 'ngay': d, 'loai_ngay': loai_ngay,
                'gio_vao': gv, 'gio_ra': gr, 'gio_cong': f'{gc:.2f}',
                'phut_tre': phut_tre, 'phut_ve_som': phut_som, 'ot_phut': ot_phut,
                'trang_thai': 'OK'
            })

    # Kiểm tra OT_THANG_VUOT (> 2400 phút của các ngày làm việc thường)
    daily_df = pd.DataFrame(daily_records)
    for nv in nv_list:
        nv_ok = daily_df[(daily_df['ma_nv'] == nv) & (daily_df['trang_thai'] == 'OK')]
        tot_ot = pd.to_numeric(nv_ok['ot_phut'], errors='coerce').sum()
        if tot_ot > 2400:
            anomalies.append({
                'ma_nv': nv,
                'ngay': 'THANG',
                'loai': 'OT_THANG_VUOT',
                'chi_tiet': f'tổng làm thêm trong tháng {int(tot_ot)} phút ({tot_ot/60:.2f} giờ), vượt ngưỡng 2400 phút/tháng',
                'can_nguoi_quyet': 'CO',
                'giai_thich': f'Tổng thời gian làm thêm trong tháng của nhân viên {nv} đạt {int(tot_ot)} phút ({tot_ot/60:.2f} giờ), vượt ngưỡng 2400 phút; cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự để rà soát giới hạn.'
            })

    # Tạo DataFrame cho bất thường
    anom_df = pd.DataFrame(anomalies)

    # 3. Tạo bảng tổng hợp theo người (tong_hop_nguoi.csv)
    summary_records = []
    for nv in nv_list:
        nv_daily = daily_df[daily_df['ma_nv'] == nv]
        nv_ok = nv_daily[nv_daily['trang_thai'] == 'OK']

        ngay_cong = len(nv_ok)
        tong_gio_cong = round(pd.to_numeric(nv_ok['gio_cong'], errors='coerce').sum(), 2)

        tre_days = nv_ok[pd.to_numeric(nv_ok['phut_tre'], errors='coerce') > 0]
        so_lan_tre = len(tre_days)
        tong_phut_tre = int(pd.to_numeric(nv_ok['phut_tre'], errors='coerce').sum())

        som_days = nv_ok[pd.to_numeric(nv_ok['phut_ve_som'], errors='coerce') > 0]
        so_lan_ve_som = len(som_days)
        tong_phut_ve_som = int(pd.to_numeric(nv_ok['phut_ve_som'], errors='coerce').sum())

        tot_ot_min = pd.to_numeric(nv_ok['ot_phut'], errors='coerce').sum()
        tong_ot_gio = round(tot_ot_min / 60.0, 2)

        so_ngay_phep = len(nv_daily[nv_daily['trang_thai'] == 'PHEP'])
        so_ngay_cho_xac_nhan = len(nv_daily[nv_daily['trang_thai'] == 'CHO_XAC_NHAN'])

        # so_ngay_vang_chua_ghi
        nv_anom = anom_df[anom_df['ma_nv'] == nv]
        so_ngay_vang = len(nv_anom[nv_anom['loai'] == 'VANG_CHUA_GHI'])
        so_bat_thuong = len(nv_anom)

        summary_records.append({
            'ma_nv': nv,
            'ngay_cong': ngay_cong,
            'tong_gio_cong': f'{tong_gio_cong:.2f}',
            'so_lan_tre': so_lan_tre,
            'tong_phut_tre': tong_phut_tre,
            'so_lan_ve_som': so_lan_ve_som,
            'tong_phut_ve_som': tong_phut_ve_som,
            'tong_ot_gio': f'{tong_ot_gio:.2f}',
            'so_ngay_phep': so_ngay_phep,
            'so_ngay_vang_chua_ghi': so_ngay_vang,
            'so_ngay_cho_xac_nhan': so_ngay_cho_xac_nhan,
            'so_bat_thuong': so_bat_thuong
        })

    summary_df = pd.DataFrame(summary_records)

    # Ghi ra 3 tệp CSV (UTF-8, đúng tên cột)
    daily_cols = ['ma_nv', 'ngay', 'loai_ngay', 'gio_vao', 'gio_ra', 'gio_cong', 'phut_tre', 'phut_ve_som', 'ot_phut', 'trang_thai']
    daily_df[daily_cols].to_csv('bang_cong_ngay.csv', index=False, encoding='utf-8')

    anom_cols = ['ma_nv', 'ngay', 'loai', 'chi_tiet', 'can_nguoi_quyet', 'giai_thich']
    # Sắp xếp bất thường cho khoa học: ngày, mã NV, loại
    anom_df = anom_df.sort_values(by=['ma_nv', 'ngay', 'loai']).reset_index(drop=True)
    anom_df[anom_cols].to_csv('bat_thuong.csv', index=False, encoding='utf-8')

    summary_cols = ['ma_nv', 'ngay_cong', 'tong_gio_cong', 'so_lan_tre', 'tong_phut_tre', 'so_lan_ve_som', 'tong_phut_ve_som', 'tong_ot_gio', 'so_ngay_phep', 'so_ngay_vang_chua_ghi', 'so_ngay_cho_xac_nhan', 'so_bat_thuong']
    summary_df[summary_cols].to_csv('tong_hop_nguoi.csv', index=False, encoding='utf-8')

    # Đếm số dòng thực tế mỗi tệp (kể cả dòng tiêu đề)
    with open('bang_cong_ngay.csv', encoding='utf-8') as f:
        lines_daily = sum(1 for _ in f)
    with open('bat_thuong.csv', encoding='utf-8') as f:
        lines_anom = sum(1 for _ in f)
    with open('tong_hop_nguoi.csv', encoding='utf-8') as f:
        lines_summary = sum(1 for _ in f)

    print("=== TỔNG HỢP KẾT QUẢ XỬ LÝ CHẤM CÔNG ===")
    print(f"1. bang_cong_ngay.csv: {lines_daily} dòng (tiêu đề + {lines_daily - 1} dòng dữ liệu)")
    print(f"2. bat_thuong.csv:     {lines_anom} dòng (tiêu đề + {lines_anom - 1} dòng dữ liệu)")
    print(f"3. tong_hop_nguoi.csv: {lines_summary} dòng (tiêu đề + {lines_summary - 1} dòng dữ liệu)")
    print("\n=== THỐNG KÊ BẤT THƯỜNG THEO TỪNG LOẠI ===")
    anom_counts = anom_df['loai'].value_counts()
    for k, v in anom_counts.items():
        print(f"- {k:<20}: {v:>2} trường hợp")
    print(f"TỔNG CỘNG BẤT THƯỜNG  : {len(anom_df)} trường hợp")

if __name__ == '__main__':
    main()
