"""Dựng các ảnh PNG của bài 08 từ log thật / file kết quả thật (không bịa dòng nào).
Chạy:  python -X utf8 dung_anh_log_va_bang.py   (từ thư mục ket-qua; nguồn là logs/*.json đã che)
Ảnh terminal = dựng lại từ log (transcript logs/*.json đã che đường dẫn máy và tên tổ chức; term.scrub_text che thêm khi dựng), không phải ảnh chụp TUI.
"""
import sys, json, csv, html, os, re
from pathlib import Path

# Đường dẫn tương đối: bài nằm ở <...>/MM/AI-Real/thuc-hanh-coding-agent/08-.../ket-qua; term.py nằm ở <...>/siptech-video/agentlab
BAI = Path(__file__).resolve().parents[1]
AGENTLAB = Path(os.environ.get("AGENTLAB") or (Path(__file__).resolve().parents[5] / "siptech-video" / "agentlab"))
sys.path.insert(0, str(AGENTLAB))
from term import render_blocks, shot_html, scrub_text, CSS as TCSS

ANH = BAI / "anh"; LOGS = BAI / "logs"; KQ = BAI / "ket-qua"


def S(x):
    """Che mọi chuỗi lấy từ log/đường dẫn trước khi đưa vào HTML (term.scrub_text + che nốt thư mục OneDrive nếu còn)."""
    if not isinstance(x, str): return x
    x = scrub_text(x)
    x = re.sub(r"OneDrive[^\\/\"\r\n]*[\\/]", "", x)   # bỏ cả thư mục OneDrive (kể cả phần tên tổ chức nếu còn)
    x = re.sub(r"(?:<HOME>|~)[\\/]+\.claude[\\/]+projects[\\/]+[^\\/\s]*", "~/.claude/projects/<thư-mục-dự-án>", x)
    return scrub_text(x)


def S_deep(v):
    if isinstance(v, str): return S(v)
    if isinstance(v, list): return [S_deep(x) for x in v]
    if isinstance(v, dict): return {k: S_deep(x) for k, x in v.items()}
    return v


def S_blocks(blocks):
    out = []
    for b in blocks:
        nb = dict(b)
        for k in ("text", "output"):
            if k in nb: nb[k] = S(nb[k])
        if isinstance(nb.get("input"), (dict, list)):
            nb["input"] = S_deep(nb["input"])
        out.append(nb)
    return out


TBL = """body{margin:0;background:#fff;font-family:'Segoe UI',Calibri,sans-serif}.w{padding:16px 18px;width:1180px}
h3{margin:0 0 8px;font-size:17px;color:#111827}table{border-collapse:collapse;font-size:13.5px;width:100%}
th{background:#1e3a8a;color:#fff;padding:6px 8px;text-align:left}td{border-bottom:1px solid #e5e7eb;padding:5px 8px;vertical-align:top}
td.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.ok{color:#047857;font-weight:600}.bad{color:#b91c1c;font-weight:600}.warn{color:#b45309;font-weight:600}
.note{font-size:12px;color:#6b7280;margin-top:8px}tr:nth-child(even) td{background:#f9fafb}"""


def tbl(title, head, rows, note, numcols=(), width=1180):
    title = S(title); note = S(note); head = [S(x) for x in head]
    h = "".join(f"<th>{html.escape(x)}</th>" for x in head)
    body = ""
    for r in rows:
        tds = ""
        for i, c in enumerate(r):
            cls = "n" if i in numcols else ""
            txt = S(str(c)); cl2 = ""
            if txt.startswith("✔"): cl2 = "ok"
            elif txt.startswith("✘"): cl2 = "bad"
            elif txt.startswith("△"): cl2 = "warn"
            tds += f'<td class="{(cls + " " + cl2).strip()}">{html.escape(txt)}</td>'
        body += f"<tr>{tds}</tr>"
    return (f'<!doctype html><meta charset="utf-8"><style>{TBL}</style><div class="w" style="width:{width}px"><h3>{html.escape(title)}</h3>'
            f'<table><tr>{h}</tr>{body}</table><div class="note">{html.escape(note)}</div></div>')


def load(name):
    t = json.loads((LOGS / f"{name}.json").read_text(encoding="utf-8"))
    t["blocks"] = S_blocks(t["blocks"]); t["prompt"] = S(t["prompt"])
    return t


def terminal(name, out, title, blocks=None, maxlines=8, prompt=False, width=1280):
    t = load(name); bl = t["blocks"]
    if blocks: bl = bl[blocks[0]:blocks[1]]
    h = render_blocks(bl, S(title), t["prompt"], maxlines, width, prompt)
    shot_html(h, ANH / out, width + 40, ".win")


def fmt(n):
    return f"{int(round(n)):,}".replace(",", ".")


def main():
    # 01 prompt đầy đủ
    pr = (BAI / "du-lieu" / "prompt-gop.txt").read_text(encoding="utf-8")
    h = (f'<!doctype html><meta charset="utf-8"><style>{TCSS}</style><div style="padding:18px;width:1240px"><div class="win"><div class="bar"><span class="dot r"></span><span class="dot y"></span><span class="dot g"></span>'
         f'<span class="t">du-lieu/prompt-gop.txt (prompt giao việc, khung 6 phần)</span></div><div class="body" style="font-size:13.5px;line-height:1.42"><div class="u">{html.escape(S(pr))}</div></div></div></div>')
    shot_html(h, ANH / "01-prompt-giao-viec.png", 1280, ".win")

    # 08-11: terminal claude / agy (bài 1-2)
    tc = load("t10-claude"); ta = load("t10-agy")
    terminal("t10-claude", "08-claude-dang-lam.png", "claude · gộp báo cáo 6 chi nhánh · các bước đầu", (0, 10), 4)
    terminal("t10-claude", "09-claude-ket-qua-cuoi.png", "claude · lời báo cáo cuối của agent", (len(tc["blocks"]) - 1, len(tc["blocks"])), 40)
    terminal("t10-agy", "10-agy-dang-lam.png", "agy (Antigravity) · viết gop.py, chạy, tự kiểm", (31, 39), 6)
    terminal("t10-agy", "11-agy-ket-qua-cuoi.png", "agy (Antigravity) · lời báo cáo cuối của agent (đầu)", (len(ta["blocks"]) - 1, len(ta["blocks"])), 28)

    # 12 bảng chấm bài 1-2
    rep = json.loads((KQ / "bao-cao-cham.json").read_text(encoding="utf-8"))
    rows = []
    for ag in ("claude", "agy"):
        c = rep["bai1_2"][ag]["cham"]
        rows.append([ag, f"{c['tim_thay']}/{c['dong_dung_ky_vong']}", f"{c['dong_dung_het_cac_truong']}/{c['dong_dung_ky_vong']}", len(c["bo_sot"]), len(c["dong_thua_khong_co_trong_dap_an"]),
                     c["dong_trung_khoa_con_lai"], f"{c['tong_chi_nhanh_dung']}/6", f"{c['tong_san_pham_dung']}/9", f"{c['o_chi_nhanh_san_pham_dung']}/{c['o_chi_nhanh_san_pham_ky_vong']}",
                     "✔ " + str(sum(1 for x in c["dong_ngay_mo_ho"] if x["ket_qua"].startswith("DUNG_CAN_NGUOI_QUYET"))) + "/3",
                     "✔ nguyên vẹn" if c["file_goc"]["nguyen_ven"] else "✘ bị sửa", f"{rep['bai1_2'][ag]['giay']:.0f} s"])
    shot_html(tbl("Chấm bằng đáp án: tháng 10/2026, 6 file, 901 dòng đúng + 3 dòng ngày mơ hồ",
                  ["Agent", "Tìm thấy", "Đúng cả 5 trường", "Bỏ sót", "Dòng thừa", "Còn trùng khóa", "Tổng CN đúng", "Tổng SP đúng", "Ô CN×SP đúng", "Ngày mơ hồ → CẦN NGƯỜI QUYẾT", "File gốc", "Thời gian"],
                  rows, "[Đo được] 2026-11-20, mỗi agent 1 lần chạy hợp lệ (n=1), dữ liệu giả. 'Đúng cả 5 trường' = ngày, mã SP, SL, đơn giá, doanh thu khớp đáp án. Nguồn: ket-qua/bao-cao-cham.json (cham.py)."),
              ANH / "12-bang-cham-bai-1-2.png", 1240, ".w")

    # 13 tổng hợp theo chi nhánh + kiểm tra (đầu ra của claude, đã được chấm đúng)
    ra = KQ / "claude-bai1-2" / "ra"
    kt = list(csv.DictReader(open(ra / "kiem_tra.csv", encoding="utf-8-sig")))
    rows = [[r["chi_nhanh"], fmt(float(r["tong_file_ghi"])), fmt(float(r["tong_dong_doc_duoc"])), fmt(float(r["tong_hop_nhat"])), fmt(float(r["chenh_lech"])), r["giai_thich"][:150] + ("…" if len(r["giai_thich"]) > 150 else "")] for r in kt]
    shot_html(tbl("ra/kiem_tra.csv (do claude/gop.py tạo): tổng từng file so với bản hợp nhất",
                  ["CN", "Tổng file ghi", "Tổng dòng đọc được", "Tổng hợp nhất", "Chênh lệch", "Giải thích (cắt bớt)"], rows,
                  "Dựng lại từ file CSV thật trong lần chạy t10-claude. Dữ liệu giả để học. Đơn vị: đồng.", numcols=(1, 2, 3, 4)), ANH / "13-kiem-tra-claude.png", 1240, ".w")
    th = list(csv.DictReader(open(ra / "tong_hop_chi_nhanh.csv", encoding="utf-8-sig")))
    sp = list(csv.DictReader(open(ra / "tong_hop_san_pham.csv", encoding="utf-8-sig")))
    html2 = (f'<!doctype html><meta charset="utf-8"><style>{TBL}.c{{display:flex;gap:22px}}.c>div{{flex:1}}</style><div class="w"><h3>Báo cáo tổng hợp tháng 10/2026 (claude/gop.py): theo chi nhánh và theo sản phẩm</h3><div class="c"><div><table><tr><th>CN</th><th>Số dòng</th><th>Doanh thu (đ)</th></tr>'
             + "".join(f'<tr><td>{r["chi_nhanh"]}</td><td class="n">{r["so_dong"]}</td><td class="n">{fmt(float(r["doanh_thu"]))}</td></tr>' for r in th)
             + f'<tr><td><b>Tổng</b></td><td class="n"><b>{sum(int(r["so_dong"]) for r in th)}</b></td><td class="n"><b>{fmt(sum(float(r["doanh_thu"]) for r in th))}</b></td></tr></table></div><div><table><tr><th>Mã</th><th>Sản phẩm</th><th>SL</th><th>Doanh thu (đ)</th></tr>'
             + "".join(f'<tr><td>{r["ma_san_pham"]}</td><td>{html.escape(r["ten_san_pham"])}</td><td class="n">{fmt(float(r["so_luong"]))}</td><td class="n">{fmt(float(r["doanh_thu"]))}</td></tr>' for r in sp)
             + '</table></div></div><div class="note">Dựng lại từ ra/tong_hop_chi_nhanh.csv và ra/tong_hop_san_pham.csv thật (lần chạy t10-claude). Dữ liệu giả để học. Dòng CHUA_XAC_DINH là 2 dòng "Combo quà Tết 2026" không có trong danh mục.</div></div>')
    shot_html(S(html2), ANH / "14-tong-hop-chi-nhanh-san-pham.png", 1240, ".w")

    # 15 việc cần hỏi (claude)
    vc = list(csv.DictReader(open(ra / "viec_can_hoi.csv", encoding="utf-8-sig")))
    pick = []
    seen = set()
    for r in vc:
        k = r["loai"]
        if k not in seen or (k == "NGAY_MO_HO" and sum(1 for x in pick if x[1] == k) < 2):
            seen.add(k); pick.append([r["chi_nhanh"], r["loai"], r["mo_ta"][:120] + ("…" if len(r["mo_ta"]) > 120 else ""), r["so_chung_tu"], r["so_tien_lien_quan"], r["cau_hoi_gui_chi_nhanh"][:150] + ("…" if len(r["cau_hoi_gui_chi_nhanh"]) > 150 else "")])
    shot_html(tbl(f"ra/viec_can_hoi.csv (claude): {len(vc)} mục, mỗi loại lấy 1-2 dòng làm ví dụ",
                  ["CN", "Loại", "Mô tả (cắt bớt)", "Chứng từ", "Tiền liên quan", "Câu hỏi gửi chi nhánh (cắt bớt)"], pick,
                  "Dựng lại từ file CSV thật trong lần chạy t10-claude. Dữ liệu giả để học.", numcols=(4,)), ANH / "15-viec-can-hoi-claude.png", 1240, ".w")

    # 16 so sánh: hai agent bài 1-2 (ca khó): cách xử lý các bẫy
    # ---- bài 3 ----
    b3 = rep["bai3"]
    def sumcell(v):
        if v["returncode"] != 0:
            err = [l for l in v["stderr_tail"].strip().splitlines() if l.strip()][-1][:150]
            return "✘ dừng, mã thoát %d: %s" % (v["returncode"], err)
        c = v["cham"]
        return "✔ %d/%d dòng đúng, tổng CN đúng %d/6, tổng %s" % (c["dong_dung_het_cac_truong"], c["dong_dung_ky_vong"], c["tong_chi_nhanh_dung"], fmt(c["tong_cong_agent"]))
    rows = []
    for ag in ("claude", "agy"):
        g = b3[ag]["gop_cu_thang_moi"]
        st = g["T11"].get("so_chung_tu_thang_khac_con_sot", {})
        n_old = sum(len(v) for k, v in st.items() if k != "viec_can_hoi.csv")
        rows.append([ag, "T11, 6 file cùng định dạng", sumcell(g["T11"]), ("✔ không sót mã tháng 10" if n_old == 0 else "✘ %d lần mã chứng từ/số của THÁNG 10 còn nằm trong kiem_tra.csv + bao_cao.md" % n_old)])
        rows.append([ag, "T11, NT đổi định dạng", sumcell(g["T11_doi_dinh_dang"]), "—"])
    shot_html(tbl("Bài 3: chạy lại gop.py của bài 1-2 cho tháng 11 (không gọi agent)",
                  ["Agent", "Tình huống", "Kết quả chấm", "Văn bản giải thích/ báo cáo"], rows,
                  "[Đo được] 2026-11-20. Dữ liệu tháng 11 giả, sinh bằng cùng chương trình (seed khác). Nguồn: ket-qua/bao-cao-cham.json (chay_lai.py).", width=1240), ANH / "16-bai3-chay-lai-gop-cu.png", 1280, ".w")

    def gt(ag, hid):
        d = KQ / f"chay-lai-T11-{ag}" / "kiem_tra.csv"
        r = [x for x in csv.DictReader(open(d, encoding="utf-8-sig")) if x["chi_nhanh"] == hid][0]
        return r
    rows = []
    for ag in ("claude", "agy"):
        r = gt(ag, "HP")
        rows.append([ag, fmt(float(r["chenh_lech"])), r["giai_thich"][:420] + ("…" if len(r["giai_thich"]) > 420 else "")])
    shot_html(tbl("kiem_tra.csv, dòng HP của THÁNG 11: cột chenh_lech do code tính, cột giải thích là gì?",
                  ["Agent", "chenh_lech (tháng 11)", "giai_thich (cắt ở 420 ký tự)"], rows,
                  "Dựng lại từ ra/kiem_tra.csv thật khi chạy lại gop.py cho tháng 11. Mã HDxxxxx trong dòng agy là của tháng 10 (xem 12-... ket-qua/dap-an-T10.json).", numcols=(1,), width=1240), ANH / "17-bai3-giai-thich-so-cu.png", 1280, ".w")
    tp = load("p-claude")
    terminal("p-claude", "18-bai3-claude-sua-dinh-dang-moi.png", "claude · sửa gop.py cho file NT mới (các bước đầu)", (0, 12), 5)
    terminal("p-claude", "19-bai3-claude-ket-qua-sua.png", "claude · lời báo cáo cuối sau khi sửa", (len(tp["blocks"]) - 1, len(tp["blocks"])), 40)
    rows = []
    for ag in ("claude", "agy"):
        s2 = b3[ag]["agent_sua"]
        m = s2["meta"]
        for tag, nm in (("T11_doi_dinh_dang", "T11, NT định dạng MỚI"), ("T11_cu", "T11, NT định dạng cũ"), ("T10_cu", "T10 (tháng trước)")):
            v = s2["chay_lai_gop_da_sua"][tag]
            rows.append([ag, nm, sumcell(v), f'{m["giay"]:.0f} s'])
    shot_html(tbl("Bài 3: gop.py SAU KHI agent sửa, chạy lại trên 3 bộ dữ liệu",
                  ["Agent (bản đã sửa)", "Dữ liệu", "Kết quả chấm", "Thời gian agent sửa"], rows,
                  "[Đo được] 2026-11-20, n=1 lần sửa mỗi agent. Chạy bằng chay_lai.py (không gọi agent). Nguồn: ket-qua/bao-cao-cham.json.", width=1240), ANH / "20-bai3-hoi-quy-sau-sua.png", 1280, ".w")
    print("ảnh xong")


if __name__ == "__main__":
    main()
