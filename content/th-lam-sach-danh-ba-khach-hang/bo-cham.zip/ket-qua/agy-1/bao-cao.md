# BÁO CÁO LÀM SẠCH VÀ HỢP NHẤT DANH BẠ KHÁCH HÀNG

## 1. Số liệu tổng quan trước và sau xử lý

| Chỉ số | Dữ liệu gốc (`danh-ba-goc.xlsx`) | Dữ liệu sạch (`danh-ba-sach.xlsx`) | Thay đổi / Ghi chú |
| :--- | :--- | :--- | :--- |
| **Tổng số dòng / khách hàng** | 400 dòng | 342 khách hàng (`KH001` - `KH342`) | Giảm 58 dòng do hợp nhất trùng lặp |
| **Số dòng giữ riêng (không gộp)** | - | 290 dòng đơn (84.8%) | Khách hàng đơn lẻ, không trùng |
| **Số dòng được gộp** | - | 110 dòng gốc gom vào 52 nhóm | Tỷ lệ gộp thành công đạt 100% |
| **Số ô trống Họ tên** | 0 ô | 0 ô | 100% có họ tên chuẩn hóa |
| **Số ô trống SĐT** | 24 ô | 7 khách hàng khuyết SĐT | Trích xuất thành công 11 SĐT bị lạc cột |
| **Số ô trống Email** | 217 ô | 216 khách hàng khuyết Email | Đã chuyển 2 email lạc cột, loại 31 email lỗi |
| **Số ô trống Địa chỉ** | 122 ô | 99 khách hàng khuyết Địa chỉ | Đã đổi 3 địa chỉ bị nhập ngược sang cột Tên |
| **Số ô trống Ghi chú** | 218 ô | 280 khách hàng có ghi chú | Bổ sung 30 danh xưng vào ghi chú |

---

## 2. Kết quả hợp nhất dữ liệu (Gộp tự động)

Quy trình gộp tuân thủ nghiêm ngặt các quy tắc cố định, không suy đoán:
* **Tổng số nhóm đã gộp:** 52 nhóm khách hàng (tương ứng 110 dòng gốc gộp thành 52 dòng sạch, giảm 58 dòng).
  * **46 nhóm 2 dòng:** Gộp 92 dòng thành 46 khách hàng.
  * **6 nhóm 3 dòng:** Gộp 18 dòng thành 6 khách hàng.
* **Chi tiết theo quy tắc gộp (ghi nhận tại `nhat-ky-gop.csv`):**
  * **Quy tắc G1 (Trùng SĐT hợp lệ + Tên tương thích):** 40 lượt gộp trực tiếp.
  * **Quy tắc G2 (Trùng Email hợp lệ + Tên tương thích):** 15 lượt gộp trực tiếp.
  * **Quy tắc Gộp bắc cầu:** 3 lượt gộp (A khớp B qua SĐT/Email và B khớp C qua SĐT/Email, suy ra A, B, C là một khách hàng: `KH009`, `KH122`, `KH282`).
  * **Quy tắc không gộp (`GIU_RIENG`):** 342 dòng đại diện / dòng đơn.

---

## 3. Các ca nghi trùng chuyển người quyết định (`nghi-trung-can-quyet.csv`)

Tổng cộng có **25 ca nghi ngờ** được giữ riêng biệt và đưa vào danh sách chờ nhân sự phụ trách quyết định:
* **13 ca nhóm Q1 (Trùng SĐT nhưng tên không tương thích):**
  * **5 ca do một bên mang tên 1 từ:** `c Linh` vs `Huynh Thanh Linh`, `Cô Trang` vs `Lê Thanh Trang`, `anh Phát` vs `Ngo Anh Phat`, `Anh Lộc` vs `Hoang Xuan Loc`, `Cô Giang` vs `Tran Kim Giang`. *Gợi ý:* Nghiêng về gộp sau khi gọi điện xác thực danh xưng.
  * **8 ca do họ tên khác hẳn nhau:** Ví dụ `Vo Cong Phat` vs `Võ Đức Phong`, `Vu My Mai` vs `Nguyễn Anh Bình`... *Gợi ý:* Không gộp vì có thể là người thân trong nhà dùng chung SĐT hoặc SIM rác đã đổi chủ.
* **12 ca nhóm Q2 (Trùng Họ tên + cùng Địa chỉ nhưng khác SĐT hoặc thiếu SĐT/Email):**
  * **4 ca một bên khuyết SĐT:** Ví dụ `Nguyễn Mỹ Thảo` (R157 vs R240), `Vũ Ngọc Dung` (R212 vs R383), `Huỳnh Hoài Giang` (R259 vs R344), `Ngô Đức Toàn` (R261 vs R349). *Gợi ý:* Nghiêng về gộp vì trùng khớp cả họ tên và địa chỉ cụ thể.
  * **8 ca khác SĐT / khác Email:** Ví dụ `Nguyễn Phương Loan` (R030 vs R224), `Hồ Quốc Thành` (R034 vs R274), `Phan Hoài Mai` (R356 vs R388)... *Gợi ý:* Nghiêng về gộp (khách hàng có 2 SIM) sau khi nhân sự gọi điện xác nhận số phụ.

---

## 4. Những lỗi không sửa được (Giữ nguyên vết tại `nhat-ky-sua.csv`)

Các trường hợp dữ liệu hỏng, không rõ ràng được làm sạch bằng cách để trống ở cột chuẩn hóa và ghi log chi tiết:
1. **13 SĐT không hợp lệ:**
   * **7 số bị che dấu sao (`***`):** `0885 *** 291`, `0895 *** 739`, `0885 *** 955`, `0325***473`, `0945***369`, `0765 *** 998`, `0815***258`.
   * **4 số thiếu chữ số (chỉ có 9 số):** `081555039`, `036555061`, `094555036`, `076555012`.
   * **2 số thuộc đầu số cũ 11 số (mạng 01x chưa đổi):** `01295550449`, `01295550548`.
2. **31 Email sai cú pháp:**
   * **12 email đuôi lạ `.con`:** `mythanh91@example.con`, `trunggia94@example.con`, `nhungngoc@example.con`...
   * **8 email có 2 ký tự `@` (`@@`):** `haiduong7@@example.org`, `ly.van@@example.com`...
   * **5 email thiếu đuôi tên miền:** `hoang.do@example`, `nghia.tran7@example`, `giangthu94@example`...
   * **3 email thiếu hẳn ký tự `@`:** `le.namexample.com`, `taidang94example.com`, `hien.hoangexample.net`.
   * **3 email chứa khoảng trắng bên trong:** `an. bui@example.net`, `dungn goc93@example.com`, `lank hanh1@example.org`.
3. **99 dòng khuyết Địa chỉ:** Giữ nguyên trống, không phỏng đoán vị trí địa lý.

---

## 5. Đề xuất quy tắc bổ sung cho các đợt xử lý sau

Nếu cửa hàng muốn tối ưu tự động hóa cao hơn, khuyến nghị xem xét áp dụng thêm 2 quy tắc:
1. **Quy tắc Q2-A (Gộp theo Định danh Địa chỉ & Tên đầy đủ):** Cho phép tự động gộp các đơn hàng trùng 100% Họ tên tiếng Việt đầy đủ và trùng khớp Địa chỉ chi tiết (đến cấp số nhà, ngách/ngõ, tên đường, phường, quận, thành phố), số điện thoại thứ hai sẽ tự động lưu vào cột `sdt_khac`.
2. **Quy tắc Q1-A (Liên kết tài khoản theo mã OTP/Zalo ID):** Với các tài khoản Zalo chỉ lưu tên gọi 1 từ (như `c Linh`, `anh Phát`), bổ sung bước gửi tin nhắn Zalo ZNS hoặc SMS OTP tự động để khách hàng xác nhận tài khoản chính, thay vì phải gọi điện thủ công.
