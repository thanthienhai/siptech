import pandas as pd
import openpyxl, re, csv, unicodedata

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
df_orders['amount'] = df_orders['Tổng phải thu'].apply(clean_amount)
df_orders['kh_clean'] = df_orders['Khách hàng'].apply(strip_accents).str.upper()

orders_by_id = {r['Mã đơn']: r for _, r in df_orders.iterrows()}

with open('sao-ke-t10-2026.csv', encoding='utf-8-sig') as f:
    rows = list(csv.reader(f))

txs = [r for r in rows[8:] if r and r[0] and 'Tong phat sinh' not in r[0] and 'So du cuoi' not in r[0]]

# Let's inspect multi-order transactions
# 1. TX #64: 75681747 | 23/10/2026 | co | 1,860,000 | DH2610-096 DH2610-063 DH2610-017 BUI NGOC YEN
# DH2610-096: 390,000; DH2610-063: 560,000; DH2610-017: 910,000 -> Sum = 390k + 560k + 910k = 1,860,000! Khớp chuẩn!
# 2. TX #85: 16513561 | 28/10/2026 | co | 710,000 | DH2610-098 105 090
# DH2610-098: 360,000; DH2610-105: 150,000; DH2610-090: 200,000 -> Sum = 360k + 150k + 200k = 710,000! Khớp chuẩn! (Khách Ngô Kim Chi)
# 3. TX #86: 48682672 | 28/10/2026 | co | 1,260,000 | DANG THI NHUNG CK DH2610031 va DH2610102
# DH2610-031: 910,000; DH2610-102: 350,000 -> Sum = 910k + 350k = 1,260,000! Khớp chuẩn! (Khách Đặng Thị Nhung)
# 4. TX #89: 31446908 | 29/10/2026 | co | 1,350,000 | TRAN HUU DAT CK 2 don
# DH2610-013: 900,000; DH2610-120: 450,000 -> Sum = 900k + 450k = 1,350,000! Khớp chuẩn! (Khách Trần Hữu Đạt)
# 5. TX #91: 69877345 | 29/10/2026 | co | 3,510,000 | TT DH2610-118, DH2610-035, DH2610-078
# DH2610-118: 780,000; DH2610-035: 1,810,000; DH2610-078: 920,000 -> Sum = 780k + 1810k + 920k = 3,510,000! Khớp chuẩn! (Khách Lý Thị Linh)
# 6. TX #94: 98430319 | 29/10/2026 | co | 1,590,000 | TT 3 don 116 024 097
# DH2610-116: 360,000; DH2610-024: 1,050,000; DH2610-097: 180,000 -> Sum = 360k + 1050k + 180k = 1,590,000! Khớp chuẩn! (Khách Hoàng Minh Khánh)

print("Verified all 6 multi-order transactions!")
