"""Sinh bộ 250 đánh giá GIẢ của một quán cà phê HƯ CẤU ("Mây Lưng Chừng") để học phân tích đánh giá.

Chạy:  python -X utf8 sinh_du_lieu.py
Ra:    danh-gia.csv, danh-gia.xlsx            (cho người học / agent)
       ../ket-qua/dap-an.json                 (đáp án: KHÔNG đưa vào thư mục agent làm việc)

Hạt giống cố định => chạy lại ra đúng bộ cũ.
Tất cả nội dung là bịa. Không có tên người, tên doanh nghiệp, SĐT, STK thật.
Giọng văn tham chiếu (chỉ tham khảo cách người Việt viết đánh giá; không chép câu nào):
  UIT-ViSFD (arXiv 2105.15079) / UIT-ViSD4SA (arXiv 2110.07833): giấy phép không rõ, "dùng cho nghiên cứu".
Đáp án cài sẵn: chủ đề + sắc thái từng ý, mỉa mai, nguy cấp, trùng/spam, 5 vấn đề được "cài" vào dữ liệu (I1..I5).
"""
import random, re, json, csv, unicodedata, datetime as dt
from collections import Counter, defaultdict
from pathlib import Path

SEED = 20261120
R = random.Random(SEED)
HERE = Path(__file__).resolve().parent
OUT_ANSWER = HERE.parent / "ket-qua" / "dap-an.json"
W0 = dt.date(2026, 8, 24)  # thứ Hai đầu tiên; 12 tuần: 24/8 .. 15/11/2026
NWEEK = 12
TOTAL = 250

TOPICS = ["gia", "phuc_vu", "chat_luong", "giao_hang", "khong_gian", "ve_sinh"]
POS, NEG, NEU = "tich_cuc", "tieu_cuc", "trung_tinh"
MON = ["cà phê muối", "bạc xỉu", "trà đào cam sả", "matcha latte", "trà sữa", "cacao đá xay", "cà phê sữa"]
TAIL = ["Mình ghé buổi sáng.", "Đi cùng nhóm bạn.", "Ghé buổi chiều tối.", "Lần thứ ba mình ghé rồi.", "Cuối tuần đi với gia đình.", "Đi một mình cho yên tĩnh.", "Đi đúng giờ nghỉ trưa.", "Hôm đó trời mưa."]

# ---------------------------------------------------------------- ngân hàng mệnh đề (đã gán đúng chủ đề + sắc thái)
BANK = {
 ("gia", POS): ["Giá mềm, sinh viên uống thoải mái", "Giá hợp lý so với chất lượng", "{mon} giá có 35k mà đầy đặn", "Giá ổn áp trong tầm này",
                "Giá rẻ hơn mấy quán quanh đây", "Combo giá hời, tiết kiệm được kha khá"],
 ("gia", NEG): ["Giá hơi cao so với cái ly nhỏ xíu", "Giá cao hơn mặt bằng chung của khu này", "Giá chưa tương xứng với chất lượng"],
 ("gia", "NEG_RAISE"): ["Dạo này quán tăng giá, {mon} lên {p}k mà ly vẫn vậy", "Lên giá mà không báo trước, thấy hơi tiếc", "Giá lên hoài, giờ đắt hơn quán bên cạnh",
                "Menu mới tăng khoảng 10k mỗi món, uống hơi xót ví", "Đắt quá, {p}k cho ly {mon} thì thôi", "Quán tăng giá rồi, ghé ít hẳn đi"],
 ("gia", NEU): ["Giá bình thường như mặt bằng chung", "Giá tầm trung, không rẻ không đắt"],
 ("phuc_vu", POS): ["Nhân viên dễ thương, tư vấn nhiệt tình", "Bạn phục vụ nhanh nhẹn, lịch sự", "Order xong lên đồ nhanh", "Nhân viên nhớ mặt khách quen, hỏi thăm vui",
                "Phục vụ chu đáo, tự động châm thêm nước lọc", "Bạn thu ngân tính tiền nhanh, cười tươi"],
 ("phuc_vu", NEG): ["Đợi {n} phút mới có nước, hỏi thì bảo đang đông", "Phục vụ chậm, gọi mấy lần mới có người ra", "Lên món sai, đổi lại mất thêm 15 phút",
                "Order bị quên, nhắc mới làm", "Nhân viên ít, giờ cao điểm xoay không kịp", "Gọi nước mà chờ gần {n} phút, bàn bên cạnh gọi sau lại có trước"],
 ("phuc_vu", NEU): ["Phục vụ bình thường, không có gì đặc biệt"],
 ("chat_luong", POS): ["{mon} ngon, vị đậm đà", "Cà phê thơm, không bị chua", "{mon} béo mà không ngấy", "Đồ ăn nóng hổi, trình bày đẹp", "Bánh tươi, mềm, ăn là mê",
                "Nước uống đúng vị, đá không loãng", "{mon} ở đây là chân ái", "Hương vị {mon} ngon hơn mong đợi"],
 ("chat_luong", NEG): ["{mon} nhạt, như pha nhiều đá", "Cà phê hôm nay chua và đắng gắt", "Bánh hơi khô, ăn không ngon như lần trước", "{mon} ngọt gắt, uống một ngụm là ngán",
                "Nước pha loãng toẹt, uống như nước đường", "Đồ ăn nguội ngắt, vị bình thường"],
 ("chat_luong", NEU): ["Đồ uống bình thường, uống được", "{mon} tạm ổn, chưa tới mức ấn tượng"],
 ("giao_hang", POS): ["Giao nhanh, đóng gói kỹ", "Shipper thân thiện, tới đúng giờ", "Ly nước giao tới còn lạnh, không đổ", "Đặt buổi trưa mà 15 phút là có, quá nhanh",
                "Đóng gói cẩn thận, có kèm ống hút và khăn giấy"],
 ("giao_hang", NEG): ["Giao chậm hơn dự kiến gần 1 tiếng", "Nước giao tới bị đổ ra túi, dính đầy", "Đồ ăn tới nguội và thiếu một món", "Shipper gọi mà không bắt máy, đồ tới trễ",
                "Đặt {mon} nhưng giao nhầm món khác", "Bánh bị bẹp dí do đóng gói sơ sài"],
 ("giao_hang", NEU): ["Giao hàng đúng như app báo, không nhanh không chậm"],
 ("khong_gian", POS): ["Quán yên tĩnh, ngồi làm việc rất ổn", "Không gian xinh, nhiều góc chụp ảnh", "Máy lạnh mát, wifi mạnh", "Ghế êm, có ổ cắm ở mỗi bàn",
                "Nhạc nhẹ nhàng, ánh đèn ấm", "View ban công nhìn ra hàng cây rất chill"],
 ("khong_gian", NEG): ["Quán ồn, nhạc to quá nói chuyện không nghe", "Chỗ ngồi chật, bàn sát nhau", "Máy lạnh yếu, ngồi nóng toát mồ hôi", "Wifi chập chờn, làm việc không nổi",
                "Ghế cứng, ngồi lâu đau lưng", "Khu để xe nhỏ, giờ đông hay hết chỗ"],
 ("khong_gian", NEU): ["Không gian cũng ổn, không có gì nổi bật"],
 ("ve_sinh", POS): ["Bàn ghế sạch sẽ, nhà vệ sinh thơm", "Ly tách sạch, nhìn là yên tâm", "Quán lau dọn liên tục, sàn khô ráo"],
 ("ve_sinh", NEG): ["Nhà vệ sinh hơi bẩn, hết giấy", "Bàn dính nước ngọt cũ chưa lau", "Có ruồi bay quanh quầy bánh", "Ly còn dấu son môi chưa rửa sạch", "Sàn trơn, có vết ướt nhiều chỗ"],
 ("ve_sinh", NEU): ["Quán sạch ở mức chấp nhận được"],
}
EMO = {POS: ["😍", "👍", "❤️", "🥰", "😋", "👏", "☕"], NEG: ["😡", "😤", "👎", "😞", "😒"], NEU: ["😐", "🙂", "🤔"]}

# ---------------------------------------------------------------- nhiễu kiểu viết đời thường
TEEN = [(r"\bkhông\b", ["ko", "k", "hok"]), (r"\bđược\b", ["dc", "đc"]), (r"\bnhân viên\b", ["nv"]), (r"\bvới\b", ["vs"]), (r"\btrước\b", ["trc"]),
        (r"\bquá\b", ["qá", "wá"]), (r"\bluôn\b", ["lun"]), (r"\bnhưng\b", ["nhg"]), (r"\bmình\b", ["mik"]), (r"\bthích\b", ["thik"]),
        (r"\bvậy\b", ["z"]), (r"\bgiờ\b", ["h"]), (r"\bmà\b", ["ma"]), (r"\bphút\b", ["p"]), (r"\bquán\b", ["quan"])]

def strip_diacritics(s):
    s = s.replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")

def teen(s):
    for pat, alts in TEEN:
        s = re.sub(pat, lambda m: R.choice(alts) if R.random() < 0.6 else m.group(0), s)
    return s

def elongate(s):
    for w in ["ngon", "đẹp", "mát", "nhanh", "thích", "xịn", "chill", "mê"]:
        if w in s and R.random() < 0.5:
            return s.replace(w, w + w[-1] * R.randint(2, 4), 1)
    return s

def nd(s):  # bỏ dấu thủ công cho câu viết tay
    return strip_diacritics(s)

# ---------------------------------------------------------------- hệ số theo tuần (cài xu hướng)
def p_sent(topic, w):
    if topic == "gia":      return (0.45, 0.25, 0.30) if w < 5 else (0.10, 0.72, 0.18)
    if topic == "giao_hang": return (0.62, 0.22, 0.16) if w < 6 else (0.10, 0.80, 0.10)
    if topic == "ve_sinh":  return (0.45, 0.50, 0.05) if w < 9 else (0.10, 0.85, 0.05)
    if topic == "phuc_vu":  return (0.55, 0.33, 0.12)
    if topic == "khong_gian": return (0.65, 0.25, 0.10)
    return (0.68, 0.20, 0.12)

def w_topic(w):
    return {"chat_luong": 0.30, "phuc_vu": 0.22, "khong_gian": 0.18, "gia": 0.14 if w < 5 else 0.30, "ve_sinh": 0.05 if w < 9 else 0.12}

def pick(weights):
    ks = list(weights); return R.choices(ks, [weights[k] for k in ks])[0]

# ---------------------------------------------------------------- bài sinh tự động
def gen_review(w):
    platform = R.choices(["gmaps", "shopee", "fb"], [0.46, 0.34, 0.20])[0]
    k = R.choices([1, 2, 3], [0.45, 0.40, 0.15])[0]
    wt = w_topic(w); topics = []
    if platform == "shopee" and R.random() < 0.85: topics.append("giao_hang")
    while len(topics) < k:
        t = pick(wt)
        if t not in topics: topics.append(t)
    topics = topics[:max(k, len(topics))]
    R.shuffle(topics)
    style = {"strip": R.random() < 0.22, "teen": R.random() < 0.35, "lower": R.random() < 0.25, "long": R.random() < 0.4}
    clauses = []
    for t in topics:
        s = R.choices([POS, NEG, NEU], p_sent(t, w))[0]
        key = (t, "NEG_RAISE") if (t == "gia" and s == NEG and w >= 5) else (t, s)
        txt = R.choice(BANK[key]).format(mon=R.choice(MON), n=R.choice([20, 25, 30, 40, 45]), p=R.choice([49, 55, 59, 65]))
        clauses.append({"chu_de": t, "sac_thai": s, "raw": txt})
    # ghép
    parts = []
    for i, c in enumerate(clauses):
        if i == 0: j = ""
        else:
            prev = clauses[i - 1]["sac_thai"]
            if prev != c["sac_thai"] and R.random() < 0.6: j = " nhưng "
            elif prev == c["sac_thai"] and R.random() < 0.3: j = " với "
            else: j = R.choice([", ", ". ", ", "])
        c["join"] = j
        raw = c["raw"] if j in ("", ". ") else c["raw"][0].lower() + c["raw"][1:]
        if style["teen"]: raw = teen(raw)
        if style["lower"] and j == "": raw = raw[0].lower() + raw[1:]
        if style["long"] and c["sac_thai"] == POS: raw = elongate(raw)
        if style["strip"]: raw = strip_diacritics(raw)
        c["doan"] = raw
        parts.append(j.replace("nhưng", "nhg") if (style["teen"] and j == " nhưng ") else j)
        parts.append(raw)
    text = "".join(parts)
    if style["strip"]: text = strip_diacritics(text)
    if not text.rstrip().endswith((".", "!", "?")) and R.random() < 0.5 and not style["lower"]: text += "."
    if R.random() < 0.35:
        text = (text.rstrip(". ") + ". " if not text.endswith(("!", "?")) else text + " ") + R.choice(TAIL)
    if R.random() < 0.42:
        s_last = clauses[-1]["sac_thai"]
        s_emo = s_last if R.random() < 0.93 else R.choice([POS, NEG])
        text += " " + R.choice(EMO[s_emo])
    stars = stars_from(clauses)
    return {"nen_tang": platform, "w": w, "text": text,
            "aspects": [{"chu_de": c["chu_de"], "sac_thai": c["sac_thai"], "doan": c["doan"]} for c in clauses], "sao": stars}

def stars_from(clauses):
    v = sum({POS: 1, NEG: -1, NEU: 0}[c["sac_thai"]] for c in clauses) / max(1, len(clauses))
    base = 5 if v > 0.6 else 4 if v > 0.2 else 3 if v > -0.2 else 2 if v > -0.6 else 1
    if R.random() < 0.06: base = R.choice([1, 2, 3, 4, 5])  # sao lệch nội dung
    return base

# ---------------------------------------------------------------- bài viết tay (tình huống khó), w = chỉ số tuần 0..11, d = thứ trong tuần 0..6
def H(w, d, nen, sao, text, aspects, **kw):
    return dict(w=w, d=d, nen_tang=nen, sao=sao, text=text, aspects=[dict(chu_de=a[0], sac_thai=a[1]) for a in aspects], hand=True, **kw)

G, S_ = "gmaps", "shopee"; F = "fb"
HAND = []
# --- nguy cấp: ngộ độc (I1) tuần 8-9. muc: chac | nghi
HAND += [
 H(8, 1, G, 1, "Ăn bánh mì chả ở đây trưa thứ Ba, tối cả hai vợ chồng nôn mửa với tiêu chảy, phải đi cấp cứu. Bác sĩ nói nghi ngộ độc thực phẩm. Quán kiểm tra lại nguồn chả giùm.", [("chat_luong|ve_sinh", NEG)], nguy_cap=("ngo_doc", "chac")),
 H(8, 2, S_, 1, "Đặt trà sữa với bánh tiramisu giao tận nhà, con mình 6 tuổi ăn xong 2 tiếng sau nôn và sốt. Hoang mang quá, ai ăn tiramisu hôm đó nhớ để ý.", [("chat_luong|ve_sinh", NEG)], nguy_cap=("ngo_doc", "chac")),
 H(8, 3, F, None, "mình thấy 1 con gián nhỏ nổi trong ly nước ép cam, chụp hình rồi. ghê quá, hết dám uống luôn", [("ve_sinh", NEG)], nguy_cap=("ngo_doc", "chac")),
 H(9, 0, G, 1, "Cảnh báo: uống ly sữa chua cacao có mùi chua lạ, hôm sau đau bụng quặn, đi ngoài liên tục tới chiều. Nhiều khả năng do sữa hỏng.", [("chat_luong|ve_sinh", NEG)], nguy_cap=("ngo_doc", "chac")),
 H(8, 4, G, 2, "Hôm qua ăn tiramisu ở đây, tối đau bụng đi ngoài mấy lần. Không dám khẳng định do quán nhưng ai ăn nhớ cẩn thận nha", [("chat_luong", NEG)], nguy_cap=("ngo_doc", "nghi")),
 H(9, 2, F, None, "croissant hình như bị ôi, cắn xong thấy buồn nôn nên bỏ lại luôn", [("chat_luong", NEG)], nguy_cap=("ngo_doc", "nghi")),
]
# --- nguy cấp: thái độ (I4) tuần 2-4
HAND += [
 H(2, 1, G, 1, "Mình hỏi lại giá ly bạc xỉu thì bạn thu ngân chửi luôn 'mù hả không đọc menu à' trước mặt cả quán. Nói chuyện kiểu đó với khách thì thôi, khỏi quay lại.", [("phuc_vu", NEG)], nguy_cap=("thai_do", "chac")),
 H(3, 0, G, 1, "Bạn nam ca tối ném menu xuống bàn rồi quay đi, hỏi gì cũng trả lời trống không. Xin thêm ly nước lọc thì liếc xéo nói 'không mua thì ra'.", [("phuc_vu", NEG)], nguy_cap=("thai_do", "chac")),
 H(3, 3, F, None, "báo hết chỗ nhưng mình thấy rõ còn 3 bàn trống, mình thắc mắc thì bị nhân viên đuổi ra khỏi quán, giọng rất hách dịch", [("phuc_vu", NEG)], nguy_cap=("thai_do", "chac")),
 H(4, 2, G, 1, "Quản lý đứng quầy quát khách vì để xe sai chỗ, dùng từ rất khó nghe, có cả khách nước ngoài đứng nhìn. Quá thất vọng về cách đối xử với khách.", [("phuc_vu", NEG)], nguy_cap=("thai_do", "chac")),
 H(4, 5, G, 1, nd("nhân viên nữ ở quầy vừa tính tiền vừa nói kỵ với đồng nghiệp, mình hỏi 1 câu thì bị quát 'đừng hỏi nhiều'. thái độ tệ nhất từng gặp"), [("phuc_vu", NEG)], nguy_cap=("thai_do", "chac")),
]
# --- nguy cấp: lừa đảo (I5) tuần 7-10
HAND += [
 H(7, 1, G, 1, "Bill ghi 2 ly bạc xỉu mà mình chỉ gọi 1, báo thì nhân viên bảo máy tính tự tính nên cứ trả đủ. Mình thấy như bị móc túi, ai thanh toán nhớ soi bill kỹ.", [("gia|phuc_vu", NEG)], nguy_cap=("lua_dao", "chac")),
 H(8, 5, F, None, "Fanpage đăng mua 1 tặng 1 cuối tuần, ra quán thì nói hết chương trình dù bảng vẫn dán ngay quầy. Câu khách bằng khuyến mãi ảo vậy sao?", [("gia|phuc_vu", NEG)], nguy_cap=("lua_dao", "chac")),
 H(9, 1, S_, 1, "Đặt Shopee Food đã trả tiền xong, quán bấm hoàn thành đơn mà không giao, gọi lại thì cúp máy. Mất 189k. Lừa đảo!", [("giao_hang", NEG)], nguy_cap=("lua_dao", "chac")),
 H(10, 0, G, 1, "Cuối bill tự cộng 10% phí dịch vụ, menu không ghi chỗ nào, hỏi thì nói quy định mới. Báo trước một câu cũng không.", [("gia", NEG)], nguy_cap=("lua_dao", "chac")),
 H(10, 3, F, None, "gọi size L trên menu, đưa ly size M mà vẫn tính tiền size L. mình đo thử rõ ràng nhỏ hơn cái ly bên cạnh. lừa khách vừa thôi", [("gia|chat_luong", NEG)], nguy_cap=("lua_dao", "chac")),
]
# --- ca ranh giới (không phạt dù báo hay không báo là nguy cấp)
HAND += [
 H(5, 2, G, 3, "Nhân viên hơi lạnh, không chào khách, nhưng đồ uống ổn.", [("phuc_vu", NEG), ("chat_luong", POS)], nguy_cap=("thai_do", "ranh_gioi")),
 H(6, 4, G, 3, "Giá trên bill cao hơn menu 5k, chắc nhập sai thôi. Mình nhắc thì bạn sửa lại luôn, cảm ơn bạn.", [("gia", NEG), ("phuc_vu", POS)], nguy_cap=("lua_dao", "ranh_gioi")),
 H(7, 3, S_, 3, "Ly nước có mùi hơi lạ, uống nửa ly thì bỏ, không biết có sao không, chắc do mình nhạy cảm.", [("chat_luong", NEG)], nguy_cap=("ngo_doc", "ranh_gioi")),
 H(9, 4, G, 1, nd("sau vụ người ta báo đau bụng ở đây thì mình cũng hơi ngại, vào thấy bàn ghế vẫn bị dính nước cũ chưa lau"), [("ve_sinh", NEG)], nguy_cap=("ngo_doc", "ranh_gioi")),
]
# --- bẫy từ khóa: khen phóng đại KHÔNG phải nguy cấp
HAND += [
 H(1, 2, G, 5, "Cà phê muối ngon xỉu luôn 😍 uống xong tim đập loạn mà vẫn muốn gọi thêm ly nữa", [("chat_luong", POS)], decoy=True),
 H(2, 4, F, None, "ghiền như bị bỏ bùa, tuần nào cũng phải ghé. nhân viên xinh như idol, nhìn là hết giận", [("chat_luong", POS), ("phuc_vu", POS)], decoy=True),
 H(5, 5, G, 5, "Đau bụng cười vì con mèo của quán béo quá, nằm chắn cả lối đi 🤣 không gian vui, nhân viên dễ thương", [("khong_gian", POS), ("phuc_vu", POS)], decoy=True),
 H(6, 1, G, 5, "Matcha latte ở đây đỉnh của chóp, không phải lừa đảo đâu thật sự ngon á 👏👏", [("chat_luong", POS)], decoy=True),
 H(6, 3, S_, 5, "Shipper giao nhanh như chớp, ly nước còn mát lạnh. Chết mê luôn", [("giao_hang", POS)], decoy=True),
 H(9, 5, G, 4, "giá đắt như vàng nhưng mà ngon tới mức sẵn sàng bán thận 😂", [("gia", NEG), ("chat_luong", POS)], decoy=True),
]
# --- mỉa mai: câu chữ nghe như khen, ý thật là chê => phải vào CẦN NGƯỜI ĐỌC
HAND += [
 H(1, 4, G, 4, "Phục vụ nhanh ghê, chỉ đợi có 45 phút thôi à 👏👏", [("phuc_vu", NEG)], mia_mai=True),
 H(2, 2, G, 5, "Quán đẹp ghê, đẹp tới mức ngồi nóng như lò nướng bánh mì 😂", [("khong_gian", NEG)], mia_mai=True),
 H(3, 5, F, None, "Giá hợp lý lắm luôn, hợp lý với ví của chủ quán 🙃", [("gia", NEG)], mia_mai=True),
 H(7, 0, S_, 5, "Shipper giao nhanh quá, nhanh tới mức mình đặt sáng giờ chưa thấy đâu", [("giao_hang", NEG)], mia_mai=True),
 H(5, 0, G, 5, "Cảm ơn quán đã cho mình trải nghiệm ly trà đào không có đào 🥰", [("chat_luong", NEG)], mia_mai=True),
 H(6, 2, G, 5, "5 sao cho sự đều đặn: lần nào cũng quên order của mình", [("phuc_vu", NEG)], mia_mai=True),
 H(8, 0, F, None, "wifi mạnh ghê luôn, mạnh tới mức mình phải xài 4G 👍", [("khong_gian", NEG)], mia_mai=True),
 H(9, 3, S_, 4, "Đồ ăn giao tới nguội ngắt, đúng kiểu ăn cho mát bụng mùa hè nhỉ 😊", [("giao_hang", NEG)], mia_mai=True),
 H(10, 2, G, 5, "Nhà vệ sinh sạch thật, sạch tới mức mình phải bịt mũi mới dám vào", [("ve_sinh", NEG)], mia_mai=True),
 H(4, 0, F, None, nd("Tuyệt vời, uống cà phê mà như uống nước đường pha đá, quán biết tiết kiệm cà phê ghê"), [("chat_luong", NEG)], mia_mai=True),
 H(11, 1, G, 5, "Quán tăng giá đều đặn mỗi tháng, chắc để khách có động lực đi làm kiếm tiền 👏", [("gia", NEG)], mia_mai=True),
 H(7, 4, G, 4, "Nhân viên thân thiện lắm, thân thiện tới mức mình giơ tay 3 lần vẫn tàng hình 🙂", [("phuc_vu", NEG)], mia_mai=True),
 H(10, 4, S_, 4, "Giao hàng chuyên nghiệp quá, bánh được ép phẳng lì miễn phí luôn", [("giao_hang", NEG)], mia_mai=True),
 H(11, 3, G, 5, nd("đúng là quán có đầu tư, nhạc to đến mức mình khỏi cần nói chuyện luôn, tiết kiệm nước bọt 😂😂"), [("khong_gian", NEG)], mia_mai=True),
]
# --- mơ hồ: không đủ ý để gán chủ đề/sắc thái => được phép để CẦN NGƯỜI ĐỌC hoặc bỏ qua
HAND += [
 H(0, 2, G, 3, "Cũng bình thường. Chắc lần sau thử lại.", [], mo_ho=True),
 H(2, 5, F, None, "ổn nhưng mà thôi kệ 🙂", [], mo_ho=True),
 H(5, 4, G, 4, "Được. Như mọi khi.", [], mo_ho=True),
 H(7, 5, G, 3, "Không như kỳ vọng, nhưng cũng không đến nỗi.", [], mo_ho=True),
 H(4, 4, S_, 4, "Ok nha 👌", [], mo_ho=True),
 H(9, 6, G, 2, "Hơi tiếc, lần trước không như vậy...", [], mo_ho=True),
]
# --- spam / không phải đánh giá
HAND += [
 H(3, 4, F, None, "Nhận chạy quảng cáo Facebook, tăng like fanpage giá rẻ, liên hệ Zalo 0900.000.000", [], loai_bo=("spam", None)),
 H(6, 0, G, 5, "Vào link này nhận quà 500k miễn phí: example.com/qua-tang", [], loai_bo=("spam", None)),
 H(8, 6, G, 5, "Quán bên kia đường ngon hơn nhiều, qua đó đi mọi người ơi", [], loai_bo=("spam", None)),
 H(10, 5, F, None, "Cho mình hỏi quán mở cửa tới mấy giờ vậy ạ?", [], loai_bo=("khong_phai_danh_gia", None)),
]
# --- tiếng Anh
HAND += [
 H(3, 2, G, 4, "Coffee is great and the staff are friendly, but the place is too noisy in the evening.", [("chat_luong", POS), ("phuc_vu", POS), ("khong_gian", NEG)]),
 H(6, 5, G, 2, "Waited 30 minutes for a latte. Overpriced for the size.", [("phuc_vu", NEG), ("gia", NEG)]),
 H(10, 6, G, 5, "Lovely cozy place, great wifi, will come back.", [("khong_gian", POS)]),
]
# --- nhiều ý trái chiều, không dấu, teen code
HAND += [
 H(1, 5, G, 4, nd("đồ uống ngon, giá ok, nhưng nhân viên hơi chậm, gọi 2 lần mới ra"), [("chat_luong", POS), ("gia", POS), ("phuc_vu", NEG)]),
 H(4, 3, F, None, "nv dễ thương mà đồ uống nhạt toẹt, ko biết do hôm nay hay sao", [("phuc_vu", POS), ("chat_luong", NEG)]),
 H(6, 6, S_, 3, "giao nhanh lắm, 20p là có rồi. vị trà đào thì ngon nhưng đóng gói ẩu nên đổ hết 1/3 ra túi 😤", [("giao_hang", POS), ("chat_luong", POS), ("giao_hang", NEG)]),
 H(2, 0, G, 5, "Chỗ làm việc lý tưởng: yên tĩnh, ổ cắm đầy đủ, wifi nhanh. Chỉ tiếc bãi xe hơi nhỏ.", [("khong_gian", POS), ("khong_gian", NEG)]),
 H(7, 2, G, 2, "Giá lên mà ly thì nhỏ lại?? 55k 1 ly cf muối mà uống 3 ngụm hết, ko đáng tiền, nhưng cf thì vẫn ngon", [("gia", NEG), ("chat_luong", POS)]),
 H(5, 3, F, None, "Hôm nay quán đông quá nên đợi hơi lâu, bù lại bạn nhân viên xin lỗi rồi tặng bánh cookie, dễ thương ghê", [("phuc_vu", NEG), ("phuc_vu", POS)]),
 H(3, 1, S_, 5, "đặt 3 ly + 2 bánh, giao tới đúng nhiệt độ luôn, bánh ngon, sẽ ủng hộ tiếp", [("giao_hang", POS), ("chat_luong", POS)]),
]

# ---------------------------------------------------------------- lắp ráp
def date_for(w, d): return W0 + dt.timedelta(days=7 * w + d)

def fmt_date(nen, day):
    if nen == "gmaps": return day.strftime("%d/%m/%Y")
    if nen == "shopee": return day.isoformat()
    return day.isoformat() if R.random() < 0.5 else day.strftime("%d/%m/%Y")

def build():
    n_dup = 4
    n_gen = TOTAL - len(HAND) - n_dup
    wts = [1, 1, 1, 1, 1, 1, 1.1, 1.1, 1.2, 1.2, 1.1, 1.1]
    weeks = R.choices(range(NWEEK), wts, k=n_gen)
    items = []
    seen = {h["text"] for h in HAND}
    for w in weeks:
        while True:
            r = gen_review(w)
            if r["text"] not in seen: break
        seen.add(r["text"]); r["d"] = R.randint(0, 6); r["hand"] = False; items.append(r)
    # trùng nguyên văn: copy 4 bài sinh (tuần <= 6, có ý kiến) sang 2-4 tuần sau
    cands = [r for r in items if r["w"] <= 6 and len(r["aspects"]) >= 1]
    R.shuffle(cands)
    dups = []
    for src in cands[:n_dup]:
        c = dict(src); c["w"] = min(NWEEK - 1, src["w"] + R.randint(2, 4)); c["d"] = R.randint(0, 6)
        c["dup_of_key"] = id(src); c["aspects"] = []; c["loai_bo"] = ("trung_lap", id(src)); c["hand"] = False
        dups.append(c)
    allr = items + HAND + dups
    for r in allr: r["date"] = date_for(r["w"], r["d"])
    allr.sort(key=lambda r: (r["date"], R.random()))
    # mã theo thứ tự ngày
    key2ma = {}
    for i, r in enumerate(allr, 1):
        r["ma"] = f"R{i:03d}"; key2ma[id(r)] = r["ma"]
    return allr, key2ma

ISSUE_DEF = {
 "I1": "Nghi ngộ độc / dị vật (cụm tuần 9-10)",
 "I2": "Giao hàng Shopee Food xấu đi từ tuần 7 (chậm, nguội, đổ, thiếu món, không giao)",
 "I3": "Tăng giá từ tuần 6, khách thấy đắt",
 "I4": "Thái độ nhân viên (chửi, quát, đuổi khách) tuần 3-5",
 "I5": "Tính tiền sai / thu phí không báo / khuyến mãi ảo / nhận tiền không giao (tuần 8-11)",
 "I6": "Phục vụ chậm giờ đông (có suốt, mức vừa) - vấn đề thật nhưng không thuộc 5 vấn đề cài chính",
}

def main():
    allr, key2ma = build()
    rows, gold = [], []
    for r in allr:
        ngay = fmt_date(r["nen_tang"], r["date"])
        sao = r["sao"]
        if r["nen_tang"] == "fb" and R.random() < 0.6 and not r["hand"]: sao = None
        rows.append({"ma": r["ma"], "nen_tang": {"gmaps": "Google Maps", "shopee": "Shopee Food", "fb": "Facebook"}[r["nen_tang"]],
                     "ngay": ngay, "sao": "" if sao is None else sao, "noi_dung": r["text"]})
        tuan = (W0 + dt.timedelta(days=7 * r["w"])).isoformat()
        aspects = [dict(chu_de=a["chu_de"], sac_thai=a["sac_thai"], doan=a.get("doan", "")) for a in r["aspects"]]
        mia = bool(r.get("mia_mai"))
        issues = set()
        for a in aspects:
            t = a["chu_de"].split("|")[0]
            if a["sac_thai"] == NEG:
                if t == "giao_hang" and r["w"] >= 6: issues.add("I2")
                if t == "gia" and r["w"] >= 5 and not r.get("nguy_cap"): issues.add("I3")
                if t == "phuc_vu" and not r.get("nguy_cap"): issues.add("I6")
        nc = r.get("nguy_cap")
        if nc and nc[1] == "chac" or (nc and nc[1] == "nghi"):
            issues.add({"ngo_doc": "I1", "thai_do": "I4", "lua_dao": "I5"}[nc[0]])
        lb = r.get("loai_bo")
        loai_bo = None
        if lb:
            loai_bo = {"ly_do": lb[0], "ma_goc": key2ma.get(lb[1]) if lb[1] else None}
        gold.append({"ma": r["ma"], "tuan": tuan, "nen_tang": rows[-1]["nen_tang"], "aspects": aspects, "mia_mai": mia, "mo_ho": bool(r.get("mo_ho")),
                     "bay_tu_khoa": bool(r.get("decoy")), "nguy_cap": ({"loai": nc[0], "muc": nc[1]} if nc else None),
                     "loai_bo": loai_bo, "van_de": sorted(issues), "viet_tay": bool(r.get("hand"))})
    # ghi dữ liệu
    with open(HERE / "danh-gia.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, ["ma", "nen_tang", "ngay", "sao", "noi_dung"]); w.writeheader(); w.writerows(rows)
    import openpyxl
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "danh-gia"
    ws.append(["ma", "nen_tang", "ngay", "sao", "noi_dung"])
    for r in rows: ws.append([r["ma"], r["nen_tang"], r["ngay"], r["sao"] if r["sao"] != "" else None, r["noi_dung"]])
    ws.column_dimensions["E"].width = 110
    wb.save(HERE / "danh-gia.xlsx")
    # đáp án + thống kê đúng theo nhãn
    wk = defaultdict(lambda: defaultdict(Counter))
    for g in gold:
        if g["loai_bo"]: continue
        for a in g["aspects"]:
            t = a["chu_de"].split("|")[0]
            wk[g["tuan"]][t][a["sac_thai"]] += 1
        if g["mia_mai"]:
            for a in g["aspects"]:
                t = a["chu_de"].split("|")[0]
                wk[g["tuan"]][t]["MIA_MAI"] += 1
    ans = {"seed": SEED, "ghi_chu": "DỮ LIỆU GIẢ để học. chu_de có dạng 'a|b' = chấp nhận a hoặc b. mia_mai: đáp án ý thật = tieu_cuc nhưng agent phải xếp CAN_NGUOI_DOC.",
           "van_de": ISSUE_DEF, "reviews": gold,
           "dem_theo_tuan_theo_nhan": {t: {c: dict(v) for c, v in d.items()} for t, d in wk.items()}}
    OUT_ANSWER.parent.mkdir(parents=True, exist_ok=True)
    OUT_ANSWER.write_text(json.dumps(ans, ensure_ascii=False, indent=1), encoding="utf-8")
    # in tóm tắt
    c = Counter(); per_week = Counter(g["tuan"] for g in gold)
    for g in gold:
        c["tong"] += 1
        if g["loai_bo"]: c["loai_bo_" + g["loai_bo"]["ly_do"]] += 1
        if g["mia_mai"]: c["mia_mai"] += 1
        if g["mo_ho"]: c["mo_ho"] += 1
        if g["bay_tu_khoa"]: c["bay_tu_khoa"] += 1
        if g["nguy_cap"]: c["nguy_cap_" + g["nguy_cap"]["muc"]] += 1
        for a in g["aspects"]: c["y_kien"] += 1
    print(dict(c)); print(sorted(per_week.items()))
    print("platform:", Counter(r["nen_tang"] for r in rows))

if __name__ == "__main__":
    main()
