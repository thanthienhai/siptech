# -*- coding: utf-8 -*-
"""Kiểm tra mọi trích dẫn có NGUYÊN VĂN trong cột noi_dung của đúng mã đó.
Chạy từ thư mục chứa danh-gia.csv:   python dau-ra/kiem-tra-trich-dan.py
Kiểm: y-kien.csv, nguy-cap.csv, và các dòng  > [mã] "trích"  trong bao-cao.md."""
import csv
import os
import re
import sys

THU_MUC = os.path.dirname(os.path.abspath(__file__))
GOC = os.path.dirname(THU_MUC)


def doc_csv(p):
    with open(p, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def main():
    noi_dung = {r["ma"]: r["noi_dung"] for r in doc_csv(os.path.join(GOC, "danh-gia.csv"))}
    ma_loai = {r["ma"] for r in doc_csv(os.path.join(THU_MUC, "loai-bo.csv"))}
    hong = []
    tong = 0

    def kiem(nguon, dong, ma, trich):
        nonlocal tong
        tong += 1
        if ma not in noi_dung:
            hong.append((nguon, dong, ma, trich, "mã không tồn tại"))
        elif not trich or trich not in noi_dung[ma]:
            hong.append((nguon, dong, ma, trich, "không có nguyên văn trong noi_dung"))

    for ten in ("y-kien.csv", "nguy-cap.csv"):
        for i, r in enumerate(doc_csv(os.path.join(THU_MUC, ten)), start=2):
            kiem(ten, i, r["ma"], r["trich_dan"])
            if ten == "y-kien.csv" and r["ma"] in ma_loai:
                hong.append((ten, i, r["ma"], r["trich_dan"], "bài đã bị loại bỏ vẫn có ý kiến"))

    mau = re.compile(r'^>\s*\[(R\d+)\]\s*"(.*)"\s*$')
    so_viec = 0
    bang_chung = []
    with open(os.path.join(THU_MUC, "bao-cao.md"), encoding="utf-8") as f:
        for i, dong in enumerate(f, start=1):
            if re.match(r"^## Việc \d+:", dong):
                so_viec += 1
                bang_chung.append(0)
            if dong.startswith(">"):
                m = mau.match(dong.rstrip("\n"))
                if not m:
                    hong.append(("bao-cao.md", i, "", dong.strip(), "dòng bằng chứng không đúng mẫu > [mã] \"trích\""))
                    continue
                kiem("bao-cao.md", i, m.group(1), m.group(2))
                if bang_chung:
                    bang_chung[-1] += 1
    if so_viec != 5:
        hong.append(("bao-cao.md", 0, "", "", "cần đúng 5 mục '## Việc', hiện có %d" % so_viec))
    for k, n in enumerate(bang_chung, start=1):
        if not 2 <= n <= 3:
            hong.append(("bao-cao.md", 0, "", "", "Việc %d có %d bằng chứng (cần 2-3)" % (k, n)))

    print("Da kiem %d trich dan." % tong)
    if hong:
        print("KHONG QUA %d dong:" % len(hong))
        for h in hong:
            print("  %s dòng %s [%s] %r -> %s" % h)
        sys.exit(1)
    print("TAT CA DEU QUA.")


if __name__ == "__main__":
    main()
