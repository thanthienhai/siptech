"""Gom 4 file CSV agent tạo thành MỘT file Excel cho chủ cửa hàng mở xem.
Chạy:  python -X utf8 xuat_excel.py <thu_muc_co_cac_file_csv> [ten_file.xlsx]
Cần: pip install openpyxl. Không đọc đáp án, chỉ đọc các file CSV trong thư mục."""
import csv, sys, json
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

d = Path(sys.argv[1]); out = Path(sys.argv[2]) if len(sys.argv) > 2 else d / "bao-cao-nhap-hang.xlsx"
SHEETS = [("De xuat nhap", "de-xuat-nhap.csv"), ("ABC va canh bao", "phan-loai-tinh-toan.csv"), ("Giu lai 2 thang", "giu-lai-do-loi.csv"), ("Loi du lieu", "loi-du-lieu.csv")]
NUM = {"sl_can_chua_xet_ngan_sach", "sl_de_xuat", "quy_cach", "don_gia_von", "thanh_tien", "gia_tri_tieu_thu_nam", "ton_kiem_ke", "ton_he_thong", "hang_dang_ve", "thuc_te", "du_bao", "moc_thang_truoc", "nhu_cau_du_bao_thang", "ton_an_toan", "diem_dat_lai", "do_lech_chuan", "chenh_kiem_ke", "so_ngay_ton", "uu_tien", "so_thang_hop_le"}
head = PatternFill("solid", fgColor="DDE6F3"); warn = PatternFill("solid", fgColor="FFF3C4"); red = PatternFill("solid", fgColor="FDE2E2")
wb = Workbook(); wb.remove(wb.active)
budget = json.loads((d / "tham-so.json").read_text(encoding="utf-8"))["ngan_sach_nhap_vnd"] if (d / "tham-so.json").exists() else None
for title, fn in SHEETS:
    p = d / fn
    if not p.exists(): continue
    rows = list(csv.reader(open(p, encoding="utf-8-sig", newline="")))
    ws = wb.create_sheet(title)
    for r, row in enumerate(rows, 1):
        for c, v in enumerate(row, 1):
            col = rows[0][c - 1]
            if r > 1 and col in NUM:
                try: v = float(v) if "." in v else int(v)
                except ValueError: pass
            cell = ws.cell(r, c, v)
            if r == 1: cell.font = Font(bold=True); cell.fill = head
            elif col in NUM: cell.number_format = "#,##0.##"
            if r > 1 and isinstance(v, str) and len(v) > 60: cell.alignment = Alignment(wrap_text=True, vertical="top")
    for c in range(1, len(rows[0]) + 1):
        w = max(len(str(ws.cell(r, c).value or "")) for r in range(1, min(len(rows), 80) + 1))
        ws.column_dimensions[get_column_letter(c)].width = min(max(10, w + 2), 60)
    ws.freeze_panes = "A2"
    header = rows[0]
    if "can_nguoi_quyet" in header:
        k = header.index("can_nguoi_quyet") + 1
        for r in range(2, len(rows) + 1):
            if ws.cell(r, k).value == "CO":
                for c in range(1, len(header) + 1): ws.cell(r, c).fill = warn
    if "canh_bao" in header:
        k = header.index("canh_bao") + 1
        for r in range(2, len(rows) + 1):
            if ws.cell(r, k).value in ("HET_HANG", "SAP_HET"):
                for c in range(1, len(header) + 1): ws.cell(r, c).fill = red
    if fn == "de-xuat-nhap.csv":
        k = header.index("thanh_tien") + 1; L = get_column_letter(k); last = len(rows)
        ws.cell(last + 2, 1, "TONG TIEN VON DE XUAT (cong thuc SUM)").font = Font(bold=True)
        ws.cell(last + 2, k, f"=SUM({L}2:{L}{last})").number_format = "#,##0"; ws.cell(last + 2, k).font = Font(bold=True)
        if budget:
            ws.cell(last + 3, 1, "Ngan sach (tham so)"); ws.cell(last + 3, k, budget).number_format = "#,##0"
            ws.cell(last + 4, 1, "Con lai / vuot (am = vuot)"); ws.cell(last + 4, k, f"={L}{last + 3}-{L}{last + 2}").number_format = "#,##0"
wb.save(out); print("da ghi", out)
