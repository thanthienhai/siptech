"""Dựng ảnh cho bài 06 từ dữ liệu và log THẬT. Chạy: python -X utf8 dung_anh.py <phần>
Phần: du-lieu | prompt | agent | ketqua | chamdiem | tukiem
Chạy với biến môi trường AGENTLAB trỏ tới thư mục chứa term.py (đường dẫn tương đối hoặc tuyệt đối trên máy bạn).
Cần: siptech-video/agentlab/term.py (render_blocks, shot_html). Các đường dẫn nằm ở đầu file.
"""
import sys, csv, json, html
from pathlib import Path
import os
sys.path.insert(0, os.environ.get("AGENTLAB", ".")); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))   # thư mục chứa term.py (công cụ dựng ảnh terminal từ log)
from term import render_blocks, shot_html, scrub_text, CSS as TCSS

def esc(x): return html.escape(scrub_text(str(x)))   # che đường dẫn máy, tên tổ chức, email trước khi đưa vào HTML

B = Path(__file__).resolve().parent.parent
ANH = B / "anh"; KQ = B / "ket-qua"; DL = B / "du-lieu"; LOGS = B / "logs"
ANH.mkdir(exist_ok=True)

CSS = """
*{box-sizing:border-box}body{margin:0;background:#f4f6fb;font-family:'Segoe UI',Arial,sans-serif;color:#0f172a}
.wrap{padding:18px;width:1280px}
h3{margin:0 0 8px;font-size:17px;color:#0b1f4d}
.cap{font-size:13px;color:#475569;margin:6px 0 0}
table{border-collapse:collapse;width:100%;font-size:14px;background:#fff}
th{background:#0b1f4d;color:#fff;text-align:left;padding:6px 10px;font-weight:600}
td{padding:5px 10px;border-bottom:1px solid #e2e8f0;font-family:'Cascadia Mono',Consolas,monospace;font-size:13px}
tr.bad td{background:#fef2f2}tr.warn td{background:#fffbeb}tr.ok td{background:#f0fdf4}
.box{background:#fff;border-radius:8px;padding:12px;box-shadow:0 2px 10px rgba(15,23,42,.08)}
.two{display:flex;gap:16px}.two>div{flex:1}
.tag{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12px;font-weight:700}
.t-r{background:#fee2e2;color:#991b1b}.t-y{background:#fef3c7;color:#92400e}.t-g{background:#dcfce7;color:#166534}
"""

def table(rows, cols, cls=None, head=None):
    h = "".join(f"<th>{esc(c)}</th>" for c in (head or cols))
    out = []
    for i, r in enumerate(rows):
        c = cls(r) if cls else ""
        out.append(f'<tr class="{c}">' + "".join(f"<td>{esc(r.get(k, ''))}</td>" for k in cols) + "</tr>")
    return f"<table><tr>{h}</tr>{''.join(out)}</table>"

def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))

def page(body, w=1280): return f"<!doctype html><meta charset='utf-8'><style>{CSS}</style><div class='wrap' style='width:{w}px'>{body}</div>"

def shot(body, name, w=1320): shot_html(page(body, w - 40), ANH / name, w, ".wrap")

def p_du_lieu():
    goc = rd(DL / "goc" / "xuat_may_cham_cong.csv")
    an = rd(DL / "an-danh" / "cham_cong.csv")
    mp = {r["ma_goc"].lstrip("0"): r["ma_an_danh"] for r in rd(KQ / "bang-ma-hoa.csv")}
    # lấy cùng một nhân viên, hai ngày để thấy khác biệt định dạng máy A và B
    sel = [r for r in goc if r["Mã NV"] in ("01006",)][:4] + [r for r in goc if r["Mã máy"] == "MAY-B1"][:4] + [r for r in goc if r["Mã NV"] == "09001" or r["Thời gian"] in ("", "31/09/2026 08:00")]
    an_sel = [dict(ma_may=r["Mã máy"], ma_nv=mp.get(r["Mã NV"].lstrip("0"), "?"), thoi_gian=r["Thời gian"]) for r in sel]
    left = table(sel, ["Mã máy", "Mã NV", "Họ tên", "Phòng ban", "Thời gian"], lambda r: "bad" if r["Thời gian"] in ("", "31/09/2026 08:00") or r["Mã NV"] == "09001" else "")
    right = table(an_sel, ["ma_may", "ma_nv", "thoi_gian"], lambda r: "bad" if r["thoi_gian"] in ("", "31/09/2026 08:00") else "ok")
    body = ("<h3>Trước và sau khi ẩn danh (dữ liệu GIẢ để học)</h3><div class='two'><div class='box'><b>Bản xuất từ máy (ở lại máy bạn)</b><br><br>" + left +
            "</div><div class='box'><b>Bản đưa cho agent</b><br><br>" + right + "</div></div>"
            "<p class='cap'>Dòng nền đỏ: mã thẻ lạ, giờ trống, ngày 31/09 không tồn tại. Máy A ghi 2026-09-01 08:00:31, máy B ghi 03/09/2026 08:01 (không có giây). Dữ liệu giả, sinh bằng sinh_du_lieu.py.</p>")
    shot(body, "01-du-lieu-truoc-sau-an-danh.png", 1400)
    # ảnh lịch ca + đơn phép
    ln = rd(DL / "an-danh" / "lich_ca_xoay.csv")[:6]; ph = rd(DL / "an-danh" / "nghi_phep.csv"); nvl = rd(DL / "an-danh" / "nhan_vien.csv")[:8]
    body = ("<h3>Ba tệp đi kèm bảng quẹt (đã ẩn danh, dữ liệu giả)</h3><div class='two'><div class='box'><b>nhan_vien.csv</b><br><br>" + table(nvl, ["ma_nv", "chi_nhanh", "loai_ca"]) +
            "</div><div class='box'><b>lich_ca_xoay.csv</b><br><br>" + table(ln, ["ma_nv", "ngay", "ca"]) +
            "</div><div class='box'><b>nghi_phep.csv</b><br><br>" + table(ph[:6], ["ma_nv", "tu_ngay", "den_ngay", "loai"]) + "</div></div>"
            "<p class='cap'>Cột Ghi chú của đơn nghỉ (có thể chứa chuyện sức khỏe, gia đình) đã bị bỏ khi ẩn danh.</p>")
    shot(body, "02-tep-di-kem.png", 1400)

def p_prompt():
    txt = (KQ / "prompt-giao-viec.txt").read_text(encoding="utf-8")
    body = ("<h3>Prompt giao việc (nguyên văn, không sửa sau khi thấy kết quả)</h3><div class='box' style='white-space:pre-wrap;font-family:Consolas,monospace;font-size:13px;line-height:1.45'>" +
            esc(txt) + "</div>")
    shot(body, "03-prompt-giao-viec.png", 1320)

def term(transcript, out, title, blocks=None, maxlines=14, width=1280, prompt=False):
    t = json.loads(Path(transcript).read_text(encoding="utf-8"))
    bl = t["blocks"][blocks[0]:blocks[1]] if blocks else t["blocks"]
    h = render_blocks(bl, title, t["prompt"], maxlines, width, prompt)
    shot_html(h, ANH / out, width + 40, ".win")


def p_agent():
    L = LOGS
    term(L / "claude-lan1.json", "04-claude-dang-lam.png", "claude · thư mục làm việc (lần 1)", (0, 7), maxlines=9)
    term(L / "claude-lan1.json", "05-claude-tu-kiem.png", "claude · tự kiểm và sửa (lần 1)", (7, 15), maxlines=7)
    term(L / "claude-lan1.json", "06-claude-ket-qua-cuoi.png", "claude · tóm tắt cuối (lần 1)", (18, 19), maxlines=40)
    term(L / "agy-lan2.json", "07-agy-dang-lam.png", "agy · thăm dò dữ liệu (lần 2)", (0, 9), maxlines=8)
    term(L / "agy-lan2.json", "08-agy-ra-ngoai-thu-muc.png", "agy · hai lệnh ngoài thư mục làm việc (lần 2)", (35, 37), maxlines=22)
    term(L / "agy-lan2.json", "09-agy-ket-qua-cuoi.png", "agy · tóm tắt cuối (lần 2)", (64, 65), maxlines=60)

def p_ketqua():
    rows = rd(KQ / "claude-lan1" / "bang_cong_ngay.csv")
    sel = [r for r in rows if r["ma_nv"] == "NV-007" and r["ngay"] in ("2026-09-01", "2026-09-02", "2026-09-03", "2026-09-04", "2026-09-05")]
    sel += [r for r in rows if r["ma_nv"] == "NV-006" and r["ngay"] in ("2026-09-23",)]
    sel += [r for r in rows if r["ma_nv"] == "NV-013" and r["ngay"] in ("2026-09-06", "2026-09-26")]
    bt = rd(KQ / "claude-lan1" / "bat_thuong.csv")
    pick = []
    for loai in ("THIEU_KHONG_RO", "NGHI_QUET_HO", "OT_THANG_VUOT", "DI_TRE"):
        pick += [r for r in bt if r["loai"] == loai][:1]
    cls = lambda r: {"OK": "ok", "CHO_XAC_NHAN": "bad", "PHEP": "warn", "NGHI": ""}.get(r["trang_thai"], "")
    t1 = table(sel, ["ma_nv", "ngay", "loai_ngay", "gio_vao", "gio_ra", "gio_cong", "phut_tre", "phut_ve_som", "ot_phut", "trang_thai"], cls)
    t2 = "".join(f"<tr><td>{esc(r['ma_nv'])}</td><td>{esc(r['ngay'])}</td><td>{esc(r['loai'])}</td><td>{esc(r['can_nguoi_quyet'])}</td>"
                 f"<td style='font-family:Segoe UI;white-space:normal'>{esc(r['chi_tiet'])}<br><i>{esc(r['giai_thich'])}</i></td></tr>" for r in pick)
    body = ("<h3>Đầu ra của Claude Code, lần 1: bảng công ngày (trích) và danh sách bất thường (trích)</h3><div class='box'>" + t1 +
            "<p class='cap'>Nền xanh: ngày OK đã tính giờ. Nền đỏ: CHO_XAC_NHAN, giờ công để trống (không đoán). Nền vàng: PHEP.</p></div><br>"
            "<div class='box'><table><tr><th>ma_nv</th><th>ngay</th><th>loai</th><th>can_nguoi_quyet</th><th>chi_tiet (code tính) và giai_thich (mô hình viết)</th></tr>" + t2 + "</table>"
            "<p class='cap'>Trích từ ket-qua/claude-lan1/. Dữ liệu giả, mã ẩn danh.</p></div>")
    shot(body, "10-ket-qua-bang-cong-bat-thuong.png", 1400)

def p_chamdiem():
    r = json.loads((KQ / "bao-cao-cham.json").read_text(encoding="utf-8"))
    names = {"claude-lan0-mat-log": "Claude Code, lần 0 (mất log)", "claude-lan1": "Claude Code, lần 1", "claude-rutgon": "Claude Code, quy định rút gọn",
             "agy-lan0-mat-log": "agy, lần 0 (mất log)", "agy-lan1-het-gio": "agy, lần 1 (hết 900 s, thiếu báo cáo)", "agy-lan2": "agy, lần 2", "agy-rutgon": "agy, quy định rút gọn"}
    rows = []
    for k, v in r.items():
        b, c, t = v["bat_thuong"], v["bang_cong_ngay"], v["tong_hop_nguoi"]
        rows.append(dict(lan=names.get(k, k), bt=f"{b['dung']}/{b['dap_an']}", bia=b["bia"], cq=b["can_nguoi_quyet_dung"], tt=c["trang_thai_dung"],
                         ok=c["ngay_OK_dung_het_cot"], ng=t["dung_het_cot"]))
    t1 = table(rows, ["lan", "bt", "bia", "cq", "tt", "ok", "ng"], lambda x: "ok" if x["tt"] == "750/750" and x["ng"] == "25/25" else "warn",
               ["Lần chạy", "Bất thường đúng", "Bịa", "can_nguoi_quyet đúng", "Trạng thái ngày đúng", "Ngày OK đúng hết cột", "Người đúng hết cột"])
    diff = []
    for k in ("agy-lan2", "agy-rutgon"):
        for x in r[k]["tong_hop_nguoi"]["vi_du_sai"][:4]:
            diff.append(dict(lan=names[k], ma=x["ma_nv"], cot=x["cot"], da=x["dap_an"], ag=x["agent"]))
    t2 = table(diff, ["lan", "ma", "cot", "da", "ag"], None, ["Lần chạy", "Mã NV", "Cột tổng hợp", "Đáp án", "Agent"])
    body = ("<h3>Chấm bằng đáp án (cham.py), ngày 2026-11-20, mỗi dòng một lần chạy (n nhỏ)</h3><div class='box'>" + t1 +
            "</div><br><div class='box'><b>Các ô tổng hợp theo người mà agent làm khác đáp án (trích)</b><br><br>" + t2 +
            "<p class='cap'>Nền vàng: có chỗ khác đáp án. Các khác biệt đều đến từ chỗ quy định chưa nói rõ (xem bài 2), không phải lỗi tính số học.</p></div>")
    shot(body, "11-cham-diem-cac-lan-chay.png", 1400)


def p_tukiem():
    import shutil, kiem_tra_dau_ra as k
    names = ["claude-lan0-mat-log", "claude-lan1", "claude-rutgon", "agy-lan0-mat-log", "agy-lan1-het-gio", "agy-lan2", "agy-rutgon"]
    M = ["1 đủ dòng", "2 trạng thái", "3 ngày chờ có lý do", "4 bất thường", "5 nhất quán", "6 tổng hợp khớp bảng ngày", "7 rò rỉ tên"]
    an, ten = DL / "an-danh", KQ / "bang-ma-hoa.csv"
    rows = []
    for n in names:
        loi = k.kiem_tra(KQ / n, an, ten)
        rows.append(dict(lan=n, **{m: ("ĐẠT" if not loi.get(m) else f"KHÔNG ĐẠT ({len(loi[m])})") for m in M}))
    mut = KQ / "_mut"; shutil.rmtree(mut, ignore_errors=True); shutil.copytree(KQ / "claude-lan1", mut)
    def rw(f, fn):
        r = rd(mut / f); c = list(r[0]); r = fn(r)
        with open(mut / f, "w", encoding="utf-8", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=c); w.writeheader(); w.writerows(r)
    rw("bang_cong_ngay.csv", lambda r: r[1:])
    rw("tong_hop_nguoi.csv", lambda r: [dict(r[0], tong_phut_tre="999")] + r[1:])
    rw("bat_thuong.csv", lambda r: [dict(r[0], giai_thich="")] + r[1:])
    loi = k.kiem_tra(mut, an, ten); shutil.rmtree(mut)
    rows.append(dict(lan="bản cố ý làm hỏng (từ claude-lan1)", **{m: ("ĐẠT" if not loi.get(m) else f"KHÔNG ĐẠT ({len(loi[m])})") for m in M}))
    t = table(rows, ["lan"] + M, lambda r: "bad" if any("KHÔNG" in str(v) for v in r.values()) else "ok", ["Bộ đầu ra"] + ["Mục " + m for m in M])
    shot("<h3>Tự kiểm không cần đáp án: kiem_tra_dau_ra.py</h3><div class='box'>" + t + "<p class='cap'>Bảy bộ đầu ra thật đều đạt 7/7, kể cả hai bộ có khác biệt cách hiểu quy định ở bài 2. Bản cố ý làm hỏng bị bắt ở các mục 1, 4, 6. Dữ liệu giả.</p></div>", "12-tu-kiem-dau-ra.png", 1500)

if __name__ == "__main__":
    {"du-lieu": p_du_lieu, "prompt": p_prompt, "agent": p_agent, "ketqua": p_ketqua, "chamdiem": p_chamdiem, "tukiem": p_tukiem}.get(sys.argv[1], lambda: None)()
