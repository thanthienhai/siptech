import csv
import os
import re
import sys

def resolve_path(filename):
    if os.path.exists(filename):
        return filename
    sub_path = os.path.join('dau-ra', filename)
    if os.path.exists(sub_path):
        return sub_path
    parent_path = os.path.join('..', filename)
    if os.path.exists(parent_path):
        return parent_path
    return filename

def main():
    danh_gia_file = resolve_path('danh-gia.csv')
    y_kien_file = resolve_path('y-kien.csv')
    nguy_cap_file = resolve_path('nguy-cap.csv')
    bao_cao_file = resolve_path('bao-cao.md')

    # Load danh-gia
    noi_dung_map = {}
    with open(danh_gia_file, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            noi_dung_map[row['ma'].strip()] = row['noi_dung']

    errors = []
    total_checked = 0

    # 1. Check y-kien.csv
    print("--- Kiem tra y-kien.csv ---")
    y_kien_count = 0
    with open(y_kien_file, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, start=2):
            ma = row['ma'].strip()
            trich_dan = row['trich_dan']
            total_checked += 1
            y_kien_count += 1
            if ma not in noi_dung_map:
                errors.append(f"[y-kien.csv L{i}] Ma {ma} khong ton tai trong danh-gia.csv")
            elif trich_dan not in noi_dung_map[ma]:
                errors.append(f"[y-kien.csv L{i}] Ma {ma}: trich_dan '{trich_dan}' KHONG co nguyen van trong noi_dung: '{noi_dung_map[ma]}'")
    print(f"Da kiem tra {y_kien_count} dong trong y-kien.csv")

    # 2. Check nguy-cap.csv
    print("\n--- Kiem tra nguy-cap.csv ---")
    nguy_cap_count = 0
    with open(nguy_cap_file, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, start=2):
            ma = row['ma'].strip()
            trich_dan = row['trich_dan']
            total_checked += 1
            nguy_cap_count += 1
            if ma not in noi_dung_map:
                errors.append(f"[nguy-cap.csv L{i}] Ma {ma} khong ton tai trong danh-gia.csv")
            elif trich_dan not in noi_dung_map[ma]:
                errors.append(f"[nguy-cap.csv L{i}] Ma {ma}: trich_dan '{trich_dan}' KHONG co nguyen van trong noi_dung: '{noi_dung_map[ma]}'")
    print(f"Da kiem tra {nguy_cap_count} dong trong nguy-cap.csv")

    # 3. Check bao-cao.md
    print("\n--- Kiem tra bao-cao.md ---")
    bao_cao_count = 0
    if os.path.exists(bao_cao_file):
        with open(bao_cao_file, mode='r', encoding='utf-8') as f:
            content = f.read()
        
        # Regex to find quotes pattern: > [mã] "trích nguyên văn"
        pattern = r'>\s*\[([A-Za-z0-9]+)\]\s*"([^"]+)"'
        matches = re.findall(pattern, content)
        for ma, quote in matches:
            total_checked += 1
            bao_cao_count += 1
            if ma not in noi_dung_map:
                errors.append(f"[bao-cao.md] Ma {ma} khong ton tai trong danh-gia.csv")
            elif quote not in noi_dung_map[ma]:
                errors.append(f"[bao-cao.md] Ma {ma}: bang chung '{quote}' KHONG co nguyen van trong noi_dung: '{noi_dung_map[ma]}'")
        print(f"Da kiem tra {bao_cao_count} trích dẫn bang chung trong bao-cao.md")
    else:
        print("Chua tim thay bao-cao.md de kiem tra.")

    print("\n=== KET QUA KIEM TRA TRICH DAN ===")
    print(f"Tong so trich dan da kiem tra: {total_checked}")
    if not errors:
        print("TAT CA TRICH DAN DEU CHINH XAC NGUYEN VAN 100%! (PASSED)")
        return 0
    else:
        print(f"PHAT HIEN {len(errors)} DONG KHONG HOP LE:")
        for err in errors:
            print(" -", err)
        return 1

if __name__ == '__main__':
    sys.exit(main())
