import pandas as pd
import numpy as np

# Load df_main and items_to_order from previous analysis
# Let's import or re-run
from run_full_analysis import df_main, items_to_order, NGAN_SACH

# Let's inspect priority ranking
# Priority criteria:
# 1. canh_bao == 'SAP_HET' > 'OK'
# 2. lop_abc: A > B > C
# 3. so_ngay_ton: ascending (fewer days of stock left -> higher priority)

priority_map_warn = {'SAP_HET': 1, 'OK': 2}
priority_map_abc = {'A': 1, 'B': 2, 'C': 3}

items = items_to_order.copy()
items['p_warn'] = items['canh_bao'].map(priority_map_warn)
items['p_abc'] = items['lop_abc'].map(priority_map_abc)

# Sort by p_warn, p_abc, so_ngay_ton
items = items.sort_values(by=['p_warn', 'p_abc', 'so_ngay_ton'], ascending=[True, True, True]).reset_index(drop=True)
items['rank'] = items.index + 1

print('Sorted items needing reorder:')
print(items[['rank', 'ma_hang', 'lop_abc', 'canh_bao', 'so_ngay_ton', 'sl_can', 'don_gia_von', 'thanh_tien_raw']].to_string())

# Let's check cumulative cost
items['cum_cost'] = items['thanh_tien_raw'].cumsum()
print('\nCumulative cost:')
print(items[['rank', 'ma_hang', 'lop_abc', 'canh_bao', 'so_ngay_ton', 'sl_can', 'thanh_tien_raw', 'cum_cost']].to_string())
