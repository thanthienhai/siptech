"""Kiểm đề xuất nhập có tuân ngân sách không và liệt kê mã bị cắt (không dùng agent, không dùng đáp án).

Dùng:  python -X utf8 kiem_ngan_sach.py <thu-muc-chua-de-xuat-nhap.csv> <ngan-sach-vnd>
Tính lại từ cột sl_de_xuat x don_gia_von (không tin cột thanh_tien), rồi in:
  - tổng tiền đề xuất, so với ngân sách
  - thanh_tien có khớp sl x đơn giá không, sl có là bội số quy_cach không
  - tổng tiền công thức cần khi chưa xét ngân sách (sl_can_chua_xet_ngan_sach x đơn giá)
  - các mã bị cắt (cần > đề xuất) và số tiền bị cắt
"""
import csv
import sys
from pathlib import Path


def so(x):
    return int(float(x)) if str(x).strip() else 0


def main():
    thu_muc, ngan_sach = Path(sys.argv[1]), int(sys.argv[2])
    with open(thu_muc / "de-xuat-nhap.csv", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    tong = tong_can = 0
    sai_tien, sai_boi = [], []
    cat = []
    for r in rows:
        sl, can, gia, qc = so(r["sl_de_xuat"]), so(r["sl_can_chua_xet_ngan_sach"]), so(r["don_gia_von"]), so(r["quy_cach"])
        tong += sl * gia
        tong_can += can * gia
        if so(r["thanh_tien"]) != sl * gia:
            sai_tien.append(r["ma_hang"])
        if qc and sl % qc:
            sai_boi.append(r["ma_hang"])
        if sl < can:
            cat.append((r["ma_hang"], can, sl, (can - sl) * gia))
    print(f"Ngan sach: {ngan_sach:,} | tong de xuat (tinh lai): {tong:,} | khong vuot: {tong <= ngan_sach}")
    print(f"Cong thuc can (chua xet ngan sach): {tong_can:,}")
    print(f"thanh_tien sai: {sai_tien or 'khong'} | khong la boi so quy cach: {sai_boi or 'khong'}")
    print(f"So ma duoc nhap: {sum(1 for r in rows if so(r['sl_de_xuat']) > 0)} | so ma bi cat: {len(cat)} | tien bi cat: {sum(c[3] for c in cat):,}")
    for ma, can, sl, tien in sorted(cat, key=lambda c: -c[3]):
        print(f"  cat {ma}: can {can}, de xuat {sl}, bi cat {tien:,}")


if __name__ == "__main__":
    main()
