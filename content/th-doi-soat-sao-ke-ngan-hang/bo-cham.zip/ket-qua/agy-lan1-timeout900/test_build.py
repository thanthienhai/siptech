import os, sys, json, csv, re, unicodedata
import pandas as pd
import openpyxl

def strip_accents(s):
    if not isinstance(s, str): return ''
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def parse_date_to_iso(val):
    if isinstance(val, pd.Timestamp):
        return val.strftime('%Y-%m-%d')
    s = str(val).strip()
    # Check DD/MM/YYYY or DD-MM-YYYY
    m = re.match(r'(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})', s)
    if m:
        d, mth, y = m.groups()
        return f"{int(y):04d}-{int(mth):02d}-{int(d):02d}"
    return s[:10]

# Let's test building the complete reconciliation
print("Testing helper functions...")
