# Báo cáo đối soát tháng 10/2026
- Sao kê 144 dòng (ghi có 125.248.650 đ, ghi nợ 73.416.000 đ); số dư cuối 91.832.650 đ, kiểm số dư khớp dòng tổng: ĐÚNG.
- Mức chắc chắn: 61 CAO, 72 TRUNG BINH, 11 CAN NGUOI QUYET (dòng chi/phí phân loại theo từ khóa nên ghi TRUNG BINH, không cần xử lý).
- Ghi có đã ghép đơn 102.180.000 đ; chưa ghép/cần người quyết 23.068.650 đ (trong đó COD gộp 9.420.000 đ, lãi ngân hàng 18.650 đ, còn lại 13.630.000 đ cần người quyết).
- Cần người quyết: 11 dòng ghi có (5 có đơn ứng viên: mã trong nội dung mâu thuẫn với tên/số tiền; 6 tiền không rõ nguồn). Chi tiết ở ngoai_le.csv.
- Chuyển thiếu 4 dòng (tổng thiếu 140.000 đ); chuyển thừa 4 dòng (thừa 320.000 đ); chuyển trùng 3 dòng (6.630.000 đ); nhiều đơn một lần chuyển 6 dòng.
- Hoàn tiền 3 dòng, trong đó 1 ca hoàn một phần (giữ lại một khoản).
- Đơn CK chưa có tiền và chưa hủy: 15 đơn, tổng 9.140.000 đ; 8 đơn đang giao (đặt cuối tháng), 5 đơn là ứng viên của dòng đang chờ người quyết.
- COD: 2 lô đối soát của hãng ghép khớp tổng với dãy đơn COD liên tiếp; còn 9 đơn COD đã giao (6.940.000 đ) chờ đối soát lô sau.
- Không chắc: (1) ghép lô COD chỉ dựa vào tổng tiền và thứ tự đơn, cần bảng kê hãng; (2) ca 'don 003 HOANG KIM VY' ghép theo mã+số tiền dù tên khác khách trên đơn;
  (3) hai khách trùng tên Trần Văn Bình (2 SĐT) ghép theo ngày đặt đơn; (4) 5 dòng sai mã đơn (nghiêng về đơn khớp tên+số tiền) tôi không tự chốt, theo đúng quy tắc.
- Quy ước: dòng CAN NGUOI QUYET ghi loai=khong_ro_nguon, ma_don là ứng viên, phan_bo để trống, chưa tính vào 'đã ghép'.
