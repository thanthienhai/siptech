#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gop.py - Gộp file doanh thu tháng của các chi nhánh thành một bảng chuẩn.

Cách chạy (từ thư mục chứa goc/ và hai file danh mục):
    python gop.py goc ra --thang 2026-10

Nguyên tắc:
  * Chỉ ĐỌC thư mục goc/ (mở file bằng bytes trong bộ nhớ, không bao giờ lưu lại).
  * Mọi con số trong kết quả (CSV và bao_cao.md) do script tính từ dữ liệu.
  * Gặp cấu trúc file không nhận ra thì dừng và báo lỗi rõ (mã thoát 2), không đoán thầm.
  * Không chắc (ngày mơ hồ không có căn cứ, ...) thì ghi CAN_NGUOI_QUYET và đưa vào viec_can_hoi.csv.
"""
import argparse
import calendar
import csv
import datetime as dt
import io
import re
import sys
import unicodedata
from collections import Counter, OrderedDict, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path

try:
    import openpyxl
except ImportError:  # pragma: no cover
    sys.exit("Thiếu thư viện openpyxl. Cài bằng: pip install openpyxl")


# ----------------------------------------------------------------------------
# Lỗi
# ----------------------------------------------------------------------------
class CauTrucLa(Exception):
    """File có cấu trúc mà script không nhận ra -> dừng, báo rõ."""


# ----------------------------------------------------------------------------
# Tiện ích chuỗi / số
# ----------------------------------------------------------------------------
def bo_dau(s):
    s = str(s).replace("đ", "d").replace("Đ", "D")
    s = unicodedata.normalize("NFD", s)
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def chuan_hoa(s):
    """chữ thường, bỏ dấu, ký tự lạ -> khoảng trắng, gộp khoảng trắng."""
    s = bo_dau(s).lower()
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def la_so_thuc(x):
    return isinstance(x, (int, float, Decimal)) and not isinstance(x, bool)


def doc_so(x):
    """Đọc số từ ô Excel (số thật hoặc chữ như '1.250.000đ', '68,000'). Trả Decimal.
    Ném ValueError nếu không đọc chắc chắn được."""
    if x is None:
        raise ValueError("ô trống")
    if isinstance(x, bool):
        raise ValueError("kiểu logic")
    if isinstance(x, (int, Decimal)):
        return Decimal(x)
    if isinstance(x, float):
        return Decimal(repr(x))
    s = str(x).strip().replace(" ", " ")
    am = False
    if s.startswith("(") and s.endswith(")"):
        am, s = True, s[1:-1].strip()
    s = re.sub(r"(?i)\s*(₫|đ|vnđ|vnd|d)\s*$", "", s).strip()
    if s.startswith("-"):
        am, s = (not am), s[1:].strip()
    elif s.endswith("-"):
        am, s = (not am), s[:-1].strip()
    s = s.replace(" ", "")
    if re.fullmatch(r"\d+", s):
        v = Decimal(s)
    elif re.fullmatch(r"\d{1,3}(\.\d{3})+", s):
        v = Decimal(s.replace(".", ""))
    elif re.fullmatch(r"\d{1,3}(,\d{3})+", s):
        v = Decimal(s.replace(",", ""))
    elif re.fullmatch(r"\d{1,3}(\.\d{3})+,\d+", s):
        v = Decimal(s.replace(".", "").replace(",", "."))
    elif re.fullmatch(r"\d{1,3}(,\d{3})+\.\d+", s):
        v = Decimal(s.replace(",", ""))
    else:
        raise ValueError("không đọc chắc chắn được số '%s'" % x)
    return -v if am else v


def so_ra(v):
    """Số -> chuỗi CSV, không dấu ngăn cách, không làm tròn."""
    if v is None:
        return ""
    v = Decimal(v)
    if v == v.to_integral_value():
        return str(int(v))
    return format(v.normalize(), "f")


def so_hien_thi(v):
    """Số -> chuỗi dễ đọc trong bao_cao.md (dấu chấm ngăn nghìn)."""
    v = Decimal(v)
    if v == v.to_integral_value():
        return "{:,}".format(int(v)).replace(",", ".")
    return format(v.normalize(), "f")


def ngay_ra(d):
    return d.isoformat() if d else ""


# ----------------------------------------------------------------------------
# Danh mục
# ----------------------------------------------------------------------------
def doc_csv(path):
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


# Quy tắc nhận diện tên sản phẩm (trên chuỗi đã chuẩn hóa: bỏ dấu, chữ thường).
# Mỗi sản phẩm cần THỎA TẤT CẢ các mẫu (gồm cả quy cách, để "Cà phê 250g" không bị nhận nhầm).
QUY_TAC_SAN_PHAM = OrderedDict([
    ("SP01", [r"\bst25\b", r"\b5 ?kg\b"]),
    ("SP02", [r"\bmam\b", r"\b500 ?ml\b"]),
    ("SP03", [r"\b(ca phe|cafe|cf)\b", r"\brang xay\b", r"\b500 ?(g|gr)\b"]),
    ("SP04", [r"\btra sen\b", r"\b200 ?g\b"]),
    ("SP05", [r"\bmat ong\b", r"\b250 ?ml\b"]),
    ("SP06", [r"\bdieu\b", r"\b500 ?g\b"]),
    ("SP07", [r"\b(banh trang|b trang)\b", r"\b(muoi tom|mt)\b", r"\b250 ?g\b"]),
    ("SP08", [r"\bdau dua\b", r"\b250 ?ml\b"]),
])
CHUA_XAC_DINH = "CHUA_XAC_DINH"


def khop_san_pham(ten_goc, danh_muc):
    """Trả (ma, ghi_chu_loi). ma = CHUA_XAC_DINH nếu không có trong danh mục / mơ hồ."""
    n = chuan_hoa(ten_goc)
    for ma, ten in danh_muc.items():            # trùng tên chuẩn
        if chuan_hoa(ten) == n:
            return ma, None
    kq = [ma for ma, mau in QUY_TAC_SAN_PHAM.items()
          if ma in danh_muc and all(re.search(m, n) for m in mau)]
    if len(kq) == 1:
        return kq[0], None
    if len(kq) > 1:
        return CHUA_XAC_DINH, "tên khớp nhiều sản phẩm (%s)" % ", ".join(kq)
    return CHUA_XAC_DINH, "không có trong danh mục"


def kiem_tra_quy_tac(danh_muc):
    for ma, mau in QUY_TAC_SAN_PHAM.items():
        if ma in danh_muc:
            n = chuan_hoa(danh_muc[ma])
            if not all(re.search(m, n) for m in mau):
                raise CauTrucLa("Quy tắc nhận diện sản phẩm %s trong gop.py không khớp tên chuẩn '%s' "
                                "trong danh_muc_san_pham.csv. Hãy cập nhật QUY_TAC_SAN_PHAM." % (ma, danh_muc[ma]))


# ----------------------------------------------------------------------------
# Đọc file Excel (chỉ đọc)
# ----------------------------------------------------------------------------
VAI_TRO = OrderedDict([
    ("ngay", [r"ngay", r"date", r"ngay ban", r"ngay gd", r"ngay giao dich"]),
    ("so_ct", [r"so hd", r"so hoa don", r"invoice", r"so phieu", r"ma don", r"chung tu", r"so chung tu", r"ma hd"]),
    ("san_pham", [r"ten hang", r"product", r"ten sp", r"san pham", r"mat hang", r"hang hoa"]),
    ("so_luong", [r"sl", r"qty", r"so luong"]),
    ("don_gia", [r"don gia( vnd)?", r"unit price( vnd)?", r"gia", r"gia ban"]),
    ("thanh_tien", [r"thanh tien( vnd)?", r"amount", r"tien", r"doanh thu"]),
])
# Cột có mặt trong file nhưng không dùng để tính doanh thu: biết nghĩa, chủ động bỏ qua.
# (chuẩn hóa như VAI_TRO). Cột lạ khác vẫn báo lỗi để người xem.
COT_BO_QUA = [r"nhan vien"]   # VT: mã nhân viên bán (NV01..NV04), không ảnh hưởng số tiền
NHAN_TONG_TUAN = re.compile(r"^cong tuan\s*\d*$")
NHAN_TONG = re.compile(r"^(tong cong|tong thang|tong ket|tong|cong|total|grand total)$")
GHI_CHU_CHU_KY = re.compile(r"(nguoi lap|prepared by|ngay lap|ke toan lap)")
GHI_CHU_QUAN_TRONG = re.compile(r"\b(tra lai|hang tra|nhap tre|thang \d+|vat|chua tru|chua gom|chua tinh|thieu|sai|loi)\b")


def mo_file(path):
    """Mở xlsx chỉ-đọc: đọc bytes vào bộ nhớ, không giữ handle tới file gốc, không lưu lại."""
    data = Path(path).read_bytes()
    wb_ct = openpyxl.load_workbook(io.BytesIO(data), data_only=False)
    wb_gt = openpyxl.load_workbook(io.BytesIO(data), data_only=True)
    return wb_ct, wb_gt


def tinh_cong_thuc(ws_ct, ws_gt, o):
    """Giá trị ô tổng: lấy giá trị đã lưu (cache) của Excel; nếu thiếu thì tự tính công thức đơn giản
    (SUM(range), cộng/trừ các ô). Không tính được -> báo lỗi."""
    v = ws_gt[o].value
    cong_thuc = ws_ct[o].value
    if not (isinstance(cong_thuc, str) and cong_thuc.startswith("=")):
        return v, None
    if v is not None:
        return v, cong_thuc
    expr = cong_thuc[1:]

    def tong_vung(m):
        t = Decimal(0)
        for row in ws_gt[m.group(1) + ":" + m.group(2)]:
            for c in row:
                if c.value is not None:
                    t += doc_so(c.value)
        return "(" + str(t) + ")"

    expr = re.sub(r"(?i)SUM\(([A-Z]+\d+):([A-Z]+\d+)\)", tong_vung, expr)

    def o_don(m):
        val = ws_gt[m.group(0)].value
        if val is None:
            raise CauTrucLa("Công thức %s ở ô %s tham chiếu ô trống %s" % (cong_thuc, o, m.group(0)))
        return "(" + str(doc_so(val)) + ")"

    expr = re.sub(r"\b[A-Z]{1,3}\d+\b", o_don, expr)
    if not re.fullmatch(r"[\d\s+\-().]+", expr):
        raise CauTrucLa("Không tính được công thức %s ở ô %s" % (cong_thuc, o))
    return Decimal(str(eval(expr, {"__builtins__": {}}, {}))), cong_thuc  # chỉ chứa số và + - ( )


def nhan_dien_chi_nhanh(ten_file, van_ban_tren, chi_nhanh):
    """chi_nhanh: dict ma -> ten. Tìm theo tên chi nhánh (bỏ dấu, bỏ khoảng trắng) trong tên file + phần tiêu đề
    phía trên bảng; không thấy thì tìm mã chi nhánh như một từ riêng trong tên file."""
    nguon = chuan_hoa(ten_file + " " + " ".join(van_ban_tren)).replace(" ", "")
    tim = [ma for ma, ten in chi_nhanh.items() if chuan_hoa(ten).replace(" ", "") in nguon]
    if len(tim) == 0:
        tu = set(chuan_hoa(ten_file).split())
        tim = [ma for ma in chi_nhanh if ma.lower() in tu]
    if len(tim) != 1:
        raise CauTrucLa("Không xác định được chi nhánh của file '%s' (khớp: %s). Kiểm tra tên file / tiêu đề."
                        % (ten_file, tim or "không có"))
    return tim[0]


def doc_sheet(ws_ct, ws_gt, ten_file, chi_nhanh):
    """Đọc một sheet -> dict kết quả thô. Báo CauTrucLa nếu không nhận ra cấu trúc."""
    max_row, max_col = ws_gt.max_row, ws_gt.max_column
    # --- tìm hàng tiêu đề
    hang_tieu_de, cot = None, None
    for r in range(1, min(max_row, 40) + 1):
        gan = {}
        for c in range(1, max_col + 1):
            v = ws_gt.cell(r, c).value
            if isinstance(v, str):
                n = chuan_hoa(v)
                for vt, mau in VAI_TRO.items():
                    if any(re.fullmatch(m, n) for m in mau):
                        gan.setdefault(vt, []).append(c)
        if len(gan) >= 5:
            hang_tieu_de, cot = r, gan
            break
    if hang_tieu_de is None:
        raise CauTrucLa("[%s] Không tìm thấy hàng tiêu đề (cần đủ các cột: ngày, số chứng từ, tên hàng, SL, đơn giá, thành tiền)." % ten_file)
    thieu = [vt for vt in VAI_TRO if vt not in cot]
    trung = [vt for vt, cs in cot.items() if len(cs) > 1]
    if thieu or trung:
        raise CauTrucLa("[%s] Hàng tiêu đề (dòng %d) thiếu cột %s hoặc có cột bị lặp %s."
                        % (ten_file, hang_tieu_de, thieu, trung))
    cot = {vt: cs[0] for vt, cs in cot.items()}
    cot_dung = set(cot.values())
    for c in range(1, max_col + 1):
        v = ws_gt.cell(hang_tieu_de, c).value
        if v not in (None, "") and c not in cot_dung:
            if isinstance(v, str) and any(re.fullmatch(m, chuan_hoa(v)) for m in COT_BO_QUA):
                continue
            raise CauTrucLa("[%s] Cột tiêu đề lạ '%s' (cột %d) mà script chưa biết là gì." % (ten_file, v, c))

    van_ban_tren = [str(ws_gt.cell(r, c).value) for r in range(1, hang_tieu_de)
                    for c in range(1, max_col + 1) if isinstance(ws_gt.cell(r, c).value, str)]
    ma_cn = nhan_dien_chi_nhanh(ten_file, van_ban_tren, chi_nhanh)

    # --- ô gộp ở cột ngày: điền giá trị ô trên-trái cho cả vùng
    gop_ngay = {}
    for rg in ws_ct.merged_cells.ranges:
        if rg.min_row > hang_tieu_de and rg.min_col <= cot["ngay"] <= rg.max_col:
            v = ws_gt.cell(rg.min_row, rg.min_col).value
            for r in range(rg.min_row, rg.max_row + 1):
                gop_ngay[r] = (v, rg.min_row)

    dong_du_lieu, tong_tuan, tong_ghi, ghi_chu = [], [], [], []
    for r in range(hang_tieu_de + 1, max_row + 1):
        gia = [ws_gt.cell(r, c).value for c in range(1, max_col + 1)]
        if all(v is None or (isinstance(v, str) and not v.strip()) for v in gia):
            continue
        nhan = None
        for v in gia:
            if isinstance(v, str):
                n = chuan_hoa(v)
                if NHAN_TONG_TUAN.fullmatch(n):
                    nhan = ("tuan", v)
                elif NHAN_TONG.fullmatch(n):
                    nhan = ("tong", v)
        if nhan:
            o_tien = ws_gt.cell(r, cot["thanh_tien"]).coordinate
            val, cong_thuc = tinh_cong_thuc(ws_ct, ws_gt, o_tien)
            try:
                gia_tri = doc_so(val)
            except ValueError:
                raise CauTrucLa("[%s] Dòng tổng '%s' (dòng %d) không có số ở cột thành tiền." % (ten_file, nhan[1], r))
            muc = {"dong": r, "nhan": nhan[1], "gia_tri": gia_tri, "o": o_tien, "cong_thuc": cong_thuc}
            if nhan[0] == "tuan":
                try:
                    muc["sl"] = doc_so(ws_gt.cell(r, cot["so_luong"]).value)
                except ValueError:
                    muc["sl"] = None
                tong_tuan.append(muc)
            else:
                tong_ghi.append(muc)
            continue
        so_ct = ws_gt.cell(r, cot["so_ct"]).value
        so_ct = so_ct.strip() if isinstance(so_ct, str) else so_ct
        co_so = any(la_so_thuc(v) for v in gia)
        if so_ct not in (None, "") or ws_gt.cell(r, cot["san_pham"]).value not in (None, "") and co_so \
                or any(ws_gt.cell(r, cot[k]).value is not None for k in ("so_luong", "don_gia", "thanh_tien")):
            ng = ws_gt.cell(r, cot["ngay"]).value
            ghi_ngay = None
            if ng is None and r in gop_ngay:
                ng = gop_ngay[r][0]
                ghi_ngay = "ngày lấy từ ô gộp A%d" % gop_ngay[r][1]
            dong_du_lieu.append({
                "dong": r,
                "ngay_raw": ng,
                "ghi_ngay": ghi_ngay,
                "so_ct": str(so_ct) if so_ct not in (None, "") else "",
                "san_pham_raw": ws_gt.cell(r, cot["san_pham"]).value,
                "sl_raw": ws_gt.cell(r, cot["so_luong"]).value,
                "dg_raw": ws_gt.cell(r, cot["don_gia"]).value,
                "tt_raw": ws_gt.cell(r, cot["thanh_tien"]).value,
            })
        else:
            chu = [str(v).strip() for v in gia if isinstance(v, str) and v.strip()]
            if len(chu) == 0:
                raise CauTrucLa("[%s] Dòng %d có nội dung nhưng không phân loại được: %s" % (ten_file, r, gia))
            ghi_chu.append({"dong": r, "noi_dung": " ".join(chu)})
    if not dong_du_lieu:
        raise CauTrucLa("[%s] Không có dòng dữ liệu nào dưới hàng tiêu đề." % ten_file)
    if len(tong_ghi) != 1:
        raise CauTrucLa("[%s] Cần đúng 1 dòng tổng cuối bảng, tìm thấy %d: %s"
                        % (ten_file, len(tong_ghi), [t["nhan"] for t in tong_ghi]))
    return {"file": ten_file, "chi_nhanh": ma_cn, "hang_tieu_de": hang_tieu_de, "dong": dong_du_lieu,
            "tong_tuan": tong_tuan, "tong_ghi": tong_ghi[0], "ghi_chu": ghi_chu}


# ----------------------------------------------------------------------------
# Ngày tháng
# ----------------------------------------------------------------------------
RE_NGAY = re.compile(r"^\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{2}|\d{4})\s*$")
RE_NGAY_ISO = re.compile(r"^\s*(\d{4})\s*[/\-.]\s*(\d{1,2})\s*[/\-.]\s*(\d{1,2})\s*$")


def tao_ngay(y, m, d):
    try:
        return dt.date(y, m, d)
    except ValueError:
        return None


def phan_tich_ngay(raw):
    """Trả dict: loai ('text'|'datetime'|'iso'|'trong'|'loi'), ung_vien {nhan: date}, a, b."""
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return {"loai": "trong", "ung_vien": {}}
    if isinstance(raw, dt.datetime):
        d = raw.date()
        uv = {"ghi": d}
        if d.day <= 12 and d.day != d.month:
            dao = tao_ngay(d.year, d.day, d.month)
            if dao:
                uv["dao"] = dao
        return {"loai": "datetime", "ung_vien": uv}
    if isinstance(raw, dt.date):
        return phan_tich_ngay(dt.datetime(raw.year, raw.month, raw.day))
    if isinstance(raw, str):
        m = RE_NGAY_ISO.match(raw)
        if m:
            d = tao_ngay(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return {"loai": "iso", "ung_vien": {"ghi": d}} if d else {"loai": "loi", "ung_vien": {}}
        m = RE_NGAY.match(raw)
        if m:
            a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            y = y + 2000 if y < 100 else y
            uv = {}
            d1 = tao_ngay(y, b, a)   # ngày/tháng
            d2 = tao_ngay(y, a, b)   # tháng/ngày
            if d1:
                uv["dmy"] = d1
            if d2 and d2 != d1:
                uv["mdy"] = d2
            return {"loai": "text", "ung_vien": uv, "a": a, "b": b, "dmy_ok": d1 is not None, "mdy_ok": d2 is not None}
    return {"loai": "loi", "ung_vien": {}}


def trong_ky(d, ky):
    return d is not None and (d.year, d.month) == ky


def doc_ngay_mot_chieu(d):
    return d.isoformat()


def giai_quyet_ngay(file_rows, ky):
    """Xác định ngày cho từng dòng của một file. Ghi vào row: ngay (date|None), tt_ngay
    ('OK'|'SUY_RA'|'CAN_NGUOI_QUYET'|'NGOAI_KY'), ghi_chu_ngay, hai_cach (mô tả khi mơ hồ)."""
    pt = [phan_tich_ngay(r["ngay_raw"]) for r in file_rows]

    # quy ước dd/mm hay mm/dd của file, suy từ các ô chỉ đọc được 1 cách
    # (ô có ngày = tháng như 10/10 đọc cách nào cũng như nhau nên không làm bằng chứng)
    chi_dmy = sum(1 for p in pt if p["loai"] == "text" and p["dmy_ok"] and not p["mdy_ok"])
    chi_mdy = sum(1 for p in pt if p["loai"] == "text" and p["mdy_ok"] and not p["dmy_ok"])
    quy_uoc = None
    if chi_dmy > 0 and chi_mdy == 0:
        quy_uoc = "dmy"
    elif chi_mdy > 0 and chi_dmy == 0:
        quy_uoc = "mdy"

    def la_chac(p):
        """Ngày xác định chắc chắn chỉ bằng một cách đọc?"""
        if p["loai"] in ("iso",):
            return p["ung_vien"]["ghi"]
        if p["loai"] == "text" and len(p["ung_vien"]) == 1:
            return list(p["ung_vien"].values())[0]
        if p["loai"] == "text" and len(p["ung_vien"]) == 0:
            return None
        if p["loai"] == "datetime":
            uv = p["ung_vien"]
            if trong_ky(uv["ghi"], ky):
                return uv["ghi"]
            if "dao" not in uv or not trong_ky(uv["dao"], ky):
                return uv["ghi"]          # ngoài kỳ chắc chắn (đảo cũng không vào kỳ)
        return None

    chac = [la_chac(p) for p in pt]
    chac_trong_ky = [(i, d) for i, d in enumerate(chac) if d is not None and trong_ky(d, ky)]
    sap_xep = all(chac_trong_ky[i][1] <= chac_trong_ky[i + 1][1] for i in range(len(chac_trong_ky) - 1)) \
        and len(chac_trong_ky) >= 10

    def hang_xom(i):
        truoc = next(((j, chac[j]) for j in range(i - 1, -1, -1) if chac[j] is not None and trong_ky(chac[j], ky)), None)
        sau = next(((j, chac[j]) for j in range(i + 1, len(pt)) if chac[j] is not None and trong_ky(chac[j], ky)), None)
        return truoc, sau

    def theo_thu_tu(i, ung_vien):
        """ung_vien: dict nhãn->date. Trả (nhãn, ngày, mô tả căn cứ) nếu thứ tự dòng chỉ ra đúng 1 cách đọc."""
        if not sap_xep:
            return None
        truoc, sau = hang_xom(i)
        if not truoc or not sau:
            return None
        hop = [(k, d) for k, d in ung_vien.items() if trong_ky(d, ky) and truoc[1] <= d <= sau[1]]
        if len(hop) != 1:
            return None
        k, d = hop[0]
        t, s = file_rows[truoc[0]], file_rows[sau[0]]
        return k, d, ("file sắp theo thứ tự ngày; dòng trước (%s) là %s và dòng sau (%s) là %s nên chỉ cách đọc %s hợp lý"
                      % (t["so_ct"], truoc[1].isoformat(), s["so_ct"], sau[1].isoformat(), d.isoformat()))

    for i, (r, p) in enumerate(zip(file_rows, pt)):
        r.update(ngay=None, tt_ngay="OK", ghi_chu_ngay=[], hai_cach=None, ngay_suy_ra_kieu=None)
        if r["ghi_ngay"]:
            r["ghi_chu_ngay"].append(r["ghi_ngay"])
        if p["loai"] == "trong":
            r.update(tt_ngay="CAN_NGUOI_QUYET", hai_cach="ô ngày trống")
            continue
        if p["loai"] == "loi" or (p["loai"] == "text" and not p["ung_vien"]):
            r.update(tt_ngay="CAN_NGUOI_QUYET", hai_cach="không đọc được ô ngày '%s'" % (r["ngay_raw"],))
            continue
        d = chac[i]
        if d is not None:
            r["ngay"] = d
            if not trong_ky(d, ky):
                r["tt_ngay"] = "NGOAI_KY"
            continue
        uv = p["ung_vien"]
        if p["loai"] == "text":
            raw = str(r["ngay_raw"]).strip()
            mo_ta = " hoặc ".join("%s (%s)" % (d2.isoformat(), "ngày/tháng" if k == "dmy" else "tháng/ngày")
                                  for k, d2 in uv.items())
            r["hai_cach"] = "ô '%s' đọc được 2 cách: %s" % (raw, mo_ta)
            if quy_uoc:
                chon, kia = uv[quy_uoc], uv["mdy" if quy_uoc == "dmy" else "dmy"]
                ten = "dd/mm" if quy_uoc == "dmy" else "mm/dd"
                can_cu = ("file dùng %s: %d ô chỉ đọc được là ngày/tháng và %d ô chỉ đọc được là tháng/ngày"
                          % (ten, chi_dmy, chi_mdy))
                if trong_ky(chon, ky) and not trong_ky(kia, ky):
                    r.update(ngay=chon, tt_ngay="SUY_RA", ngay_suy_ra_kieu=quy_uoc)
                    r["ghi_chu_ngay"].append("Ngày chữ '%s' đọc được 2 cách (%s / %s); chọn %s vì %s và cách đọc kia nằm ngoài kỳ"
                                             % (raw, uv.get("dmy", "-"), uv.get("mdy", "-"), chon.isoformat(), can_cu))
                    continue
                # quy ước của file dẫn tới ngày ngoài kỳ nhưng cách đọc kia vào kỳ -> mâu thuẫn
                tt = theo_thu_tu(i, uv)
                if tt:
                    k, dd, cc = tt
                    r.update(ngay=dd, tt_ngay="SUY_RA", ngay_suy_ra_kieu=k)
                    r["ghi_chu_ngay"].append("Ngày chữ '%s' đọc được 2 cách; chọn %s vì %s" % (raw, dd.isoformat(), cc))
                    continue
                r.update(tt_ngay="CAN_NGUOI_QUYET")
                r["hai_cach"] += "; theo quy ước của file (%s) ra %s nhưng cách còn lại %s nằm trong kỳ, không có căn cứ chắc chắn để chọn" % (
                    ten, chon.isoformat(), kia.isoformat())
                continue
            tt = theo_thu_tu(i, uv)
            if tt:
                k, dd, cc = tt
                r.update(ngay=dd, tt_ngay="SUY_RA", ngay_suy_ra_kieu=k)
                r["ghi_chu_ngay"].append("Ngày chữ '%s' đọc được 2 cách; chọn %s vì %s" % (raw, dd.isoformat(), cc))
                continue
            r.update(tt_ngay="CAN_NGUOI_QUYET")
            r["hai_cach"] += "; file không có quy ước chắc chắn và không có căn cứ thứ tự dòng"
            continue
        # datetime ngoài kỳ nhưng bản đảo ngày/tháng nằm trong kỳ
        ghi, dao = uv["ghi"], uv["dao"]
        r["hai_cach"] = "ô ngày lưu %s (ngoài kỳ); nếu ngày/tháng bị nhập đảo thì là %s (trong kỳ)" % (ghi.isoformat(), dao.isoformat())
        tt = theo_thu_tu(i, {"ghi": ghi, "dao": dao})
        if tt and tt[0] == "dao":
            r.update(ngay=dao, tt_ngay="SUY_RA", ngay_suy_ra_kieu="dao")
            r["ghi_chu_ngay"].append("Ô ngày lưu %s (ngoài kỳ), đảo ngày/tháng thành %s vì %s" % (ghi.isoformat(), dao.isoformat(), tt[2]))
            r["can_cu_dao"] = tt[2]
        else:
            r.update(tt_ngay="CAN_NGUOI_QUYET")
            r["hai_cach"] += "; không có căn cứ chắc chắn để chọn"
    return {"quy_uoc": quy_uoc, "chi_dmy": chi_dmy, "chi_mdy": chi_mdy, "sap_xep": sap_xep}


# ----------------------------------------------------------------------------
# Xử lý một file chi nhánh -> các dòng chuẩn + việc cần hỏi
# ----------------------------------------------------------------------------
def xu_ly_file(kq, danh_muc_sp, ky):
    ma_cn, tf = kq["chi_nhanh"], kq["file"]
    dong = kq["dong"]
    thongtin_ngay = giai_quyet_ngay(dong, ky)
    rows, hoi = [], []

    def them_hoi(loai, mo_ta, so_ct="", dong_nguon="", so_tien=None, cau_hoi=""):
        hoi.append({"chi_nhanh": ma_cn, "loai": loai, "mo_ta": mo_ta, "so_chung_tu": so_ct,
                    "dong_nguon": dong_nguon, "so_tien_lien_quan": so_tien, "cau_hoi": cau_hoi})

    da_thay = {}
    for d in dong:
        r = {"chi_nhanh": ma_cn, "ngay": d["ngay"], "so_chung_tu": d["so_ct"], "file_nguon": tf, "dong_nguon": d["dong"],
             "ghi_chu": list(d["ghi_chu_ngay"]), "ghi_chu_ngay": list(d["ghi_chu_ngay"]), "loai_loai": None, "sl": None, "dg": None, "tt": None,
             "ma_san_pham": CHUA_XAC_DINH, "ten_goc": d["san_pham_raw"], "tt_ngay": d["tt_ngay"], "hai_cach": d["hai_cach"],
             "kieu_suy": d["ngay_suy_ra_kieu"], "ngay_raw": d["ngay_raw"], "can_cu_dao": d.get("can_cu_dao", "")}
        loi_so = []
        for k, raw in (("sl", d["sl_raw"]), ("dg", d["dg_raw"]), ("tt", d["tt_raw"])):
            try:
                r[k] = doc_so(raw)
            except ValueError as e:
                loi_so.append("%s: %s" % ({"sl": "SL", "dg": "đơn giá", "tt": "thành tiền"}[k], e))
        if not d["so_ct"]:
            loi_so.append("thiếu số chứng từ")
        ma, ly_do = khop_san_pham(d["san_pham_raw"], danh_muc_sp) if isinstance(d["san_pham_raw"], str) and d["san_pham_raw"].strip() \
            else (CHUA_XAC_DINH, "tên sản phẩm trống")
        r["ma_san_pham"] = ma
        r["ly_do_sp"] = ly_do
        r["loi_so"] = loi_so
        rows.append(r)

    # --- phân loại từng dòng
    for r in rows:
        trang_thai = r["tt_ngay"]
        if r["loi_so"]:
            r["loai_loai"] = "CNQ"
            r["trang_thai"] = "CAN_NGUOI_QUYET"
            r["ghi_chu"].append("Thiếu/không đọc được dữ liệu: " + "; ".join(r["loi_so"]))
            them_hoi("THIEU_DU_LIEU", "Dòng thiếu hoặc không đọc được dữ liệu: " + "; ".join(r["loi_so"]),
                     r["so_chung_tu"], r["dong_nguon"], r["tt"],
                     "Vui lòng bổ sung đầy đủ dòng %s (dòng Excel %d)." % (r["so_chung_tu"] or "không số chứng từ", r["dong_nguon"]))
            continue
        # trùng?
        khoa = (r["so_chung_tu"],)
        noi_dung = (str(r["ngay_raw"]), chuan_hoa(r["ten_goc"]), r["sl"], r["dg"], r["tt"])
        if khoa in da_thay:
            dong_dau, nd_dau = da_thay[khoa]
            if nd_dau == noi_dung:
                r["loai_loai"] = "TRUNG"
                r["trang_thai"] = "TRUNG"
                them_hoi("TRUNG", "Dòng trùng hoàn toàn với dòng %d (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng %d" % (dong_dau, dong_dau),
                         r["so_chung_tu"], r["dong_nguon"], r["tt"],
                         "Chứng từ %s xuất hiện 2 lần (dòng %d và %d). Xin xác nhận chỉ tính 1 lần?" % (r["so_chung_tu"], dong_dau, r["dong_nguon"]))
                continue
            r["loai_loai"] = "CNQ"
            r["trang_thai"] = "CAN_NGUOI_QUYET"
            r["ghi_chu"].append("Cùng số chứng từ với dòng %d nhưng nội dung khác" % dong_dau)
            them_hoi("KHAC", "Số chứng từ %s xuất hiện ở dòng %d và %d với nội dung khác nhau" % (r["so_chung_tu"], dong_dau, r["dong_nguon"]),
                     r["so_chung_tu"], r["dong_nguon"], r["tt"],
                     "Hai dòng cùng số chứng từ %s nhưng khác nội dung. Dòng nào đúng?" % r["so_chung_tu"])
            continue
        da_thay[khoa] = (r["dong_nguon"], noi_dung)
        # ngoài kỳ?
        if r["tt_ngay"] == "NGOAI_KY":
            r["loai_loai"] = "NGOAI_KY"
            r["trang_thai"] = "NGOAI_KY"
            them_hoi("NGOAI_KY", "Dòng có ngày %s, ngoài kỳ báo cáo %04d-%02d; không đưa vào bảng hợp nhất" % (r["ngay"].isoformat(), ky[0], ky[1]),
                     r["so_chung_tu"], r["dong_nguon"], r["tt"],
                     "Chứng từ %s ngày %s thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng %02d/%04d không?"
                     % (r["so_chung_tu"], r["ngay"].strftime("%d/%m/%Y"), ky[1], ky[0]))
            continue
        # ngày mơ hồ không căn cứ
        if r["tt_ngay"] == "CAN_NGUOI_QUYET":
            r["loai_loai"] = "CNQ"
            r["trang_thai"] = "CAN_NGUOI_QUYET"
            r["ghi_chu"].append("Ngày mơ hồ, chưa chọn: " + (r["hai_cach"] or ""))
            them_hoi("NGAY_MO_HO", "Ngày bán mơ hồ, chưa tính vào tổng hợp: " + (r["hai_cach"] or ""),
                     r["so_chung_tu"], r["dong_nguon"], r["tt"],
                     "Chứng từ %s (dòng Excel %d): ngày bán đúng là ngày nào? (%s)" % (r["so_chung_tu"], r["dong_nguon"], r["hai_cach"]))
            continue
        r["trang_thai"] = "SUY_RA" if r["tt_ngay"] == "SUY_RA" else "OK"
        r["loai_loai"] = "TINH"
        # thành tiền lệch SL x đơn giá
        if r["sl"] * r["dg"] != r["tt"]:
            chenh = r["tt"] - r["sl"] * r["dg"]
            r["ghi_chu"].append("Thành tiền ghi %s khác SL x đơn giá = %s (lệch %s); giữ số chi nhánh ghi"
                                % (so_ra(r["tt"]), so_ra(r["sl"] * r["dg"]), so_ra(chenh)))
            them_hoi("LECH_THANH_TIEN", "Thành tiền %s khác SL x đơn giá (%s x %s = %s), lệch %s; giữ số chi nhánh ghi"
                     % (so_ra(r["tt"]), so_ra(r["sl"]), so_ra(r["dg"]), so_ra(r["sl"] * r["dg"]), so_ra(chenh)),
                     r["so_chung_tu"], r["dong_nguon"], chenh,
                     "Chứng từ %s: SL %s x giá %s = %s nhưng thành tiền ghi %s. Số nào đúng (SL, giá hay thành tiền)?"
                     % (r["so_chung_tu"], so_ra(r["sl"]), so_ra(r["dg"]), so_ra(r["sl"] * r["dg"]), so_ra(r["tt"])))
        # sản phẩm lạ
        if r["ma_san_pham"] == CHUA_XAC_DINH:
            r["ghi_chu"].append("Sản phẩm '%s' %s" % (str(r["ten_goc"]).strip(), r["ly_do_sp"]))
            them_hoi("SAN_PHAM_LA", "Sản phẩm '%s' %s; ghi CHUA_XAC_DINH, vẫn tính vào doanh thu chi nhánh" % (str(r["ten_goc"]).strip(), r["ly_do_sp"]),
                     r["so_chung_tu"], r["dong_nguon"], r["tt"],
                     "Chứng từ %s bán '%s': đây là sản phẩm gì, có mã chuẩn nào trong danh mục không?" % (r["so_chung_tu"], str(r["ten_goc"]).strip()))

    # --- xác nhận quy ước ngày chữ (1 mục/file) và ngày bị đảo trong ô ngày (từng dòng)
    suy_text = [r for r in rows if r["trang_thai"] == "SUY_RA" and r["kieu_suy"] in ("dmy", "mdy")]
    if suy_text:
        ten = "dd/mm/yyyy" if thongtin_ngay["quy_uoc"] == "dmy" else "mm/dd/yyyy"
        them_hoi("NGAY_MO_HO",
                 "File ghi ngày dạng chữ theo %s; %d dòng có ngày đọc được 2 cách (ngày <= 12) đã được đọc theo %s (căn cứ: %d ô chỉ đọc được là ngày/tháng, %d ô chỉ đọc được là tháng/ngày)"
                 % (ten, len(suy_text), ten, thongtin_ngay["chi_dmy"], thongtin_ngay["chi_mdy"]),
                 "", "", sum((r["tt"] for r in suy_text), Decimal(0)),
                 "Xin xác nhận file dùng định dạng ngày %s cho toàn bộ cột ngày. Từ kỳ sau đề nghị nhập ngày dạng ngày thật của Excel hoặc yyyy-mm-dd." % ten)
    for r in rows:
        if r["trang_thai"] == "SUY_RA" and r["kieu_suy"] == "dao":
            them_hoi("NGAY_MO_HO", "Ô ngày lưu %s (ngoài kỳ) đã được đọc là %s (đảo ngày/tháng) và tính vào tháng; căn cứ: %s" %
                     (r["ngay_raw"].date().isoformat() if isinstance(r["ngay_raw"], dt.datetime) else r["ngay_raw"], r["ngay"].isoformat(), r["can_cu_dao"]),
                     r["so_chung_tu"], r["dong_nguon"], r["tt"],
                     "Chứng từ %s (dòng Excel %d): xin xác nhận ngày bán đúng là %s, không phải %s?"
                     % (r["so_chung_tu"], r["dong_nguon"], r["ngay"].strftime("%d/%m/%Y"), r["ngay_raw"].strftime("%d/%m/%Y")))

    # --- ghi chú cuối bảng
    for g in kq["ghi_chu"]:
        n = chuan_hoa(g["noi_dung"])
        if GHI_CHU_CHU_KY.search(n) or not GHI_CHU_QUAN_TRONG.search(n):
            continue
        if re.search(r"thang \d+", n) and not re.search(r"(nhap tre|tra lai|chua)", n):
            continue
        them_hoi("KHAC", "Ghi chú của chi nhánh (dòng %d): \"%s\"" % (g["dong"], g["noi_dung"]), "", g["dong"], None,
                 "Ghi chú này ảnh hưởng thế nào đến số liệu tháng %02d/%04d (số tiền, chứng từ liên quan)? Xin gửi bản điều chỉnh nếu cần." % (ky[1], ky[0]))

    # --- kiểm tra Cộng tuần
    sai_tuan = []
    tich_tien, tich_sl, vi_tri = Decimal(0), Decimal(0), 0
    moc = sorted(kq["tong_tuan"], key=lambda t: t["dong"])
    for t in moc:
        trong = [r for r in rows if vi_tri < r["dong_nguon"] < t["dong"]]
        tong_dong = sum((r["tt"] for r in trong if r["tt"] is not None), Decimal(0))
        tong_sl = sum((r["sl"] for r in trong if r["sl"] is not None), Decimal(0))
        if tong_dong != t["gia_tri"] or (t.get("sl") is not None and t["sl"] != tong_sl):
            sai_tuan.append("%s (dòng %d): ghi %s / SL %s, tổng các dòng %s / SL %s" % (
                t["nhan"], t["dong"], so_ra(t["gia_tri"]), so_ra(t.get("sl")), so_ra(tong_dong), so_ra(tong_sl)))
            them_hoi("SAI_TONG", "%s ghi %s, nhưng tổng các dòng trong tuần = %s" % (t["nhan"], so_ra(t["gia_tri"]), so_ra(tong_dong)),
                     "", t["dong"], t["gia_tri"] - tong_dong,
                     "'%s' không khớp các dòng chi tiết. Số nào đúng?" % t["nhan"])
        vi_tri = t["dong"]
    kq["sai_tuan"] = sai_tuan

    # --- tổng chi nhánh ghi so với tổng các dòng
    tong_dong_doc = sum((r["tt"] for r in rows if r["tt"] is not None), Decimal(0))
    tg = kq["tong_ghi"]
    lech = tg["gia_tri"] - tong_dong_doc
    if lech != 0:
        them_hoi("SAI_TONG", "Tổng cuối bảng chi nhánh ghi %s (ô %s) khác tổng %d dòng đọc được %s: lệch %s"
                 % (so_ra(tg["gia_tri"]), tg["o"], len(rows), so_ra(tong_dong_doc), so_ra(lech)),
                 "", tg["dong"], lech,
                 "Tổng cuối bảng %s khác tổng các dòng chi tiết %s (chênh %s). Vui lòng kiểm tra lại: thiếu/thừa dòng hay gõ sai tổng?"
                 % (so_ra(tg["gia_tri"]), so_ra(tong_dong_doc), so_ra(lech)))
    return rows, hoi, tong_dong_doc, lech


def them_thieu_ngay(rows, hoi, ma_cn, ky):
    """Những ngày trong tháng không có dòng nào (theo ngày xác định) -> THIEU_DU_LIEU, nêu khoảng ngày."""
    so_ngay = calendar.monthrange(*ky)[1]
    co = {r["ngay"].day for r in rows if r["ngay"] and trong_ky(r["ngay"], ky) and r["trang_thai"] in ("OK", "SUY_RA")}
    thieu = [d for d in range(1, so_ngay + 1) if d not in co]
    if not thieu:
        return
    khoang, bd, truoc = [], thieu[0], thieu[0]
    for d in thieu[1:]:
        if d != truoc + 1:
            khoang.append((bd, truoc))
            bd = d
        truoc = d
    khoang.append((bd, truoc))
    for a, b in khoang:
        ds = [dt.date(ky[0], ky[1], d) for d in range(a, b + 1)]
        ung = []
        for r in rows:
            if r["trang_thai"] == "CAN_NGUOI_QUYET" and r["hai_cach"]:
                for d in ds:
                    if d.isoformat() in r["hai_cach"]:
                        ung.append("%s (dòng %d)" % (r["so_chung_tu"], r["dong_nguon"]))
                        break
        mo = "Không có dòng bán hàng nào có ngày xác định trong khoảng %s đến %s" % (ds[0].isoformat(), ds[-1].isoformat())
        truoc = [r for r in rows if r["ngay"] and r["trang_thai"] in ("OK", "SUY_RA") and r["ngay"] < ds[0]]
        sau = [r for r in rows if r["ngay"] and r["trang_thai"] in ("OK", "SUY_RA") and r["ngay"] > ds[-1]]
        if truoc and sau:
            t, u = max(truoc, key=lambda r: r["dong_nguon"]), min(sau, key=lambda r: r["dong_nguon"])
            so_t, so_u = re.search(r"(\d+)$", t["so_chung_tu"]), re.search(r"(\d+)$", u["so_chung_tu"])
            if so_t and so_u and int(so_u.group(1)) == int(so_t.group(1)) + 1:
                mo += "; số chứng từ liền kề khoảng thiếu là %s (dòng %d) và %s (dòng %d) liên tục nên không thấy chỗ nhảy số" % (
                    t["so_chung_tu"], t["dong_nguon"], u["so_chung_tu"], u["dong_nguon"])
        if ung:
            mo += "; chỉ có các dòng ngày mơ hồ có thể thuộc khoảng này: " + ", ".join(ung)
        hoi.append({"chi_nhanh": ma_cn, "loai": "THIEU_DU_LIEU", "mo_ta": mo, "so_chung_tu": "", "dong_nguon": "",
                    "so_tien_lien_quan": None,
                    "cau_hoi": "Chi nhánh có bán hàng trong khoảng %s - %s không? Nếu có xin gửi bổ sung dữ liệu (không tự điền số)."
                               % (ds[0].strftime("%d/%m/%Y"), ds[-1].strftime("%d/%m/%Y"))})


# ----------------------------------------------------------------------------
# Ghi CSV
# ----------------------------------------------------------------------------
def ghi_csv(path, cot, dong):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=",", lineterminator="\n")
        w.writerow(cot)
        for d in dong:
            w.writerow(d)


# ----------------------------------------------------------------------------
# Chương trình chính
# ----------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Gộp doanh thu chi nhánh theo tháng.")
    ap.add_argument("goc", help="thư mục chứa file .xlsx gốc của chi nhánh (chỉ đọc)")
    ap.add_argument("ra", help="thư mục ghi kết quả")
    ap.add_argument("--thang", required=True, help="kỳ báo cáo, dạng YYYY-MM (ví dụ 2026-10)")
    ap.add_argument("--danh-muc-san-pham", default="danh_muc_san_pham.csv")
    ap.add_argument("--danh-muc-chi-nhanh", default="danh_muc_chi_nhanh.csv")
    a = ap.parse_args(argv)
    for luong in (sys.stdout, sys.stderr):
        try:
            luong.reconfigure(encoding="utf-8")
        except Exception:
            pass

    m = re.fullmatch(r"(\d{4})-(\d{2})", a.thang)
    if not m or not 1 <= int(m.group(2)) <= 12:
        ap.error("--thang phải dạng YYYY-MM, ví dụ 2026-10")
    ky = (int(m.group(1)), int(m.group(2)))

    cwd = Path.cwd().resolve()
    goc, ra = Path(a.goc).resolve(), Path(a.ra).resolve()
    for p, ten in ((goc, "goc"), (ra, "ra")):
        if cwd != p and cwd not in p.parents:
            sys.exit("Lỗi: thư mục %s (%s) nằm ngoài thư mục hiện tại; chỉ đọc/ghi trong thư mục hiện tại." % (ten, p))
    if not goc.is_dir():
        sys.exit("Lỗi: không thấy thư mục %s" % goc)
    if ra == goc or goc in ra.parents or ra in goc.parents:
        sys.exit("Lỗi: thư mục ra phải nằm ngoài goc (không được ghi vào goc).")

    for f in (a.danh_muc_san_pham, a.danh_muc_chi_nhanh):
        if not Path(f).is_file():
            sys.exit("Lỗi: không thấy file danh mục %s" % f)
    danh_muc_sp = OrderedDict((r["ma_san_pham"].strip(), r["ten_san_pham"].strip()) for r in doc_csv(a.danh_muc_san_pham))
    chi_nhanh = OrderedDict((r["ma"].strip(), r["ten"].strip()) for r in doc_csv(a.danh_muc_chi_nhanh))

    try:
        kiem_tra_quy_tac(danh_muc_sp)
        files = sorted(p for p in goc.iterdir() if p.is_file() and not p.name.startswith("~$"))
        cac_xlsx = [p for p in files if p.suffix.lower() == ".xlsx"]
        khac = [p.name for p in files if p.suffix.lower() != ".xlsx"]
        if khac:
            print("Cảnh báo: bỏ qua file không phải .xlsx trong goc/: %s" % khac, file=sys.stderr)
        if not cac_xlsx:
            raise CauTrucLa("Không có file .xlsx nào trong %s" % goc)

        ket_qua = OrderedDict()
        for p in cac_xlsx:
            wb_ct, wb_gt = mo_file(p)
            sheets = [(wb_ct[n], wb_gt[n]) for n in wb_ct.sheetnames if wb_ct[n].sheet_state == "visible"]
            co_du_lieu = [(c, g) for c, g in sheets if g.max_row > 1 or g.max_column > 1]
            if len(co_du_lieu) != 1:
                raise CauTrucLa("[%s] Cần đúng 1 sheet có dữ liệu, thấy %d (%s)." % (p.name, len(co_du_lieu), wb_ct.sheetnames))
            kq = doc_sheet(co_du_lieu[0][0], co_du_lieu[0][1], p.name, chi_nhanh)
            if kq["chi_nhanh"] in ket_qua:
                raise CauTrucLa("Hai file cùng chi nhánh %s: '%s' và '%s'. Chỉ giữ một file trong goc/."
                                % (kq["chi_nhanh"], ket_qua[kq["chi_nhanh"]]["file"], p.name))
            ket_qua[kq["chi_nhanh"]] = kq
    except CauTrucLa as e:
        print("LỖI CẤU TRÚC FILE: %s" % e, file=sys.stderr)
        return 2

    # ------------------------------------------------------------------ xử lý
    tat_ca_dong, hoi, kiem = [], [], OrderedDict()
    for ma in chi_nhanh:
        if ma not in ket_qua:
            hoi.append({"chi_nhanh": ma, "loai": "THIEU_DU_LIEU", "mo_ta": "Không có file doanh thu của chi nhánh %s (%s) trong %s" % (ma, chi_nhanh[ma], goc.name),
                        "so_chung_tu": "", "dong_nguon": "", "so_tien_lien_quan": None,
                        "cau_hoi": "Xin gửi file doanh thu tháng %02d/%04d của chi nhánh %s." % (ky[1], ky[0], chi_nhanh[ma])})
            kiem[ma] = None
            continue
        try:
            rows, h, tong_doc, lech_tong = xu_ly_file(ket_qua[ma], danh_muc_sp, ky)
        except CauTrucLa as e:
            print("LỖI CẤU TRÚC FILE: %s" % e, file=sys.stderr)
            return 2
        them_thieu_ngay(rows, h, ma, ky)
        tat_ca_dong += rows
        hoi += h
        kiem[ma] = {"rows": rows, "tong_doc": tong_doc, "lech_tong": lech_tong, "kq": ket_qua[ma]}

    # ------------------------------------------------------------------ hop_nhat
    ra.mkdir(parents=True, exist_ok=True)
    thu_tu_cn = {ma: i for i, ma in enumerate(chi_nhanh)}
    vao_hop_nhat = [r for r in tat_ca_dong if r["trang_thai"] in ("OK", "SUY_RA", "CAN_NGUOI_QUYET")]
    vao_hop_nhat.sort(key=lambda r: (thu_tu_cn[r["chi_nhanh"]], r["dong_nguon"]))
    cot_hn = ["chi_nhanh", "ngay", "so_chung_tu", "ma_san_pham", "so_luong", "don_gia", "doanh_thu",
              "file_nguon", "dong_nguon", "trang_thai", "ghi_chu"]
    ghi_csv(ra / "hop_nhat.csv", cot_hn, [
        [r["chi_nhanh"], ngay_ra(r["ngay"]),
         r["so_chung_tu"], r["ma_san_pham"], so_ra(r["sl"]), so_ra(r["dg"]), so_ra(r["tt"]),
         r["file_nguon"], r["dong_nguon"], r["trang_thai"], " | ".join(r["ghi_chu"])]
        for r in vao_hop_nhat])
    # ngày để trống nếu cần người quyết (ghi đè lại cho chắc)
    # (đã xử lý ở trên: r["ngay"] của dòng CAN_NGUOI_QUYET luôn là None)

    tinh = [r for r in vao_hop_nhat if r["trang_thai"] in ("OK", "SUY_RA")]

    # ------------------------------------------------------------------ tổng hợp
    th_cn = OrderedDict((ma, [0, Decimal(0)]) for ma in chi_nhanh)
    for r in tinh:
        th_cn[r["chi_nhanh"]][0] += 1
        th_cn[r["chi_nhanh"]][1] += r["tt"]
    ghi_csv(ra / "tong_hop_chi_nhanh.csv", ["chi_nhanh", "so_dong", "doanh_thu"],
            [[ma, v[0], so_ra(v[1])] for ma, v in th_cn.items()])

    th_sp = OrderedDict((ma, [Decimal(0), Decimal(0)]) for ma in danh_muc_sp)
    th_cn_sp = OrderedDict()
    for r in tinh:
        th_sp.setdefault(r["ma_san_pham"], [Decimal(0), Decimal(0)])
        th_sp[r["ma_san_pham"]][0] += r["sl"]
        th_sp[r["ma_san_pham"]][1] += r["tt"]
        k = (r["chi_nhanh"], r["ma_san_pham"])
        th_cn_sp.setdefault(k, [Decimal(0), Decimal(0)])
        th_cn_sp[k][0] += r["sl"]
        th_cn_sp[k][1] += r["tt"]
    ten_sp = dict(danh_muc_sp)
    ten_sp[CHUA_XAC_DINH] = "Chưa xác định (ngoài danh mục)"
    if CHUA_XAC_DINH in th_sp and th_sp[CHUA_XAC_DINH] == [0, 0]:
        del th_sp[CHUA_XAC_DINH]
    ghi_csv(ra / "tong_hop_san_pham.csv", ["ma_san_pham", "ten_san_pham", "so_luong", "doanh_thu"],
            [[ma, ten_sp[ma], so_ra(v[0]), so_ra(v[1])] for ma, v in th_sp.items()])
    sap = sorted(th_cn_sp.items(), key=lambda kv: (thu_tu_cn[kv[0][0]], list(th_sp).index(kv[0][1])))
    ghi_csv(ra / "tong_hop_chi_nhanh_san_pham.csv", ["chi_nhanh", "ma_san_pham", "so_luong", "doanh_thu"],
            [[k[0], k[1], so_ra(v[0]), so_ra(v[1])] for k, v in sap])

    tong_cn = sum((v[1] for v in th_cn.values()), Decimal(0))
    tong_sp = sum((v[1] for v in th_sp.values()), Decimal(0))
    tong_ma = sum((v[1] for v in th_cn_sp.values()), Decimal(0))
    if not (tong_cn == tong_sp == tong_ma):
        print("LỖI NỘI BỘ: tổng theo chi nhánh / sản phẩm / ma trận không bằng nhau: %s %s %s" % (tong_cn, tong_sp, tong_ma), file=sys.stderr)
        return 3

    # ------------------------------------------------------------------ kiem_tra
    dong_kiem = []
    thong_ke_kiem = OrderedDict()
    for ma in chi_nhanh:
        if kiem[ma] is None:
            dong_kiem.append([ma, "", "", so_ra(th_cn[ma][1]), "", "CHƯA GIẢI THÍCH: không có file của chi nhánh"])
            thong_ke_kiem[ma] = None
            continue
        k = kiem[ma]
        rows, kq = k["rows"], k["kq"]
        tg = kq["tong_ghi"]
        tong_ghi, tong_doc, tong_nhat = tg["gia_tri"], k["tong_doc"], th_cn[ma][1]
        chenh = tong_ghi - tong_nhat
        loai_tru = OrderedDict()
        for ten, trang_thai in (("TRUNG", "TRUNG"), ("NGOAI_KY", "NGOAI_KY"), ("CNQ", "CAN_NGUOI_QUYET")):
            ds = [r for r in rows if r["trang_thai"] == trang_thai]
            loai_tru[ten] = (ds, sum((r["tt"] for r in ds if r["tt"] is not None), Decimal(0)))
        phan = []
        z = k["lech_tong"]
        if z != 0:
            gt = "Tổng chi nhánh ghi (ô %s) %s %s so với tổng các dòng đọc được (%s): lệch %s" % (
                tg["o"], "cao hơn" if z > 0 else "thấp hơn", so_ra(abs(z)), so_ra(tong_doc), so_ra(z))
            tong_slgia = sum((r["sl"] * r["dg"] for r in rows if r["sl"] is not None and r["dg"] is not None), Decimal(0))
            if tong_slgia == tong_ghi:
                gt += "; khớp với tổng SL x đơn giá của các dòng (%s), tức nguyên nhân là các dòng lệch thành tiền" % so_ra(tong_slgia)
            else:
                gt += ". CHƯA GIẢI THÍCH (không do dòng trùng/ngoài kỳ/lệch thành tiền; cần chi nhánh xác nhận, xem SAI_TONG trong viec_can_hoi.csv)"
            phan.append((z, gt))
        else:
            phan.append((Decimal(0), None))
        if k["kq"]["sai_tuan"]:
            phan.append((Decimal(0), "Các dòng cộng tuần không khớp dòng chi tiết: " + "; ".join(k["kq"]["sai_tuan"]) + " (CHƯA GIẢI THÍCH)"))
        for ten, nhan_vn in (("TRUNG", "Dòng trùng bị loại"), ("NGOAI_KY", "Dòng ngoài kỳ %02d/%04d bị loại" % (ky[1], ky[0])),
                             ("CNQ", "Dòng CAN_NGUOI_QUYET chưa tính vào tổng hợp")):
            ds, tien = loai_tru[ten]
            if ds:
                ct = ", ".join("%s (dòng %d: %s)" % (r["so_chung_tu"] or "không số", r["dong_nguon"], so_ra(r["tt"])) for r in ds)
                phan.append((tien, "%s: %d dòng, tổng %s [%s]" % (nhan_vn, len(ds), so_ra(tien), ct)))
        tong_cac_khoan = sum((p[0] for p in phan), Decimal(0))
        if tong_cac_khoan != chenh:
            print("LỖI NỘI BỘ: %s: các khoản giải thích (%s) không bằng chênh lệch (%s)" % (ma, tong_cac_khoan, chenh), file=sys.stderr)
            return 3
        cac_text = [p[1] for p in phan if p[1]]
        giai_thich = ("; ".join(cac_text)) if cac_text else "Khớp: tổng chi nhánh ghi bằng tổng bảng hợp nhất"
        if cac_text:
            giai_thich = "Chênh lệch %s = " % so_ra(chenh) + giai_thich
        dong_kiem.append([ma, so_ra(tong_ghi), so_ra(tong_doc), so_ra(tong_nhat), so_ra(chenh), giai_thich])
        thong_ke_kiem[ma] = {"ghi": tong_ghi, "doc": tong_doc, "nhat": tong_nhat, "chenh": chenh, "giai_thich": giai_thich,
                             "o_tong": tg["o"], "loai_tru": loai_tru}
    ghi_csv(ra / "kiem_tra.csv", ["chi_nhanh", "tong_file_ghi", "tong_dong_doc_duoc", "tong_hop_nhat", "chenh_lech", "giai_thich"], dong_kiem)

    # ------------------------------------------------------------------ viec_can_hoi
    thu_tu_loai = ["NGAY_MO_HO", "THIEU_DU_LIEU", "SAN_PHAM_LA", "SAI_TONG", "LECH_THANH_TIEN", "NGOAI_KY", "TRUNG", "KHAC"]
    hoi.sort(key=lambda h: (thu_tu_cn[h["chi_nhanh"]], thu_tu_loai.index(h["loai"]),
                            h["dong_nguon"] if isinstance(h["dong_nguon"], int) else 10 ** 9))
    ghi_csv(ra / "viec_can_hoi.csv",
            ["chi_nhanh", "loai", "mo_ta", "so_chung_tu", "dong_nguon", "so_tien_lien_quan", "cau_hoi_gui_chi_nhanh"],
            [[h["chi_nhanh"], h["loai"], h["mo_ta"], h["so_chung_tu"], h["dong_nguon"], so_ra(h["so_tien_lien_quan"]), h["cau_hoi"]] for h in hoi])

    viet_bao_cao(ra / "bao_cao.md", ky, chi_nhanh, danh_muc_sp, ten_sp, th_cn, th_sp, tong_cn, tat_ca_dong, thong_ke_kiem, hoi, ket_qua)

    # ------------------------------------------------------------------ tóm tắt ra màn hình
    print("Đã xử lý %d file, %d dòng dữ liệu. Kết quả trong %s" % (len(ket_qua), len(tat_ca_dong), ra))
    print("Tổng doanh thu tháng %02d/%04d (OK + SUY_RA): %s" % (ky[1], ky[0], so_hien_thi(tong_cn)))
    print("Việc cần hỏi lại: %d mục" % len(hoi))
    return 0


# ----------------------------------------------------------------------------
# bao_cao.md (mọi số liệu lấy từ biến đã tính)
# ----------------------------------------------------------------------------
def dep(chuoi):
    """Chèn dấu chấm ngăn nghìn cho các số >= 5 chữ số đứng riêng trong văn bản (chỉ dùng cho bao_cao.md)."""
    return re.sub(r"(?<![\w-])-?\d{5,}(?![\w-])", lambda m: so_hien_thi(Decimal(m.group(0))), chuoi)


def bang_md(tieu_de, dong, can_phai=()):
    out = ["| " + " | ".join(tieu_de) + " |",
           "|" + "|".join(("---:" if i in can_phai else "---") for i in range(len(tieu_de))) + "|"]
    for d in dong:
        out.append("| " + " | ".join(str(x).replace("|", "/") for x in d) + " |")
    return "\n".join(out)


def viet_bao_cao(path, ky, chi_nhanh, danh_muc_sp, ten_sp, th_cn, th_sp, tong_cn, tat_ca_dong, tk, hoi, ket_qua):
    ky_s = "%02d/%04d" % (ky[1], ky[0])
    dem = Counter(r["trang_thai"] for r in tat_ca_dong)
    tien = defaultdict(lambda: Decimal(0))
    for r in tat_ca_dong:
        if r["tt"] is not None:
            tien[r["trang_thai"]] += r["tt"]
    so_dong_tinh = dem["OK"] + dem["SUY_RA"]
    tong_ghi_all = sum((v["ghi"] for v in tk.values() if v), Decimal(0))
    tong_doc_all = sum((v["doc"] for v in tk.values() if v), Decimal(0))
    L = []
    L.append("# Báo cáo doanh thu tháng %s - Công ty Mẫu An Phát" % ky_s)
    L.append("")
    L.append("_Tạo tự động bởi `gop.py` từ %d file chi nhánh trong `goc/`. Mọi số liệu do script tính, đơn vị đồng, không làm tròn._" % len(ket_qua))
    L.append("")
    L.append("## 1. Tóm tắt cho giám đốc")
    L.append("")
    L.append("- **Tổng doanh thu tháng %s: %s đ** (%d dòng bán hàng đã xác định: %d dòng OK, %d dòng SUY_RA)." % (
        ky_s, so_hien_thi(tong_cn), so_dong_tinh, dem["OK"], dem["SUY_RA"]))
    L.append("- Chưa tính vì cần người quyết: **%s đ** (%d dòng CAN_NGUOI_QUYET)." % (so_hien_thi(tien["CAN_NGUOI_QUYET"]), dem["CAN_NGUOI_QUYET"]))
    L.append("- Đã loại khỏi bảng hợp nhất: %d dòng trùng (%s đ) và %d dòng ngoài kỳ (%s đ)." % (
        dem["TRUNG"], so_hien_thi(tien["TRUNG"]), dem["NGOAI_KY"], so_hien_thi(tien["NGOAI_KY"])))
    L.append("- Tổng các chi nhánh tự ghi ở cuối bảng: %s đ; tổng các dòng đọc được: %s đ; tổng bảng hợp nhất: %s đ." % (
        so_hien_thi(tong_ghi_all), so_hien_thi(tong_doc_all), so_hien_thi(tong_cn)))
    theo_loai = Counter(h["loai"] for h in hoi)
    L.append("- Việc cần hỏi lại chi nhánh: **%d mục** (%s)." % (len(hoi), ", ".join("%s: %d" % (k, v) for k, v in sorted(theo_loai.items()))))
    L.append("")
    L.append("## 2. Doanh thu theo chi nhánh")
    L.append("")
    dong = []
    for ma, v in th_cn.items():
        ty = (v[1] / tong_cn * 100) if tong_cn else Decimal(0)
        dong.append([ma, chi_nhanh[ma], v[0], so_hien_thi(v[1]), "%.2f%%" % ty])
    dong.append(["**Tổng**", "", sum(v[0] for v in th_cn.values()), "**%s**" % so_hien_thi(tong_cn), "100.00%" if tong_cn else ""])
    L.append(bang_md(["Mã", "Chi nhánh", "Số dòng", "Doanh thu (đ)", "Tỷ trọng"], dong, can_phai=(2, 3, 4)))
    L.append("")
    L.append("## 3. Doanh thu theo sản phẩm")
    L.append("")
    dong = []
    for ma, v in th_sp.items():
        ty = (v[1] / tong_cn * 100) if tong_cn else Decimal(0)
        dong.append([ma, ten_sp[ma], so_hien_thi(v[0]), so_hien_thi(v[1]), "%.2f%%" % ty])
    dong.append(["**Tổng**", "", so_hien_thi(sum((v[0] for v in th_sp.values()), Decimal(0))), "**%s**" % so_hien_thi(sum((v[1] for v in th_sp.values()), Decimal(0))), "100.00%" if tong_cn else ""])
    L.append(bang_md(["Mã", "Sản phẩm", "Số lượng", "Doanh thu (đ)", "Tỷ trọng"], dong, can_phai=(2, 3, 4)))
    if CHUA_XAC_DINH in th_sp:
        L.append("")
        L.append("_Dòng `%s` là hàng ngoài danh mục sản phẩm; vẫn tính vào doanh thu vì ngày và số tiền rõ ràng, chỉ mã sản phẩm chưa xác định._" % CHUA_XAC_DINH)
    L.append("")
    L.append("## 4. Đối chiếu tổng từng file với bảng hợp nhất")
    L.append("")
    dong = []
    for ma in chi_nhanh:
        v = tk[ma]
        if v is None:
            dong.append([ma, "-", "-", so_hien_thi(th_cn[ma][1]), "-"])
        else:
            dong.append([ma, so_hien_thi(v["ghi"]), so_hien_thi(v["doc"]), so_hien_thi(v["nhat"]), so_hien_thi(v["chenh"])])
    dong.append(["**Tổng**", so_hien_thi(tong_ghi_all), so_hien_thi(tong_doc_all), so_hien_thi(tong_cn), so_hien_thi(sum((v["chenh"] for v in tk.values() if v), Decimal(0)))])
    L.append(bang_md(["Chi nhánh", "Tổng file ghi", "Tổng dòng đọc được", "Tổng hợp nhất", "Chênh lệch (ghi - hợp nhất)"], dong, can_phai=(1, 2, 3, 4)))
    L.append("")
    L.append("Giải thích chênh lệch:")
    L.append("")
    for ma in chi_nhanh:
        v = tk[ma]
        if v:
            L.append("- **%s**: %s" % (ma, dep(v["giai_thich"])))
    L.append("")
    L.append("## 5. Vấn đề dữ liệu (theo loại)")
    L.append("")
    nhom = OrderedDict()
    for h in hoi:
        nhom.setdefault(h["loai"], []).append(h)
    dong = []
    for loai, ds in nhom.items():
        cac_cn = Counter(h["chi_nhanh"] for h in ds)
        dong.append([loai, len(ds), ", ".join("%s (%d)" % (k, v) for k, v in cac_cn.items())])
    L.append(bang_md(["Loại", "Số mục", "Chi nhánh (số mục)"], dong, can_phai=(1,)))
    L.append("")
    L.append("## 6. Việc cần hỏi lại chi nhánh")
    L.append("")
    cur = None
    for h in hoi:
        if h["chi_nhanh"] != cur:
            cur = h["chi_nhanh"]
            L.append("")
            L.append("### %s - %s" % (cur, chi_nhanh[cur]))
            L.append("")
        tien_s = (" - %s đ" % so_hien_thi(h["so_tien_lien_quan"])) if h["so_tien_lien_quan"] is not None else ""
        vitri = ""
        if h["so_chung_tu"]:
            vitri = " [%s, dòng %s]" % (h["so_chung_tu"], h["dong_nguon"])
        elif h["dong_nguon"] != "":
            vitri = " [dòng %s]" % h["dong_nguon"]
        L.append("- **%s**%s%s: %s  \n  Câu hỏi: %s" % (h["loai"], vitri, tien_s, dep(h["mo_ta"]), dep(h["cau_hoi"])))
    L.append("")
    L.append("## 7. Cách xử lý và giả định")
    L.append("")
    L.append("- Mỗi dòng bán hàng một dòng trong `hop_nhat.csv`; trạng thái `OK` (đọc rõ), `SUY_RA` (ngày đọc được 2 cách nhưng có căn cứ, căn cứ ghi ở cột ghi_chu), `CAN_NGUOI_QUYET` (không chắc, để trống ngày nếu liên quan ngày, không tính vào tổng hợp).")
    L.append("- Số tiền giữ đúng thành tiền chi nhánh ghi (kể cả dòng âm); dòng lệch SL x đơn giá giữ số chi nhánh ghi và đưa vào việc cần hỏi.")
    L.append("- Dòng trùng (cùng chi nhánh, cùng số chứng từ, cùng nội dung): chỉ giữ dòng đầu. Dòng ngoài kỳ %s không đưa vào bảng hợp nhất." % ky_s)
    L.append("- Tên sản phẩm được quy về mã chuẩn theo quy tắc trong `gop.py` (bỏ dấu, chữ hoa/thường, viết tắt, kèm quy cách); không khớp thì ghi `%s`." % CHUA_XAC_DINH)
    tra_hang = [r for r in tat_ca_dong if r["trang_thai"] in ("OK", "SUY_RA") and r["tt"] is not None and r["tt"] < 0]
    if tra_hang:
        L.append("- Dòng trả hàng (số âm) giữ nguyên và trừ vào doanh thu: %d dòng, tổng %s đ (%s)." % (
            len(tra_hang), so_hien_thi(sum((r["tt"] for r in tra_hang), Decimal(0))),
            ", ".join("%s %s" % (r["chi_nhanh"], r["so_chung_tu"]) for r in tra_hang)))
    nhom_nd = defaultdict(list)
    for r in tat_ca_dong:
        if r["trang_thai"] in ("OK", "SUY_RA"):
            nhom_nd[(r["chi_nhanh"], r["ngay"], r["ma_san_pham"], r["sl"], r["dg"], r["tt"])].append(r["so_chung_tu"])
    cap = [v for v in nhom_nd.values() if len(v) > 1]
    if cap:
        L.append("- %d nhóm dòng cùng chi nhánh, cùng ngày, cùng sản phẩm, SL, đơn giá và thành tiền nhưng KHÁC số chứng từ (%s). Theo quy tắc dòng trùng phải cùng số chứng từ nên vẫn tính là giao dịch riêng; chưa có căn cứ để cho là nhập hai lần." % (
            len(cap), "; ".join(" / ".join(v) for v in cap)))
    for ma, kq in ket_qua.items():
        so_suy = sum(1 for r in tat_ca_dong if r["chi_nhanh"] == ma and r["trang_thai"] == "SUY_RA")
        if so_suy:
            L.append("- %s: %d dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`)." % (ma, so_suy))
    L.append("")
    path.write_text("\n".join(L), encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
