"""Bài 3: chạy lại gop.py (do agent viết ở bài 1-2) cho tháng mới, KHÔNG gọi agent, rồi chấm bằng đáp án của tháng đó.

Dùng:  python -X utf8 chay_lai.py <gop.py> <du-lieu/thang-XX> <dap-an.json> <thư_mục_làm_việc_mới> <YYYY-MM> [--out kq.json]
Làm: chép dữ liệu tháng mới + gop.py vào thư mục trống, chạy `python gop.py goc ra --thang YYYY-MM`,
     ghi lại mã thoát/ lỗi, rồi chấm (nếu có ra/hop_nhat.csv). Có băm file gốc để chắc là không bị sửa.
"""
import sys, json, shutil, subprocess, time, argparse
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from cham import cham

ap = argparse.ArgumentParser()
ap.add_argument("gop"); ap.add_argument("data"); ap.add_argument("truth"); ap.add_argument("work"); ap.add_argument("thang"); ap.add_argument("--out"); ap.add_argument("--so-voi-thang-khac", help="dap-an.json của tháng khác: dò số chứng từ của tháng đó còn sót trong văn bản giải thích/báo cáo (số cũ gõ cứng trong script)")
a = ap.parse_args()
work = Path(a.work)
shutil.rmtree(work, ignore_errors=True); shutil.copytree(a.data, work); shutil.copy(a.gop, work / "gop.py")
t0 = time.time()
p = subprocess.run([sys.executable, "-X", "utf8", "gop.py", "goc", "ra", "--thang", a.thang], cwd=work, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
R = {"lenh": f"python gop.py goc ra --thang {a.thang}", "giay": round(time.time() - t0, 1), "returncode": p.returncode,
     "stdout_tail": p.stdout[-1500:], "stderr_tail": p.stderr[-1500:]}
if (work / "ra" / "hop_nhat.csv").exists():
    R["cham"] = cham(work, a.truth, Path(a.data) / "goc")
else:
    R["cham"] = None
if a.so_voi_thang_khac and (work / "ra").exists():
    O = json.loads(Path(a.so_voi_thang_khac).read_text(encoding="utf-8")); T = json.loads(Path(a.truth).read_text(encoding="utf-8"))
    mine = {r["inv"] for r in T["rows"]} | {x["inv"] for k in ("ask_rows", "oop_rows", "dup_rows") for x in T[k]}
    other = {x["inv"] for k in ("ask_rows", "oop_rows", "dup_rows") for x in O[k]} | {r["inv"] for r in O["rows"] if r["flags"]}
    stale = sorted(i for i in other - mine if i.startswith("HD"))   # chỉ lấy mã HDxxxxx (ngẫu nhiên, không trùng giữa 2 tháng)
    hits = {}
    for fn in ("kiem_tra.csv", "bao_cao.md", "viec_can_hoi.csv"):
        f = work / "ra" / fn
        if f.exists():
            t = f.read_text(encoding="utf-8-sig"); hits[fn] = sorted(i for i in stale if i in t)
    R["so_chung_tu_thang_khac_con_sot"] = hits
s = json.dumps(R, ensure_ascii=False, indent=1)
if a.out: Path(a.out).write_text(s, encoding="utf-8")
print(s[:3500])
