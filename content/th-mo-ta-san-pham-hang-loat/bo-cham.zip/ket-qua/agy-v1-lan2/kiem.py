# -*- coding: utf-8 -*-
"""
Script kiểm tra tính hợp lệ và độ sạch dữ liệu của các file nhập hàng loạt:
- nhap_hang_loat.csv (UTF-8 có BOM)
- nhap_hang_loat.xlsx

Các tiêu chí kiểm tra:
1. Định dạng file, cấu trúc cột, số lượng dòng (đúng 40 sản phẩm).
2. Giới hạn độ dài: tieu_de (25-100), mo_ta (200-1500), gach_1..5 (<=120), tu_khoa (6-10 cụm, <=30 ký tự/cụm).
3. Từ cấm: Kiểm tra toàn bộ 28 từ cấm trong tu_cam.txt (cả có dấu và không dấu).
4. Giọng thương hiệu: Không dùng 'quý khách', 'chị em', 'chúng tôi', không emoji, tối đa 1 dấu chấm than trong mô tả, không viết HOA cả từ để nhấn mạnh.
5. Nguyên tắc sự thật:
   - Mọi con số trong tiêu đề, mô tả, 5 gạch đầu dòng phải có trong bảng thông số (thong_so.csv, trừ ghi_chu_noi_bo).
   - Không được công bố số phiếu nếu bảng ghi 'đang chờ duyệt' hoặc để trống.
   - Thiếu trường bắt buộc phải có cụm 'CẦN BỔ SUNG: <tên cột>'.
6. Trạng thái và trường cần bổ sung: SAN_SANG vs CAN_BO_SUNG hoàn toàn khớp với dữ liệu nguồn.
7. Tính đồng bộ 1:1 giữa nhap_hang_loat.csv và nhap_hang_loat.xlsx.
"""

import os
import sys
import csv
import re
import unicodedata
import openpyxl

MANDATORY_COLS = ['dung_tich', 'thanh_phan_noi_bat', 'xuat_xu', 'han_su_dung', 'cong_dung_tren_bao_bi', 'cach_dung']
MISSING_VALUES = {"", "?", "chưa rõ", "liên hệ ncc", "n/a", "chưa có"}

def is_missing(val):
    if val is None:
        return True
    return val.strip().lower() in MISSING_VALUES

def remove_accents(input_str):
    if not input_str:
        return ""
    nfkd = unicodedata.normalize('NFKD', input_str)
    return "".join(c for c in nfkd if not unicodedata.combining(c)).replace('đ', 'd').replace('Đ', 'D').lower()

def has_emoji(text):
    for char in text:
        # Check standard emoji unicode blocks
        if ord(char) > 0x1F000:
            return True
    return False

def check_all():
    errors = []
    warnings = []
    
    print("=" * 70)
    print("KHỞI CHẠY KIỂM TRA CHẤT LƯỢNG NỘI DUNG SHOP VƯỜN NHỎ")
    print("=" * 70)
    
    # 1. Kiểm tra sự tồn tại của các file bắt buộc
    required_files = ['thong_so.csv', 'quy_dinh_shop.md', 'tu_cam.txt', 'mau_dau_ra.csv', 'nhap_hang_loat.csv', 'nhap_hang_loat.xlsx']
    for rf in required_files:
        if not os.path.exists(rf):
            errors.append(f"Thiếu file bắt buộc: {rf}")
            
    if errors:
        for err in errors:
            print(f"[LỖI] {err}")
        return False

    # 2. Đọc file mẫu đầu ra để lấy danh sách cột
    with open('mau_dau_ra.csv', 'r', encoding='utf-8-sig') as f:
        reader = csv.reader(f)
        expected_headers = next(reader)
    print(f"Cột chuẩn ({len(expected_headers)} cột): {', '.join(expected_headers)}")

    # 3. Đọc danh sách từ cấm
    with open('tu_cam.txt', 'r', encoding='utf-8') as f:
        banned_words = [line.strip().lower() for line in f if line.strip()]
    banned_words_no_acc = [remove_accents(w) for w in banned_words]
    print(f"Tổng số từ cấm nạp vào: {len(banned_words)} cụm từ")

    # 4. Đọc bảng thông số gốc
    with open('thong_so.csv', 'r', encoding='utf-8-sig') as f:
        raw_reader = csv.DictReader(f)
        raw_rows = {r['sku']: r for r in raw_reader}
    print(f"Tổng số SKU trong bảng thông số: {len(raw_rows)}")

    # 5. Kiểm tra UTF-8 có BOM của nhap_hang_loat.csv
    with open('nhap_hang_loat.csv', 'rb') as f:
        first_bytes = f.read(3)
        if first_bytes != b'\xef\xbb\xbf':
            errors.append("nhap_hang_loat.csv không có UTF-8 BOM (\\xef\\xbb\\xbf) ở đầu file!")
        else:
            print("[PASS] nhap_hang_loat.csv có UTF-8 BOM hợp lệ.")

    # Đọc dữ liệu nhap_hang_loat.csv
    with open('nhap_hang_loat.csv', 'r', encoding='utf-8-sig') as f:
        csv_reader = csv.DictReader(f)
        if csv_reader.fieldnames != expected_headers:
            errors.append(f"Header của nhap_hang_loat.csv không khớp mẫu: {csv_reader.fieldnames} != {expected_headers}")
        csv_data = list(csv_reader)

    # Đọc dữ liệu nhap_hang_loat.xlsx
    wb = openpyxl.load_workbook('nhap_hang_loat.xlsx')
    ws = wb.active
    xlsx_rows = list(ws.iter_rows(values_only=True))
    xlsx_headers = list(xlsx_rows[0])
    if xlsx_headers != expected_headers:
        errors.append(f"Header của nhap_hang_loat.xlsx không khớp mẫu: {xlsx_headers} != {expected_headers}")
    xlsx_data = [dict(zip(xlsx_headers, r)) for r in xlsx_rows[1:]]

    # Kiểm tra số dòng
    if len(csv_data) != 40:
        errors.append(f"Số dòng nhap_hang_loat.csv ({len(csv_data)}) khác 40!")
    if len(xlsx_data) != 40:
        errors.append(f"Số dòng nhap_hang_loat.xlsx ({len(xlsx_data)}) khác 40!")

    # 6. Kiểm tra tính đồng bộ 1:1 giữa CSV và XLSX
    for idx, (c_row, x_row) in enumerate(zip(csv_data, xlsx_data), 1):
        for h in expected_headers:
            c_val = str(c_row.get(h, "") or "").strip()
            x_val = str(x_row.get(h, "") or "").strip()
            if c_val != x_val:
                errors.append(f"Dòng {idx} ({c_row['sku']}) lệch dữ liệu giữa CSV và XLSX tại cột '{h}': '{c_val}' vs '{x_val}'")

    print("[PASS] Tính đồng bộ CSV và XLSX đạt chuẩn 100%.")

    # 7. Kiểm tra chi tiết từng dòng sản phẩm
    count_san_sang = 0
    count_can_bo_sung = 0

    for idx, row in enumerate(csv_data, 1):
        sku = row.get('sku', '').strip()
        tieu_de = row.get('tieu_de', '').strip()
        mo_ta = row.get('mo_ta', '').strip()
        gach_1 = row.get('gach_1', '').strip()
        gach_2 = row.get('gach_2', '').strip()
        gach_3 = row.get('gach_3', '').strip()
        gach_4 = row.get('gach_4', '').strip()
        gach_5 = row.get('gach_5', '').strip()
        tu_khoa = row.get('tu_khoa', '').strip()
        trang_thai = row.get('trang_thai', '').strip()
        truong_can_bo_sung = row.get('truong_can_bo_sung', '').strip()

        if sku not in raw_rows:
            errors.append(f"Dòng {idx}: SKU '{sku}' không tồn tại trong thong_so.csv!")
            continue

        raw = raw_rows[sku]

        # a. Độ dài tiêu đề (25 - 100)
        len_td = len(tieu_de)
        if not (25 <= len_td <= 100):
            errors.append(f"[{sku}] Độ dài tiêu đề không hợp lệ: {len_td} ký tự (yêu cầu 25-100). Tiêu đề: '{tieu_de}'")

        if not tieu_de.startswith("Vườn Nhỏ"):
            errors.append(f"[{sku}] Tiêu đề không bắt đầu bằng 'Vườn Nhỏ': '{tieu_de}'")

        # b. Độ dài mô tả (200 - 1500)
        len_mt = len(mo_ta)
        if not (200 <= len_mt <= 1500):
            errors.append(f"[{sku}] Độ dài mô tả không hợp lệ: {len_mt} ký tự (yêu cầu 200-1500).")

        # c. Độ dài 5 gạch đầu dòng (mỗi gạch <= 120)
        bullets = [('gach_1', gach_1), ('gach_2', gach_2), ('gach_3', gach_3), ('gach_4', gach_4), ('gach_5', gach_5)]
        for g_name, g_val in bullets:
            if not g_val:
                errors.append(f"[{sku}] {g_name} để trống!")
            elif len(g_val) > 120:
                errors.append(f"[{sku}] {g_name} vượt quá 120 ký tự ({len(g_val)} ký tự): '{g_val}'")

        # d. Kiểm tra từ khóa (6 - 10 cụm, mỗi cụm <= 30 ký tự)
        kws = [k.strip() for k in tu_khoa.split(';') if k.strip()]
        if not (6 <= len(kws) <= 10):
            errors.append(f"[{sku}] Số lượng từ khóa không hợp lệ: {len(kws)} cụm (yêu cầu 6-10 cụm).")
        for k in kws:
            if len(k) > 30:
                errors.append(f"[{sku}] Cụm từ khóa '{k}' vượt quá 30 ký tự ({len(k)} ký tự).")

        # e. Kiểm tra từ cấm
        full_text = f"{tieu_de} {mo_ta} {gach_1} {gach_2} {gach_3} {gach_4} {gach_5} {tu_khoa}".lower()
        full_text_no_acc = remove_accents(full_text)

        for bw in banned_words:
            # Word boundary check or substring check
            pattern = r'(?<!\w)' + re.escape(bw) + r'(?!\w)'
            if re.search(pattern, full_text):
                errors.append(f"[{sku}] Chứa từ cấm có dấu: '{bw}'")

        for bw_na in banned_words_no_acc:
            pattern_na = r'(?<!\w)' + re.escape(bw_na) + r'(?!\w)'
            if re.search(pattern_na, full_text_no_acc):
                errors.append(f"[{sku}] Chứa từ cấm không dấu: '{bw_na}'")

        # f. Kiểm tra giọng thương hiệu
        pronoun_forbidden = ['quý khách', 'chị em', 'chúng tôi']
        for p in pronoun_forbidden:
            if re.search(r'(?<!\w)' + re.escape(p) + r'(?!\w)', full_text):
                errors.append(f"[{sku}] Chứa đại từ bị cấm: '{p}'")
            if re.search(r'(?<!\w)' + re.escape(remove_accents(p)) + r'(?!\w)', full_text_no_acc):
                errors.append(f"[{sku}] Chứa đại từ bị cấm không dấu: '{p}'")

        if mo_ta.count('!') > 1:
            errors.append(f"[{sku}] Mô tả có {mo_ta.count('!')} dấu chấm than (tối đa cho phép 1 dấu).")

        if has_emoji(full_text):
            errors.append(f"[{sku}] Chứa ký tự emoji!")

        # g. Kiểm tra chữ viết hoa toàn bộ để nhấn mạnh
        # Ngoại trừ các cụm hợp lệ: CẦN BỔ SUNG, SPF, PA, UV, DEMO
        raw_upper_tokens = re.findall(r'\b[A-ZÀÁẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬÈÉẺẼẸÊẾỀỂỄỆÌÍỈĨỊÒÓỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÙÚỦŨỤƯỨỪỬỮỰỲÝỶỸỴĐ]{2,}\b', f"{tieu_de} {mo_ta} {gach_1} {gach_2} {gach_3} {gach_4} {gach_5} {tu_khoa}")
        allowed_upper = {'CẦN', 'BỔ', 'SUNG', 'SPF', 'PA', 'UV', 'DEMO', 'SKU'}
        bad_uppers = [tok for tok in raw_upper_tokens if tok not in allowed_upper]
        if bad_uppers:
            errors.append(f"[{sku}] Chứa chữ viết hoa có thể mang tính nhấn mạnh: {bad_uppers}")

        # h. Kiểm tra sự thật: Con số
        # Mọi số (\d+) trong tieu_de, mo_ta, gach_1..5 phải xuất hiện trong bảng thông số (trừ ghi_chu_noi_bo)
        allowed_numbers = set()
        for col_name, val in raw.items():
            if col_name == 'ghi_chu_noi_bo':
                continue
            if val:
                allowed_numbers.update(re.findall(r'\d+', val))

        checked_content = f"{tieu_de} {mo_ta} {gach_1} {gach_2} {gach_3} {gach_4} {gach_5}"
        found_nums = re.findall(r'\d+', checked_content)
        for num in found_nums:
            if num not in allowed_numbers:
                errors.append(f"[{sku}] Phát hiện số '{num}' trong nội dung nhưng KHÔNG CÓ trong bảng thông số! Số hợp lệ của SKU: {allowed_numbers}")

        # i. Kiểm tra phiếu công bố
        so_phieu_raw = raw.get('so_phieu_cong_bo', '').strip()
        is_published = bool(so_phieu_raw and so_phieu_raw.lower() != 'đang chờ duyệt')
        claims_published = ("phiếu công bố" in mo_ta.lower() or "đã có phiếu công bố" in mo_ta.lower() or "phiếu công bố" in full_text)
        if not is_published and claims_published:
            errors.append(f"[{sku}] Quảng cáo đã có phiếu công bố trong khi cột so_phieu_cong_bo='{so_phieu_raw}'!")

        # j. Kiểm tra trạng thái và trường cần bổ sung
        expected_missing = [c for c in MANDATORY_COLS if is_missing(raw.get(c, ''))]
        if expected_missing:
            count_can_bo_sung += 1
            if trang_thai != "CAN_BO_SUNG":
                errors.append(f"[{sku}] Trạng thái phải là CAN_BO_SUNG nhưng đang ghi là '{trang_thai}'!")
            
            # Kiểm tra truong_can_bo_sung
            actual_missing_fields = [f.strip() for f in truong_can_bo_sung.split(';') if f.strip()]
            if set(actual_missing_fields) != set(expected_missing):
                errors.append(f"[{sku}] Danh sách truong_can_bo_sung không khớp! Thực tế: {actual_missing_fields}, Kỳ vọng: {expected_missing}")

            # Kiểm tra trong mo_ta phải có cụm 'CẦN BỔ SUNG: <tên cột>' cho mỗi trường thiếu
            for f_miss in expected_missing:
                tag = f"CẦN BỔ SUNG: {f_miss}"
                if tag not in mo_ta:
                    errors.append(f"[{sku}] Mô tả thiếu cụm thông báo bắt buộc: '{tag}'")
        else:
            count_san_sang += 1
            if trang_thai != "SAN_SANG":
                errors.append(f"[{sku}] Trạng thái phải là SAN_SANG nhưng đang ghi là '{trang_thai}'!")
            if truong_can_bo_sung != "":
                errors.append(f"[{sku}] Trạng thái SAN_SANG thì truong_can_bo_sung phải để trống, nhưng đang ghi: '{truong_can_bo_sung}'")

    print("-" * 70)
    print("KẾT QUẢ TỔNG HỢP KIỂM TRA:")
    print(f"- Tổng số SKU kiểm tra: {len(csv_data)}/40")
    print(f"- Số sản phẩm SẴN SÀNG (SAN_SANG): {count_san_sang}")
    print(f"- Số sản phẩm CẦN BỔ SUNG (CAN_BO_SUNG): {count_can_bo_sung}")
    print(f"- Tổng số lỗi phát hiện: {len(errors)}")
    print(f"- Tổng số cảnh báo: {len(warnings)}")
    print("-" * 70)

    if errors:
        print("[THẤT BẠI] Các lỗi cần khắc phục:")
        for e in errors:
            print(f"  * {e}")
        return False
    else:
        print("[THÀNH CÔNG] DỮ LIỆU HOÀN TOÀN SẠCH VÀ TUÂN THỦ 100% QUY ĐỊNH SHOP VƯỜN NHỎ!")
        return True

if __name__ == '__main__':
    success = check_all()
    sys.exit(0 if success else 1)
