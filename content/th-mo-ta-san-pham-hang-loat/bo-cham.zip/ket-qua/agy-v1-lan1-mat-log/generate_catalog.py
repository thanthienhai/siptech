import pandas as pd
import re
import unicodedata

# Missing markers as per shop rule
MISSING_MARKERS = {'', '?', 'chưa rõ', 'liên hệ ncc', 'n/a', 'chưa có', 'nan'}
REQUIRED_COLS = ['dung_tich', 'thanh_phan_noi_bat', 'xuat_xu', 'han_su_dung', 'cong_dung_tren_bao_bi', 'cach_dung']

def is_missing(val):
    if pd.isna(val):
        return True
    s = str(val).strip().lower()
    return s in MISSING_MARKERS

def strip_accents(text):
    text = unicodedata.normalize('NFD', text)
    text = ''.join(c for c in text if unicodedata.category(c) != 'Mn')
    return text.replace('đ', 'd').replace('Đ', 'D')

def load_banned_words():
    with open('tu_cam.txt', 'r', encoding='utf-8') as f:
        words = [line.strip().lower() for line in f if line.strip()]
    return words

banned_words = load_banned_words()
banned_words_no_accent = [strip_accents(w) for w in banned_words]

def check_banned(text):
    t_lower = text.lower()
    t_no_acc = strip_accents(t_lower)
    for bw, bw_na in zip(banned_words, banned_words_no_accent):
        if bw in t_lower or bw_na in t_no_acc:
            return bw
    return None

def build_title(row, m):
    name = str(row['ten_san_pham']).strip()
    dt = str(row['dung_tich']).strip() if not m['dung_tich'] else ""
    nhom = str(row['nhom']).strip()
    spf = str(row['chi_so_chong_nang']).strip() if pd.notna(row['chi_so_chong_nang']) and str(row['chi_so_chong_nang']).strip().lower() not in MISSING_MARKERS else ""
    
    # Base: Vườn Nhỏ - tên sản phẩm + dung tích/khối lượng (nếu có trong bảng)
    if dt:
        base = f"Vườn Nhỏ - {name} {dt}"
    else:
        base = f"Vườn Nhỏ - {name}"
        
    if nhom == 'Chống nắng':
        if spf:
            if not m['cong_dung_tren_bao_bi']:
                cd = str(row['cong_dung_tren_bao_bi']).strip()
                cand = f"{base} {spf} - {cd}"
            else:
                cand = f"{base} {spf}"
            if len(cand) <= 100:
                return cand
        else:
            if not m['cong_dung_tren_bao_bi']:
                cd = str(row['cong_dung_tren_bao_bi']).strip()
                cand = f"{base} - {cd}"
                if len(cand) <= 100:
                    return cand
    else:
        if not m['cong_dung_tren_bao_bi']:
            cd = str(row['cong_dung_tren_bao_bi']).strip()
            cand = f"{base} - {cd}"
            if len(cand) <= 100:
                return cand
            else:
                words = cd.split()
                short_cd = ""
                for w in words:
                    if len(f"{base} - {short_cd} {w}".strip()) <= 100:
                        short_cd = f"{short_cd} {w}".strip()
                    else:
                        break
                if len(f"{base} - {short_cd}") >= 25:
                    return f"{base} - {short_cd}"
                    
    if len(base) < 25:
        base = f"{base} chăm sóc da dịu nhẹ"
    return base

def build_mo_ta(row, m):
    name = str(row['ten_san_pham']).strip()
    lines = []
    lines.append(f"Chào bạn, Vườn Nhỏ xin gửi đến bạn thông tin chi tiết về sản phẩm {name}.")
    lines.append("")
    lines.append("Thông tin sản phẩm:")
    
    # dung_tich
    if not m['dung_tich']:
        lines.append(f"- Dung tích: {str(row['dung_tich']).strip()}.")
    else:
        lines.append("- Dung tích: CẦN BỔ SUNG: dung_tich.")
        
    # thanh_phan_noi_bat
    if not m['thanh_phan_noi_bat']:
        lines.append(f"- Thành phần nổi bật: {str(row['thanh_phan_noi_bat']).strip()}.")
    else:
        lines.append("- Thành phần nổi bật: CẦN BỔ SUNG: thanh_phan_noi_bat.")
        
    # cong_dung_tren_bao_bi
    if not m['cong_dung_tren_bao_bi']:
        lines.append(f"- Công dụng trên bao bì: {str(row['cong_dung_tren_bao_bi']).strip()}.")
    else:
        lines.append("- Công dụng trên bao bì: CẦN BỔ SUNG: cong_dung_tren_bao_bi.")
        
    # chi_so_chong_nang
    if pd.notna(row['chi_so_chong_nang']) and str(row['chi_so_chong_nang']).strip().lower() not in MISSING_MARKERS:
        lines.append(f"- Chỉ số chống nắng: {str(row['chi_so_chong_nang']).strip()}.")
        
    # loai_da_phu_hop
    if pd.notna(row['loai_da_phu_hop']) and str(row['loai_da_phu_hop']).strip().lower() not in MISSING_MARKERS:
        lines.append(f"- Loại da phù hợp: {str(row['loai_da_phu_hop']).strip()}.")
    else:
        lines.append("- Loại da phù hợp: CẦN BỔ SUNG: loai_da_phu_hop.")
        
    # mui_huong
    if pd.notna(row['mui_huong']) and str(row['mui_huong']).strip().lower() not in MISSING_MARKERS:
        lines.append(f"- Mùi hương: {str(row['mui_huong']).strip()}.")
    else:
        lines.append("- Mùi hương: CẦN BỔ SUNG: mui_huong.")
        
    # xuat_xu
    if not m['xuat_xu']:
        lines.append(f"- Xuất xứ: {str(row['xuat_xu']).strip()}.")
    else:
        lines.append("- Xuất xứ: CẦN BỔ SUNG: xuat_xu.")
        
    # han_su_dung
    if not m['han_su_dung']:
        lines.append(f"- Hạn sử dụng: {str(row['han_su_dung']).strip()}.")
    else:
        lines.append("- Hạn sử dụng: CẦN BỔ SUNG: han_su_dung.")
        
    # cach_dung
    lines.append("")
    lines.append("Hướng dẫn sử dụng:")
    if not m['cach_dung']:
        lines.append(f"{str(row['cach_dung']).strip()}.")
    else:
        lines.append("CẦN BỔ SUNG: cach_dung.")
        
    # so_phieu_cong_bo: only if approved (e.g. DEMO-xxxx)
    sp = str(row['so_phieu_cong_bo']).strip() if pd.notna(row['so_phieu_cong_bo']) else ""
    if sp and sp.lower() not in MISSING_MARKERS and "chờ duyệt" not in sp.lower():
        lines.append("")
        lines.append(f"Thông tin công bố: Sản phẩm đã có phiếu công bố mã {sp}.")
        
    lines.append("")
    lines.append("Vườn Nhỏ hy vọng những thông tin rõ ràng này sẽ giúp bạn dễ dàng chọn lựa sản phẩm phù hợp cho mình. Nếu bạn có bất kỳ thắc mắc nào, bạn nhắn tin để Vườn Nhỏ hỗ trợ bạn chu đáo nhé.")
    
    return "\n".join(lines)

def build_bullets(row, m):
    # gach_1: dung_tich
    if not m['dung_tich']:
        g1 = f"Dung tích: {str(row['dung_tich']).strip()}"
    else:
        g1 = "Dung tích: CẦN BỔ SUNG: dung_tich"
        
    # gach_2: thanh_phan_noi_bat
    if not m['thanh_phan_noi_bat']:
        g2 = f"Thành phần nổi bật: {str(row['thanh_phan_noi_bat']).strip()}"
    else:
        g2 = "Thành phần nổi bật: CẦN BỔ SUNG: thanh_phan_noi_bat"
        
    # gach_3: cong_dung_tren_bao_bi
    nhom = str(row['nhom']).strip()
    spf = str(row['chi_so_chong_nang']).strip() if pd.notna(row['chi_so_chong_nang']) and str(row['chi_so_chong_nang']).strip().lower() not in MISSING_MARKERS else ""
    if not m['cong_dung_tren_bao_bi']:
        cd = str(row['cong_dung_tren_bao_bi']).strip()
        if nhom == 'Chống nắng' and spf:
            g3 = f"Công dụng trên bao bì: {cd} ({spf})"
        else:
            g3 = f"Công dụng trên bao bì: {cd}"
    else:
        if nhom == 'Chống nắng' and spf:
            g3 = f"Công dụng trên bao bì: CẦN BỔ SUNG: cong_dung_tren_bao_bi ({spf})"
        else:
            g3 = "Công dụng trên bao bì: CẦN BỔ SUNG: cong_dung_tren_bao_bi"
            
    # gach_4: cach_dung
    if not m['cach_dung']:
        g4 = f"Hướng dẫn sử dụng: {str(row['cach_dung']).strip()}"
    else:
        g4 = "Hướng dẫn sử dụng: CẦN BỔ SUNG: cach_dung"
        
    # gach_5: xuat_xu & han_su_dung
    xx_part = f"Xuất xứ: {str(row['xuat_xu']).strip()}" if not m['xuat_xu'] else "Xuất xứ: CẦN BỔ SUNG: xuat_xu"
    hsd_part = f"hạn sử dụng: {str(row['han_su_dung']).strip()}" if not m['han_su_dung'] else "hạn sử dụng: CẦN BỔ SUNG: han_su_dung"
    g5 = f"{xx_part}, {hsd_part}"
    
    return [g1, g2, g3, g4, g5]

def build_keywords(row, m):
    name = str(row['ten_san_pham']).strip().lower()
    kws = []
    
    # 1. Brand
    kws.append("vườn nhỏ")
    
    # 2. Specific category phrases
    if "sữa rửa mặt" in name:
        kws.append("sữa rửa mặt")
        kws.append("sữa rửa mặt gel")
    elif "nước cân bằng" in name:
        kws.append("nước cân bằng da")
        kws.append("toner cân bằng da")
    elif "tinh chất" in name:
        kws.append("tinh chất dưỡng da")
        kws.append("serum dưỡng da")
    elif "kem dưỡng ẩm" in name:
        kws.append("kem dưỡng ẩm")
        kws.append("kem dưỡng da mặt")
    elif "kem chống nắng" in name:
        kws.append("kem chống nắng")
        kws.append("chống nắng bảo vệ da")
    elif "mặt nạ giấy" in name:
        kws.append("mặt nạ giấy")
        kws.append("mặt nạ dưỡng da")
    elif "son dưỡng" in name:
        kws.append("son dưỡng môi")
        kws.append("dưỡng mềm môi")
    elif "dầu gội" in name:
        kws.append("dầu gội")
        kws.append("dầu gội đầu")
    elif "sữa tắm" in name:
        kws.append("sữa tắm")
        kws.append("sữa tắm làm sạch")
    elif "kem dưỡng da tay" in name:
        kws.append("kem dưỡng da tay")
        kws.append("dưỡng mềm da tay")
    elif "xịt khoáng" in name:
        kws.append("xịt khoáng")
        kws.append("xịt khoáng cấp ẩm")
    elif "nước tẩy trang" in name:
        kws.append("nước tẩy trang")
        kws.append("làm sạch da mặt")
        
    # 3. Product name (shortened if needed)
    if len(name) <= 30:
        kws.append(name)
        
    # 4. Ingredients
    if not m['thanh_phan_noi_bat']:
        tp = str(row['thanh_phan_noi_bat']).strip().lower()
        parts = [p.strip() for p in tp.split(',')]
        for p in parts:
            if len(p) <= 30 and p not in kws:
                kws.append(p)
                
    # 5. Skin/Hair type
    if pd.notna(row['loai_da_phu_hop']) and str(row['loai_da_phu_hop']).strip().lower() not in MISSING_MARKERS:
        ld = str(row['loai_da_phu_hop']).strip().lower()
        if ld == "da dầu và da hỗn hợp":
            kws.append("da dầu hỗn hợp")
        elif len(ld) <= 30:
            kws.append(ld)
            
    # 6. Origin
    if not m['xuat_xu']:
        xx = str(row['xuat_xu']).strip().lower()
        if "thái lan" in xx:
            kws.append("mỹ phẩm thái lan")
        elif "hàn quốc" in xx:
            kws.append("mỹ phẩm hàn quốc")
        elif "việt nam" in xx:
            kws.append("mỹ phẩm việt nam")
            
    # Safe fallbacks to guarantee 6 to 10
    safe_fallbacks = ["mỹ phẩm dịu nhẹ", "chăm sóc cá nhân", "sản phẩm lành tính"]
    for fb in safe_fallbacks:
        if len(kws) < 7 and fb not in kws:
            kws.append(fb)
            
    seen = set()
    final_kws = []
    for k in kws:
        k_clean = k.strip()
        if k_clean and k_clean not in seen and len(k_clean) <= 30:
            seen.add(k_clean)
            final_kws.append(k_clean)
            
    final_kws = final_kws[:10]
    return "; ".join(final_kws)

def generate_catalog():
    df = pd.read_csv('thong_so.csv')
    rows = []
    
    for idx, r in df.iterrows():
        m = {c: is_missing(r[c]) for c in df.columns}
        sku = str(r['sku']).strip()
        
        # Missing required fields
        missing_req = [col for col in REQUIRED_COLS if m[col]]
        
        if missing_req:
            trang_thai = "CAN_BO_SUNG"
            truong_can_bo_sung = ";".join(missing_req)
        else:
            trang_thai = "SAN_SANG"
            truong_can_bo_sung = ""
            
        tieu_de = build_title(r, m)
        mo_ta = build_mo_ta(r, m)
        bullets = build_bullets(r, m)
        tu_khoa = build_keywords(r, m)
        
        row_dict = {
            'sku': sku,
            'tieu_de': tieu_de,
            'mo_ta': mo_ta,
            'gach_1': bullets[0],
            'gach_2': bullets[1],
            'gach_3': bullets[2],
            'gach_4': bullets[3],
            'gach_5': bullets[4],
            'tu_khoa': tu_khoa,
            'trang_thai': trang_thai,
            'truong_can_bo_sung': truong_can_bo_sung
        }
        rows.append(row_dict)
        
    out_df = pd.DataFrame(rows)
    
    # Save CSV with UTF-8 BOM
    out_df.to_csv('nhap_hang_loat.csv', index=False, encoding='utf-8-sig')
    
    # Save Excel
    out_df.to_excel('nhap_hang_loat.xlsx', index=False, engine='openpyxl')
    print("Generated nhap_hang_loat.csv and nhap_hang_loat.xlsx successfully.")

if __name__ == '__main__':
    generate_catalog()
