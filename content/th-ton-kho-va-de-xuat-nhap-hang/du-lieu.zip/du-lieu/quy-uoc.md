# Quy ước tính toán (giả định) — bài 07

Cửa hàng GIẢ (tạp hóa / vật tư / mỹ phẩm), 60 mã hàng. Dữ liệu 12 tháng: 2025-11 đến 2026-10. Tham số nằm trong `tham-so.json`.

## Làm sạch (agent tự quyết, nhưng phải ghi lại vào loi-du-lieu.csv)
- Nhu cầu bán của tháng = tổng XUAT là bán hàng trong tháng, trừ đi số trả hàng (số âm CÓ ghi chú khách trả).
- Không tính vào nhu cầu: hủy hàng hết hạn, xuất dùng nội bộ, DIEU_CHINH kiểm kê (nhưng vẫn trừ vào tồn).
- Ca không chắc (số âm không ghi chú, số lượng gấp bất thường, thiếu số lượng, đơn sỉ một lần, ngày ở tương lai): ghi CẦN NGƯỜI QUYẾT, không tự bịa.
- Ngày viết lẫn lộn: dd/mm/yyyy, d/m/yy, yyyy-mm-dd (kiểu Việt Nam: ngày trước tháng). Mã hàng viết thường/ có dấu gạch/ khoảng trắng thì chuẩn hóa; dòng thiếu mã thì dò theo tên.

## Công thức cố định (không để mô hình tự đổi)
1. Tồn hệ thống chạy = tồn đầu kỳ + nhập − xuất (đã làm sạch). Ngày "hết hàng" = ngày tồn cuối ngày ≤ 0.
2. Tháng "cụt hàng" = tháng có từ 7 ngày hết hàng trở lên. Doanh số tháng đó bị cụt giả tạo, KHÔNG đưa vào trung bình (coi như thiếu số liệu, không phải 0).
3. Dự báo nhu cầu tháng tới F = trung bình của 3 tháng hợp lệ gần nhất (hợp lệ = đã bán + không cụt hàng). Có ít hơn 3 tháng hợp lệ: lấy trung bình số tháng có và gắn cờ DU_LIEU_NGAN.
4. Độ lệch chuẩn σ (đơn vị/tháng) = độ lệch chuẩn mẫu (n−1) của tối đa 6 tháng hợp lệ gần nhất. Dưới 3 tháng: σ = 0,5 × F (giả định, ghi cờ).
5. Tồn kho an toàn SS = Z × σ × √(T/30), T = thời gian giao (ngày), Z = 1.645 (mức phục vụ 95%). Làm tròn lên. Giả định: thời gian giao cố định (không có dữ liệu độ lệch thời gian giao), nhu cầu các tháng độc lập.
6. Điểm đặt hàng lại ROP = F/30 × T + SS. Làm tròn lên.
7. Số lượng cần nhập (chưa xét ngân sách) = max(0, F + SS − tồn kiểm kê − hàng đang về), làm tròn LÊN theo bội số quy cách đặt.
8. Phân loại ABC theo giá trị tiêu thụ 12 tháng = nhu cầu 12 tháng đã làm sạch × giá vốn hiện tại. Xếp giảm dần. Mặt hàng nào mà tổng giá trị các mặt hàng đứng TRƯỚC nó chưa đạt 80% tổng thì là A, chưa đạt 95% là B, còn lại C.
9. Cảnh báo (mỗi mã đúng một nhãn, ưu tiên từ trên xuống): HET_HANG (tồn kiểm kê = 0) > SAP_HET (0 < tồn ≤ ROP) > TON_LAU (số ngày tồn = tồn / (F/30) > 120, hoặc không bán ngày nào trong 90 ngày cuối mà tồn > 0) > BAN_CHAM (nhu cầu trung bình tháng < 3 đơn vị) > OK.
10. Tồn hiện tại để tính = số kiểm kê 2026-10-31 (file ton-kiem-ke). Chênh giữa tồn hệ thống và kiểm kê phải được liệt kê và giải thích bằng lỗi dữ liệu nếu được.

## Dự báo ngây thơ (mốc so sánh) và giữ lại
- Mốc 1: "bằng tháng liền trước" (doanh số thô tháng trước, không làm sạch).
- Mốc 2: "cùng kỳ năm trước": CHỈ có thể làm cho tháng 2026-11 (lấy 2025-11). Không làm được cho hai tháng giữ lại vì chỉ có 12 tháng dữ liệu. Phải nói rõ điều này.
- Giữ lại (hold-out): 2026-09 và 2026-10. Dự báo mỗi tháng chỉ dùng dữ liệu TRƯỚC tháng đó. Đo trên các mã-tháng không bị cụt hàng và có ít nhất 3 tháng hợp lệ trước đó. Chỉ số: MAE (đơn vị) và WAPE = Σ|F−thực| / Σ thực, so với mốc 1.

## Ngân sách
- Tổng tiền vốn = Σ (số lượng đề xuất × giá vốn hiện tại). Không được vượt `ngan_sach_nhap_vnd` trong tham-so.json.
- Nếu số cần nhập chưa xét ngân sách vượt ngân sách: agent đề xuất thứ tự ưu tiên và phần cắt, giải thích; người quyết định số cuối.
