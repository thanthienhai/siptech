# BÁO CÁO TỔNG HỢP DOANH THU BÁN HÀNG THÁNG 11/2026

**Kính gửi:** Ban Giám đốc Công ty TNHH Mẫu An Phát  
**Người lập:** Trợ lý Kế toán Quản trị  
**Kỳ báo cáo:** Tháng 11/2026 (01/11/2026 - 30/11/2026)  
**Ngày lập báo cáo:** 21/11/2026  

---

## 1. TỔNG QUAN KẾT QUẢ KINH DOANH THÁNG 11/2026

- **Tổng doanh thu hợp nhất toàn công ty:** **1,503,750,000 VNĐ**
- **Tổng số lượt giao dịch bán hàng hợp lệ:** **877 giao dịch** (chỉ tính các dòng trạng thái `OK` và `SUY_RA`)
- **Số chi nhánh gửi báo cáo:** 6/6 chi nhánh (Hà Nội, Hải Phòng, Đà Nẵng, Cần Thơ, Biên Hòa, Nha Trang)
- **Số giao dịch cần người quyết định (tạm giữ ngoài tổng hợp):** 3 giao dịch tại chi nhánh Hải Phòng (tổng giá trị **7,640,000 VNĐ** do ngày tháng mơ hồ `11/10/2026`)
- **Số giao dịch trùng lặp đã loại bỏ:** 5 giao dịch (Hải Phòng 3 dòng = 1,615,000 VNĐ; Nha Trang 2 dòng = 5,880,000 VNĐ)
- **Số giao dịch ngoài kỳ (tháng 10) đã bóc tách:** 4 giao dịch tại Hải Phòng (tổng giá trị **5,526,000 VNĐ**)

## 2. BÁO CÁO DOANH THU THEO CHI NHÁNH

| Mã CN | Tên chi nhánh | Số dòng GD | Doanh thu hợp nhất (VNĐ) | Tỷ trọng | Ghi chú |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **HN** | Hà Nội | 151 | 224,799,000 | 14.95% | Số thực tính khớp dòng chi tiết (file ghi sai tổng +100k) |
| **HP** | Hải Phòng | 142 | 253,599,000 | 16.86% | Đã trừ 3 dòng trùng, 4 đơn tháng 10, tạm giữ 3 đơn mơ hồ |
| **DN** | Đà Nẵng | 161 | 285,924,000 | 19.01% | Gồm 1 đơn trả lại (-495k); ngày chuẩn hóa MM/DD/YYYY |
| **CT** | Cần Thơ | 118 | 214,846,000 | 14.29% | Gồm 13 tr Combo quà Tết; thiếu dữ liệu 15-21/11 |
| **BH** | Biên Hòa | 150 | 269,037,000 | 17.89% | Đã loại 5 dòng cộng tuần; chuẩn hóa 3 ngày Excel đảo |
| **NT** | Nha Trang | 155 | 255,545,000 | 16.99% | Đã trừ 2 dòng trùng; giữ nguyên 2 đơn lệch thành tiền |
| **TỔNG** | **Toàn công ty** | **877** | **1,503,750,000** | **100.00%** | |

## 3. BÁO CÁO DOANH THU THEO SẢN PHẨM

| Mã SP | Tên sản phẩm | Số lượng bán | Doanh thu (VNĐ) | Tỷ trọng | Nhận xét |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **CHUA_XAC_DINH** | Chưa xác định | 20 | 13,000,000 | 0.86% | Sản phẩm lạ bán tại Cần Thơ (cần làm rõ) |
| **SP01** | Gạo ST25 túi 5kg | 1,389 | 228,313,000 | 15.18% | Sản phẩm danh mục chuẩn |
| **SP02** | Nước mắm truyền thống chai 500ml | 1,323 | 89,616,000 | 5.96% | Sản phẩm danh mục chuẩn |
| **SP03** | Cà phê rang xay 500g | 1,698 | 246,427,000 | 16.39% | Sản phẩm danh mục chuẩn |
| **SP04** | Trà sen 200g | 1,531 | 184,668,000 | 12.28% | Sản phẩm danh mục chuẩn |
| **SP05** | Mật ong rừng 250ml | 1,246 | 230,101,000 | 15.30% | Sản phẩm danh mục chuẩn |
| **SP06** | Hạt điều rang muối 500g | 1,441 | 304,630,000 | 20.26% | Sản phẩm danh mục chuẩn |
| **SP07** | Bánh tráng muối tôm 250g | 1,617 | 61,410,000 | 4.08% | Sản phẩm danh mục chuẩn |
| **SP08** | Dầu dừa ép lạnh 250ml | 1,539 | 145,585,000 | 9.68% | Sản phẩm danh mục chuẩn |
| **TỔNG** | | | **1,503,750,000** | **100.00%** | |

## 4. KẾT QUẢ ĐỐI CHIẾU VÀ GIẢI TRÌNH CHÊNH LỆCH DỮ LIỆU

Bảng đối chiếu giữa số tổng do chi nhánh tự ghi, tổng toàn bộ dòng dữ liệu đọc được và tổng đưa vào báo cáo hợp nhất:

| Chi nhánh | Tổng file ghi (VNĐ) | Tổng dòng đọc được (VNĐ) | Tổng hợp nhất (VNĐ) | Chênh lệch (VNĐ) | Nguyên nhân chênh lệch |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **HN** | 224,899,000 | 224,799,000 | 224,799,000 | 100,000 | File ghi cao hơn thực tế chi tiết 100,000đ do kế toán chi nhánh gõ tay sai tổng cộng cuối bảng (ghi 224,899,000đ nhưng thực tính 151 dòng là 224,799,000đ). |
| **HP** | 268,380,000 | 268,380,000 | 253,599,000 | 14,781,000 | File ghi cao hơn hợp nhất 14,781,000đ do: 3 dòng trùng (1,615,000đ) + 4 đơn tháng 10 nhập trễ (5,526,000đ) + 3 đơn ngày 11/10/2026 mơ hồ tạm treo (7,640,000đ). |
| **DN** | 285,924,000 | 285,924,000 | 285,924,000 | 0 | Khớp 100%. File tự động tính đúng tổng, bao gồm cả đơn hàng trả lại RT-0130 (-495,000đ). |
| **CT** | 214,846,000 | 214,846,000 | 214,846,000 | 0 | Khớp 100%. Doanh thu hợp nhất phản ánh toàn bộ 118 dòng bán hàng thực tế (bao gồm 2 đơn CT-0038 và CT-0056 tổng 13,000,000đ). |
| **BH** | 269,037,000 | 269,037,000 | 269,037,000 | 0 | Khớp 100%. File có 5 dòng cộng tuần trung gian và tổng tháng 269,037,000đ khớp chuẩn với tổng 150 dòng bán hàng. |
| **NT** | 261,425,000 | 261,425,000 | 255,545,000 | 5,880,000 | File ghi cao hơn hợp nhất 5,880,000đ do chi nhánh nhập trùng 2 dòng (NT/0087 và NT/0142). Riêng 2 đơn tính sai thành tiền (+100.000đ ở đơn NT/0068 và NT/0143) giữ nguyên theo số chi nhánh ghi. |

## 5. CÁC VẤN ĐỀ DỮ LIỆU VÀ RỦI RO PHÁT HIỆN

Qua quá trình rà soát và kiểm toán chi tiết dữ liệu 6 file Excel, trợ lý kế toán quản trị phát hiện các vấn đề nghiêm trọng sau:

1. **Rủi ro trùng lặp hóa đơn (Hải Phòng, Nha Trang):**
   - Hải Phòng có 3 hóa đơn trùng lặp (HD89632, HD45618, HD17042) làm đội khống doanh thu **1,615,000 VNĐ**.
   - Nha Trang có 2 chứng từ trùng lặp (NT/0087, NT/0142) làm đội khống doanh thu **5,880,000 VNĐ**.
   -> *Đề nghị:* Cần kiểm tra lại hệ thống xuất dữ liệu hoặc quy trình nhập liệu thủ công tại 2 chi nhánh này để tránh ghi nhận khống doanh thu.

2. **Đơn hàng ngoài kỳ hạch toán (Hải Phòng):**
   - Chi nhánh đưa 4 đơn hàng phát sinh từ 27/10 đến 31/10/2026 vào báo cáo tháng 11 với lý do 'nhập trễ', giá trị **5,526,000 VNĐ**.
   -> *Đề nghị:* Phải hạch toán bổ sung vào kỳ tháng 10/2026, không được gộp vào doanh thu tháng 11 làm sai lệch số liệu kỳ hiện tại.

3. **Ngày tháng mơ hồ, có dấu hiệu nhầm lẫn định dạng MM/DD và DD/MM:**
   - Hải Phòng có 3 đơn hàng ghi ngày `11/10/2026` (tổng **7,640,000 VNĐ**). Không rõ là ngày trong kỳ hay ngoài kỳ bị gõ theo chuẩn đảo MM/DD. Đang tạm treo trạng thái `CAN_NGUOI_QUYET`.
   - Biên Hòa có 3 dòng bị phần mềm Excel tự động hiểu lộn thành ngày tháng khác. Đã suy luận được ngày đúng nhờ số thứ tự phiếu và dòng cộng tuần.
   - Đà Nẵng lập toàn bộ theo chuẩn `MM/DD/YYYY`, Nha Trang tháng 10 lập theo `DD-MM-YY`, tháng 11 lập theo chuẩn `YYYY-MM-DD`.

4. **Lỗi tính toán sai số học và gõ tay số tổng cộng:**
   - Hà Nội gõ tay số tổng cộng cuối bảng lệch thừa **100.000 VNĐ** so với tổng chi tiết.
   - Nha Trang có 2 đơn hàng có Thành tiền lệch so với SL x Đơn giá (+50.000 VNĐ mỗi đơn, tổng lệch **+100.000 VNĐ** ở đơn NT/0068 và NT/0143). Kế toán giữ nguyên số tiền chi nhánh ghi theo nguyên tắc thận trọng nhưng yêu cầu giải trình.

5. **Thiếu dữ liệu nghiêm trọng và bán hàng ngoài danh mục (Cần Thơ):**
   - Chi nhánh Cần Thơ hoàn toàn không có dữ liệu bán hàng trong 7 ngày liên tiếp từ ngày **15/11/2026 đến 21/11/2026**.
   - Xuất hiện mặt hàng lạ **'Combo quà Tết 2026'** tại 2 đơn hàng CT-0038 và CT-0056 với tổng giá trị **13,000,000 VNĐ** chưa có trong danh mục sản phẩm của công ty.

## 6. DANH SÁCH VIỆC CẦN HỎI LẠI CHI NHÁNH VÀ KIẾN NGHỊ

Chi tiết các câu hỏi đã được kết xuất tại file `ra/viec_can_hoi.csv`. Tóm tắt nội dung trọng tâm cần làm việc ngay:

1. **Chi nhánh Hà Nội:** Xác nhận lại con số tổng doanh thu chính xác là **224,799,000 VNĐ** (theo 151 dòng chi tiết), điều chỉnh số tổng gõ tay 224,899,000 VNĐ.
2. **Chi nhánh Hải Phòng:**
   - Xác nhận xóa 3 hóa đơn trùng (HD89632, HD45618, HD17042) giá trị 1,615,000 VNĐ.
   - Xác nhận chuyển 4 đơn tháng 10 (5,526,000 VNĐ) về hạch toán bổ sung cho tháng 10.
   - Xác nhận ngày thực tế của 3 đơn ghi `11/10/2026`: nếu trong kỳ thì bổ sung vào doanh thu tháng 11 (**+7,640,000 VNĐ**); nếu ngoài kỳ thì chuyển sang tháng 10.
3. **Chi nhánh Cần Thơ:**
   - Giải trình lý do gián đoạn bán hàng từ ngày 15/11 đến 21/11/2026 (chi nhánh đóng cửa hay sót file bán hàng?).
   - Giải trình cơ cấu thành phần của mặt hàng 'Combo quà Tết 2026' (đơn giá 650.000đ) để kế toán quản trị bóc tách phân bổ về 8 sản phẩm chuẩn, hoặc trình Ban Giám đốc phê duyệt mã sản phẩm mới.
4. **Chi nhánh Nha Trang:**
   - Xác nhận xóa 2 chứng từ trùng (NT/0087, NT/0142) giá trị 5,880,000 VNĐ.
   - Kiểm tra và giải trình tại sao đơn NT/0068 và NT/0143 lại ghi thành tiền lệch +50.000đ mỗi đơn so với số lượng nhân đơn giá.
5. **Chi nhánh Biên Hòa & Đà Nẵng:** Nhắc nhở quy chuẩn lại định dạng ngày tháng theo chuẩn quốc gia `DD/MM/YYYY` hoặc `YYYY-MM-DD` để tránh nhầm lẫn khi tổng hợp tự động.

---
*Báo cáo được tạo tự động bởi hệ thống script `gop.py` dựa trên dữ liệu kế toán thực tế.*  
