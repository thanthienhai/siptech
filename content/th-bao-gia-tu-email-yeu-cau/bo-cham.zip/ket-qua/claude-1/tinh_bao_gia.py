# -*- coding: utf-8 -*-
"""
tinh_bao_gia.py - Soạn báo giá NHÁP cho 12 yêu cầu R01..R12 (công ty giả An Phát Demo).

Mọi phép tính tiền do code này làm (tra bậc giá, quy đổi đơn vị, gộp dòng, chiết khấu,
phí giao, VAT, tổng cộng). Ghi vào xlsx GIÁ TRỊ SỐ (không công thức).

Cách dùng (chạy trong thư mục chứa bang-gia.xlsx, mau-bao-gia.xlsx):
    python tinh_bao_gia.py            # tạo dau-ra/Rxx-*.{xlsx,txt}, kiểm tra, in bảng tóm tắt
    python tinh_bao_gia.py --check    # chỉ chạy kiểm tra trên file đã có

Phần SPECS ở cuối là kết quả đọc & phân loại 12 yêu cầu (mặt hàng, đơn vị khách ghi,
câu hỏi, việc cần người quyết). Code chỉ nhận (mã hàng, số lượng, đơn vị khách ghi).
"""
import math
import os
import re
import shutil
import sys
import unicodedata
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP

import openpyxl
from openpyxl.styles import Alignment

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

BASE = os.path.dirname(os.path.abspath(__file__))
F_BANGGIA = os.path.join(BASE, "bang-gia.xlsx")
F_MAU = os.path.join(BASE, "mau-bao-gia.xlsx")
OUT = os.path.join(BASE, "dau-ra")

# ---- Chính sách (chinh-sach-chiet-khau.docx, dieu-kien-giao-hang.txt) ----
NHOM_THIET_BI = "Thiết bị"
CK_NGUONG_1, CK_PCT_1 = 10_000_000, 2      # từ 10 triệu đến dưới 30 triệu: 2%
CK_NGUONG_2, CK_PCT_2 = 30_000_000, 4      # từ 30 triệu: 4%
CK_THEM_TOI_DA = 2                         # nhân viên được đồng ý thêm tối đa 2%
CK_TONG_TOI_DA = 5                         # tổng chiết khấu nhân viên tự quyết <= 5%
MIEN_PHI_TU = 3_000_000                    # nội thành: miễn phí nếu sau CK, trước VAT >= 3 triệu
PHI_NOI_THANH = 40_000
VALID_STATUS = ("SAN_SANG", "THIEU_THONG_TIN", "CAN_NGUOI_QUYET")

NOI_THANH_PATTERNS = [  # đã bỏ dấu, chữ thường
    r"\bba dinh\b", r"\bhoan kiem\b", r"\bdong da\b", r"\bhai ba trung\b", r"\bcau giay\b",
    r"\bthanh xuan\b", r"\btay ho\b", r"\blong bien\b", r"\bhoang mai\b", r"\bnam tu liem\b",
    r"\bbac tu liem\b", r"\bha dong\b",
    r"\bquan\s*(1|3|5|7|10)\b", r"\bbinh thanh\b", r"\bphu nhuan\b", r"\btan binh\b", r"\bgo vap\b",
]


# ---------------------------------------------------------------- tiện ích
def lam_tron(x):
    """Làm tròn đến đồng, 0,5 làm tròn lên."""
    return int(Decimal(x).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def fmt(n):
    return f"{n:,}".replace(",", ".") + "đ"


def fmt_n(n):
    return f"{n:,}".replace(",", ".")


def bo_dau(s):
    s = unicodedata.normalize("NFD", s.lower().replace("đ", "d"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def khu_vuc(dia_chi):
    """'noi_thanh' | 'ngoai_tinh' | 'chua_biet' theo dieu-kien-giao-hang.txt mục 1."""
    if not dia_chi:
        return "chua_biet"
    t = bo_dau(dia_chi)
    return "noi_thanh" if any(re.search(p, t) for p in NOI_THANH_PATTERNS) else "ngoai_tinh"


# ---------------------------------------------------------------- đọc dữ liệu
def doc_bang_gia():
    wb = openpyxl.load_workbook(F_BANGGIA, data_only=True)
    gia = {}
    for r in wb["BangGia"].iter_rows(min_row=4, values_only=True):
        if not r[0]:
            continue
        ma, ten, nhom, dvt, g1, t2, g2, t3, g3, kho = r[:10]
        gia[ma] = dict(ma=ma, ten=ten, nhom=nhom, dvt=dvt, g1=g1, t2=t2, g2=g2, t3=t3, g3=g3, kho=kho)
    quydoi = {}
    for r in wb["QuyDoi"].iter_rows(min_row=3, values_only=True):
        if r[0]:
            quydoi[(r[0], r[1].strip().lower())] = int(r[2])
    return gia, quydoi


def doc_tham_so():
    ws = openpyxl.load_workbook(F_MAU, data_only=True)["Tham số"]
    p = {r[0]: r[1] for r in ws.iter_rows(min_row=2, values_only=True) if r[0]}
    ngay = date.fromisoformat(str(p["ngay_bao_gia"])[:10])
    hl = int(p["hieu_luc_ngay"])
    return dict(vat=Decimal(str(p["vat_percent"])), ngay=ngay, hieu_luc=hl,
                het_han=ngay + timedelta(days=hl))


def don_gia(item, sl):
    if sl >= item["t3"]:
        return item["g3"], 3
    if sl >= item["t2"]:
        return item["g2"], 2
    return item["g1"], 1


# ---------------------------------------------------------------- lõi tính tiền
def tinh(dong_vao, gia, quydoi, ck_them=0, dia_chi=None, vat=Decimal(10)):
    """
    dong_vao: [(ma_hang, so_luong, don_vi_khach_ghi)]
    Quy đổi sang ĐVT gốc (chỉ khi QuyDoi có), gộp dòng trùng mã, tra bậc giá theo SL của chính mã đó.
    """
    nhom = {}
    for ma, sl, dv in dong_vao:
        if ma not in gia:
            raise ValueError(f"Mã {ma} không có trong bảng giá - không được lập dòng")
        item = gia[ma]
        dv_l = dv.strip().lower()
        if dv_l == item["dvt"].lower():
            sl_goc, he_so = sl, 1
        elif (ma, dv_l) in quydoi:
            he_so = quydoi[(ma, dv_l)]
            sl_goc = sl * he_so
        else:
            raise ValueError(f"{ma}: không có quy đổi '{dv}' -> '{item['dvt']}' trong sheet QuyDoi")
        nhom.setdefault(ma, []).append((sl, dv_l, he_so, sl_goc))

    dong = []
    for ma, phan in nhom.items():
        item = gia[ma]
        tong = sum(p[3] for p in phan)
        dg, bac = don_gia(item, tong)
        mo_ta = []
        for sl, dv, he_so, sl_goc in phan:
            mo_ta.append(f"{sl} {dv}" if he_so == 1 else f"{sl} {dv} (= {sl_goc} {item['dvt']})")
        ghi_chu = []
        if len(phan) > 1:
            ghi_chu.append(" + ".join(mo_ta) + f" = {tong} {item['dvt']}")
        elif phan[0][2] != 1:
            ghi_chu.append(f"{phan[0][0]} {phan[0][1]} = {tong} {item['dvt']}")
        ghi_chu.append(f"Giá bậc {bac}")
        if item["kho"] != "Còn hàng":
            ghi_chu.append(f"Kho: {item['kho']} - ngày có hàng do kho/phòng mua hàng xác nhận")
        dong.append(dict(ma=ma, ten=item["ten"], dvt=item["dvt"], nhom=item["nhom"], sl=tong,
                         don_gia=dg, bac=bac, thanh_tien=tong * dg, kho=item["kho"],
                         ghi_chu="; ".join(ghi_chu)))

    cong_hang = sum(d["thanh_tien"] for d in dong)
    co_so_ck = sum(d["thanh_tien"] for d in dong if d["nhom"] != NHOM_THIET_BI)
    pct_don = CK_PCT_2 if cong_hang >= CK_NGUONG_2 else CK_PCT_1 if cong_hang >= CK_NGUONG_1 else 0
    if ck_them and (ck_them > CK_THEM_TOI_DA or pct_don + ck_them > CK_TONG_TOI_DA):
        raise ValueError("Chiết khấu thêm vượt thẩm quyền nhân viên - phải chuyển người quyết, không được áp")
    pct_ck = pct_don + ck_them
    chiet_khau = lam_tron(Decimal(co_so_ck) * pct_ck / 100)     # làm tròn MỘT lần
    sau_ck = cong_hang - chiet_khau

    kv = khu_vuc(dia_chi)
    if kv == "noi_thanh":
        phi = 0 if sau_ck >= MIEN_PHI_TU else PHI_NOI_THANH
    else:
        phi = None                                              # theo thỏa thuận / chưa biết địa chỉ
    truoc_vat = sau_ck + (phi or 0)
    tien_vat = lam_tron(Decimal(truoc_vat) * vat / 100)
    return dict(dong=dong, cong_hang=cong_hang, co_so_ck=co_so_ck, pct_don=pct_don, ck_them=ck_them,
                pct_ck=pct_ck, chiet_khau=chiet_khau, sau_ck=sau_ck, khu_vuc=kv, phi=phi,
                truoc_vat=truoc_vat, vat_pct=vat, vat=tien_vat, tong=truoc_vat + tien_vat)


def trang_thai(spec):
    t = []
    if spec["cau_hoi"]:
        t.append("THIEU_THONG_TIN")
    if spec["cho_quyet"]:
        t.append("CAN_NGUOI_QUYET")
    return ";".join(t) if t else "SAN_SANG"


# ---------------------------------------------------------------- ghi chú tổng
def ghi_chu_tong(spec, kq):
    pct_vat = f"{kq['vat_pct'].normalize():f}"
    mot_phan = bool(spec["chua_bao_gia"])
    n = {}
    if kq["pct_ck"] == 0:
        n["ck"] = f"Không có chiết khấu (đơn dưới {fmt_n(CK_NGUONG_1)}đ)" if kq["cong_hang"] < CK_NGUONG_1 \
            else "Không có chiết khấu"
    else:
        cs = fmt_n(kq["co_so_ck"])
        if kq["ck_them"]:
            n["ck"] = (f"{kq['pct_ck']}% trên {cs}đ (dòng không thuộc nhóm Thiết bị) = "
                       f"{kq['pct_don']}% theo giá trị đơn + {kq['ck_them']}% thêm trong thẩm quyền")
        else:
            n["ck"] = f"{kq['pct_ck']}% theo giá trị đơn, trên {cs}đ (dòng không thuộc nhóm Thiết bị)"
    if kq["khu_vuc"] == "noi_thanh":
        if kq["phi"] == 0:
            n["phi"] = f"Nội thành, đơn sau chiết khấu từ {fmt_n(MIEN_PHI_TU)}đ: miễn phí"
        else:
            n["phi"] = f"Nội thành, đơn sau chiết khấu dưới {fmt_n(MIEN_PHI_TU)}đ: {fmt_n(PHI_NOI_THANH)}đ/đơn"
        n["phi"] += "; kế toán kiểm tra cách tính thuế cho dòng phí"
        if mot_phan:
            n["phi"] += "; tạm tính theo các dòng đã báo giá, tính lại khi đủ dòng"
    elif kq["khu_vuc"] == "ngoai_tinh":
        n["phi"] = "Phí giao hàng theo thỏa thuận (ngoại thành/ngoại tỉnh) - CẦN NGƯỜI QUYẾT, chưa tính vào tổng"
    else:
        n["phi"] = "Chưa có địa chỉ giao - chưa tính phí giao hàng, cần hỏi khách"
    n["vat"] = f"{pct_vat}% - mức VAT theo tham số, cần kiểm với kế toán trước khi gửi"
    n["tong"] = "TẠM TÍNH - chưa gồm các mục chưa báo giá" if mot_phan else ""
    if not kq["dong"]:
        n["tong"] = "Chưa có dòng hàng nào đủ điều kiện báo giá"
    if kq["khu_vuc"] != "noi_thanh":
        n["tong"] = (n["tong"] + "; " if n["tong"] else "") + "chưa gồm phí giao hàng"
    return n


# ---------------------------------------------------------------- xlsx
def ghi_xlsx(spec, kq, tham_so, status, duong_dan):
    shutil.copyfile(F_MAU, duong_dan)
    wb = openpyxl.load_workbook(duong_dan)
    ws = wb["Báo giá"]
    kv_txt = {"noi_thanh": " (nội thành)", "ngoai_tinh": " (ngoại thành/ngoại tỉnh)", "chua_biet": ""}[kq["khu_vuc"]]
    ws["C5"] = spec["khach"]
    ws["C6"] = (spec["dia_chi"] + kv_txt) if spec["dia_chi"] else spec["dia_chi_thieu"]
    ws["C7"] = spec["tham_chieu"]
    ws["C8"] = (f"{tham_so['ngay']:%d/%m/%Y} / hiệu lực {tham_so['hieu_luc']} ngày "
                f"(đến hết {tham_so['het_han']:%d/%m/%Y})")
    ws["C9"] = status
    ws["C10"] = None                                   # người duyệt điền
    if len(kq["dong"]) > 15:
        raise ValueError("Quá 15 dòng - mẫu chỉ có 15 dòng hàng")
    for i, d in enumerate(kq["dong"]):
        r = 14 + i
        ws.cell(r, 1, i + 1)
        ws.cell(r, 2, d["ma"])
        ws.cell(r, 3, d["ten"])
        ws.cell(r, 4, d["dvt"])
        ws.cell(r, 5, d["sl"])
        ws.cell(r, 6, d["don_gia"])
        ws.cell(r, 7, d["thanh_tien"])
        ws.cell(r, 8, d["ghi_chu"])
        for c in (5, 6, 7):
            ws.cell(r, c).number_format = "#,##0"
        ws.cell(r, 8).alignment = Alignment(wrap_text=True, vertical="top")
        ws.cell(r, 3).alignment = Alignment(wrap_text=True, vertical="top")
    n = ghi_chu_tong(spec, kq)
    tong_rows = [
        (29, kq["cong_hang"], ""),
        (30, kq["chiet_khau"], n["ck"]),
        (31, kq["phi"], n["phi"]),
        (32, kq["truoc_vat"], "Gồm tiền hàng sau chiết khấu + phí giao hàng (nếu đã tính)"),
        (33, kq["vat"], n["vat"]),
        (34, kq["tong"], n["tong"]),
    ]
    for r, v, note in tong_rows:
        ws.cell(r, 7).value = v                        # None => để trống (phí chưa tính)
        ws.cell(r, 7).number_format = "#,##0"
        if note:
            ws.cell(r, 8, note)
            ws.cell(r, 8).alignment = Alignment(wrap_text=True, vertical="top")
    # Dòng chú thích ngoài bảng (row 11, 12 của mẫu để trống)
    def ghi_chu_dong(row, text):
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=8)
        ws.cell(row, 1, text).alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = 15 * max(1, math.ceil(len(text) / 150))
    if spec["chua_bao_gia"]:
        ghi_chu_dong(11, "CHƯA BÁO GIÁ: " + " | ".join(f"{t} - {ly}" for t, ly in spec["chua_bao_gia"]))
    ql = [x[0] for x in spec["cho_quyet"]]
    if ql:
        ghi_chu_dong(12, "CẦN NGƯỜI QUYẾT (không hứa với khách): " + " | ".join(ql))
    wb.save(duong_dan)


# ---------------------------------------------------------------- email & câu hỏi
def viet_email(spec, kq, tham_so, status):
    xh = spec["xh"]
    pct_vat = f"{kq['vat_pct'].normalize():f}"
    L = []
    L.append(f"[EMAIL NHÁP - chưa gửi. Trạng thái: {status}. Người duyệt kiểm tra trước khi gửi; "
             f"mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]")
    L.append(f"Tiêu đề: {spec['tieu_de']}")
    L.append("")
    L.append(spec["chao"])
    L.append("")
    L.append(spec["mo_dau"])
    L.append("")
    muc = iter(range(1, 10))
    if kq["dong"]:
        L.append(f"{next(muc)}. Nội dung đã báo giá (ngày {tham_so['ngay']:%d/%m/%Y}, hiệu lực {tham_so['hieu_luc']} ngày, "
                 f"đến hết {tham_so['het_han']:%d/%m/%Y}; giá chưa gồm VAT):")
        for d in kq["dong"]:
            L.append(f"- {d['ten']} ({d['ma']}): {d['sl']} {d['dvt']} x {fmt_n(d['don_gia'])}đ = "
                     f"{fmt(d['thanh_tien'])}")
            sub = [g for g in d["ghi_chu"].split("; ") if not g.startswith("Giá bậc")]
            if sub:
                L.append("    (" + "; ".join(sub) + ")")
        L.append(f"- Cộng tiền hàng: {fmt(kq['cong_hang'])}")
        if kq["pct_ck"]:
            if kq["ck_them"]:
                ck_txt = (f"Chiết khấu {kq['pct_ck']}% ({kq['pct_don']}% theo giá trị đơn + {kq['ck_them']}% thêm), "
                          f"tính trên các dòng không thuộc nhóm thiết bị")
            else:
                ck_txt = f"Chiết khấu {kq['pct_ck']}% theo giá trị đơn, tính trên các dòng không thuộc nhóm thiết bị"
            L.append(f"- {ck_txt}: -{fmt(kq['chiet_khau'])}")
        else:
            L.append("- Chiết khấu: không có (đơn chưa đạt mức chiết khấu theo giá trị đơn)")
        if kq["khu_vuc"] == "noi_thanh":
            L.append("- Phí giao hàng: " + ("miễn phí (nội thành, đơn sau chiết khấu từ 3.000.000đ)" if kq["phi"] == 0
                     else f"{fmt(kq['phi'])} (nội thành, đơn sau chiết khấu dưới 3.000.000đ)"))
        elif kq["khu_vuc"] == "ngoai_tinh":
            L.append("- Phí giao hàng: phí giao hàng theo thỏa thuận (giao ngoại thành/ngoại tỉnh, "
                     "phí theo cước vận chuyển; sẽ có xác nhận) - chưa tính vào tổng bên dưới")
        else:
            L.append(f"- Phí giao hàng: chưa tính vì chưa có địa chỉ giao ({xh} cho bên em xin địa chỉ nhé)")
        L.append(f"- Cộng trước VAT: {fmt(kq['truoc_vat'])}")
        L.append(f"- VAT {pct_vat}% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi): {fmt(kq['vat'])}")
        tong_lbl = "Tổng cộng (tạm tính, chưa gồm các mục chưa báo giá)" if spec["chua_bao_gia"] else "Tổng cộng"
        L.append(f"- {tong_lbl}: {fmt(kq['tong'])}")
        if spec["chua_bao_gia"]:
            L.append("  Chiết khấu và phí giao hàng sẽ được tính lại khi bổ sung các mục còn lại.")
        if spec.get("goi_y_bac"):
            ma, sl_alt = spec["goi_y_bac"]
            d = next(x for x in kq["dong"] if x["ma"] == ma)
            gia_alt, _ = don_gia(GIA[ma], sl_alt)
            if sl_alt * gia_alt < d["thanh_tien"]:
                L.append(f"  Gợi ý: nếu lấy {sl_alt} {d['dvt']} {d['ten']} thì đơn giá còn {fmt_n(gia_alt)}đ, "
                         f"thành tiền {fmt(sl_alt * gia_alt)} (thấp hơn mua {d['sl']} {d['dvt']}: {fmt(d['thanh_tien'])}).")
        khong_san = [d for d in kq["dong"] if d["kho"] != "Còn hàng"]
        if khong_san:
            L.append("  Lưu ý tình trạng hàng: " + "; ".join(f"{d['ten']} ({d['kho']})" for d in khong_san) +
                     " - ngày có hàng do thủ kho/phòng mua hàng xác nhận, sẽ có xác nhận lịch giao của kho bằng văn bản.")
        L.append("")
    else:
        L.append(f"{next(muc)}. Hiện bên em chưa thể lập báo giá vì chưa có đủ thông tin (xem các câu hỏi bên dưới).")
        L.append("")
    if spec["chua_bao_gia"]:
        L.append(f"{next(muc)}. Nội dung CHƯA báo giá:")
        for t, ly in spec["chua_bao_gia"]:
            L.append(f"- {t}: {ly}")
        L.append("")
    if spec["cau_hoi"]:
        L.append(f"{next(muc)}. Nhờ {xh} cho bên em biết thêm:")
        for i, q in enumerate(spec["cau_hoi"], 1):
            L.append(f"   {i}. {q}")
        L.append("")
    if spec["cho_quyet"]:
        L.append(f"{next(muc)}. Các nội dung cần cấp quản lý xem xét:")
        for _, e in spec["cho_quyet"]:
            L.append(f"- {e}")
        L.append("")
    L.append("Về giao hàng: bên em chưa thể hẹn ngày/giờ giao cụ thể trong thư này; lịch giao sẽ do kho xác nhận bằng văn bản. "
             "Thanh toán: chuyển khoản trước khi giao hàng, theo điều kiện của công ty.")
    L.append("")
    L.append(f"Cảm ơn {xh}. Bên em rất mong được phục vụ.")
    L.append("")
    L.append("Trân trọng,")
    L.append("[Tên người gửi - điền khi duyệt]")
    L.append("Bộ phận kinh doanh - Công ty TNHH An Phát Demo (công ty giả, dữ liệu để học)")
    return "\n".join(L) + "\n"


def viet_cau_hoi(spec):
    if not spec["cau_hoi"]:
        return "Không có câu hỏi\n"
    return "".join(f"{i}. {q}\n" for i, q in enumerate(spec["cau_hoi"], 1))


# ---------------------------------------------------------------- tạo toàn bộ
GIA, QUYDOI = doc_bang_gia()


def tao_tat_ca():
    os.makedirs(OUT, exist_ok=True)
    ts = doc_tham_so()
    ket_qua = []
    for spec in SPECS:
        kq = tinh(spec["dong"], GIA, QUYDOI, spec.get("ck_them", 0), spec["dia_chi"], ts["vat"])
        st = trang_thai(spec)
        rid = spec["id"]
        ghi_xlsx(spec, kq, ts, st, os.path.join(OUT, f"{rid}-bao-gia.xlsx"))
        with open(os.path.join(OUT, f"{rid}-email.txt"), "w", encoding="utf-8", newline="\n") as f:
            f.write(viet_email(spec, kq, ts, st))
        with open(os.path.join(OUT, f"{rid}-cau-hoi.txt"), "w", encoding="utf-8", newline="\n") as f:
            f.write(viet_cau_hoi(spec))
        ket_qua.append((rid, st, kq["tong"], kq, spec))
    return ket_qua


# ---------------------------------------------------------------- kiểm tra độc lập
def kiem_tra():
    """Đọc lại file đã ghi, tự tính lại từ bang-gia.xlsx; trả về danh sách lỗi."""
    loi = []
    gia, quydoi = doc_bang_gia()
    ts = doc_tham_so()
    for spec in SPECS:
        rid = spec["id"]
        p = os.path.join(OUT, f"{rid}-bao-gia.xlsx")
        for suffix in ("bao-gia.xlsx", "email.txt", "cau-hoi.txt"):
            if not os.path.exists(os.path.join(OUT, f"{rid}-{suffix}")):
                loi.append(f"{rid}: thiếu file {suffix}")
        if not os.path.exists(p):
            continue
        wb = openpyxl.load_workbook(p)                       # công thức sẽ hiện dạng chuỗi '=...'
        ws = wb["Báo giá"]
        if "Tham số" not in wb.sheetnames:
            loi.append(f"{rid}: mất sheet Tham số")
        for row in ws.iter_rows():
            for c in row:
                if c.data_type == "f" or (isinstance(c.value, str) and c.value.startswith("=")):
                    loi.append(f"{rid}: {c.coordinate} là công thức")
        # tiêu đề cột & nhãn tổng giữ nguyên mẫu
        tieu_de = [ws.cell(13, c).value for c in range(1, 9)]
        if tieu_de != ["STT", "Mã hàng", "Tên hàng", "ĐVT", "Số lượng", "Đơn giá (VNĐ)", "Thành tiền (VNĐ)", "Ghi chú"]:
            loi.append(f"{rid}: tiêu đề cột bị đổi")
        nhan = [ws.cell(r, 6).value for r in range(29, 35)]
        if nhan != ["Cộng tiền hàng", "Chiết khấu", "Phí giao hàng", "Cộng trước VAT", "VAT", "Tổng cộng"]:
            loi.append(f"{rid}: nhãn dòng tổng bị đổi")
        # dòng hàng
        dong, ma_da = [], set()
        for r in range(14, 29):
            if ws.cell(r, 2).value is None:
                continue
            stt, ma, ten, dvt, sl, dg, tt = [ws.cell(r, c).value for c in range(1, 8)]
            if ma not in gia:
                loi.append(f"{rid}: dòng {r} mã {ma} không có trong bảng giá")
                continue
            if ma in ma_da:
                loi.append(f"{rid}: mã {ma} bị trùng dòng")
            ma_da.add(ma)
            it = gia[ma]
            if dvt != it["dvt"] or ten != it["ten"]:
                loi.append(f"{rid}: {ma} sai tên/ĐVT")
            if not all(isinstance(x, int) for x in (sl, dg, tt)):
                loi.append(f"{rid}: {ma} có ô tiền/số lượng không phải số nguyên")
            if sl * dg != tt:
                loi.append(f"{rid}: {ma} thành tiền {tt} != {sl} x {dg}")
            dg_dung, _ = don_gia(it, sl)
            if dg != dg_dung:
                loi.append(f"{rid}: {ma} đơn giá {dg} sai bậc (đúng {dg_dung})")
            dong.append((ma, sl, dg, tt, it["nhom"]))
        so_dong_ky_vong = len({m for m, _, _ in spec["dong"]})
        if len(dong) != so_dong_ky_vong:
            loi.append(f"{rid}: số dòng {len(dong)} != kỳ vọng {so_dong_ky_vong}")
        stts = [ws.cell(r, 1).value for r in range(14, 14 + len(dong))]
        if stts != list(range(1, len(dong) + 1)):
            loi.append(f"{rid}: STT không liên tục {stts}")
        # tổng
        g = {r: ws.cell(r, 7).value for r in range(29, 35)}
        cong = sum(d[3] for d in dong)
        if g[29] != cong:
            loi.append(f"{rid}: cộng tiền hàng {g[29]} != {cong}")
        co_so = sum(d[3] for d in dong if d[4] != NHOM_THIET_BI)
        pct = (4 if cong >= 30_000_000 else 2 if cong >= 10_000_000 else 0) + spec.get("ck_them", 0)
        ck = lam_tron(Decimal(co_so) * pct / 100)
        if g[30] != ck:
            loi.append(f"{rid}: chiết khấu {g[30]} != {ck}")
        kv = khu_vuc(spec["dia_chi"])
        if kv == "noi_thanh":
            phi_dung = 0 if cong - ck >= 3_000_000 else 40_000
            if g[31] != phi_dung:
                loi.append(f"{rid}: phí giao {g[31]} != {phi_dung}")
        elif g[31] is not None:
            loi.append(f"{rid}: phí giao phải để trống ({kv}) nhưng là {g[31]}")
        truoc = cong - ck + (g[31] or 0)
        if g[32] != truoc:
            loi.append(f"{rid}: cộng trước VAT {g[32]} != {truoc}")
        vat = lam_tron(Decimal(truoc) * ts["vat"] / 100)
        if g[33] != vat:
            loi.append(f"{rid}: VAT {g[33]} != {vat}")
        if g[34] != truoc + vat:
            loi.append(f"{rid}: tổng cộng {g[34]} != {truoc + vat}")
        # trạng thái
        st = ws["C9"].value or ""
        if not st or any(x not in VALID_STATUS for x in st.split(";")):
            loi.append(f"{rid}: trạng thái không hợp lệ '{st}'")
        # câu hỏi
        with open(os.path.join(OUT, f"{rid}-cau-hoi.txt"), encoding="utf-8") as f:
            qs = [x for x in f.read().splitlines() if x.strip()]
        if qs == ["Không có câu hỏi"]:
            co_hoi = False
        else:
            co_hoi = True
            for i, line in enumerate(qs, 1):
                if not line.startswith(f"{i}. "):
                    loi.append(f"{rid}: câu hỏi dòng {i} sai định dạng")
        if co_hoi != ("THIEU_THONG_TIN" in st.split(";")):
            loi.append(f"{rid}: trạng thái THIEU_THONG_TIN không khớp file câu hỏi")
        # email
        with open(os.path.join(OUT, f"{rid}-email.txt"), encoding="utf-8") as f:
            em = f.read()
        if "mức VAT theo tham số, cần kiểm với kế toán trước khi gửi" not in em:
            loi.append(f"{rid}: email thiếu câu về mức VAT")
        if dong and fmt(g[34]) not in em:
            loi.append(f"{rid}: email không chứa tổng cộng {fmt(g[34])}")
        if "CAN_NGUOI_QUYET" in st and "sẽ có xác nhận" not in em:
            loi.append(f"{rid}: email thiếu 'sẽ có xác nhận'")
        if re.search(r"(giao|có hàng)[^.\n]{0,40}(trước|vào|lúc)\s*\d+\s*(giờ|h)\b", em, re.I):
            loi.append(f"{rid}: email có vẻ hứa giờ giao")
    return loi


def in_tom_tat(ket_qua):
    print(f"{'Yêu cầu':8} {'Trạng thái':34} {'Số dòng':>8} {'Tổng cộng (VNĐ)':>18}")
    for rid, st, tong, kq, _ in ket_qua:
        print(f"{rid:8} {st:34} {len(kq['dong']):>8} {fmt_n(tong):>18}")


# ======================================================================================
# SPECS: kết quả đọc & phân loại 12 yêu cầu. dong = (mã hàng, số lượng, đơn vị khách ghi).
# cho_quyet = [(ghi chú nội bộ, câu nói trong email)]; chua_bao_gia = [(mục, lý do)].
# ======================================================================================
SPECS = [
    dict(
        id="R01", xh="chị", chao="Chào chị Lan,",
        khach="Công ty TNHH Cơ khí Ánh Dương (chị Lan - Phòng Hành chính, ĐT 0900 000 101, lan.mua.hang@example.com)",
        dia_chi="12 Đường Số 5, Quận Hà Đông, Hà Nội", dia_chi_thieu="",
        tham_chieu="R01 - email 'Đề nghị báo giá VPP tháng 12'",
        tieu_de="Re: Đề nghị báo giá VPP tháng 12",
        mo_dau="Cảm ơn chị đã gửi yêu cầu. Bên em gửi chị báo giá như sau. Bên em đã áp dụng mức giảm thêm 2% "
               "chị đề nghị (trong thẩm quyền của bên em).",
        dong=[("GIAY-A4-80", 25, "ram"), ("BUT-BI-TL027-XANH", 3, "hộp"), ("BANGKEO-TRONG-48", 10, "cuộn")],
        ck_them=2, chua_bao_gia=[], cau_hoi=[], cho_quyet=[],
    ),
    dict(
        id="R02", xh="anh", chao="Chào anh Dung Phat,",
        khach="Dung Phat (Zalo)",
        dia_chi=None, dia_chi_thieu="Chưa có địa chỉ giao hàng - cần hỏi khách",
        tham_chieu="R02 - tin nhắn Zalo 09:12",
        tieu_de="(Trả lời tin nhắn Zalo) Báo giá giấy A4 80 và mực HP 12A",
        mo_dau="Cảm ơn anh đã nhắn. Bên em báo giá phần đã đủ thông tin trước, phần còn lại bên em cần anh bổ sung.",
        dong=[("MUC-HP-12A", 6, "hộp")],
        chua_bao_gia=[("Giấy A4 80 gsm (GIAY-A4-80)", "chưa có số lượng")],
        cau_hoi=["Anh cần bao nhiêu ram giấy A4 80 gsm?",
                 "Địa chỉ giao hàng của anh là ở đâu (số nhà, quận/huyện, tỉnh/thành) để bên em tính phí giao?",
                 "\"Chiều anh cần\" là anh cần nhận báo giá trong chiều nay hay cần nhận hàng trong chiều nay? "
                 "(Bên em chưa thể hẹn giờ giao; lịch giao do kho xác nhận bằng văn bản.)"],
        cho_quyet=[],
    ),
    dict(
        id="R03", xh="anh/chị", chao="Chào anh/chị,",
        khach="Khách gửi từ hanh.vp@example.com (chưa rõ tên/công ty)",
        dia_chi="Tòa nhà Mẫu số 3, đường Demo, Quận Cầu Giấy, Hà Nội", dia_chi_thieu="",
        tham_chieu="R03 - email 'bao gia'",
        tieu_de="Re: bao gia",
        mo_dau="Cảm ơn anh/chị đã gửi yêu cầu. Bên em báo giá các mục đã khớp với bảng giá; hai mục còn lại bên em cần anh/chị xác nhận lại.",
        dong=[("GIAY-A4-80", 10, "ram"), ("MUC-HP-12A", 3, "hộp")],
        chua_bao_gia=[("MUC-HP-12C, 4 hộp", "mã này không có trong bảng giá; bên em không tự đoán sang mã khác"),
                      ("BUT-GEL-05-XANH, 2 hộp (mực xanh)", "mã này không có trong bảng giá")],
        cau_hoi=["Mã MUC-HP-12C không có trong bảng giá của bên em (hiện bên em có mực HP 12A và HP 78A). "
                 "Anh/chị kiểm tra lại mã/tên mực cần mua giúp bên em; và dòng 2 (MUC-HP-12C, 4 hộp) với dòng 3 "
                 "(mực HP 12A, 3 hộp) là hai loại khác nhau hay cùng một loại?",
                 "Mã BUT-GEL-05-XANH không có trong bảng giá (hiện bên em chỉ có bút gel mực đen 0.5 mm, mã BUT-GEL-05-DEN). "
                 "Anh/chị xác nhận lại mã cần mua, hoặc cho biết có muốn bên em báo giá bút gel mực đen không?"],
        cho_quyet=[],
    ),
    dict(
        id="R04", xh="anh/chị", chao="Chào anh/chị,",
        khach="Trường (người gửi: mai.hanhchinh@example.com - chưa rõ tên trường)",
        dia_chi="25 Đường Mẫu, Quận 7, TP. Hồ Chí Minh", dia_chi_thieu="",
        tham_chieu="R04 - email 'Báo giá thiết bị cho năm học mới'",
        tieu_de="Re: Báo giá thiết bị cho năm học mới",
        mo_dau="Cảm ơn anh/chị đã gửi yêu cầu. Bên em báo giá phần giấy A4 70 gsm; hai mặt hàng thiết bị hiện chưa có trong bảng giá của bên em.",
        dong=[("GIAY-A4-70", 30, "ram")],
        chua_bao_gia=[("Máy photocopy A3 đa năng, 1 cái", "chưa có trong bảng giá; không tự đặt giá, không tự thay bằng hàng khác"),
                      ("Máy chiếu độ phân giải 4K, 2 cái", "chưa có trong bảng giá; không tự đặt giá, không tự thay bằng hàng khác")],
        cau_hoi=[],
        cho_quyet=[("Máy photocopy A3 và máy chiếu 4K không có trong bảng giá -> chuyển phòng mua hàng xem có nhập được không",
                    "Hai mặt hàng máy photocopy A3 đa năng và máy chiếu 4K chưa có trong bảng giá; bên em đã chuyển phòng mua hàng "
                    "xem xét khả năng cung cấp, sẽ có xác nhận sau."),
                   ("Khách cần gấp trong tuần -> chuyển trưởng kho/giám đốc, không hứa ngày giao",
                    "Về yêu cầu cần gấp trong tuần: bên em đã chuyển bộ phận kho/quản lý xem xét, sẽ có xác nhận lịch giao bằng văn bản.")],
    ),
    dict(
        id="R05", xh="anh/chị", chao="Chào anh/chị,",
        khach="Khách gửi từ quan.vt@example.com (chưa rõ tên/công ty)",
        dia_chi="88 Đường Demo, Quận Thanh Xuân, Hà Nội", dia_chi_thieu="",
        tham_chieu="R05 - email 'RE: báo giá máy in + vật tư'",
        tieu_de="Re: báo giá máy in + vật tư",
        mo_dau="Cảm ơn anh/chị đã gửi yêu cầu. Bên em gửi báo giá theo bảng giá hiện hành và chiết khấu theo chính sách.",
        dong=[("MAY-IN-LASER-3100", 3, "cái"), ("MUC-HP-78A", 10, "hộp"), ("GIAY-A4-80", 40, "ram")],
        chua_bao_gia=[], cau_hoi=[],
        cho_quyet=[("Khách đòi giảm 25% tổng đơn (vượt thẩm quyền; dòng thiết bị không giảm) -> trưởng phòng/giám đốc quyết; báo giá chỉ áp 2%",
                    "Về đề nghị giảm 25% tổng đơn: mức này vượt phần bên em được tự quyết nên bên em đã chuyển cấp quản lý xem xét, "
                    "sẽ có xác nhận sau. Báo giá trên hiện chỉ áp chiết khấu 2% theo chính sách.")],
    ),
    dict(
        id="R06", xh="chị", chao="Chào chị Thu,",
        khach="Chị Thu - NT Phu Gia (Zalo)",
        dia_chi="5 Đường Mẫu, Quận 10, TP. Hồ Chí Minh", dia_chi_thieu="",
        tham_chieu="R06 - tin nhắn Zalo",
        tieu_de="(Trả lời tin nhắn Zalo) Báo giá vật tư",
        mo_dau="Cảm ơn chị đã nhắn. Bên em báo giá các mục đã quy đổi được, riêng mực HP 12A bên em cần chị xác nhận số lượng.",
        dong=[("GIAY-A4-70", 2, "thùng"), ("BUT-BI-TL027-XANH", 5, "tá"), ("BANGKEO-2MAT-24", 3, "lốc"),
              ("BUT-GEL-05-DEN", 2, "hộp")],
        chua_bao_gia=[("Mực HP 12A, 1 thùng (MUC-HP-12A)", "bảng quy đổi không có đơn vị 'thùng' cho mã này nên chưa biết 1 thùng = bao nhiêu hộp")],
        cau_hoi=["Chị cần bao nhiêu hộp mực HP 12A? (Bên em chỉ bán/tính giá theo hộp và chưa có quy đổi \"1 thùng\" cho mã này.)"],
        cho_quyet=[],
    ),
    dict(
        id="R07", xh="anh/chị", chao="Chào anh/chị,",
        khach="Khách gửi từ kien.kho@example.com (chưa rõ tên/công ty)",
        dia_chi="15 Đường Mẫu, Quận Gò Vấp, TP. Hồ Chí Minh", dia_chi_thieu="",
        tham_chieu="R07 - email 'Báo giá lại đợt trước'",
        tieu_de="Re: Báo giá lại đợt trước",
        mo_dau="Cảm ơn anh/chị đã gửi yêu cầu. Bên em báo giá theo bảng giá hiện hành (áp dụng từ 01/11/2026).",
        dong=[("BUT-BI-TL027-XANH", 50, "cây"), ("SO-CARO-A4-200", 49, "quyển"), ("FILE-COC-7P", 100, "cái")],
        goi_y_bac=("SO-CARO-A4-200", 50),
        chua_bao_gia=[], cau_hoi=[],
        cho_quyet=[("Khách đòi giữ giá cũ bút bi TL027 3.500đ/cây -> trưởng phòng kinh doanh quyết; báo giá theo bảng giá hiện hành",
                    "Về giá bút bi TL027 3.500đ/cây của đợt trước: bên em báo theo bảng giá hiện hành như trên; đề nghị giữ giá cũ "
                    "bên em đã chuyển trưởng phòng kinh doanh xem xét, sẽ có xác nhận sau.")],
    ),
    dict(
        id="R08", xh="anh/chị", chao="Chào anh/chị,",
        khach="Xưởng (người gửi: phuong.xuong@example.com - chưa rõ tên công ty)",
        dia_chi="Lô B2, Khu công nghiệp Mẫu, Bắc Ninh", dia_chi_thieu="",
        tham_chieu="R08 - email 'Báo giá vật tư đóng gói - gấp'",
        tieu_de="Re: Báo giá vật tư đóng gói - gấp",
        mo_dau="Cảm ơn anh/chị đã gửi yêu cầu. Bên em gửi báo giá tiền hàng như dưới đây; phí vận chuyển và lịch giao cần bộ phận liên quan xác nhận.",
        dong=[("THUNG-CARTON-30X20X20", 300, "cái"), ("MANG-BOC-PE-50CM", 24, "cuộn"), ("BANGKEO-TRONG-48", 72, "cuộn")],
        chua_bao_gia=[], cau_hoi=[],
        cho_quyet=[("Giao Bắc Ninh (ngoại tỉnh): phí vận chuyển theo cước, nhân viên điều phối báo -> không tự đặt số",
                    "Phí vận chuyển đi Bắc Ninh: phí giao hàng theo thỏa thuận, theo cước của đơn vị vận chuyển; bên em đã chuyển nhân viên "
                    "điều phối báo, sẽ có xác nhận sau."),
                   ("Khách đòi giao TRƯỚC 10 giờ sáng thứ Sáu (nếu không kịp thì hủy) -> trưởng kho/giám đốc quyết; KHÔNG hứa giờ giao",
                    "Về yêu cầu giao gấp theo mốc sáng thứ Sáu mà anh/chị nêu: bên em chưa thể xác nhận trong thư này; yêu cầu đã chuyển "
                    "trưởng kho/giám đốc, sẽ có xác nhận lịch giao của kho bằng văn bản.")],
    ),
    dict(
        id="R09", xh="chú", chao="Chào chú,",
        khach="Chu Son (Zalo)",
        dia_chi=None, dia_chi_thieu="Chưa rõ - khách ghi 'giao cho chỗ cũ', chưa có địa chỉ cụ thể",
        tham_chieu="R09 - tin nhắn Zalo",
        tieu_de="(Trả lời tin nhắn Zalo) Báo giá như đợt trước",
        mo_dau="Cảm ơn chú đã nhắn. Hiện bên em chưa thể lập báo giá vì chưa biết đợt trước gồm những mặt hàng nào; chú cho bên em xin thông tin dưới đây nhé.",
        dong=[],
        chua_bao_gia=[("Toàn bộ đơn ('như đợt trước, số lượng tăng gấp đôi')", "chưa biết mặt hàng và số lượng đợt trước")],
        cau_hoi=["Chú cho bên em biết đợt trước gồm những mặt hàng nào (mã hàng hoặc tên hàng) và số lượng từng mặt hàng, "
                 "hoặc ngày/số báo giá của đợt trước, để bên em tính số lượng mới (gấp đôi) cho đúng.",
                 "\"Chỗ cũ\" là địa chỉ nào? Chú cho bên em xin địa chỉ giao đầy đủ (số nhà, quận/huyện, tỉnh/thành) để tính phí giao.",
                 "Chú cho bên em xin tên người/đơn vị nhận báo giá để ghi vào báo giá."],
        cho_quyet=[("Khách muốn 'như đợt trước' -> nếu đòi giữ giá cũ phải do trưởng phòng kinh doanh quyết; báo giá theo bảng giá hiện hành",
                    "Về giá: bên em sẽ báo theo bảng giá hiện hành (áp dụng từ 01/11/2026), có thể khác đợt trước; nếu chú muốn giữ đúng giá "
                    "đợt trước, bên em sẽ chuyển trưởng phòng kinh doanh xem xét và sẽ có xác nhận sau.")],
    ),
    dict(
        id="R10", xh="anh/chị", chao="Chào anh/chị Ngoc SaoMai,",
        khach="Ngoc SaoMai (Zalo)",
        dia_chi="30 Đường Demo, Cầu Giấy, Hà Nội", dia_chi_thieu="",
        tham_chieu="R10 - tin nhắn Zalo",
        tieu_de="(Trả lời tin nhắn Zalo) Báo giá danh sách vật tư, thiết bị",
        mo_dau="Cảm ơn anh/chị đã gửi danh sách. Bên em đã gộp các dòng trùng (mực HP 78A: 4 + 2 = 6 hộp; giấy A4 70: 10 ram + 1 thùng = 15 ram) "
               "và áp dụng mức giảm thêm 2% anh/chị đề nghị cho các dòng không thuộc nhóm thiết bị (trong thẩm quyền của bên em). "
               "Các dòng thiết bị (máy hủy giấy, ghế xoay) giữ giá bảng giá. Dòng mực 'Epson 664 đen' bên em báo theo mã MUC-EPS-664-DEN "
               "(mực nước máy in phun đen 70 ml, dòng 664).",
        dong=[("MUC-HP-78A", 4, "hộp"), ("GIAY-A4-70", 10, "ram"), ("MAY-HUY-GIAY-S12", 1, "cái"),
              ("GHE-XOAY-LUOI-01", 6, "cái"), ("MUC-EPS-664-DEN", 12, "chai"),
              ("MUC-HP-78A", 2, "hộp"), ("GIAY-A4-70", 1, "thùng")],
        ck_them=2, chua_bao_gia=[], cau_hoi=[], cho_quyet=[],
    ),
    dict(
        id="R11", xh="anh/chị", chao="Chào anh/chị,",
        khach="Khách gửi từ hung.mua@example.com (văn phòng mới, chưa rõ tên công ty)",
        dia_chi="200 Đường Mẫu, Quận Hoàng Mai, Hà Nội", dia_chi_thieu="",
        tham_chieu="R11 - email 'Báo giá trang bị văn phòng mới (đợt lớn)'",
        tieu_de="Re: Báo giá trang bị văn phòng mới (đợt lớn)",
        mo_dau="Cảm ơn anh/chị đã gửi yêu cầu. Bên em gửi báo giá theo bảng giá hiện hành và chiết khấu theo chính sách. "
               "Dòng 'máy chấm công vân tay' bên em báo theo mã duy nhất trong bảng giá là CC-VANTAY-01 (máy chấm công vân tay mẫu 01).",
        dong=[("MAY-IN-LASER-3100", 6, "cái"), ("MAY-SCAN-A4-100", 2, "cái"), ("CC-VANTAY-01", 4, "cái"),
              ("GIAY-A4-80", 60, "ram"), ("MUC-CANON-325", 12, "hộp")],
        chua_bao_gia=[], cau_hoi=[],
        cho_quyet=[("Khách đòi giảm 10% toàn đơn (vượt thẩm quyền; dòng thiết bị không giảm) -> trưởng phòng/giám đốc quyết; báo giá chỉ áp 4%",
                    "Về đề nghị giảm 10% toàn đơn: mức này vượt phần bên em được tự quyết nên bên em đã chuyển cấp quản lý xem xét, sẽ có xác nhận sau. "
                    "Báo giá trên hiện chỉ áp chiết khấu 4% theo chính sách."),
                   ("Khách đòi mua 10 ram giấy tặng 1 ram -> chỉ giám đốc quyết",
                    "Về đề nghị mua 10 ram giấy tặng 1 ram: bên em đã chuyển giám đốc xem xét, sẽ có xác nhận sau.")],
    ),
    dict(
        id="R12", xh="anh/chị", chao="Chào anh/chị Vy Sohong,",
        khach="Vy Sohong (Zalo) - cần xuất hóa đơn công ty, chưa có tên công ty",
        dia_chi="7 Đường Mẫu, Quận Bắc Từ Liêm, Hà Nội", dia_chi_thieu="",
        tham_chieu="R12 - tin nhắn Zalo",
        tieu_de="(Trả lời tin nhắn Zalo) Báo giá vật tư văn phòng",
        mo_dau="Cảm ơn anh/chị đã gửi danh sách. Bên em gửi báo giá như dưới đây. Giấy A4 70: 5 thùng = 25 ram; bút bi TL027: 2 tá = 24 cây.",
        dong=[("GIAY-A4-70", 5, "thùng"), ("BUT-BI-TL027-XANH", 2, "tá"), ("DECAL-A4-100", 3, "xấp"),
              ("MANG-BOC-PE-50CM", 2, "cuộn"), ("KEP-BUOM-32", 4, "hộp")],
        chua_bao_gia=[],
        cau_hoi=["Để xuất hóa đơn công ty, anh/chị cho bên em xin tên công ty, mã số thuế và địa chỉ xuất hóa đơn."],
        cho_quyet=[("Khách xin công nợ 30 ngày -> chỉ giám đốc duyệt",
                    "Về đề nghị công nợ 30 ngày: bên em chưa thể đồng ý trong thư này; đề nghị đã chuyển giám đốc xem xét, sẽ có xác nhận sau. "
                    "Trong lúc chờ, điều kiện thanh toán mặc định là chuyển khoản trước khi giao hàng.")],
    ),
]


if __name__ == "__main__":
    if "--check" not in sys.argv:
        ket_qua = tao_tat_ca()
    loi = kiem_tra()
    if "--check" in sys.argv:
        ts = doc_tham_so()
        ket_qua = []
        for s in SPECS:
            kq = tinh(s["dong"], GIA, QUYDOI, s.get("ck_them", 0), s["dia_chi"], ts["vat"])
            ket_qua.append((s["id"], trang_thai(s), kq["tong"], kq, s))
    print("KIỂM TRA:", "OK - không có lỗi" if not loi else f"{len(loi)} lỗi")
    for x in loi:
        print("  -", x)
    print()
    in_tom_tat(ket_qua)
    sys.exit(1 if loi else 0)
