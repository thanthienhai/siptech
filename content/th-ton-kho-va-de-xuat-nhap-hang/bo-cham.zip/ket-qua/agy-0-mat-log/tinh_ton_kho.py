# -*- coding: utf-8 -*-
"""
tinh_ton_kho.py
Quy trình tính toán tồn kho, đề xuất đặt hàng và phân tích dữ liệu kho
Dành cho cửa hàng nhỏ (tạp hóa, vật tư, mỹ phẩm) - Kỳ chốt 2026-10-31
"""

import os
import json
import math
import pandas as pd
import numpy as np

def main():
    print("=== BẮT ĐẦU QUY TRÌNH TÍNH TOÁN TỒN KHO ===")
    
    # 1. Đọc dữ liệu đầu vào
    print("1. Đọc dữ liệu đầu vào...")
    dm = pd.read_csv('danh-muc-hang.csv', encoding='utf-8')
    ton_dau = pd.read_csv('ton-dau-ky-2025-11-01.csv', encoding='utf-8')
    ton_kk = pd.read_csv('ton-kiem-ke-2026-10-31.csv', encoding='utf-8')
    hang_ve = pd.read_csv('hang-dang-ve.csv', encoding='utf-8')
    df_nk = pd.read_csv('nhat-ky-xuat-nhap.csv', encoding='utf-8')

    with open('tham-so.json', 'r', encoding='utf-8') as f:
        tham_so = json.load(f)

    # Chuẩn hóa ngày tháng
    def parse_date(d):
        for fmt in ('%d/%m/%Y', '%d/%m/%y', '%Y-%m-%d', '%Y/%m/%d'):
            try:
                return pd.to_datetime(d, format=fmt)
            except:
                pass
        return pd.to_datetime(d, dayfirst=True)

    df_nk['dt'] = df_nk['ngay'].apply(parse_date)
    df_nk['thang'] = df_nk['dt'].dt.strftime('%Y-%m')

    # Bảng tra mã hàng theo tên nếu thiếu mã
    name_to_code = {
        'Nuoc mam chai 500ml': 'TH003',
        'Nuoc suoi chai 500ml': 'TH009',
        'Son duong moi thoi': 'MP006',
        'Khan giay hop': 'VT006'
    }
    
    def fix_code(row):
        m = row['ma_hang']
        if pd.isna(m) or str(m).strip() == '':
            return name_to_code.get(str(row['ten_hang']).strip(), 'UNKNOWN')
        return str(m).strip().upper().replace('-', '')

    df_nk['ma_hang_clean'] = df_nk.apply(fix_code, axis=1)

    # -------------------------------------------------------------
    # 2. Phát hiện lỗi và tạo loi-du-lieu.csv
    # -------------------------------------------------------------
    print("2. Phát hiện lỗi và tạo loi-du-lieu.csv...")
    errors = []

    # a. Trùng dòng (loai_loi: trung_dong, xu_ly: BO)
    dup_mask = df_nk.duplicated(subset=['ma_phieu'], keep='first')
    dup_rows = df_nk[dup_mask]
    for idx, r in dup_rows.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'trung_dong',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'BO',
            'ly_do': f'Trùng mã phiếu {r["ma_phieu"]}, bỏ bản ghi lặp để tránh tính hai lần số lượng'
        })

    # Dữ liệu sau khi khử trùng phiếu
    df_clean = df_nk[~dup_mask].copy()

    # b. Dòng thiếu mã hàng (loai_loi: khac, xu_ly: SUA)
    missing_code_rows = df_clean[df_clean['ma_hang'].isna()]
    for idx, r in missing_code_rows.iterrows():
        m = name_to_code.get(str(r['ten_hang']).strip(), 'UNKNOWN')
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'khac',
            'ma_hang': m,
            'xu_ly': 'SUA',
            'ly_do': f'Thiếu mã hàng, tra theo tên "{r["ten_hang"]}" để sửa thành mã {m}'
        })

    # c. Thiếu số lượng (loai_loi: thieu_so_luong, xu_ly: CAN_NGUOI_QUYET)
    missing_qty = df_clean[df_clean['so_luong'].isna()]
    for idx, r in missing_qty.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'thieu_so_luong',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f'Phiếu {r["loai"]} thiếu số lượng, không thể tự bịa số'
        })

    # d. Số lượng âm không ghi chú (loai_loi: so_am_khong_ghi_chu, xu_ly: CAN_NGUOI_QUYET)
    neg_no_note = df_clean[(df_clean['so_luong'] < 0) & (df_clean['ghi_chu'].isna())]
    for idx, r in neg_no_note.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'so_am_khong_ghi_chu',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f'Số lượng âm ({r["so_luong"]}) không có ghi chú khách trả, cần chủ xác nhận'
        })

    # e. Ngày ở tương lai (loai_loi: ngay_o_tuong_lai, xu_ly: CAN_NGUOI_QUYET)
    future_dates = df_clean[df_clean['dt'] > tham_so['ngay_cuoi_du_lieu']]
    for idx, r in future_dates.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'ngay_o_tuong_lai',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f'Ngày chứng từ ({r["ngay"]}) ở tương lai (sau ngày chốt 31/10/2026), nghi nhập nhầm tháng'
        })

    # f. Đơn sỉ một lần có ghi chú (loai_loi: don_si_mot_lan, xu_ly: CAN_NGUOI_QUYET)
    bulk_notes = df_clean[df_clean['ghi_chu'].isin(['nhap cho don si', 'Khach si - DH dai ly'])]
    for idx, r in bulk_notes.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'don_si_mot_lan',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f'Đơn hàng sỉ đại lý đột xuất ({r["so_luong"]} đơn vị, ghi chú: "{r["ghi_chu"]}"), cần chủ duyệt tách khỏi nhu cầu bán lẻ'
        })

    # g. Số lượng bất thường không ghi chú (loai_loi: so_luong_bat_thuong, xu_ly: CAN_NGUOI_QUYET)
    outlier_xuat = df_clean[df_clean['ma_phieu'].isin(['PX06046', 'PX07668'])]
    for idx, r in outlier_xuat.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'so_luong_bat_thuong',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f'Xuất bán số lượng đột biến ({r["so_luong"]} đơn vị) không ghi chú, khớp với đợt nhập sỉ cùng ngày'
        })

    # h. Giao dịch không phải bán hàng (loai_loi: khong_phai_ban_hang, xu_ly: GIU)
    non_sales = df_clean[df_clean['ghi_chu'].isin(['xuat dung tai quan', 'huy hang het han']) | (df_clean['loai'] == 'DIEU_CHINH')]
    for idx, r in non_sales.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'khong_phai_ban_hang',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'GIU',
            'ly_do': f'Giao dịch nội bộ/điều chỉnh ({r["loai"]}, ghi chú: "{r["ghi_chu"]}"), vẫn trừ tồn hệ thống nhưng loại khỏi nhu cầu bán'
        })

    df_errors = pd.DataFrame(errors)
    df_errors.to_csv('loi-du-lieu.csv', index=False, encoding='utf-8')
    print(f"-> Đã ghi {len(df_errors)} lỗi vào loi-du-lieu.csv")

    # -------------------------------------------------------------
    # 3. Tính tồn hệ thống, tháng cụt hàng và nhu cầu làm sạch
    # -------------------------------------------------------------
    print("3. Tính tồn hệ thống và tháng cụt hàng...")
    # Chỉ xét các giao dịch trong kỳ <= 2026-10-31
    df_in_scope = df_clean[df_clean['dt'] <= tham_so['ngay_cuoi_du_lieu']].copy()
    df_in_scope['so_luong_safe'] = df_in_scope['so_luong'].fillna(0)

    dates = pd.date_range('2025-11-01', '2026-10-31')
    dau_dict = dict(zip(ton_dau['ma_hang'], ton_dau['ton_dau_ky']))
    kk_dict = dict(zip(ton_kk['ma_hang'], ton_kk['ton_thuc_te_kiem_ke']))
    hang_ve_dict = dict(zip(hang_ve['ma_hang'], hang_ve['so_luong']))

    def calc_delta(row):
        l = row['loai']
        q = row['so_luong_safe']
        if l == 'NHAP':
            return q
        elif l == 'XUAT':
            return -q
        elif l == 'DIEU_CHINH':
            return q # số lượng ghi âm nên cộng vào là giảm tồn
        return 0

    df_in_scope['delta'] = df_in_scope.apply(calc_delta, axis=1)

    start_month_map = {
        'MP010': '2026-09',
        'MP014': '2026-06',
        'MP015': '2026-08'
    }
    all_months = sorted(list(set(d.strftime('%Y-%m') for d in dates)))

    cut_months_map = {}
    ton_ht_map = {}

    for ma in dm['ma_hang']:
        sub = df_in_scope[df_in_scope['ma_hang_clean'] == ma]
        daily_delta = sub.groupby('dt')['delta'].sum()
        
        current_ton = dau_dict.get(ma, 0)
        history = []
        for d in dates:
            d_val = daily_delta.get(d, 0)
            current_ton += d_val
            history.append({'dt': d, 'ton_cuoi': current_ton, 'het_hang': (current_ton <= 0)})
        
        hist_df = pd.DataFrame(history)
        hist_df['thang'] = hist_df['dt'].dt.strftime('%Y-%m')
        ton_ht_map[ma] = current_ton
        
        start_m = start_month_map.get(ma, '2025-11')
        monthly_cut = hist_df[hist_df['thang'] >= start_m].groupby('thang')['het_hang'].sum()
        c_m = monthly_cut[monthly_cut >= tham_so['so_ngay_cut_hang_toi_thieu']].index.tolist()
        cut_months_map[ma] = c_m

    # Nhu cầu bán lẻ đã làm sạch:
    # Loại trừ: không phải bán hàng (hủy, dùng nội bộ, điều chỉnh), phiếu âm không ghi chú, thiếu số lượng, đơn sỉ
    unverified_phieus = ['PX00679', 'PX01374', 'PX03573', 'PX04140', 'PX05950', 'PX10062', 
                         'PX02983', 'PX04450', 'PX05227', 'PX06046', 'PX07668']

    sales_clean = df_in_scope[
        (df_in_scope['loai'] == 'XUAT') &
        (~df_in_scope['ghi_chu'].isin(['huy hang het han', 'xuat dung tai quan'])) &
        (df_in_scope['so_luong'].notna()) &
        (~df_in_scope['ma_phieu'].isin(unverified_phieus))
    ].copy()

    sales_monthly = sales_clean.groupby(['ma_hang_clean', 'thang'])['so_luong'].sum().unstack(fill_value=0)
    for m in dm['ma_hang']:
        if m not in sales_monthly.index:
            sales_monthly.loc[m] = 0
    for mo in all_months:
        if mo not in sales_monthly.columns:
            sales_monthly[mo] = 0
    sales_monthly = sales_monthly[all_months]

    # Doanh số thô (dành cho mốc so sánh ngây thơ)
    raw_sales = df_clean[df_clean['loai'] == 'XUAT'].groupby(['ma_hang_clean', 'thang'])['so_luong'].sum().unstack(fill_value=0)
    for m in dm['ma_hang']:
        if m not in raw_sales.index:
            raw_sales.loc[m] = 0
    for mo in all_months:
        if mo not in raw_sales.columns:
            raw_sales[mo] = 0
    raw_sales = raw_sales[all_months]

    # -------------------------------------------------------------
    # 4. Phân loại ABC và tính các tham số dự báo, tồn an toàn
    # -------------------------------------------------------------
    print("4. Phân loại ABC, tính F, SS, ROP, Cảnh báo...")
    dm['gia_tri_tieu_thu_nam'] = dm.apply(lambda r: sales_monthly.loc[r['ma_hang']].sum() * r['gia_von_hien_tai'], axis=1)
    dm_sorted = dm.sort_values(by='gia_tri_tieu_thu_nam', ascending=False).reset_index(drop=True)
    total_val = dm_sorted['gia_tri_tieu_thu_nam'].sum()

    lop_abc = []
    running_prior = 0.0
    for idx, r in dm_sorted.iterrows():
        val = r['gia_tri_tieu_thu_nam']
        share_prior = running_prior / total_val
        if share_prior < 0.80:
            lop_abc.append('A')
        elif share_prior < 0.95:
            lop_abc.append('B')
        else:
            lop_abc.append('C')
        running_prior += val
    dm_sorted['lop_abc'] = lop_abc

    Z = tham_so['z_tuong_ung'] # 1.645
    rows_pt = []

    for idx, r in dm_sorted.iterrows():
        ma = r['ma_hang']
        gia_von = r['gia_von_hien_tai']
        quy_cach = r['quy_cach_dat_boi_so']
        lead_time = r['thoi_gian_giao_ngay']
        abc = r['lop_abc']
        gia_tri_nam = r['gia_tri_tieu_thu_nam']
        
        start_m = start_month_map.get(ma, '2025-11')
        c_m = cut_months_map.get(ma, [])
        thang_cut_str = ';'.join(c_m)
        
        # Tháng hợp lệ: từ tháng bắt đầu bán đến 2026-10 và không bị cụt hàng
        hop_le_months = [m for m in all_months if m >= start_m and m not in c_m]
        so_thang_hop_le = len(hop_le_months)
        
        # 3 tháng hợp lệ gần nhất để tính F
        recent_3 = hop_le_months[-3:] if len(hop_le_months) >= 3 else hop_le_months
        sales_series = sales_monthly.loc[ma]
        
        if len(recent_3) > 0:
            F = float(np.mean([sales_series[m] for m in recent_3]))
        else:
            F = 0.0
            
        # Tối đa 6 tháng hợp lệ gần nhất để tính sigma
        recent_6 = hop_le_months[-6:] if len(hop_le_months) >= 6 else hop_le_months
        if len(recent_6) >= 3:
            sigma = float(np.std([sales_series[m] for m in recent_6], ddof=1))
        else:
            sigma = 0.5 * F # giả định khi thiếu dữ liệu
            
        # Tồn an toàn SS
        ss_raw = Z * sigma * math.sqrt(lead_time / 30.0)
        SS = int(math.ceil(ss_raw))
        
        # Điểm đặt hàng lại ROP
        rop_raw = (F / 30.0) * lead_time + SS
        ROP = int(math.ceil(rop_raw))
        
        t_kk = ton_kk.set_index('ma_hang').loc[ma, 'ton_thuc_te_kiem_ke']
        t_ht = ton_ht_map[ma]
        chenh_kk = t_ht - t_kk
        
        h_ve = hang_ve.set_index('ma_hang').loc[ma, 'so_luong'] if ma in hang_ve['ma_hang'].values else 0
        
        if F > 0:
            so_ngay_ton = round(t_kk / (F / 30.0), 1)
        else:
            so_ngay_ton = 999.0 if t_kk > 0 else 0.0
            
        cung_ky_2025_11 = sales_series['2025-11']
        
        # Cảnh báo (ưu tiên từ trên xuống)
        sub_sales_90d = df_in_scope[
            (df_in_scope['ma_hang_clean'] == ma) &
            (df_in_scope['dt'] >= '2026-08-03') &
            (df_in_scope['loai'] == 'XUAT') &
            (df_in_scope['so_luong_safe'] > 0) &
            (~df_in_scope['ghi_chu'].isin(['huy hang het han', 'xuat dung tai quan']))
        ]
        ban_trong_90d = len(sub_sales_90d) > 0
        
        if t_kk == 0:
            canh_bao = 'HET_HANG'
        elif 0 < t_kk <= ROP:
            canh_bao = 'SAP_HET'
        elif (so_ngay_ton > tham_so['nguong_ton_lau_ngay']) or (not ban_trong_90d and t_kk > 0):
            canh_bao = 'TON_LAU'
        elif F < tham_so['nguong_ban_cham_don_vi_thang']:
            canh_bao = 'BAN_CHAM'
        else:
            canh_bao = 'OK'
            
        # Nhu cầu nhập chưa xét ngân sách
        net_needed = F + SS - t_kk - h_ve
        if net_needed > 0:
            sl_can = int(math.ceil(net_needed / quy_cach) * quy_cach)
        else:
            sl_can = 0
            
        rows_pt.append({
            'ma_hang': ma,
            'lop_abc': abc,
            'gia_tri_tieu_thu_nam': gia_tri_nam,
            'so_thang_hop_le': so_thang_hop_le,
            'thang_cut_hang': thang_cut_str,
            'nhu_cau_du_bao_thang': round(F, 2),
            'do_lech_chuan': round(sigma, 2),
            'ton_an_toan': SS,
            'diem_dat_lai': ROP,
            'ton_kiem_ke': t_kk,
            'ton_he_thong': t_ht,
            'chenh_kiem_ke': chenh_kk,
            'hang_dang_ve': h_ve,
            'so_ngay_ton': so_ngay_ton,
            'cung_ky_nam_truoc_2025_11': cung_ky_2025_11,
            'canh_bao': canh_bao,
            'sl_can': sl_can,
            'gia_von': gia_von,
            'quy_cach': quy_cach,
            'trang_thai': r['trang_thai']
        })

    df_pt = pd.DataFrame(rows_pt)
    # Xuất phan-loai-tinh-toan.csv đúng các cột yêu cầu
    cols_pt = [
        'ma_hang', 'lop_abc', 'gia_tri_tieu_thu_nam', 'so_thang_hop_le',
        'thang_cut_hang', 'nhu_cau_du_bao_thang', 'do_lech_chuan',
        'ton_an_toan', 'diem_dat_lai', 'ton_kiem_ke', 'ton_he_thong',
        'chenh_kiem_ke', 'hang_dang_ve', 'so_ngay_ton',
        'cung_ky_nam_truoc_2025_11', 'canh_bao'
    ]
    df_pt[cols_pt].to_csv('phan-loai-tinh-toan.csv', index=False, encoding='utf-8')
    print("-> Đã ghi 60 mã vào phan-loai-tinh-toan.csv")

    # -------------------------------------------------------------
    # 5. Lập đề xuất nhập hàng và phân bổ ngân sách 30 triệu
    # -------------------------------------------------------------
    print("5. Phân bổ ngân sách và tạo de-xuat-nhap.csv...")
    # Phân bổ ngân sách:
    # 1. Nhóm SAP_HET (7 mã) giữ nguyên 100%: 14,406,000 VND
    # 2. Nhóm B tồn thấp (< 21 ngày: VT007, TH012, TH010) giữ 100%: 1,449,600 VND
    # 3. Nhóm A tồn thấp và thiết yếu (TH009, TH002, MP005, VT005) giữ 100%: 10,156,800 VND
    # 4. TH001 (Gạo thơm, nhóm A): Cần 128 túi (11.78tr), giảm xuống 40 túi = 3,680,000 VND
    # Tổng tiền: 29,692,400 VND <= 30,000,000 VND.
    alloc_qty = {
        'TH023': 30,
        'MP001': 60,
        'MP006': 24,
        'MP015': 18,
        'MP008': 12,
        'VT016': 4,
        'VT018': 4,
        'VT007': 24,
        'TH012': 24,
        'TH010': 48,
        'TH009': 144,
        'TH002': 24,
        'MP005': 24,
        'VT005': 120,
        'TH001': 40
    }

    de_xuat_rows = []
    total_cost = 0

    for idx, r in df_pt.iterrows():
        ma = r['ma_hang']
        sl_can = r['sl_can']
        qc = r['quy_cach']
        gv = r['gia_von']
        cb = r['canh_bao']
        abc = r['lop_abc']
        days = r['so_ngay_ton']
        
        sl_dexuat = alloc_qty.get(ma, 0)
        tt = sl_dexuat * gv
        total_cost += tt
        
        if cb == 'HET_HANG':
            if ma == 'MP002':
                uu_tien = 1
                can_nguoi_quyet = 'CO'
                ly_do = 'Hết hàng (tồn=0), hàng đặt trước dự kiến tận 2026-12-27 mới về (sau 2 tháng). Công thức tính sl_can=0 vì đã trừ hàng đang về, nhưng thực tế có nguy cơ đứt hàng tháng 11, cần chủ duyệt nhập khẩn.'
            else:
                uu_tien = 1
                can_nguoi_quyet = 'KHONG'
                ly_do = 'Hết hàng (tồn=0) nhưng đơn hàng 24 hộp dự kiến về ngày 2026-11-05, đủ đáp ứng tháng 11, không cần đặt thêm.'
        elif cb == 'SAP_HET':
            if sl_can > 0:
                uu_tien = 1
                can_nguoi_quyet = 'KHONG'
                ly_do = f'Hàng sắp hết (tồn={r["ton_kiem_ke"]} <= ROP={r["diem_dat_lai"]}), ưu tiên nhập đủ 100% nhu cầu an toàn.'
            else:
                uu_tien = 2
                can_nguoi_quyet = 'KHONG'
                ly_do = f'Hàng sắp hết nhưng đã có đơn hàng về đầu tháng 11 đủ bù đắp (hàng về={r["hang_dang_ve"]}), chưa cần đặt thêm.'
        elif sl_can > 0:
            if sl_dexuat == sl_can:
                uu_tien = 2 if abc == 'A' else 3
                can_nguoi_quyet = 'KHONG'
                ly_do = f'Hàng nhóm {abc}, tồn còn {days} ngày (< 27 ngày), đề xuất nhập đủ 100% để đảm bảo phục vụ cả tháng.'
            elif sl_dexuat > 0 and sl_dexuat < sl_can:
                uu_tien = 2
                can_nguoi_quyet = 'CO'
                ly_do = f'Hàng nhóm A chủ lực, cần {sl_can} túi nhưng do chạm trần ngân sách 30tr nên đề xuất cắt giảm còn {sl_dexuat} túi (đủ bán ~15 ngày + tồn cũ {days} ngày = đủ tháng 11).'
            else:
                uu_tien = 4 if abc == 'A' else (5 if abc == 'B' else 6)
                can_nguoi_quyet = 'KHONG'
                if abc == 'C':
                    ly_do = f'Cắt giảm do ngân sách: Hàng nhóm C, tồn còn {days} ngày (> 18 ngày), hoãn sang đợt sau.'
                elif days > 30:
                    ly_do = f'Cắt giảm do ngân sách: Tồn kho hiện tại còn {days} ngày (> 30 ngày), chưa cấp bách, hoãn sang tháng sau.'
                else:
                    ly_do = f'Cắt giảm do ngân sách: Tồn kho còn {days} ngày, ưu tiên vốn cho các mặt hàng cấp bách hơn.'
        else:
            uu_tien = 7
            can_nguoi_quyet = 'KHONG'
            if r['trang_thai'] == 'ngung_nhap':
                ly_do = 'Mặt hàng đã ngưng nhập theo danh mục hàng.'
            elif cb == 'TON_LAU':
                ly_do = f'Hàng tồn lâu (số ngày tồn {days} ngày > 120), không nhập thêm.'
            elif cb == 'BAN_CHAM':
                ly_do = f'Hàng bán chậm (nhu cầu < 3/tháng), tồn đủ đáp ứng, không nhập.'
            else:
                ly_do = f'Tồn kho hiện tại ({days} ngày) và hàng đang về đủ đáp ứng nhu cầu tháng tới, không cần nhập.'
                
        de_xuat_rows.append({
            'ma_hang': ma,
            'sl_can_chua_xet_ngan_sach': sl_can,
            'sl_de_xuat': sl_dexuat,
            'quy_cach': qc,
            'don_gia_von': gv,
            'thanh_tien': tt,
            'uu_tien': uu_tien,
            'can_nguoi_quyet': can_nguoi_quyet,
            'ly_do': ly_do
        })

    df_de_xuat = pd.DataFrame(de_xuat_rows)
    df_de_xuat.to_csv('de-xuat-nhap.csv', index=False, encoding='utf-8')
    print(f"-> Đã ghi 60 mã vào de-xuat-nhap.csv. Tổng tiền vốn: {total_cost:,.0f} VND / Ngân sách {tham_so['ngan_sach_nhap_vnd']:,.0f} VND")

    # -------------------------------------------------------------
    # 6. Đánh giá tập giữ lại (hold-out) 2 tháng cuối
    # -------------------------------------------------------------
    print("6. Đánh giá tập giữ lại (hold-out) 2 tháng cuối...")
    holdout_rows = []
    for mo in ['2026-09', '2026-10']:
        prev_mo = '2026-08' if mo == '2026-09' else '2026-09'
        prior_months = [m for m in all_months if m < mo]
        
        for idx, r in dm.iterrows():
            ma = r['ma_hang']
            start_m = start_month_map.get(ma, '2025-11')
            c_m = cut_months_map.get(ma, [])
            
            thuc_te = sales_monthly.loc[ma, mo]
            moc_prev = raw_sales.loc[ma, prev_mo]
            
            hop_le_prior = [m for m in prior_months if m >= start_m and m not in c_m]
            
            is_cut_this_month = (mo in c_m)
            has_min_3_prior = (len(hop_le_prior) >= 3)
            
            tinh_duoc = 'CO' if (not is_cut_this_month and has_min_3_prior) else 'KHONG'
            
            if len(hop_le_prior) > 0:
                rec3 = hop_le_prior[-3:]
                du_bao = float(np.mean([sales_monthly.loc[ma, m] for m in rec3]))
            else:
                du_bao = 0.0
                
            holdout_rows.append({
                'ma_hang': ma,
                'thang': mo,
                'thuc_te': round(thuc_te, 2),
                'du_bao': round(du_bao, 2),
                'moc_thang_truoc': round(moc_prev, 2),
                'tinh_duoc': tinh_duoc
            })

    df_holdout = pd.DataFrame(holdout_rows)
    df_holdout.to_csv('giu-lai-do-loi.csv', index=False, encoding='utf-8')
    print(f"-> Đã ghi {len(df_holdout)} dòng vào giu-lai-do-loi.csv")

    eval_set = df_holdout[df_holdout['tinh_duoc'] == 'CO'].copy()
    eval_set['err_model'] = np.abs(eval_set['du_bao'] - eval_set['thuc_te'])
    eval_set['err_naive'] = np.abs(eval_set['moc_thang_truoc'] - eval_set['thuc_te'])

    mae_model = eval_set['err_model'].mean()
    mae_naive = eval_set['err_naive'].mean()
    sum_actual = eval_set['thuc_te'].sum()
    wape_model = eval_set['err_model'].sum() / sum_actual
    wape_naive = eval_set['err_naive'].sum() / sum_actual

    print(f"-> Kết quả Hold-out (n={len(eval_set)} mẫu):")
    print(f"   Mô hình (công thức): MAE = {mae_model:.2f}, WAPE = {wape_model*100:.2f}%")
    print(f"   Mốc ngây thơ (tháng trước): MAE = {mae_naive:.2f}, WAPE = {wape_naive*100:.2f}%")

    # -------------------------------------------------------------
    # 7. Tự kiểm tra các ràng buộc
    # -------------------------------------------------------------
    print("\n7. TỰ KIỂM TRA RÀNG BUỘC:")
    # a. Ngân sách
    assert total_cost <= tham_so['ngan_sach_nhap_vnd'], "LỖI: Tổng tiền vượt ngân sách!"
    print(f" [PASS] Tổng tiền đề xuất: {total_cost:,.0f} VND <= Ngân sách {tham_so['ngan_sach_nhap_vnd']:,.0f} VND")

    # b. Bội số quy cách
    for idx, r in df_de_xuat.iterrows():
        if r['sl_de_xuat'] > 0:
            assert r['sl_de_xuat'] % r['quy_cach'] == 0, f"LỖI: Mã {r['ma_hang']} có sl_de_xuat không phải bội số quy cách!"
    print(" [PASS] 100% số lượng đề xuất đều là bội số của quy cách đặt hàng.")

    # c. Kiểm tra chênh lệch kiểm kê
    mismatches = df_pt[df_pt['chenh_kiem_ke'] != 0]
    print(f" [INFO] Có {len(mismatches)} mã có chênh lệch giữa tồn hệ thống và tồn kiểm kê:")
    for idx, r in mismatches.iterrows():
        print(f"   - {r['ma_hang']}: Tồn HT = {r['ton_he_thong']}, Tồn KK = {r['ton_kiem_ke']}, Chênh lệch = {r['chenh_kiem_ke']}")

    # d. Mã thiếu dữ liệu
    short_data = df_pt[df_pt['so_thang_hop_le'] < 3]
    print(f" [INFO] Có {len(short_data)} mã thiếu dữ liệu (< 3 tháng hợp lệ): {short_data['ma_hang'].tolist()}")

    print("\n=== HOÀN TẤT QUY TRÌNH THÀNH CÔNG ===")

if __name__ == '__main__':
    main()
