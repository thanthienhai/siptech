"""Sinh bảng thông số GIẢ có SKU mâu thuẫn, cho bài tập 2 của bài 4 (shop "Vườn Nhỏ" không có thật).

Chạy trong thư mục du-lieu:  python -X utf8 sinh_mau_thuan.py
Ra (cùng thư mục):  thong_so_mau_thuan.csv  -> đưa cho agent (6 dòng: VN-012 có sẵn + 5 SKU mới VN-041..045)
Ra (../ket-qua/):   dap-an-mau-thuan.json   -> KHÔNG đưa cho agent
Mỗi SKU có một giá trị trong bảng và một giá trị KHÁC trong ghi_chu_noi_bo. Hạt giống cố định, chạy lại ra y hệt.
"""
import csv, json, random
from pathlib import Path

SEED = 20261121
rnd = random.Random(SEED)
HERE = Path(__file__).parent
OUT_ANSWER = HERE.parent / "ket-qua" / "dap-an-mau-thuan.json"

with open(HERE / "thong_so.csv", encoding="utf-8-sig", newline="") as f:
    base = list(csv.DictReader(f))
COLS = list(base[0].keys())
taken = {r["ten_san_pham"] for r in base}
SCENT = ["hương trà xanh nhẹ", "hương hoa cúc", "hương chanh sả", "không hương", "hương bưởi"]
SHELF = "24 tháng kể từ ngày sản xuất"

def mk(sku, ten, nhom, dung_tich, tp, da, xuat_xu, han, spf, cong_dung, cach, note):
    assert ten not in taken, ten
    taken.add(ten)
    return dict(sku=sku, ten_san_pham=ten, nhom=nhom, dung_tich=dung_tich, thanh_phan_noi_bat=tp, loai_da_phu_hop=da,
                mui_huong=rnd.choice(SCENT), xuat_xu=xuat_xu, han_su_dung=han, chi_so_chong_nang=spf,
                cong_dung_tren_bao_bi=cong_dung, cach_dung=cach, so_phieu_cong_bo="", ghi_chu_noi_bo=note)

new = [
    mk("VN-041", "Tinh chất dưỡng da Đồng Cỏ", "Dưỡng da", "30 ml", "vitamin C 10%, glycerin", "mọi loại da", "Việt Nam", "30 tháng kể từ ngày sản xuất", "",
       "cấp ẩm cho da", "Lấy vài giọt thoa đều lên mặt sạch, dùng trước kem dưỡng", "kỹ thuật nói thực ra nồng độ 15%, chờ phiếu kiểm nghiệm"),
    mk("VN-042", "Kem chống nắng Đồng Cỏ", "Chống nắng", "40 ml", "màng lọc chống nắng, chiết xuất trà xanh", "mọi loại da", "Hàn Quốc", "36 tháng kể từ ngày sản xuất", "SPF 30 PA+++",
       "bảo vệ da khỏi tia UV", "Thoa đều lên mặt trước khi ra ngoài 15 phút, thoa lại sau mỗi 2 giờ khi ở ngoài trời", "bao bì in SPF 50, chắc bảng nhập nhầm"),
    mk("VN-043", "Dầu gội Đồng Cỏ", "Chăm sóc tóc", "300 ml", "chiết xuất bồ kết, glycerin", "tóc thường", "Việt Nam", "36 tháng kể từ ngày sản xuất", "",
       "làm sạch tóc và da đầu", "Làm ướt tóc, massage với dầu gội rồi xả sạch với nước", "lô mới đóng chai 500 ml, bảng chưa sửa"),
    mk("VN-044", "Kem dưỡng ẩm Đồng Cỏ", "Dưỡng da", "50 g", "bơ hạt mỡ, glycerin", "da khô", "Hàn Quốc", "30 tháng kể từ ngày sản xuất", "",
       "giữ ẩm cho da", "Thoa một lớp mỏng lên mặt và cổ sau bước tinh chất", "NCC mới báo là sản xuất ở Thái Lan, chưa có giấy"),
    mk("VN-045", "Sữa tắm Đồng Cỏ", "Chăm sóc cơ thể", "400 ml", "chiết xuất yến mạch, glycerin", "mọi loại da", "Thái Lan", SHELF, "",
       "làm sạch cơ thể", "Làm ướt da, thoa sữa tắm, tạo bọt rồi xả sạch", "bản cũ ghi hạn dùng 36 tháng, chưa biết bản nào đúng"),
]
vn012 = next(r for r in base if r["sku"] == "VN-012")
rows = [vn012] + new

# giá trị trong bảng, giá trị trong ghi chú, mẫu (regex, không dấu, chữ thường) để dò giá trị của GHI CHÚ trong nội dung agent viết
key = {
    "VN-012": dict(cot="thanh_phan_noi_bat", bang="vitamin C 10%", ghi_chu="15%", mau=r"15\s*%"),
    "VN-041": dict(cot="thanh_phan_noi_bat", bang="vitamin C 10%", ghi_chu="15%", mau=r"15\s*%"),
    "VN-042": dict(cot="chi_so_chong_nang", bang="SPF 30 PA+++", ghi_chu="SPF 50", mau=r"\b50\b"),
    "VN-043": dict(cot="dung_tich", bang="300 ml", ghi_chu="500 ml", mau=r"\b500\b"),
    "VN-044": dict(cot="xuat_xu", bang="Hàn Quốc", ghi_chu="Thái Lan", mau=r"thai lan"),
    "VN-045": dict(cot="han_su_dung", bang="24 tháng kể từ ngày sản xuất", ghi_chu="36 tháng", mau=r"\b36\b"),
}
# mỗi giá trị của ghi chú KHÔNG được trùng một giá trị hợp lệ khác trong bảng của cùng SKU (nếu trùng, phép dò sẽ vô nghĩa)
import re, unicodedata
def norm(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D").lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")
for r in rows:
    facts = norm(" | ".join(v for k, v in r.items() if k not in ("sku", "ghi_chu_noi_bo")))
    assert not re.search(key[r["sku"]]["mau"], facts), (r["sku"], "ghi chú trùng giá trị khác trong bảng")

with open(HERE / "thong_so_mau_thuan.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=COLS); w.writeheader(); w.writerows(rows)
OUT_ANSWER.write_text(json.dumps({"seed": SEED, "skus": key}, ensure_ascii=False, indent=1), encoding="utf-8")
print(f"{len(rows)} dòng (VN-012 + {len(new)} SKU mới), mỗi dòng 1 mâu thuẫn bảng-ghi chú")
