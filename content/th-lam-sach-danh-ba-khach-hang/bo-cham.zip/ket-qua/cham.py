"""Chấm kết quả làm sạch danh bạ của agent bằng đáp án (dap-an.json). Không dùng mô hình.

Dùng:  python -X utf8 cham.py <nhãn>=<thư_mục_agent_đã_chạy> [<nhãn>=<thư_mục> ...] [--out bao-cao-cham.json]
Mỗi thư mục phải có các file agent đã tạo (danh-ba-sach.xlsx, nhat-ky-gop.csv, nhat-ky-sua.csv, nghi-trung-can-quyet.csv, lam_sach.py).
Chấm: (1) phủ dòng/ hoàn tác, (2) gộp đúng - gộp nhầm, (3) ca cần người quyết, (4) làm sạch từng trường,
(5) bịa, (6) chạy lại script có ra đúng kết quả không, (7) file gốc có bị sửa không.
"""
import json, sys, csv, re, hashlib, shutil, subprocess, tempfile, unicodedata
from pathlib import Path
from itertools import combinations
from collections import Counter

HERE = Path(__file__).resolve().parent
def _opt(name, default):
    return Path(sys.argv[sys.argv.index(name) + 1]) if name in sys.argv else default
ANS = json.loads(_opt("--dap-an", HERE / "dap-an.json").read_text(encoding="utf-8"))   # --dap-an <file> để chấm đợt khác
ROWS = ANS["rows"]
ORIG_XLSX = _opt("--goc", HERE.parent / "du-lieu" / "danh-ba-goc.xlsx")                  # --goc <file> là file gốc tương ứng

def nfc(s): return unicodedata.normalize("NFC", s or "")
def strip_dia(s):
    s = unicodedata.normalize("NFD", (s or "").replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")
def key(s): return re.sub(r"\s+", " ", strip_dia(s).lower()).strip()
def akey(s):
    k = key(s); k = re.sub(r"[.,;]", " ", k); k = re.sub(r"\bthanh pho\b", " ", k)
    return re.sub(r"\s+", " ", k).strip()
def digits(s): return re.sub(r"\D", "", str(s or ""))
def is_title(s):
    return all(w[:1].isupper() and (w[1:] == w[1:].lower() or w.endswith(".")) for w in s.split()) if s else True
HON = re.compile(r"^(anh|chi|co|chu|bac|a|c)\s", re.I)
VALID_PHONE = re.compile(r"^(0[35789]\d{8}|02\d{9})$")

def read_csv(p):
    p = Path(p)
    if not p.exists(): return None
    t = p.read_text(encoding="utf-8-sig", errors="replace")
    return list(csv.DictReader(t.splitlines()))

def col(d, *names):
    low = {k.strip().lower(): k for k in d}
    for n in names:
        if n in low: return d[low[n]]
    return ""

def split_ids(s): return [x.strip() for x in re.split(r"[;,\s]+", s or "") if re.fullmatch(r"R\d{3}", x.strip())]

def load_clean(run):
    import openpyxl
    p = run / "danh-ba-sach.xlsx"
    if not p.exists(): return None
    wb = openpyxl.load_workbook(p, data_only=True)
    ws = wb["KhachHang"] if "KhachHang" in wb.sheetnames else wb.active
    rows = list(ws.iter_rows(values_only=True))
    hdr = [str(h or "").strip().lower() for h in rows[0]]
    out = []
    for r in rows[1:]:
        if not any(r): continue
        out.append({hdr[i]: ("" if v is None else str(v)) for i, v in enumerate(r) if i < len(hdr)})
    return out

def pairs_of(rows):
    return {frozenset(p) for p in combinations(sorted(rows), 2)}

def score(run):
    run = Path(run); R = {}
    all_ids = sorted(ROWS)
    # ---- file gốc nguyên vẹn
    g = run / "danh-ba-goc.xlsx"
    R["file_goc_nguyen_ven"] = bool(g.exists() and hashlib.md5(g.read_bytes()).hexdigest() == hashlib.md5(ORIG_XLSX.read_bytes()).hexdigest())
    files = {n: (run / n).exists() for n in ["danh-ba-sach.xlsx", "nhat-ky-gop.csv", "nhat-ky-sua.csv", "nghi-trung-can-quyet.csv", "lam_sach.py", "bao-cao.md"]}
    R["file_dau_ra"] = files
    gop = read_csv(run / "nhat-ky-gop.csv"); clean = load_clean(run)
    if gop is None or clean is None:
        R["loi"] = "thiếu nhat-ky-gop.csv hoặc danh-ba-sach.xlsx"; return R
    # ---- phủ dòng
    row2kh, cnt = {}, Counter()
    for d in gop:
        rid = col(d, "ma_dong_goc").strip(); cnt[rid] += 1; row2kh[rid] = col(d, "ma_khach").strip()
    R["phu_dong"] = dict(so_dong_nhat_ky=len(gop), thieu=[i for i in all_ids if i not in cnt], trung=[i for i, c in cnt.items() if c > 1], la=[i for i in cnt if i not in ROWS])
    # cụm theo nhật ký gộp
    clusters = {}
    for rid, kh in row2kh.items():
        if rid in ROWS: clusters.setdefault(kh, set()).add(rid)
    # cụm theo file sạch
    clean_clusters = {}
    for rec in clean:
        ids = [i for i in split_ids(col(rec, "ma_dong_goc")) if i in ROWS]
        clean_clusters[col(rec, "ma_khach")] = ids
    part_a = {frozenset(v) for v in clusters.values()}
    part_b = {frozenset(v) for v in clean_clusters.values() if v}
    R["hoan_tac"] = dict(so_khach_sach=len(clean), so_cum_theo_nhat_ky=len(clusters), nhat_ky_khop_file_sach=(part_a == part_b),
                         tong_dong_trong_file_sach=sum(len(v) for v in clean_clusters.values()))
    pred_pairs = set()
    for v in clusters.values(): pred_pairs |= pairs_of(v)
    # ---- gộp chắc
    truth_gop = set(); grp_ok = 0; grp_part = 0; per_loai = {}
    for gr in ANS["gop_chac"]:
        rs = gr["rows"]; truth_gop |= pairs_of(rs)
        pp = pairs_of(rs); hit = pp & pred_pairs
        full = len(hit) == len(pp) and all(clusters.get(row2kh.get(r), set()) == set(rs) for r in rs if r in row2kh)
        per_loai.setdefault(gr["loai"], [0, 0]); per_loai[gr["loai"]][1] += 1
        if full: grp_ok += 1; per_loai[gr["loai"]][0] += 1
        elif hit: grp_part += 1
    R["gop_chac"] = dict(tong_nhom=len(ANS["gop_chac"]), gop_dung_tron_ven=grp_ok, gop_mot_phan=grp_part, bo_sot=len(ANS["gop_chac"]) - grp_ok - grp_part,
                         theo_loai={k: f"{a}/{b}" for k, (a, b) in per_loai.items()}, cap_dung=len(truth_gop & pred_pairs), tong_cap=len(truth_gop))
    # ---- gộp nhầm
    quyet_pairs = {}
    for g_ in ANS["can_nguoi_quyet"]: quyet_pairs[frozenset(g_["rows"])] = g_["loai"]
    khong_pairs = {frozenset(g_["rows"]): g_["loai"] for g_ in ANS["khong_gop"]}
    bad = pred_pairs - truth_gop
    R["gop_nham"] = dict(tong_cap_nham=len(bad),
                         gop_ca_can_nguoi_quyet=sorted(f"{'+'.join(sorted(p))}({quyet_pairs[p]})" for p in bad if p in quyet_pairs),
                         gop_ca_khong_gop=sorted(f"{'+'.join(sorted(p))}({khong_pairs[p]})" for p in bad if p in khong_pairs),
                         gop_khac=sorted("+".join(sorted(p)) for p in bad if p not in quyet_pairs and p not in khong_pairs))
    # ---- ca cần người quyết
    rev = read_csv(run / "nghi-trung-can-quyet.csv") or []
    rev_groups = [set(split_ids(col(d, "ma_dong_goc"))) for d in rev]
    hit_flag, merged_wrong, missed = [], [], []
    for g_ in ANS["can_nguoi_quyet"]:
        p = frozenset(g_["rows"]); a, b = sorted(p)
        flagged = any(p <= s for s in rev_groups); merged = p in pred_pairs
        (merged_wrong if merged else hit_flag if flagged else missed).append(f"{a}+{b}({g_['loai']})")
        if merged and flagged: hit_flag.append(f"{a}+{b}({g_['loai']})[vừa gộp vừa báo]")
    flag_loai = Counter()
    over = []
    for s in rev_groups:
        pp = pairs_of(s)
        if not any(q in quyet_pairs for q in pp):
            over.append(sorted(s))
    R["ca_can_nguoi_quyet"] = dict(tong=len(ANS["can_nguoi_quyet"]), bao_dung_va_khong_gop=len([x for x in hit_flag if "vừa gộp" not in x]), bi_gop_luon=merged_wrong, bo_sot_khong_bao=missed,
                                    so_nhom_agent_bao=len(rev_groups), nhom_bao_thua_khong_thuoc_ca_nao=over)
    rev_on_T = [sorted(s) for s in rev_groups if any(q in khong_pairs for q in pairs_of(s))]
    R["ca_can_nguoi_quyet"]["bao_nham_vao_cap_khong_gop(T)"] = rev_on_T
    # ---- trường
    sua = read_csv(run / "nhat-ky-sua.csv") or []
    sua_old = " | ".join(str(col(d, "gia_tri_cu")) for d in sua)
    sua_old_n = akey(sua_old)
    ph_ok = ph_need = fab_ph = badfmt = em_ok = em_need = fab_em = guess_em = nm_exact = nm_key = nm_need = nm_hon = nm_title = ad_ok = ad_need = ad_abbr = ad_fab = impure = 0
    inv_ph_in_clean = inv_em_in_clean = 0; inv_ph_total = inv_em_total = inv_ph_logged = inv_em_logged = 0
    detail = []
    for rec in clean:
        ids = [i for i in split_ids(col(rec, "ma_dong_goc")) if i in ROWS]
        if not ids: continue
        ents = {ROWS[i]["entity"] for i in ids}
        sdt = [digits(x) for x in re.split(r"[;,]", col(rec, "sdt", "sdt_chinh")) if digits(x)] + [digits(x) for x in re.split(r"[;,]", col(rec, "sdt_khac")) if digits(x)]
        main_phone = col(rec, "sdt").strip()
        emails = [x.strip().lower() for x in re.split(r"[;,\s]+", col(rec, "email") + ";" + col(rec, "email_khac")) if x.strip()]
        truth_ph = {p for i in ids for p in ROWS[i]["sdt_hop_le"]}
        truth_em = {ROWS[i]["email_hop_le"] for i in ids if ROWS[i]["email_hop_le"]}
        if main_phone and not VALID_PHONE.match(main_phone): badfmt += 1
        for p in sdt:
            if p not in truth_ph: fab_ph += 1; detail.append(f"{col(rec,'ma_khach')}: SĐT lạ {p}")
        for e in emails:
            if e not in truth_em:
                fab_em += 1; detail.append(f"{col(rec,'ma_khach')}: email lạ {e}")
                for i in ids:
                    raw = ROWS[i]["email_sai_goc"]
                    if raw and e == re.sub(r"\.con$", ".com", raw.strip().lower()): guess_em += 1
        for i in ids:
            r = ROWS[i]
            for p in r["sdt_hop_le"]:
                ph_need += 1; ph_ok += p in sdt
            if r["email_hop_le"]: em_need += 1; em_ok += r["email_hop_le"].lower() in emails
            if r["sdt_sai_goc"]:
                inv_ph_total += 1; inv_ph_in_clean += digits(r["sdt_sai_goc"]) in sdt and bool(digits(r["sdt_sai_goc"]))
                inv_ph_logged += akey(r["sdt_sai_goc"]) in sua_old_n or r["sdt_sai_goc"].strip() in sua_old
            if r["email_sai_goc"]:
                inv_em_total += 1; inv_em_in_clean += r["email_sai_goc"].strip().lower() in emails
                inv_em_logged += r["email_sai_goc"].strip().lower() in sua_old.lower()
        name = nfc(col(rec, "ho_ten", "ho_va_ten", "ten")).strip()
        if len(ents) > 1: impure += 1; continue
        e = next(iter(ents)); canon = nfc(ROWS[ids[0]]["ten_chuan_thuc_the"])
        members = {nfc(ROWS[i]["ten_dong"]) for i in ids}
        if len(ids) == 1: acc = members; exp = nfc(ROWS[ids[0]]["ten_dong"])
        else:
            full = any(ROWS[i]["ten_co_dau_day_du"] for i in ids)
            acc = ({canon} if full else {m for m in members if key(m) == key(canon)}) or members
            # không dấu + viết tắt có dấu: chấp nhận cả hai (không có cách biết dấu của chữ đệm)
            exp = sorted(acc)[0]
        exp_key = key(exp) if len(ids) == 1 else key(canon)
        nm_need += 1; nm_key += (key(name) == exp_key or name in members); nm_exact += name in acc; nm_title += is_title(name); nm_hon += bool(HON.match(key(name) + " "))
        if not (key(name) == exp_key or name in members): detail.append(f"{col(rec,'ma_khach')}: tên '{name}' != '{exp}' ({','.join(ids)})")
        addr = col(rec, "dia_chi").strip(); tr_ad = {akey(ROWS[i]["dia_chi_chuan"]) for i in ids if ROWS[i]["dia_chi_chuan"]}
        if tr_ad:
            ad_need += 1; ok = akey(addr) in tr_ad; ad_ok += ok
            if not ok: detail.append(f"{col(rec,'ma_khach')}: địa chỉ '{addr}' != {sorted(tr_ad)[0]}")
        elif addr: ad_fab += 1
        ad_abbr += bool(re.search(r"(^|[\s,])(P|Q|TP|Tp|F|p|q)\.|\b(HCM|HN|TPHCM|TP\.HCM)\b|[,\s](P|Q|F|p|q)\d", addr))
    R["truong"] = dict(
        sdt_dung=f"{ph_ok}/{ph_need}", email_dung=f"{em_ok}/{em_need}",
        ten_dung_chu_khong_dau=f"{nm_key}/{nm_need}", ten_khop_chinh_xac_dau_hoa_thuong=f"{nm_exact}/{nm_need}", ten_viet_hoa_chu_dau=f"{nm_title}/{nm_need}", ten_con_danh_xung=nm_hon,
        dia_chi_khop_sau_mo_viet_tat=f"{ad_ok}/{ad_need}", dia_chi_con_viet_tat=ad_abbr, so_khach_sach_tron_nhieu_nguoi=impure,
        sdt_chinh_sai_dinh_dang=badfmt)
    R["bia_hoac_doan"] = dict(sdt_la=fab_ph, email_la=fab_em, trong_do_email_tu_sua_con_thanh_com=guess_em, dia_chi_khong_co_trong_dong_goc=ad_fab)
    R["gia_tri_sai_khong_duoc_giu_lam_gia_tri_sach"] = dict(
        sdt_sai_tong=inv_ph_total, sdt_sai_bi_giu_o_cot_sach=inv_ph_in_clean, sdt_sai_co_ghi_trong_nhat_ky_sua=inv_ph_logged,
        email_sai_tong=inv_em_total, email_sai_bi_giu_o_cot_sach=inv_em_in_clean, email_sai_co_ghi_trong_nhat_ky_sua=inv_em_logged)
    R["chi_tiet_sai_mau"] = detail[:40]; R["so_chi_tiet_sai"] = len(detail)
    R["nhat_ky_sua_so_dong"] = len(sua)
    R["so_lieu_that_de_doi_chieu_bao_cao"] = dict(so_khach=len(clean), khach_thieu_sdt=sum(1 for c in clean if not col(c, "sdt").strip()),
                                                  khach_thieu_email=sum(1 for c in clean if not col(c, "email").strip()),
                                                  khach_thieu_dia_chi=sum(1 for c in clean if not col(c, "dia_chi").strip()),
                                                  so_nhom_da_gop=sum(1 for v in clean_clusters.values() if len(v) > 1))
    # ---- script
    sc = run / "lam_sach.py"
    if sc.exists():
        src = sc.read_text(encoding="utf-8", errors="replace")
        R["script_dung_mang_hoac_mo_hinh"] = bool(re.search(r"\b(requests|urllib|http\.client|socket|anthropic|openai)\b", src))
        tmp = Path(tempfile.mkdtemp(prefix="cham_rerun_"))
        try:
            shutil.copy(ORIG_XLSX, tmp / "danh-ba-goc.xlsx"); shutil.copy(sc, tmp / "lam_sach.py")
            pr = subprocess.run([sys.executable, "-X", "utf8", "-I", "lam_sach.py"], cwd=tmp, capture_output=True, text=True, timeout=180)
            same = {}
            for n in ["nhat-ky-gop.csv", "nhat-ky-sua.csv", "nghi-trung-can-quyet.csv"]:
                a, b = run / n, tmp / n
                same[n] = bool(a.exists() and b.exists() and a.read_bytes() == b.read_bytes())
            R["chay_lai_script"] = dict(returncode=pr.returncode, giong_het=same, loi=pr.stderr[-300:] if pr.returncode else "")
        except Exception as ex:
            R["chay_lai_script"] = dict(loi=str(ex)[:200])
        finally: shutil.rmtree(tmp, ignore_errors=True)
    return R

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if "=" in a and not a.startswith("--")]
    out = _opt("--out", HERE / "bao-cao-cham.json")
    rep = {"ngay_cham": "2026-11-20", "so_dong": ANS["meta"]["so_dong"], "thong_ke_dap_an": ANS["thong_ke_loi"]["so_khach_that"], "ket_qua": {}}
    for a in args:
        lab, d = a.split("=", 1); rep["ket_qua"][lab] = score(d)
    out.write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(rep["ket_qua"], ensure_ascii=False, indent=1))
