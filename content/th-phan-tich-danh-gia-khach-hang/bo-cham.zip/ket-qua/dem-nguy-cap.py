"""Đếm ca nguy cấp theo NGƯỠNG BẠN TỰ ĐẶT: "từ N ca cùng loại trong D ngày thì báo động" (bài tập 2, bài 4).

Dùng:
  python -X utf8 dem-nguy-cap.py <nguy-cap.csv | dap-an.json> [--so-ca 3] [--so-ngay 7] [--loai ngo_doc] [--bo-nghi]
                                 [--danh-gia ../du-lieu/danh-gia.csv]

  nguy-cap.csv : file của agent (cột ma, loai, trich_dan, ly_do). Ngày lấy từ danh-gia.csv theo mã.
  dap-an.json  : đáp án (chỉ để đối chiếu; không đưa vào thư mục agent). Ca "nghi" và "ranh_gioi" tính là "nghi".
  --so-ca N    : ngưỡng số ca (mặc định 3).
  --so-ngay D  : cửa sổ D ngày liên tiếp, tính cả ngày đầu và cuối (mặc định 7).
  --loai L     : chỉ xét một loại (ngo_doc, thai_do, lua_dao); bỏ trống = xét từng loại riêng.
  --bo-nghi    : không tính các ca có ly_do bắt đầu bằng chữ "nghi" (hoặc mức nghi/ranh giới trong đáp án).

Báo động: có ít nhất N ca cùng loại với ngày đăng nằm trong cửa sổ D ngày. In ngày báo động đầu tiên
(ngày của ca thứ N trong cửa sổ) và các mã trong cửa sổ đó. Mọi số do code đếm.
Ngưỡng là quyết định kinh doanh của chủ quán, không phải số đo.
"""
import csv
import json
import sys
import datetime as dt
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent


def parse_ngay(s):
    s = s.strip()
    return dt.datetime.strptime(s, "%d/%m/%Y").date() if "/" in s else dt.date.fromisoformat(s)


def doc_ngay(duong_dan):
    return {r["ma"].strip(): parse_ngay(r["ngay"]) for r in csv.DictReader(open(duong_dan, encoding="utf-8-sig"))}


def doc_ca(nguon, ngay):
    """Trả về list (ngày, mã, loại, nghi: bool)."""
    ca = []
    if str(nguon).lower().endswith(".json"):
        g = json.loads(Path(nguon).read_text(encoding="utf-8"))
        for r in g["reviews"]:
            nc = r.get("nguy_cap")
            if nc:
                ca.append((ngay[r["ma"]], r["ma"], nc["loai"], nc["muc"] != "chac"))
    else:
        for r in csv.DictReader(open(nguon, encoding="utf-8-sig")):
            ma = r["ma"].strip()
            nghi = (r.get("ly_do") or "").strip().lower().startswith("nghi")
            ca.append((ngay[ma], ma, r["loai"].strip(), nghi))
    return sorted(ca)


def bao_dong(ca, so_ca, so_ngay):
    """Trả về (ngày báo động đầu tiên, các mã trong cửa sổ, số ngày có báo động) hoặc None."""
    ngay_bd, dau = [], None
    for i, (d, _, _, _) in enumerate(ca):
        trong = [c for c in ca[: i + 1] if (d - c[0]).days < so_ngay]
        if len(trong) >= so_ca:
            ngay_bd.append(d)
            if dau is None:
                dau = (d, [c[1] for c in trong])
    if dau is None:
        return None
    return dau[0], dau[1], len(set(ngay_bd))


def main():
    a = sys.argv[1:]
    if not a:
        raise SystemExit(__doc__)

    def opt(ten, mac_dinh):
        if ten in a:
            i = a.index(ten)
            v = a[i + 1]
            del a[i:i + 2]
            return v
        return mac_dinh

    so_ca = int(opt("--so-ca", 3))
    so_ngay = int(opt("--so-ngay", 7))
    loai = opt("--loai", None)
    dg = opt("--danh-gia", str(HERE.parent / "du-lieu" / "danh-gia.csv"))
    bo_nghi = "--bo-nghi" in a
    if bo_nghi:
        a.remove("--bo-nghi")
    nguon = a[0]
    ngay = doc_ngay(dg)
    ca = doc_ca(nguon, ngay)
    if bo_nghi:
        ca = [c for c in ca if not c[3]]
    theo_loai = defaultdict(list)
    for c in ca:
        theo_loai[c[2]].append(c)
    print(f"Ngưỡng: từ {so_ca} ca cùng loại trong {so_ngay} ngày | bỏ ca 'nghi': {'có' if bo_nghi else 'không'} | nguồn: {Path(nguon).name}")
    tong_bd = 0
    for t in ("ngo_doc", "thai_do", "lua_dao"):
        if loai and t != loai:
            continue
        c = theo_loai.get(t, [])
        kq = bao_dong(c, so_ca, so_ngay)
        if kq:
            tong_bd += 1
            print(f"  {t:8s} {len(c):2d} ca | BÁO ĐỘNG từ {kq[0].strftime('%d/%m/%Y')} ({', '.join(kq[1])}); {kq[2]} ngày có báo động")
        else:
            print(f"  {t:8s} {len(c):2d} ca | không báo động")
    print(f"Số loại báo động: {tong_bd}")


if __name__ == "__main__":
    main()
