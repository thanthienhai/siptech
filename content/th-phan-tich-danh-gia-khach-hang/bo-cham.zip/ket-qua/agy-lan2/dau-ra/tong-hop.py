import csv
import os
from datetime import datetime, timedelta
from collections import defaultdict

def resolve_path(filename):
    if os.path.exists(filename):
        return filename
    sub_path = os.path.join('dau-ra', filename)
    if os.path.exists(sub_path):
        return sub_path
    parent_path = os.path.join('..', filename)
    if os.path.exists(parent_path):
        return parent_path
    return filename

def parse_date(d_str):
    d_str = d_str.strip()
    if '-' in d_str:
        return datetime.strptime(d_str, '%Y-%m-%d')
    elif '/' in d_str:
        return datetime.strptime(d_str, '%d/%m/%Y')
    raise ValueError(f"Unknown date format: {d_str}")

def get_monday(dt):
    mon = dt - timedelta(days=dt.weekday())
    return mon.strftime('%Y-%m-%d')

def main():
    loai_bo_file = resolve_path('loai-bo.csv')
    danh_gia_file = resolve_path('danh-gia.csv')
    y_kien_file = resolve_path('y-kien.csv')

    # Read loai-bo
    removed_mas = set()
    if os.path.exists(loai_bo_file):
        with open(loai_bo_file, mode='r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                removed_mas.add(row['ma'].strip())

    # Read danh-gia for date mapping
    date_map = {}
    with open(danh_gia_file, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            ma = row['ma'].strip()
            date_str = row['ngay'].strip()
            dt = parse_date(date_str)
            date_map[ma] = get_monday(dt)

    # Read y-kien
    # Aggregation structure: data[tuan][chu_de][sac_thai] = count
    topics = ['gia', 'phuc_vu', 'chat_luong', 'giao_hang', 'khong_gian', 've_sinh', 'khac']
    sentiments = ['tich_cuc', 'tieu_cuc', 'trung_tinh', 'can_nguoi_doc']

    tuan_set = set(date_map.values())
    sorted_tuans = sorted(list(tuan_set))

    # Initialize counter
    counts = {t: {c: {s: 0 for s in sentiments} for c in topics} for t in sorted_tuans}

    total_opinions = 0
    with open(y_kien_file, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            ma = row['ma'].strip()
            if ma in removed_mas:
                continue
            chu_de = row['chu_de'].strip()
            sac_thai = row['sac_thai'].strip().lower()
            if sac_thai == 'can_nguoi_doc':
                st_key = 'can_nguoi_doc'
            else:
                st_key = sac_thai

            tuan = date_map.get(ma)
            if tuan and chu_de in topics and st_key in sentiments:
                counts[tuan][chu_de][st_key] += 1
                total_opinions += 1

    # Output to xu-huong-tuan.csv
    out_dir = 'dau-ra' if os.path.exists('dau-ra') else '.'
    out_file = os.path.join(out_dir, 'xu-huong-tuan.csv')
    with open(out_file, mode='w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['tuan', 'chu_de', 'tich_cuc', 'tieu_cuc', 'trung_tinh', 'can_nguoi_doc'])
        for t in sorted_tuans:
            for c in topics:
                row_counts = counts[t][c]
                # Only write row if there is at least one count, or write all?
                # Usually write rows for all topics each week
                writer.writerow([
                    t, c,
                    row_counts['tich_cuc'],
                    row_counts['tieu_cuc'],
                    row_counts['trung_tinh'],
                    row_counts['can_nguoi_doc']
                ])

    print(f"Ghi thanh cong {out_file}")
    print(f"Tong so y kien da tong hop: {total_opinions}")

    # Print summary table: chu_de x sac_thai
    topic_totals = {c: {s: 0 for s in sentiments} for c in topics}
    for t in sorted_tuans:
        for c in topics:
            for s in sentiments:
                topic_totals[c][s] += counts[t][c][s]

    print("\n=== BANG CHU DE x SAC THAI ===")
    print(f"{'Chu de':<15} | {'Tich cuc':<10} | {'Tieu cuc':<10} | {'Trung tinh':<10} | {'Can nguoi doc':<15} | {'Tong':<8}")
    print("-" * 75)
    total_all = {s: 0 for s in sentiments}
    for c in topics:
        tot_row = sum(topic_totals[c].values())
        for s in sentiments:
            total_all[s] += topic_totals[c][s]
        print(f"{c:<15} | {topic_totals[c]['tich_cuc']:<10} | {topic_totals[c]['tieu_cuc']:<10} | {topic_totals[c]['trung_tinh']:<10} | {topic_totals[c]['can_nguoi_doc']:<15} | {tot_row:<8}")
    print("-" * 75)
    print(f"{'TONG CONG':<15} | {total_all['tich_cuc']:<10} | {total_all['tieu_cuc']:<10} | {total_all['trung_tinh']:<10} | {total_all['can_nguoi_doc']:<15} | {sum(total_all.values()):<8}")

    # Print weekly trend summary
    print("\n=== XU HUONG THEO TUAN (TONG CAC CHU DE) ===")
    print(f"{'Tuan':<12} | {'Tich cuc':<10} | {'Tieu cuc':<10} | {'Trung tinh':<10} | {'Can nguoi doc':<15} | {'Tong y kien':<12}")
    print("-" * 75)
    for t in sorted_tuans:
        t_tc = sum(counts[t][c]['tich_cuc'] for c in topics)
        t_ti = sum(counts[t][c]['tieu_cuc'] for c in topics)
        t_tr = sum(counts[t][c]['trung_tinh'] for c in topics)
        t_cd = sum(counts[t][c]['can_nguoi_doc'] for c in topics)
        t_tot = t_tc + t_ti + t_tr + t_cd
        print(f"{t:<12} | {t_tc:<10} | {t_ti:<10} | {t_tr:<10} | {t_cd:<15} | {t_tot:<12}")

if __name__ == '__main__':
    main()
