"""Dựng lại TOÀN BỘ ảnh trong ../anh/ từ log đã che (logs/*.json) và kết quả trong ket-qua/.

Chạy:  python -X utf8 dung_anh.py [--term-dir <thu_muc_chua_term.py>]
Cần: term.py (có render_blocks, shot_html, scrub_text) — mặc định tìm theo biến môi trường TERM_DIR,
     rồi theo --term-dir, rồi thư mục ../../../../../siptech-video/agentlab.
Mọi chuỗi lấy từ log hoặc đường dẫn đều đi qua scrub_text trước khi vào HTML.
Ảnh terminal là bản dựng lại từ log, không phải ảnh chụp trực tiếp cửa sổ TUI.
"""
import argparse, csv, html, json, os, re, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
B = HERE.parent
ap = argparse.ArgumentParser(); ap.add_argument("--term-dir", default=None); a = ap.parse_args()
cands = [a.term_dir, os.environ.get("TERM_DIR"), str(B.parents[3] / "siptech-video" / "agentlab"), r"C:\Users\user\Coding\nguoi-dung\siptech-video\agentlab"]
for c in cands:
    if c and (Path(c) / "term.py").exists(): sys.path.insert(0, c); break
else:
    raise SystemExit("không tìm thấy term.py; dùng --term-dir")
from term import render_blocks, shot_html, scrub_text as S
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt

ANH = B / "anh"; ANH.mkdir(exist_ok=True)
K = HERE; LOGS = B / "logs"

def term_img(log, out, title, rng, maxlines, clean_agy=False, width=1280):
    t = json.loads((LOGS / log).read_text(encoding="utf-8"))
    bl = t["blocks"]
    if clean_agy:  # bỏ cảnh báo cấu hình PowerShell của máy chạy khỏi phần hiển thị (không sửa log)
        for b in bl:
            o = b.get("output") or ""
            o = re.sub(r"\.: C:.{0,900}?try again\.\n?", "", o, flags=re.S)
            o = re.sub(r"Created At:.*?\nCompleted At:.*?\n", "", o).replace("Command output:\n", "")
            b["output"] = re.sub(r"\n{2,}", "\n", o).strip()
    for b in bl:  # che thêm tên chủ sở hữu file trong kết quả lệnh ls (vd "user 197121")
        if isinstance(b.get("output"), str): b["output"] = re.sub(r" PC (\d{5,}) ", r" user \1 ", b["output"])
    s, e = rng
    h = render_blocks(bl[s:e], title, t["prompt"], maxlines, width, False)
    shot_html(h, str(ANH / out), width + 40, ".win")

# ---- terminal: agent đang làm + kết quả cuối
term_img("claude-lan1.json", "b-claude-dang-lam.png", "claude · phân tích đánh giá (lan1)", (0, 17), 5)
term_img("claude-lan1.json", "c-claude-ket-qua-cuoi.png", "claude · báo cáo cuối của agent (lan1)", (31, 33), 30)
term_img("agy-lan2.json", "b-agy-dang-lam.png", "agy · phân tích đánh giá (lan2)", (0, 14), 6, clean_agy=True)
term_img("agy-lan2.json", "c-agy-ket-qua-cuoi.png", "agy · báo cáo cuối của agent (lan2)", (60, 61), 40, clean_agy=True)

# ---- (a) prompt
p = S((K / "prompt-giao-viec.txt").read_text(encoding="utf-8"))
body = html.escape(p)
for k in ["VAI TRÒ", "BỐI CẢNH", "NHIỆM VỤ", "CÁC BƯỚC", "ĐỊNH DẠNG RA", "RÀNG BUỘC"]:
    body = body.replace(k, f"<b>{k}</b>", 1)
h = f"""<!doctype html><meta charset=utf-8><style>
body{{margin:0;background:#e9edf5;font-family:'Segoe UI',sans-serif}}.w{{width:1180px;padding:18px;background:#e9edf5}}
.card{{background:#fff;border-radius:10px;padding:16px 22px;box-shadow:0 4px 18px rgba(11,31,77,.18);font-size:14.5px;line-height:1.5;white-space:pre-wrap;color:#0f172a}}
.card b{{color:#0b1f4d}}</style><div class=w id=w><div class=card>{body}</div></div>"""
shot_html(h, str(ANH / "a-prompt-giao-viec.png"), 1220, "#w")

# ---- (d) dữ liệu đầu vào
rows = {r["ma"]: r for r in csv.DictReader(open(B / "du-lieu" / "danh-gia.csv", encoding="utf-8"))}
gold = {g["ma"]: g for g in json.loads((K / "dap-an.json").read_text(encoding="utf-8"))["reviews"]}
pick = []
def first(pred, n=1):
    c = 0
    for m, g in gold.items():
        if pred(g) and m not in pick:
            pick.append(m); c += 1
            if c >= n: return
first(lambda g: g["mia_mai"] and g["tuan"] >= "2026-09-14", 2)
first(lambda g: g["nguy_cap"] and g["nguy_cap"]["loai"] == "ngo_doc" and g["nguy_cap"]["muc"] == "chac", 1)
first(lambda g: g["nguy_cap"] and g["nguy_cap"]["loai"] == "lua_dao", 1)
first(lambda g: g["bay_tu_khoa"], 2)
first(lambda g: g["loai_bo"] and g["loai_bo"]["ly_do"] == "trung_lap", 1)
first(lambda g: g["mo_ho"], 1)
first(lambda g: len(g["aspects"]) >= 3 and not g["viet_tay"], 1)
first(lambda g: not g["viet_tay"] and any(ord(c) > 0x2000 for c in rows[g["ma"]]["noi_dung"]) and len(g["aspects"]) == 2, 1)
pick = sorted(pick)
trs = "".join(f"<tr><td>{r['ma']}</td><td>{html.escape(S(r['nen_tang']))}</td><td>{r['ngay']}</td><td>{r['sao'] or '<i>(trống)</i>'}</td><td class=t>{html.escape(S(r['noi_dung']))}</td></tr>" for r in (rows[m] for m in pick))
h = f"""<!doctype html><meta charset=utf-8><style>
body{{margin:0;background:#fff;font-family:'Segoe UI',sans-serif}}.w{{width:1280px;padding:14px;background:#fff}}
h3{{margin:0 0 8px;font-size:17px;color:#0b1f4d}}table{{border-collapse:collapse;width:100%;font-size:14.5px}}
th{{background:#0b1f4d;color:#fff;padding:7px 9px;text-align:left}}td{{border:1px solid #cbd5e1;padding:6px 9px;vertical-align:top}}
tr:nth-child(even) td{{background:#f1f5f9}}.t{{width:720px}}.n{{margin-top:8px;font-size:13px;color:#b91c1c}}</style>
<div class=w id=w><h3>danh-gia.csv — {len(rows)} dòng (trích {len(pick)} dòng; từ trái sang: mã, nền tảng, ngày, sao, nội dung)</h3>
<table><tr><th>ma</th><th>nen_tang</th><th>ngay</th><th>sao</th><th>noi_dung</th></tr>{trs}</table>
<div class=n>Dữ liệu giả để học (quán hư cấu, không có người/doanh nghiệp thật), sinh bằng du-lieu/sinh_du_lieu.py, hạt giống 20261120.</div></div>"""
shot_html(h, str(ANH / "d-du-lieu-dau-vao.png"), 1320, "#w")

# ---- (e) biểu đồ xu hướng từ xu-huong-tuan.csv của claude-lan1
xr = list(csv.DictReader(open(K / "claude-lan1/dau-ra/xu-huong-tuan.csv", encoding="utf-8")))
weeks = sorted({r["tuan"] for r in xr})
names = {"gia": "Giá", "giao_hang": "Giao hàng", "ve_sinh": "Vệ sinh", "phuc_vu": "Phục vụ", "chat_luong": "Chất lượng", "khong_gian": "Không gian"}
fig, axs = plt.subplots(2, 3, figsize=(12.5, 6.2), sharex=True)
for ax, t in zip(axs.flat, ["gia", "giao_hang", "ve_sinh", "phuc_vu", "chat_luong", "khong_gian"]):
    g_ = lambda w, c: int(next(r for r in xr if r["tuan"] == w and r["chu_de"] == t)[c])
    x = range(len(weeks))
    ax.bar([i - 0.2 for i in x], [g_(w, "tich_cuc") for w in weeks], 0.4, color="#2f855a", label="tích cực")
    ax.bar([i + 0.2 for i in x], [g_(w, "tieu_cuc") for w in weeks], 0.4, color="#c53030", label="tiêu cực")
    ax.set_title(names[t], fontsize=12, fontweight="bold"); ax.set_xticks(list(x))
    ax.set_xticklabels([w[8:10] + "/" + w[5:7] for w in weeks], rotation=60, fontsize=8); ax.grid(axis="y", alpha=.3)
axs[0, 0].legend(fontsize=9)
fig.suptitle("Số ý kiến theo tuần và chủ đề, lấy từ xu-huong-tuan.csv của agent (claude, lan1). Dữ liệu giả để học.", fontsize=11)
fig.tight_layout(rect=[0, 0, 1, 0.95]); fig.savefig(ANH / "e-xu-huong-tuan.png", dpi=130); plt.close(fig)

# ---- (e2) trích bao-cao.md
bc = S((K / "claude-lan1/dau-ra/bao-cao.md").read_text(encoding="utf-8"))
def sect(n): return re.search(rf"^## Việc {n}:.*?(?=^## |\Z)", bc, flags=re.S | re.M).group(0).strip()
def md2html(s):
    out = []
    for l in s.splitlines():
        e = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", html.escape(l))
        if l.startswith("## "): out.append(f"<h3>{e[3:]}</h3>")
        elif l.startswith(">"): out.append(f"<div class=q>{e.replace('&gt;', '', 1).strip()}</div>")
        elif l.startswith("- "): out.append(f"<div class=li>• {e[2:]}</div>")
        elif l.strip(): out.append(f"<p>{e}</p>")
    return "".join(out)
body = md2html(sect(1)) + "<hr>" + md2html(sect(3))
h = f"""<!doctype html><meta charset=utf-8><style>
body{{margin:0;background:#e9edf5;font-family:'Segoe UI',sans-serif}}.w{{width:1180px;padding:18px;background:#e9edf5}}
.c{{background:#fff;border-radius:10px;padding:14px 24px;box-shadow:0 4px 18px rgba(11,31,77,.18);font-size:14.5px;line-height:1.5;color:#0f172a}}
h3{{color:#0b1f4d;margin:10px 0 6px;font-size:18px}}p{{margin:6px 0}}.li{{margin:2px 0 2px 14px}}
.q{{margin:3px 0 3px 10px;padding:4px 10px;border-left:4px solid #2563eb;background:#eff6ff}}hr{{border:0;border-top:2px dashed #cbd5e1;margin:12px 0}}
.n{{font-size:12.5px;color:#b91c1c;margin-top:8px}}</style><div class=w id=w><div class=c>{body}<div class=n>Trích từ dau-ra/bao-cao.md do claude viết ở lần chạy claude-lan1 (chỉ trích Việc 1 và Việc 3; nguyên văn từng mục). Dữ liệu giả để học.</div></div></div>"""
shot_html(h, str(ANH / "e2-bao-cao-5-viec.png"), 1220, "#w")

# ---- (f) bảng chấm
R = json.loads((K / "bao-cao-cham.json").read_text(encoding="utf-8"))
meta = {"claude-lan0": ("claude", "lần 0 (không có log)", "khoảng 6 phút (theo giờ tạo file)"), "claude-lan1": ("claude", "lần 1 (có log)", "454,5 giây"),
        "agy-lan0": ("agy", "lần 0 (không có log)", "khoảng 13 phút (theo giờ tạo file)"), "agy-lan1-het-gio": ("agy", "lần 1: hết 900 giây", "bị dừng ở 900 giây"),
        "agy-lan2": ("agy", "lần 2 (có log, timeout 1500 giây)", "957,9 giây")}
def cell(r):
    nc, mm, lb, cd, st, xh, bc_ = r["nguy_cap"], r["mia_mai"], r["loai_bo"], r["chu_de"], r["sac_thai"], r["xu_huong"], r.get("bao_cao")
    return [f'{lb["tp"]}/{lb["gold"]}', f'{cd["tp"]}/{cd["tp"]+cd["fn"]} (thừa {cd["fp"]})', f'{st["dung"]}/{st["dung"]+st["sai"]} (hoãn {st["hoan_CAN_NGUOI_DOC"]})',
            f'{mm["tp"]}/{mm["gold"]}', f'{nc["tp"]}/{nc["tp"]+nc["fn"]} (thừa {nc["fp"]})',
            f'{r["trich_dan_y_kien"]["khong_nguyen_van"]+r["trich_dan_nguy_cap"]["khong_nguyen_van"]+(bc_["trich_dan_khong_nguyen_van"] if bc_ else 0)}/{r["trich_dan_y_kien"]["tong"]+r["trich_dan_nguy_cap"]["tong"]+(bc_["so_trich_dan"] if bc_ else 0)}',
            f'{xh["tong_sai_lech_tuyet_doi_so_voi_dap_an"]} / {xh["tong_so_dem_dap_an"]}',
            (f'{bc_["so_muc_viec"]} mục, phủ {len(bc_["van_de_cai_sao_duoc_phu"])}/5 vấn đề cài' if bc_ else "KHÔNG CÓ bao-cao.md")]
labels = ["Loại bỏ đúng (trùng, spam, câu hỏi)", "Chủ đề tìm đủ (cặp bài x chủ đề)", "Sắc thái đúng (không tính mỉa mai)", "Mỉa mai vào CẦN NGƯỜI ĐỌC",
          "Nguy cấp bắt được (bắt nhầm)", "Trích dẫn KHÔNG nguyên văn / tổng", "Sai lệch số đếm theo tuần / tổng đếm", "Báo cáo 5 việc"]
cols = {k: cell(R[k]) for k in R}
ths = "".join(f"<th>{meta[k][0]}<br><span>{meta[k][1]}<br>{meta[k][2]}</span></th>" for k in R)
trs = "".join(f"<tr><td class=l>{labels[i]}</td>" + "".join(f"<td>{S(cols[k][i])}</td>" for k in R) + "</tr>" for i in range(len(labels)))
h = f"""<!doctype html><meta charset=utf-8><style>
body{{margin:0;background:#fff;font-family:'Segoe UI',sans-serif}}.w{{width:1300px;padding:14px;background:#fff}}h3{{margin:0 0 8px;color:#0b1f4d}}
table{{border-collapse:collapse;width:100%;font-size:14.5px}}th{{background:#0b1f4d;color:#fff;padding:7px;font-size:14.5px}}th span{{font-weight:400;font-size:12px;color:#cbd5e1}}
td{{border:1px solid #cbd5e1;padding:7px 9px;text-align:center}}td.l{{text-align:left;background:#f1f5f9;font-weight:600}}.n{{margin-top:8px;font-size:12.5px;color:#b91c1c}}</style>
<div class=w id=w><h3>Kết quả chấm bằng ket-qua/cham.py (n = 1 hoặc 2 lần chạy mỗi agent)</h3><table><tr><th></th>{ths}</tr>{trs}</table>
<div class=n>Dữ liệu giả để học (250 bài). Đây là kết quả của vài lần chạy, chưa đo được độ ổn định, không dùng để kết luận agent nào tốt hơn.</div></div>"""
shot_html(h, str(ANH / "f-bang-cham.png"), 1340, "#w")

# ---- (g) ca agent khác đáp án (chọn tay từ bao-cao-cham.json / y-kien.csv)
cases = [
 ("R191", "loại bỏ: spam (quảng cáo quán khác)", "loại bỏ: spam, kèm câu hỏi người quyết", "không loại; chu_de=khac, CAN_NGUOI_DOC"),
 ("R105", "phuc_vu tiêu cực; chat_luong tích cực", "chat_luong = trung_tinh (lệch 1 ý)", "khớp đáp án"),
 ("R202", "mỉa mai: CAN_NGUOI_DOC, chủ đề giao_hang", "CAN_NGUOI_DOC, giao_hang (đúng)", "CAN_NGUOI_DOC nhưng gán chat_luong (lệch chủ đề)"),
 ("R135", "ca ranh giới: gia tiêu cực + phuc_vu tích cực", "tách đúng 2 ý, ghi nguy cấp 'nghi'", "gia = CAN_NGUOI_DOC, mất ý phuc_vu, ghi nguy cấp 'nghi'"),
 ("R157", "ve_sinh tích cực; khong_gian trung tính", "khớp đáp án", "bỏ sót ý khong_gian")]
trs = "".join(f"<tr><td>{m}</td><td class=t>{html.escape(S(rows[m]['noi_dung']))}</td><td>{html.escape(g_)}</td><td>{html.escape(c)}</td><td>{html.escape(ag)}</td></tr>" for m, g_, c, ag in cases)
h = f"""<!doctype html><meta charset=utf-8><style>
body{{margin:0;background:#fff;font-family:'Segoe UI',sans-serif}}.w{{width:1320px;padding:14px;background:#fff}}h3{{margin:0 0 8px;color:#0b1f4d}}
table{{border-collapse:collapse;width:100%;font-size:14px}}th{{background:#0b1f4d;color:#fff;padding:7px;text-align:left}}td{{border:1px solid #cbd5e1;padding:7px 9px;vertical-align:top}}
td.t{{width:330px;background:#f8fafc}}.n{{margin-top:8px;font-size:12.5px;color:#b91c1c}}</style>
<div class=w id=w><h3>Một số ca agent khác đáp án (claude-lan1 và agy-lan2 so với dap-an.json)</h3>
<table><tr><th>mã</th><th>nội dung gốc</th><th>đáp án cài sẵn</th><th>claude (lan1)</th><th>agy (lan2)</th></tr>{trs}</table>
<div class=n>Dữ liệu giả để học. Lưu ý: vài ca (R191, R105, R135) chính đáp án cũng gây tranh cãi, xem bài 2.</div></div>"""
shot_html(h, str(ANH / "g-ca-khac-dap-an.png"), 1360, "#w")
print("xong:", sorted(p.name for p in ANH.glob("*.png")))
