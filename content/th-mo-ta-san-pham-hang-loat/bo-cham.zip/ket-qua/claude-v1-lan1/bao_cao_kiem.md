# Báo cáo kiểm nội dung đăng bán, shop "Vườn Nhỏ"

Ngày làm: 2026-11-20. File nộp: `nhap_hang_loat.csv` (UTF-8 có BOM), `nhap_hang_loat.xlsx`. Script kiểm: `kiem.py`.

## 1. Tóm tắt

| Chỉ số | Số lượng |
|---|---|
| Tổng sản phẩm | 40 |
| Sẵn sàng đăng (`SAN_SANG`) | **31** |
| Cần bổ sung (`CAN_BO_SUNG`) | **9** |

Mọi nội dung chỉ lấy từ các cột sự thật trong `thong_so.csv`. Cột `ghi_chu_noi_bo` không được dùng làm nguồn. Chỗ thiếu thông tin được ghi đúng cụm `CẦN BỔ SUNG: <tên cột>` trong mô tả và trong gạch đầu dòng tương ứng.

## 2. Sản phẩm cần bổ sung và trường thiếu theo từng SKU

Giá trị thiếu gồm: ô trống, `?`, `chưa rõ`, `liên hệ NCC`, `N/A`, `chưa có`. Sáu trường bắt buộc: dung_tich, thanh_phan_noi_bat, xuat_xu, han_su_dung, cong_dung_tren_bao_bi, cach_dung.

| SKU | Sản phẩm | Trường thiếu | Giá trị trong bảng |
|---|---|---|---|
| VN-007 | Nước cân bằng da Mầm Xanh | dung_tich; thanh_phan_noi_bat; xuat_xu; han_su_dung; cong_dung_tren_bao_bi; cach_dung | để trống cả dòng |
| VN-009 | Tinh chất dưỡng da Suối Mát | xuat_xu | trống |
| VN-014 | Kem dưỡng ẩm Suối Mát | xuat_xu; han_su_dung | `N/A`; `?` |
| VN-019 | Kem chống nắng Mầm Xanh | thanh_phan_noi_bat; cong_dung_tren_bao_bi | `liên hệ NCC`; `?` |
| VN-025 | Son dưỡng môi Suối Mát | thanh_phan_noi_bat | `chưa rõ` |
| VN-027 | Dầu gội Đồi Chè | cach_dung | `chưa có` |
| VN-029 | Dầu gội Mầm Xanh | dung_tich | trống |
| VN-034 | Kem dưỡng da tay Đồi Chè | dung_tich; han_su_dung | `?`; `N/A` |
| VN-038 | Nước tẩy trang Đồi Chè | dung_tich | trống |

Riêng VN-007, ngoài 6 trường bắt buộc, các cột `loai_da_phu_hop` và `mui_huong` cũng trống. Hai cột này không bắt buộc nên tôi không đưa vào `truong_can_bo_sung` và không viết gì về chúng. Shop nên bổ sung luôn khi liên hệ NCC.

Tiêu đề của VN-007, VN-029, VN-034 và VN-038 không có dung tích vì bảng không có. Khi có số liệu, cần thêm dung tích vào tiêu đề theo cấu trúc quy định.

## 3. Chỗ nghi ngờ, cần người quyết

**Cần quyết trước khi đăng (ảnh hưởng nội dung đã viết):**

1. **VN-012 (vitamin C): 10% hay 15%.** Bảng ghi 10%. Ghi chú nội bộ nói kỹ thuật cho rằng thực tế là 15%, đang chờ phiếu kiểm nghiệm. Tôi viết đúng bảng (10%) và xếp `SAN_SANG`. Nếu số 10% có thể sai, hãy giữ sản phẩm này lại cho đến khi có kiểm nghiệm. Con số nồng độ nằm trong tiêu chí "số phải đúng bảng", nên đăng sai là rủi ro thật.
2. **VN-003: "mọi loại da" với da nhạy cảm.** Bảng ghi "mọi loại da". Ghi chú nói chưa test da nhạy cảm nhưng vẫn muốn ghi phù hợp da nhạy cảm. Tôi **không** ghi "da nhạy cảm". Tôi vẫn giữ "mọi loại da" vì đó là giá trị trong bảng, nhưng cụm này về nghĩa bao gồm da nhạy cảm. Người phụ trách nên quyết giữ nguyên hay sửa lại cột `loai_da_phu_hop` trong bảng.
3. **VN-018: xuất xứ.** Bảng ghi xuất xứ Việt Nam, ghi chú đề nghị nói "hàng nhập khẩu chính ngạch". Hai điều này mâu thuẫn. Tôi ghi Việt Nam theo bảng và không dùng cụm "nhập khẩu". Cần người xác nhận lại xuất xứ thật.
4. **Số phiếu công bố dạng `DEMO-xxxx`.** 10 sản phẩm có số phiếu: VN-004, 008, 012, 020, 021, 023, 024, 025, 026, 035. Đúng quy định, tôi nêu "đã có phiếu công bố số ..." kèm số trong bảng. Nhưng các số này mang tiền tố `DEMO`, trông như dữ liệu mẫu. Cần người xác nhận đây là số phiếu thật trước khi đăng. Nếu không, hãy xóa câu này khỏi mô tả.

**Ghi chú nội bộ tôi cố ý không dùng (lời đồn hoặc từ cấm, chưa kiểm chứng):**

| SKU | Nội dung ghi chú | Lý do không dùng |
|---|---|---|
| VN-009 | "bán chạy số 1 khu vực" | từ cấm; không có số liệu |
| VN-010 | "chưa chắc cồn hay không" | chưa rõ, không khẳng định có/không cồn |
| VN-011 | "15 tháng bảo quản sau khi mở" | chưa chắc; chỉ dùng hạn dùng 30 tháng của bảng |
| VN-014 | "không paraben" (NCC nói miệng) | chưa có giấy |
| VN-019 | "trắng da sau 7 ngày" | từ cấm "trắng da sau", cam kết kết quả |
| VN-020 | "dùng được cho bà bầu và em bé" | chưa kiểm tra |
| VN-022 | "tốt nhất thị trường" | từ cấm "tốt nhất" |
| VN-024 | "chữa khỏi viêm da" | từ cấm; cam kết điều trị |
| VN-028 | "dùng 2 tuần hết mụn hẳn" | từ cấm "hết mụn"; lời khách, chưa kiểm chứng |
| VN-030 | "rẻ hơn đối thủ 30%" | từ cấm "đối thủ"; so sánh với người bán khác |
| VN-033 | "dùng 1 chai là hết nám" | từ cấm "hết nám"; cam kết kết quả |
| VN-039 | "đạt chuẩn FDA Mỹ" | chưa có giấy |

**Quyết định cách viết tôi tự chọn (nên xem lại):**

- Phiếu công bố chỉ được nêu khi bảng có số phiếu. VN-001, 027, 028, 034 ghi "đang chờ duyệt" nên không nhắc. 26 sản phẩm để trống cột này nên cũng không nhắc. Không sản phẩm nào bị nói là "đã công bố" sai.
- VN-025 có số phiếu `DEMO-8057` nhưng thiếu thành phần. Số phiếu vẫn được nêu, thành phần ghi `CẦN BỔ SUNG`.
- Nhãn kích thước theo đơn vị trong bảng: "Dung tích" cho ml, "Khối lượng" cho g, "Quy cách" cho "hộp 5/10 miếng" (3 mặt nạ giấy). Tôi suy ra từ đơn vị trong chính ô đó, không thêm thông tin.
- Giới hạn độ dài là giả định nội bộ của shop, không phải quy định của sàn. Nếu sàn có giới hạn riêng, cần so lại trước khi nhập.
- Câu mở và câu chốt trong mô tả ("Vườn Nhỏ giới thiệu đến bạn ...", "Bạn xem kỹ thông số rồi chọn sản phẩm hợp với mình nhé.") là câu giữ giọng thương hiệu, không chứa thông số nào. Các mô tả khá giống nhau vì bảng thông số chỉ có từng ấy thông tin.

## 4. Kết quả chạy `kiem.py`

Lệnh: `python kiem.py` (mã thoát 0).

```
Số dòng: 40 | SAN_SANG: 31 | CAN_BO_SUNG: 9
  VN-007: thiếu dung_tich;thanh_phan_noi_bat;xuat_xu;han_su_dung;cong_dung_tren_bao_bi;cach_dung
  VN-009: thiếu xuat_xu
  VN-014: thiếu xuat_xu;han_su_dung
  VN-019: thiếu thanh_phan_noi_bat;cong_dung_tren_bao_bi
  VN-025: thiếu thanh_phan_noi_bat
  VN-027: thiếu cach_dung
  VN-029: thiếu dung_tich
  VN-034: thiếu dung_tich;han_su_dung
  VN-038: thiếu dung_tich

SẠCH: 0 lỗi (cấu trúc, độ dài, từ cấm, con số, trạng thái, sự thật, giọng, CSV = XLSX).
```

`kiem.py` kiểm các nhóm sau:

- **Cấu trúc:** đúng 11 cột theo thứ tự, đủ 40 SKU đúng thứ tự, CSV có BOM, CSV và XLSX giống nhau từng ô.
- **Độ dài:** tiêu đề 34 đến 69 ký tự (giới hạn 25 đến 100). Mô tả 361 đến 526 ký tự (giới hạn 200 đến 1500). Gạch dài nhất 101 ký tự (tối đa 120). Từ khóa 6 đến 10 cụm, mỗi cụm tối đa 30 ký tự.
- **Gạch đầu dòng:** mọi dòng có đủ 5 gạch, không gạch nào trống.
- **Từ cấm:** quét 5 trường, so cả dạng có dấu, không dấu và viết hoa.
- **Con số:** mọi số trong tiêu đề, mô tả, gạch, từ khóa phải xuất hiện trong các ô của đúng SKU đó, không tính `ghi_chu_noi_bo` và `sku`.
- **Trạng thái:** `trang_thai` và `truong_can_bo_sung` khớp trường thật sự thiếu; cụm `CẦN BỔ SUNG: ...` chỉ đặt cho trường thiếu thật.
- **Sự thật:** giá trị từng trường bắt buộc xuất hiện nguyên văn trong mô tả; giá trị "thiếu" (`?`, `N/A`...) không bị chép vào nội dung; không có chỉ số chống nắng khi bảng không có; chỉ nhắc phiếu công bố khi có số phiếu và phải kèm đúng số đó.
- **Ghi chú nội bộ:** không chép cụm 3 từ liên tiếp từ `ghi_chu_noi_bo`; không có các cụm rủi ro (da nhạy cảm, bà bầu, cồn, paraben, FDA, nhập khẩu, ...) nếu cụm đó không có trong các ô sự thật của sản phẩm.
- **Giọng thương hiệu:** không emoji, không viết HOA nhấn mạnh, tối đa 1 dấu "!", không dùng "quý khách / chị em / chúng tôi", tiêu đề mở đầu bằng "Vườn Nhỏ".

Tôi đã thử bắt lỗi bằng 12 lỗi cố ý đưa vào bản sao trong bộ nhớ. Trong đó có từ cấm, số 15% sai, nhắc phiếu khi mới "đang chờ duyệt", da nhạy cảm, xuất xứ sai, trạng thái sai, gạch quá dài, sai số phiếu, bà bầu, từ cấm không dấu và thiếu từ khóa. `kiem.py` bắt được cả 12. Các lỗi này không được ghi vào file nộp.

**Chưa sạch / giới hạn của việc kiểm:**

- `kiem.py` kiểm được từ cấm, con số, trạng thái, cấu trúc và độ dài. Nó **không** thay được việc người đọc kiểm xem câu có đúng nghĩa với bảng hay không. Danh sách cụm rủi ro từ ghi chú nội bộ là danh sách tôi viết tay theo 40 dòng hiện có.
- Mục 3 (VN-012, VN-003, VN-018, số phiếu `DEMO-`) là việc người phải quyết. `kiem.py` không đánh giá được chúng.
