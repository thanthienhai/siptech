# Báo cáo kiểm tra chấm công tháng 09/2026

Chương trình `tinh_cong.py` tính toàn bộ số liệu; mọi ngưỡng lấy từ `quy_dinh_cong_ty.md` (tham số giả định của công ty). Báo cáo chỉ chuẩn bị dữ liệu để quản lý xác nhận, không quyết định lương hay xử lý nhân sự.

## 1. Số liệu tóm tắt
- 25 nhân viên × 30 ngày = 750 dòng bảng công. Trạng thái: **OK 501**, PHEP 12, NGHI 207, **CHO_XAC_NHAN 30**.
- 501 ngày công, 3998.11 giờ công, làm thêm 104.25 giờ (chỉ cộng ngày OK), 12 lần đi trễ, 6 lần về sớm.
- 61 bất thường: **37 cần người quyết**, 24 không cần (QUET_TRUNG 6, DI_TRE 12, VE_SOM 6).
- 30 ngày CHO_XAC_NHAN **chưa được tính giờ công**; cần xác nhận trước khi tính lương.

## 2. Việc quản lý cần xác nhận (gom theo loại)
| Loại | Số | Mã NV (ngày 09/2026) |
|---|---|---|
| VANG_CHUA_GHI | 6 | NV-002 (22), NV-003 (28), NV-010 (21), NV-023 (11), NV-024 (21), NV-026 (24) |
| THIEU_RA | 5 | NV-011 (14), NV-013 (05), NV-025 (28), NV-026 (10, 25) |
| THIEU_VAO | 3 | NV-011 (24), NV-013 (13), NV-021 (10) |
| THIEU_KHONG_RO | 3 | NV-013 (06), NV-023 (30), NV-025 (11) |
| NGHI_QUET_HO | 4 | NV-009 (23), NV-015 (20), NV-016 (24), NV-022 (24) |
| LAM_NGAY_LE | 3 | NV-007 (01), NV-010 (02), NV-018 (02) |
| LAM_NGAY_NGHI | 4 | NV-013 (12), NV-014 (24), NV-016 (12), NV-022 (27) |
| CO_PHEP_NHUNG_QUET | 2 | NV-010 (23), NV-023 (23) |
| OT_VUOT_NGUONG | 3 | NV-010 (28), NV-013 (26), NV-025 (10) |
| OT_THANG_VUOT | 1 | NV-001: 44.95 giờ (ngưỡng 40 giờ); mỗi ngày làm thêm 125-150 phút nên không vượt ngưỡng ngày |
| DU_LIEU_LOI | 3 | NV-005 (11; mã không có trong danh sách), NV-007 (dòng 298 trống giờ), NV-023 (dòng 897 ghi ngày 31/09/2026, không tồn tại) |

NGHI_QUET_HO chỉ là dấu hiệu từ giờ quẹt ở hai máy; người có thẩm quyền cần xác minh, chương trình không kết luận gì. Giờ làm thêm, nghỉ lễ, nghỉ phép: cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự. Chi tiết và lời giải thích từng dòng nằm trong `bat_thuong.csv`.

## 3. Giả định đã dùng
1. Quẹt trùng so với quẹt đang được giữ (cùng máy, <= 3 phút). Dữ liệu duy nhất có chuỗi 3 quẹt (NV-002 ngày 28) cho cùng kết quả theo cả hai cách hiểu.
2. Ngày OFF hoặc lễ nằm trong đơn nghỉ phép thì ghi NGHI, không ghi PHEP (quy định mục 5 viết cho ngày làm việc). Ví dụ NV-009 ngày 05-06 và NV-020 ngày 30.
3. Chỉ ngày OK mới có số liệu giờ công, trễ, sớm, làm thêm; các ngày khác để trống các cột này (kể cả PHEP, NGHI).
4. Ngày CHO_XAC_NHAN: `gio_vao`/`gio_ra` chỉ điền khi xác định được (quẹt đơn lẻ hiểu theo mục 4; ngày lễ/nghỉ/phép có >= 2 quẹt thì quẹt đầu/cuối). Ngày NGHI_QUET_HO để trống; ngày đó không xét thêm trễ, sớm, làm thêm.
5. Nghi quẹt hộ xét sau khi đã bỏ quẹt trùng. Làm thêm trong tháng chỉ cộng các ngày OK, chưa gồm ngày chờ xác nhận.
6. `tong_gio_cong` là tổng các giờ công đã làm tròn từng ngày. `so_bat_thuong` đếm mọi dòng của người đó trong `bat_thuong.csv`.

## 4. Điều chưa chắc
- **Quẹt ở máy khác chi nhánh: CẦN NGƯỜI QUYẾT.** Có 6 quẹt như vậy; 4 nằm trong các ngày NGHI_QUET_HO ở trên. Hai ngày còn lại là NV-012 ngày 22 (quẹt ra ở MAY-A1) và NV-025 ngày 29 (quẹt ra ở MAY-B1); quy định không nói đây là lỗi nên chương trình tính bình thường (OK). Cần xác nhận có quy tắc về quẹt khác chi nhánh không.
- **Nghỉ không lương:** đơn NV-012 ngày 28 là "Việc riêng không lương" nhưng quy định xếp mọi đơn đã duyệt vào PHEP, nên nằm trong `so_ngay_phep`. Cần nhân sự phân loại lại nếu muốn tách.
- NV-005 không có trong `nhan_vien.csv` (không có dòng ở `tong_hop_nguoi.csv`); dòng lỗi của NV-007, NV-023 không xác định được ngày. Chương trình không suy ra liên hệ giữa các dòng lỗi này với ngày vắng của cùng người.
- NV-004 làm thêm 36.18 giờ, chưa vượt ngưỡng tháng nên không có cảnh báo, nhưng gần ngưỡng.
- Mọi ngưỡng là tham số giả định, chưa đối chiếu với quy định pháp luật.
- CSV mã hóa UTF-8 không BOM; Excel có thể cần nhập dữ liệu theo UTF-8 để hiển thị đúng tiếng Việt.
