# Báo cáo làm sạch danh bạ

Chạy lại: `python -X utf8 lam_sach.py` (không mạng, không mô hình; chạy 2 lần cho đúng kết quả cũ từng byte). `danh-ba-goc.xlsx` không bị sửa.

## Số liệu trước / sau
| | Trước | Sau |
|---|---|---|
| Số dòng | 400 | **342 khách** (58 dòng gộp vào dòng khác) |
| Ô trống SĐT / Email / Địa chỉ / Ghi chú | 24 / 217 / 122 / 218 | 28 / 216 / 81 / 160 (tính trên 342 khách) |
| Ô đã sửa (ghi ở `nhat-ky-sua.csv`) | – | 865 |

- **Nhóm đã gộp: 52** (46 nhóm 2 dòng, 6 nhóm 3 dòng). Theo quy tắc: G1 (SĐT) 40 dòng, G2 (email) 15 dòng, bắc cầu 3 dòng.
- **Cần người quyết: 25 nhóm, 50 dòng** (Q1: 13, Q2: 12) trong `nghi-trung-can-quyet.csv`. Gợi ý của tôi chỉ nằm ở file này, chưa gộp gì: Q1 nghiêng về gộp 5 / không gộp 8; Q2 nghiêng về gộp 4 / không chắc 8.
- Đã đưa về đúng chỗ: 7 SĐT nằm ở Ghi chú, 4 SĐT nằm ở cột Email, 2 email nằm ở cột SĐT, 5 ô chứa hai SĐT, 3 dòng đổi chỗ tên và địa chỉ.

## Kiểm tra đã làm
Mỗi Mã dòng gốc đúng 1 lần trong `nhat-ky-gop.csv` (400/400); 342 dòng sạch + 58 dòng gộp = 400; 0 SĐT/email sạch sai định dạng; mọi `gia_tri_cu` trong `nhat-ky-sua.csv` khớp từng byte với ô gốc (kể cả tên dạng NFD). Đã kiểm lại độc lập từ các file kết quả, không dùng hàm của script.

## Lỗi không sửa được (để trống ở bản sạch, giá trị cũ giữ trong `nhat-ky-sua.csv`)
- **13 SĐT**: 7 bị che `***`, 4 thiếu số (9 số, bắt đầu bằng 0), 2 đầu số cũ 01x (11 số).
- **31 email**: 12 đuôi `.con`, 8 có hai `@`, 5 thiếu đuôi miền, 3 thiếu `@`, 3 có khoảng trắng giữa.
- **5 tên một từ** (Linh, Phát, Lộc, Trang, Giang) không gộp tự động được với tên đầy đủ; cả 5 đều nằm trong nhóm Q1 để người xác nhận. **80 khách** có tên không dấu hoàn toàn: không đoán dấu.
- Sau gộp: 23 khách không có cả SĐT lẫn email, 28 khách không SĐT, 81 khách không địa chỉ.

## Chỗ tôi phải diễn giải quy tắc (xin người duyệt)
1. **Hùng ≠ Hưng**: so tên từng từ; hai từ cùng có dấu mà khác nhau là khác nhau; một bên không dấu (`Hung`) thì coi là cùng chữ. Nếu chỉ bỏ dấu rồi so thì Hùng = Hưng, mâu thuẫn với ví dụ trong đề.
2. **SĐT 9 số**: chỉ thêm `0` khi số không bắt đầu bằng 0. `081555039` bắt đầu bằng 0 nên coi là thiếu số, không phải mất số 0 đầu.
3. **Dòng đại diện**: dòng có Mã nhỏ nhất của mỗi khách ghi `GIU_RIENG` (cả khi nhận thêm dòng khác, lúc đó nói rõ trong `bang_chung`); các dòng còn lại `GOP_VAO`.
4. **Không có cột `ten_khac`/`dia_chi_khac`**: tên/địa chỉ khác nhau thật sự (không chỉ khác dấu/hoa thường) ghi vào `ghi_chu` (9 khách có "Tên khác"; 0 khách có địa chỉ khác). Danh xưng `a`, `c` ghi nguyên văn, không đoán là anh/chị/cô.
5. SĐT lấy từ Ghi chú thì bị bỏ khỏi Ghi chú (giá trị cũ vẫn ở nhật ký sửa).
6. Đuôi email hợp lệ: com, net, org, vn, edu, gov, info, biz, io, co.

## Đề xuất thêm quy tắc (CHƯA áp dụng)
- Thành phố hiện ra hai dạng "Thành Phố Hà Nội" và "Hà Nội" (do mở `TP.` theo đúng quy tắc); nên chọn một dạng.
- Dữ liệu này chưa có email trùng giữa hai khách khác tên, nhưng quy tắc chưa nói cách xử lý ca đó (không có Q cho email).

## Người cần làm tiếp
Duyệt 25 nhóm trong `nghi-trung-can-quyet.csv`, rồi nhập tay hoặc xin lại 13 SĐT và 31 email lỗi.
