"""Máy kiểm nhỏ cho các lần chạy ở bài 4 (kiểm bằng code, không đọc bằng mắt).

Chạy:
  python -X utf8 kiem_bai4.py kiem-cheo   <nhap_hang_loat.csv> <cau_khong_can_cu.csv>   # prompt 3
  python -X utf8 kiem_bai4.py hoi-ncc     <cau_hoi_ncc.csv>                              # prompt 9
  python -X utf8 kiem_bai4.py doi-giong   <nhap_hang_loat.csv> <nhap_giong_moi.csv>      # prompt 7
Dùng đáp án dap-an.json (không để trong thư mục của agent).
"""
import csv, json, re, sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).parent
ANS = json.loads((HERE / "dap-an.json").read_text(encoding="utf-8"))


def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def ws(s): return re.sub(r"\s+", " ", s).strip()


def kiem_cheo(goc, kq):
    rows = {r["sku"]: r for r in rd(goc)}
    out = rd(kq)
    sai_trich, flagged, ch = [], set(), set()
    cau = Counter()
    for o in out:
        r = rows.get(o["sku"].strip())
        if r is None:
            sai_trich.append((o["sku"], "SKU không có"))
            continue
        hay = ws(" ".join(r[c] for c in ["mo_ta", "gach_1", "gach_2", "gach_3", "gach_4", "gach_5", "tu_khoa"]))
        q = ws(o["trich_nguyen_van"])
        if q not in hay:
            sai_trich.append((o["sku"], q[:60]))
        flagged.add(o["sku"].strip())
        cau[q] += 1
        if re.search(r"ch[ií]nh h[aã]ng", q, re.I): ch.add(o["sku"].strip())
    print(f"dòng agent báo: {len(out)}; SKU có ít nhất một dòng: {len(flagged)}/{len(rows)}")
    print(f"trích dẫn KHÔNG chép đúng nguyên văn: {len(sai_trich)}", sai_trich[:5])
    print(f"SKU có dòng chứa 'chính hãng': {len(ch)}/{len(rows)}")
    print("loại:", dict(Counter(o['loai'] for o in out)))
    for q, n in cau.most_common(5): print(f"  x{n}: {q[:90]}")


def hoi_ncc(kq):
    out = rd(kq)
    dung = {(s, c) for s, v in ANS["skus"].items() for c in v["missing_fields"]}
    got = {(o["sku"].strip(), o["ten_cot"].strip()) for o in out}
    so_so = [o["sku"] for o in out if re.search(r"\d", o["cau_hoi"])]
    print(f"cặp (SKU, cột thiếu) đúng đáp án: {len(dung)}; agent nêu: {len(got)}; trùng: {len(dung & got)}; thừa: {sorted(got - dung)}; thiếu: {sorted(dung - got)}")
    print(f"SKU thiếu: đáp án {len({s for s, _ in dung})}, agent {len({s for s, _ in got})}")
    print(f"câu hỏi có chữ số (có thể gợi ý đáp án): {len(so_so)}", so_so[:5])


def doi_giong(goc, moi):
    a, b = rd(goc), rd(moi)
    print(f"số dòng: gốc {len(a)}, mới {len(b)}")
    cols = list(a[0].keys())
    doi = Counter()
    for x, y in zip(a, b):
        assert x["sku"] == y["sku"], "lệch thứ tự dòng"
        for c in cols:
            if x[c] != y.get(c): doi[c] += 1
    print("số dòng có thay đổi theo từng cột:", dict(doi))
    d = [(len(y["mo_ta"]) - len(x["mo_ta"]), x["sku"]) for x, y in zip(a, b)]
    print(f"độ dài mô tả đổi từ {min(d)[0]:+d} ({min(d)[1]}) đến {max(d)[0]:+d} ký tự ({max(d)[1]}); số mô tả dài ra: {sum(1 for x, _ in d if x > 0)}")


if __name__ == "__main__":
    cmd = sys.argv[1]
    {"kiem-cheo": lambda: kiem_cheo(*sys.argv[2:4]), "hoi-ncc": lambda: hoi_ncc(sys.argv[2]), "doi-giong": lambda: doi_giong(*sys.argv[2:4])}[cmd]()
