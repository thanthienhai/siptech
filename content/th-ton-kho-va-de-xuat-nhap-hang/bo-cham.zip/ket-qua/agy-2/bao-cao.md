# BÁO CÁO PHÂN TÍCH TỒN KHO VÀ ĐỀ XUẤT NHẬP HÀNG THÁNG 11/2026

**Kính gửi:** Chủ cửa hàng (Tạp hóa - Mỹ phẩm - Vật tư)
**Người thực hiện:** Trợ lý kho
**Thời điểm lập:** Sau kiểm kê ngày 31/10/2026

## 1. Tóm tắt nhanh (5 dòng dành cho người chủ)
1. **Mục tiêu & Dữ liệu:** Đã rà soát toàn bộ 11.128 dòng nhật ký giao dịch 12 tháng (11/2025 - 10/2026), làm sạch 131 phiếu lỗi và tính toán tồn kho theo đúng công thức quy ước cho 60 mã hàng.
2. **Ngân sách & Đề xuất:** Tổng nhu cầu vốn tính toán là **41,942,400 đ** (vượt ngân sách); đề xuất nhập tối ưu **29,988,400 đ** (dư ngân sách **11,600 đ**), tập trung vào **10 mặt hàng** thiết yếu nhất.
3. **Tình trạng tồn kho:** Có **2 mã hết hàng** (MP002, MP011 - đều đã có hàng về đầu tháng 11); **11 mã sắp hết** (ưu tiên duyệt nhập 100% cho 6 mã chưa có hàng về); **5 mã tồn lâu** và **1 mã bán chậm** cần thanh lý.
4. **Kiểm định dự báo (Hold-out):** Đo lường trên 102 cặp mã-tháng cho thấy công thức trung bình trượt 3 tháng có sai số **WAPE = 37.19% (MAE = 21.45)**, kém hơn mốc ngây thơ tháng trước **WAPE = 26.64% (MAE = 15.36)** do phản ứng chậm với biến động ngắn hạn.
5. **Điểm cần lưu ý:** Lập danh sách **27 phiếu dữ liệu nghi vấn** (số âm không ghi chú, số lượng đột biến 10x, đơn sỉ) và **15 mã hàng bị cắt giảm ngân sách** để trình chủ cửa hàng xem xét và ra quyết định số cuối cùng.

## 2. Tổng tiền vốn đề xuất so với ngân sách và phương án phân bổ
### 2.1. Cân đối nguồn vốn
- **Trần ngân sách nhập tháng 11/2026:** **30,000,000 VND** (tham số cố định).
- **Tổng nhu cầu vốn tính theo công thức (chưa xét ngân sách):** **41,942,400 VND** (24 mã hàng phát sinh nhu cầu nhập).
- **Phần vốn bị thiếu hụt:** **11,942,400 VND**.
- **Tổng tiền vốn đề xuất thực tế:** **29,988,400 VND** (đảm bảo tuân thủ 100% bội số quy cách và trần ngân sách).
- **Số dư ngân sách dự phòng:** **11,600 VND**.

### 2.2. Nguyên tắc xếp thứ tự ưu tiên
Để bảo vệ tối đa dòng tiền và doanh thu của cửa hàng trong giới hạn 30 triệu đồng, trợ lý kho áp dụng quy tắc 3 tầng:
1. **Tầng 1 - Tối khẩn cấp (Cảnh báo SAP_HET):** Duyệt đủ 100% nhu cầu cho toàn bộ 6 mã hàng sắp hết chưa có hàng về (tổng vốn **10.494.000 đ**), ngăn chặn hoàn toàn nguy cơ đứt hàng.
2. **Tầng 2 - Hàng trọng yếu loại A nhóm OK:** Dành phần ngân sách còn lại (19.506.000 đ) cho các mặt hàng chủ lực loại A đóng góp 80% giá trị tiêu thụ, ưu tiên mã có số ngày tồn thấp nhất:
   - `VT005` (Giấy vệ sinh): Tồn còn 17,7 ngày -> Duyệt 100% (120 lốc, **6.240.000 đ**).
   - `MP005` (Sữa tắm): Tồn còn 19,4 ngày -> Duyệt 100% (24 chai, **2.352.000 đ**).
   - `TH001` (Gạo thơm túi 5kg): Tồn còn 21,7 ngày -> Phân bổ **116 túi** (**10.672.000 đ**), cắt giảm 12 túi so với nhu cầu 128 túi.
   - `TH009` (Nước suối 500ml): Tồn còn 26,9 ngày -> Phân bổ **72 chai** (**230.400 đ**), cắt giảm 72 chai.
3. **Tầng 3 - Tạm hoãn nhóm hàng còn tồn an toàn (14 mã):**
   - Hoãn nhập các mã loại A còn tồn nhiều ngày: `TH008` (Nước ngọt - còn 1.076 lon, đủ bán 28 ngày), `MP003` (Dầu gội - còn 20 chai, đủ 30,5 ngày), `MP012` (Kem đánh răng - còn 83 tuýp, đủ 36 ngày).
   - Hoãn nhập toàn bộ 6 mã nhóm B và 5 mã nhóm C đang ở trạng thái OK vì tồn kho thực tế đều trên mức ROP, đủ bán từ 15 đến 45 ngày tới.

### 2.3. Bảng các mặt hàng bị cắt giảm hoặc tạm hoãn do ngân sách (15 mã)
| STT | Mã hàng | Tên hàng | Nhóm ABC | Trạng thái kho | Tồn KK | Số ngày tồn | SL Cần | SL Đề xuất | Quy cách | Vốn đề xuất (đ) | Vốn bị cắt (đ) | Lý do đề xuất |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 9 | TH001 | Gạo thơm túi 5kg | A | OK | 230 | 21.7 | 128 | 116 | 4 | 10,672,000 | 1,104,000 | Cắt giảm từ 128 xuống 116 do trần ngân sách 30 triệu; tồn hiện tại (230) đủ bán 21.7 ngày, cần chủ duyệt. |
| 10 | TH009 | Nước suối chai 500ml | A | OK | 330 | 26.9 | 144 | 72 | 24 | 230,400 | 230,400 | Cắt giảm từ 144 xuống 72 do trần ngân sách 30 triệu; tồn hiện tại (330) đủ bán 26.9 ngày, cần chủ duyệt. |
| 11 | TH008 | Nước ngọt có ga lon 330ml | A | OK | 1076 | 28.0 | 360 | 0 | 24 | 0 | 2,700,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (1076) vẫn còn trên ROP (459), đủ bán 28.0 ngày. |
| 12 | MP003 | Dầu gội chai 650ml | A | OK | 20 | 30.5 | 12 | 0 | 12 | 0 | 1,056,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (20) vẫn còn trên ROP (16), đủ bán 30.5 ngày. |
| 13 | MP012 | Kem đánh răng tuýp 180g | A | OK | 83 | 35.9 | 24 | 0 | 24 | 0 | 744,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (83) vẫn còn trên ROP (35), đủ bán 35.9 ngày. |
| 14 | VT007 | Nước rửa chén chai 750ml | B | OK | 15 | 15.2 | 24 | 0 | 12 | 0 | 576,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (15) vẫn còn trên ROP (11), đủ bán 15.2 ngày. |
| 15 | TH012 | Sữa đặc có đường lon 380g | B | OK | 18 | 16.5 | 24 | 0 | 24 | 0 | 576,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (18) vẫn còn trên ROP (11), đủ bán 16.5 ngày. |
| 16 | TH010 | Trà xanh đóng chai 455ml | B | OK | 50 | 20.4 | 48 | 0 | 24 | 0 | 297,600 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (50) vẫn còn trên ROP (23), đủ bán 20.4 ngày. |
| 17 | TH013 | Cà phê hòa tan hộp 20 gói | B | OK | 7 | 31.5 | 12 | 0 | 12 | 0 | 456,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (7) vẫn còn trên ROP (4), đủ bán 31.5 ngày. |
| 18 | VT013 | Ô gấp | B | OK | 15 | 33.8 | 10 | 0 | 10 | 0 | 850,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (15) vẫn còn trên ROP (10), đủ bán 33.8 ngày. |
| 19 | TH006 | Mì gói thùng 30 gói | B | OK | 5 | 45.0 | 6 | 0 | 6 | 0 | 588,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (5) vẫn còn trên ROP (4), đủ bán 45.0 ngày. |
| 20 | TH020 | Bột ngọt gói 400g | C | OK | 6 | 18.0 | 20 | 0 | 20 | 0 | 560,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (6) vẫn còn trên ROP (4), đủ bán 18.0 ngày. |
| 21 | MP013 | Bàn chải đánh răng (cây) | C | OK | 17 | 19.9 | 48 | 0 | 48 | 0 | 576,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (17) vẫn còn trên ROP (10), đủ bán 19.9 ngày. |
| 22 | VT020 | Bút bi hộp 20 cây | C | OK | 8 | 21.8 | 20 | 0 | 20 | 0 | 560,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (8) vẫn còn trên ROP (7), đủ bán 21.8 ngày. |
| 23 | VT012 | Áo mưa bộ | C | OK | 9 | 36.8 | 20 | 0 | 20 | 0 | 720,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (9) vẫn còn trên ROP (6), đủ bán 36.8 ngày. |
| 24 | VT002 | Pin AA vỉ 4 viên | C | OK | 17 | 37.3 | 20 | 0 | 20 | 0 | 360,000 | Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại (17) vẫn còn trên ROP (9), đủ bán 37.3 ngày. |

> **Gợi ý linh hoạt cho chủ cửa hàng:** Mặt hàng gạo `TH001` đang ngốn gần 10,7 triệu vốn đề xuất nhưng thực tế trong kho vẫn còn 230 túi (đủ bán ~22 ngày, thời gian NCC giao chỉ 5 ngày). Nếu chủ muốn dàn vốn sang các mã B và C sắp chạm ngưỡng như nước rửa chén `VT007` (15,2 ngày tồn), sữa đặc `TH012` (16,5 ngày tồn), bột ngọt `TH020` (18 ngày tồn), chủ chỉ cần giảm `TH001` xuống 60-80 túi để giải phóng thêm 3,5 - 5,5 triệu đồng vốn.

## 3. Tình hình hàng hóa đáng lo ngại (Hết hàng, Sắp hết, Tồn lâu, Bán chậm)
Theo quy ước ưu tiên cảnh báo: `HET_HANG` > `SAP_HET` > `TON_LAU` > `BAN_CHAM` > `OK`.

### 3.1. Hàng hết hàng (HET_HANG: Tồn kiểm kê = 0)
| Mã hàng | Tên hàng | Nhóm ABC | Tồn kiểm kê | Hàng đang về | Ngày dự kiến về | Đánh giá & Khuyến nghị |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| MP002 | Sữa rửa mặt tuýp 100g | B | 0 | 12 | 27/12/2026 (PO-0008) | Đã có đơn đặt trước đó, đang trên đường về; không cần nhập thêm kỳ này. |
| MP011 | Lăn khử mùi chai 50ml | B | 0 | 24 | 05/11/2026 (PO-0011) | Đã có đơn đặt trước đó, đang trên đường về; không cần nhập thêm kỳ này. |

> **Lưu ý:** Mã `MP002` (Sữa rửa mặt) có hàng về ngày 27/12/2026 (khá muộn), cần kiểm tra lại với nhà cung cấp xem có thể giao sớm hơn hay không.

### 3.2. Hàng sắp hết (SAP_HET: 0 < Tồn kiểm kê ≤ Điểm đặt lại ROP)
| Mã hàng | Tên hàng | Nhóm ABC | Tồn KK | Điểm ROP | Tồn an toàn (SS) | Hàng đang về | Đề xuất nhập | Thành tiền (đ) | Trạng thái xử lý |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| VT008 | Bột giặt túi 3kg | A | 21 | 21 | 10 | 60 | 0 | 0 | Đã có 60 sp đang về |
| MP001 | Kem chống nắng tuýp 50g | A | 27 | 30 | 14 | 0 | 36 | 4,608,000 | Duyệt 100% (36 sp) |
| MP006 | Son dưỡng môi thỏi | A | 19 | 20 | 14 | 0 | 24 | 1,080,000 | Duyệt 100% (24 sp) |
| MP014 | Dầu dưỡng tóc chai 100ml | B | 6 | 7 | 3 | 24 | 0 | 0 | Đã có 24 sp đang về |
| MP015 | Serum vitamin C chai 30ml | B | 9 | 13 | 8 | 0 | 18 | 3,330,000 | Duyệt 100% (18 sp) |
| MP008 | Nước tẩy trang chai 300ml | B | 4 | 5 | 3 | 0 | 12 | 984,000 | Duyệt 100% (12 sp) |
| VT004 | Túi rác cuộn trung | C | 5 | 7 | 3 | 30 | 0 | 0 | Đã có 30 sp đang về |
| MP010 | Toner pad hộp 60 miếng | C | 9 | 12 | 7 | 24 | 0 | 0 | Đã có 24 sp đang về |
| TH014 | Trà túi lọc hộp 25 túi | C | 7 | 7 | 4 | 24 | 0 | 0 | Đã có 24 sp đang về |
| VT016 | Dây điện nối dài ổ cắm 5m | C | 2 | 3 | 2 | 0 | 4 | 380,000 | Duyệt 100% (4 sp) |
| VT018 | Keo dán đa năng tuýp | C | 2 | 2 | 1 | 0 | 4 | 112,000 | Duyệt 100% (4 sp) |

### 3.3. Hàng tồn lâu (TON_LAU: Số ngày tồn > 120 ngày hoặc không bán 90 ngày cuối)
| Mã hàng | Tên hàng | Nhóm ABC | Tồn kiểm kê | Số ngày tồn | Giá vốn/sp | Tổng vốn tồn đọng | Nguyên nhân & Hướng giải quyết |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| TH016 | Mứt tết hộp 400g | C | 9 | 405.0 ngày | 62,000 đ | 558,000 đ | Hàng mùa vụ Tết (mứt tết, hạt dưa) tồn đọng sau Tết; cần kiểm tra hạn dùng, đóng combo xả lỗ. |
| TH019 | Hạt dưa gói 200g | C | 11 | 990.0 ngày | 18,000 đ | 198,000 đ | Hàng mùa vụ Tết (mứt tết, hạt dưa) tồn đọng sau Tết; cần kiểm tra hạn dùng, đóng combo xả lỗ. |
| TH021 | Nước tương chai 500ml (mã cũ) | B | 61 | 999.0 ngày | 17,000 đ | 1,037,000 đ | Hàng ngừng kinh doanh (ngung_nhap); cần giảm giá thanh lý dứt điểm để thu hồi vốn. |
| VT017 | Bóng đèn tròn sợi đốt 40W | C | 46 | 999.0 ngày | 8,000 đ | 368,000 đ | Hàng ngừng kinh doanh (ngung_nhap); cần giảm giá thanh lý dứt điểm để thu hồi vốn. |
| MP016 | Gel rửa tay khô chai 500ml | B | 27 | 999.0 ngày | 42,000 đ | 1,134,000 đ | Gel rửa tay khô sau dịch không ai mua (0 đơn trong 5 tháng); đề xuất bán rẻ thu hồi vốn. |

### 3.4. Hàng bán chậm (BAN_CHAM: Nhu cầu trung bình F < 3 đơn vị/tháng)
| Mã hàng | Tên hàng | Nhóm ABC | Tồn kiểm kê | Dự báo F | Tồn an toàn | Số ngày tồn | Khuyến nghị |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| MP004 | Dầu xả chai 650ml | C | 3 | 1.33 | 1 | 67.5 ngày | Bán rất chậm (1,3 chai/tháng); tồn 3 chai đủ bán hơn 2 tháng, tuyệt đối không nhập thêm. |


## 4. Kiểm định độ chính xác dự báo trên 2 tháng giữ lại (Hold-out 2026-09 và 2026-10)
Theo quy ước, hai tháng cuối (tháng 9 và tháng 10/2026) được giữ lại độc lập để đo lường sai số. Dự báo mỗi tháng chỉ dùng số liệu lịch sử trước tháng đó trên các mã-tháng không bị cụt hàng và có ít nhất 3 tháng hợp lệ trước đó.

### 4.1. Bảng so sánh chỉ số sai số
| Phương pháp dự báo | Kích thước mẫu (N) | Sai số tuyệt đối TB (MAE) | Tỷ lệ sai số trọng số (WAPE) | Đánh giá hiệu quả |
| :--- | :---: | :---: | :---: | :--- |
| **Công thức của chủ** (Bình quân trượt 3 tháng hợp lệ) | 102 cặp mã-tháng | **21.45 đơn vị** | **37.19%** | Kém hơn mốc ngây thơ (+10,55% WAPE) |
| **Mốc ngây thơ 1** (Doanh số thô tháng liền trước) | 102 cặp mã-tháng | **15.36 đơn vị** | **26.64%** | **Chính xác hơn công thức chủ** |

> [!WARNING] **Báo cáo trung thực kết quả xấu:** Công thức bình quân trượt 3 tháng của chủ đang cho kết quả **kém hơn phương pháp dự báo ngây thơ lấy tháng trước** khoảng 6,08 đơn vị MAE và 10,55% WAPE.

### 4.2. Nguyên nhân và hạn chế đo lường
1. **Tại sao công thức bình quân trượt lại thua mốc ngây thơ?**
   - Bình quân 3 tháng bị hiện tượng trễ pha (lag). Khi một mặt hàng bước vào chu kỳ tăng tốc hoặc suy giảm sau hè/tết, việc lấy trung bình cả 3 tháng trước sẽ kéo lùi dự báo về quá khứ.
   - Mốc ngây thơ tháng liền trước bắt kịp bước nhảy nhu cầu gần nhất của khách hàng tốt hơn đối với các mặt hàng tiêu dùng nhanh (FMCG).
2. **Những hạn chế dữ liệu chưa đo lường được:**
   - **Kích thước mẫu nhỏ ($N = 102$):** Chỉ đo trên 2 tháng giữ lại (tháng 9 có 51 mã và tháng 10 có 51 mã hợp lệ; 18 mã-tháng bị loại do cụt hàng hoặc thiếu tháng lịch sử), chưa đủ đại diện cho toàn bộ 4 mùa trong năm.
   - **Không đo được Mốc ngây thơ 2 (cùng kỳ năm trước):** Do dữ liệu cửa hàng chỉ có 12 tháng (từ tháng 11/2025 đến tháng 10/2026), không có dữ liệu tháng 09/2025 và 10/2025 nên hoàn toàn không thể kiểm định mốc này trên tập hold-out. Mốc này chỉ tính được duy nhất cho tháng đề xuất 11/2026 (đã đưa vào cột `cung_ky_nam_truoc_2025_11` trong file phân loại).

## 5. Tổng hợp lỗi dữ liệu và cách xử lý (loi-du-lieu.csv)
Hệ thống đã rà soát và ghi nhận tổng cộng **131 bản ghi bất thường** vào file `loi-du-lieu.csv`:

| Loại lỗi (`loai_loi`) | Số lượng | Hướng xử lý (`xu_ly`) | Nguyên tắc thực hiện |
| :--- | :---: | :---: | :--- |
| `khong_phai_ban_hang` | 89 phiếu | `GIU` | Gồm xuất dùng tại quán (18), hủy hết hạn (16), điều chỉnh hao hụt/vỡ hỏng (55). Giữ để trừ tồn kho nhưng loại khỏi nhu cầu bán. |
| `trung_dong` | 11 phiếu | `BO` | Bỏ các bản ghi trùng lặp mã phiếu (do bấm đúp hoặc lưu trùng), chỉ giữ lại 1 bản ghi gốc. |
| `don_si_mot_lan` | 10 phiếu | `CAN_NGUOI_QUYET` | 5 cặp nhập - xuất sỉ số lượng lớn đột xuất; tạm loại khỏi F bán lẻ để tránh thổi phồng dự báo. |
| `so_am_khong_ghi_chu` | 6 phiếu | `CAN_NGUOI_QUYET` | Phiếu xuất số lượng âm nhưng thiếu ghi chú khách trả; tạm loại khỏi nhu cầu bán. |
| `so_luong_bat_thuong` | 6 phiếu | `CAN_NGUOI_QUYET` | Đơn xuất lẻ đột biến gấp 10-30 lần (nghi ngờ gõ thừa số 0); tạm loại khỏi nhu cầu bán. |
| `khac` (thiếu mã hàng) | 4 phiếu | `SUA` | Phiếu bị mất mã hàng gốc; đã dò chuẩn xác theo tên hàng để điền lại mã. |
| `thieu_so_luong` | 3 phiếu | `CAN_NGUOI_QUYET` | Phiếu xuất để trống số lượng; không tự bịa số, tạm bỏ qua chờ chủ kiểm tra sổ tay. |
| `ngay_o_tuong_lai` | 2 phiếu | `CAN_NGUOI_QUYET` | Phiếu nhập ghi ngày tháng 12/2026 (vượt mốc 31/10/2026); nghi ngờ gõ nhầm tháng 09/2026. |
| **Tổng cộng** | **131 phiếu** | | |


## 6. Các giả định tính toán đã áp dụng
1. **Thời gian giao hàng (Lead time T):** Cố định theo số ngày trong danh mục hàng do không có dữ liệu đo lường độ trễ thực tế của từng chuyến xe giao.
2. **Mức phục vụ khách hàng:** Hệ số an toàn $Z = 1,645$ tương ứng mức phục vụ 95%, giả định nhu cầu bán các tháng độc lập và tuân theo phân phối chuẩn.
3. **Làm tròn lên:** Tồn an toàn SS, Điểm đặt lại ROP và Số lượng cần nhập luôn làm tròn lên số nguyên hoặc bội số quy cách gần nhất theo quy ước của chủ.
4. **Căn cứ tồn kho:** Dùng số tồn kiểm kê thực tế ngày 31/10/2026 làm gốc để tính toán đặt hàng.
5. **Giải thích chênh lệch tồn kho (15 mã):**
   - Chênh lệch dương (tồn hệ thống > tồn kiểm kê): Do các phiếu xuất âm không ghi chú làm tăng ảo tồn hệ thống (MP003, VT007, TH018, MP012), hoặc nhập sỉ chưa bán hết.
   - Chênh lệch âm (tồn hệ thống < tồn kiểm kê): Bắt nguồn trực tiếp từ các phiếu xuất đột biến 10x nghi ngờ gõ thừa số 0 (TH002: -45, MP001: -27, MP006: -27, MP013: -27, TH011: -23) và 2 phiếu nhập ghi nhầm ngày tương lai (VT001: -20, MP015: -18).

## 7. Danh sách CẦN NGƯỜI QUYẾT (Trình chủ cửa hàng phê duyệt)
Để đảm bảo số liệu chính xác tuyệt đối và không bịa đặt, người chủ cần xem xét và cho ý kiến về hai nhóm nội dung sau:

### 7.1. Bảng 27 chứng từ nghi vấn cần chốt số liệu
| Mã phiếu | Mã hàng | Tên hàng | Ngày chứng từ | Số lượng | Loại lỗi | Nội dung nghi vấn & Câu hỏi cần chủ chốt |
| :--- | :--- | :--- | :---: | :---: | :--- | :--- |
| PX00679 | MP003 | Dầu gội chai 650ml | 2025-11-23 | -4.0 | `so_am_khong_ghi_chu` | Số lượng xuất âm (-4.0) nhưng không có ghi chú khách trả hàng; tạm loại khỏi nhu cầu, cần chủ xác nhận. |
| PX01374 | VT007 | Nước rửa chén chai 750ml | 2025-12-14 | -3.0 | `so_am_khong_ghi_chu` | Số lượng xuất âm (-3.0) nhưng không có ghi chú khách trả hàng; tạm loại khỏi nhu cầu, cần chủ xác nhận. |
| PX03573 | TH023 | Trứng gà vỉ 10 quả | 22/02/2026 | -3.0 | `so_am_khong_ghi_chu` | Số lượng xuất âm (-3.0) nhưng không có ghi chú khách trả hàng; tạm loại khỏi nhu cầu, cần chủ xác nhận. |
| PX04140 | MP012 | Kem đánh răng tuýp 180g | 2026-03-13 | -3.0 | `so_am_khong_ghi_chu` | Số lượng xuất âm (-3.0) nhưng không có ghi chú khách trả hàng; tạm loại khỏi nhu cầu, cần chủ xác nhận. |
| PX05950 | TH018 | Snack khoai tây gói 52g | 2026-05-17 | -3.0 | `so_am_khong_ghi_chu` | Số lượng xuất âm (-3.0) nhưng không có ghi chú khách trả hàng; tạm loại khỏi nhu cầu, cần chủ xác nhận. |
| PX10062 | TH003 | Nước mắm chai 500ml | 2026-10-11 | -3.0 | `so_am_khong_ghi_chu` | Số lượng xuất âm (-3.0) nhưng không có ghi chú khách trả hàng; tạm loại khỏi nhu cầu, cần chủ xác nhận. |
| PX01404 | VT007 | Nước rửa chén chai 750ml | 2025-12-15 | nan | `thieu_so_luong` | Phiếu xuất bán thiếu số lượng (để trống); không tự bịa số, tạm loại khỏi tính nhu cầu và cần chủ xác nhận. |
| PX02391 | TH023 | Trứng gà vỉ 10 quả | 2026-01-17 | nan | `thieu_so_luong` | Phiếu xuất bán thiếu số lượng (để trống); không tự bịa số, tạm loại khỏi tính nhu cầu và cần chủ xác nhận. |
| PX09402 | TH023 | Trứng gà vỉ 10 quả | 2026-09-18 | nan | `thieu_so_luong` | Phiếu xuất bán thiếu số lượng (để trống); không tự bịa số, tạm loại khỏi tính nhu cầu và cần chủ xác nhận. |
| PN0087 | VT008 | Bột giặt túi 3kg | 2026-02-04 | 84.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (84.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PX02983 | VT008 | Bột giặt túi 3kg | 04/02/2026 | 90.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (90.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PN0147 | TH007 | Mì gói vị tôm (gói) | 2026-03-23 | 2370.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (2370.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PX04450 | TH007 | Mì gói vị tôm (gói) | 2026-03-23 | 2500.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (2500.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PN0170 | MP012 | Kem đánh răng tuýp 180g | 2026-04-20 | 432.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (432.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PX05227 | MP012 | Kem đánh răng tuýp 180g | 2026-04-20 | 420.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (420.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PN0198 | VT007 | Nước rửa chén chai 750ml | 2026-05-21 | 156.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (156.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PX06046 | VT007 | Nước rửa chén chai 750ml | 2026-05-21 | 140.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (140.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PN0262 | VT015 | Khẩu trang y tế hộp 50 cái | 2026-07-17 | 280.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (280.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PX07668 | VT015 | Khẩu trang y tế hộp 50 cái | 2026-07-17 | 260.0 | `don_si_mot_lan` | Đơn hàng sỉ/đại lý mua số lượng lớn một lần (260.0); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt. |
| PN0349 | VT001 | Bóng đèn LED 9W | 2026-12-11 | 20.0 | `ngay_o_tuong_lai` | Ngày chứng từ ở tương lai (2026-12-11); nghi ngờ gõ nhầm tháng khi nhập phiếu, cần chủ duyệt ngày đúng. |
| PN0350 | MP015 | Serum vitamin C chai 30ml | 13/12/2026 | 18.0 | `ngay_o_tuong_lai` | Ngày chứng từ ở tương lai (13/12/2026); nghi ngờ gõ nhầm tháng khi nhập phiếu, cần chủ duyệt ngày đúng. |
| PX04209 | MP013 | Bàn chải đánh răng (cây) | 2026-03-15 | 30.0 | `so_luong_bat_thuong` | Số lượng xuất bán (30.0) đột biến gấp 10-30 lần mức bán lẻ thông thường; nghi ngờ gõ thừa số 0, cần chủ xác nhận. |
| PX05025 | TH023 | Trứng gà vỉ 10 quả | 2026-04-12 | 40.0 | `so_luong_bat_thuong` | Số lượng xuất bán (40.0) đột biến gấp 10-30 lần mức bán lẻ thông thường; nghi ngờ gõ thừa số 0, cần chủ xác nhận. |
| PX05126 | MP001 | Kem chống nắng tuýp 50g | 2026-04-17 | 30.0 | `so_luong_bat_thuong` | Số lượng xuất bán (30.0) đột biến gấp 10-30 lần mức bán lẻ thông thường; nghi ngờ gõ thừa số 0, cần chủ xác nhận. |
| PX07009 | TH011 | Sữa tươi hộp 1L | 2026-06-24 | 30.0 | `so_luong_bat_thuong` | Số lượng xuất bán (30.0) đột biến gấp 10-30 lần mức bán lẻ thông thường; nghi ngờ gõ thừa số 0, cần chủ xác nhận. |
| PX08283 | MP006 | Son dưỡng môi thỏi | 10/8/26 | 30.0 | `so_luong_bat_thuong` | Số lượng xuất bán (30.0) đột biến gấp 10-30 lần mức bán lẻ thông thường; nghi ngờ gõ thừa số 0, cần chủ xác nhận. |
| PX10382 | TH002 | Dầu ăn đậu nành chai 1L | 22/10/2026 | 50.0 | `so_luong_bat_thuong` | Số lượng xuất bán (50.0) đột biến gấp 10-30 lần mức bán lẻ thông thường; nghi ngờ gõ thừa số 0, cần chủ xác nhận. |

### 7.2. Danh sách 15 mặt hàng bị cắt giảm ngân sách cần duyệt phân bổ
Chủ cửa hàng vui lòng xem xét phương án phân bổ 29.988.400 đ trong file `de-xuat-nhap.csv`:
- Duyệt giảm `TH001` (Gạo) từ 128 túi xuống **116 túi** (tiết kiệm 1.104.000 đ) hoặc chủ động giảm tiếp xuống **60-80 túi**.
- Duyệt giảm `TH009` (Nước suối) từ 144 chai xuống **72 chai** (tiết kiệm 230.400 đ).
- Duyệt tạm hoãn nhập 13 mã nhóm OK (hoặc điều chuyển một phần tiền từ gạo TH001 sang các mã B và C có số ngày tồn < 20 ngày như VT007, TH012, TH020, MP013).

---
*Báo cáo được trích xuất tự động từ hệ thống bằng code Python tinh_ton_kho.py.*