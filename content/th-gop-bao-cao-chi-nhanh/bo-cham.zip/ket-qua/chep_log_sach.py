"""Chép log thật của các lần chạy vào logs/ để công bố, sau khi:
  - thay tiền tố đường dẫn máy người dùng (C:\\Users\\...\\...) bằng <WORK>/, <HOME>, <user> ... (không đổi nội dung kỹ thuật);
  - bỏ các sự kiện type="system" khỏi *.raw.jsonl (sự kiện khởi tạo liệt kê cấu hình/ skill/ máy chủ MCP của máy người chạy, không liên quan bài toán).
Mọi sự kiện khác (lời agent, lệnh, kết quả lệnh, số token) giữ nguyên.
Chạy:  python -X utf8 chep_log_sach.py <thư_mục_scratch_agentlab/08> <thư_mục_bài>
"""
import sys, json, shutil
from pathlib import Path
LAB = Path(sys.argv[1]); BAI = Path(sys.argv[2])
sys.path.insert(0, str(LAB)); import sanitize
(BAI / "logs").mkdir(exist_ok=True)
for f in sorted((LAB / "logs").glob("*")):
    if f.name.endswith(".raw.jsonl"):
        keep = []
        for ln in f.read_text(encoding="utf-8").splitlines():
            try:
                if json.loads(ln).get("type") == "system": continue
            except Exception:
                pass
            keep.append(ln)
        (BAI / "logs" / f.name).write_text(sanitize.clean("\n".join(keep)) + "\n", encoding="utf-8")
    else:
        (BAI / "logs" / f.name).write_text(sanitize.clean(f.read_text(encoding="utf-8")), encoding="utf-8")
    print("ok", f.name)
