# Báo cáo kiểm: nhap_hang_loat.csv (6 SKU)

## Tóm tắt

- Cả 6 SKU đều ở trạng thái `CAN_BO_SUNG`. Chưa SKU nào nên đăng lên sàn trước khi có người quyết.
- Nguyên nhân chung: bảng `thong_so.csv` đủ các trường bắt buộc, nhưng cột `ghi_chu_noi_bo` của mỗi SKU nêu một giá trị khác hoặc nghi ngờ về một thông số.
- Quy định nói ghi chú nội bộ là lời đồn, không phải sự thật. Tôi cũng không có cách kiểm chứng bảng là đúng, nên không chọn bên nào.
- Cách làm: phần lấy từ bảng mà không bị nghi ngờ vẫn viết đầy đủ. Riêng thông số bị nghi ngờ, tôi để `CẦN NGƯỜI QUYẾT: ...` ở đúng chỗ đó và không điền số.
- Không có giá trị nào từ ghi chú nội bộ được viết vào file nộp.
- File đã kiểm bằng script: tiêu đề, mô tả, gạch, từ khóa đều trong giới hạn độ dài. Không có từ cấm (đã thử cả bản không dấu). Không có emoji, không viết HOA cả từ. Mọi con số đều có trong bảng của đúng SKU đó.

## SKU cần người quyết

Mỗi dòng dưới đây ghi giá trị trong bảng, điều ghi chú nội bộ nói, và cột đang bị để trống trong file.

| SKU | Cột bị giữ lại | Trong bảng | Ghi chú nội bộ nói | Cần làm |
|---|---|---|---|---|
| VN-012 | `thanh_phan_noi_bat` (nồng độ vitamin C) | vitamin C 10% | kỹ thuật nói thực ra 15%, chờ phiếu kiểm nghiệm | Chốt nồng độ theo phiếu kiểm nghiệm. |
| VN-041 | `thanh_phan_noi_bat` (nồng độ vitamin C) | vitamin C 10% | giống VN-012 | Chốt nồng độ như VN-012. |
| VN-042 | `chi_so_chong_nang` | SPF 30 PA+++ | bao bì in SPF 50, "chắc bảng nhập nhầm" | Đối chiếu bao bì thật, rồi sửa bảng hoặc bao bì. |
| VN-043 | `dung_tich` | 300 ml | lô mới đóng chai 500 ml, bảng chưa sửa | Xác nhận lô nào đang bán. Tiêu đề hiện chưa có dung tích. |
| VN-044 | `xuat_xu` | Hàn Quốc | NCC mới báo sản xuất ở Thái Lan, chưa có giấy | Chờ giấy tờ của NCC rồi chốt xuất xứ. |
| VN-045 | `han_su_dung` | 24 tháng | bản cũ ghi 36 tháng, chưa biết bản nào đúng | Chốt hạn dùng theo bao bì hoặc hồ sơ sản phẩm. |

Vì sao tôi giữ lại các thông số này, thay vì dùng giá trị trong bảng:

- SPF, nồng độ hoạt chất, dung tích, xuất xứ và hạn dùng là những thông tin người mua dựa vào để quyết định. Đăng sai thì khó sửa và có thể bị khách phản ánh.
- Nếu người quyết kết luận bảng đúng, chỉ cần điền giá trị trong bảng vào chỗ `CẦN NGƯỜI QUYẾT`, rồi đổi `trang_thai` thành `SAN_SANG` và xóa `truong_can_bo_sung`. Nếu kết luận bảng sai, họ cần sửa bảng trước.
- Tiêu đề của VN-042 và VN-043 hiện chưa có chỉ số chống nắng hoặc dung tích. Sau khi chốt, nên thêm vào tiêu đề theo mục 3 của quy định.

## SKU cần bổ sung thông tin (thiếu trường)

Không có. Cả 6 SKU đều đủ các trường bắt buộc: `dung_tich`, `thanh_phan_noi_bat`, `xuat_xu`, `han_su_dung`, `cong_dung_tren_bao_bi`, `cach_dung`.

## Điều tôi không chắc

1. **VN-012 và phiếu công bố.** Bảng có số phiếu `DEMO-2644`, nên mô tả ghi "đã có phiếu công bố số DEMO-2644". Ghi chú lại nói "chờ phiếu kiểm nghiệm". Kiểm nghiệm và công bố là hai thủ tục khác nhau, nên tôi không coi hai thông tin này mâu thuẫn. Nhờ người phụ trách hồ sơ xác nhận số phiếu còn hiệu lực.
2. **VN-041, 042, 043, 044, 045 không có số phiếu công bố.** Tôi không nhắc đến phiếu công bố ở các SKU này, đúng mục 5 của quy định. Phiếu không nằm trong danh sách trường bắt buộc, nên tôi không coi đây là thiếu thông tin.
3. **Việc giữ cả 6 SKU có thể quá thận trọng.** Tôi đọc "không chắc thì không đoán" nghiêm hơn mức tối thiểu, vì ghi chú nội bộ đều nêu giá trị cụ thể và khác bảng. Nếu shop coi bảng luôn đúng, có thể điền giá trị trong bảng ngay. Đó là quyết định của người có quyền, không phải của tôi.
4. **Công dụng chỉ lấy đúng chữ trong cột `cong_dung_tren_bao_bi`**, ví dụ "cấp ẩm cho da", "bảo vệ da khỏi tia UV". Tôi không diễn giải thêm, nên không có ý "hiệu quả" nào ngoài bảng.
5. **Thành phần chỉ nêu tên.** Mô tả không nói về tác dụng của vitamin C, glycerin hay bồ kết, vì bảng không ghi.
6. **Mô tả sau khi thay chỗ trống.** Chữ `CẦN NGƯỜI QUYẾT` nằm giữa câu. Khi điền giá trị, nên đọc lại câu cho liền mạch.
7. **File `nhap_hang_loat.xlsx` chưa tạo.** Mục 6 của quy định yêu cầu nộp cả CSV và XLSX, còn yêu cầu của bạn chỉ có CSV. Tôi chưa tạo XLSX. Nên tạo sau khi các SKU đã được chốt, để khỏi phải làm hai lần.
8. **Quy định của shop có thể thay đổi.** Giới hạn độ dài (mục 2) là giả định nội bộ của shop. Nếu sàn có giới hạn riêng, cần so lại.
