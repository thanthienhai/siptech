# Báo cáo đánh giá khách hàng

Nguồn: `danh-gia.csv` (Google Maps, Shopee Food, Facebook), các bài từ 24/08/2026 đến 15/11/2026. Mọi con số dưới đây lấy từ kết quả chạy `tong-hop.py` (các số đếm theo từ khóa cũng do code đếm, xem phần "Số liệu bổ sung" khi chạy lại file).

## Tổng quan

- Tổng số đánh giá trong file: **250**
- Số bài loại bỏ: **8** (4 trùng nguyên văn: R117, R171, R177, R205; 3 spam/quảng cáo: R070, R122, R191; 1 không phải đánh giá: R228)
- Số bài được phân tích: **242**, tách ra **400** ý kiến
- Đánh giá nguy cấp: **18** dòng trong `nguy-cap.csv` (7 ngộ độc/dị vật, 6 lừa đảo/tính tiền sai, 5 thái độ nhân viên; trong đó 3 dòng ghi "nghi")
- Ý kiến cần người đọc (CAN_NGUOI_DOC): **15** ý kiến, thuộc 15 bài: R029, R040, R054, R075, R077, R096, R126, R146, R159, R169, R202, R217, R225, R236, R245. Phần lớn là mỉa mai; R054 là câu không rõ nghĩa.

### Chủ đề x sắc thái (số ý kiến)

| Chủ đề | Tích cực | Tiêu cực | Trung tính | Cần người đọc | Tổng |
|---|---:|---:|---:|---:|---:|
| Giá (gia) | 14 | 44 | 11 | 2 | 71 |
| Phục vụ (phuc_vu) | 39 | 32 | 9 | 3 | 83 |
| Chất lượng (chat_luong) | 54 | 28 | 10 | 2 | 94 |
| Giao hàng (giao_hang) | 19 | 30 | 6 | 3 | 58 |
| Không gian (khong_gian) | 30 | 19 | 7 | 3 | 59 |
| Vệ sinh (ve_sinh) | 4 | 19 | 4 | 1 | 28 |
| Khác (khac) | 2 | 1 | 3 | 1 | 7 |
| **Tổng** | **162** | **173** | **50** | **15** | **400** |

Đồ uống và đồ ăn (chất lượng) vẫn được khen nhiều hơn chê (54 so với 28). Chủ đề bị chê nhiều nhất là giá (44), rồi phục vụ (32) và giao hàng (30). Vệ sinh ít bài nhưng gần như chỉ có chê (19 tiêu cực, 4 tích cực).

## Xu hướng theo tuần

Số ý kiến theo tuần (tuần bắt đầu thứ Hai; chi tiết từng chủ đề trong `xu-huong-tuan.csv`):

| Tuần | Số bài | Tích cực | Tiêu cực |
|---|---:|---:|---:|
| 24/08 | 16 | 10 | 10 |
| 31/08 | 19 | 16 | 10 |
| 07/09 | 19 | 18 | 9 |
| 14/09 | 21 | 19 | 14 |
| 21/09 | 19 | 15 | 13 |
| 28/09 | 22 | 18 | 13 |
| 05/10 | 25 | 16 | 24 |
| 12/10 | 22 | 13 | 14 |
| 19/10 | 23 | 11 | 20 |
| 26/10 | 20 | 5 | 19 |
| 02/11 | 18 | 9 | 16 |
| 09/11 | 18 | 12 | 11 |

- **Ý kiến tiêu cực tăng, tích cực giảm từ đầu tháng 10.** Tiêu cực ở mức 9 đến 14 mỗi tuần từ 24/08 đến 28/09, vọt lên 24 ở tuần 05/10 và giữ 11 đến 20 sau đó. Tích cực giảm từ 19 (tuần 14/09) xuống thấp nhất là 5 (tuần 26/10). Tuần 09/11 hạ nhiệt (11 tiêu cực, 12 tích cực); file không cho biết nguyên nhân.
- **Giá là biến động lớn nhất.** Trước 28/09 chỉ có 3 bài chê giá; từ 28/09 có 41 bài. 26 bài nhắc thẳng đến việc tăng giá, tất cả từ 28/09 trở đi (không bài nào trước đó).
- **Giao hàng xấu đi từ tuần 05/10.** Ý kiến tiêu cực về giao hàng là 5, 4, 5, 5, 4 mỗi tuần từ 05/10 đến 08/11, trong khi các tuần trước chỉ 0 đến 3. Tuần 09/11 là 0.
- **Cụm ngộ độc cuối tháng 10.** 6 bài kể đau bụng, nôn, tiêu chảy hoặc có dị vật/mùi lạ nằm trong 20/10 đến 28/10 (R170, R175, R178, R181, R193, R198), trước đó có R155 (15/10) nói ly nước có mùi lạ. R206 (30/10) cho biết khách đã ngại vì "vụ người ta báo đau bụng".
- **Vệ sinh tăng ở cuối kỳ.** Tuần 09/11 có 4 ý kiến tiêu cực về vệ sinh, nhiều nhất trong các tuần.
- **Chờ lâu và thiếu người ở quầy giảm.** Ý kiến tiêu cực về phục vụ cao nhất ở tuần 14/09 (7) rồi xuống 0 đến 3 mỗi tuần từ tuần 12/10.

## Việc 1: Kiểm soát an toàn thực phẩm ngay, điều tra các ca đau bụng và dị vật

**Vì sao.** Đây là nguy cơ lớn nhất: 7 bài thuộc loại ngộ độc/dị vật, 6 bài trong số đó đổ dồn vào 20/10 đến 28/10. Hai bài (R175, R181) cùng nhắc món tiramisu, và R170 kể đi cấp cứu, bác sĩ nghi ngộ độc thực phẩm. R193 nghi sữa hỏng, R198 nghi bánh croissant bị ôi, R178 có gián trong ly nước ép (khách nói đã chụp hình). Ngoài ra 3 bài nhắc ruồi bay quanh quầy bánh (R124, R192, R246) và 4 bài nhắc ly còn dấu son môi chưa rửa sạch (R133, R136, R240, R247). Một bài tới tay cơ quan quản lý hay lan trên mạng sẽ ảnh hưởng nặng hơn mọi vấn đề khác.

**Đề xuất hành động.**
- Tạm ngưng hoặc kiểm tra kỹ các món bánh kem/tiramisu, bánh mì chả, sữa chua cacao, croissant: kiểm hạn dùng, nhiệt độ bảo quản, nguồn nhập.
- Liên hệ các khách trên (qua phần trả lời đánh giá) để xin chi tiết và ghi nhận phản hồi; không tranh cãi công khai.
- Lập phiếu kiểm tra vệ sinh đầu ca (khu bánh có côn trùng chưa, ly rửa sạch chưa) và kiểm tra ly sau khi rửa.
- Báo cho nhà cung cấp chả, sữa, bánh để đối chiếu lô hàng.

**Bằng chứng.**
> [R170] "tối cả hai vợ chồng nôn mửa với tiêu chảy, phải đi cấp cứu. Bác sĩ nói nghi ngộ độc thực phẩm."
> [R175] "con mình 6 tuổi ăn xong 2 tiếng sau nôn và sốt"
> [R178] "mình thấy 1 con gián nhỏ nổi trong ly nước ép cam, chụp hình rồi"

## Việc 2: Chấm dứt tính tiền sai, phụ thu không báo và khuyến mãi không thực hiện

**Vì sao.** 6 bài thuộc loại lừa đảo/tính tiền, trong đó 1 bài ghi "nghi" (R135, khách nghĩ chỉ là nhập sai và nhân viên đã sửa). Các bài còn lại là: tính thừa một ly và nhân viên từ chối sửa (R149), tự cộng 10% phí dịch vụ không có trên menu (R216), giao ly size M nhưng tính size L (R219), khuyến mãi mua 1 tặng 1 trên fanpage nhưng quán nói hết chương trình dù bảng còn dán (R183), và Shopee Food đã thanh toán nhưng quán bấm hoàn thành đơn mà không giao, mất 189k (R197). Khách đang khuyên người khác "soi bill kỹ", tức là mất tin cậy.

**Đề xuất hành động.**
- Đối chiếu bill với menu mỗi ca; thu ngân phải sửa ngay khi khách báo sai, không được nói "máy tính tự tính".
- Nếu có phí dịch vụ 10%, ghi rõ trên menu và báo trước, hoặc bỏ.
- Gỡ bảng và bài đăng khuyến mãi ngay khi hết chương trình; ghi rõ ngày áp dụng.
- Xem lại đơn trong R197 trên Shopee Food: hoàn tiền cho khách và tìm hiểu vì sao đơn bị bấm hoàn thành mà không giao.

**Bằng chứng.**
> [R149] "Bill ghi 2 ly bạc xỉu mà mình chỉ gọi 1, báo thì nhân viên bảo máy tính tự tính nên cứ trả đủ"
> [R216] "Cuối bill tự cộng 10% phí dịch vụ, menu không ghi chỗ nào, hỏi thì nói quy định mới."
> [R219] "gọi size L trên menu, đưa ly size M mà vẫn tính tiền size L"

## Việc 3: Xử lý nhân viên chửi, quát, đuổi khách

**Vì sao.** 5 bài kể nhân viên chửi, quát hoặc đuổi khách (R039, R057, R066, R083, R091), diễn ra giữa 08/09 và 26/09, có bài ngay trước mặt cả quán hoặc khách nước ngoài (R083). Trong 5 bài, người bị nêu có thu ngân (R039), nhân viên ca tối (R057), nhân viên ở quầy (R091) và quản lý (R083), nên đây không phải chuyện một người. Khách viết "khỏi quay lại" (R039). Cùng lúc, các bài khen thái độ nhân viên vẫn nhiều (phục vụ có 39 ý kiến tích cực), nên đây là chuyện một số ca và vị trí, cần xử lý đúng chỗ.

**Đề xuất hành động.**
- Chủ quán hoặc quản lý xác định ca, người được nhắc tới (R039 thu ngân; R057 ca tối; R091 nhân viên nữ ở quầy; R066 và R083 xem camera nếu có) và nói chuyện trực tiếp.
- Đặt quy tắc đơn giản: khách hỏi thì phải trả lời; không quát, không cho khách ra khỏi quán khi chưa gây rối.
- Quản lý cũng phải theo quy tắc này (R083).
- Phản hồi công khai các bài này bằng lời xin lỗi ngắn.

**Bằng chứng.**
> [R039] "bạn thu ngân chửi luôn 'mù hả không đọc menu à' trước mặt cả quán"
> [R066] "mình thắc mắc thì bị nhân viên đuổi ra khỏi quán, giọng rất hách dịch"
> [R083] "Quản lý đứng quầy quát khách vì để xe sai chỗ, dùng từ rất khó nghe"

## Việc 4: Giải thích hoặc điều chỉnh đợt tăng giá và kích cỡ ly

**Vì sao.** Giá là chủ đề bị chê nhiều nhất: 44 ý kiến tiêu cực, 41 trong số đó từ 28/09. 26 bài nhắc tăng giá (menu mới tăng khoảng 10k mỗi món, trà đào cam sả lên 55k đến 65k), 4 bài nói rõ "không báo trước", 8 bài nói đắt hơn quán bên cạnh, 10 bài nhắc đến kích cỡ ly so với giá (ly vẫn vậy, ly nhỏ, hoặc size không đúng như R219). Đây cũng là nguyên nhân khách nói ghé ít đi (R182, R243). Không bài nào chê giá trước 28/09 nói về tăng giá, nên thời điểm tăng giá là nguyên nhân rõ nhất của đợt chê này.

**Đề xuất hành động.**
- Báo trước việc tăng giá bằng bảng giá mới và bài đăng, không để khách biết lúc thanh toán.
- Xem lại các món tăng nhiều nhất (trà đào cam sả, cacao đá xay, cà phê muối) so với quán bên cạnh; nếu giữ giá thì cho khách thấy ly đủ đầy (R106, R052 từng khen "giá có 35k mà đầy đặn").
- Kiểm tra lại dung tích ly: khách so sánh ly nhỏ lại (R151).
- Cân nhắc giữ vài món giá cũ hoặc combo cho sinh viên, vì có khách khen giá mềm (R092, R100).

**Bằng chứng.**
> [R118] "lên giá mà không báo trước, thấy hơi tiếc"
> [R151] "Giá lên mà ly thì nhỏ lại?? 55k 1 ly cf muối mà uống 3 ngụm hết, ko đáng tiền"
> [R099] "Giá lên hoài, giờ đắt hơn quán bên cạnh"

## Việc 5: Sửa khâu giao hàng và đóng gói trên Shopee Food

**Vì sao.** 30 ý kiến giao hàng tiêu cực (19 tích cực), tăng từ tuần 05/10. Theo từ khóa: 7 bài nước đổ ra túi, 7 bài đồ ăn tới nguội/thiếu món, 11 bài giao chậm hoặc trễ, 3 bài giao nhầm món, 4 bài shipper gọi không bắt máy; ngoài ra R197 là đơn không giao. Đóng gói và nhiệt độ là lỗi lặp lại, quán tự sửa được (R143, R215 nói đóng gói ẩu/sơ sài). Phần giao chậm có thể do shipper, nhưng 4 bài "không bắt máy" cho thấy quán và shipper chưa phối hợp tốt.

**Đề xuất hành động.**
- Đóng nắp và bọc ly hai lớp trước khi cho vào túi; dùng túi/hộp giữ nhiệt cho đồ ăn.
- Kiểm đơn trước khi giao theo danh sách (đủ món, đúng món); tách người đóng gói và người nhận đơn khi đông.
- Xem lại thời gian chuẩn bị trên Shopee Food để không hứa quá ngắn, và theo dõi các đơn giao chậm trên 30 phút.
- Chia sẻ các bài này với người phụ trách đơn để rà từng trường hợp.

**Bằng chứng.**
> [R147] "Nước giao tới bị đổ ra túi, dính đầy"
> [R173] "đồ ăn tới nguội và thiếu một món"
> [R162] "Shipper gọi mà không bắt máy, đồ tới trễ"

## Ghi chú và các việc không nằm trong 5 việc trên

- **Vệ sinh chỗ ngồi và nhà vệ sinh:** 19 ý kiến tiêu cực (6 bài bàn dính nước ngọt cũ chưa lau, 3 bài sàn trơn/ướt, 2 bài nhà vệ sinh bẩn/hết giấy). Có thể xử lý cùng Việc 1 bằng phiếu kiểm tra vệ sinh.
- **Chờ lâu và thiếu nhân viên giờ cao điểm:** 10 bài chờ lâu, 6 bài nhân viên ít; đã giảm từ tháng 10 nhưng chưa biến mất.
- **Wifi chập chờn, quán ồn, chỗ để xe nhỏ:** xuất hiện lẻ tẻ trong chủ đề không gian (19 ý kiến tiêu cực).
- **Điểm mạnh nên giữ:** chất lượng đồ uống (54 ý kiến tích cực), phục vụ (39), không gian (30), nhất là ghế êm có ổ cắm, view ban công, nhân viên nhớ mặt khách quen.
- **Các lựa chọn cần chủ quán xem lại:**
  - R191 ("Quán bên kia đường ngon hơn nhiều, qua đó đi mọi người ơi") được loại là spam/quảng cáo cho quán khác; nếu chủ quán coi đó là một lời chê thật thì hãy đưa lại vào phân tích.
  - Các bài "lên giá mà không báo trước" (R118, R187, R195, R218) được xếp vào chủ đề giá, không xếp vào nguy cấp, vì khách không nói bị tính sai so với menu.
  - R118 và R218 chỉ khác nhau ở chữ hoa/chữ thường, R144 và R173 cũng vậy; vì không trùng nguyên văn nên cả hai cặp đều được giữ lại.
  - R115 ("Đau bụng cười...") và R123 ("không phải lừa đảo đâu...") chỉ là cách nói đùa/khen, không thuộc nguy cấp.
