# Báo cáo kiểm – nội dung đăng bán 40 sản phẩm "Vườn Nhỏ"

## 1. Tóm tắt

| | Số lượng |
|---|---|
| Tổng sản phẩm | 40 |
| `SAN_SANG` (đủ 6 trường bắt buộc) | **31** |
| `CAN_BO_SUNG` (thiếu ít nhất 1 trường bắt buộc) | **9** (VN-007, 009, 014, 019, 025, 027, 029, 034, 038) |
| Ô thông tin bắt buộc còn thiếu | 17 |
| Dòng dùng `CẦN NGƯỜI QUYẾT` trong file | 0 (xem mục 3: các điểm cần người quyết nằm ở báo cáo, không ghi vào mô tả) |

Kết quả `kiem.py`: **0 lỗi**. Chưa có gì "chưa sạch" theo các phép kiểm trong mục 4. Lưu ý: "sạch" chỉ nghĩa là khớp bảng thông số và quy định; các điểm ở mục 3 vẫn cần người xem trước khi đăng.

File nộp: `nhap_hang_loat.csv` (UTF-8 có BOM), `nhap_hang_loat.xlsx` (nội dung giống hệt csv), `kiem.py`, `bao_cao_kiem.md`.

## 2. Trường thiếu theo từng SKU (9 sản phẩm CAN_BO_SUNG)

Cụm `CẦN BỔ SUNG: <cột>` đã được ghi đúng chỗ trong `mo_ta` và gạch liên quan; cột `truong_can_bo_sung` liệt kê các cột này.

| SKU | Sản phẩm | Trường bắt buộc còn thiếu | Giá trị hiện trong bảng |
|---|---|---|---|
| VN-007 | Nước cân bằng da Mầm Xanh | dung_tich; thanh_phan_noi_bat; xuat_xu; han_su_dung; cong_dung_tren_bao_bi; cach_dung | để trống cả 6 (và cả loai_da_phu_hop, mui_huong, so_phieu_cong_bo) |
| VN-009 | Tinh chất dưỡng da Suối Mát | xuat_xu | để trống |
| VN-014 | Kem dưỡng ẩm Suối Mát | xuat_xu; han_su_dung | `N/A`; `?` |
| VN-019 | Kem chống nắng Mầm Xanh | thanh_phan_noi_bat; cong_dung_tren_bao_bi | `liên hệ NCC`; `?` |
| VN-025 | Son dưỡng môi Suối Mát | thanh_phan_noi_bat | `chưa rõ` |
| VN-027 | Dầu gội Đồi Chè | cach_dung | `chưa có` |
| VN-029 | Dầu gội Mầm Xanh | dung_tich | để trống |
| VN-034 | Kem dưỡng da tay Đồi Chè | dung_tich; han_su_dung | `?`; `N/A` |
| VN-038 | Nước tẩy trang Đồi Chè | dung_tich | để trống |

Ghi chú khi bổ sung:
- Tiêu đề của các SKU thiếu `dung_tich` (VN-007, 029, 034, 038) hiện **không có dung tích** (quy định cho phép: "nếu có trong bảng"). Khi có số, cần thêm vào tiêu đề.
- Trường **không bắt buộc** nhưng cũng đang trống: VN-007 thiếu `loai_da_phu_hop` và `mui_huong`. Tôi không đưa hai cột này vào `truong_can_bo_sung` vì quy định chỉ coi 6 trường kia là bắt buộc; mô tả VN-007 chỉ bỏ qua hai ý đó.
- `chi_so_chong_nang` trống ở các sản phẩm không phải chống nắng là bình thường, không tính là thiếu.

## 3. Chỗ nghi ngờ, cần người quyết

**A. Ghi chú nội bộ mâu thuẫn hoặc có thể sai (đã KHÔNG đưa vào nội dung):**

| SKU | Vấn đề | Tôi đã làm gì | Cần người quyết |
|---|---|---|---|
| VN-012 | Bảng ghi vitamin C **10%**, ghi chú nói "thực ra 15%, chờ phiếu kiểm nghiệm" | Dùng 10% theo bảng; xếp `SAN_SANG` | **Quan trọng nhất.** Nếu 10% sai thì mô tả, gạch 1 và từ khóa đều sai. Nên đợi phiếu kiểm nghiệm rồi mới đăng, hoặc bỏ nồng độ khỏi nội dung. |
| VN-003 | Ghi chú: chưa test da nhạy cảm nhưng cứ ghi "phù hợp da nhạy cảm" | Chỉ ghi "mọi loại da" như bảng, không nhắc da nhạy cảm | Có giữ "mọi loại da" khi chưa test da nhạy cảm không? |
| VN-010 | Chưa chắc có cồn hay không | Không nói gì về cồn | Hỏi lại NCC |
| VN-011 | Bản cũ ghi 15 tháng sau khi mở, chưa chắc | Không ghi hạn sau khi mở; chỉ ghi hạn trong bảng | Hỏi lại NCC |
| VN-014 | NCC nói miệng "không paraben", chưa có giấy | Không ghi | Cần giấy tờ |
| VN-018 | Ghi chú "hàng nhập khẩu chính ngạch" **trái** với xuất xứ Việt Nam trong bảng | Ghi xuất xứ Việt Nam | Xác nhận lại xuất xứ |
| VN-020 | Ghi chú "dùng được cho bà bầu và em bé (chưa kiểm tra)" | Không ghi | Chưa kiểm tra thì không nên ghi |
| VN-039 | NCC nói "đạt chuẩn FDA Mỹ", chưa có giấy | Không ghi | Cần giấy tờ |

**B. Ghi chú đề nghị ghi nội dung vi phạm quy định (đã bỏ qua hoàn toàn):** VN-009 ("bán chạy số 1"), VN-019 ("trắng da sau 7 ngày"), VN-022 ("tốt nhất thị trường"), VN-024 ("chữa khỏi viêm da"), VN-028 ("hết mụn hẳn"), VN-030 ("rẻ hơn đối thủ 30%"), VN-033 ("hết nám"). Đều là từ cấm hoặc so sánh/cam kết kết quả; số 7, 30 cũng không có trong bảng của các SKU này.

**C. Phiếu công bố:**
- Có số phiếu → mô tả ghi "đã có phiếu công bố số …": **10** SKU (VN-004, 008, 012, 020, 021, 023, 024, 025, 026, 035).
- Ghi "đang chờ duyệt" → **không** nhắc phiếu, không nói đã công bố: 4 SKU (VN-001, 027, 028, 034).
- Để trống → không nhắc phiếu: 26 SKU còn lại.
- VN-025 có số phiếu `DEMO-8057` nhưng thành phần lại "chưa rõ". Thường phiếu công bố ghi đủ thành phần, nên nên tra phiếu này để điền cột thành phần.
- Số phiếu mang tiền tố `DEMO`. Tôi chép đúng như bảng, nhưng nếu đây chỉ là mã giả thì không nên đăng thật.

**D. Quyết định cách viết của tôi, cần người đồng ý:**
- Công dụng được viết là "Công dụng ghi trên bao bì: …" (đúng tên cột `cong_dung_tren_bao_bi`), không viết thành lời hứa của shop.
- "SPF", "PA", "UV", "DEMO-…" là viết tắt/mã có trong bảng, giữ nguyên; tôi không coi là "viết HOA để nhấn mạnh". Cụm `CẦN BỔ SUNG` do quy định bắt buộc nên cũng viết hoa.
- Câu kết "Bạn cần hỏi thêm về sản phẩm, cứ nhắn Vườn Nhỏ nhé." là câu duy nhất không lấy từ bảng; nó giả định shop nhận tin nhắn trên sàn. Bỏ đi nếu không đúng.
- Từ khóa gồm cả dạng không dấu (ví dụ "sua rua mat gel") được suy ra từ tên sản phẩm. Không thêm từ khóa nào ngoài bảng.
- Các giới hạn độ dài là giả định nội bộ của shop (theo quy định), chưa đối chiếu với giới hạn thật của từng sàn.

## 4. Kết quả chạy kiem.py

Lệnh: `python kiem.py`, mã thoát 0.

```
Đã kiểm 40 sản phẩm: 31 SAN_SANG, 9 CAN_BO_SUNG.
SẠCH: 0 lỗi (độ dài, từ cấm, số liệu, 5 gạch, từ khóa, trạng thái, xlsx = csv).
```

Các phép kiểm (mỗi sản phẩm):
- File: có BOM, đúng tiêu đề cột như `mau_dau_ra.csv`, đủ 40 dòng, SKU đúng thứ tự, xlsx khớp csv từng ô.
- Độ dài: tiêu đề 25–100; mô tả 200–1500; 5 gạch đều có và ≤120; từ khóa 6–10 cụm, ≤30 ký tự, không trùng.
- Từ cấm (cả viết hoa và không dấu) ở tiêu đề, mô tả, gạch, từ khóa.
- Mọi con số trong tiêu đề, mô tả, gạch phải có trong bảng của đúng sản phẩm đó (không tính cột `sku` và `ghi_chu_noi_bo`).
- Mô tả chứa đúng nguyên văn từng trường bắt buộc có trong bảng; xuất xứ, thành phần, mùi hương, loại da không nhắc thứ bảng không có; không có cụm lấy từ ghi chú nội bộ (FDA, paraben, cồn, nhạy cảm, bà bầu…).
- Chỉ nhắc phiếu công bố khi bảng có số phiếu, và nêu đúng số đó.
- Giọng thương hiệu: không emoji, không "quý khách/chị em/chúng tôi", ≤1 dấu chấm than, không viết HOA cả từ, có "bạn" và "Vườn Nhỏ".
- Trạng thái và `truong_can_bo_sung` khớp đúng các trường thiếu; `CAN_BO_SUNG` có đủ cụm `CẦN BỔ SUNG: <cột>`; `SAN_SANG` không còn cụm "CẦN …".

Tự kiểm lại bộ kiểm: tôi tạo bản sao tạm, cố ý tiêm 21 lỗi, qua hai lượt thử (từ cấm "tốt nhất" và "chữa khỏi", số 15 từ ghi chú, đổi 10% thành 15%, FDA/Mỹ, "nhạy cảm", emoji, hai dấu chấm than, chữ HOA, "rẻ hơn", nói "đã công bố" khi chỉ chờ duyệt, số phiếu sai, xuất xứ sai, gạch rỗng, gạch dài 130, từ khóa chỉ 3 cụm, tiêu đề 4 ký tự, trạng thái sai, thiếu cột trong `truong_can_bo_sung`, thay "CẦN BỔ SUNG" bằng số liệu tự điền). `kiem.py` bắt được tất cả; bản sao đã xóa. Hạn chế: `kiem.py` kiểm khớp bảng và quy định bằng quy tắc, không hiểu nghĩa câu. Một ý nói theo cách khác, không chứa từ trong danh sách cụm nghi ngờ, vẫn có thể lọt. Nội dung do mẫu câu cố định sinh ra từ bảng nên rủi ro này thấp, nhưng nếu ai sửa tay thì nên đọc lại.
