# BÁO CÁO KIỂM TRA DỮ LIỆU CHẤM CÔNG THÁNG 09/2026

**Kính gửi:** Ban Quản lý / Bộ phận Điều hành  
**Người chuẩn bị:** Trợ lý kiểm tra chấm công  
**Kỳ chấm công:** 01/09/2026 – 30/09/2026 (30 ngày dương lịch)  
**Quy mô:** 25 nhân viên (15 nhân viên Chi nhánh A, 10 nhân viên Chi nhánh B)  

---

## 1. TỔNG HỢP SỐ LIỆU CHẤM CÔNG TOÀN CÔNG TY

- **Tổng số công chuẩn xác nhận hoàn thành (OK):** 501 ngày công (trung bình 20.04 công/người).
- **Tổng số giờ làm việc chuẩn đã tính:** 3,989.11 giờ.
- **Tổng số giờ làm thêm (OT) đã ghi nhận:** 98.48 giờ (trong đó nhân viên NV-001 có thời gian làm thêm cao nhất: 44.95 giờ).
- **Tổng số ngày nghỉ phép hợp lệ (PHEP):** 15 ngày (theo đơn đã duyệt).
- **Tổng số ngày nghỉ tuần/nghỉ lễ không phát sinh quẹt (NGHI):** 204 ngày.
- **Tổng số ngày công cần quản lý xác nhận (CHO_XAC_NHAN):** 30 ngày.
- **Tổng số trường hợp bất thường phát hiện:** 61 trường hợp (37 trường hợp cần người quyết, 24 trường hợp tự động xử lý theo quy định).

---

## 2. DANH SÁCH VIỆC CẦN QUẢN LÝ XÁC NHẬN (GOM THEO NHÓM)

### Nhóm 1: Nghi vấn quẹt hộ giữa hai chi nhánh (4 trường hợp) – `NGHI_QUET_HO`
Phát hiện mã thẻ được quẹt tại cả 2 máy (MAY-A1 và MAY-B1) cách nhau <= 10 phút:
- **NV-009** (23/09): quẹt MAY-A1 lúc 07:59 và MAY-B1 lúc 08:05 (cách 6 phút).
- **NV-015** (20/09): quẹt MAY-B1 lúc 05:54 và MAY-A1 lúc 06:01 (cách 7 phút).
- **NV-016** (24/09): quẹt MAY-A1 lúc 07:56 và MAY-B1 lúc 08:04 (cách 8 phút).
- **NV-022** (24/09): quẹt MAY-A1 lúc 07:52 và MAY-B1 lúc 07:54 (cách 2 phút).
> **Đề xuất xử lý:** Đề nghị người có thẩm quyền kiểm tra hình ảnh camera tại hai máy chấm công và lịch trình di chuyển thực tế của nhân sự liên quan để xác minh, không tự ý kết luận. Ngày công đang tạm để trống giờ làm việc (`CHO_XAC_NHAN`).

### Nhóm 2: Vắng mặt chưa có đơn nghỉ phép (6 trường hợp) – `VANG_CHUA_GHI`
Không có dữ liệu quẹt thẻ trong ngày làm việc và chưa có đơn nghỉ duyệt trên hệ thống:
- **NV-002** (22/09, ca C), **NV-003** (28/09, ca S), **NV-010** (21/09, ca HC), **NV-023** (11/09, ca HC), **NV-024** (21/09, ca HC), **NV-026** (24/09, ca HC).
> **Đề xuất xử lý:** Quản lý trực tiếp liên hệ với nhân viên để kiểm tra lý do vắng mặt, hướng dẫn bổ sung đơn xin nghỉ phép/nghỉ việc riêng (nếu có lý do chính đáng) hoặc xác nhận hình thức nghỉ.

### Nhóm 3: Quẹt thẻ đơn lẻ / Thiếu lượt quẹt (11 trường hợp)
- **Thiếu quẹt ra (5 ca) – `THIEU_RA`:** NV-011 (14/09, vào 13:49 ca C), NV-013 (05/09, vào 13:51 ca C), NV-025 (28/09, vào 07:58 ca HC), NV-026 (10/09 và 25/09, đều vào 08:03 ca HC).
- **Thiếu quẹt vào (3 ca) – `THIEU_VAO`:** NV-011 (24/09, ra 14:12 ca S), NV-013 (13/09, ra 14:20 ca S), NV-021 (10/09, ra 17:09 ca HC).
- **Quẹt giữa ca không rõ chiều (3 ca) – `THIEU_KHONG_RO`:** NV-013 (06/09 lúc 18:12 ca C), NV-023 (30/09 lúc 13:21 ca HC), NV-025 (11/09 lúc 13:21 ca HC).
> **Đề xuất xử lý:** Quản lý bộ phận xác nhận thời gian đến và về thực tế của nhân viên để hoàn thiện giờ công.

### Nhóm 4: Quẹt thẻ vào ngày nghỉ và ngày lễ (7 trường hợp)
- **Làm ngày lễ (3 ca) – `LAM_NGAY_LE`:** NV-007 (01/09, 08:00–16:41), NV-010 (02/09, 08:06–16:42), NV-018 (02/09, 07:58–17:09).
- **Làm ngày nghỉ (4 ca) – `LAM_NGAY_NGHI`:** NV-013 (12/09, 08:16–12:20), NV-014 (24/09, 07:55–17:03), NV-016 (12/09, 07:52–17:23), NV-022 (27/09, 07:58–12:05).
> **Đề xuất xử lý:** Quản lý xác nhận có phân công làm thêm vào ngày nghỉ/ngày lễ hay không; chế độ phụ cấp và tính công ngày lễ, nghỉ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.

### Nhóm 5: Có đơn nghỉ phép đã duyệt nhưng vẫn quẹt thẻ (2 trường hợp) – `CO_PHEP_NHUNG_QUET`
- **NV-010** (23/09, quẹt 07:41–17:24, đơn Phép năm).
- **NV-023** (23/09, quẹt 07:42–17:16, đơn Phép năm).
> **Đề xuất xử lý:** Xác nhận với nhân viên có đi làm thực tế để hủy đơn nghỉ phép và tính công, hoặc giữ nguyên phép và hủy giờ quẹt.

### Nhóm 6: Làm thêm giờ vượt ngưỡng cảnh báo (4 trường hợp)
- **Vượt ngưỡng ngày (> 180 phút, 3 ca) – `OT_VUOT_NGUONG`:** NV-025 (10/09, làm thêm 222 phút), NV-013 (26/09, làm thêm 199 phút), NV-010 (28/09, làm thêm 227 phút).
- **Vượt ngưỡng tháng (> 2400 phút, 1 ca) – `OT_THANG_VUOT`:** NV-001 (tổng làm thêm cả tháng đạt 2697 phút ~ 44.95 giờ).
> **Đề xuất xử lý:** Quản lý xác nhận việc giao việc làm thêm giờ; quy định giới hạn giờ làm thêm cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.

### Nhóm 7: Dữ liệu lỗi hệ thống máy chấm công (3 trường hợp) – `DU_LIEU_LOI`
- Quẹt mang mã **NV-005** (2026-09-11 lúc 09:20 tại MAY-A1): mã không tồn tại trong danh sách nhân viên.
- Quẹt của **NV-007** tại MAY-A1 có thời gian bị trống (`NaN`).
- Quẹt của **NV-023** tại MAY-B1 có thời gian không hợp lệ (`31/09/2026 08:00`, tháng 9 chỉ có 30 ngày).
> **Đề xuất xử lý:** Bộ phận kỹ thuật IT kiểm tra lại bộ nhớ và thiết lập thời gian máy MAY-A1, MAY-B1; bộ phận nhân sự kiểm tra xem NV-005 có phải nhân sự mới chưa khai báo.

---

## 3. CÁC TRƯỜNG HỢP HỆ THỐNG ĐÃ TỰ ĐỘNG XỬ LÝ (KHÔNG CẦN QUYẾT)
- **Đi trễ (12 ca) – `DI_TRE`:** Đã tính đúng số phút trễ (trên 5 phút dung sai) và trừ giờ công theo quy chế.
- **Về sớm (6 ca) – `VE_SOM`:** Đã tính đúng số phút về sớm (trên 5 phút dung sai) và trừ giờ công theo quy chế.
- **Quẹt trùng (6 ca) – `QUET_TRUNG`:** Đã tự động giữ lần quẹt đầu tiên và loại bỏ các lần quẹt sau trong phạm vi <= 3 phút cùng máy.

---

## 4. CÁC GIẢ ĐỊNH VÀ VẤN ĐỀ CẦN LƯU Ý (ĐIỀU CHƯA CHẮC)
1. **Xử lý ngày nghỉ phép trùng ngày nghỉ tuần:** Đơn nghỉ ốm có giấy của NV-009 (từ 03/09 đến 07/09) bao gồm 2 ngày nghỉ tuần (05-06/09) và NV-020 (từ 29/09 đến 30/09) bao gồm ngày OFF (30/09). Theo nguyên văn quy chế công ty mục 5.7 ("Ngày nằm trong đơn nghỉ phép đã duyệt và không có quẹt: trạng thái PHEP"), hệ thống hiện ghi nhận toàn bộ các ngày trong đơn là PHEP (NV-009 có 5 ngày phép, NV-020 có 2 ngày phép). Tuy nhiên, về mặt hưởng trợ cấp ốm đau hoặc quy đổi ngày phép làm việc thực tế, cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự để quyết định có chuyển các ngày nghỉ tuần về trạng thái NGHI hay không.
2. **Quẹt đơn lẻ giữa ca (THIEU_KHONG_RO):** 3 trường hợp quẹt giữa ca (13:21 hoặc 18:12) hoàn toàn để trống giờ vào và giờ ra, không phỏng đoán, chờ người có thẩm quyền quyết định.
3. **Giờ công các ngày chờ xác nhận:** Toàn bộ 30 ngày trạng thái `CHO_XAC_NHAN` đều để trống số giờ công và giờ làm thêm, không tạm tính để tránh sai lệch lương.
