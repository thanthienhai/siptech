import csv
import datetime
from datetime import timedelta
import pandas as pd

def parse_time(val):
    if pd.isna(val) or val is None:
        return None
    s = str(val).strip()
    if not s or s.lower() == 'nan':
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%d/%m/%Y %H:%M'):
        try:
            dt = datetime.datetime.strptime(s, fmt)
            return dt.replace(second=0, microsecond=0)
        except ValueError:
            pass
    return None

def to_min(t_str):
    h, m = map(int, t_str.split(':'))
    return h * 60 + m

def main():
    # 1. Read input files
    nv_df = pd.read_csv('nhan_vien.csv')
    np_df = pd.read_csv('nghi_phep.csv')
    lc_df = pd.read_csv('lich_ca_xoay.csv')
    cc_df = pd.read_csv('cham_cong.csv')

    valid_nv = set(nv_df['ma_nv'])
    nv_info = {r['ma_nv']: r for _, r in nv_df.iterrows()}

    # Parse shifts in lich_ca_xoay
    lc_df['date_iso'] = lc_df['ngay'].apply(lambda s: datetime.datetime.strptime(s.strip(), '%d/%m/%Y').strftime('%Y-%m-%d'))
    lc_map = {(r['ma_nv'].strip(), r['date_iso']): r['ca'].strip() for _, r in lc_df.iterrows()}

    # Parse approved leaves
    np_set = set()
    for _, r in np_df.iterrows():
        if str(r['trang_thai']).strip() == 'Đã duyệt':
            m = str(r['ma_nv']).strip()
            t_start = datetime.datetime.strptime(str(r['tu_ngay']).strip(), '%d/%m/%Y')
            t_end = datetime.datetime.strptime(str(r['den_ngay']).strip(), '%d/%m/%Y')
            cur = t_start
            while cur <= t_end:
                np_set.add((m, cur.strftime('%Y-%m-%d')))
                cur += timedelta(days=1)

    # 2. Identify DU_LIEU_LOI and valid swipes
    anomalies = []
    valid_swipes = []

    for idx, r in cc_df.iterrows():
        m = str(r['ma_nv']).strip() if pd.notna(r['ma_nv']) else ''
        t_raw = r['thoi_gian']
        t_str = str(t_raw).strip() if pd.notna(t_raw) else ''
        m_may = str(r['ma_may']).strip() if pd.notna(r['ma_may']) else ''
        dt = parse_time(t_raw)

        is_error = False
        if m not in valid_nv:
            is_error = True
            date_str = dt.strftime('%Y-%m-%d') if dt else ''
            anomalies.append({
                'ma_nv': m,
                'ngay': date_str,
                'loai': 'DU_LIEU_LOI',
                'chi_tiet': f"Mã NV {m} không có trong danh sách nhân viên, quẹt tại {m_may} lúc {dt.strftime('%H:%M') if dt else t_str}",
                'can_nguoi_quyet': 'CO',
                'giai_thich': f"Mã nhân viên {m} không tồn tại trong danh sách nhân sự của công ty nhưng có dữ liệu quẹt thẻ. Cần kiểm tra lại mã thẻ hoặc thông tin nhân sự mới chưa được cập nhật."
            })
        elif dt is None:
            is_error = True
            anomalies.append({
                'ma_nv': m,
                'ngay': '',
                'loai': 'DU_LIEU_LOI',
                'chi_tiet': f"Thời gian quẹt không hợp lệ/trống ({t_str}) tại {m_may}",
                'can_nguoi_quyet': 'CO',
                'giai_thich': f"Bản ghi quẹt thẻ của {m} tại máy {m_may} có thời gian trống hoặc không hợp lệ trên lịch dương. Cần kiểm tra kỹ thuật thiết bị hoặc đối chiếu nhật ký quẹt thẻ."
            })

        if not is_error:
            valid_swipes.append({
                'orig_idx': idx,
                'ma_nv': m,
                'ma_may': m_may,
                'dt': dt,
                'date': dt.strftime('%Y-%m-%d'),
                'time': dt.strftime('%H:%M')
            })

    v_df = pd.DataFrame(valid_swipes)

    # 3. Helper to determine shift
    def get_shift_info(ma_nv, date_str):
        if date_str in ('2026-09-01', '2026-09-02'):
            return 'LE', None, None
        emp = nv_info[ma_nv]
        dt_obj = datetime.datetime.strptime(date_str, '%Y-%m-%d')
        if emp['loai_ca'] == 'HC':
            if dt_obj.weekday() in (5, 6): # Sat, Sun
                return 'OFF', None, None
            return 'HC', '08:00', '17:00'
        else: # XOAY
            ca = lc_map.get((ma_nv, date_str), 'OFF')
            if ca == 'S':
                return 'S', '06:00', '14:00'
            elif ca == 'C':
                return 'C', '14:00', '22:00'
            else:
                return 'OFF', None, None

    all_days = [d.strftime('%Y-%m-%d') for d in pd.date_range('2026-09-01', '2026-09-30')]
    sorted_emps = sorted(list(valid_nv))

    bang_cong_rows = []
    emp_ot_month = {m: 0 for m in sorted_emps}

    # Process timesheets
    for m in sorted_emps:
        for d in all_days:
            loai_ngay, s_in, s_out = get_shift_info(m, d)

            # Get day's swipes
            if len(v_df) > 0:
                day_swipes = v_df[(v_df['ma_nv'] == m) & (v_df['date'] == d)].sort_values(by=['dt', 'orig_idx'])
            else:
                day_swipes = pd.DataFrame()

            # Check NGHI_QUET_HO: two swipes at different machines within <= 10 min
            is_susp = False
            susp_detail = ""
            for i in range(len(day_swipes)):
                for j in range(i + 1, len(day_swipes)):
                    diff_m = abs((day_swipes.iloc[j]['dt'] - day_swipes.iloc[i]['dt']).total_seconds()) / 60.0
                    if day_swipes.iloc[i]['ma_may'] != day_swipes.iloc[j]['ma_may'] and diff_m <= 10.0:
                        is_susp = True
                        susp_detail = f"quẹt tại {day_swipes.iloc[i]['ma_may']} lúc {day_swipes.iloc[i]['time']} và {day_swipes.iloc[j]['ma_may']} lúc {day_swipes.iloc[j]['time']} (cách nhau {int(diff_m)} phút)"
                        break
                if is_susp:
                    break

            # Filter duplicates (QUET_TRUNG): same machine, diff <= 3 min
            kept_swipes = []
            has_dup = False
            dup_detail = []
            for _, sw in day_swipes.iterrows():
                if not kept_swipes:
                    kept_swipes.append(sw)
                else:
                    prev = kept_swipes[-1]
                    diff_m = (sw['dt'] - prev['dt']).total_seconds() / 60.0
                    if sw['ma_may'] == prev['ma_may'] and diff_m <= 3.0:
                        has_dup = True
                        dup_detail.append(f"{prev['time']} và {sw['time']} ({int(diff_m)} phút)")
                    else:
                        kept_swipes.append(sw)

            if has_dup:
                anomalies.append({
                    'ma_nv': m,
                    'ngay': d,
                    'loai': 'QUET_TRUNG',
                    'chi_tiet': f"quẹt trùng tại cùng máy: {', '.join(dup_detail)}",
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f"Ghi nhận quẹt thẻ nhiều lần trên cùng một máy cách nhau <= 3 phút. Hệ thống đã tự động giữ quẹt đầu và bỏ quẹt sau theo quy định."
                })

            if is_susp:
                anomalies.append({
                    'ma_nv': m,
                    'ngay': d,
                    'loai': 'NGHI_QUET_HO',
                    'chi_tiet': susp_detail,
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f"Dữ liệu ghi nhận {m} quẹt ở 2 chi nhánh khác nhau trong thời gian ngắn, nghi ngờ quẹt hộ. Đề nghị người có thẩm quyền kiểm tra camera hoặc đối chiếu lịch trình thực tế, không tự ý kết luận."
                })
                # As per rule 5.9: không tự tính giờ, chờ xác nhận
                gio_v = day_swipes.iloc[0]['time']
                gio_r = day_swipes.iloc[-1]['time']
                bang_cong_rows.append({
                    'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': gio_v, 'gio_ra': gio_r,
                    'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': 'CHO_XAC_NHAN'
                })
                continue

            has_leave = (m, d) in np_set

            # Check leave
            if has_leave:
                if len(day_swipes) > 0:
                    gio_v = day_swipes.iloc[0]['time']
                    gio_r = day_swipes.iloc[-1]['time']
                    anomalies.append({
                        'ma_nv': m,
                        'ngay': d,
                        'loai': 'CO_PHEP_NHUNG_QUET',
                        'chi_tiet': f"có đơn nghỉ phép đã duyệt nhưng có quẹt (vào {gio_v}, ra {gio_r})",
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} đã có đơn nghỉ phép được duyệt nhưng vẫn phát sinh dữ liệu quẹt thẻ. Cần người quản lý xác nhận nhân viên có đi làm thực tế hay hủy đơn nghỉ phép để tính công."
                    })
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': gio_v, 'gio_ra': gio_r,
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'CHO_XAC_NHAN'
                    })
                else:
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': '', 'gio_ra': '',
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'PHEP'
                    })
                continue

            # Check holiday (LE)
            if loai_ngay == 'LE':
                if len(day_swipes) > 0:
                    gio_v = day_swipes.iloc[0]['time']
                    gio_r = day_swipes.iloc[-1]['time']
                    anomalies.append({
                        'ma_nv': m,
                        'ngay': d,
                        'loai': 'LAM_NGAY_LE',
                        'chi_tiet': f"quẹt thẻ ngày lễ ({gio_v} - {gio_r})",
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} phát sinh dữ liệu quẹt thẻ trong ngày nghỉ lễ. Cần người quản lý xác nhận việc phân công làm việc ngày lễ và kiểm tra với văn bản hiện hành hoặc chuyên gia nhân sự."
                    })
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': gio_v, 'gio_ra': gio_r,
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'CHO_XAC_NHAN'
                    })
                else:
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': '', 'gio_ra': '',
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'NGHI'
                    })
                continue

            # Check rest day (OFF)
            if loai_ngay == 'OFF':
                if len(day_swipes) > 0:
                    gio_v = day_swipes.iloc[0]['time']
                    gio_r = day_swipes.iloc[-1]['time']
                    anomalies.append({
                        'ma_nv': m,
                        'ngay': d,
                        'loai': 'LAM_NGAY_NGHI',
                        'chi_tiet': f"quẹt thẻ ngày nghỉ OFF ({gio_v} - {gio_r})",
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} phát sinh dữ liệu quẹt thẻ vào ngày nghỉ tuần hoặc ca OFF. Cần người quản lý xác nhận việc phân công làm việc ngoài lịch để phê duyệt công."
                    })
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': gio_v, 'gio_ra': gio_r,
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'CHO_XAC_NHAN'
                    })
                else:
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': '', 'gio_ra': '',
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'NGHI'
                    })
                continue

            # Regular work day: HC, S, C
            if len(day_swipes) == 0:
                anomalies.append({
                    'ma_nv': m,
                    'ngay': d,
                    'loai': 'VANG_CHUA_GHI',
                    'chi_tiet': f"ca {loai_ngay} không có dữ liệu quẹt thẻ và không có đơn nghỉ",
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f"Nhân viên {m} vắng mặt trong ca làm việc mà không có dữ liệu quẹt thẻ hay đơn nghỉ phép. Cần người quản lý kiểm tra lý do và xác nhận hình thức nghỉ."
                })
                bang_cong_rows.append({
                    'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                    'gio_vao': '', 'gio_ra': '',
                    'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                    'trang_thai': 'CHO_XAC_NHAN'
                })
                continue

            if len(kept_swipes) == 1:
                t_sw_str = kept_swipes[0]['time']
                t_sw = to_min(t_sw_str)
                t_in = to_min(s_in)
                t_out = to_min(s_out)

                if t_sw <= t_in + 120:
                    anomalies.append({
                        'ma_nv': m,
                        'ngay': d,
                        'loai': 'THIEU_RA',
                        'chi_tiet': f"vào {t_sw_str}, thiếu quẹt ra",
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} có quẹt vào lúc {t_sw_str} nhưng thiếu dữ liệu quẹt ra cuối ca. Cần người quản lý xác nhận giờ về thực tế."
                    })
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': t_sw_str, 'gio_ra': '',
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'CHO_XAC_NHAN'
                    })
                elif t_sw >= t_out - 120:
                    anomalies.append({
                        'ma_nv': m,
                        'ngay': d,
                        'loai': 'THIEU_VAO',
                        'chi_tiet': f"ra {t_sw_str}, thiếu quẹt vào",
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} có quẹt ra lúc {t_sw_str} nhưng thiếu dữ liệu quẹt vào đầu ca. Cần người quản lý xác nhận giờ đến thực tế."
                    })
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': '', 'gio_ra': t_sw_str,
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'CHO_XAC_NHAN'
                    })
                else:
                    anomalies.append({
                        'ma_nv': m,
                        'ngay': d,
                        'loai': 'THIEU_KHONG_RO',
                        'chi_tiet': f"quẹt lúc {t_sw_str}, không rõ vào hay ra",
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} chỉ quẹt một lần lúc {t_sw_str} giữa ca làm việc, không rõ vào hay ra. Cần người quản lý xác nhận thời gian làm việc thực tế."
                    })
                    bang_cong_rows.append({
                        'ma_nv': m, 'ngay': d, 'loai_ngay': loai_ngay,
                        'gio_vao': '', 'gio_ra': '',
                        'gio_cong': '', 'phut_tre': '', 'phut_ve_som': '', 'ot_phut': '',
                        'trang_thai': 'CHO_XAC_NHAN'
                    })
                continue

            # Two or more swipes
            gio_v_str = kept_swipes[0]['time']
            gio_r_str = kept_swipes[-1]['time']
            t_in_sw = to_min(gio_v_str)
            t_out_sw = to_min(gio_r_str)
            s_in_min = to_min(s_in)
            s_out_min = to_min(s_out)

            # Rule 5.3: phut_tre, phut_ve_som
            diff_tre = t_in_sw - s_in_min
            phut_tre = diff_tre if diff_tre > 5 else 0

            diff_som = s_out_min - t_out_sw
            phut_ve_som = diff_som if diff_som > 5 else 0

            # Rule 4 & 5.4: ot_phut
            diff_ot = t_out_sw - s_out_min
            ot_phut = diff_ot if diff_ot >= 30 else 0

            if phut_tre > 0:
                anomalies.append({
                    'ma_nv': m,
                    'ngay': d,
                    'loai': 'DI_TRE',
                    'chi_tiet': f"vào {gio_v_str}, trễ {phut_tre} phút",
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f"Nhân viên {m} vào ca muộn {phut_tre} phút so với giờ bắt đầu ca {s_in}. Đã ghi nhận số phút trễ vào bảng công theo quy định."
                })

            if phut_ve_som > 0:
                anomalies.append({
                    'ma_nv': m,
                    'ngay': d,
                    'loai': 'VE_SOM',
                    'chi_tiet': f"ra {gio_r_str}, về sớm {phut_ve_som} phút",
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f"Nhân viên {m} ra về sớm {phut_ve_som} phút so với giờ kết thúc ca {s_out}. Đã ghi nhận số phút về sớm vào bảng công theo quy định."
                })

            if ot_phut > 0:
                emp_ot_month[m] += ot_phut
                if ot_phut > 180:
                    anomalies.append({
                        'ma_nv': m,
                        'ngay': d,
                        'loai': 'OT_VUOT_NGUONG',
                        'chi_tiet': f"làm thêm {ot_phut} phút (ra lúc {gio_r_str})",
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} làm thêm {ot_phut} phút trong ngày, vượt ngưỡng 180 phút (3 giờ). Cần quản lý phê duyệt và kiểm tra với văn bản hiện hành hoặc chuyên gia nhân sự."
                    })

            # Rule 5.5: gio_cong
            start_w = s_in_min if t_in_sw <= s_in_min + 5 else t_in_sw
            end_w = s_out_min if t_out_sw >= s_out_min - 5 else t_out_sw
            end_w = min(end_w, s_out_min)

            worked_min = max(0, end_w - start_w)
            if loai_ngay == 'HC':
                lunch_overlap = max(0, min(end_w, 13 * 60) - max(start_w, 12 * 60))
                worked_min -= lunch_overlap

            gio_cong = round(worked_min / 60.0, 2)

            bang_cong_rows.append({
                'ma_nv': m,
                'ngay': d,
                'loai_ngay': loai_ngay,
                'gio_vao': gio_v_str,
                'gio_ra': gio_r_str,
                'gio_cong': f"{gio_cong:.2f}",
                'phut_tre': phut_tre,
                'phut_ve_som': phut_ve_som,
                'ot_phut': ot_phut,
                'trang_thai': 'OK'
            })

    # 4. Check monthly OT threshold > 2400 minutes
    for m in sorted_emps:
        tot_ot = emp_ot_month[m]
        if tot_ot > 2400:
            anomalies.append({
                'ma_nv': m,
                'ngay': 'THANG',
                'loai': 'OT_THANG_VUOT',
                'chi_tiet': f"tổng OT tháng đạt {tot_ot} phút ({tot_ot/60.0:.2f} giờ), vượt ngưỡng 2400 phút",
                'can_nguoi_quyet': 'CO',
                'giai_thich': f"Tổng thời gian làm thêm trong tháng của {m} đạt {tot_ot} phút ({tot_ot/60.0:.2f} giờ), vượt ngưỡng 2400 phút (40 giờ). Cần đối chiếu kế hoạch và kiểm tra với văn bản hiện hành hoặc chuyên gia nhân sự."
            })

    # Sort anomalies by ma_nv, ngay, loai
    # Note: sort ngay handling 'THANG' and empty strings cleanly
    def anom_sort_key(a):
        d_val = a['ngay']
        if d_val == 'THANG':
            d_sort = '9999-99-99'
        elif not d_val:
            d_sort = '0000-00-00'
        else:
            d_sort = d_val
        return (a['ma_nv'], d_sort, a['loai'])

    anomalies.sort(key=anom_sort_key)

    # 5. Write bang_cong_ngay.csv
    bc_fieldnames = ['ma_nv', 'ngay', 'loai_ngay', 'gio_vao', 'gio_ra', 'gio_cong', 'phut_tre', 'phut_ve_som', 'ot_phut', 'trang_thai']
    with open('bang_cong_ngay.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=bc_fieldnames)
        writer.writeheader()
        for row in bang_cong_rows:
            writer.writerow(row)

    # 6. Write bat_thuong.csv
    bt_fieldnames = ['ma_nv', 'ngay', 'loai', 'chi_tiet', 'can_nguoi_quyet', 'giai_thich']
    with open('bat_thuong.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=bt_fieldnames)
        writer.writeheader()
        for row in anomalies:
            writer.writerow(row)

    # 7. Aggregate tong_hop_nguoi.csv
    # Build per-employee stats
    bc_df = pd.DataFrame(bang_cong_rows)
    bt_df = pd.DataFrame(anomalies)

    tong_hop_rows = []
    for m in sorted_emps:
        m_bc = bc_df[bc_df['ma_nv'] == m]
        m_bt = bt_df[bt_df['ma_nv'] == m]

        ok_days = m_bc[m_bc['trang_thai'] == 'OK']
        ngay_cong = len(ok_days)
        tong_gio_cong = sum(float(x) for x in ok_days['gio_cong'] if x != '')

        # so_lan_tre and tong_phut_tre
        tre_records = [int(x) for x in ok_days['phut_tre'] if x != '' and int(x) > 0]
        so_lan_tre = len(tre_records)
        tong_phut_tre = sum(tre_records)

        # so_lan_ve_som and tong_phut_ve_som
        som_records = [int(x) for x in ok_days['phut_ve_som'] if x != '' and int(x) > 0]
        so_lan_ve_som = len(som_records)
        tong_phut_ve_som = sum(som_records)

        # OT
        tong_ot_phut = emp_ot_month[m]
        tong_ot_gio = round(tong_ot_phut / 60.0, 2)

        # Leave
        so_ngay_phep = len(m_bc[m_bc['trang_thai'] == 'PHEP'])

        # Vang chua ghi
        so_ngay_vang = len(m_bt[m_bt['loai'] == 'VANG_CHUA_GHI'])

        # Cho xac nhan
        so_ngay_cxn = len(m_bc[m_bc['trang_thai'] == 'CHO_XAC_NHAN'])

        # Anomalies count
        so_bat_thuong = len(m_bt)

        tong_hop_rows.append({
            'ma_nv': m,
            'ngay_cong': ngay_cong,
            'tong_gio_cong': f"{tong_gio_cong:.2f}",
            'so_lan_tre': so_lan_tre,
            'tong_phut_tre': tong_phut_tre,
            'so_lan_ve_som': so_lan_ve_som,
            'tong_phut_ve_som': tong_phut_ve_som,
            'tong_ot_gio': f"{tong_ot_gio:.2f}",
            'so_ngay_phep': so_ngay_phep,
            'so_ngay_vang_chua_ghi': so_ngay_vang,
            'so_ngay_cho_xac_nhan': so_ngay_cxn,
            'so_bat_thuong': so_bat_thuong
        })

    th_fieldnames = [
        'ma_nv', 'ngay_cong', 'tong_gio_cong',
        'so_lan_tre', 'tong_phut_tre',
        'so_lan_ve_som', 'tong_phut_ve_som',
        'tong_ot_gio', 'so_ngay_phep',
        'so_ngay_vang_chua_ghi', 'so_ngay_cho_xac_nhan',
        'so_bat_thuong'
    ]
    with open('tong_hop_nguoi.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=th_fieldnames)
        writer.writeheader()
        for row in tong_hop_rows:
            writer.writerow(row)

    # 8. Print summary to screen
    print("=== TỔNG KẾT TẠO TỆP ===")
    print(f"bang_cong_ngay.csv: {len(bang_cong_rows) + 1} dòng (gồm 1 dòng tiêu đề, {len(bang_cong_rows)} bản ghi)")
    print(f"bat_thuong.csv: {len(anomalies) + 1} dòng (gồm 1 dòng tiêu đề, {len(anomalies)} bản ghi)")
    print(f"tong_hop_nguoi.csv: {len(tong_hop_rows) + 1} dòng (gồm 1 dòng tiêu đề, {len(tong_hop_rows)} bản ghi)")

    print("\n=== SỐ LƯỢNG BẤT THƯỜNG THEO TỪNG LOẠI ===")
    loai_counts = pd.Series([a['loai'] for a in anomalies]).value_counts()
    for loai, cnt in loai_counts.items():
        print(f"- {loai}: {cnt}")
    print(f"TỔNG CỘNG: {len(anomalies)} bất thường")

if __name__ == '__main__':
    main()
