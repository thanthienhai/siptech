"""Tự kiểm đầu ra của agent KHÔNG cần đáp án (dùng được với dữ liệu thật của quán).

Dùng:  python -X utf8 kiem-tra-dau-ra.py <thu_muc_co_danh-gia.csv> [thu_muc_dau_ra]
  - thu_muc_co_danh-gia.csv: nơi có danh-gia.csv (thư mục agent làm việc, hoặc ../du-lieu)
  - thu_muc_dau_ra: mặc định <thu_muc>/dau-ra
Kiểm: (1) đủ file, đúng cột; (2) chủ đề/sắc thái hợp lệ; (3) mọi trích dẫn có NGUYÊN VĂN trong đúng bài;
(4) bài chưa loại bỏ đều có ít nhất 1 ý kiến; (5) xu-huong-tuan.csv trùng số đếm lại từ y-kien.csv;
(6) báo cáo có đúng 5 mục "## Việc" và mỗi mục 2-3 trích dẫn; (7) liệt kê bài CAN_NGUOI_DOC để người đọc.
Thoát mã 1 nếu có lỗi. Không đánh giá việc gán nhãn đúng hay sai (cần người hoặc đáp án).
"""
import csv, re, sys, unicodedata, datetime as dt
from collections import Counter, defaultdict
from pathlib import Path

nfc = lambda s: unicodedata.normalize("NFC", s or "")
TOPICS = {"gia", "phuc_vu", "chat_luong", "giao_hang", "khong_gian", "ve_sinh", "khac"}
SENTS = {"tich_cuc", "tieu_cuc", "trung_tinh", "CAN_NGUOI_DOC"}
LOAI = {"ngo_doc", "thai_do", "lua_dao"}

def read(p, cols, errs):
    if not p.exists(): errs.append(f"thiếu {p.name}"); return []
    rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
    if rows and not set(cols) <= set(rows[0]): errs.append(f"{p.name}: thiếu cột {sorted(set(cols) - set(rows[0]))}")
    return rows

def tuan_cua(s):
    s = s.strip()
    d = dt.datetime.strptime(s, "%d/%m/%Y").date() if "/" in s else dt.date.fromisoformat(s)
    return (d - dt.timedelta(days=d.weekday())).isoformat()

def main():
    base = Path(sys.argv[1]); out = Path(sys.argv[2]) if len(sys.argv) > 2 else base / "dau-ra"
    errs = []
    dg = {r["ma"]: r for r in csv.DictReader(open(base / "danh-gia.csv", encoding="utf-8-sig"))}
    lb = read(out / "loai-bo.csv", ["ma", "ly_do"], errs); yk = read(out / "y-kien.csv", ["ma", "chu_de", "sac_thai", "trich_dan"], errs)
    nc = read(out / "nguy-cap.csv", ["ma", "loai", "trich_dan"], errs); xh = read(out / "xu-huong-tuan.csv", ["tuan", "chu_de", "tich_cuc", "tieu_cuc", "trung_tinh", "can_nguoi_doc"], errs)
    loai = {r["ma"].strip() for r in lb}
    for r in lb:
        if r["ma"].strip() not in dg: errs.append(f"loai-bo: mã lạ {r['ma']}")
    # y-kien
    has = set(); n_bad_q = 0
    for i, r in enumerate(yk, 2):
        m = r["ma"].strip()
        if m not in dg: errs.append(f"y-kien dòng {i}: mã lạ {m}"); continue
        if m in loai: errs.append(f"y-kien dòng {i}: {m} đã bị loại bỏ mà vẫn có ý kiến")
        if r["chu_de"].strip() not in TOPICS: errs.append(f"y-kien dòng {i}: chu_de lạ '{r['chu_de']}'")
        if r["sac_thai"].strip() not in SENTS: errs.append(f"y-kien dòng {i}: sac_thai lạ '{r['sac_thai']}'")
        if not r["trich_dan"] or nfc(r["trich_dan"]) not in nfc(dg[m]["noi_dung"]):
            n_bad_q += 1; errs.append(f"y-kien dòng {i}: trích dẫn không nguyên văn [{m}] '{r['trich_dan'][:60]}'")
        has.add(m)
    thieu = [m for m in dg if m not in loai and m not in has]
    if thieu: errs.append(f"{len(thieu)} bài chưa có ý kiến nào và chưa bị loại bỏ: {thieu[:10]}")
    for i, r in enumerate(nc, 2):
        m = r["ma"].strip()
        if r["loai"].strip() not in LOAI: errs.append(f"nguy-cap dòng {i}: loai lạ '{r['loai']}'")
        if m not in dg or not r["trich_dan"] or nfc(r["trich_dan"]) not in nfc(dg[m]["noi_dung"]): errs.append(f"nguy-cap dòng {i}: trích dẫn không nguyên văn [{m}]")
    # đếm lại
    cnt = defaultdict(Counter)
    for r in yk:
        m = r["ma"].strip()
        if m in dg and m not in loai:
            cnt[(tuan_cua(dg[m]["ngay"]), r["chu_de"].strip())]["can_nguoi_doc" if r["sac_thai"].strip() == "CAN_NGUOI_DOC" else r["sac_thai"].strip()] += 1
    ag = {(r["tuan"].strip(), r["chu_de"].strip()): {c: int(r.get(c) or 0) for c in ("tich_cuc", "tieu_cuc", "trung_tinh", "can_nguoi_doc")} for r in xh}
    n_lech = 0
    for k in set(cnt) | set(ag):
        for c in ("tich_cuc", "tieu_cuc", "trung_tinh", "can_nguoi_doc"):
            a, b = ag.get(k, {}).get(c, 0), cnt.get(k, Counter()).get(c, 0)
            if a != b: n_lech += 1; errs.append(f"xu-huong {k} {c}: file ghi {a}, đếm lại {b}")
    # báo cáo
    p = out / "bao-cao.md"
    if not p.exists(): errs.append("thiếu bao-cao.md")
    else:
        bc = p.read_text(encoding="utf-8"); parts = re.split(r"^##\s*Việc\s*\d+", bc, flags=re.M)[1:]
        if len(parts) != 5: errs.append(f"bao-cao.md có {len(parts)} mục 'Việc', cần đúng 5")
        for j, it in enumerate(parts, 1):
            qs = re.findall(r'^\s*>\s*\[?(R\d+)\]?\s*[:\-]?\s*["“«]?(.+?)["”»]?\s*$', it, flags=re.M)
            if not 2 <= len(qs) <= 3: errs.append(f"Việc {j}: có {len(qs)} trích dẫn, cần 2-3")
            for m, q in qs:
                if m not in dg or nfc(q) not in nfc(dg[m]["noi_dung"]): errs.append(f"Việc {j}: trích dẫn không nguyên văn [{m}] '{q[:60]}'")
    cnd = sorted({r["ma"].strip() for r in yk if r["sac_thai"].strip() == "CAN_NGUOI_DOC"})
    print(f"bài: {len(dg)} | loại bỏ: {len(loai)} | ý kiến: {len(yk)} | nguy cấp: {len(nc)} | ô xu hướng: {len(ag)}")
    print(f"CẦN NGƯỜI ĐỌC ({len(cnd)} bài): {', '.join(cnd)}")
    for m in cnd: print(f"   {m}: {dg[m]['noi_dung'][:110]}")
    print("KẾT QUẢ:", "QUA" if not errs else f"CÓ {len(errs)} LỖI")
    for e in errs[:40]: print(" -", e)
    sys.exit(1 if errs else 0)

if __name__ == "__main__":
    main()
