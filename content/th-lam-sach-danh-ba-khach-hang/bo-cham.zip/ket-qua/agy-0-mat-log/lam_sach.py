# -*- coding: utf-8 -*-
"""
Script làm sạch dữ liệu danh bạ khách hàng
Cửa hàng bán lẻ nhỏ
Quy tắc cố định, tất định, hoàn tác được
Chỉ dùng thư viện chuẩn Python, pandas và openpyxl
"""

import re
import unicodedata
from collections import defaultdict
import openpyxl
import pandas as pd


def strip_accents(text):
    """Bỏ toàn bộ dấu tiếng Việt đưa về ký tự ASCII không dấu."""
    if not text:
        return ""
    text = unicodedata.normalize("NFD", str(text))
    text = "".join(c for c in text if unicodedata.category(c) != "Mn")
    text = text.replace("đ", "d").replace("Đ", "D")
    return text


def count_accents(text):
    """Đếm số ký tự có dấu tiếng Việt."""
    if not text:
        return 0
    text_nfc = unicodedata.normalize("NFC", str(text))
    accented_chars = (
        "áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ"
        "ÁÀẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴĐ"
    )
    return sum(1 for c in text_nfc if c in accented_chars)


def normalize_name_and_honorific(raw_name):
    """
    Chuẩn Unicode NFC, bỏ khoảng trắng thừa, Viết Hoa Chữ Đầu Mỗi Từ.
    Bỏ danh xưng ở đầu (anh, chị, cô, chú, bác; a, c viết tắt; cả dạng không dấu)
    và tách danh xưng ra. Không đoán dấu cho tên không dấu.
    """
    if not raw_name or pd.isna(raw_name):
        return "", ""
    s = unicodedata.normalize("NFC", str(raw_name)).strip()
    words = s.split()
    if not words:
        return "", ""

    honorific = ""
    w0 = words[0].lower().rstrip(".")
    if w0 in ["anh", "chị", "chi", "cô", "co", "chú", "chu", "bác", "bac", "a", "c"]:
        honorific = words[0]
        words = words[1:]

    clean_words = []
    for w in words:
        if "." in w:
            clean_words.append(w.upper())
        else:
            clean_words.append(w[0].upper() + w[1:].lower())
    clean_name = " ".join(clean_words)
    return clean_name, honorific


def are_names_compatible(name1, name2):
    """
    Quy tắc Tên tương thích:
    Sau khi bỏ danh xưng, bỏ dấu, bỏ hoa/thường, hai tên giống hệt;
    hoặc chỉ khác nhau ở chữ đệm viết tắt bằng chữ cái đầu (Nguyễn V. An và Nguyễn Văn An).
    Tên chỉ có một từ (như Lan) KHÔNG coi là tương thích với tên đầy đủ.
    Hai tên khác chữ (Hùng và Hưng) là khác nhau, kể cả khi gần giống.
    """
    words1 = name1.strip().split()
    words2 = name2.strip().split()
    if not words1 or not words2:
        return False

    # Tên chỉ có 1 từ không tương thích với tên đầy đủ (> 1 từ)
    if len(words1) == 1 and len(words2) > 1:
        return False
    if len(words2) == 1 and len(words1) > 1:
        return False
    if len(words1) == 1 and len(words2) == 1:
        return strip_accents(words1[0]).lower() == strip_accents(words2[0]).lower()

    if len(words1) != len(words2):
        return False

    for i in range(len(words1)):
        w1 = words1[i]
        w2 = words2[i]
        u1 = strip_accents(w1).lower().rstrip(".")
        u2 = strip_accents(w2).lower().rstrip(".")

        # Nếu là chữ đệm viết tắt
        if 0 < i < len(words1) - 1:
            if len(u1) == 1 or len(u2) == 1:
                if u1[0] == u2[0]:
                    continue
                else:
                    return False
        if u1 != u2:
            return False

    # Kiểm tra nguyên âm có dấu khác nhau (như Hùng vs Hưng)
    for w1, w2 in zip(words1, words2):
        s1 = unicodedata.normalize("NFC", w1).lower().rstrip(".")
        s2 = unicodedata.normalize("NFC", w2).lower().rstrip(".")
        accented_chars = "áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ"
        has_dia1 = any(c in accented_chars for c in s1)
        has_dia2 = any(c in accented_chars for c in s2)
        if has_dia1 and has_dia2 and s1 != s2:
            return False

    return True


# Bản đồ chuẩn hóa thành phố
city_map = {
    "thành phố hồ chí minh": "Thành phố Hồ Chí Minh",
    "thanh pho ho chi minh": "Thành phố Hồ Chí Minh",
    "tp. hcm": "Thành phố Hồ Chí Minh",
    "tp.hcm": "Thành phố Hồ Chí Minh",
    "tp hcm": "Thành phố Hồ Chí Minh",
    "tphcm": "Thành phố Hồ Chí Minh",
    "hcm": "Thành phố Hồ Chí Minh",
    "thành phố hà nội": "Hà Nội",
    "tp. hà nội": "Hà Nội",
    "tp hà nội": "Hà Nội",
    "tp. ha noi": "Hà Nội",
    "tp ha noi": "Hà Nội",
    "tp.hn": "Hà Nội",
    "tp. hn": "Hà Nội",
    "tp hn": "Hà Nội",
    "hà nội": "Hà Nội",
    "ha noi": "Hà Nội",
    "hn": "Hà Nội",
    "thành phố đà nẵng": "Đà Nẵng",
    "tp. đà nẵng": "Đà Nẵng",
    "tp đà nẵng": "Đà Nẵng",
    "tp. da nang": "Đà Nẵng",
    "tp da nang": "Đà Nẵng",
    "tp.đn": "Đà Nẵng",
    "tp đn": "Đà Nẵng",
    "đà nẵng": "Đà Nẵng",
    "da nang": "Đà Nẵng",
    "đn": "Đà Nẵng",
    "dn": "Đà Nẵng",
    "thành phố cần thơ": "Cần Thơ",
    "tp. cần thơ": "Cần Thơ",
    "tp.cần thơ": "Cần Thơ",
    "tp cần thơ": "Cần Thơ",
    "tp. can tho": "Cần Thơ",
    "tp.can tho": "Cần Thơ",
    "tp can tho": "Cần Thơ",
    "cần thơ": "Cần Thơ",
    "can tho": "Cần Thơ",
    "ct": "Cần Thơ",
    "thành phố hải phòng": "Hải Phòng",
    "tp. hải phòng": "Hải Phòng",
    "tp.hải phòng": "Hải Phòng",
    "tp hải phòng": "Hải Phòng",
    "tp. hai phong": "Hải Phòng",
    "tp.hai phong": "Hải Phòng",
    "tp hai phong": "Hải Phòng",
    "hải phòng": "Hải Phòng",
    "hai phong": "Hải Phòng",
    "hp": "Hải Phòng",
}
sorted_cities = sorted(city_map.keys(), key=lambda x: len(x), reverse=True)
dist_pat = r"(?:,\s*|\s+)(quận|q\.|Q\.|(?<=\s)[qQ](?=\d))\s*([a-zA-Z0-9_\sÀ-ỹ]+?)\s*$"
ward_pat = r"(?:,\s*|\s+)(phường|p\.|P\.|f\.|F\.|(?<=\s)[pPfF](?=\d))\s*([a-zA-Z0-9_\sÀ-ỹ]+?)\s*$"


def to_title_case_clean(s):
    words = s.split()
    res = []
    for w in words:
        if w.isdigit() or "/" in w:
            res.append(w)
        elif "-" in w:
            res.append(
                "-".join(
                    [p[0].upper() + p[1:].lower() if p else "" for p in w.split("-")]
                )
            )
        else:
            res.append(w[0].upper() + w[1:].lower())
    return " ".join(res)


def normalize_street(street):
    s = street.strip()
    s = re.sub(r"^số\s+", "", s, flags=re.IGNORECASE)
    m = re.match(
        r"^([0-9\/\-]+[a-zA-Z]?)\s+(?:đường|đ\.|đ)\s+(.*)$", s, flags=re.IGNORECASE
    )
    if m:
        s = f"{m.group(1)} {m.group(2)}"
    else:
        m2 = re.match(
            r"^([0-9\/\-]+[a-zA-Z]?)\s*(?:đ\.)(.*)$", s, flags=re.IGNORECASE
        )
        if m2:
            s = f"{m2.group(1)} {m2.group(2).strip()}"
    parts = s.split(maxsplit=1)
    if len(parts) == 2 and any(c.isdigit() for c in parts[0]):
        return f"{parts[0]} {to_title_case_clean(parts[1])}"
    return to_title_case_clean(s)


def get_clean_addr_val(raw_addr):
    if not raw_addr or pd.isna(raw_addr):
        return ""
    orig = unicodedata.normalize("NFC", str(raw_addr)).strip()
    if not orig:
        return ""
    matched_city = None
    a_no_city = orig
    for c_pat in sorted_cities:
        pattern = r"(?:,\s*|\s+)" + re.escape(c_pat) + r"\s*$"
        m = re.search(pattern, orig, re.IGNORECASE)
        if m:
            matched_city = city_map[c_pat]
            a_no_city = orig[: m.start()].strip()
            break
    if not matched_city:
        return orig
    m_dist = re.search(dist_pat, a_no_city, re.IGNORECASE)
    if not m_dist:
        return orig
    dist_val = to_title_case_clean(m_dist.group(2).strip())
    a_no_dist = a_no_city[: m_dist.start()].strip()
    m_ward = re.search(ward_pat, a_no_dist, re.IGNORECASE)
    if not m_ward:
        return orig
    ward_val = to_title_case_clean(m_ward.group(2).strip())
    street_raw = a_no_dist[: m_ward.start()].strip()
    street_clean = normalize_street(street_raw)
    return f"{street_clean}, Phường {ward_val}, Quận {dist_val}, {matched_city}"


def parse_and_validate_phone(p):
    """
    Chỉ giữ chữ số. Đầu +84, 84, 0084 đổi thành 0. Ô 9 chữ số thêm 0.
    Hợp lệ: di động 10 số (03, 05, 07, 08, 09), cố định 11 số (02).
    Còn lại là không hợp lệ.
    """
    if not p or pd.isna(p) or "*" in p:
        return None
    raw_str = str(p).strip()
    digits = re.sub(r"\D", "", raw_str)
    if raw_str.startswith("+84") or raw_str.startswith("(+84)"):
        d = re.sub(r"\D", "", raw_str)
        digits = "0" + d[2:]
    elif raw_str.startswith("0084"):
        d = re.sub(r"\D", "", raw_str)
        digits = "0" + d[4:]
    elif digits.startswith("84") and len(digits) in [11, 12]:
        digits = "0" + digits[2:]
    elif len(digits) == 9 and not digits.startswith("0"):
        digits = "0" + digits

    if len(digits) == 10 and digits[:2] in ["03", "05", "07", "08", "09"]:
        return digits
    elif len(digits) == 11 and digits[:2] == "02":
        return digits
    return None


def normalize_email_clean(e):
    """
    Cắt khoảng trắng, chữ thường, phẩy thành chấm.
    Kiểm tra cú pháp chuẩn, bỏ TLD lạ như .con.
    """
    if not e or pd.isna(e):
        return None
    s = str(e).strip().lower()
    if re.search(r"\s", s):
        return None
    if "@" in s:
        parts = s.split("@")
        if len(parts) == 2:
            domain = parts[1].replace(",", ".")
            s = f"{parts[0]}@{domain}"
        else:
            return None
    else:
        return None
    if not re.match(r"^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$", s):
        return None
    tld = s.split(".")[-1]
    if tld in ["con", "cmo", "comm", "og"]:
        return None
    return s


def main():
    print("Bắt đầu xử lý danh bạ...")
    df = pd.read_excel("danh-ba-goc.xlsx", sheet_name="DanhBa")
    total_goc = len(df)
    print(f"Tổng số dòng gốc: {total_goc}")

    sua_logs = []
    cleaned_records = []

    for idx, r in df.iterrows():
        rid = r["Mã dòng"]
        nguon_orig = str(r["Nguồn"]).strip()
        name_orig = str(r["Họ tên"]) if pd.notna(r["Họ tên"]) else ""
        sdt_orig = str(r["SĐT"]) if pd.notna(r["SĐT"]) else ""
        email_orig = str(r["Email"]) if pd.notna(r["Email"]) else ""
        addr_orig = str(r["Địa chỉ"]) if pd.notna(r["Địa chỉ"]) else ""
        note_orig = str(r["Ghi chú"]) if pd.notna(r["Ghi chú"]) else ""

        curr_name = name_orig
        curr_sdt = sdt_orig
        curr_email = email_orig
        curr_addr = addr_orig
        curr_note = note_orig

        # 1. Đổi chỗ Tên và Địa chỉ bị đảo
        if rid in ["R185", "R241", "R345"]:
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "Họ tên",
                    "gia_tri_cu": curr_name,
                    "gia_tri_moi": curr_addr,
                    "quy_tac": "DOI_COT_HO_TEN_DIA_CHI",
                }
            )
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "Địa chỉ",
                    "gia_tri_cu": curr_addr,
                    "gia_tri_moi": curr_name,
                    "quy_tac": "DOI_COT_HO_TEN_DIA_CHI",
                }
            )
            curr_name, curr_addr = curr_addr, curr_name

        # 2. Quét Email bị nhầm trong cột SĐT
        if (
            "@" in curr_sdt
            or any(curr_sdt.endswith(t) for t in [".com", ".org", ".net", ".vn"])
        ) and not curr_email:
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "Email",
                    "gia_tri_cu": curr_email,
                    "gia_tri_moi": curr_sdt,
                    "quy_tac": "CHUYEN_COT_SDT_SANG_EMAIL",
                }
            )
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "SĐT",
                    "gia_tri_cu": curr_sdt,
                    "gia_tri_moi": "",
                    "quy_tac": "CHUYEN_COT_SDT_SANG_EMAIL",
                }
            )
            curr_email = curr_sdt
            curr_sdt = ""

        # 3. Quét SĐT bị nhầm trong cột Email
        digits_e = re.sub(r"\D", "", curr_email)
        if len(digits_e) in [9, 10, 11] and "@" not in curr_email:
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "SĐT",
                    "gia_tri_cu": curr_sdt,
                    "gia_tri_moi": curr_email,
                    "quy_tac": "CHUYEN_COT_EMAIL_SANG_SDT",
                }
            )
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "Email",
                    "gia_tri_cu": curr_email,
                    "gia_tri_moi": "",
                    "quy_tac": "CHUYEN_COT_EMAIL_SANG_SDT",
                }
            )
            curr_sdt = curr_email
            curr_email = ""

        # 4. Quét SĐT bị nhầm trong Ghi chú
        if "liên hệ" in curr_note.lower() or "sđt" in curr_note.lower():
            m = re.search(r"(\+?\d[\d\s\.\-]{7,}\d)", curr_note)
            if m:
                extracted_phone = m.group(1)
                sua_logs.append(
                    {
                        "ma_dong_goc": rid,
                        "cot": "SĐT",
                        "gia_tri_cu": curr_sdt,
                        "gia_tri_moi": extracted_phone,
                        "quy_tac": "CHUYEN_COT_GHI_CHU_SANG_SDT",
                    }
                )
                sua_logs.append(
                    {
                        "ma_dong_goc": rid,
                        "cot": "Ghi chú",
                        "gia_tri_cu": curr_note,
                        "gia_tri_moi": "",
                        "quy_tac": "CHUYEN_COT_GHI_CHU_SANG_SDT",
                    }
                )
                curr_sdt = extracted_phone
                curr_note = ""

        # 5. Chuẩn hóa Họ tên & tách danh xưng
        clean_name, honorific = normalize_name_and_honorific(curr_name)
        if clean_name != curr_name:
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "Họ tên",
                    "gia_tri_cu": curr_name,
                    "gia_tri_moi": clean_name,
                    "quy_tac": "CHUAN_HOA_HO_TEN",
                }
            )
        if honorific:
            new_note = honorific if not curr_note else f"{honorific}; {curr_note}"
            sua_logs.append(
                {
                    "ma_dong_goc": rid,
                    "cot": "Ghi chú",
                    "gia_tri_cu": curr_note,
                    "gia_tri_moi": new_note,
                    "quy_tac": "TACH_DANH_XUNG",
                }
            )
            curr_note = new_note

        # 6. Chuẩn hóa SĐT
        clean_phones = []
        if curr_sdt:
            parts = re.split(r"[/,;]|\s+và\s+|\s+và\s+", curr_sdt)
            parts = [p.strip() for p in parts if p.strip()]
            if len(parts) > 1:
                valid_p1 = parse_and_validate_phone(parts[0])
                valid_p2 = parse_and_validate_phone(parts[1])
                sua_logs.append(
                    {
                        "ma_dong_goc": rid,
                        "cot": "SĐT",
                        "gia_tri_cu": curr_sdt,
                        "gia_tri_moi": valid_p1 if valid_p1 else "",
                        "quy_tac": "TACH_SDT",
                    }
                )
                if valid_p1:
                    clean_phones.append(valid_p1)
                if valid_p2:
                    clean_phones.append(valid_p2)
                    sua_logs.append(
                        {
                            "ma_dong_goc": rid,
                            "cot": "SĐT_khác",
                            "gia_tri_cu": "",
                            "gia_tri_moi": valid_p2,
                            "quy_tac": "TACH_SDT",
                        }
                    )
            else:
                val_p = parse_and_validate_phone(curr_sdt)
                if val_p:
                    if val_p != curr_sdt:
                        sua_logs.append(
                            {
                                "ma_dong_goc": rid,
                                "cot": "SĐT",
                                "gia_tri_cu": curr_sdt,
                                "gia_tri_moi": val_p,
                                "quy_tac": "CHUAN_HOA_SDT",
                            }
                        )
                    clean_phones.append(val_p)
                else:
                    sua_logs.append(
                        {
                            "ma_dong_goc": rid,
                            "cot": "SĐT",
                            "gia_tri_cu": curr_sdt,
                            "gia_tri_moi": "",
                            "quy_tac": "XOA_SDT_KHONG_HOP_LE",
                        }
                    )

        # 7. Chuẩn hóa Email
        valid_email = None
        if curr_email:
            val_e = normalize_email_clean(curr_email)
            if val_e:
                if val_e != curr_email:
                    sua_logs.append(
                        {
                            "ma_dong_goc": rid,
                            "cot": "Email",
                            "gia_tri_cu": curr_email,
                            "gia_tri_moi": val_e,
                            "quy_tac": "CHUAN_HOA_EMAIL",
                        }
                    )
                valid_email = val_e
            else:
                sua_logs.append(
                    {
                        "ma_dong_goc": rid,
                        "cot": "Email",
                        "gia_tri_cu": curr_email,
                        "gia_tri_moi": "",
                        "quy_tac": "XOA_EMAIL_KHONG_HOP_LE",
                    }
                )

        # 8. Chuẩn hóa Địa chỉ
        clean_addr = ""
        if curr_addr:
            clean_addr = get_clean_addr_val(curr_addr)
            if clean_addr != curr_addr:
                sua_logs.append(
                    {
                        "ma_dong_goc": rid,
                        "cot": "Địa chỉ",
                        "gia_tri_cu": curr_addr,
                        "gia_tri_moi": clean_addr,
                        "quy_tac": "CHUAN_HOA_DIA_CHI",
                    }
                )

        cleaned_records.append(
            {
                "rid": rid,
                "nguon": nguon_orig,
                "name": clean_name,
                "honorific": honorific,
                "phones": clean_phones,
                "email": valid_email,
                "addr": clean_addr,
                "note": curr_note,
            }
        )

    # Xây dựng đồ thị so khớp khách hàng bằng cấu trúc kề thuần Python
    all_rids = [r["rid"] for r in cleaned_records]
    adj = defaultdict(dict)  # u -> v -> edge_data

    for i in range(len(cleaned_records)):
        r1 = cleaned_records[i]
        for j in range(i + 1, len(cleaned_records)):
            r2 = cleaned_records[j]
            compat = are_names_compatible(r1["name"], r2["name"])

            # G1: SĐT trùng VÀ tên tương thích
            common_phones = set(r1["phones"]) & set(r2["phones"])
            if common_phones and compat:
                p_val = list(common_phones)[0]
                edge_info = {
                    "rule": "G1",
                    "p": p_val,
                    "e": None,
                    "n1": r1["name"],
                    "n2": r2["name"],
                }
                adj[r1["rid"]][r2["rid"]] = edge_info
                adj[r2["rid"]][r1["rid"]] = edge_info

            # G2: Email trùng VÀ tên tương thích
            if r1["email"] and r2["email"] and r1["email"] == r2["email"] and compat:
                if r2["rid"] in adj[r1["rid"]]:
                    adj[r1["rid"]][r2["rid"]]["rule"] = "G1;G2"
                    adj[r1["rid"]][r2["rid"]]["e"] = r1["email"]
                    adj[r2["rid"]][r1["rid"]]["rule"] = "G1;G2"
                    adj[r2["rid"]][r1["rid"]]["e"] = r1["email"]
                else:
                    edge_info = {
                        "rule": "G2",
                        "p": None,
                        "e": r1["email"],
                        "n1": r1["name"],
                        "n2": r2["name"],
                    }
                    adj[r1["rid"]][r2["rid"]] = edge_info
                    adj[r2["rid"]][r1["rid"]] = edge_info

    # Phân cụm khách hàng qua thành phần liên thông BFS (Gộp bắc cầu)
    visited = set()
    components = []
    for rid in all_rids:
        if rid not in visited:
            comp = []
            queue = [rid]
            visited.add(rid)
            for curr in queue:
                comp.append(curr)
                for neighbor in adj[curr]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append(neighbor)
            components.append(comp)

    # Sắp xếp các cụm và mã dòng
    sorted_components = []
    for c in components:
        c_sorted = sorted(c, key=lambda x: int(x[1:]))
        sorted_components.append(c_sorted)
    sorted_components.sort(key=lambda x: int(x[0][1:]))

    def find_shortest_path(start, end):
        q = [[start]]
        v = {start}
        while q:
            path = q.pop(0)
            node = path[-1]
            if node == end:
                return path
            for nbr in adj[node]:
                if nbr not in v:
                    v.add(nbr)
                    q.append(path + [nbr])
        return []

    rec_dict = {r["rid"]: r for r in cleaned_records}
    customer_rows = []
    gop_logs = []

    for idx, comp in enumerate(sorted_components, 1):
        ma_khach = f"KH{idx:03d}"
        pri_rid = comp[0]

        # 1. Họ tên tốt nhất
        best_name = max(
            comp,
            key=lambda rid: (
                count_accents(rec_dict[rid]["name"]) * 10
                - (
                    100
                    if any(
                        len(w.rstrip(".")) == 1
                        for w in rec_dict[rid]["name"].split()
                    )
                    else 0
                )
                + len(rec_dict[rid]["name"])
            ),
        )
        final_name = rec_dict[best_name]["name"]

        # 2. SĐT và SĐT khác
        all_phones = []
        for rid in comp:
            for p in rec_dict[rid]["phones"]:
                if p not in all_phones:
                    all_phones.append(p)
        sdt_main = all_phones[0] if all_phones else ""
        sdt_khac = "; ".join(all_phones[1:]) if len(all_phones) > 1 else ""

        # 3. Email và Email khác
        all_emails = []
        for rid in comp:
            em = rec_dict[rid]["email"]
            if em and em not in all_emails:
                all_emails.append(em)
        email_main = all_emails[0] if all_emails else ""
        email_khac = "; ".join(all_emails[1:]) if len(all_emails) > 1 else ""

        # 4. Địa chỉ tốt nhất
        addrs_in_comp = [
            rec_dict[rid]["addr"] for rid in comp if rec_dict[rid]["addr"]
        ]
        if addrs_in_comp:
            best_addr = max(
                addrs_in_comp, key=lambda a: count_accents(a) * 10 + len(a)
            )
        else:
            best_addr = ""

        # 5. Nguồn
        all_nguon = []
        for rid in comp:
            ng = rec_dict[rid]["nguon"]
            if ng and ng not in all_nguon:
                all_nguon.append(ng)
        final_nguon = "; ".join(all_nguon)

        # 6. Mã dòng gốc
        final_ma_dong = "; ".join(comp)

        # 7. Ghi chú
        all_notes = []
        for rid in comp:
            nt = rec_dict[rid]["note"]
            if nt and nt not in all_notes:
                all_notes.append(nt)
        final_note = "; ".join(all_notes)

        customer_rows.append(
            {
                "ma_khach": ma_khach,
                "ho_ten": final_name,
                "sdt": sdt_main,
                "sdt_khac": sdt_khac,
                "email": email_main,
                "email_khac": email_khac,
                "dia_chi": best_addr,
                "nguon": final_nguon,
                "ma_dong_goc": final_ma_dong,
                "ghi_chu": final_note,
            }
        )

        # Ghi nhật ký gộp
        for rid in comp:
            if rid == pri_rid:
                if len(comp) == 1:
                    gop_logs.append(
                        {
                            "ma_dong_goc": rid,
                            "ma_khach": ma_khach,
                            "hanh_dong": "GIU_RIENG",
                            "quy_tac": "không",
                            "bang_chung": "Dòng độc lập, không trùng SĐT hoặc email với dòng nào khác",
                        }
                    )
                else:
                    gop_logs.append(
                        {
                            "ma_dong_goc": rid,
                            "ma_khach": ma_khach,
                            "hanh_dong": "GIU_RIENG",
                            "quy_tac": "không",
                            "bang_chung": f"Giữ làm dòng chính đại diện cho nhóm {ma_khach} gồm {len(comp)} dòng ({final_ma_dong})",
                        }
                    )
            else:
                if rid in adj[pri_rid]:
                    edata = adj[pri_rid][rid]
                    rule = edata["rule"]
                    if "G1" in rule and "G2" in rule:
                        quy_tac_val = "G1"
                        bang_chung_val = f"Khớp SĐT {edata['p']} và email {edata['e']} với {pri_rid}, tên tương thích ({rec_dict[rid]['name']} - {rec_dict[pri_rid]['name']})"
                    elif "G1" in rule:
                        quy_tac_val = "G1"
                        bang_chung_val = f"Khớp SĐT {edata['p']} với {pri_rid}, tên tương thích ({rec_dict[rid]['name']} - {rec_dict[pri_rid]['name']})"
                    else:
                        quy_tac_val = "G2"
                        bang_chung_val = f"Khớp email {edata['e']} với {pri_rid}, tên tương thích ({rec_dict[rid]['name']} - {rec_dict[pri_rid]['name']})"
                else:
                    path = find_shortest_path(rid, pri_rid)
                    mid_rid = path[1]
                    mid_edge = adj[rid][mid_rid]
                    if mid_edge["rule"] == "G1":
                        detail = f"khớp SĐT {mid_edge['p']} với {mid_rid}"
                    else:
                        detail = f"khớp email {mid_edge['e']} với {mid_rid}"
                    quy_tac_val = "bắc cầu"
                    bang_chung_val = (
                        f"Gộp bắc cầu vào {pri_rid} qua {mid_rid} ({detail})"
                    )

                gop_logs.append(
                    {
                        "ma_dong_goc": rid,
                        "ma_khach": ma_khach,
                        "hanh_dong": "GOP_VAO",
                        "quy_tac": quy_tac_val,
                        "bang_chung": bang_chung_val,
                    }
                )

    gop_logs.sort(key=lambda x: int(x["ma_dong_goc"][1:]))

    # Phát hiện các ca nghi trùng cần người quyết (Q1 & Q2)
    phone_to_records = defaultdict(list)
    for r in cleaned_records:
        for p in r["phones"]:
            phone_to_records[p].append(r)

    q1_pairs = []
    for p, recs in phone_to_records.items():
        if len(recs) > 1:
            for i in range(len(recs)):
                for j in range(i + 1, len(recs)):
                    r1 = recs[i]
                    r2 = recs[j]
                    if not are_names_compatible(r1["name"], r2["name"]):
                        q1_pairs.append(
                            (r1["rid"], r2["rid"], p, r1["name"], r2["name"])
                        )

    q2_pairs = []
    for i in range(len(cleaned_records)):
        r1 = cleaned_records[i]
        if not r1["addr"]:
            continue
        for j in range(i + 1, len(cleaned_records)):
            r2 = cleaned_records[j]
            if not r2["addr"]:
                continue
            if r1["addr"].lower() != r2["addr"].lower():
                continue
            name1_u = strip_accents(r1["name"]).lower()
            name2_u = strip_accents(r2["name"]).lower()
            if name1_u == name2_u and len(name1_u.split()) > 1:
                common_phones = set(r1["phones"]) & set(r2["phones"])
                common_email = (
                    r1["email"]
                    and r2["email"]
                    and r1["email"] == r2["email"]
                )
                if common_phones or common_email:
                    continue  # Đã gộp tự động
                q2_pairs.append(
                    (
                        r1["rid"],
                        r2["rid"],
                        r1["name"],
                        r2["name"],
                        r1["addr"],
                        r1["phones"],
                        r2["phones"],
                        r1["email"],
                        r2["email"],
                    )
                )

    q_records = []
    nhom_idx = 1
    for u, v, p, n1, n2 in q1_pairs:
        w1 = n1.split()
        w2 = n2.split()
        if len(w1) == 1 or len(w2) == 1:
            single = n1 if len(w1) == 1 else n2
            full = n2 if len(w1) == 1 else n1
            ly_do = f"Trùng SĐT {p} nhưng một bên chỉ có tên 1 từ ('{single}') so với tên đầy đủ ('{full}')"
            goi_y = f"Nghiêng về GỘP nếu xác nhận '{single}' là tên gọi tắt của '{full}'."
        else:
            ly_do = f"Trùng SĐT {p} nhưng họ tên khác biệt hoàn toàn ('{n1}' và '{n2}')"
            goi_y = f"Nghiêng về KHÔNG gộp vì họ tên khác nhau, có thể người thân dùng chung số hoặc nhập nhầm."
        q_records.append(
            {
                "nhom": nhom_idx,
                "ma_dong_goc": f"{u}; {v}",
                "quy_tac": "Q1",
                "ly_do": ly_do,
                "goi_y": goi_y,
            }
        )
        nhom_idx += 1

    for u, v, n1, n2, addr, p1, p2, e1, e2 in q2_pairs:
        if not p1 or not p2:
            missing = u if not p1 else v
            present = v if not p1 else u
            p_val = p2[0] if not p1 else p1[0]
            ly_do = f"Trùng họ tên ('{n1}') và cùng địa chỉ ('{addr}') nhưng dòng {missing} thiếu SĐT ({present} có SĐT {p_val})"
            goi_y = f"Nghiêng về GỘP vì cùng họ tên và địa chỉ cư trú, dòng {missing} bị khuyết số điện thoại."
        else:
            p1_val = p1[0]
            p2_val = p2[0]
            ly_do = f"Trùng họ tên ('{n1}') và cùng địa chỉ ('{addr}') nhưng khác SĐT ({p1_val} vs {p2_val})"
            goi_y = f"Nghiêng về GỘP nếu cùng một khách hàng sử dụng hai số điện thoại khác nhau."
        q_records.append(
            {
                "nhom": nhom_idx,
                "ma_dong_goc": f"{u}; {v}",
                "quy_tac": "Q2",
                "ly_do": ly_do,
                "goi_y": goi_y,
            }
        )
        nhom_idx += 1

    # Xuất các file đầu ra
    print("Xuất file danh-ba-sach.xlsx...")
    df_clean = pd.DataFrame(customer_rows)
    with pd.ExcelWriter("danh-ba-sach.xlsx", engine="openpyxl") as writer:
        df_clean.to_excel(writer, sheet_name="KhachHang", index=False)

    print("Xuất file nhat-ky-gop.csv...")
    df_gop = pd.DataFrame(gop_logs)
    df_gop.to_csv("nhat-ky-gop.csv", index=False, encoding="utf-8-sig")

    print("Xuất file nhat-ky-sua.csv...")
    df_sua = pd.DataFrame(sua_logs)
    df_sua.to_csv("nhat-ky-sua.csv", index=False, encoding="utf-8-sig")

    print("Xuất file nghi-trung-can-quyet.csv...")
    df_q = pd.DataFrame(q_records)
    df_q.to_csv("nghi-trung-can-quyet.csv", index=False, encoding="utf-8-sig")

    # Tự kiểm tra các ràng buộc
    print("\n=== BẮT ĐẦU TỰ KIỂM ===")
    # 1. Mỗi Mã dòng gốc xuất hiện đúng 1 lần trong nhat-ky-gop.csv
    assert len(df_gop) == total_goc, f"Lỗi: số dòng nhật ký gộp {len(df_gop)} != tổng dòng gốc {total_goc}"
    assert df_gop["ma_dong_goc"].nunique() == total_goc, "Lỗi: Mã dòng gốc bị trùng trong nhật ký gộp!"
    print("✓ Kiểm tra 1 đạt: Mỗi Mã dòng gốc xuất hiện đúng 1 lần trong nhat-ky-gop.csv.")

    # 2. Số dòng sạch + số dòng bị gộp vào dòng khác = số dòng gốc
    so_dong_sach = len(df_clean)
    so_dong_gop = (df_gop["hanh_dong"] == "GOP_VAO").sum()
    assert (
        so_dong_sach + so_dong_gop == total_goc
    ), f"Lỗi: {so_dong_sach} + {so_dong_gop} != {total_goc}"
    print(
        f"✓ Kiểm tra 2 đạt: Số dòng sạch ({so_dong_sach}) + số dòng bị gộp ({so_dong_gop}) = {total_goc} dòng gốc."
    )

    # 3. Không SĐT sạch nào sai định dạng
    for idx_c, crow in df_clean.iterrows():
        p1 = crow["sdt"]
        if p1:
            assert (
                len(p1) == 10 and p1[:2] in ["03", "05", "07", "08", "09"]
            ) or (
                len(p1) == 11 and p1[:2] == "02"
            ), f"Lỗi SĐT chính sai: {p1} tại {crow['ma_khach']}"
        p2 = crow["sdt_khac"]
        if p2:
            for pk in p2.split("; "):
                assert (
                    len(pk) == 10 and pk[:2] in ["03", "05", "07", "08", "09"]
                ) or (
                    len(pk) == 11 and pk[:2] == "02"
                ), f"Lỗi SĐT khác sai: {pk} tại {crow['ma_khach']}"
    print("✓ Kiểm tra 3 đạt: 100% SĐT sạch trong danh bạ chuẩn định dạng.")

    print("\nHoàn tất xử lý thành công toàn bộ dữ liệu!")


if __name__ == "__main__":
    main()
