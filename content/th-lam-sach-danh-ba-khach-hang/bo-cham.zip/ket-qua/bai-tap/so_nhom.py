"""So hai lần làm sạch (ví dụ bản thật và bản giả danh): các nhóm đã gộp và danh sách cần người quyết có giống nhau không?

Dùng:  python -X utf8 so_nhom.py <thư_mục_A> <thư_mục_B>
Mỗi thư mục cần có nhat-ky-gop.csv và nghi-trung-can-quyet.csv. So theo Mã dòng gốc (không so tên, SĐT).
"""
import csv, sys
from pathlib import Path


def rd(p):
    return list(csv.DictReader(Path(p).read_text(encoding="utf-8-sig").splitlines()))


def nhom_gop(d):
    g = {}
    for r in rd(Path(d) / "nhat-ky-gop.csv"):
        g.setdefault(r["ma_khach"], set()).add(r["ma_dong_goc"].strip())
    return {frozenset(v) for v in g.values() if len(v) > 1}


def nhom_quyet(d):
    return {frozenset(x.strip() for x in r["ma_dong_goc"].split(";") if x.strip()) for r in rd(Path(d) / "nghi-trung-can-quyet.csv")}


if __name__ == "__main__":
    A, B = sys.argv[1], sys.argv[2]
    ok = True
    for ten, f in (("nhóm đã gộp", nhom_gop), ("nhóm cần người quyết", nhom_quyet)):
        a, b = f(A), f(B)
        print(f"{ten}: A {len(a)}, B {len(b)}, giống nhau {len(a & b)}, chỉ ở A {len(a - b)}, chỉ ở B {len(b - a)}")
        for x in sorted(map(sorted, a - b))[:5]: print("   chỉ ở A:", x)
        for x in sorted(map(sorted, b - a))[:5]: print("   chỉ ở B:", x)
        ok = ok and a == b
    print("KẾT LUẬN:", "giống hệt" if ok else "có khác biệt")
    sys.exit(0 if ok else 1)
