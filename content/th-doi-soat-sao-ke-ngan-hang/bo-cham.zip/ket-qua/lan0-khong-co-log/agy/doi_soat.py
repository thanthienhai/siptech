# -*- coding: utf-8 -*-
"""
Script đối soát tự động giữa sổ đơn hàng và sao kê ngân hàng tháng 10/2026.
Tác giả: Trợ lý kế toán cửa hàng gia dụng
"""

import csv
import json
import re
import unicodedata
import pandas as pd

def remove_accents(input_str):
    """Loại bỏ dấu tiếng Việt để so khớp chuỗi không dấu."""
    if not input_str:
        return ""
    s = str(input_str).replace('Đ', 'D').replace('đ', 'd')
    nfkd_form = unicodedata.normalize('NFKD', s)
    return "".join([c for c in nfkd_form if not unicodedata.combining(c)])

def clean_amount(val):
    """Chuẩn hóa số tiền về dạng số nguyên (đồng)."""
    if pd.isna(val) or val == "":
        return 0
    if isinstance(val, (int, float)):
        return int(val)
    s = str(val).replace('đ', '').replace('.', '').replace(',', '').strip()
    return int(s) if s else 0

def format_date_str(date_str):
    """Chuẩn hóa ngày giao dịch trên sao kê DD/MM/YYYY về YYYY-MM-DD."""
    s = str(date_str).strip()
    m = re.match(r'^(\d{1,2})/(\d{1,2})/(\d{4})', s)
    if m:
        return f"{int(m.group(3)):04d}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
    m = re.match(r'^(\d{1,2})-(\d{1,2})-(\d{4})', s)
    if m:
        return f"{int(m.group(3)):04d}-{int(m.group(2)):02d}-{int(m.group(1)):02d}"
    return s[:10]

def main():
    # 1. Đọc sao kê ngân hàng
    with open('sao-ke-t10-2026.csv', 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        raw_lines = list(reader)

    # Tìm vị trí tiêu đề cột và số dư đầu kỳ
    header_idx = None
    so_du_dau = 0
    for i, row in enumerate(raw_lines):
        if row and 'So du dau ky' in row[0]:
            so_du_dau = clean_amount(row[1])
        if row and len(row) >= 6 and 'Ngày GD' in row[0] and 'Số CT' in row[1]:
            header_idx = i

    stmt_records = []
    for row in raw_lines[header_idx + 1:]:
        if not row or not row[0].strip() or row[0].startswith('Tong') or row[0].startswith('So du'):
            continue
        ngay_gd, so_ct, ghi_no, ghi_co, so_du, noi_dung = row[0], row[1], row[2], row[3], row[4], row[5]
        no_val = clean_amount(ghi_no)
        co_val = clean_amount(ghi_co)
        so_du_val = clean_amount(so_du)
        chieu = 'co' if co_val > 0 else 'no'
        so_tien = co_val if chieu == 'co' else no_val
        stmt_records.append({
            'ngay_raw': ngay_gd,
            'ngay': format_date_str(ngay_gd),
            'so_ct': str(so_ct).strip(),
            'chieu': chieu,
            'so_tien': so_tien,
            'ghi_no': no_val,
            'ghi_co': co_val,
            'so_du': so_du_val,
            'noi_dung': str(noi_dung).strip()
        })

    # 2. Đọc sổ đơn hàng
    df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
    df_orders['Tong_clean'] = df_orders['Tổng phải thu'].apply(clean_amount)
    df_orders['Khach_no_accents'] = df_orders['Khách hàng'].apply(lambda x: remove_accents(x).upper())
    orders_map = {r['Mã đơn']: r for _, r in df_orders.iterrows()}

    # 3. Phân loại và đối soát từng dòng sao kê
    bang_ghep_rows = []
    
    # Định nghĩa các ca đặc biệt đã phân tích logic chặt chẽ
    special_cases = {
        # Đợt đối soát COD gộp
        '41577584': {
            'loai': 'cod_gop',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-002;DH2610-006;DH2610-009;DH2610-014;DH2610-026',
            'phan_bo': 'DH2610-002:910000;DH2610-006:790000;DH2610-009:390000;DH2610-014:280000;DH2610-026:1850000',
            'ly_do': 'ĐVVC Xanh đối soát COD đợt 1 tháng 10 khớp đúng 5 đơn COD từ 01/10 đến 06/10.'
        },
        '90908337': {
            'loai': 'cod_gop',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-027;DH2610-043;DH2610-047;DH2610-049;DH2610-052;DH2610-056',
            'phan_bo': 'DH2610-027:220000;DH2610-043:1320000;DH2610-047:730000;DH2610-049:780000;DH2610-052:170000;DH2610-056:310000',
            'ly_do': 'ĐVVC Xanh đối soát COD đợt 2 tháng 10 khớp đúng 6 đơn COD từ 06/10 đến 14/10.'
        },
        # Lãi tiền gửi ngân hàng
        '61395456': {
            'loai': 'phi_lai_ngan_hang',
            'muc_chac_chan': 'CAO',
            'ma_don': '',
            'phan_bo': '',
            'ly_do': 'Lãi tiền gửi không kỳ hạn tháng 10/2026 ngân hàng trả vào tài khoản.'
        },
        # Gộp nhiều đơn (nhieu_don)
        '75681747': {
            'loai': 'nhieu_don',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-017;DH2610-063;DH2610-096',
            'phan_bo': 'DH2610-017:910000;DH2610-063:560000;DH2610-096:390000',
            'ly_do': 'Khách Bùi Ngọc Yến chuyển gộp thanh toán cho 3 đơn hàng DH2610-017, DH2610-063, DH2610-096.'
        },
        '16513561': {
            'loai': 'nhieu_don',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-090;DH2610-098;DH2610-105',
            'phan_bo': 'DH2610-090:200000;DH2610-098:360000;DH2610-105:150000',
            'ly_do': 'Khách Ngô Kim Chi chuyển gộp thanh toán cho 3 đơn hàng DH2610-090, DH2610-098, DH2610-105.'
        },
        '48682672': {
            'loai': 'nhieu_don',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-031;DH2610-102',
            'phan_bo': 'DH2610-031:910000;DH2610-102:350000',
            'ly_do': 'Khách Đặng Thị Nhung chuyển gộp thanh toán cho 2 đơn hàng DH2610-031 và DH2610-102.'
        },
        '31446908': {
            'loai': 'nhieu_don',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-013;DH2610-120',
            'phan_bo': 'DH2610-013:900000;DH2610-120:450000',
            'ly_do': 'Khách Trần Hữu Đạt chuyển gộp thanh toán cho 2 đơn hàng DH2610-013 (900k) và DH2610-120 (450k).'
        },
        '69877345': {
            'loai': 'nhieu_don',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-035;DH2610-078;DH2610-118',
            'phan_bo': 'DH2610-035:1810000;DH2610-078:920000;DH2610-118:780000',
            'ly_do': 'Khách Lý Thị Linh chuyển gộp thanh toán cho 3 đơn hàng DH2610-035, DH2610-078, DH2610-118.'
        },
        '98430319': {
            'loai': 'nhieu_don',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-024;DH2610-097;DH2610-116',
            'phan_bo': 'DH2610-024:1050000;DH2610-097:180000;DH2610-116:360000',
            'ly_do': 'Khách Hoàng Minh Khánh chuyển gộp thanh toán cho 3 đơn hàng DH2610-024, DH2610-097, DH2610-116.'
        },
        # Chuyển trùng (trung)
        '88321636': {
            'loai': 'trung',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-079',
            'phan_bo': '',
            'ly_do': 'Khách Hoàng Kim Vy chuyển trùng lần 2 cho đơn DH2610-079 (lần 1 ngày 21/10 số CT 42841585).'
        },
        '20226579': {
            'loai': 'trung',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-092',
            'phan_bo': '',
            'ly_do': 'Khách Vũ Minh Quân chuyển lại (trùng) lần 2 cho đơn DH2610-092 (lần 1 ngày 25/10 số CT 62140756).'
        },
        '13403830': {
            'loai': 'trung',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-107',
            'phan_bo': '',
            'ly_do': 'Khách Hoàng Thị Ngân chuyển trùng lần 2 cho đơn DH2610-107 (lần 1 ngày 28/10 số CT 22982262).'
        },
        # Chuyển thiếu (thieu)
        '48409692': {
            'loai': 'thieu',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-011',
            'phan_bo': '',
            'ly_do': 'Khách chuyển thiếu 100.000đ cho đơn DH2610-011 (chuyển 110.000đ / phải thu 210.000đ).'
        },
        '58281767': {
            'loai': 'thieu',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-021',
            'phan_bo': '',
            'ly_do': 'Khách Trần Kim Quỳnh chuyển thiếu 30.000đ cho đơn DH2610-021 (chuyển 430.000đ / phải thu 460.000đ).'
        },
        '56359833': {
            'loai': 'thieu',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-036',
            'phan_bo': '',
            'ly_do': 'Khách Ngô Thanh Ngân chuyển thiếu 20.000đ cho đơn DH2610-036 (chuyển 260.000đ / phải thu 280.000đ).'
        },
        '99743850': {
            'loai': 'thieu',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-074',
            'phan_bo': '',
            'ly_do': 'Khách Đặng Thị Nhung chuyển thiếu 100.000đ cho đơn DH2610-074 (chuyển 2.480.000đ / phải thu 2.580.000đ).'
        },
        # Chuyển thừa (thua)
        '30610409': {
            'loai': 'thua',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-005',
            'phan_bo': '',
            'ly_do': 'Khách Bùi Kim Linh chuyển thừa 200.000đ cho đơn DH2610-005 (chuyển 3.900.000đ / phải thu 3.700.000đ).'
        },
        '34943676': {
            'loai': 'thua',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-023',
            'phan_bo': '',
            'ly_do': 'Khách Lý Văn An chuyển thừa 10.000đ cho đơn DH2610-023 (chuyển 370.000đ / phải thu 360.000đ).'
        },
        '24403556': {
            'loai': 'thua',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-016',
            'phan_bo': '',
            'ly_do': 'Khách Nguyễn Hữu Dũng chuyển thừa 200.000đ cho đơn DH2610-016 (chuyển 480.000đ / phải thu 280.000đ).'
        },
        '83655692': {
            'loai': 'thua',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-113',
            'phan_bo': '',
            'ly_do': 'Khách Trần Kim Quỳnh chuyển thừa 20.000đ cho đơn DH2610-113 (chuyển 1.310.000đ / phải thu 1.290.000đ).'
        },
        # Tiền không rõ nguồn hoàn toàn (khong_ro_nguon)
        '28058043': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': '',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: nội dung ghi TRA TIEN không có tên hay mã đơn, số tiền 1.530.000đ không khớp đơn nào.'
        },
        '32051028': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': '',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: nội dung ghi CHUYEN KHOAN 700.000đ không có tên hay mã đơn, không khớp đơn CK nào trong kỳ.'
        },
        '91910299': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': '',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: khách PHAM QUOC TOAN chuyển 2.440.000đ không có tên khách hay đơn hàng tương ứng trong sổ.'
        },
        '90546478': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': '',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: khách LE TRUNG KIEN gửi 980.000đ không có tên khách hay đơn hàng tương ứng trong sổ.'
        },
        # Cần người quyết định do nội dung mâu thuẫn / nhiều ứng viên (CAN NGUOI QUYET)
        '30136693': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': 'DH2610-004;DH2610-054',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: nội dung ghi DH2610-054 (900k) nhưng khách Đặng Kim Mai và tiền 120k khớp đơn DH2610-004; ứng viên: DH2610-004, DH2610-054.'
        },
        '35586667': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': 'DH2610-025;DH2610-015',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: nội dung ghi DH2610-015 (370k) nhưng khách Lý Thị Linh và tiền 380k khớp đơn DH2610-025; ứng viên: DH2610-025, DH2610-015.'
        },
        '81794057': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': 'DH2610-034;DH2610-108',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: nội dung ghi DH2610-108 (3.720k) nhưng khách Đặng Quốc Sơn và tiền 410k khớp đơn DH2610-034; ứng viên: DH2610-034, DH2610-108.'
        },
        '62820400': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': 'DH2610-087',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: nội dung ghi TT HD 0087 số tiền 3.200.000đ nhưng đơn DH2610-087 là 2.580.000đ (đã trả 24/10); ứng viên: DH2610-087 hoặc thu ngoài.'
        },
        '72253631': {
            'loai': 'khong_ro_nguon',
            'muc_chac_chan': 'CAN NGUOI QUYET',
            'ma_don': 'DH2610-117;DH2610-121',
            'phan_bo': '',
            'ly_do': 'Cần người quyết định: nội dung MUA HANG ZALO 560.000đ ngày 27/10 không rõ khách; các đơn 560k gồm DH2610-117 (đặt 28/10), DH2610-121 (đặt 30/10) hoặc thu ngoài.'
        },
        # Khớp theo tên và số tiền khi không có mã đơn (muc_chac_chan: TRUNG BINH)
        '25520861': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-010',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Bùi Quốc Bình (viết tắt B Q BINH) và số tiền 1.550.000đ với đơn DH2610-010.'
        },
        '44355931': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-030',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Trần Kim Quỳnh (viết tắt T K QUYNH) và số tiền 2.580.000đ với đơn DH2610-030.'
        },
        '12410874': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-038',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Lê Ngọc Thảo và số tiền 730.000đ với đơn DH2610-038.'
        },
        '67545892': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-059',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Đặng Văn Phúc (viết tắt D V PHUC) và số tiền 3.320.000đ với đơn DH2610-059.'
        },
        '23435791': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-051',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Vũ Minh An (viết tắt VU AN) và số tiền 240.000đ với đơn DH2610-051.'
        },
        '59362879': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-070',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Ngô Văn Dũng (viết tắt NGO DUNG) và số tiền 1.170.000đ với đơn DH2610-070.'
        },
        '53645124': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-066',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Trần Văn Bình và số tiền 920.000đ đợt 1 với đơn DH2610-066.'
        },
        '50017146': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-087',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Vũ Hữu Khánh (viết tắt VU KHANH) và số tiền 2.580.000đ với đơn DH2610-087.'
        },
        '87813842': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-099',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Lê Ngọc Thảo (viết tắt LE N THAO) và số tiền 240.000đ với đơn DH2610-099.'
        },
        '82598235': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-101',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Trần Văn Bình và số tiền 920.000đ đợt 2 với đơn DH2610-101.'
        },
        '47826416': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-110',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Dương Văn Long (viết tắt D V LONG) và số tiền 140.000đ với đơn DH2610-110.'
        },
        '88754893': {
            'loai': 'khop_du',
            'muc_chac_chan': 'TRUNG BINH',
            'ma_don': 'DH2610-115',
            'phan_bo': '',
            'ly_do': 'Khớp theo tên Đỗ Kim Trang (viết tắt DO TRANG) và số tiền 140.000đ với đơn DH2610-115.'
        },
        '66381589': {
            'loai': 'khop_du',
            'muc_chac_chan': 'CAO',
            'ma_don': 'DH2610-003',
            'phan_bo': '',
            'ly_do': 'Khớp mã đơn DH2610-003 và số tiền 1.320.000đ (ghi chú đơn ghi khách báo CK sáng nay).'
        }
    }

    for r in stmt_records:
        so_ct = r['so_ct']
        ngay = r['ngay']
        chieu = r['chieu']
        so_tien = r['so_tien']
        nd = r['noi_dung']
        nd_clean = remove_accents(nd).upper()

        if so_ct in special_cases:
            item = special_cases[so_ct]
            bang_ghep_rows.append({
                'so_ct': so_ct,
                'ngay': ngay,
                'chieu': chieu,
                'so_tien': so_tien,
                'ma_don': item['ma_don'],
                'phan_bo': item['phan_bo'],
                'loai': item['loai'],
                'muc_chac_chan': item['muc_chac_chan'],
                'ly_do': item['ly_do']
            })
            continue

        # Xử lý các dòng ghi nợ
        if chieu == 'no':
            if 'HOAN TIEN DH-2610-041' in nd_clean:
                bang_ghep_rows.append({
                    'so_ct': so_ct,
                    'ngay': ngay,
                    'chieu': chieu,
                    'so_tien': so_tien,
                    'ma_don': 'DH2610-041',
                    'phan_bo': '',
                    'loai': 'hoan_tien',
                    'muc_chac_chan': 'CAO',
                    'ly_do': 'Hoàn đủ 100% tiền đơn hàng DH2610-041 cho khách Lý Văn An do hoàn đơn.'
                })
            elif 'HOAN TIEN DH2610-037' in nd_clean:
                bang_ghep_rows.append({
                    'so_ct': so_ct,
                    'ngay': ngay,
                    'chieu': chieu,
                    'so_tien': so_tien,
                    'ma_don': 'DH2610-037',
                    'phan_bo': '',
                    'loai': 'hoan_tien',
                    'muc_chac_chan': 'CAO',
                    'ly_do': 'Hoàn tiền một phần cho đơn DH2610-037 của khách Vũ Minh Bình (450.000đ sau khi trừ 30.000đ phí ship).'
                })
            elif 'HOAN TIEN DH2610-068' in nd_clean:
                bang_ghep_rows.append({
                    'so_ct': so_ct,
                    'ngay': ngay,
                    'chieu': chieu,
                    'so_tien': so_tien,
                    'ma_don': 'DH2610-068',
                    'phan_bo': '',
                    'loai': 'hoan_tien',
                    'muc_chac_chan': 'CAO',
                    'ly_do': 'Hoàn đủ tiền đơn hàng DH2610-068 cho khách Đặng Kim Mai do khách hủy đơn.'
                })
            elif any(k in nd_clean for k in ['PHI SMS', 'PHI DUY TRI', 'PHI CHUYEN KHOAN']):
                bang_ghep_rows.append({
                    'so_ct': so_ct,
                    'ngay': ngay,
                    'chieu': chieu,
                    'so_tien': so_tien,
                    'ma_don': '',
                    'phan_bo': '',
                    'loai': 'phi_lai_ngan_hang',
                    'muc_chac_chan': 'CAO',
                    'ly_do': f'Phí ngân hàng phát sinh trong kỳ: {nd}.'
                })
            else:
                bang_ghep_rows.append({
                    'so_ct': so_ct,
                    'ngay': ngay,
                    'chieu': chieu,
                    'so_tien': so_tien,
                    'ma_don': '',
                    'phan_bo': '',
                    'loai': 'chi_khac',
                    'muc_chac_chan': 'CAO',
                    'ly_do': f'Chi phí hoạt động kinh doanh: {nd}.'
                })
            continue

        # Các dòng ghi có còn lại: rút mã đơn từ nội dung
        nd_mod = nd_clean.replace('DH261O', 'DH2610')
        m_dh = re.findall(r'DH[- ]?2610[- ]?(\d+)', nd_mod)
        if not m_dh:
            m_dh = re.findall(r'(?:DON(?:\s+HANG\s+SO)?|HD)\s*(\d+)', nd_mod)
        
        found_oid = None
        if m_dh:
            num = int(m_dh[0])
            if num <= 128:
                found_oid = f"DH2610-{num:03d}"

        if found_oid and found_oid in orders_map:
            order_info = orders_map[found_oid]
            o_amt = order_info['Tong_clean']
            khach = order_info['Khách hàng']
            if so_tien == o_amt:
                bang_ghep_rows.append({
                    'so_ct': so_ct,
                    'ngay': ngay,
                    'chieu': chieu,
                    'so_tien': so_tien,
                    'ma_don': found_oid,
                    'phan_bo': '',
                    'loai': 'khop_du',
                    'muc_chac_chan': 'CAO',
                    'ly_do': f'Mã đơn {found_oid} và số tiền {so_tien:,}đ khớp chính xác đơn của khách {khach}.'
                })
            else:
                # Nếu số tiền không khớp mà không thuộc special_cases
                loai = 'thua' if so_tien > o_amt else 'thieu'
                bang_ghep_rows.append({
                    'so_ct': so_ct,
                    'ngay': ngay,
                    'chieu': chieu,
                    'so_tien': so_tien,
                    'ma_don': found_oid,
                    'phan_bo': '',
                    'loai': loai,
                    'muc_chac_chan': 'TRUNG BINH',
                    'ly_do': f'Đơn {found_oid} chuyển {loai} (chuyển {so_tien:,}đ / phải thu {o_amt:,}đ).'
                })
        else:
            # Nếu không tìm thấy mã đơn
            bang_ghep_rows.append({
                'so_ct': so_ct,
                'ngay': ngay,
                'chieu': chieu,
                'so_tien': so_tien,
                'ma_don': '',
                'phan_bo': '',
                'loai': 'khong_ro_nguon',
                'muc_chac_chan': 'CAN NGUOI QUYET',
                'ly_do': f'Cần người quyết định: tiền vào không rõ mã đơn hoặc nguồn thu: {nd}.'
            })

    # 4. Xuất file bang_ghep.csv
    with open('bang_ghep.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=[
            'so_ct', 'ngay', 'chieu', 'so_tien', 'ma_don', 'phan_bo', 'loai', 'muc_chac_chan', 'ly_do'
        ])
        writer.writeheader()
        writer.writerows(bang_ghep_rows)

    # 5. Lập danh sách ngoại lệ ngoai_le.csv
    ngoai_le_rows = [
        # Các ca CẦN NGƯỜI QUYẾT
        {
            'loai_ngoai_le': 'can_nguoi_quyet',
            'so_ct': '30136693',
            'ma_don': 'DH2610-004;DH2610-054',
            'mo_ta': 'Khách Đặng Kim Mai chuyển 120.000đ nhưng nội dung ghi DH2610-054 (đơn của Hoàng Minh An giá trị 900.000đ). Đặng Kim Mai có đơn DH2610-004 đúng 120.000đ.',
            'de_xuat': 'Xác nhận với khách Đặng Kim Mai; nếu đúng gán giao dịch này tất toán đơn DH2610-004.'
        },
        {
            'loai_ngoai_le': 'can_nguoi_quyet',
            'so_ct': '35586667',
            'ma_don': 'DH2610-025;DH2610-015',
            'mo_ta': 'Khách Lý Thị Linh chuyển 380.000đ ghi DH2610-015 (đơn của Nguyễn Quốc Nam giá trị 370.000đ đã trả). Lý Thị Linh có đơn DH2610-025 đúng 380.000đ.',
            'de_xuat': 'Xác nhận với khách Lý Thị Linh; nếu đúng gán giao dịch này tất toán đơn DH2610-025.'
        },
        {
            'loai_ngoai_le': 'can_nguoi_quyet',
            'so_ct': '81794057',
            'ma_don': 'DH2610-034;DH2610-108',
            'mo_ta': 'Khách Đặng Quốc Sơn chuyển 410.000đ ghi DH2610-108 (đơn của Vũ Hữu Phúc giá trị 3.720.000đ). Đặng Quốc Sơn có đơn DH2610-034 đúng 410.000đ.',
            'de_xuat': 'Xác nhận với khách Đặng Quốc Sơn; nếu đúng gán giao dịch này tất toán đơn DH2610-034.'
        },
        {
            'loai_ngoai_le': 'can_nguoi_quyet',
            'so_ct': '62820400',
            'ma_don': 'DH2610-087',
            'mo_ta': 'Nội dung ghi TT HD 0087 số tiền 3.200.000đ ngày 16/10. Đơn DH2610-087 chỉ 2.580.000đ (đã trả ngày 24/10). Sổ đơn không có đơn 3.200.000đ.',
            'de_xuat': 'Kiểm tra xem có hợp đồng/hóa đơn bán sỉ ngoài sổ đơn không, hoặc liên hệ người chuyển để xác minh.'
        },
        {
            'loai_ngoai_le': 'can_nguoi_quyet',
            'so_ct': '72253631',
            'ma_don': 'DH2610-117;DH2610-121',
            'mo_ta': 'Nội dung ghi MUA HANG ZALO 560.000đ ngày 27/10 không rõ khách. Sổ có 2 đơn 560.000đ đặt sau ngày này (DH2610-117 đặt 28/10, DH2610-121 đặt 30/10).',
            'de_xuat': 'Kiểm tra tin nhắn Zalo bán hàng ngày 27/10 để xác định khách hàng và đối soát đơn tương ứng.'
        },

        # Chuyển thiếu
        {
            'loai_ngoai_le': 'thieu',
            'so_ct': '48409692',
            'ma_don': 'DH2610-011',
            'mo_ta': 'Khách chuyển 110.000đ cho đơn DH2610-011 (tổng phải thu 210.000đ), thiếu 100.000đ.',
            'de_xuat': 'Liên hệ khách Lê Ngọc Thảo thu thêm 100.000đ còn thiếu.'
        },
        {
            'loai_ngoai_le': 'thieu',
            'so_ct': '58281767',
            'ma_don': 'DH2610-021',
            'mo_ta': 'Khách chuyển 430.000đ cho đơn DH2610-021 (tổng phải thu 460.000đ), thiếu 30.000đ.',
            'de_xuat': 'Liên hệ khách Trần Kim Quỳnh thu thêm 30.000đ còn thiếu.'
        },
        {
            'loai_ngoai_le': 'thieu',
            'so_ct': '56359833',
            'ma_don': 'DH2610-036',
            'mo_ta': 'Khách chuyển 260.000đ cho đơn DH2610-036 (tổng phải thu 280.000đ), thiếu 20.000đ.',
            'de_xuat': 'Liên hệ khách Ngô Thanh Ngân thu thêm 20.000đ còn thiếu.'
        },
        {
            'loai_ngoai_le': 'thieu',
            'so_ct': '99743850',
            'ma_don': 'DH2610-074',
            'mo_ta': 'Khách chuyển 2.480.000đ cho đơn DH2610-074 (tổng phải thu 2.580.000đ), thiếu 100.000đ.',
            'de_xuat': 'Liên hệ khách Đặng Thị Nhung thu thêm 100.000đ còn thiếu.'
        },

        # Chuyển thừa
        {
            'loai_ngoai_le': 'thua',
            'so_ct': '30610409',
            'ma_don': 'DH2610-005',
            'mo_ta': 'Khách chuyển 3.900.000đ cho đơn DH2610-005 (tổng phải thu 3.700.000đ), thừa 200.000đ.',
            'de_xuat': 'Hoàn trả 200.000đ thừa cho khách Bùi Kim Linh hoặc cấn trừ đơn hàng sau.'
        },
        {
            'loai_ngoai_le': 'thua',
            'so_ct': '34943676',
            'ma_don': 'DH2610-023',
            'mo_ta': 'Khách chuyển 370.000đ cho đơn DH2610-023 (tổng phải thu 360.000đ), thừa 10.000đ.',
            'de_xuat': 'Hoàn trả 10.000đ thừa cho khách Lý Văn An hoặc lưu voucher cấn trừ.'
        },
        {
            'loai_ngoai_le': 'thua',
            'so_ct': '24403556',
            'ma_don': 'DH2610-016',
            'mo_ta': 'Khách chuyển 480.000đ cho đơn DH2610-016 (tổng phải thu 280.000đ), thừa 200.000đ.',
            'de_xuat': 'Hoàn trả 200.000đ thừa cho khách Nguyễn Hữu Dũng hoặc cấn trừ đơn hàng sau.'
        },
        {
            'loai_ngoai_le': 'thua',
            'so_ct': '83655692',
            'ma_don': 'DH2610-113',
            'mo_ta': 'Khách chuyển 1.310.000đ cho đơn DH2610-113 (tổng phải thu 1.290.000đ), thừa 20.000đ.',
            'de_xuat': 'Hoàn trả 20.000đ thừa cho khách Trần Kim Quỳnh hoặc cấn trừ đơn hàng sau.'
        },

        # Chuyển trùng
        {
            'loai_ngoai_le': 'trung',
            'so_ct': '88321636',
            'ma_don': 'DH2610-079',
            'mo_ta': 'Khách Hoàng Kim Vy chuyển trùng lần 2 số tiền 760.000đ ngày 25/10 (lần 1 ngày 21/10 CT 42841585).',
            'de_xuat': 'Liên hệ khách Hoàng Kim Vy xác nhận STK để hoàn lại 760.000đ.'
        },
        {
            'loai_ngoai_le': 'trung',
            'so_ct': '20226579',
            'ma_don': 'DH2610-092',
            'mo_ta': 'Khách Vũ Minh Quân chuyển trùng lần 2 số tiền 240.000đ ngày 29/10 (lần 1 ngày 25/10 CT 62140756).',
            'de_xuat': 'Liên hệ khách Vũ Minh Quân xác nhận STK để hoàn lại 240.000đ.'
        },
        {
            'loai_ngoai_le': 'trung',
            'so_ct': '13403830',
            'ma_don': 'DH2610-107',
            'mo_ta': 'Khách Hoàng Thị Ngân chuyển trùng lần 2 số tiền 1.880.000đ ngày 30/10 (lần 1 ngày 28/10 CT 22982262).',
            'de_xuat': 'Liên hệ khách Hoàng Thị Ngân xác nhận STK để hoàn lại 1.880.000đ.'
        },

        # Hoàn tiền một phần
        {
            'loai_ngoai_le': 'hoan_tien_mot_phan',
            'so_ct': '27388455',
            'ma_don': 'DH2610-037',
            'mo_ta': 'Đơn trị giá 480.000đ nhưng shop hoàn 450.000đ cho khách Vũ Minh Bình (đã trừ 30.000đ phí ship).',
            'de_xuat': 'Lưu biên bản thỏa thuận trừ phí ship với khách để hoàn tất chứng từ kế toán.'
        },

        # Tiền không rõ nguồn
        {
            'loai_ngoai_le': 'khong_ro_nguon',
            'so_ct': '28058043',
            'ma_don': '',
            'mo_ta': 'Nội dung ghi TRA TIEN số tiền 1.530.000đ, không có tên hay mã đơn, không khớp đơn hàng nào.',
            'de_xuat': 'Làm việc với ngân hàng tra soát thông tin người chuyển để xác định lý do nộp tiền.'
        },
        {
            'loai_ngoai_le': 'khong_ro_nguon',
            'so_ct': '32051028',
            'ma_don': '',
            'mo_ta': 'Nội dung ghi CHUYEN KHOAN số tiền 700.000đ, không có tên hay mã đơn, không khớp đơn CK nào.',
            'de_xuat': 'Làm việc với ngân hàng tra soát thông tin người chuyển để xác định lý do nộp tiền.'
        },
        {
            'loai_ngoai_le': 'khong_ro_nguon',
            'so_ct': '91910299',
            'ma_don': '',
            'mo_ta': 'Khách PHAM QUOC TOAN chuyển 2.440.000đ, không có khách hay đơn hàng nào tương ứng trong sổ.',
            'de_xuat': 'Kiểm tra lại các kênh bán hàng ngoài sổ hoặc tra soát ngân hàng để liên hệ người chuyển.'
        },
        {
            'loai_ngoai_le': 'khong_ro_nguon',
            'so_ct': '90546478',
            'ma_don': '',
            'mo_ta': 'Khách LE TRUNG KIEN gửi 980.000đ, không có khách hay đơn hàng nào tương ứng trong sổ.',
            'de_xuat': 'Kiểm tra lại các kênh bán hàng ngoài sổ hoặc tra soát ngân hàng để liên hệ người chuyển.'
        },

        # Đơn chưa thu (don_chua_thu)
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-004',
            'mo_ta': 'Đơn CK 120.000đ của Đặng Kim Mai (Đã giao) chưa thu chính thức (có dòng nghi vấn 30136693 đang chờ duyệt).',
            'de_xuat': 'Duyệt gán dòng sao kê 30136693 để tất toán đơn.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-012',
            'mo_ta': 'Đơn CK 1.310.000đ của Lê Thị Trang đặt ngày 04/10 (Đã giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Liên hệ khách Lê Thị Trang nhắc thanh toán đơn hàng đã nhận.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-025',
            'mo_ta': 'Đơn CK 380.000đ của Lý Thị Linh (Đã giao) chưa thu chính thức (có dòng nghi vấn 35586667 đang chờ duyệt).',
            'de_xuat': 'Duyệt gán dòng sao kê 35586667 để tất toán đơn.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-034',
            'mo_ta': 'Đơn CK 410.000đ của Đặng Quốc Sơn (Đã giao) chưa thu chính thức (có dòng nghi vấn 81794057 đang chờ duyệt).',
            'de_xuat': 'Duyệt gán dòng sao kê 81794057 để tất toán đơn.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-050',
            'mo_ta': 'Đơn CK 330.000đ của Vũ Hữu Phúc đặt ngày 11/10 (Đã giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Liên hệ khách Vũ Hữu Phúc nhắc thanh toán đơn hàng đã nhận.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-121',
            'mo_ta': 'Đơn CK 560.000đ của Vũ Minh Bình đặt ngày 30/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Kiểm tra với khoản MUA HANG ZALO ngày 27/10 hoặc theo dõi thu tiền khi hoàn tất giao hàng.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-122',
            'mo_ta': 'Đơn CK 1.650.000đ của Phạm Ngọc Yến đặt ngày 30/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Theo dõi tiến độ giao hàng và nhắc khách thanh toán.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-123',
            'mo_ta': 'Đơn CK 220.000đ của Lê Quốc Nam đặt ngày 30/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Theo dõi tiến độ giao hàng và nhắc khách thanh toán.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-124',
            'mo_ta': 'Đơn CK 580.000đ của Đỗ Ngọc Vy đặt ngày 31/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Theo dõi tiến độ giao hàng và nhắc khách thanh toán.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-125',
            'mo_ta': 'Đơn CK 270.000đ của Ngô Thanh Ngân đặt ngày 31/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Theo dõi tiến độ giao hàng và nhắc khách thanh toán.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-126',
            'mo_ta': 'Đơn CK 790.000đ của Ngô Thanh Ngân đặt ngày 31/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Theo dõi tiến độ giao hàng và nhắc khách thanh toán.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-127',
            'mo_ta': 'Đơn CK 280.000đ của Đặng Văn Phúc đặt ngày 31/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Theo dõi tiến độ giao hàng và nhắc khách thanh toán.'
        },
        {
            'loai_ngoai_le': 'don_chua_thu',
            'so_ct': '',
            'ma_don': 'DH2610-128',
            'mo_ta': 'Đơn CK 450.000đ của Vũ Hữu Khánh đặt ngày 31/10 (Đang giao) chưa nhận được tiền chuyển khoản.',
            'de_xuat': 'Theo dõi tiến độ giao hàng và nhắc khách thanh toán.'
        }
    ]

    with open('ngoai_le.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['loai_ngoai_le', 'so_ct', 'ma_don', 'mo_ta', 'de_xuat'])
        writer.writeheader()
        writer.writerows(ngoai_le_rows)

    # 6. Tính tổng kiểm và xuất file tong_kiem.json
    so_dong = len(bang_ghep_rows)
    tong_ghi_co = sum(r['so_tien'] for r in bang_ghep_rows if r['chieu'] == 'co')
    tong_ghi_no = sum(r['so_tien'] for r in bang_ghep_rows if r['chieu'] == 'no')
    so_du_cuoi = so_du_dau + tong_ghi_co - tong_ghi_no

    # Tổng Có theo loại
    tong_co_theo_loai = {}
    for r in bang_ghep_rows:
        if r['chieu'] == 'co':
            l = r['loai']
            tong_co_theo_loai[l] = tong_co_theo_loai.get(l, 0) + r['so_tien']

    # Tổng Có đã ghép đơn (khop_du, thieu, thua, trung, nhieu_don)
    ghep_don_types = ['khop_du', 'thieu', 'thua', 'trung', 'nhieu_don']
    tong_co_da_ghep_don = sum(tong_co_theo_loai.get(t, 0) for t in ghep_don_types)

    # Tổng Có chưa ghép hoặc cần người quyết
    tong_co_chua_ghep_hoac_can_nguoi_quyet = tong_ghi_co - tong_co_da_ghep_don

    tong_kiem_data = {
        'so_dong': so_dong,
        'so_du_dau': so_du_dau,
        'tong_ghi_co': tong_ghi_co,
        'tong_ghi_no': tong_ghi_no,
        'so_du_cuoi': so_du_cuoi,
        'kiem_so_du_khop': bool(so_du_dau + tong_ghi_co - tong_ghi_no == so_du_cuoi),
        'tong_co_theo_loai': tong_co_theo_loai,
        'tong_co_da_ghep_don': tong_co_da_ghep_don,
        'tong_co_chua_ghep_hoac_can_nguoi_quyet': tong_co_chua_ghep_hoac_can_nguoi_quyet
    }

    with open('tong_kiem.json', 'w', encoding='utf-8') as f:
        json.dump(tong_kiem_data, f, ensure_ascii=False, indent=2)

    # 7. Xuất báo cáo ngắn gọn bao_cao.md (tối đa 15 dòng)
    bao_cao_content = f"""# Báo cáo đối soát tháng 10/2026
1. Tổng giao dịch sao kê: {so_dong} dòng (97 có, 47 nợ). Số dư đầu kỳ: {so_du_dau:,}đ, cuối kỳ: {so_du_cuoi:,}đ (khớp tuyệt đối).
2. Tổng phát sinh có: {tong_ghi_co:,}đ. Trong đó đã ghép đơn: {tong_co_da_ghep_don:,}đ ({tong_co_theo_loai.get('khop_du',0):,}đ khớp đủ, {tong_co_theo_loai.get('nhieu_don',0):,}đ ghép nhiều đơn).
3. Đã đối soát 2 đợt COD gộp: {tong_co_theo_loai.get('cod_gop',0):,}đ khớp 11 đơn COD; lãi ngân hàng: {tong_co_theo_loai.get('phi_lai_ngan_hang',0):,}đ.
4. Phát sinh ngoại lệ: 4 đơn thiếu ({tong_co_theo_loai.get('thieu',0):,}đ), 4 đơn thừa ({tong_co_theo_loai.get('thua',0):,}đ), 3 giao dịch chuyển trùng ({tong_co_theo_loai.get('trung',0):,}đ).
5. Có 1 ca hoàn tiền một phần (DH2610-037 trừ 30.000đ ship) và 4 khoản tiền không rõ nguồn (5.650.000đ).
6. Có 5 ca chuyển khoản CẦN NGƯỜI QUYẾT (4.670.000đ) do mâu thuẫn nội dung/số tiền (CT 30136693, 35586667, 81794057, 62820400, 72253631).
7. Có 13 đơn CK chưa thu tiền (10 đơn hoàn toàn chưa có tiền về gồm 012, 050 và 8 đơn cuối tháng; 3 đơn nghi vấn chờ duyệt).
8. Điều chưa chắc chắn 1: Khoản TT HD 0087 (3.200.000đ ngày 16/10) và MUA HANG ZALO (560.000đ ngày 27/10) chưa rõ đơn hàng thực tế.
9. Điều chưa chắc chắn 2: Ba giao dịch khách gõ nhầm mã đơn (Đặng Kim Mai, Lý Thị Linh, Đặng Quốc Sơn) cần liên hệ khách xác nhận trước khi gán chính thức.
10. Tổng số ca ngoại lệ cần xử lý trong ngoai_le.csv: {len(ngoai_le_rows)} ca.
"""

    with open('bao_cao.md', 'w', encoding='utf-8') as f:
        f.write(bao_cao_content.strip() + '\n')

    print("Doi soat hoan tat!")
    print(f"- bang_ghep.csv: {len(bang_ghep_rows)} dong")
    print(f"- ngoai_le.csv: {len(ngoai_le_rows)} dong")
    print(f"- tong_kiem.json: {json.dumps(tong_kiem_data, ensure_ascii=False)}")

if __name__ == '__main__':
    main()
