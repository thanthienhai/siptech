"""Dung: python -X utf8 chay_agent_giu_log.py <claude|agy> <thu_muc_lam_viec> <file_prompt> <tien_to_log> <giay_toi_da>
Bọc agent_run: ghi log gốc theo dòng NGAY KHI chạy, nên hết giờ vẫn giữ được log. Dùng lại norm_* của agent_run.py."""
import sys, os, json, time, shutil, subprocess
sys.path.insert(0, os.environ.get("AGENTLAB", "."))   # thu muc chua agent_run.py
import agent_run
from pathlib import Path
agent, cwd, pf, prefix, to = sys.argv[1], sys.argv[2], sys.argv[3], Path(sys.argv[4]), int(sys.argv[5])
prompt = Path(pf).read_text(encoding="utf-8")
env = dict(os.environ); env.pop("CLAUDECODE", None)
exe = shutil.which(agent) or agent
cmd = ([exe, "-p", prompt, "--output-format", "stream-json", "--verbose", "--permission-mode", "acceptEdits", "--allowedTools", "Read,Write,Edit,Glob,Grep,Bash"]
       if agent == "claude" else [exe, "-p", prompt, "--output-format", "stream-json", "--dangerously-skip-permissions"])
raw = prefix.with_suffix(".raw.jsonl"); t0 = time.time(); timed_out = False
with open(raw, "w", encoding="utf-8") as f:
    p = subprocess.Popen(cmd, cwd=str(Path(cwd).resolve()), stdout=f, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", env=env)
    try: _, err = p.communicate(timeout=to)
    except subprocess.TimeoutExpired:
        timed_out = True; p.kill(); _, err = p.communicate()
dt = time.time() - t0
events = []
for ln in raw.read_text(encoding="utf-8", errors="replace").splitlines():
    if ln.strip().startswith("{"):
        try: events.append(json.loads(ln))
        except Exception: pass
blocks, meta = (agent_run.norm_claude if agent == "claude" else agent_run.norm_agy)(events)
out = {"agent": agent, "cwd": str(Path(cwd).resolve()), "prompt": prompt, "seconds": round(dt, 1), "returncode": p.returncode, "timed_out": timed_out,
       "stderr_tail": (err or "")[-600:], "blocks": blocks, **meta}
prefix.with_suffix(".json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
print(agent, round(dt, 1), "s", "HẾT GIỜ" if timed_out else "xong", len(blocks), "khối")
