"""Kiểm file nhập hàng loạt KHÔNG cần đáp án riêng: lấy chính thong_so.csv làm sự thật.
Dùng hằng ngày sau khi agent viết xong, trước khi người duyệt.

Chạy:  python -X utf8 kiem_hang_ngay.py <nhap_hang_loat.csv> [thong_so.csv] [tu_cam.txt] [--bo-qua loi1,loi2] [--ghi ket_qua.txt]
--bo-qua: bỏ qua một số loại lỗi cứng (ví dụ --bo-qua giong khi cố ý đổi giọng thương hiệu, bài 4).
--ghi: ghi thêm toàn bộ kết quả in ra vào một file UTF-8 (để đưa cho agent đọc).
Cần file ../ket-qua/cham.py (dùng lại logic chấm). Thoát mã 1 nếu còn lỗi cứng.
Chỉ bắt được những gì cham.py biết bắt (xem bài 2): từ cấm, số ngoài bảng, cụm bịa trong danh sách tay,
rò ghi chú, "đã công bố" sai, trạng thái/ trường thiếu, độ dài, giọng. Không đọc hiểu nghĩa câu, không thay người duyệt.
Ngoài ra chặn đăng nhầm: còn chữ CẦN BỔ SUNG / CẦN NGƯỜI QUYẾT trong dòng nào thì dòng đó phải ở trạng thái CAN_BO_SUNG.
"""
import csv, sys
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE.parent / "ket-qua"))
import cham  # noqa: E402

MISSING = {"", "?", "chưa rõ", "liên hệ ncc", "n/a", "chưa có"}
FACT_COLS = ["ten_san_pham", "nhom", "dung_tich", "thanh_phan_noi_bat", "loai_da_phu_hop", "mui_huong", "xuat_xu",
             "han_su_dung", "chi_so_chong_nang", "cong_dung_tren_bao_bi", "cach_dung", "so_phieu_cong_bo"]
REQUIRED = ["dung_tich", "thanh_phan_noi_bat", "xuat_xu", "han_su_dung", "cong_dung_tren_bao_bi", "cach_dung"]
HARD = ("thieu_dong", "so_gach", "dai_tieu_de", "dai_mo_ta", "dai_gach", "tukhoa", "tu_cam", "so_ngoai_bang", "cum_ngoai_bang",
        "ro_ghi_chu", "cong_bo_khong_co_phieu", "khong_ghi_CAN_BO_SUNG", "trang_thai_sai", "truong_thieu_lech",
        "bao_dong_gia_CAN_BO_SUNG", "giong")


def is_missing(v): return v.strip().lower() in MISSING


def build_truth(spec_rows, forbidden):
    skus = {}
    for r in spec_rows:
        facts = {c: r[c] for c in FACT_COLS if c in r and not is_missing(r[c]) and r[c].strip().lower() != "đang chờ duyệt"}
        cert = r.get("so_phieu_cong_bo", "").strip()
        skus[r["sku"]] = {
            "missing_fields": [c for c in REQUIRED if is_missing(r.get(c, ""))],
            "fact_text": " | ".join(facts.values()),
            "pending_certificate": cert.lower() == "đang chờ duyệt",
            "has_certificate": bool(cert) and not is_missing(cert) and cert.lower() != "đang chờ duyệt",
            "note": r.get("ghi_chu_noi_bo", ""),
        }
    return {"brand": "Vườn Nhỏ", "forbidden": forbidden, "required": REQUIRED, "skus": skus}


def main():
    args = sys.argv[1:]
    skip = set()
    if "--bo-qua" in args:
        i = args.index("--bo-qua")
        skip = {x.strip() for x in args[i + 1].split(",") if x.strip()}
        unknown = skip - set(HARD)
        if unknown:
            raise SystemExit(f"--bo-qua: không có loại lỗi {sorted(unknown)}; các loại có: {', '.join(HARD)}")
        del args[i:i + 2]
    ghi = None
    if "--ghi" in args:
        i = args.index("--ghi")
        ghi = Path(args[i + 1])
        del args[i:i + 2]
    out_csv = args[0]
    spec = Path(args[1]) if len(args) > 1 else HERE / "thong_so.csv"
    bad = Path(args[2]) if len(args) > 2 else HERE / "tu_cam.txt"
    forbidden = [x.strip() for x in bad.read_text(encoding="utf-8").splitlines() if x.strip()]
    with open(spec, encoding="utf-8-sig", newline="") as f:
        spec_rows = list(csv.DictReader(f))
    truth = build_truth(spec_rows, forbidden)
    cham.ANS = truth; cham.FORBIDDEN = forbidden; cham.REQUIRED = REQUIRED
    res = cham.cham(out_csv, "kiem_hang_ngay")
    n_bad = 0
    lines = []
    for sku, v in res["per_sku"].items():
        hard = {k: x for k, x in v["loi"].items() if k in HARD and k not in skip}
        soft = {k: x for k, x in v["loi"].items() if k not in HARD or k in skip}
        if hard or soft:
            lines.append(("LỖI CỨNG " if hard else "XEM LẠI  ") + sku + " " + str(hard or soft))
        n_bad += bool(hard)
    t = res["tong"]
    tong = (f"{len(truth['skus'])} SKU: {len(truth['skus']) - n_bad} sạch, {n_bad} có lỗi cứng; "
            f"thiếu thông số {t['miss_sku_total']} (gắn cờ đúng {t['miss_fields_exact']}), báo động giả {t['false_alarm']}.")
    for ln in lines:
        print(ln)
    print("\n" + tong)
    if ghi:
        ghi.write_text("\n".join(lines + ["", tong]) + "\n", encoding="utf-8")
    sys.exit(1 if n_bad else 0)


if __name__ == "__main__":
    main()
