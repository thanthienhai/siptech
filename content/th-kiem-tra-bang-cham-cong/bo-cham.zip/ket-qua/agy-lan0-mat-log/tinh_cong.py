#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Chương trình tính công và phát hiện bất thường tháng 09/2026.
Tuân thủ đầy đủ quy định tại quy_dinh_cong_ty.md.
"""

import os
import csv
from datetime import datetime, timedelta

def parse_time(val):
    """
    Parse chuỗi thời gian từ máy chấm công.
    Trả về datetime hoặc None / 'INVALID'.
    """
    if val is None:
        return None
    val = str(val).strip()
    if not val or val.lower() == 'nan':
        return None
    try:
        if '-' in val:
            if len(val) >= 19:
                return datetime.strptime(val[:19], '%Y-%m-%d %H:%M:%S')
            elif len(val) >= 16:
                return datetime.strptime(val[:16], '%Y-%m-%d %H:%M')
        elif '/' in val:
            parts = val.split(' ')
            dparts = parts[0].split('/')
            day, month, year = int(dparts[0]), int(dparts[1]), int(dparts[2])
            tparts = parts[1].split(':')
            hour, minute = int(tparts[0]), int(tparts[1])
            second = int(tparts[2]) if len(tparts) > 2 else 0
            return datetime(year, month, day, hour, minute, second)
    except Exception:
        return 'INVALID'
    return 'INVALID'

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 1. Đọc danh sách nhân viên
    nhan_vien_path = os.path.join(base_dir, 'nhan_vien.csv')
    emp_list = []
    emp_dict = {}
    with open(nhan_vien_path, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            emp_list.append(row['ma_nv'])
            emp_dict[row['ma_nv']] = row
            
    nv_set = set(emp_list)

    # 2. Đọc lịch ca xoay
    lich_xoay_path = os.path.join(base_dir, 'lich_ca_xoay.csv')
    lc_dict = {}
    with open(lich_xoay_path, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            m = row['ma_nv']
            # Chuyển dd/mm/yyyy -> yyyy-mm-dd
            d_obj = datetime.strptime(row['ngay'], '%d/%m/%Y')
            d_str = d_obj.strftime('%Y-%m-%d')
            lc_dict[(m, d_str)] = row['ca']

    # 3. Đọc đơn nghỉ phép đã duyệt
    nghi_phep_path = os.path.join(base_dir, 'nghi_phep.csv')
    leaves_dict = {}
    with open(nghi_phep_path, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row['trang_thai'] == 'Đã duyệt':
                m = row['ma_nv']
                tu_d = datetime.strptime(row['tu_ngay'], '%d/%m/%Y')
                den_d = datetime.strptime(row['den_ngay'], '%d/%m/%Y')
                curr = tu_d
                while curr <= den_d:
                    leaves_dict[(m, curr.strftime('%Y-%m-%d'))] = row['loai']
                    curr += timedelta(days=1)

    # 4. Đọc dữ liệu chấm công và phân loại lỗi dữ liệu (DU_LIEU_LOI)
    cham_cong_path = os.path.join(base_dir, 'cham_cong.csv')
    valid_swipes = []
    du_lieu_loi = []
    
    with open(cham_cong_path, mode='r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for idx, row in enumerate(reader):
            m = row['ma_nv']
            mach = row['ma_may']
            t_raw = row['thoi_gian']
            
            # Kiểm tra mã NV hợp lệ
            if m not in nv_set:
                pt = parse_time(t_raw)
                d_str = pt.strftime('%Y-%m-%d') if isinstance(pt, datetime) else ""
                du_lieu_loi.append({
                    'ma_nv': m,
                    'ngay': d_str,
                    'loai': 'DU_LIEU_LOI',
                    'chi_tiet': f"mã {m} không có trong danh sách nhân viên, quẹt tại {mach}",
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f"Mã nhân viên {m} không tồn tại trong danh mục nhân sự của công ty nhưng có dữ liệu quẹt thẻ tại máy {mach}. Cần kiểm tra kỹ thuật máy chấm công hoặc cập nhật hồ sơ nhân sự."
                })
                continue
                
            pt = parse_time(t_raw)
            if pt is None:
                du_lieu_loi.append({
                    'ma_nv': m,
                    'ngay': "",
                    'loai': 'DU_LIEU_LOI',
                    'chi_tiet': f"thời gian quẹt để trống (NaN) tại máy {mach}",
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f"Dữ liệu quẹt thẻ của nhân viên {m} tại máy {mach} bị trống trường thời gian. Quản lý cần kiểm tra kỹ thuật kết nối hoặc bộ nhớ máy chấm công."
                })
                continue
            elif pt == 'INVALID':
                du_lieu_loi.append({
                    'ma_nv': m,
                    'ngay': "",
                    'loai': 'DU_LIEU_LOI',
                    'chi_tiet': f"thời gian '{t_raw}' không hợp lệ tại máy {mach}",
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f"Dữ liệu quẹt thẻ của nhân viên {m} tại máy {mach} có định dạng ngày giờ không hợp lệ ({t_raw}). Cần kiểm tra kỹ thuật đồng bộ dữ liệu trên máy chấm công."
                })
                continue
                
            # Quẹt hợp lệ
            # Bỏ phần giây theo quy định: 08:05:59 xem là 08:05
            pt_trunc = pt.replace(second=0, microsecond=0)
            valid_swipes.append({
                'ma_nv': m,
                'ma_may': mach,
                'dt_exact': pt,
                'dt': pt_trunc,
                'ngay': pt.strftime('%Y-%m-%d'),
                'gio': pt.strftime('%H:%M')
            })

    # Gom quẹt hợp lệ theo (ma_nv, ngay)
    swipes_by_day = {}
    for s in valid_swipes:
        key = (s['ma_nv'], s['ngay'])
        if key not in swipes_by_day:
            swipes_by_day[key] = []
        swipes_by_day[key].append(s)

    # Cấu hình ca làm việc (phút tính từ 00:00)
    # HC: 08:00 - 17:00, trừ nghỉ trưa 12:00-13:00 (720-780)
    # S:  06:00 - 14:00, không trừ nghỉ trưa
    # C:  14:00 - 22:00, không trừ nghỉ trưa
    shift_config = {
        'HC': {'start': 8 * 60, 'end': 17 * 60, 'has_lunch': True},
        'S':  {'start': 6 * 60, 'end': 14 * 60, 'has_lunch': False},
        'C':  {'start': 14 * 60, 'end': 22 * 60, 'has_lunch': False},
    }

    daily_records = []
    bat_thuong_list = list(du_lieu_loi)
    emp_monthly_ot = {m: 0 for m in emp_list}

    # Lặp qua từng nhân viên và từng ngày trong tháng 09/2026
    for m in emp_list:
        loai_ca_nv = emp_dict[m]['loai_ca']
        
        for day in range(1, 31):
            dt_curr = datetime(2026, 9, day)
            d_str = dt_curr.strftime('%Y-%m-%d')
            weekday = dt_curr.weekday() # 0: Thứ 2, ..., 5: Thứ 7, 6: Chủ nhật
            
            # 1. Xác định loại ngày
            if d_str in ['2026-09-01', '2026-09-02']:
                loai_ngay = 'LE'
            else:
                if loai_ca_nv == 'HC':
                    loai_ngay = 'OFF' if weekday in [5, 6] else 'HC'
                else: # XOAY
                    loai_ngay = lc_dict.get((m, d_str), 'OFF')
                    
            has_leave = (m, d_str) in leaves_dict
            raw_swipes = sorted(swipes_by_day.get((m, d_str), []), key=lambda x: x['dt_exact'])
            
            # Kiểm tra nghi quẹt hộ:
            # Hai quẹt Ở HAI MÁY KHÁC NHAU cách nhau <= 10 phút trong cùng ngày
            has_nghi_quet_ho = False
            quet_ho_details = []
            for i in range(len(raw_swipes)):
                for j in range(i + 1, len(raw_swipes)):
                    s1, s2 = raw_swipes[i], raw_swipes[j]
                    if s1['ma_may'] != s2['ma_may']:
                        diff_sec = abs((s2['dt_exact'] - s1['dt_exact']).total_seconds())
                        diff_min = abs((s2['dt'] - s1['dt']).total_seconds()) / 60.0
                        if diff_sec <= 600 or diff_min <= 10:
                            has_nghi_quet_ho = True
                            quet_ho_details.append((s1, s2, int(diff_min)))
                            
            # Bỏ quẹt trùng: hai quẹt CÙNG MÁY cách nhau <= 3 phút
            # Giữ quẹt đầu, bỏ quẹt sau, ghi nhận QUET_TRUNG
            filtered_swipes = []
            has_quet_trung = False
            quet_trung_details = []
            for s in raw_swipes:
                if filtered_swipes and filtered_swipes[-1]['ma_may'] == s['ma_may']:
                    diff_sec = (s['dt_exact'] - filtered_swipes[-1]['dt_exact']).total_seconds()
                    diff_min = (s['dt'] - filtered_swipes[-1]['dt']).total_seconds() / 60.0
                    if diff_sec <= 180 or diff_min <= 3:
                        has_quet_trung = True
                        quet_trung_details.append((filtered_swipes[-1], s, int(diff_min)))
                        continue
                filtered_swipes.append(s)
                
            # Ghi nhận bất thường QUET_TRUNG
            if has_quet_trung:
                prev_s, curr_s, d_m = quet_trung_details[0]
                bat_thuong_list.append({
                    'ma_nv': m,
                    'ngay': d_str,
                    'loai': 'QUET_TRUNG',
                    'chi_tiet': f"quẹt lúc {prev_s['gio']} và {curr_s['gio']} cùng máy {curr_s['ma_may']}, cách nhau {d_m} phút",
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f"Nhân viên {m} quẹt thẻ lặp lại trong vòng 3 phút trên cùng một máy chấm công. Hệ thống tự động ghi nhận lần quẹt đầu và loại bỏ lần sau."
                })
                
            # Ghi nhận bất thường NGHI_QUET_HO
            if has_nghi_quet_ho:
                s1, s2, d_m = quet_ho_details[0]
                bat_thuong_list.append({
                    'ma_nv': m,
                    'ngay': d_str,
                    'loai': 'NGHI_QUET_HO',
                    'chi_tiet': f"quẹt tại {s1['ma_may']} lúc {s1['gio']} và {s2['ma_may']} lúc {s2['gio']}, cách nhau {d_m} phút",
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f"Ghi nhận quẹt thẻ ở 2 chi nhánh khác nhau chỉ cách nhau {d_m} phút. Đề nghị người có thẩm quyền xác minh sự có mặt thực tế của nhân viên {m}, không tự ý kết luận gian lận."
                })

            # Chuẩn bị dòng bảng công ngày
            row_day = {
                'ma_nv': m,
                'ngay': d_str,
                'loai_ngay': loai_ngay,
                'gio_vao': '',
                'gio_ra': '',
                'gio_cong': '',
                'phut_tre': '',
                'phut_ve_som': '',
                'ot_phut': '',
                'trang_thai': ''
            }

            # Phân loại và tính toán theo loại ngày
            if loai_ngay == 'LE':
                if len(filtered_swipes) > 0:
                    row_day['trang_thai'] = 'CHO_XAC_NHAN'
                    row_day['gio_vao'] = filtered_swipes[0]['gio']
                    row_day['gio_ra'] = filtered_swipes[-1]['gio'] if len(filtered_swipes) > 1 else ''
                    bat_thuong_list.append({
                        'ma_nv': m,
                        'ngay': d_str,
                        'loai': 'LAM_NGAY_LE',
                        'chi_tiet': f"quẹt ngày lễ lúc vào {row_day['gio_vao']}" + (f", ra {row_day['gio_ra']}" if row_day['gio_ra'] else ""),
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} có quẹt thẻ làm việc vào ngày nghỉ lễ. Quản lý cần xác nhận có phân công làm việc ngày lễ hay không; chế độ ngày lễ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
                    })
                else:
                    row_day['trang_thai'] = 'NGHI'
                    
            elif loai_ngay == 'OFF':
                if len(filtered_swipes) > 0:
                    row_day['trang_thai'] = 'CHO_XAC_NHAN'
                    row_day['gio_vao'] = filtered_swipes[0]['gio']
                    row_day['gio_ra'] = filtered_swipes[-1]['gio'] if len(filtered_swipes) > 1 else ''
                    bat_thuong_list.append({
                        'ma_nv': m,
                        'ngay': d_str,
                        'loai': 'LAM_NGAY_NGHI',
                        'chi_tiet': f"quẹt ngày nghỉ lúc vào {row_day['gio_vao']}" + (f", ra {row_day['gio_ra']}" if row_day['gio_ra'] else ""),
                        'can_nguoi_quyet': 'CO',
                        'giai_thich': f"Nhân viên {m} phát sinh quẹt thẻ vào ngày nghỉ ca/cuối tuần. Quản lý cần xác nhận có phân công làm thêm ngày nghỉ không để có căn cứ tính công."
                    })
                else:
                    row_day['trang_thai'] = 'NGHI'
                    
            else: # Ngày làm việc thông thường: HC, S, C
                if has_leave:
                    if len(filtered_swipes) > 0:
                        row_day['trang_thai'] = 'CHO_XAC_NHAN'
                        row_day['gio_vao'] = filtered_swipes[0]['gio']
                        row_day['gio_ra'] = filtered_swipes[-1]['gio'] if len(filtered_swipes) > 1 else ''
                        bat_thuong_list.append({
                            'ma_nv': m,
                            'ngay': d_str,
                            'loai': 'CO_PHEP_NHUNG_QUET',
                            'chi_tiet': f"có đơn nghỉ phép nhưng quẹt thẻ vào {row_day['gio_vao']}" + (f", ra {row_day['gio_ra']}" if row_day['gio_ra'] else ""),
                            'can_nguoi_quyet': 'CO',
                            'giai_thich': f"Nhân viên {m} có đơn nghỉ phép đã duyệt nhưng vẫn phát sinh quẹt thẻ. Quản lý cần xác nhận nhân viên có đi làm thực tế hay không; quy định nghỉ phép cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
                        })
                    else:
                        row_day['trang_thai'] = 'PHEP'
                else:
                    if len(filtered_swipes) == 0:
                        # Vắng chưa ghi
                        row_day['trang_thai'] = 'CHO_XAC_NHAN'
                        bat_thuong_list.append({
                            'ma_nv': m,
                            'ngay': d_str,
                            'loai': 'VANG_CHUA_GHI',
                            'chi_tiet': f"vắng ca {loai_ngay}, 0 quẹt, không có đơn nghỉ phép",
                            'can_nguoi_quyet': 'CO',
                            'giai_thich': f"Nhân viên {m} không đi làm và chưa có đơn nghỉ phép được duyệt. Quản lý cần liên hệ nhân viên kiểm tra lý do vắng và xác nhận hình thức nghỉ."
                        })
                    elif len(filtered_swipes) == 1:
                        # Quẹt đơn lẻ
                        row_day['trang_thai'] = 'CHO_XAC_NHAN'
                        s_single = filtered_swipes[0]
                        s_m = s_single['dt'].hour * 60 + s_single['dt'].minute
                        c_start = shift_config[loai_ngay]['start']
                        c_end = shift_config[loai_ngay]['end']
                        
                        if s_m <= c_start + 120:
                            row_day['gio_vao'] = s_single['gio']
                            bat_thuong_list.append({
                                'ma_nv': m,
                                'ngay': d_str,
                                'loai': 'THIEU_RA',
                                'chi_tiet': f"vào {s_single['gio']}, thiếu quẹt ra",
                                'can_nguoi_quyet': 'CO',
                                'giai_thich': f"Nhân viên {m} có quẹt vào ca lúc {s_single['gio']} nhưng thiếu quẹt ra ca. Quản lý cần xác nhận giờ kết thúc làm việc thực tế với nhân viên."
                            })
                        elif s_m >= c_end - 120:
                            row_day['gio_ra'] = s_single['gio']
                            bat_thuong_list.append({
                                'ma_nv': m,
                                'ngay': d_str,
                                'loai': 'THIEU_VAO',
                                'chi_tiet': f"ra {s_single['gio']}, thiếu quẹt vào",
                                'can_nguoi_quyet': 'CO',
                                'giai_thich': f"Nhân viên {m} có quẹt ra ca lúc {s_single['gio']} nhưng thiếu quẹt vào ca. Quản lý cần xác nhận giờ bắt đầu làm việc thực tế với nhân viên."
                            })
                        else:
                            bat_thuong_list.append({
                                'ma_nv': m,
                                'ngay': d_str,
                                'loai': 'THIEU_KHONG_RO',
                                'chi_tiet': f"quẹt duy nhất lúc {s_single['gio']}, không rõ vào hay ra",
                                'can_nguoi_quyet': 'CO',
                                'giai_thich': f"Nhân viên {m} chỉ có 1 lần quẹt giữa ca lúc {s_single['gio']}, không đủ cơ sở xác định là vào hay ra. Quản lý cần xác nhận toàn bộ thời gian làm việc thực tế trong ngày."
                            })
                    else: # Có từ hai quẹt trở lên
                        row_day['gio_vao'] = filtered_swipes[0]['gio']
                        row_day['gio_ra'] = filtered_swipes[-1]['gio']
                        
                        if has_nghi_quet_ho:
                            row_day['trang_thai'] = 'CHO_XAC_NHAN'
                        else:
                            row_day['trang_thai'] = 'OK'
                            c_start = shift_config[loai_ngay]['start']
                            c_end = shift_config[loai_ngay]['end']
                            has_lunch = shift_config[loai_ngay]['has_lunch']
                            
                            v_m = filtered_swipes[0]['dt'].hour * 60 + filtered_swipes[0]['dt'].minute
                            r_m = filtered_swipes[-1]['dt'].hour * 60 + filtered_swipes[-1]['dt'].minute
                            
                            # Đi trễ: giờ vào - giờ vào ca, nếu > 5 phút dung sai
                            if v_m - c_start > 5:
                                phut_tre = v_m - c_start
                                row_day['phut_tre'] = phut_tre
                                bat_thuong_list.append({
                                    'ma_nv': m,
                                    'ngay': d_str,
                                    'loai': 'DI_TRE',
                                    'chi_tiet': f"vào {filtered_swipes[0]['gio']}, trễ {phut_tre} phút",
                                    'can_nguoi_quyet': 'KHONG',
                                    'giai_thich': f"Nhân viên {m} vào ca lúc {filtered_swipes[0]['gio']}, trễ {phut_tre} phút so với giờ bắt đầu ca {loai_ngay}. Quản lý cần kiểm tra lý do đến trễ để có phương án điều phối."
                                })
                            else:
                                row_day['phut_tre'] = 0
                                
                            # Về sớm: giờ ra ca - giờ ra, nếu > 5 phút dung sai
                            if c_end - r_m > 5:
                                phut_ve_som = c_end - r_m
                                row_day['phut_ve_som'] = phut_ve_som
                                bat_thuong_list.append({
                                    'ma_nv': m,
                                    'ngay': d_str,
                                    'loai': 'VE_SOM',
                                    'chi_tiet': f"ra {filtered_swipes[-1]['gio']}, sớm {phut_ve_som} phút",
                                    'can_nguoi_quyet': 'KHONG',
                                    'giai_thich': f"Nhân viên {m} rời ca lúc {filtered_swipes[-1]['gio']}, sớm {phut_ve_som} phút so với giờ kết thúc ca {loai_ngay}. Quản lý cần kiểm tra lý do về sớm của nhân viên."
                                })
                            else:
                                row_day['phut_ve_som'] = 0
                                
                            # Làm thêm giờ (OT): chỉ tính khi quẹt ra muộn hơn giờ ra ca >= 30 phút
                            if r_m - c_end >= 30:
                                ot_phut = r_m - c_end
                                row_day['ot_phut'] = ot_phut
                                emp_monthly_ot[m] += ot_phut
                                if ot_phut > 180:
                                    bat_thuong_list.append({
                                        'ma_nv': m,
                                        'ngay': d_str,
                                        'loai': 'OT_VUOT_NGUONG',
                                        'chi_tiet': f"ra lúc {filtered_swipes[-1]['gio']}, làm thêm {ot_phut} phút (vượt ngưỡng 180 phút)",
                                        'can_nguoi_quyet': 'CO',
                                        'giai_thich': f"Thời gian làm thêm trong ngày của nhân viên {m} đạt {ot_phut} phút, vượt ngưỡng 180 phút/ngày theo quy định công ty. Quản lý cần kiểm tra phê duyệt làm thêm; quy định làm thêm giờ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
                                    })
                            else:
                                row_day['ot_phut'] = 0
                                
                            # Giờ công: số giờ nằm trong khung ca
                            t_start = c_start if (v_m - c_start <= 5) else v_m
                            t_end = c_end if (c_end - r_m <= 5) else min(r_m, c_end)
                            
                            eff_m = 0
                            if t_end > t_start:
                                eff_m = t_end - t_start
                                if has_lunch:
                                    # Trừ phần giao với 12:00-13:00 (720 đến 780)
                                    lunch_s = max(t_start, 12 * 60)
                                    lunch_e = min(t_end, 13 * 60)
                                    if lunch_e > lunch_s:
                                        eff_m -= (lunch_e - lunch_s)
                                        
                            row_day['gio_cong'] = f"{round(eff_m / 60.0, 2):.2f}"

            daily_records.append(row_day)

    # Kiểm tra ngưỡng OT tháng (> 2400 phút = 40 giờ)
    for m in emp_list:
        tot_ot = emp_monthly_ot[m]
        if tot_ot > 2400:
            bat_thuong_list.append({
                'ma_nv': m,
                'ngay': 'THANG',
                'loai': 'OT_THANG_VUOT',
                'chi_tiet': f"tổng làm thêm ngày thường {tot_ot} phút ({tot_ot/60:.2f} giờ, vượt ngưỡng 2400 phút)",
                'can_nguoi_quyet': 'CO',
                'giai_thich': f"Tổng thời gian làm thêm trong tháng của nhân viên {m} đạt {tot_ot} phút ({tot_ot/60:.2f} giờ), vượt ngưỡng 2400 phút/tháng theo quy định công ty. Quản lý cần rà soát khối lượng công việc; quy định làm thêm giờ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
            })

    # Sắp xếp bất thường để dễ theo dõi
    def anom_sort_key(item):
        return (item['ma_nv'], item['ngay'] if item['ngay'] else '9999-99-99', item['loai'])
    bat_thuong_list.sort(key=anom_sort_key)

    # 5. Ghi tệp bang_cong_ngay.csv
    bang_cong_ngay_path = os.path.join(base_dir, 'bang_cong_ngay.csv')
    daily_fields = [
        'ma_nv', 'ngay', 'loai_ngay', 'gio_vao', 'gio_ra',
        'gio_cong', 'phut_tre', 'phut_ve_som', 'ot_phut', 'trang_thai'
    ]
    with open(bang_cong_ngay_path, mode='w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=daily_fields)
        writer.writeheader()
        writer.writerows(daily_records)

    # 6. Ghi tệp bat_thuong.csv
    bat_thuong_path = os.path.join(base_dir, 'bat_thuong.csv')
    anom_fields = ['ma_nv', 'ngay', 'loai', 'chi_tiet', 'can_nguoi_quyet', 'giai_thich']
    with open(bat_thuong_path, mode='w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=anom_fields)
        writer.writeheader()
        writer.writerows(bat_thuong_list)

    # 7. Tổng hợp theo người và ghi tệp tong_hop_nguoi.csv
    tong_hop_records = []
    daily_by_emp = {}
    for r in daily_records:
        daily_by_emp.setdefault(r['ma_nv'], []).append(r)
        
    anom_by_emp = {}
    for a in bat_thuong_list:
        anom_by_emp.setdefault(a['ma_nv'], []).append(a)

    for m in emp_list:
        e_days = daily_by_emp.get(m, [])
        e_anoms = anom_by_emp.get(m, [])
        
        ok_days = [r for r in e_days if r['trang_thai'] == 'OK']
        ngay_cong = len(ok_days)
        tong_gio_cong = round(sum(float(r['gio_cong']) for r in ok_days), 2)
        
        # Số lần trễ và tổng phút trễ
        tre_days = [r for r in ok_days if r['phut_tre'] != '' and int(r['phut_tre']) > 0]
        so_lan_tre = len(tre_days)
        tong_phut_tre = sum(int(r['phut_tre']) for r in tre_days)
        
        # Số lần về sớm và tổng phút về sớm
        som_days = [r for r in ok_days if r['phut_ve_som'] != '' and int(r['phut_ve_som']) > 0]
        so_lan_ve_som = len(som_days)
        tong_phut_ve_som = sum(int(r['phut_ve_som']) for r in som_days)
        
        # OT giờ
        ot_days = [r for r in ok_days if r['ot_phut'] != '' and int(r['ot_phut']) > 0]
        tong_ot_phut = sum(int(r['ot_phut']) for r in ot_days)
        tong_ot_gio = round(tong_ot_phut / 60.0, 2)
        
        so_ngay_phep = sum(1 for r in e_days if r['trang_thai'] == 'PHEP')
        so_ngay_vang_chua_ghi = sum(1 for a in e_anoms if a['loai'] == 'VANG_CHUA_GHI')
        so_ngay_cho_xac_nhan = sum(1 for r in e_days if r['trang_thai'] == 'CHO_XAC_NHAN')
        so_bat_thuong = len(e_anoms)
        
        tong_hop_records.append({
            'ma_nv': m,
            'ngay_cong': ngay_cong,
            'tong_gio_cong': f"{tong_gio_cong:.2f}",
            'so_lan_tre': so_lan_tre,
            'tong_phut_tre': tong_phut_tre,
            'so_lan_ve_som': so_lan_ve_som,
            'tong_phut_ve_som': tong_phut_ve_som,
            'tong_ot_gio': f"{tong_ot_gio:.2f}",
            'so_ngay_phep': so_ngay_phep,
            'so_ngay_vang_chua_ghi': so_ngay_vang_chua_ghi,
            'so_ngay_cho_xac_nhan': so_ngay_cho_xac_nhan,
            'so_bat_thuong': so_bat_thuong
        })

    tong_hop_path = os.path.join(base_dir, 'tong_hop_nguoi.csv')
    summary_fields = [
        'ma_nv', 'ngay_cong', 'tong_gio_cong', 'so_lan_tre', 'tong_phut_tre',
        'so_lan_ve_som', 'tong_phut_ve_som', 'tong_ot_gio', 'so_ngay_phep',
        'so_ngay_vang_chua_ghi', 'so_ngay_cho_xac_nhan', 'so_bat_thuong'
    ]
    with open(tong_hop_path, mode='w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=summary_fields)
        writer.writeheader()
        writer.writerows(tong_hop_records)

    # 8. In ra màn hình tóm tắt
    print("==================================================")
    print("HOÀN THÀNH TÍNH CÔNG VÀ XUẤT 3 TỆP CSV THÀNH CÔNG!")
    print("==================================================")
    print(f"1. bang_cong_ngay.csv: {len(daily_records) + 1} dòng (gồm header, {len(daily_records)} bản ghi)")
    print(f"2. bat_thuong.csv:     {len(bat_thuong_list) + 1} dòng (gồm header, {len(bat_thuong_list)} bản ghi)")
    print(f"3. tong_hop_nguoi.csv: {len(tong_hop_records) + 1} dòng (gồm header, {len(tong_hop_records)} bản ghi)")
    print("\nSố lượng bất thường theo từng loại:")
    
    anom_counts = {}
    for a in bat_thuong_list:
        anom_counts[a['loai']] = anom_counts.get(a['loai'], 0) + 1
        
    for loai in sorted(anom_counts.keys()):
        print(f"  - {loai:<20}: {anom_counts[loai]:>2} trường hợp")
    print(f"  TỔNG CỘNG             : {len(bat_thuong_list):>2} trường hợp")
    print("==================================================")

if __name__ == '__main__':
    main()
