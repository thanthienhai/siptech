# Báo cáo đánh giá khách hàng: những việc nên sửa trước

Nguồn: `danh-gia.csv` (Google Maps, Shopee Food, Facebook), ngày đăng từ 24/08/2026 đến 15/11/2026. Mọi con số dưới đây do `tong-hop.py` đếm từ `y-kien.csv`, `danh-gia.csv` và `loai-bo.csv`.

## Tổng quan

- Tổng số đánh giá trong file: **250**
- Số bài loại bỏ: **8** (4 trùng nguyên văn: R117, R171, R177, R205; 3 quảng cáo/spam: R070, R122, R191; 1 không phải đánh giá: R228). Chi tiết ở `loai-bo.csv`.
- Số bài được phân tích: **242**, tách thành **404** ý kiến (`y-kien.csv`).
- Số bài có ý kiến cần người đọc (`CAN_NGUOI_DOC`): **16** (mỉa mai hoặc không rõ nghĩa; không tự đoán).
- Đánh giá nguy cấp: **18** dòng trong `nguy-cap.csv`: 7 ngộ độc/dị vật, 5 thái độ nhân viên, 6 tính tiền/khuyến mãi/nhận tiền không giao. 4 dòng đánh dấu "nghi" (R155, R198, R135, R183).

### Bảng chủ đề x sắc thái (số ý kiến)

| Chủ đề | Tích cực | Tiêu cực | Trung tính | Cần người đọc | Tổng |
|---|---:|---:|---:|---:|---:|
| gia | 14 | 44 | 11 | 2 | 71 |
| phuc_vu | 39 | 31 | 9 | 3 | 82 |
| chat_luong | 53 | 28 | 14 | 2 | 97 |
| giao_hang | 19 | 30 | 6 | 3 | 58 |
| khong_gian | 30 | 19 | 8 | 3 | 60 |
| ve_sinh | 4 | 19 | 4 | 1 | 28 |
| khac | 2 | 1 | 3 | 2 | 8 |
| **Tổng** | **161** | **172** | **55** | **16** | **404** |

Cách đọc: giá là chủ đề bị chê nhiều nhất (44 ý tiêu cực so với 14 tích cực). Chất lượng đồ uống/đồ ăn được khen nhiều nhất (53 ý tích cực). Vệ sinh ít được nhắc nhưng gần như toàn chê (19 tiêu cực so với 4 tích cực).

## Xu hướng theo tuần

Tuần tính từ thứ Hai; số liệu chi tiết ở `xu-huong-tuan.csv`. Mỗi tuần chỉ có vài ý đến vài chục ý, nên đây là dấu hiệu để theo dõi, chưa phải kết luận chắc.

| Tuần bắt đầu | Tích cực | Tiêu cực |
|---|---:|---:|
| 24/08 | 10 | 10 |
| 31/08 | 16 | 10 |
| 07/09 | 18 | 9 |
| 14/09 | 19 | 14 |
| 21/09 | 15 | 12 |
| 28/09 | 17 | 13 |
| 05/10 | 16 | 24 |
| 12/10 | 13 | 14 |
| 19/10 | 11 | 20 |
| 26/10 | 5 | 19 |
| 02/11 | 9 | 16 |
| 09/11 | 12 | 11 |

- **Từ tuần 05/10 ý tiêu cực vượt ý tích cực** ở 5 trong 6 tuần (05/10, 12/10, 19/10, 26/10, 02/11); trước đó, trừ tuần đầu 24/08 (bằng nhau 10-10), tích cực luôn nhiều hơn. Thấp nhất là tuần 26/10: 5 tích cực, 19 tiêu cực. Tuần 09/11 có dấu hiệu dịu lại (12 so với 11).
- **Giá:** trước tuần 28/09 chỉ có 3 ý tiêu cực. Từ tuần 28/09 đến hết dữ liệu có 41 ý tiêu cực (6, 8, 6, 7, 4, 7, 3 theo từng tuần). 27 ý trong nhóm giá tiêu cực nhắc việc tăng giá, ly không đổi hoặc nhỏ lại, đắt hơn quán bên cạnh.
- **Giao hàng:** 7 ý tiêu cực trong 6 tuần đầu (24/08 đến 28/09), rồi 23 ý trong 5 tuần từ 05/10 đến 08/11 (5, 4, 5, 5, 4 theo tuần). Tuần 09/11 là 0 nhưng dữ liệu chỉ đến 15/11, chưa đủ để nói đã hết.
- **Vệ sinh:** 1 ý tiêu cực trong 3 tuần đầu, rồi 18 ý trong 8 tuần từ 21/09 (3, 0, 3, 0, 3, 3, 2, 4). Tuần 09/11 là tuần cao nhất.
- **Phục vụ:** ý tiêu cực cao nhất ở tuần 14/09 (7 ý), sau đó giảm về 0 đến 4 ý mỗi tuần.
- **Không gian:** ý tiêu cực nhiều ở 4 tuần đầu (12 trong 19 ý), sau đó chỉ 0 đến 2 ý mỗi tuần.
- **Ngộ độc/dị vật:** 7 dòng nguy cấp đều đăng trong khoảng 15/10 đến 28/10 (R155, R170, R175, R178, R181, R193, R198).
- **Thái độ nhân viên:** 5 dòng nguy cấp đều đăng trong tháng 9 (08/09 đến 26/09). Dữ liệu không có bài tương tự sau 26/09, nhưng điều đó không chứng minh vấn đề đã hết.

## Việc 1: Điều tra ngay các ca nghi ngộ độc và côn trùng trong đồ uống

**Vì sao:** Trong 14 ngày (15/10 đến 28/10) có 7 bài nói về sức khỏe hoặc dị vật. Ca nặng nhất là hai vợ chồng đi cấp cứu sau khi ăn bánh mì chả (R170). R175 và R181 cùng nhắc món tiramisu: một trẻ 6 tuổi nôn và sốt, một khách đau bụng đi ngoài. R193 nói đến ly sữa chua cacao có mùi lạ rồi đau bụng. R178 có chụp hình con gián trong ly nước ép cam. R198 và R155 là hai trường hợp "nghi" (bánh croissant hình như bị ôi, ly nước có mùi lạ). R206 cho thấy khách đã bắt đầu e ngại vì chuyện đau bụng. Với quán ăn uống, đây là rủi ro lớn nhất: ảnh hưởng sức khỏe, có thể kéo theo khiếu nại hoặc báo cơ quan quản lý.

**Đề xuất hành động:**
- Hôm nay: tạm ngưng bán các món bị nhắc (bánh mì chả, tiramisu, sữa chua cacao, croissant) cho đến khi kiểm tra xong nguồn nguyên liệu và hạn dùng.
- Giữ lại mẫu và nguyên liệu còn của các mẻ đó; rà lại nhiệt độ bảo quản lạnh và quy trình vệ sinh dụng cụ làm nước ép.
- Liên hệ trực tiếp các khách đã viết (qua phản hồi trên nền tảng) để hỏi thăm, xin thông tin ngày giờ mua, và xin lỗi. Không tự kết luận nguyên nhân khi chưa có kết quả kiểm tra.
- Chọn một người phụ trách ghi lại từng ca và kết quả xử lý.

**Bằng chứng:**
> [R170] "tối cả hai vợ chồng nôn mửa với tiêu chảy, phải đi cấp cứu"
> [R175] "con mình 6 tuổi ăn xong 2 tiếng sau nôn và sốt"
> [R178] "mình thấy 1 con gián nhỏ nổi trong ly nước ép cam"

## Việc 2: Chấn chỉnh thái độ nhân viên và quản lý, kèm bố trí đủ người giờ cao điểm

**Vì sao:** Có 5 bài kể nhân viên chửi, quát, ném menu hoặc đuổi khách (R039, R057, R066, R083, R091), trong đó có thu ngân và quản lý, có lần diễn ra trước mặt cả quán và khách nước ngoài. Khách nói rõ sẽ không quay lại (R039). Cùng lúc, thiếu người giờ cao điểm được nhắc ở 6 ý tiêu cực (R044, R061, R065, R100, R223, R247) và chờ lâu hoặc phục vụ chậm ở ít nhất 9 ý. Phần lớn ý khen phục vụ vẫn rất tốt (39 ý tích cực), nên đây là vấn đề của một số người/ca làm, không phải toàn bộ đội ngũ.

**Đề xuất hành động:**
- Chủ quán nói chuyện riêng với người bị nhắc (thu ngân ở R039, nhân viên ca tối ở R057, quản lý ở R083, nhân viên nữ ở quầy ở R091); xác minh bằng ca làm việc và camera nếu có.
- Đặt quy tắc ứng xử bằng văn bản: khách hỏi giá hoặc xin nước lọc không bị từ chối hay quát; nếu hết chỗ thì giải thích lịch sự.
- Xem lại số người mỗi ca giờ đông; khi quá tải, báo khách thời gian chờ thay vì để khách hỏi nhiều lần.
- Phản hồi công khai và xin lỗi ở các bài trên Google Maps.

**Bằng chứng:**
> [R039] "bạn thu ngân chửi luôn 'mù hả không đọc menu à' trước mặt cả quán"
> [R083] "Quản lý đứng quầy quát khách vì để xe sai chỗ, dùng từ rất khó nghe"
> [R065] "nhân viên ít, giờ cao điểm xoay không kịp"

## Việc 3: Làm rõ giá và bill: tính tiền sai, phụ thu không báo, tăng giá, khuyến mãi

**Vì sao:** Giá là chủ đề tiêu cực nhiều nhất (44 ý) và gần như toàn bộ xuất hiện từ cuối tháng 9. Có hai lớp vấn đề. (1) Sự việc tính tiền cụ thể: bill ghi dư ly (R149), thu thêm 10% phí dịch vụ không niêm yết (R216), tính tiền size L nhưng đưa size M (R219), bill cao hơn menu 5k (R135, đã sửa khi khách nhắc), khuyến mãi mua 1 tặng 1 trên fanpage nhưng ở quán nói đã hết (R183). Đây là loại bài khách dễ gọi là "lừa" và nhắc người khác soi bill. (2) Tăng giá: 27 ý nhắc tăng giá, ly không đổi hoặc nhỏ lại, hoặc đắt hơn quán bên cạnh; 4 bài than "lên giá mà không báo trước" (R118, R187, R195, R218).

Lưu ý dữ liệu: cùng món trà đào cam sả, khách ghi các mức giá rất khác nhau (35k ở R106 và R238; 49k ở R224; 55k ở R189; 59k ở R150; 65k ở R215). Chủ quán cần đối chiếu bảng giá thật và xem giá trên Shopee Food/Facebook có khác giá tại quán không; tôi không thể xác định điều này từ file.

**Đề xuất hành động:**
- Kiểm tra máy tính tiền và phần mềm: lỗi cộng dư ly, phí dịch vụ tự bật, lệch giá menu và bill, chọn nhầm size.
- Nếu có thu phí dịch vụ thì ghi rõ trên menu và báo ở quầy; nếu không chủ trương thu thì tắt.
- Khuyến mãi: gỡ bảng và bài đăng khi hết chương trình, ghi rõ ngày kết thúc.
- Khi tăng giá: dán thông báo, và giải thích nếu kích cỡ ly thay đổi. Hướng dẫn thu ngân hoàn tiền ngay khi khách báo sai bill.

**Bằng chứng:**
> [R149] "Bill ghi 2 ly bạc xỉu mà mình chỉ gọi 1, báo thì nhân viên bảo máy tính tự tính nên cứ trả đủ"
> [R216] "Cuối bill tự cộng 10% phí dịch vụ, menu không ghi chỗ nào, hỏi thì nói quy định mới"
> [R151] "Giá lên mà ly thì nhỏ lại?? 55k 1 ly cf muối mà uống 3 ngụm hết, ko đáng tiền"

## Việc 4: Sửa khâu giao hàng trên Shopee Food (trễ, đóng gói, thiếu món, đơn không giao)

**Vì sao:** Cả 58 ý về giao hàng đều đến từ Shopee Food, và 30 ý là tiêu cực, tăng rõ từ tuần 05/10. Các lỗi lặp lại: giao chậm gần 1 tiếng (7 ý), nước đổ ra túi hoặc đóng gói ẩu (7 ý), đồ ăn nguội và thiếu món (7 ý), shipper không bắt máy và đồ tới trễ (4 ý), giao nhầm món (3 ý). Nặng nhất là R197: khách đã trả tiền, quán bấm hoàn thành đơn mà không giao, rồi cúp máy, mất 189k. Đây vừa là vấn đề giao hàng vừa là rủi ro bị coi là lừa đảo. Mặt tích cực: có 19 ý khen giao nhanh, đóng gói kỹ, shipper thân thiện, nên làm được.

**Đề xuất hành động:**
- Xử lý ngay đơn ở R197: liên hệ khách, hoàn tiền, kiểm tra vì sao đơn bị bấm hoàn thành.
- Đóng gói: dùng nắp/ly có khóa, túi có đáy, và kiểm tra lại món trước khi giao để tránh thiếu món.
- Đồ ăn: dùng túi giữ nhiệt; báo thời gian chuẩn bị đúng trên app để tránh trễ.
- Đặt một người trực điện thoại cho đơn Shopee Food giờ cao điểm để nghe máy shipper và khách.

**Bằng chứng:**
> [R197] "quán bấm hoàn thành đơn mà không giao, gọi lại thì cúp máy. Mất 189k"
> [R143] "đóng gói ẩu nên đổ hết 1/3 ra túi"
> [R174] "Giao chậm hơn dự kiến gần 1 tiếng"

## Việc 5: Làm sạch và giữ vệ sinh khu phục vụ (ly, bàn, quầy bánh, sàn)

**Vì sao:** Vệ sinh ít được nhắc (28 ý) nhưng 19 ý là tiêu cực và tăng từ tuần 21/09 (18 trong 19 ý). Các lỗi lặp lại: bàn dính nước ngọt cũ chưa lau (6 ý), ly còn dấu son môi chưa rửa sạch (4 ý), ruồi bay quanh quầy bánh (3 ý), sàn trơn có vết ướt (3 ý), nhà vệ sinh bẩn, hết giấy (2 ý). Những lỗi này cũng nằm trong bối cảnh Việc 1: R206 nói rõ khách ngại hơn vì chuyện đau bụng và thấy bàn ghế vẫn dính nước cũ. Ly còn son môi và ruồi quanh quầy bánh là hình ảnh có thể khiến khách nghi ngờ cả khâu chế biến.

**Đề xuất hành động:**
- Lập bảng kiểm vệ sinh theo giờ (lau bàn, soi ly sau khi rửa, kiểm tra nhà vệ sinh và giấy, lau sàn kèm biển cảnh báo).
- Che đậy quầy bánh, xử lý ruồi (bẫy, kín cửa, đổ rác đúng giờ).
- Chọn người ký xác nhận mỗi ca; kiểm tra bất ngờ vài lần mỗi tuần.

**Bằng chứng:**
> [R246] "Có ruồi bay quanh quầy bánh"
> [R247] "Ly còn dấu son môi chưa rửa sạch"
> [R207] "Bàn dính nước ngọt cũ chưa lau"

## Ghi chú: những gì chưa nằm trong 5 việc và những điều cần người quyết

- **Chưa xếp vào 5 việc:** tiếng ồn và nhạc to (5 ý tiêu cực trong khong_gian: R011, R064, R065, R142, R239), ghế cứng (R214), món nhạt hoặc ngọt gắt (nằm trong chat_luong, 28 ý tiêu cực). Đây là các điểm nên theo dõi tiếp.
- **Điểm mạnh nên giữ:** chất lượng đồ uống/đồ ăn được khen nhiều nhất (53 ý tích cực), nhân viên thân thiện, nhớ khách quen, wifi/ổ cắm/view ban công được nhiều khách nhắc tốt.
- **16 bài cần người đọc** (`CAN_NGUOI_DOC`): R029, R040, R054, R075, R077, R096, R126, R146, R159, R169, R202, R211, R217, R225, R236, R245. Phần lớn là mỉa mai (nghe như khen nhưng có thể là chê) nên tôi không tự gán sắc thái; R054 và R211 không rõ nghĩa.
- **Quyết định phán đoán cần người xem lại:** (a) R191 ("Quán bên kia đường ngon hơn nhiều...") bị loại là spam vì giống quảng cáo quán khác; nếu chủ quán thấy đây là đánh giá thật thì cần thêm lại. (b) Các bài "lên giá mà không báo trước" tôi xếp vào chủ đề giá, không xếp vào nguy cấp `lua_dao`, vì đây là tăng giá niêm yết chứ không phải thu thêm khi tính tiền. (c) R144 và R173 gần giống nhau (chỉ khác chữ hoa) nên không bị coi là trùng nguyên văn.
