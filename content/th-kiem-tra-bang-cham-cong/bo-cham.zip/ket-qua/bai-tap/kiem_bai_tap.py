"""Kiểm kết quả ba bài tập ở bài 4 bằng code (không dùng mô hình).

Chạy:
  python -X utf8 ket-qua/bai-tap/kiem_bai_tap.py 1 <thư mục có kết quả tinh_cong.py>      # bài tập 1: đổi giờ ca sáng
  python -X utf8 ket-qua/bai-tap/kiem_bai_tap.py 2 <thư mục có kết quả tinh_cong.py>      # bài tập 2: thêm ngày lễ 15/09
  python -X utf8 ket-qua/bai-tap/kiem_bai_tap.py 3 <thư mục đã ẩn danh + kết quả> <bang-ma-cua-toi.csv>   # bài tập 3: tự ẩn danh

Các số kỳ vọng của bài 1 và 2 là [Đo được]: chạy ket-qua/claude-lan1/tinh_cong.py (bản Claude Code lần 1) sau khi chỉ sửa đúng một dòng như đề, trên du-lieu/an-danh.
Nếu bạn dùng tinh_cong.py của bản khác (ví dụ của agy) thì kết quả có thể lệch vì cách hiểu quy định khác nhau.
"""
import csv, re, sys, unicodedata
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
BAI = HERE.parent.parent                      # thư mục bài toán
BASE = BAI / "ket-qua" / "claude-lan1"        # đầu ra mẫu (mã ẩn danh của bản mẫu)
BANG_MAU = BAI / "ket-qua" / "bang-ma-hoa.csv"
GOC = BAI / "du-lieu" / "goc"

def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def tong_ot(d):
    return round(sum(float(r["tong_ot_gio"] or 0) for r in rd(Path(d) / "tong_hop_nguoi.csv")), 2)

KY_VONG = {
    "1": {   # ca sáng S: 06:00-14:00 -> 05:30-13:30
        "dem": {"DI_TRE": 108, "VE_SOM": 3, "THIEU_RA": 5, "THIEU_VAO": 3, "THIEU_KHONG_RO": 3, "QUET_TRUNG": 6, "OT_VUOT_NGUONG": 3, "OT_THANG_VUOT": 1,
                "VANG_CHUA_GHI": 6, "LAM_NGAY_LE": 3, "LAM_NGAY_NGHI": 4, "NGHI_QUET_HO": 4, "CO_PHEP_NHUNG_QUET": 2, "DU_LIEU_LOI": 3},
        "tong": 154, "ok": 501, "le": 50, "ot": 165.98,
    },
    "2": {   # thêm 15/09 vào ngày lễ
        "dem": {"DI_TRE": 12, "VE_SOM": 5, "LAM_NGAY_LE": 26, "THIEU_RA": 5, "THIEU_VAO": 3, "THIEU_KHONG_RO": 3, "QUET_TRUNG": 6, "OT_VUOT_NGUONG": 3,
                "OT_THANG_VUOT": 1, "VANG_CHUA_GHI": 6, "LAM_NGAY_NGHI": 4, "NGHI_QUET_HO": 4, "CO_PHEP_NHUNG_QUET": 2, "DU_LIEU_LOI": 3},
        "tong": 83, "ok": 478, "le": 75, "ot": 100.25,
    },
}

def kiem_12(n, d):
    d = Path(d); kv = KY_VONG[n]; loi = []
    bt = rd(d / "bat_thuong.csv"); bc = rd(d / "bang_cong_ngay.csv")
    dem = Counter(r["loai"] for r in bt)
    for loai, v in kv["dem"].items():
        if dem.get(loai, 0) != v: loi.append(f"{loai}: có {dem.get(loai, 0)}, cần {v}")
    if len(bt) != kv["tong"]: loi.append(f"tổng dòng bat_thuong: có {len(bt)}, cần {kv['tong']}")
    st = Counter(r["trang_thai"] for r in bc)
    if st.get("OK", 0) != kv["ok"]: loi.append(f"số ngày OK: có {st.get('OK', 0)}, cần {kv['ok']}")
    if abs(tong_ot(d) - kv["ot"]) > 0.011: loi.append(f"tổng làm thêm: có {tong_ot(d)} giờ, cần {kv['ot']}")
    le = sum(1 for r in bc if r["loai_ngay"] == "LE")
    if n == "2" and le != kv["le"]: loi.append(f"số dòng loai_ngay = LE: có {le}, cần {kv['le']}")
    print(f"bài tập {n}: bat_thuong {len(bt)} dòng; OK {st.get('OK', 0)}; DI_TRE {dem.get('DI_TRE', 0)}; VE_SOM {dem.get('VE_SOM', 0)}; LAM_NGAY_LE {dem.get('LAM_NGAY_LE', 0)}; dòng LE {le}; tổng làm thêm {tong_ot(d)} giờ")
    return loi

def bo_dau(s):
    s = unicodedata.normalize("NFD", s).replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()

def kiem_3(d, bang):
    d = Path(d); loi = []
    nv_goc = rd(GOC / "nhan_vien.csv")
    # (a) cấu trúc bốn tệp đầu vào: không còn cột nhận dạng
    for ten in ("cham_cong.csv", "lich_ca_xoay.csv", "nghi_phep.csv", "nhan_vien.csv"):
        if not (d / ten).exists(): loi.append(f"thiếu {ten}"); continue
        cot = list(rd(d / ten)[0].keys())
        for xau in ("Họ tên", "Phòng ban", "Ghi chú"):
            if xau in cot: loi.append(f"{ten}: còn cột {xau}")
    # (b) rò rỉ: họ tên (có dấu / không dấu) và mã gốc trong bốn tệp đầu vào
    blob = "\n".join((d / t).read_text(encoding="utf-8-sig") for t in ("cham_cong.csv", "lich_ca_xoay.csv", "nghi_phep.csv", "nhan_vien.csv") if (d / t).exists())
    bl = bo_dau(blob)
    for r in nv_goc:
        if r["Họ tên"] in blob or bo_dau(r["Họ tên"]) in bl: loi.append(f"lộ họ tên: {r['Họ tên']}")
        if re.search(rf"(?<![\w-]){re.escape(r['Mã NV'])}(?![\w:/-])", blob): loi.append(f"lộ mã gốc: {r['Mã NV']}")
    for kw in ("Kế toán", "Kinh doanh", "khám bệnh", "đi du lịch", "về quê"):
        if kw.lower() in blob.lower(): loi.append(f"lộ từ khóa: {kw}")
    # (c) kết quả không đổi: dịch mã ẩn danh của bạn và của bản mẫu về họ tên rồi so
    # mã thẻ lạ (không có trong nhan_vien.csv) gọi chung là "(mã lạ)" để mỗi người đặt tên tùy ý
    hop_le = {r["ma_nv"] for r in rd(d / "nhan_vien.csv")} if (d / "nhan_vien.csv").exists() else set()
    ten_cua_toi = {r["ma_an_danh"]: (r["ho_ten"] if r["ma_an_danh"] in hop_le else "(mã lạ)") for r in rd(bang)}
    hop_le_mau = {r["ma_nv"] for r in rd(BAI / "du-lieu" / "an-danh" / "nhan_vien.csv")}
    ten_mau = {r["ma_an_danh"]: (r["ho_ten"] if r["ma_an_danh"] in hop_le_mau else "(mã lạ)") for r in rd(BANG_MAU)}
    for ten in ("bang_cong_ngay.csv", "bat_thuong.csv", "tong_hop_nguoi.csv"):
        if not (d / ten).exists(): loi.append(f"thiếu kết quả {ten} (đã chạy tinh_cong.py trong thư mục này chưa?)")
    if not loi or all("thiếu kết quả" not in x for x in loi):
        def dich(rows, tbl, hop, kieu):
            out = set()
            for r in rows:
                m = r["ma_nv"]
                if m in tbl: ten = tbl[m]
                elif m not in hop: ten = "(mã lạ)"
                else: loi.append(f"mã {m} không có trong bảng đối chiếu"); continue
                if kieu == "bt": out.add((ten, r["ngay"], r["loai"]))
                else: out.add((ten, r["ngay"], r["trang_thai"], r["gio_vao"], r["gio_ra"], r["gio_cong"], r["phut_tre"], r["phut_ve_som"], r["ot_phut"]))
            return out
        a = dich(rd(d / "bat_thuong.csv"), ten_cua_toi, hop_le, "bt"); b = dich(rd(BASE / "bat_thuong.csv"), ten_mau, hop_le_mau, "bt")
        if a != b: loi.append(f"bất thường khác bản mẫu: thiếu {len(b - a)}, thừa {len(a - b)} (so {len(b)} dòng)")
        a2 = dich(rd(d / "bang_cong_ngay.csv"), ten_cua_toi, hop_le, "bc"); b2 = dich(rd(BASE / "bang_cong_ngay.csv"), ten_mau, hop_le_mau, "bc")
        if a2 != b2: loi.append(f"bảng công ngày khác bản mẫu: {len(b2 - a2)} dòng lệch (so {len(b2)} dòng)")
        print(f"bài tập 3: bất thường {len(a & b)}/{len(b)} giống bản mẫu; bảng công ngày {len(a2 & b2)}/{len(b2)} giống bản mẫu")
    return loi

if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] in (["1"], ["2"]) and len(a) == 2: loi = kiem_12(a[0], a[1])
    elif a[:1] == ["3"] and len(a) == 3: loi = kiem_3(a[1], a[2])
    else: raise SystemExit(__doc__)
    if loi:
        print("KHÔNG ĐẠT:"); [print("  -", x) for x in loi]; sys.exit(1)
    print("ĐẠT")
