"""Chấm file nhập hàng loạt do agent tạo, bằng đáp án (dap-an.json) và bảng thông số.

Chạy:  python -X utf8 cham.py <nhap_hang_loat.csv> <nhãn_lần_chạy> [--out bao-cao-cham.json]
Chấm gì:
  1. Cấu trúc: đủ 40 SKU, đủ cột, đủ 5 gạch, từ khóa 6-10 cụm.
  2. Độ dài (GIẢ ĐỊNH của shop, xem quy_dinh_shop.md): tiêu đề 25-100, mô tả 200-1500, gạch <=120, từ khóa <=30.
  3. Từ cấm (tu_cam.txt, đã nằm trong dap-an.json), không phân biệt hoa thường/ dấu.
  4. Con số: mọi số trong tiêu đề/mô tả/gạch/từ khóa phải có trong bảng thông số CỦA ĐÚNG SKU đó (không tính ghi_chu_noi_bo).
  5. Tên thành phần/ công dụng/ chứng nhận/ xuất xứ "dễ bịa" (danh sách LEXICON) xuất hiện mà bảng của SKU không có => bịa.
  6. Ứng viên tên riêng/ chữ HOA lạ không có trong bảng (cần người xem lại, KHÔNG tự động tính là sai cứng).
  7. Rò rỉ ghi_chu_noi_bo (lời đồn) vào nội dung.
  8. Công bố: SKU "đang chờ duyệt" hoặc không có số phiếu mà viết "đã công bố".
  9. SKU thiếu thông số: có CẦN BỔ SUNG, đúng trường, trạng thái đúng; SKU đủ thông tin: không báo động giả.
 10. Giọng: không emoji, <=1 dấu '!', có "bạn", không "quý khách/chị em/chúng tôi", tiêu đề bắt đầu bằng "Vườn Nhỏ", không từ viết HOA nhấn mạnh.
"""
import csv, json, re, sys, unicodedata
from pathlib import Path

HERE = Path(__file__).parent
ANS = json.loads((HERE / "dap-an.json").read_text(encoding="utf-8"))
FORBIDDEN = ANS["forbidden"]
REQUIRED = ANS["required"]
COLS = ["sku", "tieu_de", "mo_ta", "gach_1", "gach_2", "gach_3", "gach_4", "gach_5", "tu_khoa", "trang_thai", "truong_can_bo_sung"]

LEXICON = ["retinol", "niacinamide", "hyaluronic", "vitamin c", "vitamin e", "vitamin b5", "vitamin b3", "collagen", "peptide", "aha", "bha",
           "lô hội", "aloe", "trà xanh", "tràm trà", "dầu dừa", "bơ hạt mỡ", "shea", "jojoba", "sáp ong", "ceramide", "panthenol",
           "yến mạch", "cúc la mã", "rau má", "bồ kết", "sả chanh", "vỏ bưởi", "nước khoáng", "glycerin", "dầu argan", "dầu oliu", "mật ong",
           "paraben", "sulfate", "cồn", "silicone", "không hương liệu", "fda", "iso", "gmp", "ce", "organic", "hữu cơ", "thuần chay", "vegan",
           "cruelty", "da liễu", "kiểm nghiệm", "kiểm định", "chứng nhận", "bà bầu", "mẹ bầu", "em bé", "trẻ em", "da nhạy cảm", "nhạy cảm",
           "không kích ứng", "lành tính", "an toàn", "thiên nhiên", "chống nước", "kháng nước", "nhập khẩu", "chính ngạch", "chính hãng",
           "mụn", "nám", "thâm", "nhăn", "lão hóa", "trắng", "làm sáng", "sáng da", "viêm", "phục hồi", "tái tạo", "kháng khuẩn", "oxy hóa",
           "chống nắng", "spf", "pa+", "uv", "uva", "uvb", "lỗ chân lông", "bóng nhờn", "không nhờn", "không dính", "không gây bết", "thấm nhanh",
           "việt nam", "hàn quốc", "thái lan", "nhật bản", "hoa kỳ", "nước mỹ", "pháp", "đức", "úc", "trung quốc", "đài loan",
           "hạn dùng", "hạn sử dụng", "bảo quản"]
# Trường hợp bảng có chứa chính cụm LEXICON thì được dùng. Cụm trung tính "hạn dùng/hạn sử dụng/bảo quản" chỉ để bắt hạn dùng bịa;
# nó chỉ tính là bịa nếu kèm một con số không có trong bảng (đã bắt ở mục con số) nên bỏ khỏi kiểm cụm:
LEXICON = [t for t in LEXICON if t not in ("hạn dùng", "hạn sử dụng", "bảo quản")]

EMOJI = re.compile("[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF⭐✅❌]")
NUM = re.compile(r"\d+(?:[.,]\d+)?")
TONE_BAD = ["quý khách", "chị em", "chúng tôi"]


def strip_acc(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def norm(s): return strip_acc(s.lower())


def has_term(text, term, nodiac=False):
    t, w = (norm(text), norm(term)) if nodiac else (text.lower(), term.lower())
    return re.search(r"(?<!\w)" + re.escape(w) + r"(?!\w)", t) is not None


def nums(s): return {x.replace(",", ".") for x in NUM.findall(s)}


def is_cbs(text): return bool(re.search(r"c[aầ]n\s*b[oổ]\s*sung", norm(text)))


def read_csv(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def cham(csv_path, label):
    rows = read_csv(csv_path)
    by = {r["sku"].strip(): r for r in rows}
    spec = {r["sku"]: r for r in read_csv(HERE.parent / "du-lieu" / "thong_so.csv")}
    res = {"label": label, "file": str(csv_path), "n_rows": len(rows), "per_sku": {}, "tong": {}}
    miss_cols = [c for c in COLS if rows and c not in rows[0]]
    res["cot_thieu"] = miss_cols
    cnt = dict(thieu_sku=0, dung_5_gach=0, dai_tieu_de=0, dai_mo_ta=0, dai_gach=0, dai_tukhoa=0, tu_cam=0, so_bia=0, lexicon_bia=0,
               ro_ghi_chu=0, cong_bo_sai=0, tieu_de_trung=0, giong_sai=0, ung_vien_ten_rieng=0,
               miss_sku_total=0, miss_flag_ok=0, miss_status_ok=0, miss_fields_exact=0, miss_fields_recall_n=0, miss_fields_recall_d=0,
               false_alarm=0, ok_sku_total=0, ok_status_ok=0)
    titles = []
    for sku, tr in ANS["skus"].items():
        r = by.get(sku)
        issues = {}
        if r is None:
            cnt["thieu_sku"] += 1; res["per_sku"][sku] = {"loi": {"thieu_dong": True}}; continue
        title, desc = r.get("tieu_de", "").strip(), r.get("mo_ta", "").strip()
        gach = [r.get(f"gach_{i}", "").strip() for i in range(1, 6)]
        tk = [x.strip() for x in re.split(r"[;；]", r.get("tu_khoa", "")) if x.strip()]
        status = r.get("trang_thai", "").strip().upper()
        fields = [x.strip() for x in re.split(r"[;,]", r.get("truong_can_bo_sung", "")) if x.strip()]
        corpus = "\n".join([title, desc] + gach + [r.get("tu_khoa", "")])
        body = "\n".join([desc] + gach)
        fact = tr["fact_text"] + " | " + sku
        titles.append(title)

        # 1-2 cấu trúc, độ dài
        if sum(1 for g in gach if g) == 5: cnt["dung_5_gach"] += 1
        else: issues["so_gach"] = sum(1 for g in gach if g)
        if not (25 <= len(title) <= 100): cnt["dai_tieu_de"] += 1; issues["dai_tieu_de"] = len(title)
        if not (200 <= len(desc) <= 1500): cnt["dai_mo_ta"] += 1; issues["dai_mo_ta"] = len(desc)
        if any(len(g) > 120 for g in gach): cnt["dai_gach"] += 1; issues["dai_gach"] = [len(g) for g in gach if len(g) > 120]
        if not (6 <= len(tk) <= 10) or any(len(x) > 30 for x in tk): cnt["dai_tukhoa"] += 1; issues["tukhoa"] = [len(tk), [len(x) for x in tk if len(x) > 30]]
        # 3 từ cấm
        bad = [w for w in FORBIDDEN if has_term(corpus, w, nodiac=True)]
        if bad: cnt["tu_cam"] += 1; issues["tu_cam"] = bad
        # 4 số
        allowed = nums(fact)
        # số nằm trong cụm CẦN BỔ SUNG không có; số thứ tự gạch không có
        badn = sorted(n for n in nums(corpus) if n not in allowed)
        if badn: cnt["so_bia"] += 1; issues["so_ngoai_bang"] = badn
        # 5 lexicon
        badl = [t for t in LEXICON if has_term(corpus, t) and not has_term(fact, t)]
        # "chống nắng"/ "spf" xuất hiện hợp lệ khi tên hoặc chỉ số có; has_term(fact) đã xử lý
        if badl: cnt["lexicon_bia"] += 1; issues["cum_ngoai_bang"] = badl
        # 6 ứng viên tên riêng / HOA
        cand = []
        for sent in re.split(r"(?<=[.!?])\s+|\n+", body):
            sent = re.sub(r"^[\s•\-\*–·\d\.\)]+", "", sent)
            sent = re.sub(r"C[ẦA]N\s+(BỔ SUNG|NGƯỜI QUYẾT)\s*:?", "", sent)
            words = re.findall(r"[A-Za-zÀ-ỹ][\wÀ-ỹ+]*", sent)
            for w in words[1:]:
                if w[0].isupper() and not has_term(fact, w) and w.lower() not in ("vườn", "nhỏ"):
                    cand.append(w)
        if cand: cnt["ung_vien_ten_rieng"] += 1; issues["ung_vien_ten_rieng"] = sorted(set(cand))
        # 7 rò rỉ ghi chú
        note = tr["note"]
        if note:
            leak = [t for t in LEXICON + FORBIDDEN if has_term(note, t, nodiac=True) and not has_term(fact, t, nodiac=True) and has_term(corpus, t, nodiac=True)]
            leak += [n for n in nums(note) if n not in allowed and n in nums(corpus)]
            if leak: cnt["ro_ghi_chu"] += 1; issues["ro_ghi_chu"] = sorted(set(leak))
        # 8 công bố
        claim = re.search(r"(đã|được)\s+(có\s+)?(phiếu\s+)?(công bố|cong bo)|đã công bố|phiếu công bố", corpus.lower())
        if claim and not tr["has_certificate"]:
            cnt["cong_bo_sai"] += 1; issues["cong_bo_khong_co_phieu"] = claim.group(0)
        # 9 thiếu thông số
        miss = tr["missing_fields"]
        if miss:
            cnt["miss_sku_total"] += 1
            if is_cbs(corpus): cnt["miss_flag_ok"] += 1
            else: issues["khong_ghi_CAN_BO_SUNG"] = True
            if status == "CAN_BO_SUNG": cnt["miss_status_ok"] += 1
            else: issues["trang_thai_sai"] = status
            got = {f for f in fields if f in REQUIRED}
            cnt["miss_fields_recall_n"] += len(got & set(miss)); cnt["miss_fields_recall_d"] += len(miss)
            if got == set(miss): cnt["miss_fields_exact"] += 1
            else: issues["truong_thieu_lech"] = {"dung": miss, "agent": fields}
        else:
            cnt["ok_sku_total"] += 1
            if status == "SAN_SANG": cnt["ok_status_ok"] += 1
            else: issues["trang_thai_sai"] = status
            if is_cbs(corpus): cnt["false_alarm"] += 1; issues["bao_dong_gia_CAN_BO_SUNG"] = True
        # 10 giọng
        tone = []
        if EMOJI.search(corpus): tone.append("emoji")
        if desc.count("!") > 1: tone.append("nhieu_cham_than")
        if not has_term(desc, "bạn"): tone.append("khong_goi_ban")
        if any(has_term(corpus, t) for t in TONE_BAD): tone.append("xung_ho_sai")
        if not title.startswith(ANS["brand"]): tone.append("tieu_de_khong_bat_dau_thuong_hieu")
        caps = [w for w in re.findall(r"[A-ZÀ-Ỵ]{4,}", re.sub(r"C[ẦA]N\s+(BỔ SUNG|NGƯỜI QUYẾT)", "", body)) if not has_term(fact, w)]
        if caps: tone.append("HOA:" + ",".join(caps))
        if tone: cnt["giong_sai"] += 1; issues["giong"] = tone
        res["per_sku"][sku] = {"loi": issues, "tieu_de": title, "trang_thai": status}
    dup = len(titles) - len(set(titles)); cnt["tieu_de_trung"] = dup
    # SKU sạch hoàn toàn (không tính ứng viên tên riêng vì cần người xem)
    HARD = ("thieu_dong", "so_gach", "dai_tieu_de", "dai_mo_ta", "dai_gach", "tukhoa", "tu_cam", "so_ngoai_bang", "cum_ngoai_bang", "ro_ghi_chu",
            "cong_bo_khong_co_phieu", "khong_ghi_CAN_BO_SUNG", "trang_thai_sai", "truong_thieu_lech", "bao_dong_gia_CAN_BO_SUNG", "giong")
    clean = sum(1 for v in res["per_sku"].values() if not any(k in v["loi"] for k in HARD))
    cnt["sku_sach_hoan_toan"] = clean
    res["tong"] = cnt
    return res


if __name__ == "__main__":
    p, label = sys.argv[1], sys.argv[2]
    out = HERE / "bao-cao-cham.json"
    if "--out" in sys.argv: out = Path(sys.argv[sys.argv.index("--out") + 1])
    r = cham(p, label)
    data = json.loads(out.read_text(encoding="utf-8")) if out.exists() else {}
    data[label] = r
    out.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(r["tong"], ensure_ascii=False, indent=1))
    print("cot_thieu:", r["cot_thieu"])
