#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Đối soát sao kê ngân hàng T10/2026 với sổ đơn hàng.

Đầu vào (chỉ đọc):  sao-ke-t10-2026.csv, so-don-hang-t10-2026.xlsx
Đầu ra (ghi vào cùng thư mục): bang_ghep.csv, ngoai_le.csv, tong_kiem.json, bao_cao.md
Mọi phép cộng/trừ/so sánh tiền đều do script này tính.

Chạy:  python -X utf8 doi_soat.py
"""
import csv
import itertools
import json
import re
import unicodedata
from datetime import date, datetime
from pathlib import Path

import openpyxl

BASE = Path(__file__).resolve().parent
SAO_KE = BASE / "sao-ke-t10-2026.csv"
SO_DON = BASE / "so-don-hang-t10-2026.xlsx"

ALL_LOAI = ["khop_du", "thieu", "thua", "trung", "nhieu_don", "hoan_tien",
            "cod_gop", "phi_lai_ngan_hang", "chi_khac", "khong_ro_nguon"]
LOAI_DA_GHEP = {"khop_du", "thieu", "thua", "trung", "nhieu_don"}
CAO, TB, CNQ = "CAO", "TRUNG BINH", "CAN NGUOI QUYET"


# ----------------------------------------------------------------- tiện ích
def bo_dau(s):
    s = unicodedata.normalize("NFD", str(s))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D")


def chuan_hoa(s):
    """Chữ hoa, không dấu, chỉ còn chữ-số và khoảng trắng đơn."""
    s = bo_dau(s).upper()
    s = re.sub(r"[^A-Z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def parse_tien(v):
    """'1,250,000' / '5.550.000 đ' / 1250000 -> int (đồng). Rỗng -> None."""
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return int(round(v))
    digits = re.sub(r"\D", "", str(v))
    return int(digits) if digits else None


def parse_ngay(v):
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v).strip()
    for f in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(s, f).date()
        except ValueError:
            pass
    raise ValueError(f"Không đọc được ngày: {v!r}")


def vnd(n):
    return f"{n:,}".replace(",", ".") + " đ"


def ddmm(d):
    return d.strftime("%d/%m")


# --------------------------------------------------------------- đọc dữ liệu
def doc_so_don():
    ws = openpyxl.load_workbook(SO_DON, data_only=True).worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    idx = {str(h).strip(): i for i, h in enumerate(rows[0])}
    orders, loi = {}, []
    for r in rows[1:]:
        if not r or not r[idx["Mã đơn"]]:
            continue
        ma = str(r[idx["Mã đơn"]]).strip().upper()
        o = {
            "ma": ma,
            "ngay": parse_ngay(r[idx["Ngày đặt"]]),
            "khach": str(r[idx["Khách hàng"]]).strip(),
            "sdt": str(r[idx["SĐT"]]).strip(),
            "tien_hang": parse_tien(r[idx["Tiền hàng"]]),
            "ship": parse_tien(r[idx["Phí ship"]]) or 0,
            "tong": parse_tien(r[idx["Tổng phải thu"]]),
            "tt": str(r[idx["Hình thức TT"]]).strip().upper(),
            "trang_thai": str(r[idx["Trạng thái"]]).strip(),
            "da_tra": 0,   # tổng tiền ghi có đã phân bổ vào đơn
            "da_hoan": 0,  # tổng tiền đã hoàn (ghi nợ hoan_tien)
            "dong_cod": None,
        }
        o["khach_chuan"] = chuan_hoa(o["khach"])
        if o["tien_hang"] + o["ship"] != o["tong"]:
            loi.append(f"{ma}: tiền hàng+ship={o['tien_hang'] + o['ship']} khác tổng phải thu={o['tong']}")
        if ma in orders:
            loi.append(f"{ma}: mã đơn bị trùng trong sổ")
        orders[ma] = o
    return orders, loi


def doc_sao_ke():
    with open(SAO_KE, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    h = next(i for i, r in enumerate(rows) if r and chuan_hoa(r[0]) == "NGAY GD")
    info = {}
    for r in rows[:h]:  # dòng thông tin tài khoản phía trên bảng
        if len(r) >= 2 and r[0].strip():
            info[chuan_hoa(r[0])] = r[1].strip()
    giao_dich, tong = [], {}
    for r in rows[h + 1:]:
        if not r or not any(c.strip() for c in r):
            continue
        try:
            ngay = parse_ngay(r[0])
        except ValueError:  # dòng tổng cuối file
            if len(r) >= 2:
                tong[chuan_hoa(r[0])] = parse_tien(r[1])
            continue
        no, co = parse_tien(r[2]), parse_tien(r[3])
        giao_dich.append({
            "ngay": ngay, "so_ct": r[1].strip(), "no": no, "co": co,
            "so_du": parse_tien(r[4]), "nd": r[5].strip(),
        })
    return info, giao_dich, tong


# ------------------------------------------------------- rút mã đơn / tên
RE_MA = re.compile(
    r"(?<![A-Z0-9])D\s*H\s*2\s*6\s*1\s*[0O]\s*([0-9O]{1,3})(?![0-9])((?:\s+\d{1,3}(?![0-9A-Z]))*)")
RE_DON = re.compile(
    r"(?<![A-Z0-9])DON(?:\s+HANG)?(?:\s+SO)?\s+((?:\d{1,3}(?![0-9A-Z])\s*)+)")
RE_SO_DON = re.compile(r"(?<![A-Z0-9])(\d)\s+DON(?![A-Z0-9])")


def ma_tu_so(s):
    return "DH2610-%03d" % int(s.replace("O", "0"))


def rut_ma(nd_chuan):
    """Mã đơn trong nội dung (đã chuẩn hóa). Chịu: DH261O-028, DH2610061, DH 2610 067,
    dh2610-42, 'don hang so 33', 'DH2610-098 105 090', '3 don 116 024 097'."""
    ma = []
    for m in RE_MA.finditer(nd_chuan):
        ma.append(ma_tu_so(m.group(1)))
        ma += [ma_tu_so(x) for x in m.group(2).split()]
    for m in RE_DON.finditer(nd_chuan):
        ma += [ma_tu_so(x) for x in m.group(1).split()]
    return list(dict.fromkeys(ma))


def tim_ten(nd_chuan, ten_chuan):
    """3 = có đủ họ tên; 2 = viết tắt (B Q BINH, LE N THAO) hoặc họ+tên (NGO DUNG); 0 = không."""
    if f" {ten_chuan} " in f" {nd_chuan} ":
        return 3
    toks = ten_chuan.split()
    n = len(toks)
    if n >= 2:
        parts = [rf"(?:{t}|{t[0]})" for t in toks[:-1]] + [toks[-1]]
        if re.search(r"(?<![A-Z0-9])" + r"\s+".join(parts) + r"(?![A-Z0-9])", nd_chuan):
            return 2
        if n >= 3 and re.search(rf"(?<![A-Z0-9]){toks[0]}\s+{toks[-1]}(?![A-Z0-9])", nd_chuan):
            return 2
    return 0


# ------------------------------------------------------------------ chính
def main():
    orders, loi_so_don = doc_so_don()
    info, gd, tong_dong = doc_sao_ke()
    ten_khach = sorted({o["khach_chuan"] for o in orders.values()})
    sdt_theo_ten = {}
    for o in orders.values():
        sdt_theo_ten.setdefault(o["khach_chuan"], set()).add(o["sdt"])

    lines = []
    for g in gd:
        co_hai = g["no"] is not None and g["co"] is not None
        lines.append({
            "so_ct": g["so_ct"], "ngay": g["ngay"],
            "chieu": "no" if g["no"] is not None else "co",
            "so_tien": g["no"] if g["no"] is not None else g["co"],
            "so_du": g["so_du"], "nd": g["nd"], "nd_chuan": chuan_hoa(g["nd"]),
            "loai": None, "muc": None, "ly_do": "", "ma_don": [], "phan_bo": {},
            "ngoai_le": [], "co_hai_chieu": co_hai,
        })

    # --- tiện ích gán kết quả
    def dat(l, loai, muc, ly_do, ma=None, pb=None):
        l.update(loai=loai, muc=muc, ly_do=ly_do, ma_don=list(ma or []), phan_bo=dict(pb or {}))
        for m, v in l["phan_bo"].items():
            if l["chieu"] == "co":
                orders[m]["da_tra"] += v
            else:
                orders[m]["da_hoan"] += v

    def nl(l, loai, mo_ta, de_xuat, ma=None):
        l["ngoai_le"].append({"loai_ngoai_le": loai, "so_ct": l["so_ct"],
                              "ma_don": ";".join(ma if ma is not None else l["ma_don"]),
                              "mo_ta": mo_ta, "de_xuat": de_xuat})

    def cnq(l, ly_do, ung_vien=(), loai_nl=None):
        dat(l, "khong_ro_nguon", CNQ, ly_do, ma=ung_vien)
        loai_nl = loai_nl or ("can_nguoi_quyet" if ung_vien else "khong_ro_nguon")
        nl(l, loai_nl,
           f"{ddmm(l['ngay'])} ghi có {vnd(l['so_tien'])}, nội dung \"{l['nd']}\": {ly_do}",
           "Người phụ trách xác định khoản này thuộc đơn nào (hoặc là tiền ngoài đơn) rồi mới ghi sổ."
           if ung_vien else "Hỏi lại khách/ngân hàng để biết người chuyển; chưa xác định được thì giữ ở tài khoản treo.")

    def ten_phat_hien(l):
        return {t for t in ten_khach if tim_ten(l["nd_chuan"], t) >= 2}

    def don_ck_chua_tra(ten_set, ngay):
        return [o for o in orders.values()
                if o["khach_chuan"] in ten_set and o["tt"] == "CK" and o["trang_thai"] != "Hủy"
                and o["da_tra"] == 0 and o["ngay"] <= ngay]

    ten_goc = {}  # tên chuẩn hóa -> tên có dấu trong sổ, để hiển thị
    for o in orders.values():
        ten_goc.setdefault(o["khach_chuan"], o["khach"])

    def canh_bao_ten_trung(ten_set):
        out = []
        for t in sorted(ten_set):
            if len(sdt_theo_ten[t]) > 1:
                out.append(f"có {len(sdt_theo_ten[t])} khách trùng tên '{ten_goc[t]}' với SĐT khác nhau")
        return out

    # ===== Bước 0: phân loại theo từ khóa (không cần đối chiếu đơn)
    for l in lines:
        nd = l["nd_chuan"]
        if l["co_hai_chieu"]:
            cnq(l, "Dòng sao kê có cả ghi nợ lẫn ghi có, cần kiểm tra lại với ngân hàng.")
            continue
        if l["chieu"] == "co" and "DOI SOAT COD" in nd:
            l["loai"] = "cod_gop"
        elif any(k in nd for k in ("LAI TIEN GUI", "PHI SMS", "PHI DUY TRI", "PHI CHUYEN KHOAN")):
            dat(l, "phi_lai_ngan_hang", TB,
                "Phí/lãi ngân hàng, phân loại theo nội dung, không gắn với đơn hàng.")
        elif l["chieu"] == "no" and "HOAN TIEN" in nd:
            l["loai"] = "hoan_tien"
        elif l["chieu"] == "no":
            dat(l, "chi_khac", TB,
                "Khoản chi không liên quan đơn hàng, phân loại theo nội dung chuyển khoản.")

    # ===== Bước A: ghi có có mã đơn trong nội dung
    for l in lines:
        if l["loai"] or l["chieu"] != "co":
            continue
        codes = rut_ma(l["nd_chuan"])
        if not codes:
            continue
        amt, names = l["so_tien"], ten_phat_hien(l)
        chua_co = [c for c in codes if c not in orders]
        if chua_co:
            cnq(l, f"Mã {', '.join(chua_co)} trong nội dung không có trong sổ đơn hàng.")
            continue
        os_ = [orders[c] for c in codes]
        sai = [o for o in os_ if o["tt"] != "CK" or o["trang_thai"] == "Hủy"]
        if sai:
            cnq(l, "Nội dung nêu đơn " + ", ".join(
                f"{o['ma']} ({'COD' if o['tt'] != 'CK' else 'đã hủy'})" for o in sai)
                + " là đơn không cần thu chuyển khoản.", codes)
            continue

        if len(codes) == 1:
            o = os_[0]
            due = o["tong"] - o["da_tra"]
            ten_ok = (not names) or (o["khach_chuan"] in names)
            truoc_ngay = l["ngay"] < o["ngay"]
            if not ten_ok:
                alt = don_ck_chua_tra(names, l["ngay"])
                alt = [a for a in alt if a["tong"] == amt]
                if alt:
                    a_ma = [a["ma"] for a in alt]
                    why = (f"Mã {o['ma']} (khách {o['khach']}) mâu thuẫn với tên người chuyển; tên và số tiền "
                           f"{vnd(amt)} lại khớp {', '.join(a_ma)} ({alt[0]['khach']})"
                           + (f"; đơn {o['ma']} đặt {ddmm(o['ngay'])}, sau ngày chuyển" if truoc_ngay else "")
                           + (f"; đơn {o['ma']} đã có dòng trả {vnd(o['da_tra'])}" if o["da_tra"] else "")
                           + ".")
                    cnq(l, why, codes + a_ma)
                elif due > 0 and amt == due:
                    ten_ck = ", ".join(sorted(ten_goc[t] for t in names))
                    dat(l, "khop_du", TB,
                        f"Mã {o['ma']} và số tiền {vnd(amt)} khớp nhưng tên người chuyển ({ten_ck}) khác khách trên đơn "
                        f"({o['khach']}), nên chưa chắc.", codes, {o["ma"]: amt})
                    nl(l, "can_xac_nhan",
                       f"{ddmm(l['ngay'])} ghi có {vnd(amt)} \"{l['nd']}\" ghép {o['ma']} theo mã và số tiền, "
                       f"nhưng tên người chuyển ({ten_ck}) khác khách {o['khach']}.",
                       "Hỏi khách xem có chuyển hộ không; nếu đúng thì giữ ghép.")
                else:
                    cnq(l, f"Mã {o['ma']} không khớp tên người chuyển và không có đơn nào khớp số tiền.", codes)
                continue
            if due <= 0:  # đơn đã thu đủ -> chuyển trùng
                muc = CAO if (amt == o["tong"] and not truoc_ngay) else TB
                dat(l, "trung", muc,
                    f"Đơn {o['ma']} đã được thanh toán đủ trước đó, dòng này chuyển lặp lại {vnd(amt)}.", codes)
                nl(l, "chuyen_trung",
                   f"{ddmm(l['ngay'])} khách {o['khach']} chuyển lặp {vnd(amt)} cho đơn {o['ma']} đã thu đủ.",
                   f"Hoàn lại {vnd(amt)} cho khách hoặc trừ vào đơn sau của khách, theo thỏa thuận.")
            elif amt == due:
                dat(l, "khop_du", TB if truoc_ngay else CAO,
                    f"Mã {o['ma']} và số tiền {vnd(amt)} khớp đơn"
                    + ("" if not names else ", tên người chuyển khớp khách") + "."
                    + (" Lưu ý: ngày chuyển trước ngày đặt đơn." if truoc_ngay else ""),
                    codes, {o["ma"]: amt})
            elif amt < due:
                dat(l, "thieu", TB,
                    f"Mã {o['ma']} đúng nhưng chuyển thiếu {vnd(due - amt)} (phải thu {vnd(due)}, chuyển {vnd(amt)}).",
                    codes, {o["ma"]: amt})
                nl(l, "chuyen_thieu",
                   f"Đơn {o['ma']} ({o['khach']}) phải thu {vnd(due)}, khách chuyển {vnd(amt)}, còn thiếu {vnd(due - amt)}.",
                   f"Liên hệ khách thu nốt {vnd(due - amt)}; chưa tất toán đơn.")
            else:
                dat(l, "thua", TB,
                    f"Mã {o['ma']} đúng nhưng chuyển thừa {vnd(amt - due)} (phải thu {vnd(due)}, chuyển {vnd(amt)}).",
                    codes, {o["ma"]: due})
                nl(l, "chuyen_thua",
                   f"Đơn {o['ma']} ({o['khach']}) phải thu {vnd(due)}, khách chuyển {vnd(amt)}, thừa {vnd(amt - due)}.",
                   f"Hoàn lại {vnd(amt - due)} cho khách hoặc ghi nhận khách ứng trước.")
            continue

        # nhiều mã trong một lần chuyển
        due_list = [o["tong"] - o["da_tra"] for o in os_]
        ten_ok = (not names) or all(o["khach_chuan"] in names for o in os_)
        if not ten_ok:
            cnq(l, "Nhiều mã đơn nhưng tên người chuyển không khớp khách của các đơn đó.", codes)
        elif any(d <= 0 for d in due_list):
            cnq(l, "Trong các mã nêu có đơn đã thu đủ trước đó, cần người xem lại cách chia.", codes)
        elif sum(due_list) == amt:
            dat(l, "nhieu_don", CAO,
                f"Một lần chuyển trả {len(codes)} đơn: tổng phải thu {vnd(sum(due_list))} đúng bằng số tiền chuyển.",
                codes, {o["ma"]: d for o, d in zip(os_, due_list)})
        else:
            cnq(l, f"Nhiều mã đơn nhưng tổng phải thu {vnd(sum(due_list))} khác số tiền chuyển {vnd(amt)}.", codes)

    # ===== Bước B: ghi có không có mã -> khớp theo tên + số tiền
    for l in lines:
        if l["loai"] or l["chieu"] != "co":
            continue
        amt = l["so_tien"]
        names = ten_phat_hien(l)
        if not names:
            uv = [o["ma"] for o in orders.values()
                  if o["tt"] == "CK" and o["trang_thai"] != "Hủy" and o["da_tra"] == 0
                  and o["tong"] == amt and o["ngay"] <= l["ngay"]]
            if uv:
                cnq(l, f"Không có mã đơn, không nhận ra tên khách; số tiền {vnd(amt)} trùng đơn chưa thu "
                       f"{', '.join(uv)}.", uv)
            else:
                hd = re.search(r"(?<![A-Z0-9])HD\s*(\d+)", l["nd_chuan"])
                ghi_chu_hd = (f" Nội dung ghi 'HD {hd.group(1)}' không phải mã đơn dạng DH2610-xxx nên không tự suy ra đơn."
                              if hd else "")
                cnq(l, f"Không có mã đơn, nội dung không nhận ra khách nào trong sổ và số tiền {vnd(amt)} "
                       f"không khớp đơn CK chưa thu nào tính đến ngày {ddmm(l['ngay'])}." + ghi_chu_hd)
            continue
        ten_hien = ", ".join(sorted(ten_goc[t] for t in names))
        luu_y = canh_bao_ten_trung(names)
        uv = [o for o in don_ck_chua_tra(names, l["ngay"]) if o["tong"] == amt]
        if len(uv) == 1:
            o = uv[0]
            why = (f"Không có mã; khớp theo tên ({ten_hien}) và số tiền {vnd(amt)} với đơn {o['ma']}, "
                   f"là đơn duy nhất phù hợp")
            if luu_y:
                why += "; lưu ý " + "; ".join(luu_y) + ", đã loại đơn đặt sau ngày chuyển"
            dat(l, "khop_du", TB, why + ".", [o["ma"]], {o["ma"]: amt})
            if luu_y:
                nl(l, "can_xac_nhan", f"{ddmm(l['ngay'])} {vnd(amt)} \"{l['nd']}\" ghép {o['ma']} theo tên và số tiền, "
                   f"nhưng {'; '.join(luu_y)}.",
                   "Xác nhận đúng khách (đối chiếu SĐT/địa chỉ nhận hàng) trước khi chốt.")
            continue
        if len(uv) > 1:
            cnq(l, f"Tên ({ten_hien}) và số tiền {vnd(amt)} khớp nhiều đơn: {', '.join(o['ma'] for o in uv)}.",
                [o["ma"] for o in uv])
            continue
        # thử gộp nhiều đơn của cùng khách
        pool = don_ck_chua_tra(names, l["ngay"])
        m = RE_SO_DON.search(l["nd_chuan"])
        sizes = [int(m.group(1))] if m and 2 <= int(m.group(1)) <= 4 else [2, 3]
        combos = []
        for k in sizes:
            combos += [c for c in itertools.combinations(pool, k) if sum(o["tong"] for o in c) == amt]
        if len(combos) == 1:
            c = combos[0]
            dat(l, "nhieu_don", TB,
                f"Không ghi mã; tên ({ten_hien}) và nội dung chỉ rõ {len(c)} đơn: tổng phải thu của "
                f"{', '.join(o['ma'] for o in c)} đúng {vnd(amt)}, là cách ghép duy nhất.",
                [o["ma"] for o in c], {o["ma"]: o["tong"] for o in c})
            continue
        if len(combos) > 1:
            cnq(l, f"Tên ({ten_hien}) khớp nhiều cách gộp đơn có cùng tổng {vnd(amt)}.",
                sorted({o["ma"] for c in combos for o in c}))
            continue
        # chuyển trùng một đơn đã thu đủ?
        da_tra_du = [o for o in orders.values()
                     if o["khach_chuan"] in names and o["tt"] == "CK" and o["trang_thai"] != "Hủy"
                     and o["tong"] == amt and o["da_tra"] >= o["tong"]]
        if da_tra_du:
            ma = [o["ma"] for o in da_tra_du]
            dat(l, "trung", TB,
                f"Không ghi mã; tên ({ten_hien}) và số tiền {vnd(amt)} khớp đơn {', '.join(ma)} đã thu đủ, nhiều khả năng chuyển lặp.",
                ma)
            nl(l, "chuyen_trung", f"{ddmm(l['ngay'])} {vnd(amt)} \"{l['nd']}\" có vẻ chuyển lặp cho {', '.join(ma)}.",
               "Xác nhận với khách rồi hoàn lại hoặc trừ vào đơn sau.")
            continue
        uv_ten = [o["ma"] for o in pool]
        cnq(l, f"Tên khớp khách {ten_hien} nhưng số tiền {vnd(amt)} không khớp đơn chưa thu nào của khách.", uv_ten)

    # ===== Bước C: COD gộp theo lô (hãng vận chuyển đối soát)
    cod_ds = sorted([o for o in orders.values() if o["tt"] == "COD" and o["trang_thai"] == "Đã giao"],
                    key=lambda o: o["ma"])
    con_tro = 0
    for l in lines:
        if l["loai"] != "cod_gop":
            continue
        s, run, tim = 0, [], None
        for o in cod_ds[con_tro:]:
            if o["ngay"] > l["ngay"]:
                break
            s += o["tong"]
            run.append(o)
            if s == l["so_tien"]:
                tim = run[:]
                break
            if s > l["so_tien"]:
                break
        if tim:
            con_tro += len(tim)
            for o in tim:
                o["dong_cod"] = l["so_ct"]
            dat(l, "cod_gop", TB,
                f"Hãng vận chuyển đối soát COD gộp {len(tim)} đơn: tổng {vnd(l['so_tien'])} đúng bằng các đơn COD đã giao "
                f"liên tiếp {tim[0]['ma']} đến {tim[-1]['ma']} (giả định hãng đối soát theo thứ tự đơn).",
                [o["ma"] for o in tim], {o["ma"]: o["tong"] for o in tim})
            nl(l, "can_xac_nhan",
               f"{ddmm(l['ngay'])} {vnd(l['so_tien'])} COD gộp: ghép {len(tim)} đơn {tim[0]['ma']}..{tim[-1]['ma']} "
               "chỉ dựa trên tổng tiền và thứ tự đơn, nội dung không liệt kê mã.",
               "Đối chiếu với bảng kê chi tiết của hãng vận chuyển.")
        else:
            dat(l, "cod_gop", CNQ, "COD gộp nhưng không ghép được thành dãy đơn COD có tổng đúng bằng số tiền.")
            nl(l, "can_nguoi_quyet", f"{ddmm(l['ngay'])} {vnd(l['so_tien'])} COD gộp không ghép được đơn.",
               "Xin bảng kê chi tiết từ hãng vận chuyển.")

    # ===== Bước D: hoàn tiền (ghi nợ)
    for l in lines:
        if l["loai"] != "hoan_tien":
            continue
        codes = rut_ma(l["nd_chuan"])
        amt = l["so_tien"]
        if len(codes) != 1 or codes[0] not in orders:
            dat(l, "hoan_tien", CNQ, "Hoàn tiền nhưng không xác định được đúng một mã đơn.", codes if codes and all(c in orders for c in codes) else [])
            nl(l, "can_nguoi_quyet", f"{ddmm(l['ngay'])} chi {vnd(amt)} \"{l['nd']}\" không xác định được đơn.",
               "Xác định đơn được hoàn.")
            continue
        o = orders[codes[0]]
        da_tra = o["da_tra"]
        if da_tra == 0:
            dat(l, "hoan_tien", CNQ, f"Hoàn tiền cho {o['ma']} nhưng không có dòng ghi có nào đã thu của đơn này.", codes)
            nl(l, "can_nguoi_quyet", f"{ddmm(l['ngay'])} chi hoàn {vnd(amt)} cho {o['ma']} mà chưa ghi nhận khoản thu.",
               "Kiểm tra khoản thu gốc của đơn.")
        elif amt + o["da_hoan"] == da_tra:
            dat(l, "hoan_tien", CAO,
                f"Hoàn đủ {vnd(amt)} cho đơn {o['ma']} ({o['khach']}), bằng số đã thu; đơn ở trạng thái {o['trang_thai']}.",
                codes, {o["ma"]: amt})
        elif amt + o["da_hoan"] < da_tra:
            giu = da_tra - amt - o["da_hoan"]
            vi_sao = (f", khớp phí ship của đơn {vnd(o['ship'])}" if giu == o["ship"] else "")
            dat(l, "hoan_tien", TB,
                f"Hoàn một phần {vnd(amt)} cho đơn {o['ma']}, shop giữ lại {vnd(giu)}{vi_sao} (đã thu {vnd(da_tra)}).",
                codes, {o["ma"]: amt})
            nl(l, "hoan_tien_mot_phan",
               f"Đơn {o['ma']} ({o['khach']}) đã thu {vnd(da_tra)}, hoàn {vnd(amt)}, giữ lại {vnd(giu)}{vi_sao}.",
               "Xác nhận khoản giữ lại đúng chính sách (nội dung ghi 'trừ phí ship') rồi ghi nhận doanh thu/phí tương ứng.")
        else:
            dat(l, "hoan_tien", CNQ, f"Số hoàn vượt số đã thu của đơn {o['ma']}.", codes)
            nl(l, "can_nguoi_quyet", f"Hoàn {vnd(amt)} vượt số thu {vnd(da_tra)} của {o['ma']}.", "Kiểm tra lại.")

    # đơn trạng thái 'Hoàn tiền' mà chưa có dòng chi hoàn
    for o in orders.values():
        if o["trang_thai"] == "Hoàn tiền" and o["da_tra"] > 0 and o["da_hoan"] == 0:
            lines[-1]["ngoai_le"].append({
                "loai_ngoai_le": "hoan_tien_chua_chi", "so_ct": "", "ma_don": o["ma"],
                "mo_ta": f"Đơn {o['ma']} trạng thái Hoàn tiền, đã thu {vnd(o['da_tra'])} nhưng chưa thấy dòng chi hoàn.",
                "de_xuat": "Kiểm tra và chi hoàn cho khách."})

    # ===== kiểm tra tất cả dòng đã có loại
    for l in lines:
        assert l["loai"] in ALL_LOAI and l["muc"] in (CAO, TB, CNQ, "THAP"), l

    # ===== ngoại lệ: đơn CK chưa thu
    cnq_ref = {}
    for l in lines:
        if l["muc"] == CNQ and l["chieu"] == "co":
            for m in l["ma_don"]:
                cnq_ref.setdefault(m, []).append(l["so_ct"])
    ngoai_le = [e for l in lines for e in l["ngoai_le"]]
    chua_thu = []
    for o in sorted(orders.values(), key=lambda x: x["ma"]):
        if o["tt"] == "CK" and o["trang_thai"] != "Hủy" and o["da_tra"] == 0:
            chua_thu.append(o)
            mo = f"Đơn CK {o['ma']} ({o['khach']}, ngày đặt {o['ngay'].strftime('%d/%m')}) phải thu {vnd(o['tong'])}, chưa có dòng sao kê nào trả tiền; trạng thái {o['trang_thai']}."
            dx = "Nhắc khách chuyển khoản hoặc kiểm tra lại với khách."
            if o["trang_thai"] == "Đang giao":
                mo += " Đơn mới đặt cuối tháng, có thể chưa tới hạn chuyển."
                dx = "Theo dõi sang tháng sau; chưa cần nhắc nếu khách chưa nhận hàng."
            if o["ma"] in cnq_ref:
                mo += f" Đơn đang là ứng viên của dòng {', '.join(cnq_ref[o['ma']])} (chờ người quyết)."
                dx = "Quyết định dòng sao kê liên quan trước; nếu không phải của đơn này thì nhắc khách chuyển."
            ngoai_le.append({"loai_ngoai_le": "don_chua_thu", "so_ct": "", "ma_don": o["ma"],
                             "mo_ta": mo, "de_xuat": dx})
    cod_cho = [o for o in orders.values() if o["tt"] == "COD" and o["trang_thai"] == "Đã giao" and not o["dong_cod"]]
    if cod_cho:
        tcod = sum(o["tong"] for o in cod_cho)
        ngoai_le.append({
            "loai_ngoai_le": "cod_cho_doi_soat", "so_ct": "", "ma_don": ";".join(o["ma"] for o in cod_cho),
            "mo_ta": f"{len(cod_cho)} đơn COD đã giao, tổng {vnd(tcod)}, chưa nằm trong lô đối soát nào của tháng (thông tin, không phải đơn chưa thu).",
            "de_xuat": "Theo dõi đợt đối soát COD tiếp theo của hãng vận chuyển."})

    # ===== tổng kiểm
    so_du_dau = parse_tien(info.get("SO DU DAU KY"))
    tong_co = sum(l["so_tien"] for l in lines if l["chieu"] == "co")
    tong_no = sum(l["so_tien"] for l in lines if l["chieu"] == "no")
    so_du_cuoi = so_du_dau + tong_co - tong_no
    lech_so_du, du = [], so_du_dau
    for l in lines:
        du += l["so_tien"] if l["chieu"] == "co" else -l["so_tien"]
        if du != l["so_du"]:
            lech_so_du.append(l["so_ct"])
            du = l["so_du"]
    so_ct_trung = len(lines) - len({l["so_ct"] for l in lines})
    kiem = (so_du_cuoi == parse_tien(info.get("SO DU CUOI KY", tong_dong.get("SO DU CUOI KY")))
            and tong_co == tong_dong.get("TONG PHAT SINH CO")
            and tong_no == tong_dong.get("TONG PHAT SINH NO")
            and not lech_so_du and so_ct_trung == 0)
    theo_loai = {k: sum(l["so_tien"] for l in lines if l["chieu"] == "co" and l["loai"] == k) for k in ALL_LOAI}
    co_da_ghep = sum(v for k, v in theo_loai.items() if k in LOAI_DA_GHEP)
    tong_kiem = {
        "so_dong": len(lines),
        "so_du_dau": so_du_dau,
        "tong_ghi_co": tong_co,
        "tong_ghi_no": tong_no,
        "so_du_cuoi": so_du_cuoi,
        "kiem_so_du_khop": bool(kiem),
        "tong_co_theo_loai": theo_loai,
        "tong_co_da_ghep_don": co_da_ghep,
        "tong_co_chua_ghep_hoac_can_nguoi_quyet": tong_co - co_da_ghep,
        "doi_chieu_sao_ke": {
            "so_du_cuoi_theo_sao_ke": tong_dong.get("SO DU CUOI KY") or parse_tien(info.get("SO DU CUOI KY")),
            "tong_co_theo_dong_tong": tong_dong.get("TONG PHAT SINH CO"),
            "tong_no_theo_dong_tong": tong_dong.get("TONG PHAT SINH NO"),
            "so_dong_lech_so_du_chay": lech_so_du,
            "so_ct_bi_trung": so_ct_trung,
        },
        "ghi_chu": "tong_co_da_ghep_don = ghi có loại khop_du/thieu/thua/trung/nhieu_don; phần còn lại "
                   "(cod_gop, phi_lai, khong_ro_nguon gồm cả các ca CAN NGUOI QUYET) nằm ở tong_co_chua_ghep_hoac_can_nguoi_quyet.",
    }

    # ===== kiểm tra nội bộ (dừng nếu sai)
    for l in lines:
        assert all(m in orders for m in l["ma_don"]), l
        if l["chieu"] == "co":
            assert sum(l["phan_bo"].values()) <= l["so_tien"], l
        if l["muc"] == CAO:
            assert l["ma_don"] and l["loai"] in ("khop_du", "nhieu_don", "trung", "hoan_tien"), l
        if l["muc"] == CNQ and l["loai"] in LOAI_DA_GHEP:
            raise AssertionError(l)
    for o in orders.values():
        assert o["da_tra"] <= o["tong"], o
    assert sum(theo_loai.values()) == tong_co
    assert co_da_ghep + tong_kiem["tong_co_chua_ghep_hoac_can_nguoi_quyet"] == tong_co

    # ===== ghi file
    with open(BASE / "bang_ghep.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["so_ct", "ngay", "chieu", "so_tien", "ma_don", "phan_bo", "loai", "muc_chac_chan", "ly_do"])
        for l in lines:
            w.writerow([l["so_ct"], l["ngay"].isoformat(), l["chieu"], l["so_tien"], ";".join(l["ma_don"]),
                        ";".join(f"{m}:{v}" for m, v in l["phan_bo"].items()), l["loai"], l["muc"], l["ly_do"]])
    with open(BASE / "ngoai_le.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["loai_ngoai_le", "so_ct", "ma_don", "mo_ta", "de_xuat"])
        for e in ngoai_le:
            w.writerow([e["loai_ngoai_le"], e["so_ct"], e["ma_don"], e["mo_ta"], e["de_xuat"]])
    with open(BASE / "tong_kiem.json", "w", encoding="utf-8") as f:
        json.dump(tong_kiem, f, ensure_ascii=False, indent=2)

    # ===== báo cáo (số liệu lấy từ code)
    dem_muc = {k: sum(1 for l in lines if l["muc"] == k) for k in (CAO, TB, CNQ)}
    dem_loai = {k: sum(1 for l in lines if l["loai"] == k) for k in ALL_LOAI}
    cnq_co = [l for l in lines if l["muc"] == CNQ and l["chieu"] == "co"]
    n_cnq_uv = sum(1 for l in cnq_co if l["ma_don"])
    n_khong_ro = len(cnq_co) - n_cnq_uv
    tien_loai = lambda ten: sum(l["so_tien"] for l in lines if l["loai"] == ten and l["chieu"] == "co")
    tien_thieu = sum(orders[next(iter(l["phan_bo"]))]["tong"] - l["so_tien"] for l in lines if l["loai"] == "thieu")
    tien_thua = sum(l["so_tien"] - sum(l["phan_bo"].values()) for l in lines if l["loai"] == "thua")
    tien_trung = sum(l["so_tien"] for l in lines if l["loai"] == "trung")
    tien_chua_thu = sum(o["tong"] for o in chua_thu)
    n_hoan_mot_phan = sum(1 for e in ngoai_le if e["loai_ngoai_le"] == "hoan_tien_mot_phan")
    bc = [
        "# Báo cáo đối soát tháng 10/2026",
        f"- Sao kê {len(lines)} dòng (ghi có {tien_fmt(tong_co)}, ghi nợ {tien_fmt(tong_no)}); số dư cuối {tien_fmt(so_du_cuoi)}, "
        f"kiểm số dư khớp dòng tổng: {'ĐÚNG' if kiem else 'SAI'}.",
        f"- Mức chắc chắn: {dem_muc[CAO]} CAO, {dem_muc[TB]} TRUNG BINH, {dem_muc[CNQ]} CAN NGUOI QUYET "
        "(dòng chi/phí phân loại theo từ khóa nên ghi TRUNG BINH, không cần xử lý).",
        f"- Ghi có đã ghép đơn {tien_fmt(co_da_ghep)}; chưa ghép/cần người quyết {tien_fmt(tong_co - co_da_ghep)} "
        f"(trong đó COD gộp {tien_fmt(theo_loai['cod_gop'])}, lãi ngân hàng {tien_fmt(theo_loai['phi_lai_ngan_hang'])}, "
        f"còn lại {tien_fmt(theo_loai['khong_ro_nguon'])} cần người quyết).",
        f"- Cần người quyết: {len(cnq_co)} dòng ghi có ({n_cnq_uv} có đơn ứng viên: mã trong nội dung mâu thuẫn với tên/số tiền; "
        f"{n_khong_ro} tiền không rõ nguồn). Chi tiết ở ngoai_le.csv.",
        f"- Chuyển thiếu {dem_loai['thieu']} dòng (tổng thiếu {tien_fmt(tien_thieu)}); chuyển thừa {dem_loai['thua']} dòng "
        f"(thừa {tien_fmt(tien_thua)}); chuyển trùng {dem_loai['trung']} dòng ({tien_fmt(tien_trung)}); "
        f"nhiều đơn một lần chuyển {dem_loai['nhieu_don']} dòng.",
        f"- Hoàn tiền {dem_loai['hoan_tien']} dòng, trong đó {n_hoan_mot_phan} ca hoàn một phần (giữ lại một khoản).",
        f"- Đơn CK chưa có tiền và chưa hủy: {len(chua_thu)} đơn, tổng {tien_fmt(tien_chua_thu)}; "
        f"{sum(1 for o in chua_thu if o['trang_thai'] == 'Đang giao')} đơn đang giao (đặt cuối tháng), "
        f"{sum(1 for o in chua_thu if o['ma'] in cnq_ref)} đơn là ứng viên của dòng đang chờ người quyết.",
        f"- COD: {dem_loai['cod_gop']} lô đối soát của hãng ghép khớp tổng với dãy đơn COD liên tiếp; "
        f"còn {len(cod_cho)} đơn COD đã giao ({tien_fmt(sum(o['tong'] for o in cod_cho))}) chờ đối soát lô sau.",
        "- Không chắc: (1) ghép lô COD chỉ dựa vào tổng tiền và thứ tự đơn, cần bảng kê hãng; "
        "(2) ca 'don 003 HOANG KIM VY' ghép theo mã+số tiền dù tên khác khách trên đơn;",
        f"  (3) hai khách trùng tên Trần Văn Bình (2 SĐT) ghép theo ngày đặt đơn; (4) {n_cnq_uv} dòng sai mã đơn (nghiêng về đơn khớp tên+số tiền) "
        "tôi không tự chốt, theo đúng quy tắc.",
        "- Quy ước: dòng CAN NGUOI QUYET ghi loai=khong_ro_nguon, ma_don là ứng viên, phan_bo để trống, chưa tính vào 'đã ghép'.",
    ]
    assert len(bc) <= 15
    (BASE / "bao_cao.md").write_text("\n".join(bc) + "\n", encoding="utf-8")

    # ===== in tóm tắt
    print("so_dong", len(lines), "| kiem_so_du_khop", kiem, "| lech so du chay:", lech_so_du)
    print("loi so don:", loi_so_don)
    print("muc:", dem_muc)
    print("loai:", dem_loai)
    print("tong_co_theo_loai:", theo_loai)
    print("da ghep:", co_da_ghep, "chua ghep/CNQ:", tong_co - co_da_ghep)
    print("don chua thu:", [o["ma"] for o in chua_thu])
    print("ngoai le:", len(ngoai_le))


def tien_fmt(n):
    return f"{n:,}".replace(",", ".") + " đ"


if __name__ == "__main__":
    main()
