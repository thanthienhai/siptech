# BÁO CÁO TỒN KHO VÀ ĐỀ XUẤT NHẬP HÀNG THÁNG 11/2026
**Kính gửi:** Chủ cửa hàng  
**Người lập:** Trợ lý kho  
**Kỳ dữ liệu:** 12 tháng (01/11/2025 đến 31/10/2026) — 60 mã hàng  

---

## 1. Tóm tắt 5 dòng
1. **Làm sạch dữ liệu:** Đã xử lý 11.128 dòng nhật ký, phát hiện và phân loại chính xác 125 dòng lỗi/bất thường theo đúng quy ước, không tự ý bịa số liệu.
2. **Nhu cầu vốn lý thuyết:** Theo công thức quy ước, nhu cầu nhập chưa xét ngân sách là **46.958.400 đ** (26 mã hàng), vượt ngân sách 30.000.000 đ là **16.958.400 đ**.
3. **Phương án phân bổ ngân sách:** Đề xuất nhập **15 mặt hàng** với tổng tiền vốn là **29.692.400 đ** (đạt 98,97% ngân sách, dư an toàn 307.600 đ), 100% số lượng là bội số quy cách.
4. **Bảo vệ hàng trọng điểm:** Bảo đảm 100% nhu cầu của 7 mã sắp hết hàng (`SAP_HET`), ưu tiên các mặt hàng nhóm A/B tồn dưới 21 ngày; cắt giảm các mã nhóm C và các mã tồn còn trên 30 ngày.
5. **Cảnh báo và kiểm định:** Phát hiện 2 mã hết hàng (`HET_HANG`) trong đó MP002 cần duyệt nhập khẩn; kiểm định 2 tháng giữ lại cho thấy công thức trung bình trượt có sai số WAPE là 37,89% (cao hơn mốc tháng trước là 27,24%).

---

## 2. Tổng tiền vốn đề xuất so với ngân sách, phần bị cắt và cách ưu tiên

### 2.1. Tổng quan ngân sách
- **Ngân sách ấn định:** 30.000.000 đ
- **Tổng tiền vốn cần chưa xét ngân sách:** 46.958.400 đ (26 mã)
- **Số tiền vượt trần ngân sách:** 16.958.400 đ
- **Tổng tiền vốn đề xuất sau phân bổ:** **29.692.400 đ** (15 mã)
- **Số dư ngân sách dự phòng:** 307.600 đ

### 2.2. Thứ tự ưu tiên phân bổ
Để không vượt ngân sách mà vẫn bảo đảm cửa hàng không bị đứt hàng bán chạy, quy tắc phân bổ được thực hiện theo 4 cấp ưu tiên:
1. **Cấp 1 — Nhập 100% hàng Sắp hết (`SAP_HET`):** Toàn bộ 7 mặt hàng sắp hết có nhu cầu nhập được duyệt 100% (MP001, MP015, MP006, MP008, TH023, VT016, VT018). Tổng vốn: **14.406.000 đ**.
2. **Cấp 2 — Nhập 100% hàng nhóm B có tồn thấp (< 21 ngày):** VT007 (tồn 15,2 ngày), TH012 (tồn 16,5 ngày), TH010 (tồn 20,4 ngày). Tổng vốn: **1.449.600 đ**.
3. **Cấp 3 — Nhập 100% hàng nhóm A chủ lực có tồn thấp & vốn vừa phải:** TH009 (Nước suối), TH002 (Dầu ăn), MP005 (Sữa tắm), VT005 (Giấy vệ sinh, tồn 17,7 ngày). Tổng vốn: **10.156.800 đ**.
4. **Cấp 4 — Điều chỉnh giảm hàng nhóm A chiếm vốn lớn nhất (TH001 - Gạo thơm 5kg):** Nhu cầu lý thuyết là 128 túi (11.776.000 đ). Đề xuất giảm xuống **40 túi** (**3.680.000 đ**, bội số của 4) để vừa trọn ngân sách 30 triệu. Số lượng 40 túi cộng với tồn hiện tại 230 túi (đủ bán 21,7 ngày) sẽ bảo đảm đủ hàng bán hết tháng 11.

### 2.3. Bảng các mặt hàng được đề xuất nhập tháng 11/2026 (15 mã)
| Mã hàng | Tên hàng | Nhóm ABC | Cảnh báo | Số ngày tồn | SL cần ban đầu | SL đề xuất | Quy cách | Đơn giá vốn (đ) | Thành tiền (đ) | Mức ưu tiên |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **TH023** | Trứng gà vỉ 10 quả | A | SAP_HET | 5,5 | 30 | **30** | 10 | 28.000 | 840.000 | 1 |
| **MP001** | Kem chống nắng tuýp 50g | A | SAP_HET | 14,5 | 60 | **60** | 12 | 128.000 | 7.680.000 | 1 |
| **MP006** | Son dưỡng môi thỏi | A | SAP_HET | 32,9 | 24 | **24** | 24 | 45.000 | 1.080.000 | 1 |
| **MP015** | Serum vitamin C chai 30ml | B | SAP_HET | 18,0 | 18 | **18** | 6 | 185.000 | 3.330.000 | 1 |
| **MP008** | Nước tẩy trang chai 300ml | B | SAP_HET | 30,0 | 12 | **12** | 12 | 82.000 | 984.000 | 1 |
| **VT016** | Dây điện nối dài ổ cắm 5m | C | SAP_HET | 25,7 | 4 | **4** | 2 | 95.000 | 380.000 | 1 |
| **VT018** | Keo dán đa năng tuýp | C | SAP_HET | 25,7 | 4 | **4** | 4 | 28.000 | 112.000 | 1 |
| **VT007** | Nước rửa chén chai 750ml | B | OK | 15,2 | 24 | **24** | 12 | 24.000 | 576.000 | 3 |
| **TH012** | Sữa đặc có đường lon 380g | B | OK | 16,5 | 24 | **24** | 24 | 24.000 | 576.000 | 3 |
| **VT005** | Giấy vệ sinh lốc 10 cuộn | A | OK | 17,7 | 120 | **120** | 12 | 52.000 | 6.240.000 | 2 |
| **MP005** | Sữa tắm chai 900ml | A | OK | 19,4 | 24 | **24** | 12 | 98.000 | 2.352.000 | 2 |
| **TH010** | Trà xanh đóng chai 455ml | B | OK | 20,4 | 48 | **48** | 24 | 6.200 | 297.600 | 3 |
| **TH001** | Gạo thơm túi 5kg | A | OK | 21,7 | 128 | **40** | 4 | 92.000 | 3.680.000 | 2 (Cắt giảm) |
| **TH002** | Dầu ăn đậu nành chai 1L | A | OK | 25,6 | 24 | **24** | 12 | 46.000 | 1.104.000 | 2 |
| **TH009** | Nước suối chai 500ml | A | OK | 26,9 | 144 | **144** | 24 | 3.200 | 460.800 | 2 |
| **TỔNG** | | | | | | | | | **29.692.400** | |

### 2.4. Danh sách 11 mặt hàng bị cắt giảm do ngân sách
| Mã hàng | Tên hàng | Nhóm | Tình trạng | Số ngày tồn | SL cắt | Tiền cắt giảm (đ) | Lý do cắt giảm |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **TH001** | Gạo thơm túi 5kg | A | OK | 21,7 | 88 | 8.096.000 | Cắt bớt phần nhu cầu dư, chỉ nhập 40 túi để giữ tổng vốn dưới 30 triệu. |
| **TH008** | Nước ngọt có ga lon | A | OK | 28,0 | 360 | 2.700.000 | Tồn kho còn 1.076 lon (đủ bán 28 ngày), chưa cấp bách. |
| **MP003** | Dầu gội chai 650ml | A | OK | 30,5 | 12 | 1.056.000 | Tồn kho còn đủ bán hơn 1 tháng, hoãn sang tháng sau. |
| **MP012** | Kem đánh răng tuýp 180g | A | OK | 35,9 | 24 | 744.000 | Tồn kho còn 83 tuýp (đủ bán 36 ngày), hoãn sang tháng sau. |
| **VT013** | Ô gấp | B | OK | 33,8 | 10 | 850.000 | Tồn kho còn đủ bán 34 ngày. |
| **TH006** | Mì gói thùng 30 gói | B | OK | 45,0 | 6 | 588.000 | Tồn kho còn đủ bán 45 ngày (1,5 tháng). |
| **TH013** | Cà phê hòa tan hộp 20 | B | OK | 31,5 | 12 | 456.000 | Tồn kho còn đủ bán hơn 1 tháng. |
| **VT012** | Áo mưa bộ | C | OK | 36,8 | 20 | 720.000 | Hàng nhóm C, doanh số nhỏ, tồn còn 37 ngày. |
| **TH020** | Bột ngọt gói 400g | C | OK | 18,0 | 20 | 560.000 | Hàng nhóm C, tạm hoãn để ưu tiên vốn cho nhóm A. |
| **MP013** | Bàn chải đánh răng | C | OK | 19,9 | 48 | 576.000 | Hàng nhóm C, tạm hoãn để ưu tiên vốn cho nhóm A. |
| **VT020** | Bút bi hộp 20 cây | C | OK | 21,8 | 20 | 560.000 | Hàng nhóm C, tạm hoãn để ưu tiên vốn cho nhóm A. |
| **VT002** | Pin AA vỉ 4 viên | C | OK | 37,3 | 20 | 360.000 | Hàng nhóm C, tồn còn 37 ngày. |

---

## 3. Bảng hàng sắp hết, hết hàng, tồn lâu, bán chậm

### 3.1. Hàng hết hàng (`HET_HANG` — Tồn kiểm kê = 0)
| Mã hàng | Tên hàng | Nhóm | Tồn KK | Hàng đang về | Ngày dự kiến về | Đánh giá & Rủi ro |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **MP011** | Lăn khử mùi chai 50ml | B | 0 | 24 | 05/11/2026 | An toàn: Đơn hàng 24 chai về ngay đầu tháng 11, không lo đứt hàng. |
| **MP002** | Sữa rửa mặt tuýp 100g | B | 0 | 12 | **27/12/2026** | **RẤT NGUY HIỂM:** Hàng đang về tận 27/12 (sau 2 tháng). Nguy cơ đứt hàng toàn bộ tháng 11 và 12. Cần chủ duyệt đặt khẩn. |

### 3.2. Hàng sắp hết (`SAP_HET` — 0 < Tồn KK ≤ Điểm đặt lại ROP)
| Mã hàng | Tên hàng | Nhóm | Tồn KK | Điểm đặt lại ROP | Tồn an toàn SS | Hàng đang về | Đề xuất xử lý |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **TH023** | Trứng gà vỉ 10 quả | A | 13 | 20 | 5 | 50 (về 04/11) | Nhập thêm 30 vỉ (bán rất nhanh, tồn chỉ còn 5,5 ngày). |
| **MP001** | Kem chống nắng tuýp 50g | A | 27 | 40 | 13 | 0 | Nhập đủ 60 tuýp (nhóm A chủ lực, tồn chỉ còn 14,5 ngày). |
| **MP006** | Son dưỡng môi thỏi | A | 19 | 20 | 8 | 0 | Nhập 24 thỏi. |
| **MP015** | Serum vitamin C chai 30ml | B | 9 | 13 | 4 | 0 | Nhập 18 chai (hàng mới bán chạy). |
| **MP008** | Nước tẩy trang chai 300ml | B | 12 | 5 | 2 | 0 | Nhập 12 chai. |
| **VT016** | Dây điện nối dài 5m | C | 2 | 3 | 1 | 0 | Nhập 4 cái. |
| **VT018** | Keo dán đa năng tuýp | C | 2 | 2 | 1 | 0 | Nhập 4 tuýp. |
| **VT008** | Bột giặt túi 3kg | A | 21 | 21 | 12 | 60 (về 06/11) | Đã có hàng về 60 túi, không cần đặt thêm. |
| **MP014** | Dầu dưỡng tóc chai 100ml | B | 24 | 7 | 4 | 24 (về 08/11) | Đã có hàng về 24 chai, không cần đặt thêm. |
| **TH014** | Trà túi lọc hộp 25 túi | C | 7 | 7 | 3 | 24 (về 07/11) | Đã có hàng về 24 hộp, không cần đặt thêm. |
| **VT004** | Túi rác cuộn trung | C | 5 | 7 | 2 | 30 (về 04/11) | Đã có hàng về 30 cuộn, không cần đặt thêm. |
| **MP010** | Toner pad hộp 60 miếng | C | 10 | 12 | 4 | 24 (về 08/11) | Đã có hàng về 24 hộp, không cần đặt thêm. |

### 3.3. Hàng tồn lâu (`TON_LAU` — Số ngày tồn > 120 ngày hoặc không bán được trong 90 ngày cuối)
| Mã hàng | Tên hàng | Nhóm | Tồn KK | Nhu cầu F/tháng | Số ngày tồn | Trạng thái / Nguyên nhân |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **TH021** | Nước tương chai 500ml (mã cũ) | C | 61 | 13,4 | **136,5 ngày** | Mã cũ, trạng thái `ngung_nhap`, đang bán giải phóng tồn. |
| **VT017** | Bóng đèn tròn sợi đốt 40W | C | 46 | 8,2 | **168,0 ngày** | Hàng lỗi thời, trạng thái `ngung_nhap`, xả hàng tồn. |
| **TH015** | Bánh quy hộp thiếc 500g | C | 25 | 6,0 | **125,0 ngày** | Bán chậm sau Tết, tồn kho kéo dài. |
| **TH017** | Kẹo dẻo gói 100g | C | 84 | 19,4 | **130,2 ngày** | Nhập nhiều đợt trước, tốc độ bán chậm lại. |
| **TH019** | Hạt dưa gói 200g | C | 11 | 0,0 | **Không bán 90 ngày** | Hàng thời vụ Tết, từ tháng 05 đến tháng 10 không phát sinh bán. |

### 3.4. Hàng bán chậm (`BAN_CHAM` — Nhu cầu F < 3 đơn vị/tháng)
| Mã hàng | Tên hàng | Nhóm | Tồn KK | Nhu cầu F/tháng | Số ngày tồn | Đánh giá |
| :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **VT011** | Thuốc xịt muỗi chai 600ml | C | 15 | **2,67** | 168,8 ngày | Nhu cầu trung bình chỉ ~2,7 chai/tháng, tồn 15 chai đủ bán gần 6 tháng. |

---

## 4. Kết quả kiểm định giữ lại 2 tháng cuối (Hold-out 2026-09 và 2026-10)

Theo quy ước, mô hình dự báo đã được chạy kiểm định trên 2 tháng giữ lại (chỉ dùng dữ liệu quá khứ trước tháng đó) và đối chuẩn trực tiếp với Mốc ngây thơ 1 ("bằng doanh số thô tháng liền trước").

### 4.1. Bảng so sánh sai số dự báo
| Chỉ số sai số | Công thức quy ước (Trung bình trượt 3 tháng hợp lệ) | Mốc ngây thơ 1 (Doanh số thô tháng liền trước) | Chênh lệch |
| :--- | :---: | :---: | :---: |
| **MAE (Sai số tuyệt đối trung bình)** | **22,04 đơn vị** | **15,84 đơn vị** | Công thức sai lệch nhiều hơn +6,20 đơn vị |
| **WAPE (Tỷ lệ sai số trọng số)** | **37,89%** | **27,24%** | Công thức kém hơn +10,65% |
| **Số mẫu đo lường hợp lệ (n)** | **102 mã-tháng** | **102 mã-tháng** | (Đủ điều kiện không cụt hàng & ≥ 3 tháng trước đó) |

### 4.2. Báo cáo trung thực và giải thích nguyên nhân
1. **Kết quả kém hơn mốc ngây thơ:** Công thức trung bình trượt 3 tháng cho kết quả kém hơn cách lấy thẳng số bán tháng trước (WAPE 37,89% so với 27,24%).
2. **Lý do kỹ thuật:**
   - Phương pháp trung bình trượt tạo ra độ trễ (lag): Khi nhu cầu của một mặt hàng đang trên đà tăng hoặc giảm, trung bình trượt 3 tháng bị chậm nhịp so với thực tế, trong khi số bán tháng liền trước bắt nhịp xu hướng nhanh hơn.
   - Khi loại bỏ các tháng cụt hàng, công thức buộc phải lấy lùi về các tháng quá khứ xa hơn (4-5 tháng trước), khiến dự báo không còn phản ánh đúng quy mô tiêu thụ hiện tại.
3. **Những hạn chế và điều chưa đo được:**
   - **Cỡ mẫu nhỏ (n = 102):** Chỉ đánh giá trên 2 tháng gần nhất nên chưa đủ kiểm nghiệm tính vững chắc cho cả năm.
   - **Chưa đo được mốc ngây thơ 2 ("Cùng kỳ năm trước"):** Dữ liệu cửa hàng chỉ có 12 tháng (11/2025 đến 10/2026), nên với tháng 09/2026 và 10/2026 không có dữ liệu tháng 09/2025 và 10/2025 để so sánh. Mốc cùng kỳ chỉ áp dụng được cho tháng 11/2026 (so với 11/2025).
   - **Tính mùa vụ dài hạn:** Chưa nắm bắt được các mặt hàng biến động mạnh theo mùa (ví dụ hạt dưa, bánh kẹo Tết).

---

## 5. Danh sách lỗi dữ liệu và cách xử lý (File `loi-du-lieu.csv`)

Tổng cộng đã phát hiện và xử lý **125 trường hợp lỗi và giao dịch đặc biệt**:
- **Trùng dòng (`trung_dong`, 11 dòng):** Bỏ dòng lặp (`BO`), giữ 1 bản ghi duy nhất.
- **Thiếu mã hàng (`khac`, 4 dòng):** Đã sửa (`SUA`) bằng cách đối chiếu tên hàng để điền mã chuẩn (TH003, TH009, MP006, VT006).
- **Giao dịch không phải bán lẻ (`khong_phai_ban_hang`, 89 dòng):** Giữ nguyên (`GIU`) để tính biến động tồn kho nhưng loại khỏi nhu cầu bán hàng (gồm 55 phiếu điều chỉnh hao hụt vỡ hỏng, 18 phiếu xuất dùng tại quán, 16 phiếu hủy hàng hết hạn).
- **Nhóm cần người quyết định (`CAN_NGUOI_QUYET`, 21 dòng):** Gồm 3 phiếu thiếu số lượng, 6 phiếu xuất âm không ghi chú, 2 phiếu nhập ghi ngày tương lai, 8 phiếu đơn sỉ đại lý có ghi chú, 2 phiếu xuất sỉ đột biến không ghi chú.

### Giải thích nguyên nhân 15 mã chênh lệch giữa Tồn hệ thống và Tồn kiểm kê:
| Nhóm nguyên nhân | Mã hàng | Chênh lệch (Tồn HT − Tồn KK) | Giải thích nguyên nhân cụ thể |
| :--- | :--- | :---: | :--- |
| **Ghi nhầm ngày tương lai** | **VT001** | **−20** | Phiếu nhập PN0349 (20 cái) ghi ngày 11/12/2026. Tồn HT đến 31/10 chưa cộng vào nên âm 3 (KK là 17). Nếu sửa ngày về tháng 10 thì khớp 100%. |
| | **MP015** | **−18** | Phiếu nhập PN0350 (18 chai) ghi ngày 13/12/2026. Tồn HT chưa cộng nên âm 9 (KK là 9). Nếu sửa ngày thì khớp 100%. |
| **Gõ nhầm dấu âm hoặc thiếu ghi chú** | **MP003** | **+8** | Phiếu PX00679 xuất âm 4 không ghi chú. Nghi nhầm dấu (nếu xuất dương 4 thì lệch đúng 8). |
| | **TH003** | **+6** | Phiếu PX10062 xuất âm 3 không ghi chú. Nghi gõ nhầm dấu âm thay vì dương. |
| | **TH018** | **+6** | Phiếu PX05950 xuất âm 3 không ghi chú. Nghi gõ nhầm dấu âm. |
| | **MP012** | **+9** | Phiếu PX04140 xuất âm 3 không ghi chú. |
| | **VT007** | **+9** | Phiếu PX01374 xuất âm 3 không ghi chú và PX01404 thiếu số lượng. |
| | **TH023** | **−18** | Phiếu PX03573 xuất âm 3 không ghi chú và 2 phiếu PX02391, PX09402 thiếu số lượng. |
| **Hao hụt/thất thoát thực tế** | **TH002** | **−45** | Dầu ăn chai 1L: Tồn HT là 1 chai, kiểm kê thực tế 46 chai. Nghi bỏ sót chứng từ nhập kho. |
| | **TH011** | **−23** | Sữa tươi hộp 1L: Hao hụt hoặc thiếu phiếu nhập. |
| | **MP001** | **−27** | Kem chống nắng: Nghi thiếu phiếu nhập trong kỳ. |
| | **MP006** | **−27** | Son dưỡng môi: Nghi thiếu phiếu nhập trong kỳ. |
| | **MP013** | **−27** | Bàn chải đánh răng: Nghi thiếu phiếu nhập trong kỳ. |
| | **TH012** | **+4** | Lệch kiểm kê nhỏ (hao hụt thông thường). |
| | **VT019** | **+3** | Lệch kiểm kê nhỏ (3 cuốn tập học sinh). |

---

## 6. Các giả định tính toán đã áp dụng
1. **Thời gian giao hàng cố định:** Sử dụng số ngày giao hàng trong `danh-muc-hang.csv` làm chuẩn cố định, không tính biến thiên thời gian giao hàng.
2. **Nhu cầu độc lập:** Giả định nhu cầu tiêu thụ giữa các tháng là các biến ngẫu nhiên độc lập.
3. **Mức độ phục vụ 95%:** Hệ số an toàn Z = 1,645 theo phân phối chuẩn.
4. **Mặt hàng thiếu dữ liệu:** Với các mặt hàng bán dưới 3 tháng hợp lệ (MP010, MP015), áp dụng giả định độ lệch chuẩn σ = 0,5 × F theo đúng quy ước.
5. **Quy cách đóng gói:** Mọi đề xuất đặt hàng đều phải làm tròn lên theo đúng bội số quy cách đặt hàng của nhà cung cấp.
6. **Tách biệt đơn sỉ đột xuất:** Loại bỏ 5 giao dịch bán sỉ đột xuất để dữ liệu phản ánh chính xác nhu cầu bán lẻ thường xuyên của khách hàng cá nhân.
7. **Cơ sở tồn kho hiện tại:** Lấy số liệu kiểm kê thực tế ngày 31/10/2026 trong file `ton-kiem-ke` làm căn cứ tính lượng cần nhập.

---

## 7. Danh sách CẦN NGƯỜI QUYẾT (Các vấn đề chờ Chủ duyệt)

| STT | Vấn đề cần quyết định | Chi tiết & Đề xuất của trợ lý | Lựa chọn của Chủ cửa hàng |
| :---: | :--- | :--- | :--- |
| **1** | **Duyệt phương án ngân sách 29.692.400 đ** | Đề xuất nhập 15 mã hàng, trong đó mã gạo TH001 giảm từ 128 túi xuống 40 túi để giữ trong trần 30 triệu. | [ ] Duyệt phương án 29,69tr<br>[ ] Tăng thêm ngân sách để nhập đủ 128 túi gạo (+8,1tr) |
| **2** | **Nhập khẩn mặt hàng MP002 (Sữa rửa mặt)** | Hàng đã hết (tồn=0), đơn hàng đặt trước 12 tuýp dự kiến tận 27/12/2026 mới về. Nếu không đặt khẩn sẽ đứt hàng suốt 2 tháng. | [ ] Đặt khẩn 12 tuýp (744.000 đ) ngay đầu tháng 11<br>[ ] Chờ đơn hàng tháng 12 |
| **3** | **Xác nhận 2 phiếu nhập ngày tương lai** | Phiếu PN0349 (VT001 nhập 20 cái) và PN0350 (MP015 nhập 18 chai) bị ghi ngày tháng 12/2026. | [ ] Xác nhận đã nhận hàng trong tháng 10, sửa ngày chứng từ<br>[ ] Hàng chưa về, giữ nguyên ngày |
| **4** | **Xác nhận 6 phiếu xuất âm không ghi chú** | PX00679 (MP003, -4), PX01374 (VT007, -3), PX03573 (TH023, -3), PX04140 (MP012, -3), PX05950 (TH018, -3), PX10062 (TH003, -3). | [ ] Đây là khách trả hàng<br>[ ] Đây là lỗi nhân viên gõ nhầm dấu âm thay vì dương |
| **5** | **Xử lý 3 phiếu xuất thiếu số lượng** | PX01404 (VT007), PX02391 (TH023), PX09402 (TH023) bị để trống số lượng. | [ ] Cho kiểm tra lại cùi vé/hóa đơn giấy để điền bổ sung<br>[ ] Hủy bỏ 3 phiếu này |
| **6** | **Xử lý chênh lệch kiểm kê lớn** | 5 mặt hàng có chênh lệch lớn giữa sổ sách và kiểm kê: TH002 (-45 chai), TH011 (-23 hộp), MP001 (-27 tuýp), MP006 (-27 thỏi), MP013 (-27 cây). | [ ] Cho rà soát phiếu nhập kho bị sót<br>[ ] Lập biên bản điều chỉnh kiểm kê kỳ này |
| **7** | **Kế hoạch cho hàng tồn lâu** | TH021 (Nước tương) và VT017 (Bóng đèn sợi đốt) đã ngưng nhập nhưng tồn còn >130 ngày; TH019 (Hạt dưa) không bán được trong 90 ngày. | [ ] Giảm giá xả hàng thu hồi vốn<br>[ ] Gom hàng đóng gói combo khuyến mãi Tết |

---
*Báo cáo được lập tự động bằng script Python `tinh_ton_kho.py`. Toàn bộ dữ liệu chi tiết có thể tra cứu tại các file:*
- [`loi-du-lieu.csv`](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/07/runs/agy/loi-du-lieu.csv)
- [`phan-loai-tinh-toan.csv`](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/07/runs/agy/phan-loai-tinh-toan.csv)
- [`de-xuat-nhap.csv`](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/07/runs/agy/de-xuat-nhap.csv)
- [`giu-lai-do-loi.csv`](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/07/runs/agy/giu-lai-do-loi.csv)
