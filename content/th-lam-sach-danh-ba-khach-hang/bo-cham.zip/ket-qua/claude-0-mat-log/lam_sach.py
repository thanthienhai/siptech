#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
lam_sach.py - Làm sạch danh bạ khách hàng (quy tắc cố định, không mô hình, không mạng).

Đọc : danh-ba-goc.xlsx (sheet DanhBa)  -- chỉ đọc, không sửa
Ghi  : danh-ba-sach.xlsx, nhat-ky-gop.csv, nhat-ky-sua.csv, nghi-trung-can-quyet.csv
Chạy : python lam_sach.py      (chạy lại cho đúng kết quả cũ)

Các bước: (1) chuẩn hóa từng dòng  (2) so khớp từng cặp dòng theo G1/G2/Q1/Q2
          (3) gộp bắc cầu bằng union-find  (4) ghi file  (5) tự kiểm.
"""
import csv
import re
import sys
import unicodedata
from collections import defaultdict, deque
from itertools import combinations
from pathlib import Path

import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

HERE = Path(__file__).resolve().parent
FILE_GOC = HERE / "danh-ba-goc.xlsx"
SHEET_GOC = "DanhBa"

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:  # noqa: BLE001
    pass


# ----------------------------------------------------------------------------
# Tiện ích chuỗi
# ----------------------------------------------------------------------------
def nfc(s):
    return unicodedata.normalize("NFC", s)


def fold_char(c):
    """Bỏ dấu một ký tự, luôn trả về đúng 1 ký tự (giữ nguyên độ dài chuỗi)."""
    if c in "đĐ":
        return "d" if c == "đ" else "D"
    return unicodedata.normalize("NFD", c)[0]


def fold(s):
    """Bỏ dấu tiếng Việt (độ dài giữ nguyên với chuỗi NFC)."""
    return "".join(fold_char(c) for c in nfc(s))


def has_diacritics(s):
    return fold(s) != nfc(s)


def squash(s):
    return re.sub(r"\s+", " ", s).strip()


def cap_words(s):
    """Viết Hoa Chữ Đầu Mỗi Từ."""
    return " ".join(w[:1].upper() + w[1:].lower() for w in squash(s).split(" ") if w)


def cell_text(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v)


# ----------------------------------------------------------------------------
# SĐT
# ----------------------------------------------------------------------------
RE_PHONE_ONLY = re.compile(r"^[\d\s.\-+()*/;,|]+$")
RE_PHONE_IN_TEXT = re.compile(r"(?:\+|\(\+)?\d[\d .\-()]{7,}\d")
RE_PHONE_LABEL = re.compile(r"(?:liên hệ|lien he|sđt|sdt)\s*:?\s*$", re.I)


def norm_phone(raw):
    """Chuẩn hóa về dạng chỉ chữ số, đầu 0. Có thể trả về chuỗi KHÔNG hợp lệ."""
    plus = "+" in raw
    d = re.sub(r"\D", "", raw)
    if not d:
        return ""
    if d.startswith("0084"):
        rest = d[4:]
        d = rest if rest.startswith("0") else "0" + rest
    elif d.startswith("84") and (plus or len(d) in (11, 12)):
        rest = d[2:]
        d = rest if rest.startswith("0") else "0" + rest
    elif len(d) == 9 and not d.startswith("0"):
        d = "0" + d
    return d


def phone_valid(d):
    return bool(re.fullmatch(r"0[35789]\d{8}", d) or re.fullmatch(r"02\d{9}", d))


# ----------------------------------------------------------------------------
# Email
# ----------------------------------------------------------------------------
TLD_OK = {"com", "net", "org", "vn", "com.vn", "edu.vn", "gov.vn", "info", "biz",
          "edu", "gov", "io", "co", "me"}
RE_EMAIL_FIND = re.compile(r"[^\s;,]+@[^\s;]+")


def norm_email(raw):
    e = raw.strip().lower()
    if "@" in e:
        local, _, dom = e.partition("@")
        e = local + "@" + dom.replace(",", ".")
    return e


def email_valid(e):
    if e.count("@") != 1 or re.search(r"\s", e):
        return False
    local, dom = e.split("@")
    if not re.fullmatch(r"[a-z0-9][a-z0-9._%+\-]*", local) or local.endswith("."):
        return False
    labels = dom.split(".")
    if len(labels) < 2 or any(not re.fullmatch(r"[a-z0-9\-]+", x) or x.startswith("-")
                              or x.endswith("-") for x in labels):
        return False
    tld = ".".join(labels[-2:]) if ".".join(labels[-2:]) in TLD_OK else labels[-1]
    return tld in TLD_OK


# ----------------------------------------------------------------------------
# Họ tên
# ----------------------------------------------------------------------------
TITLES = {"anh": "Anh", "a": "Anh", "chị": "Chị", "chi": "Chị", "c": "Chị",
          "cô": "Cô", "co": "Cô", "chú": "Chú", "chu": "Chú", "bác": "Bác", "bac": "Bác"}


def split_title(name):
    """Tách danh xưng ở đầu. Trả về (danh_xung_chuan | '', ten_con_lai)."""
    toks = name.split(" ")
    if len(toks) >= 2:
        t = toks[0]
        key = t.lower()
        if key in TITLES and not (key == "chu" and t[:1].isupper()):  # 'Chu' viết hoa = họ Chu
            return TITLES[key], " ".join(toks[1:])
    return "", name


def name_tokens(name):
    return [t.lower() for t in name.split(" ") if t]


def tok_eq(a, b):
    """Hai chữ giống nhau: y hệt, hoặc một bên KHÔNG dấu và bỏ dấu bên kia thì khớp.
    Hai chữ cùng có dấu mà khác nhau (Hùng/Hưng) là khác."""
    if a == b:
        return True
    fa, fb = fold(a), fold(b)
    return fa == fb and (a == fa or b == fb)


def is_initial(t):
    return len(t.rstrip(".")) == 1 and t.rstrip(".").isalpha()


def tok_init_match(a, b):
    """Một trong hai là chữ cái đầu viết tắt của chữ kia."""
    for x, y in ((a, b), (b, a)):
        if is_initial(x) and not is_initial(y) and fold(y)[0] == fold(x.rstrip("."))[0]:
            return True
    return False


def name_same(t1, t2):
    return len(t1) == len(t2) and all(tok_eq(a, b) for a, b in zip(t1, t2))


def name_compat(t1, t2):
    if len(t1) != len(t2):
        return False
    n = len(t1)
    for i, (a, b) in enumerate(zip(t1, t2)):
        if tok_eq(a, b):
            continue
        if 0 < i < n - 1 and tok_init_match(a, b):  # chỉ chữ đệm mới được viết tắt
            continue
        return False
    return True


# ----------------------------------------------------------------------------
# Địa chỉ
# ----------------------------------------------------------------------------
CITY_ABBR = {"hcm": "Hồ Chí Minh", "tphcm": "Hồ Chí Minh", "hn": "Hà Nội", "dn": "Đà Nẵng",
             "ct": "Cần Thơ", "hp": "Hải Phòng"}
CITY_FULL = {"ho chi minh", "ha noi", "da nang", "can tho", "hai phong"}
RE_CITY = re.compile(
    r"(?:^|(?<=[\s,.]))(?:(?:tp|thanh pho)\.?\s*)?"
    r"(tphcm|hcm|ho chi minh|ha noi|da nang|can tho|hai phong|hn|dn|ct|hp)\s*$", re.I)
RE_WARD = re.compile(r"(?:(?<=[\s,])|^)(phường|p|f)(?=[\s.\d])\.?\s*", re.I)
RE_DIST = re.compile(r"(?:(?<=[\s,])|^)(quận|q)(?=[\s.\d])\.?\s*", re.I)


def clean_street(piece):
    piece = piece.strip(" ,.")
    m = re.match(r"^((?:\d[\w/\-]*)\s+)?(.*)$", piece)
    num = (m.group(1) or "").strip()
    name = m.group(2)
    name = re.sub(r"^(?:đường\s+|đ\.\s*)", "", name, flags=re.I)
    return squash(" ".join(x for x in (num, cap_words(name)) if x))


def unit_text(label, piece):
    piece = piece.strip(" ,.")
    if not piece:
        return ""
    return f"{label} {piece}" if piece.isdigit() else f"{label} {cap_words(piece)}"


def clean_address(raw):
    """Trả về (địa chỉ chuẩn, đầy_đủ: có đủ phường+quận+thành phố)."""
    s = squash(nfc(raw))
    s = re.sub(r"^số\s+", "", s, flags=re.I)
    city = ""
    m = RE_CITY.search(fold(s).lower())
    if m:
        key = m.group(1)
        orig = s[m.start(1):m.end(1)]
        s = s[:m.start()].strip(" ,.")
        name = CITY_ABBR.get(key, cap_words(orig))
        is_hcm = key in ("tphcm", "hcm", "ho chi minh")
        city = ("Thành phố " + name) if is_hcm else name
    mw = RE_WARD.search(s)
    md = RE_DIST.search(s, mw.end() if mw else 0)
    ward = dist = ""
    if mw and md:
        street, ward, dist = s[:mw.start()], s[mw.end():md.start()], s[md.end():]
    elif mw:
        street, ward = s[:mw.start()], s[mw.end():]
    elif md:
        street, dist = s[:md.start()], s[md.end():]
    else:
        street = s
    parts = [clean_street(street), unit_text("Phường", ward), unit_text("Quận", dist), city]
    parts = [p for p in parts if p]
    return ", ".join(parts), bool(ward and dist and city)


def addr_key(a):
    return fold(a).lower() if a else ""


# ----------------------------------------------------------------------------
# Bước 1: chuẩn hóa từng dòng
# ----------------------------------------------------------------------------
COLS_GOC = ["Mã dòng", "Nguồn", "Họ tên", "SĐT", "Email", "Địa chỉ", "Ghi chú"]


def clean_row(rec):
    """rec: dict các cột gốc (đã chuyển thành chuỗi). Trả về dict kết quả + log ô."""
    tags = defaultdict(set)  # cột -> các nhãn quy tắc
    raw = {c: rec[c] for c in COLS_GOC}

    # --- 1. họ tên / địa chỉ đổi chỗ -------------------------------------------------
    name_raw, addr_raw = raw["Họ tên"], raw["Địa chỉ"]
    if re.search(r"\d", name_raw) and addr_raw and not re.search(r"\d", addr_raw):
        name_raw, addr_raw = addr_raw, name_raw
        tags["Họ tên"].add("doi_cho_ten_dia_chi")
        tags["Địa chỉ"].add("doi_cho_ten_dia_chi")

    # --- 2. SĐT & email: gom ứng viên từ cả 3 cột -------------------------------------
    phones, emails = [], []   # (giá trị đã chuẩn hóa, cột nguồn)
    bad_phone, bad_email = [], []  # (giá trị thô, cột nguồn)
    note = raw["Ghi chú"]

    def take_phone(piece, col):
        d = norm_phone(piece)
        if phone_valid(d):
            phones.append((d, col))
            if col != "SĐT":
                tags[col].add("sdt_nhap_nham_cot")
        else:
            bad_phone.append((piece.strip(), col))
            tags[col].add("sdt_khong_hop_le")

    def take_email(piece, col):
        e = norm_email(piece)
        if email_valid(e):
            emails.append((e, col))
            if col != "Email":
                tags[col].add("email_nhap_nham_cot")
        else:
            bad_email.append((piece.strip(), col))
            tags[col].add("email_khong_hop_le")

    s = raw["SĐT"]
    if s.strip():
        if "@" in s or re.search(r"[A-Za-z]", s):
            take_email(s, "SĐT")
        else:
            for piece in re.split(r"[;/,|]", s):
                if piece.strip():
                    take_phone(piece, "SĐT")
    e = raw["Email"]
    if e.strip():
        if RE_PHONE_ONLY.match(e.strip()):
            for piece in re.split(r"[;/,|]", e):
                if piece.strip():
                    take_phone(piece, "Email")
        else:
            take_email(e, "Email")
    new_note = note
    n_before = len(phones) + len(bad_phone) + len(emails) + len(bad_email)
    for m in list(RE_PHONE_IN_TEXT.finditer(note)):
        take_phone(m.group(0), "Ghi chú")
    for m in list(RE_EMAIL_FIND.finditer(note)):
        take_email(m.group(0), "Ghi chú")
    if len(phones) + len(bad_phone) + len(emails) + len(bad_email) > n_before:
        # SĐT/email đã được chuyển sang cột đúng: bỏ khỏi Ghi chú (kể cả nhãn "liên hệ", "SĐT:")
        new_note = RE_PHONE_IN_TEXT.sub("", note)
        new_note = RE_EMAIL_FIND.sub("", new_note)
        new_note = RE_PHONE_LABEL.sub("", new_note.strip()).strip(" :;,-")

    def uniq(seq):
        out = []
        for v, c in seq:
            if v not in [x for x, _ in out]:
                out.append((v, c))
        return out

    phone_list, email_list = uniq(phones), uniq(emails)
    sdt = phone_list[0][0] if phone_list else ""
    sdt_khac = ";".join(v for v, _ in phone_list[1:])
    email = email_list[0][0] if email_list else ""
    email_khac = ";".join(v for v, _ in email_list[1:])
    for v, c in phone_list[1:]:
        tags["sdt_khac"].add("sdt_tach_hai_so" if c == "SĐT" else "sdt_nhap_nham_cot")
        if c == "SĐT":
            tags["SĐT"].add("sdt_tach_hai_so")
    for v, c in email_list[1:]:
        tags["email_khac"].add("email_nhap_nham_cot" if c != "Email" else "email_chuan_hoa")
    if phone_list and phone_list[0][1] != "SĐT":
        tags["SĐT"].add("sdt_nhap_nham_cot")
    if email_list and email_list[0][1] != "Email":
        tags["Email"].add("email_nhap_nham_cot")
    if raw["SĐT"].strip() and not tags["SĐT"]:
        tags["SĐT"].add("sdt_chuan_hoa")
    if raw["Email"].strip() and not tags["Email"]:
        tags["Email"].add("email_chuan_hoa")
    phone_list = [v for v, _ in phone_list]
    email_list = [v for v, _ in email_list]

    # --- 3. họ tên ------------------------------------------------------------------
    name = nfc(name_raw)
    title, name = split_title(squash(name))
    ho_ten = cap_words(name)
    if title:
        tags["Họ tên"].add("bo_danh_xung")
        new_note = "; ".join(x for x in (new_note, f"Danh xưng: {title}") if x)
        tags["Ghi chú"].add("ghi_danh_xung")
    tags["Họ tên"].add("ten_chuan_hoa")

    # --- 4. địa chỉ -----------------------------------------------------------------
    dia_chi, day_du = ("", False)
    if addr_raw.strip():
        dia_chi, day_du = clean_address(addr_raw)
        tags["Địa chỉ"].add("dia_chi_chuan_hoa")

    out = {
        "Họ tên": ho_ten, "SĐT": sdt, "sdt_khac": sdt_khac, "Email": email,
        "email_khac": email_khac, "Địa chỉ": dia_chi, "Ghi chú": new_note,
    }
    # --- 5. log mức ô ---------------------------------------------------------------
    log = []
    for col in ("Họ tên", "SĐT", "sdt_khac", "Email", "email_khac", "Địa chỉ", "Ghi chú"):
        cu = raw.get(col, "")
        moi = out[col]
        if cu == moi:
            continue
        t = set(tags[col])
        if col == "Họ tên" and ("doi_cho_ten_dia_chi" in t or "bo_danh_xung" in t):
            t.discard("ten_chuan_hoa")
        log.append((col, cu, moi, "+".join(sorted(t)) or "chuan_hoa"))
    # SĐT/email không hợp lệ bị bỏ khỏi cột sạch: ghi rõ giá trị cũ
    return {
        "ma": raw["Mã dòng"], "nguon": raw["Nguồn"], "ten": ho_ten, "title": title,
        "ten_tokens": name_tokens(ho_ten), "phones": phone_list, "emails": email_list,
        "sdt": sdt, "sdt_khac": sdt_khac, "email": email, "email_khac": email_khac,
        "dia_chi": dia_chi, "dia_chi_day_du": day_du, "ghi_chu": new_note,
        "bad_phone": bad_phone, "bad_email": bad_email, "log": log,
    }


# ----------------------------------------------------------------------------
# Bước 2-3: so khớp & gộp
# ----------------------------------------------------------------------------
def find_clusters(rows):
    n = len(rows)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    g_edges = []   # (i, j, [bằng chứng], có_sdt)
    q1_pairs = []  # (i, j, sdt_chung)
    for i, j in combinations(range(n), 2):
        a, b = rows[i], rows[j]
        sp = [p for p in a["phones"] if p in b["phones"]]
        se = [e for e in a["emails"] if e in b["emails"]]
        compat = name_compat(a["ten_tokens"], b["ten_tokens"])
        if sp and compat:
            g_edges.append((i, j, sp, se, True))
        elif se and compat:
            g_edges.append((i, j, sp, se, False))
        if sp and not compat:
            q1_pairs.append((i, j, sp))
    for i, j, *_ in g_edges:
        parent[find(i)] = find(j)
    return find, g_edges, q1_pairs


def main():
    # ---- đọc ----
    ws = openpyxl.load_workbook(FILE_GOC, read_only=True, data_only=True)[SHEET_GOC]
    data = list(ws.iter_rows(values_only=True))
    assert list(data[0]) == COLS_GOC, f"Tiêu đề lạ: {data[0]}"
    raw_rows = [{c: cell_text(v) for c, v in zip(COLS_GOC, r)} for r in data[1:]
                if any(v not in (None, "") for v in r)]
    rows = [clean_row(r) for r in raw_rows]
    n = len(rows)
    idx = {r["ma"]: i for i, r in enumerate(rows)}
    assert len(idx) == n, "Mã dòng gốc bị trùng"

    # ---- so khớp ----
    find, g_edges, q1_pairs = find_clusters(rows)
    clusters = defaultdict(list)
    for i in range(n):
        clusters[find(i)].append(i)
    cluster_list = sorted(clusters.values(), key=lambda c: min(c))  # theo dòng đầu tiên
    ma_khach = {}
    for k, members in enumerate(cluster_list, 1):
        for i in members:
            ma_khach[i] = f"KH{k:03d}"

    adj = defaultdict(list)
    for i, j, sp, se, by_phone in g_edges:
        adj[i].append((j, sp, se, by_phone))
        adj[j].append((i, sp, se, by_phone))

    def ev_text(sp, se):
        bits = []
        if sp:
            bits.append("trùng SĐT " + ", ".join(sp))
        if se:
            bits.append("trùng email " + ", ".join(se))
        return " và ".join(bits)

    # ---- nhật ký gộp ----
    log_gop = {}
    conflicts = []
    for members in cluster_list:
        members = sorted(members)
        host = members[0]
        mk = ma_khach[host]
        if len(members) == 1:
            log_gop[host] = (mk, "GIU_RIENG", "không",
                             "Không có dòng nào khác trùng SĐT/email kèm tên tương thích (G1/G2).")
            continue
        others = [rows[m]["ma"] for m in members[1:]]
        log_gop[host] = (mk, "GIU_RIENG", "không",
                         f"Dòng đại diện của khách {mk}; nhận thêm các dòng: {', '.join(others)}.")
        # BFS từ host
        prev = {host: None}
        dq = deque([host])
        while dq:
            u = dq.popleft()
            for v, sp, se, by_phone in sorted(adj[u], key=lambda x: x[0]):
                if v not in prev:
                    prev[v] = (u, sp, se, by_phone)
                    dq.append(v)
        for m in members[1:]:
            chain = []
            x = m
            while prev[x] is not None:
                u, sp, se, by_phone = prev[x]
                chain.append((u, x, sp, se, by_phone))
                x = u
            chain.reverse()
            if len(chain) == 1:
                u, x, sp, se, by_phone = chain[0]
                rule = "G1" if by_phone else "G2"
                bc = (f"{ev_text(sp, se).capitalize()} và tên tương thích "
                      f"('{rows[x]['ten']}' ~ '{rows[u]['ten']}') với dòng {rows[u]['ma']}.")
            else:
                rule = "bắc cầu"
                steps = "; ".join(f"{rows[u]['ma']}~{rows[x]['ma']} {ev_text(sp, se)}"
                                  for u, x, sp, se, _ in chain)
                bc = (f"Nối với dòng đại diện {rows[host]['ma']} qua chuỗi: {steps}; "
                      f"tên đều tương thích.")
            log_gop[m] = (mk, "GOP_VAO", rule, bc)
        # kiểm xung đột tên trong nhóm (không áp quy tắc mới, chỉ báo)
        for a, b in combinations(members, 2):
            if not name_compat(rows[a]["ten_tokens"], rows[b]["ten_tokens"]):
                conflicts.append((ma_khach[a], rows[a]["ma"], rows[b]["ma"],
                                  rows[a]["ten"], rows[b]["ten"]))

    # ---- nghi trùng Q1 / Q2 ----
    q_edges = []  # (i, j, 'Q1'|'Q2', lý do)
    for i, j, sp in q1_pairs:
        if find(i) == find(j):
            continue
        a, b = rows[i], rows[j]
        q_edges.append((i, j, "Q1",
                        f"{a['ma']} ('{a['ten']}', {ma_khach[i]}) và {b['ma']} ('{b['ten']}', "
                        f"{ma_khach[j]}) trùng SĐT {', '.join(sp)} nhưng tên không tương thích."))
    for i, j in combinations(range(n), 2):
        a, b = rows[i], rows[j]
        if find(i) == find(j) or not a["dia_chi"] or not b["dia_chi"]:
            continue
        if not (name_same(a["ten_tokens"], b["ten_tokens"])
                and addr_key(a["dia_chi"]) == addr_key(b["dia_chi"])):
            continue
        if a["phones"] and b["phones"]:
            lien_he = f"SĐT khác nhau ({', '.join(a['phones'])} so với {', '.join(b['phones'])})"
        elif a["emails"] and b["emails"] and not (set(a["emails"]) & set(b["emails"])):
            lien_he = "email khác nhau"
        else:
            lien_he = "một bên thiếu SĐT/email"
        if (set(a["phones"]) & set(b["phones"])) or (set(a["emails"]) & set(b["emails"])):
            continue  # đã thuộc G1/G2 (không xảy ra ở đây vì tên giống => tương thích)
        q_edges.append((i, j, "Q2",
                        f"{a['ma']} ({ma_khach[i]}) và {b['ma']} ({ma_khach[j]}) cùng tên "
                        f"'{a['ten']}' và cùng địa chỉ '{a['dia_chi']}', nhưng {lien_he}."))

    # nhóm các cặp nghi trùng bằng union-find trên dòng
    qp = {}

    def qfind(x):
        qp.setdefault(x, x)
        while qp[x] != x:
            qp[x] = qp[qp[x]]
            x = qp[x]
        return x

    for i, j, *_ in q_edges:
        qp[qfind(i)] = qfind(j)
    qgroups = defaultdict(list)
    for i, j, rule, why in q_edges:
        qgroups[qfind(i)].append((i, j, rule, why))
    qlist = sorted(qgroups.values(), key=lambda g: min(min(e[0], e[1]) for e in g))

    def goi_y(group):
        rules = {e[2] for e in group}
        members = sorted({x for e in group for x in e[:2]})
        names = [rows[m]["ten_tokens"] for m in members]
        if rules == {"Q2"}:
            if any("một bên thiếu" in e[3] for e in group):
                return ("Nghiêng về gộp (khá chắc): tên và địa chỉ giống hệt, một bên chưa có "
                        "SĐT/email nên không có gì mâu thuẫn.")
            return ("Nghiêng về gộp nhưng nên xác nhận: tên và địa chỉ giống hệt, hai SĐT khác nhau "
                    "(khách có thể đổi số hoặc có hai số).")
        # Q1
        single = any(len(t) == 1 for t in names)
        last_same = len({fold(t[-1]) for t in names}) == 1
        if single and last_same:
            return ("Nghiêng về gộp: cùng SĐT, tên một từ trùng chữ cuối (tên gọi) của tên đầy đủ.")
        if len({tuple(fold(w) for w in t) for t in names}) > 1 and all(
                len(t) == len(names[0]) for t in names) and sum(
                1 for a, b in zip(names[0], names[1]) if not tok_eq(a, b)) == 1:
            return ("Nghiêng về không gộp, nên hỏi lại khách: cùng SĐT, tên chỉ lệch một chữ "
                    "(có thể gõ nhầm dấu nhưng cũng có thể là hai người).")
        return ("Nghiêng về không gộp: cùng SĐT nhưng tên khác hẳn "
                "(có thể người thân dùng chung số).")

    # ---- gom thông tin mỗi khách ----
    def best_name(members):
        def score(i):
            toks = rows[i]["ten"].split(" ")
            return (not any(is_initial(t) for t in toks), sum(ord(c) > 127 for c in rows[i]["ten"]),
                    -i)
        return max(members, key=score)

    def best_addr(members):
        cand = [i for i in members if rows[i]["dia_chi"]]
        if not cand:
            return None
        return max(cand, key=lambda i: (rows[i]["dia_chi_day_du"],
                                        sum(ord(c) > 127 for c in rows[i]["dia_chi"]), -i))

    def uniq(seq):
        out = []
        for v in seq:
            if v and v not in out:
                out.append(v)
        return out

    khach = []
    for members in cluster_list:
        members = sorted(members)
        bn = best_name(members)
        ba = best_addr(members)
        phones = uniq(p for i in members for p in rows[i]["phones"])
        emails = uniq(e for i in members for e in rows[i]["emails"])
        notes = [rows[i]["ghi_chu"] for i in members]
        alt_names = uniq(rows[i]["ten"] for i in members if rows[i]["ten"] != rows[bn]["ten"])
        alt_addr = uniq(rows[i]["dia_chi"] for i in members
                        if rows[i]["dia_chi"] and (ba is None or rows[i]["dia_chi"] != rows[ba]["dia_chi"]))
        ghi_chu = []
        for t in notes:
            for part in t.split("; "):
                if part and part not in ghi_chu:
                    ghi_chu.append(part)
        if alt_names:
            ghi_chu.append("Tên khác: " + " | ".join(alt_names))
        if alt_addr:
            ghi_chu.append("Địa chỉ khác: " + " | ".join(alt_addr))
        khach.append({
            "ma_khach": ma_khach[members[0]],
            "ho_ten": rows[bn]["ten"],
            "sdt": phones[0] if phones else "",
            "sdt_khac": ";".join(phones[1:]),
            "email": emails[0] if emails else "",
            "email_khac": ";".join(emails[1:]),
            "dia_chi": rows[ba]["dia_chi"] if ba is not None else "",
            "nguon": ";".join(uniq(rows[i]["nguon"] for i in members)),
            "ma_dong_goc": ";".join(rows[i]["ma"] for i in members),
            "ghi_chu": "; ".join(ghi_chu),
        })

    # ---- ghi file ----
    cols_sach = ["ma_khach", "ho_ten", "sdt", "sdt_khac", "email", "email_khac",
                 "dia_chi", "nguon", "ma_dong_goc", "ghi_chu"]
    wb = openpyxl.Workbook()
    wsx = wb.active
    wsx.title = "KhachHang"
    wsx.append(cols_sach)
    for c in wsx[1]:
        c.font = Font(bold=True)
    for k in khach:
        wsx.append([k[c] for c in cols_sach])
    for row in wsx.iter_rows(min_row=2):
        for c in row:
            c.number_format = "@"
    wsx.freeze_panes = "A2"
    for ci, c in enumerate(cols_sach, 1):
        w = max(len(c), *(len(str(k[c])) for k in khach))
        wsx.column_dimensions[get_column_letter(ci)].width = min(max(w + 2, 10), 60)
    wb.save(HERE / "danh-ba-sach.xlsx")

    def write_csv(name, header, rows_):
        with open(HERE / name, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(header)
            w.writerows(rows_)

    write_csv("nhat-ky-gop.csv",
              ["ma_dong_goc", "ma_khach", "hanh_dong", "quy_tac", "bang_chung"],
              [(rows[i]["ma"], *log_gop[i]) for i in range(n)])

    sua = []
    for r in rows:
        for col, cu, moi, rule in r["log"]:
            sua.append((r["ma"], col, cu, moi, rule))
    write_csv("nhat-ky-sua.csv", ["ma_dong_goc", "cot", "gia_tri_cu", "gia_tri_moi", "quy_tac"], sua)

    nghi = []
    for k, g in enumerate(qlist, 1):
        members = sorted({x for e in g for x in e[:2]})
        rules = ";".join(sorted({e[2] for e in g}))
        nghi.append((k, ";".join(rows[m]["ma"] for m in members), rules,
                     " | ".join(e[3] for e in g), goi_y(g)))
    write_csv("nghi-trung-can-quyet.csv", ["nhom", "ma_dong_goc", "quy_tac", "ly_do", "goi_y"], nghi)

    # ---- tự kiểm ----
    errs = []
    ids = [r[0] for r in csv.reader(open(HERE / "nhat-ky-gop.csv", encoding="utf-8-sig"))][1:]
    if sorted(ids) != sorted(r["ma"] for r in rows) or len(set(ids)) != len(ids):
        errs.append("nhat-ky-gop.csv: mỗi Mã dòng gốc phải xuất hiện đúng 1 lần")
    n_giu = sum(1 for v in log_gop.values() if v[1] == "GIU_RIENG")
    n_gop = sum(1 for v in log_gop.values() if v[1] == "GOP_VAO")
    if n_giu != len(khach) or n_giu + n_gop != n:
        errs.append(f"số dòng sạch {len(khach)} + bị gộp {n_gop} != gốc {n}")
    all_ma = [m for k in khach for m in k["ma_dong_goc"].split(";")]
    if sorted(all_ma) != sorted(ids):
        errs.append("ma_dong_goc trong danh-ba-sach.xlsx không phủ đủ các dòng gốc")
    for k in khach:
        for p in [k["sdt"]] + [x for x in k["sdt_khac"].split(";") if x]:
            if p and not phone_valid(p):
                errs.append(f"{k['ma_khach']}: SĐT sai định dạng {p}")
        for e in [k["email"]] + [x for x in k["email_khac"].split(";") if x]:
            if e and not email_valid(e):
                errs.append(f"{k['ma_khach']}: email sai cú pháp {e}")
    wsr = openpyxl.load_workbook(HERE / "danh-ba-sach.xlsx")["KhachHang"]
    if wsr.max_row - 1 != len(khach):
        errs.append("danh-ba-sach.xlsx: số dòng không khớp")

    # ---- thống kê ----
    from collections import Counter
    stat = {
        "dong_goc": n, "khach_sach": len(khach), "dong_bi_gop": n_gop,
        "nhom_gop(>=2 dong)": sum(1 for m in cluster_list if len(m) > 1),
        "quy_tac_gop": dict(Counter(v[2] for v in log_gop.values() if v[1] == "GOP_VAO")),
        "nhom_can_nguoi_quyet": len(nghi),
        "Q": dict(Counter(x[2] for x in nghi)),
        "sdt_khong_hop_le": sum(len(r["bad_phone"]) for r in rows),
        "email_khong_hop_le": sum(len(r["bad_email"]) for r in rows),
        "dong_sdt_hop_le>=1": sum(1 for r in rows if r["phones"]),
        "dong_email_hop_le>=1": sum(1 for r in rows if r["emails"]),
        "khach_co_sdt": sum(1 for k in khach if k["sdt"]),
        "khach_co_email": sum(1 for k in khach if k["email"]),
        "dong_co_sdt_khac": sum(1 for r in rows if r["sdt_khac"]),
        "dong_co_danh_xung": sum(1 for r in rows if r["title"]),
        "dong_doi_cho_ten_dia_chi": sum(1 for r in rows if any(x[3] and "doi_cho" in x[3] for x in r["log"])),
        "dia_chi_khong_day_du": sum(1 for r in rows if r["dia_chi"] and not r["dia_chi_day_du"]),
        "so_o_da_sua": len(sua),
        "xung_dot_ten_trong_nhom": len(conflicts),
    }
    print("== THỐNG KÊ ==")
    for k, v in stat.items():
        print(f"{k}: {v}")
    for c in conflicts:
        print("XUNG ĐỘT TÊN:", c)
    if errs:
        print("== LỖI TỰ KIỂM ==")
        for e in errs:
            print(" -", e)
        sys.exit(1)
    print("== Tự kiểm: ĐẠT ==")


if __name__ == "__main__":
    main()
