#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script gộp và xử lý dữ liệu doanh thu bán hàng các chi nhánh cho công ty Mẫu An Phát.
Sử dụng: python gop.py goc ra --thang 2026-11
"""

import os
import sys
import argparse
import csv
import re
from datetime import datetime, date
import openpyxl

def parse_number(val):
    """Chuyển đổi chuỗi/số tiền hoặc số lượng thành số nguyên, xử lý dấu chấm, phẩy, chữ đ, số âm."""
    if val is None:
        return 0
    if isinstance(val, (int, float)):
        return int(round(val))
    s = str(val).strip()
    s = s.replace("đ", "").replace("Đ", "").replace("VND", "").replace("vnd", "").strip()
    s = s.replace(".", "").replace(",", "").replace(" ", "")
    try:
        return int(s)
    except Exception:
        return 0

def normalize_product(raw_name):
    """Ánh xạ tên sản phẩm từ các kiểu viết khác nhau về mã chuẩn SP01-SP08 hoặc CHUA_XAC_DINH."""
    if not raw_name or not isinstance(raw_name, str):
        return "CHUA_XAC_DINH"
    s_low = raw_name.strip().lower()
    
    # SP01: Gạo ST25 túi 5kg
    if "st25" in s_low or "gạo st25" in s_low or "gao st25" in s_low:
        return "SP01"
    # SP02: Nước mắm truyền thống chai 500ml
    if "mắm" in s_low or "mam" in s_low or "n.mắm" in s_low:
        return "SP02"
    # SP03: Cà phê rang xay 500g
    if "cà phê" in s_low or "ca phe" in s_low or "cafe" in s_low or "cf " in s_low or s_low.startswith("cf"):
        return "SP03"
    # SP04: Trà sen 200g
    if "trà sen" in s_low or "tra sen" in s_low:
        return "SP04"
    # SP05: Mật ong rừng 250ml
    if "mật ong" in s_low or "mat ong" in s_low:
        return "SP05"
    # SP06: Hạt điều rang muối 500g
    if "hạt điều" in s_low or "hat dieu" in s_low or "điều rang" in s_low:
        return "SP06"
    # SP07: Bánh tráng muối tôm 250g
    if "bánh tráng" in s_low or "banh trang" in s_low or "b.tráng" in s_low:
        return "SP07"
    # SP08: Dầu dừa ép lạnh 250ml
    if "dầu dừa" in s_low or "dau dua" in s_low:
        return "SP08"
        
    return "CHUA_XAC_DINH"

def identify_branch(fname, sheet, dm_cn):
    """Xác định mã chi nhánh từ tên file hoặc nội dung vài dòng đầu."""
    fname_upper = fname.upper()
    for code, name in dm_cn.items():
        if code in fname_upper or name.upper() in fname_upper:
            return code
    # Check BienHoa
    if "BIENHOA" in fname_upper or "BIÊN HÒA" in fname_upper:
        return "BH"
    if "NHATRANG" in fname_upper or "NHA TRANG" in fname_upper:
        return "NT"
    # Check top rows of sheet
    for r in range(1, min(6, sheet.max_row + 1)):
        for c in range(1, min(6, sheet.max_column + 1)):
            v = sheet.cell(r, c).value
            if v and isinstance(v, str):
                v_up = v.upper()
                for code, name in dm_cn.items():
                    if code in v_up or name.upper() in v_up:
                        return code
                if "BIÊN HÒA" in v_up or "BIEN HOA" in v_up:
                    return "BH"
                if "NHA TRANG" in v_up:
                    return "NT"
    raise ValueError(f"Không nhận diện được chi nhánh cho file: {fname}")

def find_header_and_cols(sheet, fname):
    """Tìm dòng tiêu đề và xác định vị trí các cột dữ liệu cần thiết."""
    for r in range(1, min(15, sheet.max_row + 1)):
        row_vals = [sheet.cell(r, c).value for c in range(1, sheet.max_column + 1)]
        row_texts = [str(v).strip().lower() if v is not None else "" for v in row_vals]
        
        # Check if row looks like a header
        c_ngay = None
        c_ct = None
        c_sp = None
        c_sl = None
        c_gia = None
        c_tien = None
        
        for idx, t in enumerate(row_texts, 1):
            if not t:
                continue
            if any(k in t for k in ["ngày", "date", "ngày bán", "ngày gd", "ngay"]):
                c_ngay = idx
            elif any(k in t for k in ["số hđ", "số phiếu", "invoice", "mã đơn", "chứng từ", "mã chứng từ", "so hd", "so phieu", "ma don", "ma chung tu"]):
                c_ct = idx
            elif any(k in t for k in ["tên hàng", "product", "tên sp", "sản phẩm", "mặt hàng", "hàng hóa", "ten hang", "ten sp", "san pham", "mat hang", "hang hoa"]):
                c_sp = idx
            elif any(k in t for k in ["sl", "qty", "số lượng", "so luong"]):
                c_sl = idx
            elif any(k in t for k in ["đơn giá", "unit price", "giá bán", "giá", "giá niêm yết", "don gia", "gia niem yet"]):
                c_gia = idx
            elif any(k in t for k in ["thành tiền", "amount", "doanh thu", "tiền", "doanh số", "doanh so"]):
                c_tien = idx
                
        # If all 6 columns found
        if c_ngay and c_ct and c_sp and c_sl and c_gia and c_tien:
            return r, {"ngay": c_ngay, "ct": c_ct, "sp": c_sp, "sl": c_sl, "gia": c_gia, "tien": c_tien}
            
    raise ValueError(f"Không nhận diện được hàng tiêu đề hợp lệ trong file: {fname}")

def main():
    parser = argparse.ArgumentParser(description="Gộp và tổng hợp doanh thu bán hàng các chi nhánh")
    parser.add_argument("thu_muc_goc", help="Thư mục chứa các file Excel gốc (chỉ đọc)")
    parser.add_argument("thu_muc_ra", help="Thư mục lưu kết quả xuất ra")
    parser.add_argument("--thang", required=True, help="Kỳ báo cáo dạng YYYY-MM (ví dụ 2026-10 hoặc 2026-11)")
    args = parser.parse_args()

    goc_dir = args.thu_muc_goc
    ra_dir = args.thu_muc_ra
    ky_thang = args.thang.strip()

    # Parse ky_thang
    try:
        ky_parts = ky_thang.split("-")
        target_year = int(ky_parts[0])
        target_month = int(ky_parts[1])
    except Exception:
        raise ValueError(f"Tham số --thang không đúng định dạng YYYY-MM: {ky_thang}")

    prev_month = 12 if target_month == 1 else target_month - 1
    prev_year = target_year - 1 if target_month == 1 else target_year

    # Đọc danh mục chi nhánh và sản phẩm
    dm_sp = {}
    with open("danh_muc_san_pham.csv", mode="r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for r in reader:
            dm_sp[r["ma_san_pham"].strip()] = r["ten_san_pham"].strip()

    dm_cn = {}
    with open("danh_muc_chi_nhanh.csv", mode="r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for r in reader:
            dm_cn[r["ma"].strip()] = r["ten"].strip()

    if not os.path.exists(goc_dir):
        raise FileNotFoundError(f"Thư mục gốc không tồn tại: {goc_dir}")

    os.makedirs(ra_dir, exist_ok=True)

    excel_files = sorted([f for f in os.listdir(goc_dir) if f.endswith(".xlsx") and not f.startswith("~$")])
    if not excel_files:
        raise ValueError(f"Không tìm thấy file Excel nào trong thư mục: {goc_dir}")

    all_parsed_rows = []       # Dòng chi tiết lưu vào hop_nhat.csv
    viec_can_hoi = []          # Dòng việc cần hỏi
    branch_stats = {}          # Thống kê từng chi nhánh cho kiem_tra.csv

    for fname in excel_files:
        fpath = os.path.join(goc_dir, fname)
        wb = openpyxl.load_workbook(fpath, data_only=True)
        sheet = wb.active

        cn_code = identify_branch(fname, sheet, dm_cn)
        header_row, cols = find_header_and_cols(sheet, fname)

        # Xử lý merged cells của cột ngày (như ở HN)
        merged_date_map = {}
        for rng in sheet.merged_cells.ranges:
            if rng.min_col <= cols["ngay"] <= rng.max_col:
                top_left_val = sheet.cell(rng.min_row, rng.min_col).value
                for r_idx in range(rng.min_row, rng.max_row + 1):
                    merged_date_map[r_idx] = top_left_val

        last_valid_date = None
        total_file_ghi = 0
        total_dong_doc_duoc = 0
        raw_rows_in_file = []
        subtotal_count = 0

        for r in range(header_row + 1, sheet.max_row + 1):
            val_ngay = sheet.cell(r, cols["ngay"]).value
            val_ct = sheet.cell(r, cols["ct"]).value
            val_sp = sheet.cell(r, cols["sp"]).value
            val_sl = sheet.cell(r, cols["sl"]).value
            val_gia = sheet.cell(r, cols["gia"]).value
            val_tien = sheet.cell(r, cols["tien"]).value

            all_vals = [val_ngay, val_ct, val_sp, val_sl, val_gia, val_tien]
            if all(v is None for v in all_vals):
                continue

            row_str = " ".join(str(v) for v in all_vals if v is not None).lower()

            # Nhận diện dòng tổng cộng / subtotal
            if any(k in row_str for k in ["tổng cộng", "tổng tháng", "tổng:", "total", "cộng"]):
                if "cộng tuần" in row_str:
                    # Dòng subtotal tuần, bỏ qua
                    subtotal_count += 1
                    continue
                else:
                    # Dòng tổng cộng cuối bảng
                    # Tìm số tiền ở cột tien, gia hoặc sl
                    for v in [val_tien, val_gia, val_sl]:
                        num = parse_number(v)
                        if num > 0:
                            total_file_ghi = num
                            break
                    continue

            # Nhận diện dòng ghi chú / footer
            if any(k in row_str for k in ["ghi chú", "lưu ý", "prepared by", "người lập", "* gồm"]):
                continue

            # Nếu không có số chứng từ và không có tên sản phẩm -> bỏ qua
            if val_ct is None and val_sp is None:
                continue

            # Lấy ngày
            actual_date_raw = val_ngay
            if actual_date_raw is None and r in merged_date_map:
                actual_date_raw = merged_date_map[r]
            if actual_date_raw is None and cn_code == "HN" and last_valid_date is not None:
                actual_date_raw = last_valid_date
            if actual_date_raw is not None:
                last_valid_date = actual_date_raw

            so_ct_str = str(val_ct).strip() if val_ct is not None else ""
            sp_str = str(val_sp).strip() if val_sp is not None else ""
            sl_num = parse_number(val_sl)
            gia_num = parse_number(val_gia)
            tien_num = parse_number(val_tien)

            total_dong_doc_duoc += tien_num

            raw_rows_in_file.append({
                "row_idx": r,
                "ngay_raw": actual_date_raw,
                "so_ct": so_ct_str,
                "sp_raw": sp_str,
                "sl": sl_num,
                "gia": gia_num,
                "tien": tien_num,
            })

        wb.close()

        # Kiểm tra tính toán SL * Đơn giá != Thành tiền
        calc_diffs_for_branch = []
        for rec in raw_rows_in_file:
            calc_val = rec["sl"] * rec["gia"]
            if calc_val != rec["tien"]:
                calc_diffs_for_branch.append(rec)
                viec_can_hoi.append({
                    "chi_nhanh": cn_code,
                    "loai": "LECH_THANH_TIEN",
                    "mo_ta": f"Dòng {rec['row_idx']} đơn {rec['so_ct']} mặt hàng '{rec['sp_raw']}': Thành tiền ghi {rec['tien']}đ lệch so với SL x Đơn giá ({rec['sl']} x {rec['gia']} = {calc_val}đ, lệch {rec['tien'] - calc_val:+d}đ).",
                    "so_chung_tu": rec["so_ct"],
                    "dong_nguon": str(rec["row_idx"]),
                    "so_tien_lien_quan": str(rec["tien"]),
                    "cau_hoi_gui_chi_nhanh": f"Số tiền đúng của chứng từ {rec['so_ct']} là {rec['tien']:,}đ hay theo công thức {calc_val:,}đ?",
                })

        # Kiểm tra trùng lặp trong file
        seen_records = {}
        duplicate_row_indices = set()
        dup_list_for_branch = []
        for rec in raw_rows_in_file:
            key = (rec["so_ct"], rec["sp_raw"], rec["sl"], rec["gia"], rec["tien"])
            if key in seen_records:
                first_r = seen_records[key]
                duplicate_row_indices.add(rec["row_idx"])
                dup_list_for_branch.append(rec)
                viec_can_hoi.append({
                    "chi_nhanh": cn_code,
                    "loai": "TRUNG",
                    "mo_ta": f"Dòng {rec['row_idx']} trùng lặp hoàn toàn với dòng {first_r} (cùng số CT {rec['so_ct']}, mặt hàng '{rec['sp_raw']}', SL {rec['sl']}, Thành tiền {rec['tien']}đ).",
                    "so_chung_tu": rec["so_ct"],
                    "dong_nguon": str(rec["row_idx"]),
                    "so_tien_lien_quan": str(rec["tien"]),
                    "cau_hoi_gui_chi_nhanh": f"Chứng từ {rec['so_ct']} tại dòng {rec['row_idx']} có phải nhập trùng với dòng {first_r} không? Có cần hủy dòng trùng này không?",
                })
            else:
                seen_records[key] = rec["row_idx"]

        # Phân tích ngày tháng, xác định dòng ngoài kỳ, mơ hồ, suy ra, ok
        valid_dates_set = set()
        oop_list_for_branch = []
        amb_list_for_branch = []
        inv_list_for_branch = []

        for rec in raw_rows_in_file:
            r = rec["row_idx"]
            if r in duplicate_row_indices:
                # Dòng trùng loại bỏ khỏi hop_nhat.csv
                continue

            d_raw = rec["ngay_raw"]
            so_ct = rec["so_ct"]
            sp_raw = rec["sp_raw"]
            sl = rec["sl"]
            gia = rec["gia"]
            tien = rec["tien"]

            ma_sp = normalize_product(sp_raw)
            if ma_sp == "CHUA_XAC_DINH":
                viec_can_hoi.append({
                    "chi_nhanh": cn_code,
                    "loai": "SAN_PHAM_LA",
                    "mo_ta": f"Dòng {r} chứng từ {so_ct} bán sản phẩm lạ '{sp_raw}' không có trong danh mục chuẩn của công ty.",
                    "so_chung_tu": so_ct,
                    "dong_nguon": str(r),
                    "so_tien_lien_quan": str(tien),
                    "cau_hoi_gui_chi_nhanh": f"Mặt hàng '{sp_raw}' thuộc mã sản phẩm nào trong danh mục hoặc bao gồm các sản phẩm thành phần nào?",
                })

            # Xử lý ngày tháng
            parsed_date_str = ""
            trang_thai = "OK"
            ghi_chu = ""

            # TH1: d_raw là datetime / date
            if isinstance(d_raw, (datetime, date)):
                # Kiểm tra lỗi Excel đảo mm/dd (như ở Biên Hòa)
                if d_raw.year == target_year and d_raw.month != target_month and d_raw.day == target_month:
                    inferred_day = d_raw.month
                    parsed_date_str = f"{target_year:04d}-{target_month:02d}-{inferred_day:02d}"
                    trang_thai = "SUY_RA"
                    ghi_chu = f"Ô ngày gốc {d_raw.strftime('%Y-%m-%d')} bị Excel đảo mm/dd khi nhập {inferred_day:02d}/{target_month:02d}; suy ra {parsed_date_str} dựa vào thứ tự số phiếu và vị trí trong tuần."
                    inv_list_for_branch.append(rec)
                elif d_raw.year == target_year and d_raw.month == target_month:
                    parsed_date_str = d_raw.strftime("%Y-%m-%d")
                    trang_thai = "OK"
                else:
                    # Dòng ngoài kỳ
                    oop_list_for_branch.append(rec)
                    viec_can_hoi.append({
                        "chi_nhanh": cn_code,
                        "loai": "NGOAI_KY",
                        "mo_ta": f"Dòng {r} chứng từ {so_ct} ngày {d_raw.strftime('%Y-%m-%d')} không thuộc kỳ báo cáo {ky_thang}.",
                        "so_chung_tu": so_ct,
                        "dong_nguon": str(r),
                        "so_tien_lien_quan": str(tien),
                        "cau_hoi_gui_chi_nhanh": f"Chứng từ {so_ct} phát sinh ngoài kỳ tháng {target_month:02d}/{target_year}, đề nghị chi nhánh làm rõ có chuyển sang kỳ phù hợp không?",
                    })
                    continue

            # TH2: d_raw là chuỗi (string)
            elif isinstance(d_raw, str):
                d_str = d_raw.strip()
                m_iso = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", d_str)
                m_slash = re.match(r"^(\d{1,2})/(\d{1,2})/(\d{4})$", d_str)
                m_dash = re.match(r"^(\d{1,2})-(\d{1,2})-(\d{2,4})$", d_str)

                if m_iso:
                    # Dạng ISO YYYY-MM-DD (phần mềm mới của Nha Trang)
                    py, pm, pd = int(m_iso.group(1)), int(m_iso.group(2)), int(m_iso.group(3))
                    if py == target_year and pm == target_month:
                        parsed_date_str = f"{py:04d}-{pm:02d}-{pd:02d}"
                        trang_thai = "OK"
                    else:
                        oop_list_for_branch.append(rec)
                        viec_can_hoi.append({
                            "chi_nhanh": cn_code,
                            "loai": "NGOAI_KY",
                            "mo_ta": f"Dòng {r} chứng từ {so_ct} ngày {d_str} ngoài kỳ báo cáo.",
                            "so_chung_tu": so_ct,
                            "dong_nguon": str(r),
                            "so_tien_lien_quan": str(tien),
                            "cau_hoi_gui_chi_nhanh": f"Chứng từ phát sinh ngoài kỳ tháng {target_month:02d}/{target_year}, đề nghị xác nhận kỳ hạch toán?",
                        })
                        continue

                elif m_slash:
                    p1, p2, py = int(m_slash.group(1)), int(m_slash.group(2)), int(m_slash.group(3))
                    if cn_code == "DN":
                        # Đà Nẵng dùng MM/DD/YYYY (tháng ở vị trí đầu)
                        if p1 == target_month and py == target_year:
                            parsed_date_str = f"{py:04d}-{p1:02d}-{p2:02d}"
                            if p2 <= 12:
                                trang_thai = "SUY_RA"
                                if target_month == 10:
                                    ghi_chu = "Suy ra ngày theo định dạng MM/DD/YYYY căn cứ chuỗi ngày liên tục đến 31/10, số chứng từ tăng dần và tiêu đề báo cáo tháng 10/2026."
                                else:
                                    last_day_m = 30 if target_month in [4, 6, 9, 11] else 31
                                    ghi_chu = f"Suy ra ngày theo định dạng MM/DD/YYYY căn cứ chuỗi ngày liên tục đến {last_day_m:02d}/{target_month:02d}, số chứng từ tăng dần và tiêu đề báo cáo tháng {target_month:02d}/{target_year}."
                            else:
                                trang_thai = "OK"
                        else:
                            # Ngoài kỳ
                            oop_list_for_branch.append(rec)
                            viec_can_hoi.append({
                                "chi_nhanh": cn_code,
                                "loai": "NGOAI_KY",
                                "mo_ta": f"Dòng {r} chứng từ {so_ct} ngày {d_str} ngoài kỳ báo cáo.",
                                "so_chung_tu": so_ct,
                                "dong_nguon": str(r),
                                "so_tien_lien_quan": str(tien),
                                "cau_hoi_gui_chi_nhanh": "Chứng từ phát sinh ngoài kỳ, đề nghị xác nhận kỳ hạch toán?",
                            })
                            continue
                    elif cn_code == "HP":
                        # Hải Phòng dùng DD/MM/YYYY, có đơn tháng trước nhập trễ và đơn ngày mơ hồ
                        if p2 == target_month and py == target_year:
                            # Thuộc kỳ hiện tại
                            parsed_date_str = f"{py:04d}-{p2:02d}-{p1:02d}"
                            trang_thai = "OK"
                        elif p2 == prev_month and py == prev_year:
                            if p1 > 12:
                                # Chắc chắn là ngày ngoài kỳ tháng trước nhập trễ
                                oop_list_for_branch.append(rec)
                                viec_can_hoi.append({
                                    "chi_nhanh": cn_code,
                                    "loai": "NGOAI_KY",
                                    "mo_ta": f"Dòng {r} chứng từ {so_ct} ngày {d_str} thuộc tháng {prev_month:02d}/{prev_year} nhập trễ ngoài kỳ.",
                                    "so_chung_tu": so_ct,
                                    "dong_nguon": str(r),
                                    "so_tien_lien_quan": str(tien),
                                    "cau_hoi_gui_chi_nhanh": f"Hóa đơn {so_ct} ngày {d_str} nhập trễ của tháng {prev_month}, có cần điều chỉnh về kỳ tháng {prev_month} không?",
                                })
                                continue
                            else:
                                # Ngày mơ hồ: target_month/prev_month (ví dụ 10/09/2026 hoặc 11/10/2026)
                                parsed_date_str = ""
                                trang_thai = "CAN_NGUOI_QUYET"
                                if target_month == 10:
                                    ghi_chu = "Ngày ghi 10/09/2026 mơ hồ (có thể là 10/09/2026 ngoài kỳ hoặc 09/10/2026 trong kỳ); ghi chú cuối bảng chỉ nhắc 4 đơn tháng 9 từ 26-30/09; cần người quyết định."
                                    mo_ta_msg = f"Dòng {r} chứng từ {so_ct} ngày ghi '10/09/2026' mơ hồ: có thể hiểu là 10/09/2026 (ngoài kỳ) hoặc 09/10/2026 (trong kỳ)."
                                    q_msg = f"Hóa đơn {so_ct} ngày chính xác là 09/10/2026 hay 10/09/2026?"
                                else:
                                    note_range = f"27-31/{prev_month:02d}"
                                    ghi_chu = f"Ngày ghi {d_str} mơ hồ (có thể là {d_str} ngoài kỳ hoặc {prev_month:02d}/{target_month:02d}/{py} trong kỳ); ghi chú cuối bảng chỉ nhắc 4 đơn tháng {prev_month:02d} từ {note_range}; cần người quyết định."
                                    mo_ta_msg = f"Dòng {r} chứng từ {so_ct} ngày ghi '{d_str}' mơ hồ: có thể hiểu là {d_str} (ngoài kỳ) hoặc {prev_month:02d}/{target_month:02d}/{py} (trong kỳ)."
                                    q_msg = f"Hóa đơn {so_ct} ngày chính xác là {prev_month:02d}/{target_month:02d}/{py} hay {d_str}?"
                                
                                amb_list_for_branch.append(dict(rec, date_str=d_str))
                                viec_can_hoi.append({
                                    "chi_nhanh": cn_code,
                                    "loai": "NGAY_MO_HO",
                                    "mo_ta": mo_ta_msg,
                                    "so_chung_tu": so_ct,
                                    "dong_nguon": str(r),
                                    "so_tien_lien_quan": str(tien),
                                    "cau_hoi_gui_chi_nhanh": q_msg,
                                })
                        else:
                            oop_list_for_branch.append(rec)
                            viec_can_hoi.append({
                                "chi_nhanh": cn_code,
                                "loai": "NGOAI_KY",
                                "mo_ta": f"Dòng {r} chứng từ {so_ct} ngày {d_str} ngoài kỳ báo cáo.",
                                "so_chung_tu": so_ct,
                                "dong_nguon": str(r),
                                "so_tien_lien_quan": str(tien),
                                "cau_hoi_gui_chi_nhanh": "Chứng từ ngoài kỳ, xác nhận điều chỉnh?",
                            })
                            continue
                    else:
                        # Các chi nhánh khác nếu có slash
                        if p2 == target_month and py == target_year:
                            parsed_date_str = f"{py:04d}-{p2:02d}-{p1:02d}"
                            trang_thai = "OK"
                        elif p1 == target_month and py == target_year:
                            parsed_date_str = f"{py:04d}-{p1:02d}-{p2:02d}"
                            trang_thai = "OK"
                        else:
                            oop_list_for_branch.append(rec)
                            continue

                elif m_dash:
                    # Dạng DD-MM-YY (Nha Trang cũ: '01-10-26')
                    p1, p2, py = int(m_dash.group(1)), int(m_dash.group(2)), int(m_dash.group(3))
                    if py < 100:
                        py += 2000
                    if cn_code == "NT":
                        if p2 == target_month and py == target_year:
                            parsed_date_str = f"{py:04d}-{p2:02d}-{p1:02d}"
                            if p1 <= 12:
                                trang_thai = "SUY_RA"
                                if target_month == 10:
                                    ghi_chu = "Suy ra ngày theo định dạng DD-MM-YY căn cứ chuỗi ngày tăng dần từ 01 đến 31, số chứng từ tăng dần và tiêu đề tháng 10/2026."
                                else:
                                    last_day_m = 30 if target_month in [4, 6, 9, 11] else 31
                                    ghi_chu = f"Suy ra ngày theo định dạng DD-MM-YY căn cứ chuỗi ngày tăng dần từ 01 đến {last_day_m:02d}, số chứng từ tăng dần và tiêu đề tháng {target_month:02d}/{target_year}."
                            else:
                                trang_thai = "OK"
                        else:
                            oop_list_for_branch.append(rec)
                            continue
                    else:
                        if p2 == target_month and py == target_year:
                            parsed_date_str = f"{py:04d}-{p2:02d}-{p1:02d}"
                            trang_thai = "OK"
                        elif p1 == target_month and py == target_year:
                            parsed_date_str = f"{py:04d}-{p1:02d}-{p2:02d}"
                            trang_thai = "OK"
                        else:
                            oop_list_for_branch.append(rec)
                            continue
            else:
                # Không nhận diện được kiểu ngày
                parsed_date_str = ""
                trang_thai = "CAN_NGUOI_QUYET"
                ghi_chu = f"Không nhận diện được định dạng ngày '{d_raw}'; cần người quyết định."
                viec_can_hoi.append({
                    "chi_nhanh": cn_code,
                    "loai": "NGAY_MO_HO",
                    "mo_ta": f"Dòng {r} chứng từ {so_ct} có định dạng ngày không xác định: {d_raw}.",
                    "so_chung_tu": so_ct,
                    "dong_nguon": str(r),
                    "so_tien_lien_quan": str(tien),
                    "cau_hoi_gui_chi_nhanh": "Ngày chính xác của chứng từ này là ngày nào?",
                })

            if parsed_date_str:
                valid_dates_set.add(parsed_date_str)

            if ma_sp == "CHUA_XAC_DINH" and not ghi_chu:
                ghi_chu = f"Mặt hàng '{sp_raw}' không có trong danh mục chuẩn của công ty."

            all_parsed_rows.append({
                "chi_nhanh": cn_code,
                "ngay": parsed_date_str,
                "so_chung_tu": so_ct,
                "ma_san_pham": ma_sp,
                "so_luong": sl,
                "don_gia": gia,
                "doanh_thu": tien,
                "file_nguon": fname,
                "dong_nguon": r,
                "trang_thai": trang_thai,
                "ghi_chu": ghi_chu,
            })

        # Kiểm tra khoảng ngày thiếu dữ liệu (> 3 ngày không có đơn hàng)
        if valid_dates_set:
            sorted_dates = sorted([datetime.strptime(d, "%Y-%m-%d").date() for d in valid_dates_set])
            for i in range(len(sorted_dates) - 1):
                gap = (sorted_dates[i+1] - sorted_dates[i]).days
                if gap > 2:
                    start_gap = sorted_dates[i].strftime("%d/%m/%Y")
                    end_gap = sorted_dates[i+1].strftime("%d/%m/%Y")
                    viec_can_hoi.append({
                        "chi_nhanh": cn_code,
                        "loai": "THIEU_DU_LIEU",
                        "mo_ta": f"Chi nhánh không có dữ liệu bán hàng từ sau ngày {start_gap} đến trước ngày {end_gap} (gián đoạn {gap-1} ngày liên tiếp).",
                        "so_chung_tu": "",
                        "dong_nguon": "",
                        "so_tien_lien_quan": "",
                        "cau_hoi_gui_chi_nhanh": f"Trong khoảng thời gian từ {start_gap} đến {end_gap} chi nhánh có phát sinh doanh thu không, hay chi nhánh tạm nghỉ/sót dữ liệu?",
                    })

        branch_stats[cn_code] = {
            "fname": fname,
            "total_file_ghi": total_file_ghi,
            "total_dong_doc_duoc": total_dong_doc_duoc,
            "raw_rows_count": len(raw_rows_in_file),
            "duplicates": dup_list_for_branch,
            "out_of_period": oop_list_for_branch,
            "ambiguous_dates": amb_list_for_branch,
            "inverted_dates": inv_list_for_branch,
            "subtotal_count": subtotal_count,
            "negative_orders": [r for r in raw_rows_in_file if r["tien"] < 0],
            "calc_diffs": calc_diffs_for_branch,
            "unknown_products": [r for r in raw_rows_in_file if normalize_product(r["sp_raw"]) == "CHUA_XAC_DINH"],
        }

    # Kiểm tra sai tổng ở cấp file (SAI_TONG)
    for cn_code, stat in branch_stats.items():
        diff = stat["total_file_ghi"] - stat["total_dong_doc_duoc"]
        if diff != 0:
            viec_can_hoi.append({
                "chi_nhanh": cn_code,
                "loai": "SAI_TONG",
                "mo_ta": f"Tổng cộng file chi nhánh ghi ({stat['total_file_ghi']:,}đ) lệch {diff:+d}đ so với tổng các dòng chi tiết đọc được ({stat['total_dong_doc_duoc']:,}đ). Do chi nhánh cộng nhẩm/gõ tay sai.",
                "so_chung_tu": "",
                "dong_nguon": "",
                "so_tien_lien_quan": str(abs(diff)),
                "cau_hoi_gui_chi_nhanh": f"Chi nhánh xác nhận lại con số tổng cộng chính xác là {stat['total_dong_doc_duoc']:,}đ (theo chi tiết) hay {stat['total_file_ghi']:,}đ?",
            })

    # 1. Xuất ra/hop_nhat.csv
    # Sắp xếp hop_nhat theo chi_nhanh, dong_nguon
    all_parsed_rows.sort(key=lambda x: (x["chi_nhanh"], x["dong_nguon"]))

    hop_nhat_path = os.path.join(ra_dir, "hop_nhat.csv")
    with open(hop_nhat_path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "chi_nhanh", "ngay", "so_chung_tu", "ma_san_pham",
            "so_luong", "don_gia", "doanh_thu", "file_nguon",
            "dong_nguon", "trang_thai", "ghi_chu"
        ])
        for r in all_parsed_rows:
            writer.writerow([
                r["chi_nhanh"], r["ngay"], r["so_chung_tu"], r["ma_san_pham"],
                r["so_luong"], r["don_gia"], r["doanh_thu"], r["file_nguon"],
                r["dong_nguon"], r["trang_thai"], r["ghi_chu"]
            ])

    # 2. Xuất ra/tong_hop_chi_nhanh.csv (chỉ tính dòng OK và SUY_RA)
    valid_rows = [r for r in all_parsed_rows if r["trang_thai"] in ["OK", "SUY_RA"]]

    th_cn = {}
    for cn in dm_cn.keys():
        th_cn[cn] = {"so_dong": 0, "doanh_thu": 0}

    for r in valid_rows:
        cn = r["chi_nhanh"]
        if cn not in th_cn:
            th_cn[cn] = {"so_dong": 0, "doanh_thu": 0}
        th_cn[cn]["so_dong"] += 1
        th_cn[cn]["doanh_thu"] += r["doanh_thu"]

    tong_hop_cn_path = os.path.join(ra_dir, "tong_hop_chi_nhanh.csv")
    with open(tong_hop_cn_path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["chi_nhanh", "so_dong", "doanh_thu"])
        for cn in dm_cn.keys():
            writer.writerow([cn, th_cn[cn]["so_dong"], th_cn[cn]["doanh_thu"]])

    # 3. Xuất ra/tong_hop_san_pham.csv
    th_sp = {}
    for ma_sp, ten_sp in dm_sp.items():
        th_sp[ma_sp] = {"ten_san_pham": ten_sp, "so_luong": 0, "doanh_thu": 0}

    for r in valid_rows:
        ma = r["ma_san_pham"]
        if ma not in th_sp:
            th_sp[ma] = {"ten_san_pham": "Chưa xác định", "so_luong": 0, "doanh_thu": 0}
        th_sp[ma]["so_luong"] += r["so_luong"]
        th_sp[ma]["doanh_thu"] += r["doanh_thu"]

    tong_hop_sp_path = os.path.join(ra_dir, "tong_hop_san_pham.csv")
    with open(tong_hop_sp_path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ma_san_pham", "ten_san_pham", "so_luong", "doanh_thu"])
        for ma in sorted(th_sp.keys()):
            writer.writerow([ma, th_sp[ma]["ten_san_pham"], th_sp[ma]["so_luong"], th_sp[ma]["doanh_thu"]])

    # 4. Xuất ra/tong_hop_chi_nhanh_san_pham.csv
    th_cn_sp = {}
    for r in valid_rows:
        key = (r["chi_nhanh"], r["ma_san_pham"])
        if key not in th_cn_sp:
            th_cn_sp[key] = {"so_luong": 0, "doanh_thu": 0}
        th_cn_sp[key]["so_luong"] += r["so_luong"]
        th_cn_sp[key]["doanh_thu"] += r["doanh_thu"]

    tong_hop_cn_sp_path = os.path.join(ra_dir, "tong_hop_chi_nhanh_san_pham.csv")
    with open(tong_hop_cn_sp_path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["chi_nhanh", "ma_san_pham", "so_luong", "doanh_thu"])
        for key in sorted(th_cn_sp.keys()):
            writer.writerow([key[0], key[1], th_cn_sp[key]["so_luong"], th_cn_sp[key]["doanh_thu"]])

    # 5. Xuất ra/viec_can_hoi.csv
    viec_can_hoi_path = os.path.join(ra_dir, "viec_can_hoi.csv")
    with open(viec_can_hoi_path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "chi_nhanh", "loai", "mo_ta", "so_chung_tu",
            "dong_nguon", "so_tien_lien_quan", "cau_hoi_gui_chi_nhanh"
        ])
        for v in viec_can_hoi:
            writer.writerow([
                v["chi_nhanh"], v["loai"], v["mo_ta"], v["so_chung_tu"],
                v["dong_nguon"], v["so_tien_lien_quan"], v["cau_hoi_gui_chi_nhanh"]
            ])

    # 6. Xuất ra/kiem_tra.csv
    kiem_tra_path = os.path.join(ra_dir, "kiem_tra.csv")
    with open(kiem_tra_path, mode="w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "chi_nhanh", "tong_file_ghi", "tong_dong_doc_duoc",
            "tong_hop_nhat", "chenh_lech", "giai_thich"
        ])
        for cn in dm_cn.keys():
            stat = branch_stats.get(cn, {
                "total_file_ghi": 0, "total_dong_doc_duoc": 0,
                "raw_rows_count": 0, "duplicates": [], "out_of_period": [],
                "ambiguous_dates": [], "inverted_dates": [], "subtotal_count": 0,
                "negative_orders": [], "calc_diffs": [], "unknown_products": []
            })
            t_ghi = stat["total_file_ghi"]
            t_doc = stat["total_dong_doc_duoc"]
            t_hn = th_cn[cn]["doanh_thu"]
            c_lech = t_ghi - t_hn

            # Tạo giải thích chi tiết cho từng chi nhánh
            giai_thich_items = []
            if cn == "HN":
                if c_lech != 0:
                    giai_thich_items.append(f"Chi nhánh tự gõ tay số tổng cộng ({t_ghi:,}đ) lệch {c_lech:+d}đ so với tổng {stat['raw_rows_count']} dòng chi tiết thực tế ({t_doc:,}đ).")
                else:
                    giai_thich_items.append("Khớp 100% giữa file gốc và bảng hợp nhất.")
            elif cn == "DN":
                if c_lech == 0:
                    if stat["negative_orders"]:
                        no_sample = stat["negative_orders"][0]
                        ret_desc = f"{no_sample['so_ct']} giá trị {no_sample['tien']:,}đ".replace(",", ".")
                        giai_thich_items.append(f"Khớp 100% giữa file gốc và bảng hợp nhất (đã bao gồm đơn hàng trả lại {ret_desc}).")
                    else:
                        giai_thich_items.append("Khớp 100% giữa file gốc và bảng hợp nhất.")
                else:
                    giai_thich_items.append(f"Chênh lệch {c_lech:,}đ chưa xác định rõ nguyên nhân.")
            elif cn == "BH":
                if c_lech == 0:
                    giai_thich_items.append(f"Khớp 100% giữa file gốc và bảng hợp nhất (đã loại bỏ {stat['subtotal_count']} dòng cộng tuần trung gian và chuẩn hóa {len(stat['inverted_dates'])} ngày bị đảo mm/dd trong Excel).")
                else:
                    giai_thich_items.append(f"Chênh lệch {c_lech:,}đ chưa xác định rõ nguyên nhân.")
            elif cn == "CT":
                if c_lech == 0:
                    if stat["unknown_products"]:
                        up_sum = sum(up["tien"] for up in stat["unknown_products"])
                        up_sum_str = f"{up_sum:,}đ".replace(",", ".")
                        up_cts = " và ".join(up["so_ct"] for up in stat["unknown_products"])
                        up_names = list(dict.fromkeys(up["sp_raw"] for up in stat["unknown_products"]))
                        giai_thich_items.append(f"Khớp 100% giữa file gốc và bảng hợp nhất (bao gồm {len(stat['unknown_products'])} đơn {up_cts} tổng {up_sum_str} bán mặt hàng {', '.join(up_names)} với mã CHUA_XAC_DINH).")
                    else:
                        giai_thich_items.append("Khớp 100% giữa file gốc và bảng hợp nhất.")
                else:
                    giai_thich_items.append(f"Chênh lệch {c_lech:,}đ.")
            elif cn == "HP":
                details = []
                if stat["duplicates"]:
                    dup_sum = sum(d["tien"] for d in stat["duplicates"])
                    dup_sum_str = f"{dup_sum:,}đ".replace(",", ".")
                    dup_desc_parts = [f"{d['so_ct']} dòng {d['row_idx']}: {d['tien']:,}đ".replace(",", ".") for d in stat["duplicates"]]
                    dup_desc = "; ".join(dup_desc_parts)
                    details.append(f"{dup_sum_str} do {len(stat['duplicates'])} dòng trùng lặp ({dup_desc})")
                if stat["out_of_period"]:
                    oop_sum = sum(d["tien"] for d in stat["out_of_period"])
                    oop_sum_str = f"{oop_sum:,}đ".replace(",", ".")
                    oop_desc_parts = [f"{d['so_ct']}: {d['tien']:,}đ".replace(",", ".") for d in stat["out_of_period"]]
                    oop_desc = "; ".join(oop_desc_parts)
                    details.append(f"{oop_sum_str} do {len(stat['out_of_period'])} đơn tháng {prev_month} nhập trễ ngoài kỳ ({oop_desc})")
                if stat["ambiguous_dates"]:
                    amb_sum = sum(d["tien"] for d in stat["ambiguous_dates"])
                    amb_sum_str = f"{amb_sum:,}đ".replace(",", ".")
                    amb_desc_parts = [f"{d['so_ct']}: {d['tien']:,}đ".replace(",", ".") for d in stat["ambiguous_dates"]]
                    amb_desc = "; ".join(amb_desc_parts)
                    d_sample = stat["ambiguous_dates"][0]["date_str"]
                    details.append(f"{amb_sum_str} do {len(stat['ambiguous_dates'])} đơn ngày {d_sample} mơ hồ thuộc diện CAN_NGUOI_QUYET không đưa vào tổng hợp ({amb_desc})")
                if details:
                    giai_thich_items.append(f"Chênh lệch {c_lech:,}đ gồm: " + "; ".join(details) + ".")
                else:
                    giai_thich_items.append("Khớp 100% giữa file gốc và bảng hợp nhất." if c_lech == 0 else f"Chênh lệch {c_lech:,}đ.")
            elif cn == "NT":
                details = []
                if stat["duplicates"]:
                    dup_sum = sum(d["tien"] for d in stat["duplicates"])
                    dup_sum_str = f"{dup_sum:,}đ".replace(",", ".")
                    dup_desc_parts = [f"{d['so_ct']} dòng {d['row_idx']}: {d['tien']:,}đ".replace(",", ".") for d in stat["duplicates"]]
                    dup_desc = "; ".join(dup_desc_parts)
                    details.append(f"{dup_sum_str} do {len(stat['duplicates'])} dòng trùng lặp ({dup_desc})")
                if stat["calc_diffs"]:
                    diff_sum = sum(d["tien"] - (d["sl"] * d["gia"]) for d in stat["calc_diffs"])
                    diff_sum_str = f"{diff_sum:+,.0f}đ".replace(",", ".")
                    cts = " và ".join(d["so_ct"] for d in stat["calc_diffs"])
                    details.append(f"Khoản lệch thành tiền {diff_sum_str} ở đơn {cts} được giữ nguyên số tiền chi nhánh ghi nên không làm phát sinh thêm chênh lệch tổng hợp")
                if details:
                    giai_thich_items.append(f"Chênh lệch {c_lech:,}đ gồm: " + "; ".join(details) + ".")
                else:
                    giai_thich_items.append("Khớp 100% giữa file gốc và bảng hợp nhất." if c_lech == 0 else f"Chênh lệch {c_lech:,}đ.")

            giai_thich_str = " ".join(giai_thich_items)
            writer.writerow([cn, t_ghi, t_doc, t_hn, c_lech, giai_thich_str])

    # 7. Xuất ra/bao_cao.md
    total_doanh_thu = sum(th_cn[cn]["doanh_thu"] for cn in dm_cn.keys())
    total_so_dong = sum(th_cn[cn]["so_dong"] for cn in dm_cn.keys())

    total_ambiguous_rows = sum(len(stat["ambiguous_dates"]) for stat in branch_stats.values())
    total_ambiguous_money = sum(sum(d["tien"] for d in stat["ambiguous_dates"]) for stat in branch_stats.values())
    hp_amb_dates_str = branch_stats["HP"]["ambiguous_dates"][0]["date_str"] if branch_stats.get("HP", {}).get("ambiguous_dates") else ""

    hp_dups_count = len(branch_stats.get("HP", {}).get("duplicates", []))
    hp_dups_money = sum(d["tien"] for d in branch_stats.get("HP", {}).get("duplicates", []))
    nt_dups_count = len(branch_stats.get("NT", {}).get("duplicates", []))
    nt_dups_money = sum(d["tien"] for d in branch_stats.get("NT", {}).get("duplicates", []))
    total_dups_count = hp_dups_count + nt_dups_count

    hp_oop_count = len(branch_stats.get("HP", {}).get("out_of_period", []))
    hp_oop_money = sum(d["tien"] for d in branch_stats.get("HP", {}).get("out_of_period", []))

    last_day_of_month = 30 if target_month in [4, 6, 9, 11] else 31

    bao_cao_path = os.path.join(ra_dir, "bao_cao.md")
    with open(bao_cao_path, mode="w", encoding="utf-8") as f:
        f.write(f"# BÁO CÁO TỔNG HỢP DOANH THU BÁN HÀNG THÁNG {target_month:02d}/{target_year}\n\n")
        f.write(f"**Kính gửi:** Ban Giám đốc Công ty TNHH Mẫu An Phát  \n")
        f.write(f"**Người lập:** Trợ lý Kế toán Quản trị  \n")
        f.write(f"**Kỳ báo cáo:** Tháng {target_month:02d}/{target_year} (01/{target_month:02d}/{target_year} - {last_day_of_month:02d}/{target_month:02d}/{target_year})  \n")
        f.write(f"**Ngày lập báo cáo:** {datetime.now().strftime('%d/%m/%Y')}  \n\n")
        f.write(f"---\n\n")

        f.write(f"## 1. TỔNG QUAN KẾT QUẢ KINH DOANH THÁNG {target_month:02d}/{target_year}\n\n")
        f.write(f"- **Tổng doanh thu hợp nhất toàn công ty:** **{total_doanh_thu:,} VNĐ**\n")
        f.write(f"- **Tổng số lượt giao dịch bán hàng hợp lệ:** **{total_so_dong:,} giao dịch** (chỉ tính các dòng trạng thái `OK` và `SUY_RA`)\n")
        f.write(f"- **Số chi nhánh gửi báo cáo:** 6/6 chi nhánh (Hà Nội, Hải Phòng, Đà Nẵng, Cần Thơ, Biên Hòa, Nha Trang)\n")
        f.write(f"- **Số giao dịch cần người quyết định (tạm giữ ngoài tổng hợp):** {total_ambiguous_rows} giao dịch tại chi nhánh Hải Phòng (tổng giá trị **{total_ambiguous_money:,} VNĐ** do ngày tháng mơ hồ `{hp_amb_dates_str}`)\n")
        f.write(f"- **Số giao dịch trùng lặp đã loại bỏ:** {total_dups_count} giao dịch (Hải Phòng {hp_dups_count} dòng = {hp_dups_money:,} VNĐ; Nha Trang {nt_dups_count} dòng = {nt_dups_money:,} VNĐ)\n")
        f.write(f"- **Số giao dịch ngoài kỳ (tháng {prev_month:02d}) đã bóc tách:** {hp_oop_count} giao dịch tại Hải Phòng (tổng giá trị **{hp_oop_money:,} VNĐ**)\n\n")

        f.write(f"## 2. BÁO CÁO DOANH THU THEO CHI NHÁNH\n\n")
        f.write(f"| Mã CN | Tên chi nhánh | Số dòng GD | Doanh thu hợp nhất (VNĐ) | Tỷ trọng | Ghi chú |\n")
        f.write(f"| :--- | :--- | :---: | :---: | :---: | :--- |\n")
        for cn, info in dm_cn.items():
            dt = th_cn[cn]["doanh_thu"]
            sd = th_cn[cn]["so_dong"]
            ty_trong = (dt / total_doanh_thu * 100) if total_doanh_thu > 0 else 0
            note = ""
            if cn == "HP":
                note = f"Đã trừ {hp_dups_count} dòng trùng, {hp_oop_count} đơn tháng {prev_month:02d}, tạm giữ {total_ambiguous_rows} đơn mơ hồ"
            elif cn == "NT":
                note = f"Đã trừ {nt_dups_count} dòng trùng; giữ nguyên {len(branch_stats['NT']['calc_diffs'])} đơn lệch thành tiền"
            elif cn == "HN":
                note = "Số thực tính khớp dòng chi tiết (file ghi sai tổng +100k)"
            elif cn == "CT":
                up_sum_tr = sum(up['tien'] for up in branch_stats['CT']['unknown_products']) // 1000000
                note = f"Gồm {up_sum_tr} tr Combo quà Tết; thiếu dữ liệu 15-21/{target_month:02d}"
            elif cn == "DN":
                if branch_stats["DN"]["negative_orders"]:
                    no_sample = branch_stats["DN"]["negative_orders"][0]
                    note = f"Gồm 1 đơn trả lại ({no_sample['tien']//1000}k); ngày chuẩn hóa MM/DD/YYYY"
                else:
                    note = "Ngày chuẩn hóa MM/DD/YYYY"
            elif cn == "BH":
                note = f"Đã loại {branch_stats['BH']['subtotal_count']} dòng cộng tuần; chuẩn hóa {len(branch_stats['BH']['inverted_dates'])} ngày Excel đảo"
            f.write(f"| **{cn}** | {info} | {sd:,} | {dt:,} | {ty_trong:.2f}% | {note} |\n")
        f.write(f"| **TỔNG** | **Toàn công ty** | **{total_so_dong:,}** | **{total_doanh_thu:,}** | **100.00%** | |\n\n")

        f.write(f"## 3. BÁO CÁO DOANH THU THEO SẢN PHẨM\n\n")
        f.write(f"| Mã SP | Tên sản phẩm | Số lượng bán | Doanh thu (VNĐ) | Tỷ trọng | Nhận xét |\n")
        f.write(f"| :--- | :--- | :---: | :---: | :---: | :--- |\n")
        for ma in sorted(th_sp.keys()):
            sp_info = th_sp[ma]
            dt = sp_info["doanh_thu"]
            sl = sp_info["so_luong"]
            ty_trong = (dt / total_doanh_thu * 100) if total_doanh_thu > 0 else 0
            nhan_xet = "Sản phẩm danh mục chuẩn" if ma != "CHUA_XAC_DINH" else "Sản phẩm lạ bán tại Cần Thơ (cần làm rõ)"
            f.write(f"| **{ma}** | {sp_info['ten_san_pham']} | {sl:,} | {dt:,} | {ty_trong:.2f}% | {nhan_xet} |\n")
        f.write(f"| **TỔNG** | | | **{total_doanh_thu:,}** | **100.00%** | |\n\n")

        f.write(f"## 4. KẾT QUẢ ĐỐI CHIẾU VÀ GIẢI TRÌNH CHÊNH LỆCH DỮ LIỆU\n\n")
        f.write(f"Bảng đối chiếu giữa số tổng do chi nhánh tự ghi, tổng toàn bộ dòng dữ liệu đọc được và tổng đưa vào báo cáo hợp nhất:\n\n")
        f.write(f"| Chi nhánh | Tổng file ghi (VNĐ) | Tổng dòng đọc được (VNĐ) | Tổng hợp nhất (VNĐ) | Chênh lệch (VNĐ) | Nguyên nhân chênh lệch |\n")
        f.write(f"| :--- | :---: | :---: | :---: | :---: | :--- |\n")
        for cn in dm_cn.keys():
            stat = branch_stats[cn]
            tg = stat["total_file_ghi"]
            td = stat["total_dong_doc_duoc"]
            thn = th_cn[cn]["doanh_thu"]
            cl = tg - thn
            
            exp = ""
            if cn == "HN":
                exp = f"File ghi cao hơn thực tế chi tiết {cl:,}đ do kế toán chi nhánh gõ tay sai tổng cộng cuối bảng (ghi {tg:,}đ nhưng thực tính {stat['raw_rows_count']} dòng là {td:,}đ)."
            elif cn == "DN":
                if stat["negative_orders"]:
                    no_sample = stat["negative_orders"][0]
                    exp = f"Khớp 100%. File tự động tính đúng tổng, bao gồm cả đơn hàng trả lại {no_sample['so_ct']} ({no_sample['tien']:,}đ)."
                else:
                    exp = "Khớp 100%. File tự động tính đúng tổng."
            elif cn == "BH":
                exp = f"Khớp 100%. File có {stat['subtotal_count']} dòng cộng tuần trung gian và tổng tháng {tg:,}đ khớp chuẩn với tổng {stat['raw_rows_count']} dòng bán hàng."
            elif cn == "CT":
                up_sum = sum(up['tien'] for up in stat['unknown_products'])
                up_cts = " và ".join(up['so_ct'] for up in stat['unknown_products'])
                exp = f"Khớp 100%. Doanh thu hợp nhất phản ánh toàn bộ {stat['raw_rows_count']} dòng bán hàng thực tế (bao gồm {len(stat['unknown_products'])} đơn {up_cts} tổng {up_sum:,}đ)."
            elif cn == "HP":
                exp = f"File ghi cao hơn hợp nhất {cl:,}đ do: {hp_dups_count} dòng trùng ({hp_dups_money:,}đ) + {hp_oop_count} đơn tháng {prev_month:02d} nhập trễ ({hp_oop_money:,}đ) + {total_ambiguous_rows} đơn ngày {hp_amb_dates_str} mơ hồ tạm treo ({total_ambiguous_money:,}đ)."
            elif cn == "NT":
                dup_cts = " và ".join(d['so_ct'] for d in stat['duplicates'])
                calc_cts = " và ".join(d['so_ct'] for d in stat['calc_diffs'])
                exp = f"File ghi cao hơn hợp nhất {cl:,}đ do chi nhánh nhập trùng {nt_dups_count} dòng ({dup_cts}). Riêng {len(stat['calc_diffs'])} đơn tính sai thành tiền (+100.000đ ở đơn {calc_cts}) giữ nguyên theo số chi nhánh ghi."
            f.write(f"| **{cn}** | {tg:,} | {td:,} | {thn:,} | {cl:,} | {exp} |\n")
        f.write(f"\n")

        f.write(f"## 5. CÁC VẤN ĐỀ DỮ LIỆU VÀ RỦI RO PHÁT HIỆN\n\n")
        f.write(f"Qua quá trình rà soát và kiểm toán chi tiết dữ liệu 6 file Excel, trợ lý kế toán quản trị phát hiện các vấn đề nghiêm trọng sau:\n\n")
        f.write(f"1. **Rủi ro trùng lặp hóa đơn (Hải Phòng, Nha Trang):**\n")
        hp_dup_list_str = ", ".join(d["so_ct"] for d in branch_stats["HP"]["duplicates"])
        nt_dup_list_str = ", ".join(d["so_ct"] for d in branch_stats["NT"]["duplicates"])
        f.write(f"   - Hải Phòng có {hp_dups_count} hóa đơn trùng lặp ({hp_dup_list_str}) làm đội khống doanh thu **{hp_dups_money:,} VNĐ**.\n")
        f.write(f"   - Nha Trang có {nt_dups_count} chứng từ trùng lặp ({nt_dup_list_str}) làm đội khống doanh thu **{nt_dups_money:,} VNĐ**.\n")
        f.write(f"   -> *Đề nghị:* Cần kiểm tra lại hệ thống xuất dữ liệu hoặc quy trình nhập liệu thủ công tại 2 chi nhánh này để tránh ghi nhận khống doanh thu.\n\n")
        
        f.write(f"2. **Đơn hàng ngoài kỳ hạch toán (Hải Phòng):**\n")
        oop_range_str = "từ 26/09 đến 30/09/2026" if target_month == 10 else f"từ 27/{prev_month:02d} đến 31/{prev_month:02d}/{prev_year}"
        f.write(f"   - Chi nhánh đưa {hp_oop_count} đơn hàng phát sinh {oop_range_str} vào báo cáo tháng {target_month:02d} với lý do 'nhập trễ', giá trị **{hp_oop_money:,} VNĐ**.\n")
        f.write(f"   -> *Đề nghị:* Phải hạch toán bổ sung vào kỳ tháng {prev_month:02d}/{prev_year}, không được gộp vào doanh thu tháng {target_month:02d} làm sai lệch số liệu kỳ hiện tại.\n\n")

        f.write(f"3. **Ngày tháng mơ hồ, có dấu hiệu nhầm lẫn định dạng MM/DD và DD/MM:**\n")
        f.write(f"   - Hải Phòng có {total_ambiguous_rows} đơn hàng ghi ngày `{hp_amb_dates_str}` (tổng **{total_ambiguous_money:,} VNĐ**). Không rõ là ngày trong kỳ hay ngoài kỳ bị gõ theo chuẩn đảo MM/DD. Đang tạm treo trạng thái `CAN_NGUOI_QUYET`.\n")
        f.write(f"   - Biên Hòa có {len(branch_stats['BH']['inverted_dates'])} dòng bị phần mềm Excel tự động hiểu lộn thành ngày tháng khác. Đã suy luận được ngày đúng nhờ số thứ tự phiếu và dòng cộng tuần.\n")
        f.write(f"   - Đà Nẵng lập toàn bộ theo chuẩn `MM/DD/YYYY`, Nha Trang tháng 10 lập theo `DD-MM-YY`, tháng 11 lập theo chuẩn `YYYY-MM-DD`.\n\n")

        f.write(f"4. **Lỗi tính toán sai số học và gõ tay số tổng cộng:**\n")
        f.write(f"   - Hà Nội gõ tay số tổng cộng cuối bảng lệch thừa **100.000 VNĐ** so với tổng chi tiết.\n")
        nt_calc_cts = " và ".join(d["so_ct"] for d in branch_stats["NT"]["calc_diffs"])
        f.write(f"   - Nha Trang có {len(branch_stats['NT']['calc_diffs'])} đơn hàng có Thành tiền lệch so với SL x Đơn giá (+50.000 VNĐ mỗi đơn, tổng lệch **+100.000 VNĐ** ở đơn {nt_calc_cts}). Kế toán giữ nguyên số tiền chi nhánh ghi theo nguyên tắc thận trọng nhưng yêu cầu giải trình.\n\n")

        f.write(f"5. **Thiếu dữ liệu nghiêm trọng và bán hàng ngoài danh mục (Cần Thơ):**\n")
        f.write(f"   - Chi nhánh Cần Thơ hoàn toàn không có dữ liệu bán hàng trong 7 ngày liên tiếp từ ngày **15/{target_month:02d}/{target_year} đến 21/{target_month:02d}/{target_year}**.\n")
        ct_combo_sum = sum(up['tien'] for up in branch_stats['CT']['unknown_products'])
        ct_combo_cts = " và ".join(up['so_ct'] for up in branch_stats['CT']['unknown_products'])
        f.write(f"   - Xuất hiện mặt hàng lạ **'Combo quà Tết 2026'** tại {len(branch_stats['CT']['unknown_products'])} đơn hàng {ct_combo_cts} với tổng giá trị **{ct_combo_sum:,} VNĐ** chưa có trong danh mục sản phẩm của công ty.\n\n")

        f.write(f"## 6. DANH SÁCH VIỆC CẦN HỎI LẠI CHI NHÁNH VÀ KIẾN NGHỊ\n\n")
        f.write(f"Chi tiết các câu hỏi đã được kết xuất tại file `ra/viec_can_hoi.csv`. Tóm tắt nội dung trọng tâm cần làm việc ngay:\n\n")
        f.write(f"1. **Chi nhánh Hà Nội:** Xác nhận lại con số tổng doanh thu chính xác là **{branch_stats['HN']['total_dong_doc_duoc']:,} VNĐ** (theo {branch_stats['HN']['raw_rows_count']} dòng chi tiết), điều chỉnh số tổng gõ tay {branch_stats['HN']['total_file_ghi']:,} VNĐ.\n")
        f.write(f"2. **Chi nhánh Hải Phòng:**\n")
        f.write(f"   - Xác nhận xóa {hp_dups_count} hóa đơn trùng ({hp_dup_list_str}) giá trị {hp_dups_money:,} VNĐ.\n")
        f.write(f"   - Xác nhận chuyển {hp_oop_count} đơn tháng {prev_month:02d} ({hp_oop_money:,} VNĐ) về hạch toán bổ sung cho tháng {prev_month:02d}.\n")
        f.write(f"   - Xác nhận ngày thực tế của {total_ambiguous_rows} đơn ghi `{hp_amb_dates_str}`: nếu trong kỳ thì bổ sung vào doanh thu tháng {target_month:02d} (**+{total_ambiguous_money:,} VNĐ**); nếu ngoài kỳ thì chuyển sang tháng {prev_month:02d}.\n")
        f.write(f"3. **Chi nhánh Cần Thơ:**\n")
        f.write(f"   - Giải trình lý do gián đoạn bán hàng từ ngày 15/{target_month:02d} đến 21/{target_month:02d}/{target_year} (chi nhánh đóng cửa hay sót file bán hàng?).\n")
        f.write(f"   - Giải trình cơ cấu thành phần của mặt hàng 'Combo quà Tết 2026' (đơn giá 650.000đ) để kế toán quản trị bóc tách phân bổ về 8 sản phẩm chuẩn, hoặc trình Ban Giám đốc phê duyệt mã sản phẩm mới.\n")
        f.write(f"4. **Chi nhánh Nha Trang:**\n")
        f.write(f"   - Xác nhận xóa {nt_dups_count} chứng từ trùng ({nt_dup_list_str}) giá trị {nt_dups_money:,} VNĐ.\n")
        f.write(f"   - Kiểm tra và giải trình tại sao đơn {nt_calc_cts} lại ghi thành tiền lệch +50.000đ mỗi đơn so với số lượng nhân đơn giá.\n")
        f.write(f"5. **Chi nhánh Biên Hòa & Đà Nẵng:** Nhắc nhở quy chuẩn lại định dạng ngày tháng theo chuẩn quốc gia `DD/MM/YYYY` hoặc `YYYY-MM-DD` để tránh nhầm lẫn khi tổng hợp tự động.\n\n")

        f.write(f"---\n")
        f.write(f"*Báo cáo được tạo tự động bởi hệ thống script `gop.py` dựa trên dữ liệu kế toán thực tế.*  \n")

    print("\n==================== XỬ LÝ HOÀN TẤT THÀNH CÔNG ====================")
    print(f"Tổng doanh thu hợp nhất tháng {ky_thang}: {total_doanh_thu:,} VNĐ")
    print(f"Số dòng giao dịch hợp lệ: {total_so_dong:,}")
    print(f"Các file kết quả đã được lưu tại thư mục: {ra_dir}/")
    print("  - hop_nhat.csv")
    print("  - tong_hop_chi_nhanh.csv")
    print("  - tong_hop_san_pham.csv")
    print("  - tong_hop_chi_nhanh_san_pham.csv")
    print("  - viec_can_hoi.csv")
    print("  - kiem_tra.csv")
    print("  - bao_cao.md")

if __name__ == "__main__":
    main()
