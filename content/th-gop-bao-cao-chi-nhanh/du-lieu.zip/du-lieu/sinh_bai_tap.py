"""Sinh dữ liệu GIẢ cho 3 bài tập ở bài 4 (hạt giống cố định, chạy lại ra đúng bản cũ).

Chạy (đứng trong thư mục du-lieu):  python -X utf8 sinh_bai_tap.py
Cần có sẵn du-lieu/thang-11/ (do sinh_du_lieu.py sinh) và ket-qua/dap-an-T11.json.

Ra:
  bai-tap/bt1-chi-nhanh-thu-7/   6 file tháng 11 + file chi nhánh VT (Vũng Tàu) định dạng mới; danh mục CHƯA có VT
  bai-tap/bt2-doi-ten-cot/       tháng 11, chi nhánh HN đổi tên 6 cột (đáp án vẫn là dap-an-T11.json)
  ../ket-qua/dap-an-bt1.json     đáp án của bài tập 1 (7 chi nhánh). KHÔNG đưa cho agent.
Bài tập 3 (báo cáo theo tuần) dùng dữ liệu có sẵn; đáp án tính từ dap-an-T10/T11 bằng ket-qua/kiem_tuan.py.

Toàn bộ là dữ liệu giả.
"""
import copy
import json
import random
import shutil
import sys
from pathlib import Path

import openpyxl
import xlsxwriter

AQUI = Path(__file__).resolve().parent
KQ = AQUI.parent / "ket-qua"
sys.path.insert(0, str(AQUI))
from sinh_du_lieu import ALIAS, SP, gen_rows  # noqa: E402

SEED_VT = 20261122
VT_FILE = "VungTau_T11_2026.xlsx"


def dot(n):
    return f"{n:,}".replace(",", ".")


def sinh_bt1(out):
    shutil.rmtree(out, ignore_errors=True)
    (out / "goc").mkdir(parents=True)
    src = AQUI / "thang-11"
    for p in (src / "goc").glob("*.xlsx"):
        shutil.copy(p, out / "goc" / p.name)
    for n in ("danh_muc_san_pham.csv", "danh_muc_chi_nhanh.csv"):
        shutil.copy(src / n, out / n)   # danh mục vẫn 6 chi nhánh: thêm VT là một phần của bài tập

    rng = random.Random(SEED_VT)
    rows = gen_rows(rng, "VT", 2026, 11)
    for r in rows:
        r["inv"] = f"VT{r['seq']:05d}"
        r["nv"] = rng.choice(["NV01", "NV02", "NV03", "NV04"])
    dups = rng.sample(rows, 2)
    lines = []
    for r in rows:
        lines.append((r, "main"))
        if r in dups:
            lines.append((r, "dup"))

    wb = xlsxwriter.Workbook(str(out / "goc" / VT_FILE))
    ws = wb.add_worksheet("BC T11")
    fb = wb.add_format({"bold": True, "font_size": 13})
    fh = wb.add_format({"bold": True, "bg_color": "#FDE9D9", "border": 1})
    ws.write(0, 0, "CHI NHÁNH VŨNG TÀU (dữ liệu giả để học)", fb)
    ws.write(1, 0, "Báo cáo bán hàng 01/11/2026 - 30/11/2026")
    ws.write(2, 0, "Xuất từ phần mềm quản lý bán hàng. Đơn vị: đồng")
    heads = ["Ngày", "Mã HĐ", "Nhân viên", "Sản phẩm", "SL", "Đơn giá (VND)", "Thành tiền (VND)"]
    for j, h in enumerate(heads):
        ws.write(4, j, h, fh)
    raw = 0
    truth_rows, truth_dups = [], []
    for k, (r, kind) in enumerate(lines):
        x = 5 + k
        d = r["date"]
        ws.write_string(x, 0, f"{d.day}.{d.month}.{d.year}")          # 5.11.2026 (chấm, không số 0 đầu)
        ws.write(x, 1, r["inv"]); ws.write(x, 2, r["nv"]); ws.write(x, 3, r["label"]); ws.write_number(x, 4, r["qty"])
        ws.write_string(x, 5, dot(r["price"]) + " VND"); ws.write_string(x, 6, dot(r["amount"]) + " VND")
        raw += r["amount"]
        if kind == "main":
            truth_rows.append(dict(branch="VT", inv=r["inv"], date=d.isoformat(), prod=r["prod"], qty=r["qty"], price=r["price"],
                                   amount=r["amount"], status="OK", flags=[], file=VT_FILE, src_row=x + 1))
        else:
            truth_dups.append(dict(branch="VT", inv=r["inv"], amount=r["amount"], src_row=x + 1))
    x = 5 + len(lines)
    ws.write(x, 5, "Tổng cộng:", fb); ws.write_string(x, 6, dot(raw) + " VND", fb)
    ws.write(x + 2, 0, "Ghi chú: 2 dòng nhập lặp do lỗi máy in, chưa xóa.")
    ws.set_column(0, 2, 12); ws.set_column(3, 3, 34); ws.set_column(4, 6, 16)
    wb.close()

    T = json.loads((KQ / "dap-an-T11.json").read_text(encoding="utf-8"))
    T = copy.deepcopy(T)
    T["ghi_chu"] = "DỮ LIỆU GIẢ. Đáp án bài tập 1 (6 chi nhánh tháng 11 + VT). Không đưa cho agent."
    T["rows"] += truth_rows
    T["dup_rows"] += truth_dups
    T["files"]["VT"] = dict(file=VT_FILE, tong_file_ghi=raw, tong_moi_dong_doc_duoc=raw,
                            ghi_chu="Ngày chữ d.m.yyyy, số chữ '... VND', thêm cột Nhân viên, tiêu đề ở dòng 5, 2 dòng trùng, tổng gồm cả dòng trùng.")
    tot_vt = sum(r["amount"] for r in truth_rows)
    T["tong_chi_nhanh_xac_nhan"]["VT"] = tot_vt
    T["tong_chi_nhanh_neu_tinh_ca_mo_ho"]["VT"] = tot_vt
    for r in truth_rows:
        T["tong_san_pham_xac_nhan"][r["prod"]] = T["tong_san_pham_xac_nhan"].get(r["prod"], 0) + r["amount"]
        k = f"VT|{r['prod']}"
        T["tong_chi_nhanh_san_pham"][k] = T["tong_chi_nhanh_san_pham"].get(k, 0) + r["amount"]
    T["tong_xac_nhan"] = sum(T["tong_chi_nhanh_xac_nhan"].values())
    (KQ / "dap-an-bt1.json").write_text(json.dumps(T, ensure_ascii=False, indent=1), encoding="utf-8")
    return len(truth_rows), tot_vt, len(truth_dups), T["tong_xac_nhan"]


DOI_TEN = {"Ngày": "Ngày xuất", "Số HĐ": "Số phiếu xuất", "Tên hàng": "Mặt hàng", "SL": "Số lượng",
           "Đơn giá": "Giá bán", "Thành tiền": "Giá trị"}


def sinh_bt2(out):
    shutil.rmtree(out, ignore_errors=True)
    (out / "goc").mkdir(parents=True)
    src = AQUI / "thang-11"
    for p in (src / "goc").glob("*.xlsx"):
        shutil.copy(p, out / "goc" / p.name)
    for n in ("danh_muc_san_pham.csv", "danh_muc_chi_nhanh.csv"):
        shutil.copy(src / n, out / n)
    hn = out / "goc" / "BC doanh thu T11 - HN.xlsx"
    wb = openpyxl.load_workbook(hn)
    ws = wb.active
    doi = 0
    for c in ws[4]:       # hàng tiêu đề của HN nằm ở dòng 4
        if c.value in DOI_TEN:
            c.value = DOI_TEN[c.value]; doi += 1
    wb.save(hn)
    return doi


if __name__ == "__main__":
    base = AQUI / "bai-tap"
    n, tot, nd, tong = sinh_bt1(base / "bt1-chi-nhanh-thu-7")
    print(f"BT1: VT {n} dòng xác nhận, tổng VT {tot:,}, {nd} dòng trùng; tổng 7 chi nhánh {tong:,}")
    print(f"BT2: đã đổi {sinh_bt2(base / 'bt2-doi-ten-cot')} tên cột ở file HN")
