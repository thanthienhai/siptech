"""Kiểm mọi trích dẫn có nguyên văn trong cột noi_dung của đúng mã đó.

Kiểm:
  1. y-kien.csv   : cột trich_dan
  2. nguy-cap.csv : cột trich_dan
  3. bao-cao.md   : các dòng bằng chứng dạng   > [mã] "trích nguyên văn"
Ngoài ra kiểm cấu trúc báo cáo: đúng 5 mục "## Việc N:", mỗi mục 2-3 dòng bằng chứng,
và không có dòng '>' nào sai mẫu.
Chạy: python kiem-tra-trich-dan.py   (thoát mã 1 nếu có dòng không qua)
"""
import csv
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def doc_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


goc = {r["ma"]: r["noi_dung"] for r in doc_csv(os.path.join(HERE, "..", "danh-gia.csv"))}
loi = []


def kiem(nguon, dong, ma, trich):
    if ma not in goc:
        loi.append(f"{nguon} {dong}: mã {ma} không có trong danh-gia.csv")
    elif not trich:
        loi.append(f"{nguon} {dong}: [{ma}] trích dẫn rỗng")
    elif trich not in goc[ma]:
        loi.append(f"{nguon} {dong}: [{ma}] không có nguyên văn: {trich!r}")


so_csv = {}
for ten in ("y-kien.csv", "nguy-cap.csv"):
    rows = doc_csv(os.path.join(HERE, ten))
    so_csv[ten] = len(rows)
    for i, r in enumerate(rows, start=2):  # dòng 1 là tên cột
        kiem(ten, f"dòng {i}", r["ma"], r["trich_dan"])

# --- bao-cao.md ---
mau = re.compile(r'^>\s*\[(R\d+)\]\s*"(.+)"\s*$')
muc = None            # tên mục "Việc N" hiện tại
so_bang_chung = {}    # mục -> số dòng bằng chứng
tong_bc = 0
with open(os.path.join(HERE, "bao-cao.md"), encoding="utf-8") as f:
    for n, dong in enumerate(f, start=1):
        dong = dong.rstrip("\n")
        if dong.startswith("## "):
            muc = dong[3:] if re.match(r"^## Việc \d+:", dong) else None
            if muc:
                so_bang_chung[muc] = 0
            continue
        if dong.lstrip().startswith(">"):
            m = mau.match(dong)
            if not m:
                loi.append(f"bao-cao.md dòng {n}: dòng '>' sai mẫu > [mã] \"trích dẫn\": {dong[:60]}")
                continue
            tong_bc += 1
            kiem("bao-cao.md", f"dòng {n}", m.group(1), m.group(2))
            if muc:
                so_bang_chung[muc] += 1
            else:
                loi.append(f"bao-cao.md dòng {n}: bằng chứng nằm ngoài các mục Việc")

if len(so_bang_chung) != 5:
    loi.append(f"bao-cao.md có {len(so_bang_chung)} mục 'Việc', cần đúng 5")
for muc, so in so_bang_chung.items():
    if not 2 <= so <= 3:
        loi.append(f"bao-cao.md mục '{muc}': {so} dòng bằng chứng, cần 2 đến 3")

print(f"y-kien.csv: {so_csv['y-kien.csv']} trích dẫn | nguy-cap.csv: {so_csv['nguy-cap.csv']} | bao-cao.md: {tong_bc} bằng chứng "
      f"trong {len(so_bang_chung)} mục Việc")
if loi:
    print(f"KHÔNG QUA: {len(loi)} lỗi")
    for l in loi:
        print(" -", l)
    sys.exit(1)
print("QUA: mọi trích dẫn đều có nguyên văn trong đúng mã.")
