"""Script nhỏ cho bài 3: đọc don-hang-thu.csv, in số dòng, khách đầu tiên và tổng tiền.
Cố ý đọc file bằng open() mặc định (không ghi encoding) để thấy vì sao cần python -X utf8 trên Windows.
Chạy:  python -X utf8 tong_don_hang.py <đường dẫn file csv>
"""
import csv
import sys

with open(sys.argv[1], newline="") as f:
    rows = list(csv.reader(f))
data = rows[1:]
tong = sum(int(r[4]) * int(r[5]) for r in data)
print(f"So dong hang: {len(data)}")
print(f"Khach dau tien: {data[0][2]}")
print(f"Tong tien: {tong:,} dong")
