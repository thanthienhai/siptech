#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tính công tháng 09/2026 và phát hiện bất thường theo quy_dinh_cong_ty.md.

Chỉ đọc 4 tệp CSV trong thư mục hiện tại, không sửa dữ liệu gốc.
Sinh: bang_cong_ngay.csv, bat_thuong.csv, tong_hop_nguoi.csv, bao_cao.md.
Mọi ngưỡng lấy từ quy định (mục 2, 4, 5, 7); đổi tham số chỉ ở khối THAM SỐ dưới đây.
"""
import csv
import os
import sys
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------ THAM SỐ (quy định mục 1-4)
KY_BAT_DAU = date(2026, 9, 1)
KY_KET_THUC = date(2026, 9, 30)
NGAY_LE = {date(2026, 9, 1), date(2026, 9, 2)}
CA = {  # phút kể từ 00:00
    "HC": (8 * 60, 17 * 60),
    "S": (6 * 60, 14 * 60),
    "C": (14 * 60, 22 * 60),
}
NGHI_TRUA = (12 * 60, 13 * 60)  # chỉ trừ với ca HC
DUNG_SAI = 5            # trễ/sớm <= 5 phút vẫn đủ
TRUNG_PHUT = 3          # cùng máy cách nhau <= 3 phút là quẹt trùng
QUET_HO_PHUT = 10       # hai máy khác nhau cách nhau <= 10 phút
OT_TOI_THIEU = 30       # quẹt ra muộn >= 30 phút mới tính OT
OT_NGAY_NGUONG = 180    # > 180 phút: OT_VUOT_NGUONG
OT_THANG_NGUONG = 2400  # > 2400 phút: OT_THANG_VUOT
DON_LE_CAN = 120        # quẹt đơn lẻ: trong 120 phút quanh giờ vào/ra ca
MAY = {"MAY-A1": "%Y-%m-%d %H:%M:%S", "MAY-B1": "%d/%m/%Y %H:%M"}

KHONG_CAN_QUYET = {"QUET_TRUNG", "DI_TRE", "VE_SOM"}
CHO = "CẦN NGƯỜI QUYẾT"


def hm(minutes):
    return "%02d:%02d" % (minutes // 60, minutes % 60)


def doc_csv(ten):
    with open(os.path.join(HERE, ten), encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def ghi_csv(ten, cot, dong):
    with open(os.path.join(HERE, ten), "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cot, lineterminator="\n")
        w.writeheader()
        w.writerows(dong)


def parse_dmy(s):
    return datetime.strptime(s.strip(), "%d/%m/%Y").date()


# ------------------------------------------------------------------ ĐỌC DỮ LIỆU
def nap_du_lieu():
    nv = {r["ma_nv"].strip(): r for r in doc_csv("nhan_vien.csv")}
    lich = {}
    for r in doc_csv("lich_ca_xoay.csv"):
        lich[(r["ma_nv"].strip(), parse_dmy(r["ngay"]))] = r["ca"].strip()
    phep = defaultdict(list)  # (ma_nv, ngay) -> [loai đơn]
    for r in doc_csv("nghi_phep.csv"):
        if r["trang_thai"].strip() != "Đã duyệt":
            continue
        d1, d2 = parse_dmy(r["tu_ngay"]), parse_dmy(r["den_ngay"])
        d = d1
        while d <= d2:
            phep[(r["ma_nv"].strip(), d)].append(r["loai"].strip())
            d += timedelta(days=1)
    return nv, lich, phep


def phan_loai_quet(rows, nv):
    """Trả về (quet_hop_le, loi). quet_hop_le: {(ma_nv, ngay): [(phut_tuyet_doi, may, so_dong)]}."""
    hop_le = defaultdict(list)
    loi = defaultdict(list)  # (ma_nv, ngay hoặc '') -> [mô tả]
    for i, r in enumerate(rows, start=2):  # dòng 1 là tiêu đề
        ma_nv = (r.get("ma_nv") or "").strip()
        may = (r.get("ma_may") or "").strip()
        tg = (r.get("thoi_gian") or "").strip()
        dt = None
        ly_do = []
        if may not in MAY:
            ly_do.append("mã máy '%s' không thuộc hai máy khai báo" % may)
        elif not tg:
            ly_do.append("thời gian trống")
        else:
            try:
                dt = datetime.strptime(tg, MAY[may])
            except ValueError:
                ly_do.append("thời gian '%s' không phải ngày giờ hợp lệ" % tg)
        if ma_nv not in nv:
            ly_do.append("mã '%s' không có trong nhan_vien.csv" % ma_nv)
        if dt is not None and not (KY_BAT_DAU <= dt.date() <= KY_KET_THUC):
            ly_do.append("ngày %s nằm ngoài kỳ chấm công" % dt.date().isoformat())
        if ly_do:
            ngay = dt.date().isoformat() if dt is not None else ""
            loi[(ma_nv, ngay)].append(
                "dòng %d (%s, thời gian '%s'): %s" % (i, may, tg, "; ".join(ly_do)))
            continue
        # bỏ phần giây: so sánh theo phút
        phut = dt.hour * 60 + dt.minute
        hop_le[(ma_nv, dt.date())].append((phut, may, i))
    return hop_le, loi


# ------------------------------------------------------------------ XỬ LÝ MỘT NGÀY
def loai_ngay_cua(ma_nv, d, nv, lich):
    if d in NGAY_LE:
        return "LE"
    if nv[ma_nv]["loai_ca"].strip() == "HC":
        return "HC" if d.weekday() < 5 else "OFF"
    ca = lich.get((ma_nv, d))
    if ca is None:
        raise SystemExit("Thiếu lịch ca xoay của %s ngày %s" % (ma_nv, d))
    return ca


def bo_trung(quet):
    """Quy định mục 4: cùng máy cách quẹt GIỮ gần nhất <= 3 phút thì bỏ quẹt sau."""
    quet = sorted(quet, key=lambda x: (x[0], x[2]))
    giu, bo = [], []
    cuoi = {}
    for q in quet:
        phut, may, _ = q
        if may in cuoi and phut - cuoi[may] <= TRUNG_PHUT:
            bo.append((q, cuoi[may]))
        else:
            giu.append(q)
            cuoi[may] = phut
    return giu, bo


def tim_quet_ho(giu):
    cap = []
    for a in range(len(giu)):
        for b in range(a + 1, len(giu)):
            if giu[a][1] != giu[b][1] and abs(giu[b][0] - giu[a][0]) <= QUET_HO_PHUT:
                cap.append((giu[a], giu[b]))
    return cap


def tinh_gio_cong(ca, vao, ra):
    bd, kt = CA[ca]
    tre = vao - bd
    som = kt - ra
    bat_dau = bd if tre <= DUNG_SAI else vao
    ket_thuc = kt if som <= DUNG_SAI else min(ra, kt)
    phut = max(0, ket_thuc - bat_dau)
    if ca == "HC":
        giao = max(0, min(ket_thuc, NGHI_TRUA[1]) - max(bat_dau, NGHI_TRUA[0]))
        phut -= giao
    return phut


def mo_ta_quet(giu):
    return ", ".join("%s (%s)" % (hm(p), m) for p, m, _ in giu)


def main():
    nv, lich, phep = nap_du_lieu()
    with open(os.path.join(HERE, "cham_cong.csv"), encoding="utf-8-sig", newline="") as f:
        rows_goc = list(csv.DictReader(f))
    hop_le, loi = phan_loai_quet(rows_goc, nv)

    ngay_ky = []
    d = KY_BAT_DAU
    while d <= KY_KET_THUC:
        ngay_ky.append(d)
        d += timedelta(days=1)

    bang = []       # bang_cong_ngay
    bt = []         # bat_thuong
    thong_ke_phu = Counter()  # số liệu phụ cho báo cáo

    def them_bt(ma_nv, ngay, loai, chi_tiet, giai_thich):
        bt.append({
            "ma_nv": ma_nv, "ngay": ngay, "loai": loai, "chi_tiet": chi_tiet,
            "can_nguoi_quyet": "KHONG" if loai in KHONG_CAN_QUYET else "CO",
            "giai_thich": giai_thich,
        })

    ot_thang = defaultdict(int)
    ot_ngay_thang = defaultdict(int)
    cho_thang = defaultdict(int)

    for ma_nv in sorted(nv):
        for d in ngay_ky:
            iso = d.isoformat()
            loai_ngay = loai_ngay_cua(ma_nv, d, nv, lich)
            dong = {"ma_nv": ma_nv, "ngay": iso, "loai_ngay": loai_ngay, "gio_vao": "",
                    "gio_ra": "", "gio_cong": "", "phut_tre": "", "phut_ve_som": "",
                    "ot_phut": "", "trang_thai": ""}
            quet = hop_le.get((ma_nv, d), [])
            giu, bo = bo_trung(quet)
            if bo:
                ct = "; ".join("quẹt %s (%s) cách quẹt giữ lại %s %d phút, bỏ" %
                               (hm(q[0]), q[1], hm(g), q[0] - g) for q, g in bo)
                them_bt(ma_nv, iso, "QUET_TRUNG", ct,
                        "%s có quẹt trùng cùng máy trong ngày %s; hệ thống đã giữ quẹt đầu và bỏ quẹt sau. "
                        "Không cần xử lý, chỉ để quản lý biết." % (ma_nv, iso))
            quet_ho = tim_quet_ho(giu)
            co_phep = (ma_nv, d) in phep

            if quet_ho:
                ct_ho = "; ".join("%s (%s) và %s (%s) cách nhau %d phút" %
                                  (hm(a[0]), a[1], hm(b[0]), b[1], abs(b[0] - a[0]))
                                  for a, b in quet_ho)
                gt_ho = ("%s có hai quẹt ở hai máy khác nhau cách nhau không quá %d phút trong ngày %s. "
                         "Đây chỉ là dấu hiệu cần đối chiếu; đề nghị người có thẩm quyền xác minh, "
                         "chưa tính giờ cho ngày này." % (ma_nv, QUET_HO_PHUT, iso))
                them_bt(ma_nv, iso, "NGHI_QUET_HO", "%s. %s" % (ct_ho, CHO), gt_ho)

            if loai_ngay in ("OFF", "LE"):
                if giu:
                    dong["trang_thai"] = "CHO_XAC_NHAN"
                    ma = "LAM_NGAY_LE" if loai_ngay == "LE" else "LAM_NGAY_NGHI"
                    ten = "ngày lễ" if loai_ngay == "LE" else "ngày nghỉ (OFF)"
                    them_bt(ma_nv, iso, ma,
                            "có %d quẹt: %s; %s. %s" % (len(giu), mo_ta_quet(giu), ten, CHO),
                            "%s có quẹt trong %s %s, không tính giờ công thường. "
                            "Nên hỏi xem ngày này có được giao làm không và cách ghi nhận; "
                            "giờ làm thêm/nghỉ lễ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
                            % (ma_nv, ten, iso))
                else:
                    dong["trang_thai"] = "NGHI"
            else:
                bd, kt = CA[loai_ngay]
                if not giu:
                    if co_phep:
                        dong["trang_thai"] = "PHEP"
                    else:
                        dong["trang_thai"] = "CHO_XAC_NHAN"
                        them_bt(ma_nv, iso, "VANG_CHUA_GHI",
                                "ngày làm việc ca %s, không có quẹt, không có đơn nghỉ đã duyệt. %s"
                                % (loai_ngay, CHO),
                                "%s không có quẹt nào và không có đơn nghỉ đã duyệt ngày %s. "
                                "Nên hỏi quản lý trực tiếp xem là nghỉ chưa làm đơn hay chưa ghi nhận quẹt."
                                % (ma_nv, iso))
                elif co_phep:
                    dong["trang_thai"] = "CHO_XAC_NHAN"
                    them_bt(ma_nv, iso, "CO_PHEP_NHUNG_QUET",
                            "đơn '%s' đã duyệt nhưng có %d quẹt: %s. %s"
                            % ("; ".join(phep[(ma_nv, d)]), len(giu), mo_ta_quet(giu), CHO),
                            "%s có đơn nghỉ đã duyệt ngày %s nhưng vẫn có quẹt, nên chưa tính giờ. "
                            "Nên kiểm xem đơn nghỉ còn hiệu lực hay đã được thay đổi; nghỉ phép cần kiểm "
                            "với văn bản hiện hành hoặc chuyên gia nhân sự." % (ma_nv, iso))
                elif quet_ho:
                    dong["trang_thai"] = "CHO_XAC_NHAN"
                elif len(giu) == 1:
                    p, may, _ = giu[0]
                    dong["trang_thai"] = "CHO_XAC_NHAN"
                    if p <= bd + DON_LE_CAN:
                        dong["gio_vao"] = hm(p)
                        them_bt(ma_nv, iso, "THIEU_RA",
                                "chỉ có 1 quẹt lúc %s (%s), coi là quẹt vào của ca %s; thiếu quẹt ra. %s"
                                % (hm(p), may, loai_ngay, CHO),
                                "%s chỉ có một quẹt vào lúc %s ngày %s, không có quẹt ra. "
                                "Nên hỏi giờ ra thực tế hoặc đối chiếu nguồn khác trước khi tính công."
                                % (ma_nv, hm(p), iso))
                    elif p >= kt - DON_LE_CAN:
                        dong["gio_ra"] = hm(p)
                        them_bt(ma_nv, iso, "THIEU_VAO",
                                "chỉ có 1 quẹt lúc %s (%s), coi là quẹt ra của ca %s; thiếu quẹt vào. %s"
                                % (hm(p), may, loai_ngay, CHO),
                                "%s chỉ có một quẹt ra lúc %s ngày %s, không có quẹt vào. "
                                "Nên hỏi giờ vào thực tế hoặc đối chiếu nguồn khác trước khi tính công."
                                % (ma_nv, hm(p), iso))
                    else:
                        them_bt(ma_nv, iso, "THIEU_KHONG_RO",
                                "chỉ có 1 quẹt lúc %s (%s), không xác định là vào hay ra của ca %s. %s"
                                % (hm(p), may, loai_ngay, CHO),
                                "%s chỉ có một quẹt lúc %s ngày %s, không rõ là quẹt vào hay quẹt ra. "
                                "Cần hỏi nhân viên/quản lý để xác định giờ vào và giờ ra."
                                % (ma_nv, hm(p), iso))
                else:
                    vao, ra = giu[0][0], giu[-1][0]
                    tre = vao - bd
                    som = kt - ra
                    phut_tre = tre if tre > DUNG_SAI else 0
                    phut_som = som if som > DUNG_SAI else 0
                    ot = -som if -som >= OT_TOI_THIEU else 0
                    gc = tinh_gio_cong(loai_ngay, vao, ra)
                    dong.update({
                        "gio_vao": hm(vao), "gio_ra": hm(ra), "gio_cong": "%.2f" % (gc / 60.0),
                        "phut_tre": phut_tre, "phut_ve_som": phut_som, "ot_phut": ot,
                        "trang_thai": "OK"})
                    ot_thang[ma_nv] += ot
                    if ot:
                        ot_ngay_thang[ma_nv] += 1
                    if len(giu) > 2:
                        thong_ke_phu["ngay_nhieu_quet"] += 1
                    if phut_tre:
                        them_bt(ma_nv, iso, "DI_TRE", "vào %s, trễ %d phút (ca %s vào %s)"
                                % (hm(vao), phut_tre, loai_ngay, hm(bd)),
                                "%s vào trễ %d phút ngày %s, vượt dung sai %d phút. "
                                "Nên hỏi lý do/đối chiếu đơn từ nếu cần." % (ma_nv, phut_tre, iso, DUNG_SAI))
                    if phut_som:
                        them_bt(ma_nv, iso, "VE_SOM", "ra %s, về sớm %d phút (ca %s ra %s)"
                                % (hm(ra), phut_som, loai_ngay, hm(kt)),
                                "%s ra sớm %d phút ngày %s, vượt dung sai %d phút. "
                                "Nên hỏi lý do/đối chiếu đơn từ nếu cần." % (ma_nv, phut_som, iso, DUNG_SAI))
                    if ot > OT_NGAY_NGUONG:
                        them_bt(ma_nv, iso, "OT_VUOT_NGUONG",
                                "ra %s, làm thêm %d phút (%.2f giờ) > %d phút" % (hm(ra), ot, ot / 60.0, OT_NGAY_NGUONG),
                                "%s làm thêm %d phút ngày %s, vượt ngưỡng %d phút/ngày. Nên kiểm xem có "
                                "phê duyệt làm thêm giờ không; giờ làm thêm cần kiểm với văn bản hiện hành "
                                "hoặc chuyên gia nhân sự." % (ma_nv, ot, iso, OT_NGAY_NGUONG))
            if dong["trang_thai"] == "CHO_XAC_NHAN" and loai_ngay in ("HC", "S", "C"):
                cho_thang[ma_nv] += 1
            bang.append(dong)

    # OT tháng
    for ma_nv in sorted(nv):
        if ot_thang[ma_nv] > OT_THANG_NGUONG:
            them_bt(ma_nv, "THANG", "OT_THANG_VUOT",
                    "tổng làm thêm ngày làm việc thường %d phút (%.2f giờ) > %d phút, từ %d ngày có OT"
                    "; còn %d ngày làm việc chờ xác nhận chưa tính OT"
                    % (ot_thang[ma_nv], ot_thang[ma_nv] / 60.0, OT_THANG_NGUONG,
                       ot_ngay_thang[ma_nv], cho_thang[ma_nv]),
                    "%s có tổng giờ làm thêm tháng vượt ngưỡng %d phút. Nên kiểm danh sách ngày OT và "
                    "phê duyệt; giờ làm thêm cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
                    % (ma_nv, OT_THANG_NGUONG))

    # DU_LIEU_LOI
    for (ma_nv, ngay), ds in sorted(loi.items()):
        if ngay:
            gt = ("Có %d dòng quẹt của %s không dùng để tính (ngày %s). Nên đối chiếu với dữ liệu gốc của máy chấm công."
                  % (len(ds), ma_nv or "(trống)", ngay))
        else:
            gt = ("Có %d dòng quẹt của %s không xác định được ngày nên không dùng để tính. "
                  "Nên đối chiếu với dữ liệu gốc của máy chấm công và xem các ngày liên quan của mã này."
                  % (len(ds), ma_nv or "(trống)"))
        them_bt(ma_nv, ngay, "DU_LIEU_LOI", " | ".join(ds) + ". " + CHO, gt)

    def khoa_sap(r):
        return (r["ma_nv"], r["ngay"] == "" , r["ngay"] == "THANG", r["ngay"], r["loai"])
    bt.sort(key=khoa_sap)

    # ---------------------------------------------------------- tổng hợp theo người
    tong = []
    for ma_nv in sorted(nv):
        ds = [r for r in bang if r["ma_nv"] == ma_nv]
        ok = [r for r in ds if r["trang_thai"] == "OK"]
        ot_gio = sum(int(r["ot_phut"]) for r in ok) / 60.0
        tong.append({
            "ma_nv": ma_nv,
            "ngay_cong": len(ok),
            "tong_gio_cong": "%.2f" % sum(float(r["gio_cong"]) for r in ok),
            "so_lan_tre": sum(1 for r in ok if r["phut_tre"] > 0),
            "tong_phut_tre": sum(r["phut_tre"] for r in ok),
            "so_lan_ve_som": sum(1 for r in ok if r["phut_ve_som"] > 0),
            "tong_phut_ve_som": sum(r["phut_ve_som"] for r in ok),
            "tong_ot_gio": "%.2f" % ot_gio,
            "so_ngay_phep": sum(1 for r in ds if r["trang_thai"] == "PHEP"),
            "so_ngay_vang_chua_ghi": sum(1 for r in bt if r["ma_nv"] == ma_nv and r["loai"] == "VANG_CHUA_GHI"),
            "so_ngay_cho_xac_nhan": sum(1 for r in ds if r["trang_thai"] == "CHO_XAC_NHAN"),
            "so_bat_thuong": sum(1 for r in bt if r["ma_nv"] == ma_nv),
        })

    COT_BANG = ["ma_nv", "ngay", "loai_ngay", "gio_vao", "gio_ra", "gio_cong", "phut_tre",
                "phut_ve_som", "ot_phut", "trang_thai"]
    COT_BT = ["ma_nv", "ngay", "loai", "chi_tiet", "can_nguoi_quyet", "giai_thich"]
    COT_TONG = ["ma_nv", "ngay_cong", "tong_gio_cong", "so_lan_tre", "tong_phut_tre",
                "so_lan_ve_som", "tong_phut_ve_som", "tong_ot_gio", "so_ngay_phep",
                "so_ngay_vang_chua_ghi", "so_ngay_cho_xac_nhan", "so_bat_thuong"]
    ghi_csv("bang_cong_ngay.csv", COT_BANG, bang)
    ghi_csv("bat_thuong.csv", COT_BT, bt)
    ghi_csv("tong_hop_nguoi.csv", COT_TONG, tong)

    viet_bao_cao(bang, bt, tong, rows_goc, hop_le, thong_ke_phu, nv)

    # ---------------------------------------------------------- in tóm tắt
    print("Số dòng dữ liệu (không tính tiêu đề):")
    print("  bang_cong_ngay.csv : %d" % len(bang))
    print("  bat_thuong.csv     : %d" % len(bt))
    print("  tong_hop_nguoi.csv : %d" % len(tong))
    print("Số bất thường theo loại:")
    dem = Counter(r["loai"] for r in bt)
    for loai in ["THIEU_RA", "THIEU_VAO", "THIEU_KHONG_RO", "QUET_TRUNG", "DI_TRE", "VE_SOM",
                 "OT_VUOT_NGUONG", "OT_THANG_VUOT", "VANG_CHUA_GHI", "LAM_NGAY_LE",
                 "LAM_NGAY_NGHI", "NGHI_QUET_HO", "CO_PHEP_NHUNG_QUET", "DU_LIEU_LOI"]:
        print("  %-20s %d" % (loai, dem.get(loai, 0)))
    print("  %-20s %d" % ("TỔNG", len(bt)))
    print("Trạng thái ngày:", dict(Counter(r["trang_thai"] for r in bang)))


# ------------------------------------------------------------------ BÁO CÁO
def gom(bt, loai, dinh_dang_ngay=True):
    """Gom theo NV: 'NV-001 (09-03, 09-10)'."""
    theo = defaultdict(list)
    for r in bt:
        if r["loai"] == loai:
            theo[r["ma_nv"] or "(trống)"].append(r["ngay"][5:] if r["ngay"] not in ("", "THANG") else (r["ngay"] or "không rõ ngày"))
    return "; ".join("%s (%s)" % (k, ", ".join(v)) for k, v in sorted(theo.items()))


def viet_bao_cao(bang, bt, tong, rows_goc, hop_le, phu, nv):
    dem = Counter(r["loai"] for r in bt)
    tt = Counter(r["trang_thai"] for r in bang)
    so_quet_hl = sum(len(v) for v in hop_le.values())
    quet_khac_may = sum(1 for (ma_nv, _), v in hop_le.items() for p, m, _ in v
                        if (m == "MAY-A1") != (nv[ma_nv]["chi_nhanh"].strip() == "A"))
    tong_gio = sum(float(t["tong_gio_cong"]) for t in tong)
    tong_ot = sum(float(t["tong_ot_gio"]) for t in tong)
    dong = []
    w = dong.append
    w("# Báo cáo kiểm tra chấm công tháng 09/2026")
    w("")
    w("Do `tinh_cong.py` tạo; chỉ là bản chuẩn bị để quản lý xác nhận, không quyết định lương hay kỷ luật.")
    w("")
    w("## Số liệu tóm tắt")
    w("- %d nhân viên × 30 ngày = %d dòng công; %d dòng quẹt gốc, %d dòng dùng được."
      % (len(nv), len(bang), len(rows_goc), so_quet_hl))
    w("- Trạng thái ngày: OK %d, PHEP %d, NGHI %d, CHO_XAC_NHAN %d."
      % (tt["OK"], tt["PHEP"], tt["NGHI"], tt["CHO_XAC_NHAN"]))
    w("- Tổng giờ công (chỉ ngày OK): %.2f giờ; tổng làm thêm: %.2f giờ." % (tong_gio, tong_ot))
    w("- %d bất thường: " % len(bt) + ", ".join("%s %d" % (k, v) for k, v in sorted(dem.items(), key=lambda x: -x[1])) + ".")
    w("")
    w("## Việc quản lý cần xác nhận (can_nguoi_quyet = CO, theo loại; ngày dạng MM-DD)")
    for loai in ["THIEU_RA", "THIEU_VAO", "THIEU_KHONG_RO", "VANG_CHUA_GHI", "LAM_NGAY_LE",
                 "LAM_NGAY_NGHI", "NGHI_QUET_HO", "CO_PHEP_NHUNG_QUET", "OT_VUOT_NGUONG",
                 "OT_THANG_VUOT", "DU_LIEU_LOI"]:
        if dem.get(loai):
            w("- **%s (%d)**: %s" % (loai, dem[loai], gom(bt, loai)))
    w("")
    w("Chi tiết và câu hỏi gợi ý nằm trong `bat_thuong.csv`. Các mã không cần quyết (QUET_TRUNG %d, DI_TRE %d, VE_SOM %d) "
      "đã tính vào bảng công, xem trong cùng tệp." % (dem["QUET_TRUNG"], dem["DI_TRE"], dem["VE_SOM"]))
    w("")
    w("## Giả định đã dùng")
    w("- Ngày lễ 09-01 và 09-02 là LE với mọi người; đơn nghỉ phép chỉ có hiệu lực ở ngày làm việc (ngày OFF/LE trùng đơn ghi NGHI hoặc LAM_NGAY_*).")
    w("- Mọi đơn 'Đã duyệt' (kể cả 'Việc riêng không lương') ghi PHEP vì quy định không phân biệt loại đơn.")
    w("- Ngày VANG_CHUA_GHI và các ngày bất thường cần người quyết đều có trang_thai = CHO_XAC_NHAN; "
      "so_ngay_cho_xac_nhan đếm cả các ngày vắng chưa ghi (cột so_ngay_vang_chua_ghi là phần con của nó).")
    w("- Ngày CHO_XAC_NHAN: để trống phut_tre, phut_ve_som, ot_phut, gio_cong; gio_vao/gio_ra chỉ điền với THIEU_RA/THIEU_VAO. Không xét DI_TRE/VE_SOM/OT cho các ngày này.")
    w("- Quẹt trùng so với quẹt GIỮ LẠI gần nhất của cùng máy; so sánh theo phút sau khi bỏ giây. NGHI_QUET_HO xét trên các quẹt còn lại sau khi bỏ quẹt trùng.")
    w("- so_bat_thuong = số dòng của người đó trong bat_thuong.csv (tính cả QUET_TRUNG, DI_TRE, VE_SOM). OT tháng chỉ cộng ot_phut của các ngày OK.")
    w("")
    w("## Điều chưa chắc")
    w("- Cách ghi công, làm thêm cho ngày lễ/ngày nghỉ có quẹt, và cho ngày có đơn nghỉ mà vẫn quẹt: quy định chưa nói rõ, cần người quyết; "
      "giờ làm thêm, nghỉ lễ, nghỉ phép cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.")
    if quet_khac_may:
        w("- %d quẹt hợp lệ nằm ở máy của chi nhánh khác với chi nhánh ghi trong nhan_vien.csv. Quy định không coi đây là bất thường nên chỉ tính bình thường; "
          "nếu hai máy cùng ngày cách nhau <= 10 phút thì đã báo NGHI_QUET_HO (chỉ là dấu hiệu, cần người có thẩm quyền xác minh)." % quet_khac_may)
    if dem["DU_LIEU_LOI"]:
        w("- Dòng DU_LIEU_LOI không gán được ngày không ảnh hưởng ngày nào trong bảng công; cần đối chiếu dữ liệu gốc của máy.")
    if phu["ngay_nhieu_quet"]:
        w("- %d ngày OK có hơn hai quẹt: chỉ lấy quẹt đầu và cuối theo quy định (các quẹt giữa bị bỏ qua)." % phu["ngay_nhieu_quet"])
    with open(os.path.join(HERE, "bao_cao.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(dong) + "\n")


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass
    sys.exit(main())
