"""Kiểm nhanh kết quả của agent, KHÔNG cần đáp án và KHÔNG dùng script của agent.

Chạy:  python -X utf8 kiem_nhanh.py sao-ke-t10-2026.csv THU_MUC_DAU_RA
  sao-ke-...csv   sao kê gốc (định dạng như bài 1: dòng "Ngày GD" là tiêu đề cột, dòng "Tong phat sinh ..." ở cuối)
  THU_MUC_DAU_RA  thư mục có bang_ghep.csv và tong_kiem.json do agent tạo

Ba kiểm tra:
  1. Tự cộng từ sao kê gốc (số dòng, tổng có, tổng nợ, số dư cuối) rồi so với tong_kiem.json và dòng tổng của sao kê.
  2. bang_ghep.csv phải có đúng các số CT của sao kê (không thiếu, không thừa, không trùng) và cộng tiền từng chiều phải bằng sao kê.
  3. Một đơn không được nằm ở hai dòng loại khop_du (đơn đã trả đủ mà có dòng thứ hai thì phải là loại trung).
     Dòng ghi CAN NGUOI QUYET không tính (đơn trong dòng đó chỉ là ứng viên, chưa ghép).
Chỉ phát hiện lỗi cộng trừ và ghép trùng. Không biết ghép ĐÚNG hay SAI đơn: việc đó vẫn cần người xem mẫu dòng CAO.
Thoát mã 1 nếu có lỗi.
"""
import csv
import json
import re
import sys
from collections import defaultdict
from pathlib import Path


def so(s):
    s = re.sub(r"[^\d]", "", s or "")
    return int(s) if s else 0


def doc_sao_ke(p):
    rows = list(csv.reader(open(p, encoding="utf-8-sig", newline="")))
    h = next(i for i, r in enumerate(rows) if r and r[0].strip() == "Ngày GD")
    dau = next(so(r[1]) for r in rows[:h] if r and r[0].strip().lower() == "so du dau ky")
    gd, tong = [], {}
    for r in rows[h + 1:]:
        if not any(c.strip() for c in r):
            continue
        if re.match(r"\d\d/\d\d/\d{4}$", r[0].strip()):
            gd.append({"so_ct": r[1].strip(), "no": so(r[2]), "co": so(r[3]), "du": so(r[4])})
        elif len(r) >= 2:
            tong[r[0].strip().lower()] = so(r[1])
    return dau, gd, tong


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    dau, gd, tong = doc_sao_ke(sys.argv[1])
    d = Path(sys.argv[2])
    loi = []
    co, no = sum(g["co"] for g in gd), sum(g["no"] for g in gd)
    cuoi = dau + co - no
    print(f"Tự cộng từ sao kê: {len(gd)} dòng, tổng có {co:,}, tổng nợ {no:,}, số dư cuối {cuoi:,}")
    if (tong.get("tong phat sinh co"), tong.get("tong phat sinh no"), tong.get("so du cuoi ky")) != (co, no, cuoi):
        loi.append("tự cộng KHÁC dòng tổng ghi trên sao kê (file sao kê đọc sai?)")
    tk = json.loads((d / "tong_kiem.json").read_text(encoding="utf-8"))
    for k, v in (("so_dong", len(gd)), ("tong_ghi_co", co), ("tong_ghi_no", no), ("so_du_cuoi", cuoi)):
        if so(str(tk.get(k))) != v:
            loi.append(f"tong_kiem.json: {k} = {tk.get(k)}, tự cộng ra {v:,}")
    rows = list(csv.DictReader(open(d / "bang_ghep.csv", encoding="utf-8-sig", newline="")))
    ct_goc = {g["so_ct"]: g for g in gd}
    ct_bang = [r["so_ct"].strip() for r in rows]
    print(f"bang_ghep.csv: {len(rows)} dòng")
    thieu = sorted(set(ct_goc) - set(ct_bang))
    thua = sorted(set(ct_bang) - set(ct_goc))
    trung = sorted({c for c in ct_bang if ct_bang.count(c) > 1})
    if thieu:
        loi.append(f"bang_ghep.csv thiếu {len(thieu)} số CT: {', '.join(thieu[:5])}")
    if thua:
        loi.append(f"bang_ghep.csv có {len(thua)} số CT không có trên sao kê: {', '.join(thua[:5])}")
    if trung:
        loi.append(f"bang_ghep.csv có {len(trung)} số CT bị lặp: {', '.join(trung[:5])}")
    lech = [r["so_ct"] for r in rows if r["so_ct"] in ct_goc and so(r["so_tien"]) != (ct_goc[r["so_ct"]]["co"] or ct_goc[r["so_ct"]]["no"])]
    if lech:
        loi.append(f"{len(lech)} dòng lệch số tiền so với sao kê: {', '.join(lech[:5])}")
    b_co = sum(so(r["so_tien"]) for r in rows if r["chieu"].strip().lower() == "co")
    b_no = sum(so(r["so_tien"]) for r in rows if r["chieu"].strip().lower() == "no")
    print(f"  cộng lại: có {b_co:,}, nợ {b_no:,}")
    if (b_co, b_no) != (co, no):
        loi.append(f"bang_ghep.csv cộng ra có {b_co:,}, nợ {b_no:,}; sao kê là có {co:,}, nợ {no:,}")
    theo_don = defaultdict(list)
    for r in rows:
        if r["loai"].strip().lower() == "khop_du" and "CAN NGUOI QUYET" not in r["muc_chac_chan"].upper():
            for m in filter(None, (x.strip() for x in r["ma_don"].split(";"))):
                theo_don[m].append(r["so_ct"])
    nhieu = {m: c for m, c in theo_don.items() if len(c) > 1}
    print(f"  đơn nằm ở hơn một dòng khop_du: {len(nhieu)}")
    for m, c in sorted(nhieu.items()):
        loi.append(f"đơn {m} nằm ở {len(c)} dòng khop_du: {', '.join(c)}")
    print()
    for x in loi:
        print("LỖI:", x)
    print("KẾT QUẢ:", f"{len(loi)} vấn đề, dừng và xem lại" if loi else "ĐẠT (không có lỗi cộng trừ hay ghép trùng)")
    sys.exit(1 if loi else 0)


main()
