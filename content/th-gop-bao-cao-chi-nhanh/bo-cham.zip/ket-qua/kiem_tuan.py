"""Bài tập 3 (bài 4): chấm file ra/tong_hop_tuan.csv bằng đáp án, không dùng mắt.

Dùng:  python -X utf8 kiem_tuan.py <thư_mục_chứa_ra> <dap-an.json>
Ví dụ: python -X utf8 ket-qua\\kiem_tuan.py lan-chay-tuan ket-qua\\dap-an-T10.json

Quy ước tuần: tuần 1 = ngày 1-7, tuần 2 = 8-14, tuần 3 = 15-21, tuần 4 = 22-28, tuần 5 = 29 đến hết tháng.
Chỉ tính dòng bán hàng xác nhận (OK hoặc SUY_RA); dòng ngày mơ hồ, trùng, ngoài kỳ không tính.
Cột bắt buộc của tong_hop_tuan.csv: chi_nhanh, tuan, so_dong, doanh_thu.
Thoát mã 0 nếu đạt tất cả, mã 1 nếu có lỗi.
"""
import csv
import json
import sys
from pathlib import Path


def tuan_cua(ngay_iso):
    d = int(ngay_iso[8:10])
    return min((d - 1) // 7 + 1, 5)


def dap_an_tuan(truth):
    kq = {}
    for r in truth["rows"]:
        if r["status"] not in ("OK", "INFER"):
            continue
        k = (r["branch"], tuan_cua(r["date"]))
        n, s = kq.get(k, (0, 0))
        kq[k] = (n + 1, s + r["amount"])
    return kq


def so(v):
    try:
        return int(float(str(v).strip()))
    except ValueError:
        return None


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    thu_muc, dap_an = Path(sys.argv[1]), Path(sys.argv[2])
    truth = json.loads(dap_an.read_text(encoding="utf-8"))
    want = dap_an_tuan(truth)
    f = thu_muc / "ra" / "tong_hop_tuan.csv"
    if not f.exists():
        print(f"KHÔNG ĐẠT: không thấy {f}")
        sys.exit(1)
    with open(f, encoding="utf-8-sig", newline="") as fh:
        rd = csv.DictReader(fh)
        cols = rd.fieldnames or []
        rows = list(rd)
    loi = []
    thieu = [c for c in ("chi_nhanh", "tuan", "so_dong", "doanh_thu") if c not in cols]
    if thieu:
        print("KHÔNG ĐẠT: thiếu cột", ", ".join(thieu), "| cột đang có:", ", ".join(cols))
        sys.exit(1)
    got = {}
    for r in rows:
        k = (r["chi_nhanh"].strip().upper(), so(r["tuan"]))
        if k in got:
            loi.append(f"trùng dòng {k}")
        got[k] = (so(r["so_dong"]), so(r["doanh_thu"]))
    dung = sum(1 for k, v in want.items() if got.get(k) == v)
    for k, v in sorted(want.items()):
        if got.get(k) != v:
            loi.append(f"{k[0]} tuần {k[1]}: đáp án {v[0]} dòng / {v[1]:,} đ, file của bạn {got.get(k)}")
    thua = sorted(k for k in got if k not in want)
    for k in thua:
        loi.append(f"dòng thừa không có trong đáp án: {k}")
    tong_got = sum(v[1] for v in got.values() if v[1] is not None)
    tong_want = truth["tong_xac_nhan"]
    print(f"Cặp (chi nhánh, tuần) đúng: {dung}/{len(want)}; dòng thừa: {len(thua)}")
    print(f"Tổng doanh thu cộng các tuần: {tong_got:,} (đáp án {tong_want:,})")
    if tong_got != tong_want:
        loi.append("tổng các tuần khác tổng đáp án")
    for m in loi[:15]:
        print("  -", m)
    print("ĐẠT" if not loi else f"KHÔNG ĐẠT ({len(loi)} lỗi)")
    sys.exit(0 if not loi else 1)


if __name__ == "__main__":
    main()
