# Báo cáo kiểm tra chấm công 09/2026
_Do `tinh_cong.py` sinh từ dữ liệu. Quản lý xác nhận; chương trình không quyết lương hay kỷ luật._

## 1. Số liệu tóm tắt
- 25 nhân viên × 30 ngày = 750 dòng công: OK 501, PHEP 12, NGHI 207, CHO_XAC_NHAN 30. Giờ công (ngày OK) 3998.12 giờ; làm thêm 104.25 giờ.
- Đọc 1160 dòng quẹt: 3 dòng lỗi bị bỏ, 7 quẹt trùng bị bỏ.
- Bất thường 61 dòng: THIEU_RA 5; THIEU_VAO 3; THIEU_KHONG_RO 3; QUET_TRUNG 6; DI_TRE 12; VE_SOM 6; OT_VUOT_NGUONG 3; OT_THANG_VUOT 1; VANG_CHUA_GHI 6; LAM_NGAY_LE 3; LAM_NGAY_NGHI 4; NGHI_QUET_HO 4; CO_PHEP_NHUNG_QUET 2; DU_LIEU_LOI 3. Chỉ ghi nhận, không cần người quyết: QUET_TRUNG, DI_TRE, VE_SOM.

## 2. Việc quản lý cần xác nhận (chi tiết: bat_thuong.csv; ngày CHO_XAC_NHAN chưa tính giờ)
- **Thiếu quẹt (THIEU_RA / THIEU_VAO / THIEU_KHONG_RO)** (11): THIEU_RA: NV-011 14/09, NV-013 05/09, NV-025 28/09, NV-026 10/09, NV-026 25/09; THIEU_VAO: NV-011 24/09, NV-013 13/09, NV-021 10/09; THIEU_KHONG_RO: NV-013 06/09, NV-023 30/09, NV-025 11/09
- **Vắng chưa ghi (VANG_CHUA_GHI)** (6): NV-002 22/09, NV-003 28/09, NV-010 21/09, NV-023 11/09, NV-024 21/09, NV-026 24/09
- **Làm ngày lễ / ngày nghỉ (LAM_NGAY_LE, LAM_NGAY_NGHI)** (7): LAM_NGAY_LE: NV-007 01/09, NV-010 02/09, NV-018 02/09; LAM_NGAY_NGHI: NV-013 12/09, NV-014 24/09, NV-016 12/09, NV-022 27/09
- **Nghi quẹt hộ (NGHI_QUET_HO)** (4): NV-009 23/09, NV-015 20/09, NV-016 24/09, NV-022 24/09
- **Có phép nhưng có quẹt (CO_PHEP_NHUNG_QUET)** (2): NV-010 23/09, NV-023 23/09
- **Làm thêm vượt ngưỡng (OT_VUOT_NGUONG, OT_THANG_VUOT)** (4): OT_VUOT_NGUONG: NV-010 28/09, NV-013 26/09, NV-025 10/09; OT_THANG_VUOT: NV-001 THANG
- **Dữ liệu lỗi (DU_LIEU_LOI)** (3): NV-005 11/09, NV-007 không rõ ngày, NV-023 không rõ ngày
- Giờ làm thêm, ngày lễ, nghỉ phép: cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.

## 3. Giả định đã dùng (mục 5 quy định chưa viết chi tiết)
- Giờ công = thời gian nằm trong khung ca (sớm trước giờ vào hoặc muộn sau giờ ra không cộng); ca HC trừ phần giao với 12:00-13:00, ca S/C không trừ. Làm thêm ghi riêng (ot_phut), không cộng vào gio_cong.
- Trễ/sớm ≤ 5 phút: tính đủ, ghi 0. Từ 6 phút: ghi toàn bộ số phút lệch so với giờ ca, giờ công tính từ giờ quẹt thực.
- Từ 2 quẹt (sau khi bỏ trùng): quẹt đầu = vào, quẹt cuối = ra, quẹt giữa (gồm quẹt nghỉ trưa ca HC) bỏ qua. Quẹt trùng so với quẹt cùng máy đã giữ gần nhất, so theo phút.
- Ngày CHO_XAC_NHAN để trống giờ công, trễ, sớm, làm thêm; gio_vao/gio_ra chỉ điền khi xác định rõ. Ngày lễ ghi LE kể cả khi lịch xoay có ca. Ngày OFF/LE không quẹt = NGHI.
- Làm thêm tháng chỉ cộng ngày OK. Nghỉ không lương cũng ghi PHEP. so_ngay_phep chỉ đếm ngày làm việc (ngày OFF/LE trong kỳ nghỉ = NGHI).

## 4. Điều chưa chắc
- 6 quẹt ở máy khác chi nhánh (NV-015 20/09, NV-012 22/09, NV-009 23/09, NV-022 24/09, NV-016 24/09, NV-025 29/09). Quy định không coi là bất thường; chỉ cặp cách ≤ 10 phút bị gắn NGHI_QUET_HO.
- Ngày có quẹt giữa ca không phải quẹt trùng và không phải quẹt nghỉ trưa: NV-016 25/09. Đã bỏ qua khi tính giờ, quy định không có mã riêng nên không gắn cờ. CẦN NGƯỜI QUYẾT có xem lại không.
- Dòng DU_LIEU_LOI bị bỏ có thể thuộc ngày nào đó của nhân viên nêu trong dòng; chương trình không đoán. Cách tính ở mục 3 là diễn giải của tôi, CẦN NGƯỜI QUYẾT xác nhận.
- CSV là UTF-8 không BOM; mở bằng Excel cần chọn nhập UTF-8 để đúng tiếng Việt.
