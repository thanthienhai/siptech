# -*- coding: utf-8 -*-
"""Đếm ý kiến theo chủ đề x sắc thái và theo tuần. Chạy từ thư mục chứa danh-gia.csv:
    python dau-ra/tong-hop.py
Đọc: danh-gia.csv, dau-ra/y-kien.csv, dau-ra/loai-bo.csv. Ghi: dau-ra/xu-huong-tuan.csv.
Bài đã loại bỏ không được đếm."""
import csv
import datetime
import os
import sys
from collections import Counter

THU_MUC = os.path.dirname(os.path.abspath(__file__))
GOC = os.path.dirname(THU_MUC)
CHU_DE = ["gia", "phuc_vu", "chat_luong", "giao_hang", "khong_gian", "ve_sinh", "khac"]
SAC_THAI = ["tich_cuc", "tieu_cuc", "trung_tinh", "CAN_NGUOI_DOC"]


def doc_csv(duong_dan):
    with open(duong_dan, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def parse_ngay(s):
    s = s.strip()
    if "/" in s:  # DD/MM/YYYY (kiểu Việt Nam)
        d, m, y = s.split("/")
        return datetime.date(int(y), int(m), int(d))
    return datetime.date.fromisoformat(s)  # YYYY-MM-DD


def thu_hai(d):
    return d - datetime.timedelta(days=d.weekday())


def so_lieu_bo_sung(dem_ky, ngay):
    """Đếm số bài theo từ khóa trong trich_dan (chỉ ý kiến tieu_cuc của chủ đề tương ứng)."""
    import re
    moc = datetime.date(2026, 9, 28)

    def dem(chu_de, mau):
        ma = {r["ma"] for r in dem_ky if r["chu_de"] == chu_de and r["sac_thai"] == "tieu_cuc"
              and re.search(mau, r["trich_dan"], re.I)}
        return ma

    print()
    print("So lieu bo sung (so bai, dem theo tu khoa trong trich_dan, y kien tieu_cuc):")
    nhom = [
        ("giao_hang: do/tran ra tui", "giao_hang", "đổ|do ra"),
        ("giao_hang: nguoi/thieu mon", "giao_hang", "nguội|nguoi|thiếu|thieu"),
        ("giao_hang: cham/tre", "giao_hang", "chậm|cham|trễ|tiếng|tieng"),
        ("giao_hang: giao nham mon", "giao_hang", "nhầm"),
        ("giao_hang: shipper khong bat may", "giao_hang", "không bắt máy|khong bat may"),
        ("gia: tang/len gia", "gia", "tăng giá|lên giá|len gia|giá lên|tang khoang|tăng khoảng|lên mà"),
        ("gia: lên giá không báo trước", "gia", "không báo trước|khong bao truoc"),
        ("gia: dat hon quan ben canh", "gia", "đắt hơn|dat hon"),
        ("gia: ly van vay/ly nho", "gia", "ly vẫn vậy|ly thì nhỏ|nhỏ xíu|size"),
        ("ve_sinh: ban dinh nuoc cu", "ve_sinh", "dính nước|dinh nuoc"),
        ("ve_sinh: ly con dau son moi", "ve_sinh", "son môi|son moi"),
        ("ve_sinh: ruoi", "ve_sinh", "ruồi|ruoi"),
        ("ve_sinh: san tron/uot", "ve_sinh", "sàn trơn"),
        ("phuc_vu: cho lau", "phuc_vu", "chờ|đợi|cho gan|chậm|cham|Waited|mấy lần|2 lan"),
        ("phuc_vu: thieu nhan vien gio cao diem", "phuc_vu", "ít|it,"),
        ("phuc_vu: quen order/len mon sai", "phuc_vu", "quên|quen|món sai"),
    ]
    for ten, cd, mau in nhom:
        ma = dem(cd, mau)
        print("  %s: %d (truoc 28/09: %d, tu 28/09: %d)" % (
            ten, len(ma), sum(1 for m in ma if ngay[m] < moc), sum(1 for m in ma if ngay[m] >= moc)))
    gia_tc = {r["ma"] for r in dem_ky if r["chu_de"] == "gia" and r["sac_thai"] == "tieu_cuc"}
    print("  gia tieu_cuc (tong bai): %d (truoc 28/09: %d, tu 28/09: %d)" % (
        len(gia_tc), sum(1 for m in gia_tc if ngay[m] < moc), sum(1 for m in gia_tc if ngay[m] >= moc)))
    nc_path = os.path.join(THU_MUC, "nguy-cap.csv")
    if os.path.exists(nc_path):
        nc = doc_csv(nc_path)
        print("  nguy cap: %d dong; theo loai %s; trong do 'nghi': %d" % (
            len(nc), dict(Counter(r["loai"] for r in nc)), sum(1 for r in nc if r["ly_do"].startswith("nghi"))))
        print("  nguy cap ngo_doc theo ngay:", sorted((ngay[r["ma"]].isoformat(), r["ma"]) for r in nc if r["loai"] == "ngo_doc"))


def main():
    danh_gia = doc_csv(os.path.join(GOC, "danh-gia.csv"))
    y_kien = doc_csv(os.path.join(THU_MUC, "y-kien.csv"))
    loai_bo = doc_csv(os.path.join(THU_MUC, "loai-bo.csv"))

    ngay = {r["ma"]: parse_ngay(r["ngay"]) for r in danh_gia}
    ma_loai = {r["ma"] for r in loai_bo}
    ma_con_lai = set(ngay) - ma_loai

    # kiểm tra nhất quán đầu vào
    loi = False
    for r in y_kien:
        if r["ma"] not in ngay:
            print("LOI: y-kien.csv có mã không tồn tại:", r["ma"]); loi = True
        if r["chu_de"] not in CHU_DE or r["sac_thai"] not in SAC_THAI:
            print("LOI: nhãn không hợp lệ:", r); loi = True
    for m in ma_loai - set(ngay):
        print("LOI: loai-bo.csv có mã không tồn tại:", m); loi = True
    thieu = ma_con_lai - {r["ma"] for r in y_kien}
    if thieu:
        print("CANH BAO: bài còn lại nhưng chưa có ý kiến nào:", sorted(thieu))
    if loi:
        sys.exit(1)

    dem_ky = [r for r in y_kien if r["ma"] in ma_con_lai]  # bỏ ý kiến của bài đã loại
    bo_qua = len(y_kien) - len(dem_ky)
    if bo_qua:
        print("CANH BAO: bỏ qua %d ý kiến thuộc bài đã loại" % bo_qua)

    # xu hướng theo tuần
    theo_tuan = Counter()
    for r in dem_ky:
        theo_tuan[(thu_hai(ngay[r["ma"]]), r["chu_de"], r["sac_thai"])] += 1
    tuan_min = thu_hai(min(ngay[m] for m in ma_con_lai))
    tuan_max = thu_hai(max(ngay[m] for m in ma_con_lai))
    duong_ra = os.path.join(THU_MUC, "xu-huong-tuan.csv")
    with open(duong_ra, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["tuan", "chu_de", "tich_cuc", "tieu_cuc", "trung_tinh", "can_nguoi_doc"])
        t = tuan_min
        while t <= tuan_max:
            for cd in CHU_DE:
                w.writerow([t.isoformat(), cd] + [theo_tuan[(t, cd, st)] for st in SAC_THAI])
            t += datetime.timedelta(days=7)

    # in tổng hợp để dán vào báo cáo
    print("Tong so danh gia trong file:", len(danh_gia))
    print("So bai loai bo:", len(ma_loai), dict(Counter(r["ly_do"] for r in loai_bo)))
    print("So bai duoc phan tich:", len(ma_con_lai))
    print("So y kien:", len(dem_ky))
    print("So bai co it nhat 1 y kien CAN_NGUOI_DOC:",
          len({r["ma"] for r in dem_ky if r["sac_thai"] == "CAN_NGUOI_DOC"}))
    print("So y kien CAN_NGUOI_DOC:", sum(1 for r in dem_ky if r["sac_thai"] == "CAN_NGUOI_DOC"))
    print()
    tong = Counter((r["chu_de"], r["sac_thai"]) for r in dem_ky)
    print("chu_de | " + " | ".join(SAC_THAI) + " | tong")
    cot = Counter()
    for cd in CHU_DE:
        hang = [tong[(cd, st)] for st in SAC_THAI]
        for st, v in zip(SAC_THAI, hang):
            cot[st] += v
        print(cd + " | " + " | ".join(map(str, hang)) + " | " + str(sum(hang)))
    print("tong | " + " | ".join(str(cot[st]) for st in SAC_THAI) + " | " + str(sum(cot.values())))
    print()
    print("Theo tuan (tong ý kiến tieu_cuc / tich_cuc / so bai):")
    bai_tuan = Counter(thu_hai(ngay[m]) for m in ma_con_lai)
    t = tuan_min
    while t <= tuan_max:
        tc = sum(v for (tt, cd, st), v in theo_tuan.items() if tt == t and st == "tich_cuc")
        tn = sum(v for (tt, cd, st), v in theo_tuan.items() if tt == t and st == "tieu_cuc")
        print(t.isoformat(), "bai=%d" % bai_tuan[t], "tich_cuc=%d" % tc, "tieu_cuc=%d" % tn)
        t += datetime.timedelta(days=7)
    print()
    print("Theo tuan, tung chu de tieu_cuc:")
    print("tuan | " + " | ".join(CHU_DE))
    t = tuan_min
    while t <= tuan_max:
        print(t.isoformat() + " | " + " | ".join(str(theo_tuan[(t, cd, "tieu_cuc")]) for cd in CHU_DE))
        t += datetime.timedelta(days=7)
    so_lieu_bo_sung(dem_ky, ngay)
    print("Da ghi", duong_ra)


if __name__ == "__main__":
    main()
