import pandas as pd
import numpy as np
import math
import json

# 1. Load parameters
with open('tham-so.json', 'r', encoding='utf-8') as f:
    tham_so = json.load(f)

Z = tham_so.get('z_tuong_ung', 1.645)
NGAN_SACH = tham_so.get('ngan_sach_nhap_vnd', 30000000)
NGUONG_TON_LAU = tham_so.get('nguong_ton_lau_ngay', 120)
NGUONG_KHONG_BAN = tham_so.get('nguong_khong_ban_ngay', 90)
NGUONG_BAN_CHAM = tham_so.get('nguong_ban_cham_don_vi_thang', 3)
CUT_HANG_MIN_DAYS = tham_so.get('so_ngay_cut_hang_toi_thieu', 7)
NGAY_CUOI = pd.to_datetime(tham_so.get('ngay_cuoi_du_lieu', '2026-10-31'))

dm = pd.read_csv('danh-muc-hang.csv')
nk = pd.read_csv('nhat-ky-xuat-nhap.csv')
td = pd.read_csv('ton-dau-ky-2025-11-01.csv')
tk = pd.read_csv('ton-kiem-ke-2026-10-31.csv')
hve = pd.read_csv('hang-dang-ve.csv')

def parse_date(d_str):
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d/%m/%y'):
        try:
            return pd.to_datetime(d_str, format=fmt)
        except ValueError:
            pass
    return pd.to_datetime(d_str, dayfirst=True, errors='coerce')

nk['parsed_date'] = nk['ngay'].apply(parse_date)
nk['ma_hang_raw'] = nk['ma_hang']
nk['ma_hang_clean'] = nk['ma_hang'].str.strip().str.upper().str.replace('-', '')

name_to_sku = {
    'Nuoc mam chai 500ml': 'TH003',
    'Nuoc suoi chai 500ml': 'TH009',
    'Son duong moi thoi': 'MP006',
    'Khan giay hop': 'VT006'
}
for name, sku in name_to_sku.items():
    nk.loc[nk['ten_hang'] == name, 'ma_hang_clean'] = sku

# 2. Build loi-du-lieu.csv
errors = []

# Duplicates
dup_rows = nk[nk.duplicated(subset=['ma_phieu'], keep=False)]
dup_ids = dup_rows['ma_phieu'].unique()
for mid in dup_ids:
    sub = nk[nk['ma_phieu'] == mid]
    for idx in sub.index[1:]:
        r = sub.loc[idx]
        errors.append({
            'ma_phieu': mid,
            'loai_loi': 'trung_dong',
            'ma_hang': r['ma_hang_clean'],
            'xu_ly': 'BO',
            'ly_do': 'Trùng mã phiếu và nội dung với dòng trước, bỏ dòng lặp'
        })

nk_dedup = nk.drop_duplicates(subset=['ma_phieu'], keep='first').copy()

# Missing SKU
for name, sku in name_to_sku.items():
    sub = nk_dedup[(nk_dedup['ten_hang'] == name) & (nk_dedup['ma_hang_raw'].isna())]
    for _, r in sub.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'khac',
            'ma_hang': sku,
            'xu_ly': 'SUA',
            'ly_do': f"Thiếu mã hàng, tra cứu tên hàng '{name}' bổ sung mã {sku}"
        })

# Negative without note
neg_no_note = nk_dedup[(nk_dedup['so_luong'] < 0) & (nk_dedup['ghi_chu'].isna())]
for _, r in neg_no_note.iterrows():
    errors.append({
        'ma_phieu': r['ma_phieu'],
        'loai_loi': 'so_am_khong_ghi_chu',
        'ma_hang': r['ma_hang_clean'],
        'xu_ly': 'CAN_NGUOI_QUYET',
        'ly_do': 'Phiếu xuất số lượng âm không có ghi chú khách trả hàng'
    })

# Missing quantity
nan_qty = nk_dedup[nk_dedup['so_luong'].isna()]
for _, r in nan_qty.iterrows():
    errors.append({
        'ma_phieu': r['ma_phieu'],
        'loai_loi': 'thieu_so_luong',
        'ma_hang': r['ma_hang_clean'],
        'xu_ly': 'CAN_NGUOI_QUYET',
        'ly_do': 'Phiếu xuất thiếu số lượng, không tự ý điền số'
    })

# Abnormal quantity
abnormal = nk_dedup[nk_dedup['ma_phieu'].isin(['PX06046', 'PX07668'])]
for _, r in abnormal.iterrows():
    sl_val = r['so_luong']
    errors.append({
        'ma_phieu': r['ma_phieu'],
        'loai_loi': 'so_luong_bat_thuong',
        'ma_hang': r['ma_hang_clean'],
        'xu_ly': 'CAN_NGUOI_QUYET',
        'ly_do': f"Số lượng xuất đột biến ({sl_val}) không có ghi chú, nghi đơn sỉ bỏ sót ghi chú"
    })

# Wholesale orders
wholesale = nk_dedup[nk_dedup['ghi_chu'] == 'Khach si - DH dai ly']
for _, r in wholesale.iterrows():
    sl_val = r['so_luong']
    errors.append({
        'ma_phieu': r['ma_phieu'],
        'loai_loi': 'don_si_mot_lan',
        'ma_hang': r['ma_hang_clean'],
        'xu_ly': 'CAN_NGUOI_QUYET',
        'ly_do': f"Đơn sỉ đại lý một lần ({sl_val}), cần quyết định có loại khỏi nhu cầu bán lẻ để dự báo"
    })

# Future dates
future = nk_dedup[nk_dedup['parsed_date'] > NGAY_CUOI]
for _, r in future.iterrows():
    d_val = r['ngay']
    errors.append({
        'ma_phieu': r['ma_phieu'],
        'loai_loi': 'ngay_o_tuong_lai',
        'ma_hang': r['ma_hang_clean'],
        'xu_ly': 'CAN_NGUOI_QUYET',
        'ly_do': f"Ngày chứng từ ({d_val}) sau ngày kết thúc kỳ dữ liệu 2026-10-31"
    })

# Non-sales
non_sales = nk_dedup[nk_dedup['ghi_chu'].isin(['xuat dung tai quan', 'huy hang het han'])]
for _, r in non_sales.iterrows():
    gc_val = r['ghi_chu']
    errors.append({
        'ma_phieu': r['ma_phieu'],
        'loai_loi': 'khong_phai_ban_hang',
        'ma_hang': r['ma_hang_clean'],
        'xu_ly': 'BO',
        'ly_do': f"{gc_val}: loại khỏi nhu cầu bán lẻ, vẫn trừ vào tồn kho"
    })

df_errors = pd.DataFrame(errors)

# Filter dataset to period <= NGAY_CUOI
nk_period = nk_dedup[nk_dedup['parsed_date'] <= NGAY_CUOI].copy()

# List of uncertain vouchers to exclude from retail sales demand
uncertain_vouchers = set(neg_no_note['ma_phieu']).union(
    set(nan_qty['ma_phieu']),
    set(abnormal['ma_phieu']),
    set(wholesale['ma_phieu'])
)
non_sales_vouchers = set(non_sales['ma_phieu'])

# 3. Daily inventory simulation for running book inventory & cut-hang detection
# Dates: 2025-11-01 to 2026-10-31
all_dates = pd.date_range('2025-11-01', '2026-10-31')
all_months = sorted(list(set(d.strftime('%Y-%m') for d in all_dates)))

stockout_days_by_sku = {}
cut_months_by_sku = {}
ending_book_stock = {}

for sku in dm['ma_hang']:
    t0 = td[td['ma_hang'] == sku]['ton_dau_ky'].values[0]
    sku_tx = nk_period[nk_period['ma_hang_clean'] == sku]
    
    # We group transactions by date
    tx_by_date = sku_tx.groupby(sku_tx['parsed_date'].dt.date)
    curr_stock = t0
    
    sku_so_days = {m: 0 for m in all_months}
    
    for d in all_dates:
        d_date = d.date()
        m_str = d.strftime('%Y-%m')
        if d_date in tx_by_date.groups:
            group = tx_by_date.get_group(d_date)
            for _, r in group.iterrows():
                sl = r['so_luong']
                if pd.isna(sl):
                    continue
                if r['loai'] == 'NHAP':
                    curr_stock += sl
                elif r['loai'] == 'XUAT':
                    curr_stock -= sl
                elif r['loai'] == 'DIEU_CHINH':
                    curr_stock += sl # sl is negative
        if curr_stock <= 0:
            sku_so_days[m_str] += 1
            
    ending_book_stock[sku] = curr_stock
    stockout_days_by_sku[sku] = sku_so_days
    cut_months = [m for m in all_months if sku_so_days[m] >= CUT_HANG_MIN_DAYS]
    cut_months_by_sku[sku] = cut_months

# 4. Monthly Cleaned Demand & Raw Demand
# For each SKU and month:
# Cleaned demand:
# XUAT transactions in month:
# Exclude: non_sales_vouchers ('xuat dung tai quan', 'huy hang het han'), uncertain_vouchers
# If ghi_chu == 'khach tra' and so_luong < 0, it reduces demand (- so_luong which is negative, so sum of so_luong)
# Raw demand:
# Sum of all XUAT so_luong in month (raw, uncleaned)

# Also identify when a product started selling (for new products)
# MP010: from 2026-09
# MP014: from 2026-06
# MP015: from 2026-08
first_sale_month = {}
for sku in dm['ma_hang']:
    sku_xuat = nk_period[(nk_period['ma_hang_clean'] == sku) & (nk_period['loai'] == 'XUAT') & (nk_period['so_luong'] > 0)]
    if len(sku_xuat) > 0:
        first_sale_month[sku] = sku_xuat['parsed_date'].min().strftime('%Y-%m')
    else:
        first_sale_month[sku] = '2025-11'

print('First sale month for items starting after 2025-11:')
for sku, fsm in first_sale_month.items():
    if fsm > '2025-11':
        print(f'  {sku}: {fsm}')

cleaned_monthly_demand = {sku: {} for sku in dm['ma_hang']}
raw_monthly_demand = {sku: {} for sku in dm['ma_hang']}

nk_period['month_str'] = nk_period['parsed_date'].dt.strftime('%Y-%m')

for sku in dm['ma_hang']:
    sku_rows = nk_period[nk_period['ma_hang_clean'] == sku]
    for m in all_months:
        m_rows = sku_rows[sku_rows['month_str'] == m]
        
        # Raw demand
        m_xuat_raw = m_rows[m_rows['loai'] == 'XUAT']
        raw_val = m_xuat_raw['so_luong'].sum(skipna=True)
        raw_monthly_demand[sku][m] = float(raw_val)
        
        # Cleaned demand
        m_xuat_clean = m_xuat_raw[
            (~m_xuat_raw['ma_phieu'].isin(non_sales_vouchers)) & 
            (~m_xuat_raw['ma_phieu'].isin(uncertain_vouchers))
        ]
        clean_val = m_xuat_clean['so_luong'].sum(skipna=True)
        cleaned_monthly_demand[sku][m] = float(clean_val)

# Check 12-month total consumption value for ABC
annual_consumption_value = {}
for sku in dm['ma_hang']:
    cost = dm[dm['ma_hang'] == sku]['gia_von_hien_tai'].values[0]
    ann_qty = sum(cleaned_monthly_demand[sku].values())
    annual_consumption_value[sku] = ann_qty * cost

# Sort for ABC classification
sorted_skus_by_val = sorted(dm['ma_hang'], key=lambda s: annual_consumption_value[s], reverse=True)
total_ann_val = sum(annual_consumption_value.values())

abc_class = {}
cum_val = 0.0
for sku in sorted_skus_by_val:
    val = annual_consumption_value[sku]
    pct_before = (cum_val / total_ann_val) * 100
    if pct_before < 80.0:
        abc_class[sku] = 'A'
    elif pct_before < 95.0:
        abc_class[sku] = 'B'
    else:
        abc_class[sku] = 'C'
    cum_val += val

print('\nABC classification counts:')
print(pd.Series(abc_class).value_counts())

# 5. Forecasting helper function
def compute_forecast_for_target(sku, target_month):
    # Only consider months strictly before target_month
    prior_months = [m for m in all_months if m < target_month]
    
    # Valid months: on sale (>= first_sale_month) and not cut-hang
    fsm = first_sale_month[sku]
    cut_m = cut_months_by_sku[sku]
    
    valid_months = [m for m in prior_months if m >= fsm and m not in cut_m]
    
    # Check if there are at least 3 valid months
    flag_du_lieu_ngan = len(valid_months) < 3
    
    if len(valid_months) == 0:
        F = 0.0
        sigma = 0.0
    else:
        # 3 most recent valid months for F
        f_months = valid_months[-3:]
        f_values = [cleaned_monthly_demand[sku][m] for m in f_months]
        F = float(np.mean(f_values))
        
        # Up to 6 most recent valid months for sigma
        s_months = valid_months[-6:]
        s_values = [cleaned_monthly_demand[sku][m] for m in s_months]
        if len(s_values) < 3:
            sigma = 0.5 * F
        else:
            sigma = float(np.std(s_values, ddof=1))
            
    return F, sigma, valid_months, flag_du_lieu_ngan

# 6. Hold-out evaluation for 2026-09 and 2026-10
holdout_results = []
for m_target, prev_m in [('2026-09', '2026-08'), ('2026-10', '2026-09')]:
    for sku in dm['ma_hang']:
        thuc_te = cleaned_monthly_demand[sku][m_target]
        F, sigma, valid_m, is_short = compute_forecast_for_target(sku, m_target)
        moc_prev = raw_monthly_demand[sku][prev_m]
        
        # Condition to be evaluable:
        # "Đo trên các mã-tháng không bị cụt hàng và có ít nhất 3 tháng hợp lệ trước đó."
        is_cut = m_target in cut_months_by_sku[sku]
        has_min_3 = len(valid_m) >= 3
        tinh_duoc = 'CO' if (not is_cut and has_min_3) else 'KHONG'
        
        holdout_results.append({
            'ma_hang': sku,
            'thang': m_target,
            'thuc_te': thuc_te,
            'du_bao': round(F, 2),
            'moc_thang_truoc': moc_prev,
            'tinh_duoc': tinh_duoc,
            'F_raw': F
        })

df_holdout = pd.DataFrame(holdout_results)

# Calculate MAE and WAPE on tinh_duoc == 'CO'
eval_sub = df_holdout[df_holdout['tinh_duoc'] == 'CO'].copy()
print(f'\nHold-out evaluable rows: {len(eval_sub)} / {len(df_holdout)}')

mae_model = np.mean(np.abs(eval_sub['F_raw'] - eval_sub['thuc_te']))
wape_model = np.sum(np.abs(eval_sub['F_raw'] - eval_sub['thuc_te'])) / np.sum(eval_sub['thuc_te']) * 100

mae_naive = np.mean(np.abs(eval_sub['moc_thang_truoc'] - eval_sub['thuc_te']))
wape_naive = np.sum(np.abs(eval_sub['moc_thang_truoc'] - eval_sub['thuc_te'])) / np.sum(eval_sub['thuc_te']) * 100

print(f'Model Hold-out: MAE = {mae_model:.2f}, WAPE = {wape_model:.2f}%')
print(f'Naive Hold-out: MAE = {mae_naive:.2f}, WAPE = {wape_naive:.2f}%')

# 7. Main calculations for 2026-11
main_rows = []
hang_ve_dict = dict(zip(hve['ma_hang'], hve['so_luong']))
ton_kk_dict = dict(zip(tk['ma_hang'], tk['ton_thuc_te_kiem_ke']))

for sku in dm['ma_hang']:
    sku_info = dm[dm['ma_hang'] == sku].iloc[0]
    lead_time = sku_info['thoi_gian_giao_ngay']
    pack_size = sku_info['quy_cach_dat_boi_so']
    cost = sku_info['gia_von_hien_tai']
    status = sku_info['trang_thai']
    
    F, sigma, valid_m, is_short = compute_forecast_for_target(sku, '2026-11')
    
    # SS = Z * sigma * sqrt(T/30) rounded up
    ss_float = Z * sigma * math.sqrt(lead_time / 30.0)
    SS = int(math.ceil(ss_float))
    
    # ROP = F/30 * T + SS rounded up
    rop_float = (F / 30.0) * lead_time + SS
    ROP = int(math.ceil(rop_float))
    
    ton_kk = ton_kk_dict[sku]
    ton_ht = ending_book_stock[sku]
    chenh_kk = ton_ht - ton_kk # or ton_kk - ton_ht
    h_ve = hang_ve_dict.get(sku, 0)
    
    # Unconstrained needed quantity
    # max(0, F + SS - ton_kk - h_ve), round UP to pack_size
    raw_needed = max(0.0, F + SS - ton_kk - h_ve)
    if raw_needed > 0 and status != 'ngung_nhap':
        sl_can = int(math.ceil(raw_needed / pack_size) * pack_size)
    else:
        sl_can = 0
        
    # Days of supply: ton_kk / (F / 30)
    if F > 0:
        so_ngay_ton = round(ton_kk / (F / 30.0), 1)
    else:
        so_ngay_ton = 999.0
        
    # Check sales in last 90 days (2026-08-03 to 2026-10-31)
    sales_last_90 = nk_period[
        (nk_period['ma_hang_clean'] == sku) & 
        (nk_period['loai'] == 'XUAT') & 
        (nk_period['parsed_date'] >= (NGAY_CUOI - pd.Timedelta(days=90))) & 
        (nk_period['so_luong'] > 0)
    ]
    khong_ban_90_ngay = (len(sales_last_90) == 0) and (ton_kk > 0)
    
    # Warnings: priority order
    # HET_HANG > SAP_HET > TON_LAU > BAN_CHAM > OK
    if ton_kk == 0:
        canh_bao = 'HET_HANG'
    elif 0 < ton_kk <= ROP:
        canh_bao = 'SAP_HET'
    elif (so_ngay_ton > NGUONG_TON_LAU) or khong_ban_90_ngay:
        canh_bao = 'TON_LAU'
    elif F < NGUONG_BAN_CHAM:
        canh_bao = 'BAN_CHAM'
    else:
        canh_bao = 'OK'
        
    # Same period last year: 2025-11
    cung_ky_2025_11 = cleaned_monthly_demand[sku]['2025-11']
    
    cut_m_str = ';'.join(cut_months_by_sku[sku])
    
    main_rows.append({
        'ma_hang': sku,
        'lop_abc': abc_class[sku],
        'gia_tri_tieu_thu_nam': annual_consumption_value[sku],
        'so_thang_hop_le': len(valid_m),
        'thang_cut_hang': cut_m_str,
        'nhu_cau_du_bao_thang': round(F, 2),
        'do_lech_chuan': round(sigma, 2),
        'ton_an_toan': SS,
        'diem_dat_lai': ROP,
        'ton_kiem_ke': ton_kk,
        'ton_he_thong': ton_ht,
        'chenh_kiem_ke': chenh_kk,
        'hang_dang_ve': h_ve,
        'so_ngay_ton': so_ngay_ton,
        'cung_ky_nam_truoc_2025_11': cung_ky_2025_11,
        'canh_bao': canh_bao,
        'sl_can': sl_can,
        'don_gia_von': cost,
        'status': status,
        'pack_size': pack_size,
        'is_short': is_short
    })

df_main = pd.DataFrame(main_rows)
print('\nMain calculations overview:')
print(df_main[['ma_hang', 'lop_abc', 'nhu_cau_du_bao_thang', 'ton_an_toan', 'diem_dat_lai', 'ton_kiem_ke', 'hang_dang_ve', 'sl_can', 'canh_bao']].head(15))

# 8. Budget allocation
items_to_order = df_main[df_main['sl_can'] > 0].copy()
items_to_order['thanh_tien_raw'] = items_to_order['sl_can'] * items_to_order['don_gia_von']
total_needed_money = items_to_order['thanh_tien_raw'].sum()
print(f'\nTotal needed money before budget: {total_needed_money:,.0f} VND')
print(f'Budget: {NGAN_SACH:,.0f} VND')
print(f'Exceeds budget by: {total_needed_money - NGAN_SACH:,.0f} VND')
