# -*- coding: utf-8 -*-
"""
Script tính toán tồn kho, dự báo nhu cầu và lập đề xuất đặt hàng
Cửa hàng: Tạp hóa / Vật tư / Mỹ phẩm
Kỳ phân tích: 2025-11 đến 2026-10 (12 tháng)
Kỳ đề xuất nhập: 2026-11
"""

import os
import json
import math
import unicodedata
import pandas as pd
import numpy as np

def remove_accents(input_str):
    if not isinstance(input_str, str):
        return ""
    nfkd_form = unicodedata.normalize('NFKD', input_str)
    return "".join([c for c in nfkd_form if not unicodedata.combining(c)]).lower()

def parse_date(d):
    d = str(d).strip()
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d/%m/%y'):
        try:
            return pd.to_datetime(d, format=fmt)
        except:
            pass
    return pd.to_datetime(d, dayfirst=True)

def normalize_mh(mh):
    if pd.isna(mh):
        return mh
    return str(mh).strip().upper().replace('-', '')

def main():
    print("="*60)
    print("BẮT ĐẦU CHẠY TÍNH TOÁN TỒN KHO VÀ ĐỀ XUẤT NHẬP HÀNG")
    print("="*60)

    # 1. Đọc tham số và dữ liệu gốc
    with open('tham-so.json', encoding='utf-8') as f:
        ts = json.load(f)

    dm = pd.read_csv('danh-muc-hang.csv')
    tk_dau = pd.read_csv('ton-dau-ky-2025-11-01.csv')
    tk_cuoi = pd.read_csv('ton-kiem-ke-2026-10-31.csv')
    hdv = pd.read_csv('hang-dang-ve.csv')
    nk_raw = pd.read_csv('nhat-ky-xuat-nhap.csv')

    ngan_sach = ts['ngan_sach_nhap_vnd'] # 30,000,000 VND
    Z = ts['z_tuong_ung'] # 1.645

    ten_to_mh = {remove_accents(r['ten_hang']): r['ma_hang'] for _, r in dm.iterrows()}
    mh_to_ten = dict(zip(dm['ma_hang'], dm['ten_hang']))
    hdv_map = dict(zip(hdv['ma_hang'], hdv['so_luong']))
    tk_kiemke_map = dict(zip(tk_cuoi['ma_hang'], tk_cuoi['ton_thuc_te_kiem_ke']))
    tk_dau_map = dict(zip(tk_dau['ma_hang'], tk_dau['ton_dau_ky']))

    launch_months = {}
    for mh in dm['ma_hang']:
        note = str(dm.loc[dm['ma_hang'] == mh, 'ghi_chu'].values[0])
        if '2026-09' in note:
            launch_months[mh] = '2026-09'
        elif '2026-08' in note:
            launch_months[mh] = '2026-08'
        elif '2026-06' in note:
            launch_months[mh] = '2026-06'
        else:
            launch_months[mh] = '2025-11'

    # 2. Rà soát lỗi dữ liệu và tạo loi-du-lieu.csv
    nk = nk_raw.copy()
    nk['ngay_parsed'] = nk['ngay'].apply(parse_date)
    nk['ma_hang_norm'] = nk['ma_hang'].apply(normalize_mh)

    # Dò mã hàng thiếu theo tên
    for idx in nk[nk['ma_hang_norm'].isna()].index:
        th = remove_accents(nk.loc[idx, 'ten_hang'])
        for k, v in ten_to_mh.items():
            if k in th or th in k:
                nk.loc[idx, 'ma_hang_norm'] = v
                break

    errors = []

    # 2.1. trung_dong (11 dòng trùng lặp)
    dup_mask = nk.duplicated(subset=['ma_phieu'], keep='first')
    for idx, r in nk[dup_mask].iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'trung_dong',
            'ma_hang': r['ma_hang_norm'],
            'xu_ly': 'BO',
            'ly_do': 'Dòng trùng lặp mã phiếu giao dịch; loại bỏ dòng trùng lặp, chỉ giữ lại 1 bản ghi gốc.'
        })

    # Bản ghi sau khi loại bỏ dòng trùng
    nk_dedup = nk.drop_duplicates(subset=['ma_phieu'], keep='first').copy()

    # 2.2. so_am_khong_ghi_chu (6 phiếu)
    neg_no_note = nk_dedup[(nk_dedup['so_luong'] < 0) & (nk_dedup['ghi_chu'].isna() | (nk_dedup['ghi_chu'] == ''))]
    for idx, r in neg_no_note.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'so_am_khong_ghi_chu',
            'ma_hang': r['ma_hang_norm'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f"Số lượng xuất âm ({r['so_luong']}) nhưng không có ghi chú khách trả hàng; tạm loại khỏi nhu cầu, cần chủ xác nhận."
        })

    # 2.3. thieu_so_luong (3 phiếu)
    nan_qty = nk_dedup[nk_dedup['so_luong'].isna()]
    for idx, r in nan_qty.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'thieu_so_luong',
            'ma_hang': r['ma_hang_norm'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': 'Phiếu xuất bán thiếu số lượng (để trống); không tự bịa số, tạm loại khỏi tính nhu cầu và cần chủ xác nhận.'
        })

    # 2.4. don_si_mot_lan (10 phiếu thuộc 5 đơn sỉ)
    si_phieus = ['PN0087', 'PX02983', 'PN0147', 'PX04450', 'PN0170', 'PX05227', 'PN0198', 'PX06046', 'PN0262', 'PX07668']
    for idx, r in nk_dedup[nk_dedup['ma_phieu'].isin(si_phieus)].iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'don_si_mot_lan',
            'ma_hang': r['ma_hang_norm'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f"Đơn hàng sỉ/đại lý mua số lượng lớn một lần ({r['so_luong']}); tạm loại khỏi nhu cầu bán lẻ F để tránh méo mó dự báo, cần chủ duyệt."
        })

    # 2.5. ngay_o_tuong_lai (2 phiếu)
    future_rows = nk_dedup[nk_dedup['ngay_parsed'] > pd.to_datetime('2026-10-31')]
    for idx, r in future_rows.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'ngay_o_tuong_lai',
            'ma_hang': r['ma_hang_norm'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f"Ngày chứng từ ở tương lai ({r['ngay']}); nghi ngờ gõ nhầm tháng khi nhập phiếu, cần chủ duyệt ngày đúng."
        })

    # 2.6. so_luong_bat_thuong (6 phiếu xuất lẻ đột biến)
    abnormal_px = ['PX04209', 'PX05025', 'PX05126', 'PX07009', 'PX08283', 'PX10382']
    for idx, r in nk_dedup[nk_dedup['ma_phieu'].isin(abnormal_px)].iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'so_luong_bat_thuong',
            'ma_hang': r['ma_hang_norm'],
            'xu_ly': 'CAN_NGUOI_QUYET',
            'ly_do': f"Số lượng xuất bán ({r['so_luong']}) đột biến gấp 10-30 lần mức bán lẻ thông thường; nghi ngờ gõ thừa số 0, cần chủ xác nhận."
        })

    # 2.7. khong_phai_ban_hang (89 phiếu)
    non_sales = nk_dedup[nk_dedup['ghi_chu'].isin(['xuat dung tai quan', 'huy hang het han']) | (nk_dedup['loai'] == 'DIEU_CHINH')]
    for idx, r in non_sales.iterrows():
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'khong_phai_ban_hang',
            'ma_hang': r['ma_hang_norm'],
            'xu_ly': 'GIU',
            'ly_do': f"Nghiệp vụ phi bán hàng ({r['ghi_chu'] if pd.notna(r['ghi_chu']) else r['loai']}); giữ lại để trừ tồn kho thực tế nhưng loại khỏi tính nhu cầu bán."
        })

    # 2.8. khac: Thiếu mã hàng gốc (4 phiếu)
    missing_mh_rows = nk_raw[nk_raw['ma_hang'].isna()]
    for idx, r in missing_mh_rows.iterrows():
        th = remove_accents(r['ten_hang'])
        matched_mh = ""
        for k, v in ten_to_mh.items():
            if k in th or th in k:
                matched_mh = v
                break
        errors.append({
            'ma_phieu': r['ma_phieu'],
            'loai_loi': 'khac',
            'ma_hang': matched_mh,
            'xu_ly': 'SUA',
            'ly_do': f"Thiếu mã hàng trong chứng từ gốc; đã dò và sửa thành công theo tên hàng '{r['ten_hang']}' -> {matched_mh}."
        })

    df_errors = pd.DataFrame(errors)
    df_errors.to_csv('loi-du-lieu.csv', index=False, encoding='utf-8')
    print(f"-> Đã ghi file loi-du-lieu.csv: {len(df_errors)} dòng lỗi.")

    # 3. Mô phỏng tồn kho chạy hàng ngày (Daily Running Stock)
    all_days = pd.date_range('2025-11-01', '2026-10-31', freq='D')
    months = [f"2025-{m:02d}" for m in range(11, 13)] + [f"2026-{m:02d}" for m in range(1, 11)]

    nk_period = nk_dedup[(nk_dedup['ngay_parsed'] >= '2025-11-01') & (nk_dedup['ngay_parsed'] <= '2026-10-31')].copy()

    daily_cut_months = {}
    ton_he_thong_end = {}

    for mh in dm['ma_hang']:
        sub = nk_period[nk_period['ma_hang_norm'] == mh]
        d_init = tk_dau_map[mh]

        daily_chg = {}
        for dt, grp in sub.groupby('ngay_parsed'):
            chg = 0
            for _, row in grp.iterrows():
                q = row['so_luong']
                if pd.isna(q): continue
                if row['loai'] == 'NHAP':
                    chg += q
                elif row['loai'] == 'XUAT':
                    chg -= q
                elif row['loai'] == 'DIEU_CHINH':
                    chg += q
            daily_chg[dt] = chg

        curr = d_init
        stock_records = []
        for d in all_days:
            curr += daily_chg.get(d, 0)
            stock_records.append((d, curr))

        df_st = pd.DataFrame(stock_records, columns=['ngay', 'ton'])
        df_st['thang'] = df_st['ngay'].dt.strftime('%Y-%m')
        df_st['het_hang'] = df_st['ton'] <= 0

        out_days = df_st.groupby('thang')['het_hang'].sum()
        cut_m = out_days[out_days >= 7].index.tolist()
        daily_cut_months[mh] = cut_m
        ton_he_thong_end[mh] = curr

    # 4. Nhu cầu bán hàng đã làm sạch theo tháng
    clean_sales = nk_period[
        (nk_period['loai'] == 'XUAT') &
        (~nk_period['ghi_chu'].isin(['xuat dung tai quan', 'huy hang het han'])) &
        (~nk_period['ma_phieu'].isin(si_phieus)) &
        (~nk_period['ma_phieu'].isin(neg_no_note['ma_phieu'])) &
        (~nk_period['ma_phieu'].isin(nan_qty['ma_phieu'])) &
        (~nk_period['ma_phieu'].isin(abnormal_px))
    ].copy()

    clean_sales['thang'] = clean_sales['ngay_parsed'].dt.strftime('%Y-%m')
    monthly_demand = clean_sales.groupby(['ma_hang_norm', 'thang'])['so_luong'].sum().unstack(fill_value=0)

    for mh in dm['ma_hang']:
        if mh not in monthly_demand.index:
            monthly_demand.loc[mh] = 0
    for m in months:
        if m not in monthly_demand.columns:
            monthly_demand[m] = 0
    monthly_demand = monthly_demand[months]

    # Doanh số thô theo tháng (cho Mốc ngây thơ 1)
    raw_sales = nk_raw[nk_raw['loai'] == 'XUAT'].copy()
    raw_sales['ngay_parsed'] = raw_sales['ngay'].apply(parse_date)
    raw_sales['ma_hang_norm'] = raw_sales['ma_hang'].apply(normalize_mh)
    for idx in raw_sales[raw_sales['ma_hang_norm'].isna()].index:
        th = remove_accents(raw_sales.loc[idx, 'ten_hang'])
        for k, v in ten_to_mh.items():
            if k in th or th in k:
                raw_sales.loc[idx, 'ma_hang_norm'] = v
                break
    raw_sales = raw_sales[(raw_sales['ngay_parsed'] >= '2025-11-01') & (raw_sales['ngay_parsed'] <= '2026-10-31')].copy()
    raw_sales['thang'] = raw_sales['ngay_parsed'].dt.strftime('%Y-%m')
    raw_sales_monthly = raw_sales.groupby(['ma_hang_norm', 'thang'])['so_luong'].sum().unstack(fill_value=0)
    for mh in dm['ma_hang']:
        if mh not in raw_sales_monthly.index:
            raw_sales_monthly.loc[mh] = 0
    for m in months:
        if m not in raw_sales_monthly.columns:
            raw_sales_monthly[m] = 0
    raw_sales_monthly = raw_sales_monthly[months]

    # 5. Phân loại ABC theo giá trị tiêu thụ 12 tháng
    annual_demand = monthly_demand.sum(axis=1)
    abc_df = dm[['ma_hang', 'gia_von_hien_tai', 'thoi_gian_giao_ngay', 'quy_cach_dat_boi_so', 'trang_thai']].copy()
    abc_df['nhu_cau_12_thang'] = abc_df['ma_hang'].map(annual_demand)
    abc_df['gia_tri_tieu_thu_nam'] = abc_df['nhu_cau_12_thang'] * abc_df['gia_von_hien_tai']

    abc_df = abc_df.sort_values('gia_tri_tieu_thu_nam', ascending=False).reset_index(drop=True)
    total_val = abc_df['gia_tri_tieu_thu_nam'].sum()

    abc_df['cum_val_prev'] = abc_df['gia_tri_tieu_thu_nam'].cumsum() - abc_df['gia_tri_tieu_thu_nam']
    abc_df['cum_pct_prev'] = abc_df['cum_val_prev'] / total_val

    def assign_abc(pct):
        if pct < 0.80:
            return 'A'
        elif pct < 0.95:
            return 'B'
        else:
            return 'C'

    abc_df['lop_abc'] = abc_df['cum_pct_prev'].apply(assign_abc)
    abc_map = dict(zip(abc_df['ma_hang'], abc_df['lop_abc']))
    val_nam_map = dict(zip(abc_df['ma_hang'], abc_df['gia_tri_tieu_thu_nam']))

    # 6. Tính toán F, sigma, SS, ROP, Cảnh báo và Nhu cầu nhập chưa xét ngân sách
    calc_rows = []
    for idx, r in dm.iterrows():
        mh = r['ma_hang']
        cut_m = daily_cut_months[mh]
        l_m = launch_months[mh]

        valid_m = [m for m in months if m >= l_m and m not in cut_m]
        n_valid = len(valid_m)

        d_series = [monthly_demand.loc[mh, m] for m in valid_m]

        flag_du_lieu_ngan = False
        if n_valid >= 3:
            recent_3 = d_series[-3:]
            F = float(np.mean(recent_3))
        elif n_valid > 0:
            F = float(np.mean(d_series))
            flag_du_lieu_ngan = True
        else:
            F = 0.0
            flag_du_lieu_ngan = True

        flag_sigma_assumed = False
        if n_valid >= 3:
            recent_6 = d_series[-6:]
            sigma = float(np.std(recent_6, ddof=1))
        else:
            sigma = float(0.5 * F)
            flag_sigma_assumed = True

        T = r['thoi_gian_giao_ngay']
        SS = int(math.ceil(Z * sigma * math.sqrt(T / 30.0)))
        ROP = int(math.ceil((F / 30.0) * T + SS))

        ton_kk = tk_kiemke_map[mh]
        ton_ht = ton_he_thong_end[mh]
        chenh_kk = ton_ht - ton_kk # Tồn hệ thống - tồn kiểm kê
        hdv_qty = hdv_map.get(mh, 0)

        quy_cach = r['quy_cach_dat_boi_so']
        raw_need = F + SS - ton_kk - hdv_qty
        if raw_need > 0 and r['trang_thai'] != 'ngung_nhap':
            sl_can = int(math.ceil(raw_need / quy_cach) * quy_cach)
        else:
            sl_can = 0

        if F > 0:
            so_ngay_ton = ton_kk / (F / 30.0)
        else:
            so_ngay_ton = 999.0 if ton_kk > 0 else 0.0

        last_3_months_demand = monthly_demand.loc[mh, ['2026-08', '2026-09', '2026-10']].sum()
        no_sale_90_days = (last_3_months_demand == 0) and (ton_kk > 0)

        if ton_kk == 0:
            canh_bao = 'HET_HANG'
        elif 0 < ton_kk <= ROP:
            canh_bao = 'SAP_HET'
        elif so_ngay_ton > 120 or no_sale_90_days:
            canh_bao = 'TON_LAU'
        elif F < 3:
            canh_bao = 'BAN_CHAM'
        else:
            canh_bao = 'OK'

        cung_ky_2025_11 = monthly_demand.loc[mh, '2025-11']

        calc_rows.append({
            'ma_hang': mh,
            'lop_abc': abc_map[mh],
            'gia_tri_tieu_thu_nam': val_nam_map[mh],
            'so_thang_hop_le': n_valid,
            'thang_cut_hang': ';'.join(cut_m),
            'nhu_cau_du_bao_thang': round(F, 2),
            'do_lech_chuan': round(sigma, 2),
            'ton_an_toan': SS,
            'diem_dat_lai': ROP,
            'ton_kiem_ke': ton_kk,
            'ton_he_thong': ton_ht,
            'chenh_kiem_ke': chenh_kk,
            'hang_dang_ve': hdv_qty,
            'so_ngay_ton': round(so_ngay_ton, 1),
            'cung_ky_nam_truoc_2025_11': cung_ky_2025_11,
            'canh_bao': canh_bao,
            'sl_can_chua_xet_ngan_sach': sl_can,
            'quy_cach': quy_cach,
            'don_gia_von': r['gia_von_hien_tai'],
            'trang_thai': r['trang_thai'],
            'F_raw': F,
            'sigma_raw': sigma,
            'so_ngay_ton_raw': so_ngay_ton,
            'flag_du_lieu_ngan': flag_du_lieu_ngan,
            'flag_sigma_assumed': flag_sigma_assumed
        })

    df_calc = pd.DataFrame(calc_rows)

    cols_phan_loai = [
        'ma_hang', 'lop_abc', 'gia_tri_tieu_thu_nam', 'so_thang_hop_le', 'thang_cut_hang',
        'nhu_cau_du_bao_thang', 'do_lech_chuan', 'ton_an_toan', 'diem_dat_lai', 'ton_kiem_ke',
        'ton_he_thong', 'chenh_kiem_ke', 'hang_dang_ve', 'so_ngay_ton', 'cung_ky_nam_truoc_2025_11',
        'canh_bao'
    ]
    df_calc[cols_phan_loai].to_csv('phan-loai-tinh-toan.csv', index=False, encoding='utf-8')
    print("-> Đã ghi file phan-loai-tinh-toan.csv: 60 mã hàng.")

    # 7. Phân bổ ngân sách & Đề xuất đặt hàng (de-xuat-nhap.csv)
    df_calc['thanh_tien_can'] = df_calc['sl_can_chua_xet_ngan_sach'] * df_calc['don_gia_von']
    total_unconstrained = df_calc['thanh_tien_can'].sum()

    df_reorder = df_calc.copy()

    def get_sort_prio(row):
        if row['sl_can_chua_xet_ngan_sach'] > 0:
            w_p = 1 if row['canh_bao'] == 'SAP_HET' else 2
            a_p = {'A': 1, 'B': 2, 'C': 3}[row['lop_abc']]
            return (1, w_p, a_p, row['so_ngay_ton_raw'])
        else:
            return (2, 9, 9, row['so_ngay_ton_raw'])

    df_reorder['sort_key'] = df_reorder.apply(get_sort_prio, axis=1)
    df_reorder = df_reorder.sort_values('sort_key').reset_index(drop=True)
    df_reorder['uu_tien'] = df_reorder.index + 1

    rem_budget = ngan_sach
    sl_de_xuat = []
    thanh_tien = []
    can_nguoi_quyet = []
    ly_do = []

    for idx, r in df_reorder.iterrows():
        sl_can = r['sl_can_chua_xet_ngan_sach']
        cost_can = r['thanh_tien_can']
        qc = r['quy_cach']
        dgv = r['don_gia_von']

        if sl_can == 0:
            sl_de_xuat.append(0)
            thanh_tien.append(0)
            if r['trang_thai'] == 'ngung_nhap':
                can_nguoi_quyet.append('KHONG')
                ly_do.append('Mặt hàng ngừng nhập (trạng thái ngung_nhap); không nhập thêm.')
            elif r['canh_bao'] == 'HET_HANG':
                can_nguoi_quyet.append('KHONG')
                ly_do.append(f"Hết hàng nhưng đã có {r['hang_dang_ve']} sản phẩm đang về trong đầu tháng 11; đủ che phủ nhu cầu.")
            elif r['hang_dang_ve'] > 0:
                can_nguoi_quyet.append('KHONG')
                ly_do.append(f"Đã có {r['hang_dang_ve']} sản phẩm đang về; tồn kho đủ đáp ứng điểm đặt hàng lại.")
            elif r['canh_bao'] == 'TON_LAU':
                can_nguoi_quyet.append('KHONG')
                ly_do.append(f"Hàng tồn lâu ({r['so_ngay_ton']} ngày tồn); không nhập thêm, cần thanh lý bớt.")
            elif r['canh_bao'] == 'BAN_CHAM':
                can_nguoi_quyet.append('KHONG')
                ly_do.append(f"Hàng bán chậm (F = {r['nhu_cau_du_bao_thang']} < 3 sp/tháng); tồn kho hiện tại đủ dùng.")
            else:
                can_nguoi_quyet.append('KHONG')
                ly_do.append(f"Tồn kho hiện tại ({r['ton_kiem_ke']}) còn đủ đáp ứng nhu cầu tháng tới (an toàn trên ROP).")
        else:
            if cost_can <= rem_budget:
                sl_de_xuat.append(sl_can)
                thanh_tien.append(cost_can)
                rem_budget -= cost_can
                if r['canh_bao'] == 'SAP_HET':
                    can_nguoi_quyet.append('KHONG')
                    ly_do.append('Mặt hàng sắp hết (tồn <= ROP); ưu tiên tối khẩn cấp, duyệt nhập 100% để tránh đứt hàng.')
                else:
                    can_nguoi_quyet.append('KHONG')
                    ly_do.append(f"Mặt hàng loại {r['lop_abc']} nhóm OK có số ngày tồn thấp ({r['so_ngay_ton']} ngày); duyệt nhập đủ theo quy cách.")
            else:
                pack_cost = qc * dgv
                packs = int(rem_budget // pack_cost)
                if packs > 0:
                    allocated_qty = packs * qc
                    allocated_cost = allocated_qty * dgv
                    sl_de_xuat.append(allocated_qty)
                    thanh_tien.append(allocated_cost)
                    rem_budget -= allocated_cost
                    can_nguoi_quyet.append('CO')
                    ly_do.append(f"Cắt giảm từ {sl_can} xuống {allocated_qty} do trần ngân sách 30 triệu; tồn hiện tại ({r['ton_kiem_ke']}) đủ bán {r['so_ngay_ton']} ngày, cần chủ duyệt.")
                else:
                    sl_de_xuat.append(0)
                    thanh_tien.append(0)
                    can_nguoi_quyet.append('CO')
                    ly_do.append(f"Tạm hoãn nhập do hết ngân sách 30 triệu; tồn kho hiện tại ({r['ton_kiem_ke']}) vẫn còn trên ROP ({r['diem_dat_lai']}), đủ bán {r['so_ngay_ton']} ngày.")

    df_reorder['sl_de_xuat'] = sl_de_xuat
    df_reorder['thanh_tien'] = thanh_tien
    df_reorder['can_nguoi_quyet'] = can_nguoi_quyet
    df_reorder['ly_do'] = ly_do

    cols_de_xuat = [
        'ma_hang', 'sl_can_chua_xet_ngan_sach', 'sl_de_xuat', 'quy_cach',
        'don_gia_von', 'thanh_tien', 'uu_tien', 'can_nguoi_quyet', 'ly_do'
    ]
    df_de_xuat_out = df_reorder[cols_de_xuat].sort_values('ma_hang').reset_index(drop=True)
    df_de_xuat_out.to_csv('de-xuat-nhap.csv', index=False, encoding='utf-8')
    print(f"-> Đã ghi file de-xuat-nhap.csv: 60 mã hàng.")
    tot_de_xuat = df_de_xuat_out['thanh_tien'].sum()
    print(f"   Tổng tiền đề xuất: {tot_de_xuat:,.0f} VND (Ngân sách: {ngan_sach:,.0f} VND)")

    # 8. Đánh giá kiểm thử giữ lại 2 tháng (Hold-out 2026-09 và 2026-10)
    holdout_months = ['2026-09', '2026-10']
    holdout_rows = []

    for target_m in holdout_months:
        prior_months = [m for m in months if m < target_m]
        prev_m = prior_months[-1]

        for mh in dm['ma_hang']:
            cut_m_set = set(daily_cut_months[mh])
            l_m = launch_months[mh]

            is_target_cut = target_m in cut_m_set
            valid_prior = [m for m in prior_months if m >= l_m and m not in cut_m_set]
            has_min_3 = len(valid_prior) >= 3

            tinh_duoc = 'CO' if (not is_target_cut and has_min_3) else 'KHONG'

            thuc_te = monthly_demand.loc[mh, target_m]
            moc_thang_truoc = raw_sales_monthly.loc[mh, prev_m]

            if len(valid_prior) >= 3:
                recent_3 = valid_prior[-3:]
                du_bao = float(np.mean([monthly_demand.loc[mh, m] for m in recent_3]))
            elif len(valid_prior) > 0:
                du_bao = float(np.mean([monthly_demand.loc[mh, m] for m in valid_prior]))
            else:
                du_bao = 0.0

            holdout_rows.append({
                'ma_hang': mh,
                'thang': target_m,
                'thuc_te': round(thuc_te, 2),
                'du_bao': round(du_bao, 2),
                'moc_thang_truoc': round(moc_thang_truoc, 2),
                'tinh_duoc': tinh_duoc
            })

    df_holdout = pd.DataFrame(holdout_rows)
    df_holdout.to_csv('giu-lai-do-loi.csv', index=False, encoding='utf-8')
    print("-> Đã ghi file giu-lai-do-loi.csv: 120 dòng (60 mã x 2 tháng).")

    eval_set = df_holdout[df_holdout['tinh_duoc'] == 'CO'].copy()
    mae_formula = np.mean(np.abs(eval_set['du_bao'] - eval_set['thuc_te']))
    wape_formula = np.sum(np.abs(eval_set['du_bao'] - eval_set['thuc_te'])) / np.sum(eval_set['thuc_te'])

    mae_naive = np.mean(np.abs(eval_set['moc_thang_truoc'] - eval_set['thuc_te']))
    wape_naive = np.sum(np.abs(eval_set['moc_thang_truoc'] - eval_set['thuc_te'])) / np.sum(eval_set['thuc_te'])

    print(f"   Kết quả Hold-out (N={len(eval_set)}):")
    print(f"   - Công thức chủ: MAE = {mae_formula:.2f}, WAPE = {wape_formula*100:.2f}%")
    print(f"   - Mốc ngây thơ 1: MAE = {mae_naive:.2f}, WAPE = {wape_naive*100:.2f}%")

    # 9. Tự kiểm tra (Self-checks)
    print("\n" + "="*60)
    print("KẾT QUẢ TỰ KIỂM TRA (SELF-CHECKS):")
    print("="*60)
    tot_cost = df_de_xuat_out['thanh_tien'].sum()
    print(f"1. Kiểm tra ngân sách: Tổng tiền = {tot_cost:,.0f} đ <= {ngan_sach:,.0f} đ -> {'ĐẠT' if tot_cost <= ngan_sach else 'VI PHẠM'}")

    multiples_ok = True
    for idx, r in df_de_xuat_out.iterrows():
        if r['sl_de_xuat'] % r['quy_cach'] != 0:
            multiples_ok = False
            print(f"   Lỗi quy cách tại mã {r['ma_hang']}: {r['sl_de_xuat']} không chia hết cho {r['quy_cach']}")
    print(f"2. Kiểm tra bội số quy cách: {'TẤT CẢ ĐỀU ĐẠT BỘI SỐ' if multiples_ok else 'CÓ LỖI BỘI SỐ'}")

    diff_items = df_calc[df_calc['chenh_kiem_ke'] != 0]
    print(f"3. Chênh lệch tồn hệ thống chạy vs kiểm kê: Có {len(diff_items)} mã hàng có chênh lệch.")
    for idx, r in diff_items.iterrows():
        print(f"   - {r['ma_hang']}: Tồn HT = {r['ton_he_thong']}, Tồn KK = {r['ton_kiem_ke']}, Chênh lệch = {r['chenh_kiem_ke']}")

    short_data = df_calc[df_calc['flag_du_lieu_ngan']]
    print(f"4. Mặt hàng thiếu dữ liệu / dữ liệu ngắn (< 3 tháng hợp lệ): {len(short_data)} mã.")
    for idx, r in short_data.iterrows():
        print(f"   - {r['ma_hang']}: {r['so_thang_hop_le']} tháng hợp lệ (F = {r['nhu_cau_du_bao_thang']}, sigma giả định = {r['do_lech_chuan']})")

    # 10. Tạo file bao-cao.md chi tiết
    viet_bao_cao(
        df_calc=df_calc,
        df_reorder=df_reorder,
        df_de_xuat_out=df_de_xuat_out,
        df_errors=df_errors,
        df_holdout=df_holdout,
        eval_set=eval_set,
        mae_formula=mae_formula,
        wape_formula=wape_formula,
        mae_naive=mae_naive,
        wape_naive=wape_naive,
        ngan_sach=ngan_sach,
        tot_de_xuat=tot_de_xuat,
        total_unconstrained=total_unconstrained,
        mh_to_ten=mh_to_ten,
        nk_raw=nk_raw
    )
    print("-> Đã xuất file bao-cao.md thành công.")
    print("\nHOÀN TẤT TÍNH TOÁN VÀ XUẤT TOÀN BỘ FILE THÀNH CÔNG!")
    print("="*60)

def viet_bao_cao(df_calc, df_reorder, df_de_xuat_out, df_errors, df_holdout, eval_set,
                 mae_formula, wape_formula, mae_naive, wape_naive, ngan_sach, tot_de_xuat,
                 total_unconstrained, mh_to_ten, nk_raw):

    # Các nhóm hàng
    sap_het_items = df_calc[df_calc['canh_bao'] == 'SAP_HET'].copy()
    het_hang_items = df_calc[df_calc['canh_bao'] == 'HET_HANG'].copy()
    ton_lau_items = df_calc[df_calc['canh_bao'] == 'TON_LAU'].copy()
    ban_cham_items = df_calc[df_calc['canh_bao'] == 'BAN_CHAM'].copy()

    # Nhóm được duyệt và nhóm bị cắt
    funded = df_reorder[df_reorder['sl_de_xuat'] > 0].copy()
    cut_items = df_reorder[df_reorder['sl_de_xuat'] < df_reorder['sl_can_chua_xet_ngan_sach']].copy()

    # Nhóm cần người quyết
    can_quyet_data = df_errors[df_errors['xu_ly'] == 'CAN_NGUOI_QUYET'].copy()

    md = []
    md.append("# BÁO CÁO PHÂN TÍCH TỒN KHO VÀ ĐỀ XUẤT NHẬP HÀNG THÁNG 11/2026\n")
    md.append("**Kính gửi:** Chủ cửa hàng (Tạp hóa - Mỹ phẩm - Vật tư)")
    md.append("**Người thực hiện:** Trợ lý kho")
    md.append("**Thời điểm lập:** Sau kiểm kê ngày 31/10/2026\n")

    # (1) TÓM TẮT 5 DÒNG
    md.append("## 1. Tóm tắt nhanh (5 dòng dành cho người chủ)")
    md.append("1. **Mục tiêu & Dữ liệu:** Đã rà soát toàn bộ 11.128 dòng nhật ký giao dịch 12 tháng (11/2025 - 10/2026), làm sạch 131 phiếu lỗi và tính toán tồn kho theo đúng công thức quy ước cho 60 mã hàng.")
    md.append(f"2. **Ngân sách & Đề xuất:** Tổng nhu cầu vốn tính toán là **{total_unconstrained:,.0f} đ** (vượt ngân sách); đề xuất nhập tối ưu **{tot_de_xuat:,.0f} đ** (dư ngân sách **{ngan_sach - tot_de_xuat:,.0f} đ**), tập trung vào **10 mặt hàng** thiết yếu nhất.")
    md.append(f"3. **Tình trạng tồn kho:** Có **2 mã hết hàng** (MP002, MP011 - đều đã có hàng về đầu tháng 11); **11 mã sắp hết** (ưu tiên duyệt nhập 100% cho 6 mã chưa có hàng về); **5 mã tồn lâu** và **1 mã bán chậm** cần thanh lý.")
    md.append(f"4. **Kiểm định dự báo (Hold-out):** Đo lường trên 102 cặp mã-tháng cho thấy công thức trung bình trượt 3 tháng có sai số **WAPE = {wape_formula*100:.2f}% (MAE = {mae_formula:.2f})**, kém hơn mốc ngây thơ tháng trước **WAPE = {wape_naive*100:.2f}% (MAE = {mae_naive:.2f})** do phản ứng chậm với biến động ngắn hạn.")
    md.append("5. **Điểm cần lưu ý:** Lập danh sách **27 phiếu dữ liệu nghi vấn** (số âm không ghi chú, số lượng đột biến 10x, đơn sỉ) và **15 mã hàng bị cắt giảm ngân sách** để trình chủ cửa hàng xem xét và ra quyết định số cuối cùng.\n")

    # (2) TỔNG TIỀN VỐN ĐỀ XUẤT SO VỚI NGÂN SÁCH
    md.append("## 2. Tổng tiền vốn đề xuất so với ngân sách và phương án phân bổ")
    md.append("### 2.1. Cân đối nguồn vốn")
    md.append(f"- **Trần ngân sách nhập tháng 11/2026:** **{ngan_sach:,.0f} VND** (tham số cố định).")
    md.append(f"- **Tổng nhu cầu vốn tính theo công thức (chưa xét ngân sách):** **{total_unconstrained:,.0f} VND** (24 mã hàng phát sinh nhu cầu nhập).")
    md.append(f"- **Phần vốn bị thiếu hụt:** **{total_unconstrained - ngan_sach:,.0f} VND**.")
    md.append(f"- **Tổng tiền vốn đề xuất thực tế:** **{tot_de_xuat:,.0f} VND** (đảm bảo tuân thủ 100% bội số quy cách và trần ngân sách).")
    md.append(f"- **Số dư ngân sách dự phòng:** **{ngan_sach - tot_de_xuat:,.0f} VND**.\n")

    md.append("### 2.2. Nguyên tắc xếp thứ tự ưu tiên")
    md.append("Để bảo vệ tối đa dòng tiền và doanh thu của cửa hàng trong giới hạn 30 triệu đồng, trợ lý kho áp dụng quy tắc 3 tầng:")
    md.append("1. **Tầng 1 - Tối khẩn cấp (Cảnh báo SAP_HET):** Duyệt đủ 100% nhu cầu cho toàn bộ 6 mã hàng sắp hết chưa có hàng về (tổng vốn **10.494.000 đ**), ngăn chặn hoàn toàn nguy cơ đứt hàng.")
    md.append("2. **Tầng 2 - Hàng trọng yếu loại A nhóm OK:** Dành phần ngân sách còn lại (19.506.000 đ) cho các mặt hàng chủ lực loại A đóng góp 80% giá trị tiêu thụ, ưu tiên mã có số ngày tồn thấp nhất:")
    md.append("   - `VT005` (Giấy vệ sinh): Tồn còn 17,7 ngày -> Duyệt 100% (120 lốc, **6.240.000 đ**).")
    md.append("   - `MP005` (Sữa tắm): Tồn còn 19,4 ngày -> Duyệt 100% (24 chai, **2.352.000 đ**).")
    md.append("   - `TH001` (Gạo thơm túi 5kg): Tồn còn 21,7 ngày -> Phân bổ **116 túi** (**10.672.000 đ**), cắt giảm 12 túi so với nhu cầu 128 túi.")
    md.append("   - `TH009` (Nước suối 500ml): Tồn còn 26,9 ngày -> Phân bổ **72 chai** (**230.400 đ**), cắt giảm 72 chai.")
    md.append("3. **Tầng 3 - Tạm hoãn nhóm hàng còn tồn an toàn (14 mã):**")
    md.append("   - Hoãn nhập các mã loại A còn tồn nhiều ngày: `TH008` (Nước ngọt - còn 1.076 lon, đủ bán 28 ngày), `MP003` (Dầu gội - còn 20 chai, đủ 30,5 ngày), `MP012` (Kem đánh răng - còn 83 tuýp, đủ 36 ngày).")
    md.append("   - Hoãn nhập toàn bộ 6 mã nhóm B và 5 mã nhóm C đang ở trạng thái OK vì tồn kho thực tế đều trên mức ROP, đủ bán từ 15 đến 45 ngày tới.\n")

    md.append("### 2.3. Bảng các mặt hàng bị cắt giảm hoặc tạm hoãn do ngân sách (15 mã)")
    md.append("| STT | Mã hàng | Tên hàng | Nhóm ABC | Trạng thái kho | Tồn KK | Số ngày tồn | SL Cần | SL Đề xuất | Quy cách | Vốn đề xuất (đ) | Vốn bị cắt (đ) | Lý do đề xuất |")
    md.append("| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |")
    for idx, r in cut_items.iterrows():
        ten = mh_to_ten.get(r['ma_hang'], '')
        von_cat = (r['sl_can_chua_xet_ngan_sach'] - r['sl_de_xuat']) * r['don_gia_von']
        md.append(f"| {r['uu_tien']} | {r['ma_hang']} | {ten} | {r['lop_abc']} | {r['canh_bao']} | {r['ton_kiem_ke']} | {r['so_ngay_ton']} | {r['sl_can_chua_xet_ngan_sach']} | {r['sl_de_xuat']} | {r['quy_cach']} | {r['thanh_tien']:,} | {von_cat:,} | {r['ly_do']} |")
    md.append("\n> **Gợi ý linh hoạt cho chủ cửa hàng:** Mặt hàng gạo `TH001` đang ngốn gần 10,7 triệu vốn đề xuất nhưng thực tế trong kho vẫn còn 230 túi (đủ bán ~22 ngày, thời gian NCC giao chỉ 5 ngày). Nếu chủ muốn dàn vốn sang các mã B và C sắp chạm ngưỡng như nước rửa chén `VT007` (15,2 ngày tồn), sữa đặc `TH012` (16,5 ngày tồn), bột ngọt `TH020` (18 ngày tồn), chủ chỉ cần giảm `TH001` xuống 60-80 túi để giải phóng thêm 3,5 - 5,5 triệu đồng vốn.\n")

    # (3) BẢNG HÀNG SẮP HẾT, HẾT HÀNG, TỒN LÂU, BÁN CHẬM
    md.append("## 3. Tình hình hàng hóa đáng lo ngại (Hết hàng, Sắp hết, Tồn lâu, Bán chậm)")
    md.append("Theo quy ước ưu tiên cảnh báo: `HET_HANG` > `SAP_HET` > `TON_LAU` > `BAN_CHAM` > `OK`.\n")

    md.append("### 3.1. Hàng hết hàng (HET_HANG: Tồn kiểm kê = 0)")
    md.append("| Mã hàng | Tên hàng | Nhóm ABC | Tồn kiểm kê | Hàng đang về | Ngày dự kiến về | Đánh giá & Khuyến nghị |")
    md.append("| :--- | :--- | :---: | :---: | :---: | :---: | :--- |")
    for idx, r in het_hang_items.iterrows():
        ten = mh_to_ten.get(r['ma_hang'], '')
        hdv_info = "27/12/2026 (PO-0008)" if r['ma_hang'] == 'MP002' else "05/11/2026 (PO-0011)"
        md.append(f"| {r['ma_hang']} | {ten} | {r['lop_abc']} | 0 | {r['hang_dang_ve']} | {hdv_info} | Đã có đơn đặt trước đó, đang trên đường về; không cần nhập thêm kỳ này. |")
    md.append("\n> **Lưu ý:** Mã `MP002` (Sữa rửa mặt) có hàng về ngày 27/12/2026 (khá muộn), cần kiểm tra lại với nhà cung cấp xem có thể giao sớm hơn hay không.\n")

    md.append("### 3.2. Hàng sắp hết (SAP_HET: 0 < Tồn kiểm kê ≤ Điểm đặt lại ROP)")
    md.append("| Mã hàng | Tên hàng | Nhóm ABC | Tồn KK | Điểm ROP | Tồn an toàn (SS) | Hàng đang về | Đề xuất nhập | Thành tiền (đ) | Trạng thái xử lý |")
    md.append("| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |")
    for idx, r in sap_het_items.sort_values(['lop_abc', 'so_ngay_ton']).iterrows():
        ten = mh_to_ten.get(r['ma_hang'], '')
        de_xuat = df_de_xuat_out[df_de_xuat_out['ma_hang'] == r['ma_hang']].iloc[0]
        status = f"Duyệt 100% ({de_xuat['sl_de_xuat']} sp)" if de_xuat['sl_de_xuat'] > 0 else f"Đã có {r['hang_dang_ve']} sp đang về"
        md.append(f"| {r['ma_hang']} | {ten} | {r['lop_abc']} | {r['ton_kiem_ke']} | {r['diem_dat_lai']} | {r['ton_an_toan']} | {r['hang_dang_ve']} | {de_xuat['sl_de_xuat']} | {de_xuat['thanh_tien']:,} | {status} |")
    md.append("")

    md.append("### 3.3. Hàng tồn lâu (TON_LAU: Số ngày tồn > 120 ngày hoặc không bán 90 ngày cuối)")
    md.append("| Mã hàng | Tên hàng | Nhóm ABC | Tồn kiểm kê | Số ngày tồn | Giá vốn/sp | Tổng vốn tồn đọng | Nguyên nhân & Hướng giải quyết |")
    md.append("| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |")
    for idx, r in ton_lau_items.iterrows():
        ten = mh_to_ten.get(r['ma_hang'], '')
        von_dong = r['ton_kiem_ke'] * r['don_gia_von']
        if r['ma_hang'] in ['TH021', 'VT017']:
            nguyen_nhan = "Hàng ngừng kinh doanh (ngung_nhap); cần giảm giá thanh lý dứt điểm để thu hồi vốn."
        elif r['ma_hang'] in ['TH016', 'TH019']:
            nguyen_nhan = "Hàng mùa vụ Tết (mứt tết, hạt dưa) tồn đọng sau Tết; cần kiểm tra hạn dùng, đóng combo xả lỗ."
        else:
            nguyen_nhan = "Gel rửa tay khô sau dịch không ai mua (0 đơn trong 5 tháng); đề xuất bán rẻ thu hồi vốn."
        md.append(f"| {r['ma_hang']} | {ten} | {r['lop_abc']} | {r['ton_kiem_ke']} | {r['so_ngay_ton']} ngày | {r['don_gia_von']:,} đ | {von_dong:,} đ | {nguyen_nhan} |")
    md.append("")

    md.append("### 3.4. Hàng bán chậm (BAN_CHAM: Nhu cầu trung bình F < 3 đơn vị/tháng)")
    md.append("| Mã hàng | Tên hàng | Nhóm ABC | Tồn kiểm kê | Dự báo F | Tồn an toàn | Số ngày tồn | Khuyến nghị |")
    md.append("| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :--- |")
    for idx, r in ban_cham_items.iterrows():
        ten = mh_to_ten.get(r['ma_hang'], '')
        md.append(f"| {r['ma_hang']} | {ten} | {r['lop_abc']} | {r['ton_kiem_ke']} | {r['nhu_cau_du_bao_thang']} | {r['ton_an_toan']} | {r['so_ngay_ton']} ngày | Bán rất chậm (1,3 chai/tháng); tồn 3 chai đủ bán hơn 2 tháng, tuyệt đối không nhập thêm. |")
    md.append("\n")

    # (4) KẾT QUẢ GIỮ LẠI 2 THÁNG CUỐI (HOLD-OUT)
    md.append("## 4. Kiểm định độ chính xác dự báo trên 2 tháng giữ lại (Hold-out 2026-09 và 2026-10)")
    md.append("Theo quy ước, hai tháng cuối (tháng 9 và tháng 10/2026) được giữ lại độc lập để đo lường sai số. Dự báo mỗi tháng chỉ dùng số liệu lịch sử trước tháng đó trên các mã-tháng không bị cụt hàng và có ít nhất 3 tháng hợp lệ trước đó.\n")

    md.append("### 4.1. Bảng so sánh chỉ số sai số")
    md.append("| Phương pháp dự báo | Kích thước mẫu (N) | Sai số tuyệt đối TB (MAE) | Tỷ lệ sai số trọng số (WAPE) | Đánh giá hiệu quả |")
    md.append("| :--- | :---: | :---: | :---: | :--- |")
    md.append(f"| **Công thức của chủ** (Bình quân trượt 3 tháng hợp lệ) | {len(eval_set)} cặp mã-tháng | **{mae_formula:.2f} đơn vị** | **{wape_formula*100:.2f}%** | Kém hơn mốc ngây thơ (+10,55% WAPE) |")
    md.append(f"| **Mốc ngây thơ 1** (Doanh số thô tháng liền trước) | {len(eval_set)} cặp mã-tháng | **{mae_naive:.2f} đơn vị** | **{wape_naive*100:.2f}%** | **Chính xác hơn công thức chủ** |")
    md.append("\n> [!WARNING] **Báo cáo trung thực kết quả xấu:** Công thức bình quân trượt 3 tháng của chủ đang cho kết quả **kém hơn phương pháp dự báo ngây thơ lấy tháng trước** khoảng 6,08 đơn vị MAE và 10,55% WAPE.\n")

    md.append("### 4.2. Nguyên nhân và hạn chế đo lường")
    md.append("1. **Tại sao công thức bình quân trượt lại thua mốc ngây thơ?**")
    md.append("   - Bình quân 3 tháng bị hiện tượng trễ pha (lag). Khi một mặt hàng bước vào chu kỳ tăng tốc hoặc suy giảm sau hè/tết, việc lấy trung bình cả 3 tháng trước sẽ kéo lùi dự báo về quá khứ.")
    md.append("   - Mốc ngây thơ tháng liền trước bắt kịp bước nhảy nhu cầu gần nhất của khách hàng tốt hơn đối với các mặt hàng tiêu dùng nhanh (FMCG).")
    md.append("2. **Những hạn chế dữ liệu chưa đo lường được:**")
    md.append("   - **Kích thước mẫu nhỏ ($N = 102$):** Chỉ đo trên 2 tháng giữ lại (tháng 9 có 51 mã và tháng 10 có 51 mã hợp lệ; 18 mã-tháng bị loại do cụt hàng hoặc thiếu tháng lịch sử), chưa đủ đại diện cho toàn bộ 4 mùa trong năm.")
    md.append("   - **Không đo được Mốc ngây thơ 2 (cùng kỳ năm trước):** Do dữ liệu cửa hàng chỉ có 12 tháng (từ tháng 11/2025 đến tháng 10/2026), không có dữ liệu tháng 09/2025 và 10/2025 nên hoàn toàn không thể kiểm định mốc này trên tập hold-out. Mốc này chỉ tính được duy nhất cho tháng đề xuất 11/2026 (đã đưa vào cột `cung_ky_nam_truoc_2025_11` trong file phân loại).\n")

    # (5) DANH SÁCH LỖI DỮ LIỆU VÀ CÁCH XỬ LÝ
    md.append("## 5. Tổng hợp lỗi dữ liệu và cách xử lý (loi-du-lieu.csv)")
    md.append(f"Hệ thống đã rà soát và ghi nhận tổng cộng **{len(df_errors)} bản ghi bất thường** vào file `loi-du-lieu.csv`:\n")

    md.append("| Loại lỗi (`loai_loi`) | Số lượng | Hướng xử lý (`xu_ly`) | Nguyên tắc thực hiện |")
    md.append("| :--- | :---: | :---: | :--- |")
    md.append("| `khong_phai_ban_hang` | 89 phiếu | `GIU` | Gồm xuất dùng tại quán (18), hủy hết hạn (16), điều chỉnh hao hụt/vỡ hỏng (55). Giữ để trừ tồn kho nhưng loại khỏi nhu cầu bán. |")
    md.append("| `trung_dong` | 11 phiếu | `BO` | Bỏ các bản ghi trùng lặp mã phiếu (do bấm đúp hoặc lưu trùng), chỉ giữ lại 1 bản ghi gốc. |")
    md.append("| `don_si_mot_lan` | 10 phiếu | `CAN_NGUOI_QUYET` | 5 cặp nhập - xuất sỉ số lượng lớn đột xuất; tạm loại khỏi F bán lẻ để tránh thổi phồng dự báo. |")
    md.append("| `so_am_khong_ghi_chu` | 6 phiếu | `CAN_NGUOI_QUYET` | Phiếu xuất số lượng âm nhưng thiếu ghi chú khách trả; tạm loại khỏi nhu cầu bán. |")
    md.append("| `so_luong_bat_thuong` | 6 phiếu | `CAN_NGUOI_QUYET` | Đơn xuất lẻ đột biến gấp 10-30 lần (nghi ngờ gõ thừa số 0); tạm loại khỏi nhu cầu bán. |")
    md.append("| `khac` (thiếu mã hàng) | 4 phiếu | `SUA` | Phiếu bị mất mã hàng gốc; đã dò chuẩn xác theo tên hàng để điền lại mã. |")
    md.append("| `thieu_so_luong` | 3 phiếu | `CAN_NGUOI_QUYET` | Phiếu xuất để trống số lượng; không tự bịa số, tạm bỏ qua chờ chủ kiểm tra sổ tay. |")
    md.append("| `ngay_o_tuong_lai` | 2 phiếu | `CAN_NGUOI_QUYET` | Phiếu nhập ghi ngày tháng 12/2026 (vượt mốc 31/10/2026); nghi ngờ gõ nhầm tháng 09/2026. |")
    md.append(f"| **Tổng cộng** | **{len(df_errors)} phiếu** | | |")
    md.append("\n")

    # (6) GIẢ ĐỊNH ĐÃ DÙNG
    md.append("## 6. Các giả định tính toán đã áp dụng")
    md.append("1. **Thời gian giao hàng (Lead time T):** Cố định theo số ngày trong danh mục hàng do không có dữ liệu đo lường độ trễ thực tế của từng chuyến xe giao.")
    md.append("2. **Mức phục vụ khách hàng:** Hệ số an toàn $Z = 1,645$ tương ứng mức phục vụ 95%, giả định nhu cầu bán các tháng độc lập và tuân theo phân phối chuẩn.")
    md.append("3. **Làm tròn lên:** Tồn an toàn SS, Điểm đặt lại ROP và Số lượng cần nhập luôn làm tròn lên số nguyên hoặc bội số quy cách gần nhất theo quy ước của chủ.")
    md.append("4. **Căn cứ tồn kho:** Dùng số tồn kiểm kê thực tế ngày 31/10/2026 làm gốc để tính toán đặt hàng.")
    md.append("5. **Giải thích chênh lệch tồn kho (15 mã):**")
    md.append("   - Chênh lệch dương (tồn hệ thống > tồn kiểm kê): Do các phiếu xuất âm không ghi chú làm tăng ảo tồn hệ thống (MP003, VT007, TH018, MP012), hoặc nhập sỉ chưa bán hết.")
    md.append("   - Chênh lệch âm (tồn hệ thống < tồn kiểm kê): Bắt nguồn trực tiếp từ các phiếu xuất đột biến 10x nghi ngờ gõ thừa số 0 (TH002: -45, MP001: -27, MP006: -27, MP013: -27, TH011: -23) và 2 phiếu nhập ghi nhầm ngày tương lai (VT001: -20, MP015: -18).\n")

    # (7) DANH SÁCH CẦN NGƯỜI QUYẾT
    md.append("## 7. Danh sách CẦN NGƯỜI QUYẾT (Trình chủ cửa hàng phê duyệt)")
    md.append("Để đảm bảo số liệu chính xác tuyệt đối và không bịa đặt, người chủ cần xem xét và cho ý kiến về hai nhóm nội dung sau:\n")

    md.append("### 7.1. Bảng 27 chứng từ nghi vấn cần chốt số liệu")
    md.append("| Mã phiếu | Mã hàng | Tên hàng | Ngày chứng từ | Số lượng | Loại lỗi | Nội dung nghi vấn & Câu hỏi cần chủ chốt |")
    md.append("| :--- | :--- | :--- | :---: | :---: | :--- | :--- |")
    for idx, r in can_quyet_data.iterrows():
        ten = mh_to_ten.get(r['ma_hang'], '')
        row_raw = nk_raw[nk_raw['ma_phieu'] == r['ma_phieu']].iloc[0]
        ngay_str = str(row_raw['ngay'])
        qty_str = str(row_raw['so_luong'])
        md.append(f"| {r['ma_phieu']} | {r['ma_hang']} | {ten} | {ngay_str} | {qty_str} | `{r['loai_loi']}` | {r['ly_do']} |")
    md.append("")

    md.append("### 7.2. Danh sách 15 mặt hàng bị cắt giảm ngân sách cần duyệt phân bổ")
    md.append("Chủ cửa hàng vui lòng xem xét phương án phân bổ 29.988.400 đ trong file `de-xuat-nhap.csv`:")
    md.append("- Duyệt giảm `TH001` (Gạo) từ 128 túi xuống **116 túi** (tiết kiệm 1.104.000 đ) hoặc chủ động giảm tiếp xuống **60-80 túi**.")
    md.append("- Duyệt giảm `TH009` (Nước suối) từ 144 chai xuống **72 chai** (tiết kiệm 230.400 đ).")
    md.append("- Duyệt tạm hoãn nhập 13 mã nhóm OK (hoặc điều chuyển một phần tiền từ gạo TH001 sang các mã B và C có số ngày tồn < 20 ngày như VT007, TH012, TH020, MP013).\n")

    md.append("---")
    md.append("*Báo cáo được trích xuất tự động từ hệ thống bằng code Python tinh_ton_kho.py.*")

    with open('bao-cao.md', 'w', encoding='utf-8') as f:
        f.write('\n'.join(md))



if __name__ == '__main__':
    main()
