# Báo cáo kiểm tra chấm công tháng 09/2026

Do `tinh_cong.py` tạo; chỉ là bản chuẩn bị để quản lý xác nhận, không quyết định lương hay kỷ luật.

## Số liệu tóm tắt
- 25 nhân viên × 30 ngày = 750 dòng công; 1160 dòng quẹt gốc, 1157 dòng dùng được.
- Trạng thái ngày: OK 501, PHEP 12, NGHI 207, CHO_XAC_NHAN 30.
- Tổng giờ công (chỉ ngày OK): 3998.11 giờ; tổng làm thêm: 104.25 giờ.
- 61 bất thường: DI_TRE 12, VANG_CHUA_GHI 6, QUET_TRUNG 6, VE_SOM 6, THIEU_RA 5, NGHI_QUET_HO 4, LAM_NGAY_NGHI 4, DU_LIEU_LOI 3, LAM_NGAY_LE 3, OT_VUOT_NGUONG 3, THIEU_VAO 3, THIEU_KHONG_RO 3, CO_PHEP_NHUNG_QUET 2, OT_THANG_VUOT 1.

## Việc quản lý cần xác nhận (can_nguoi_quyet = CO, theo loại; ngày dạng MM-DD)
- **THIEU_RA (5)**: NV-011 (09-14); NV-013 (09-05); NV-025 (09-28); NV-026 (09-10, 09-25)
- **THIEU_VAO (3)**: NV-011 (09-24); NV-013 (09-13); NV-021 (09-10)
- **THIEU_KHONG_RO (3)**: NV-013 (09-06); NV-023 (09-30); NV-025 (09-11)
- **VANG_CHUA_GHI (6)**: NV-002 (09-22); NV-003 (09-28); NV-010 (09-21); NV-023 (09-11); NV-024 (09-21); NV-026 (09-24)
- **LAM_NGAY_LE (3)**: NV-007 (09-01); NV-010 (09-02); NV-018 (09-02)
- **LAM_NGAY_NGHI (4)**: NV-013 (09-12); NV-014 (09-24); NV-016 (09-12); NV-022 (09-27)
- **NGHI_QUET_HO (4)**: NV-009 (09-23); NV-015 (09-20); NV-016 (09-24); NV-022 (09-24)
- **CO_PHEP_NHUNG_QUET (2)**: NV-010 (09-23); NV-023 (09-23)
- **OT_VUOT_NGUONG (3)**: NV-010 (09-28); NV-013 (09-26); NV-025 (09-10)
- **OT_THANG_VUOT (1)**: NV-001 (THANG)
- **DU_LIEU_LOI (3)**: NV-005 (09-11); NV-007 (không rõ ngày); NV-023 (không rõ ngày)

Chi tiết và câu hỏi gợi ý nằm trong `bat_thuong.csv`. Các mã không cần quyết (QUET_TRUNG 6, DI_TRE 12, VE_SOM 6) đã tính vào bảng công, xem trong cùng tệp.

## Giả định đã dùng
- Ngày lễ 09-01 và 09-02 là LE với mọi người; đơn nghỉ phép chỉ có hiệu lực ở ngày làm việc (ngày OFF/LE trùng đơn ghi NGHI hoặc LAM_NGAY_*).
- Mọi đơn 'Đã duyệt' (kể cả 'Việc riêng không lương') ghi PHEP vì quy định không phân biệt loại đơn.
- Ngày VANG_CHUA_GHI và các ngày bất thường cần người quyết đều có trang_thai = CHO_XAC_NHAN; so_ngay_cho_xac_nhan đếm cả các ngày vắng chưa ghi (cột so_ngay_vang_chua_ghi là phần con của nó).
- Ngày CHO_XAC_NHAN: để trống phut_tre, phut_ve_som, ot_phut, gio_cong; gio_vao/gio_ra chỉ điền với THIEU_RA/THIEU_VAO. Không xét DI_TRE/VE_SOM/OT cho các ngày này.
- Quẹt trùng so với quẹt GIỮ LẠI gần nhất của cùng máy; so sánh theo phút sau khi bỏ giây. NGHI_QUET_HO xét trên các quẹt còn lại sau khi bỏ quẹt trùng.
- so_bat_thuong = số dòng của người đó trong bat_thuong.csv (tính cả QUET_TRUNG, DI_TRE, VE_SOM). OT tháng chỉ cộng ot_phut của các ngày OK.

## Điều chưa chắc
- Cách ghi công, làm thêm cho ngày lễ/ngày nghỉ có quẹt, và cho ngày có đơn nghỉ mà vẫn quẹt: quy định chưa nói rõ, cần người quyết; giờ làm thêm, nghỉ lễ, nghỉ phép cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.
- 6 quẹt hợp lệ nằm ở máy của chi nhánh khác với chi nhánh ghi trong nhan_vien.csv. Quy định không coi đây là bất thường nên chỉ tính bình thường; nếu hai máy cùng ngày cách nhau <= 10 phút thì đã báo NGHI_QUET_HO (chỉ là dấu hiệu, cần người có thẩm quyền xác minh).
- Dòng DU_LIEU_LOI không gán được ngày không ảnh hưởng ngày nào trong bảng công; cần đối chiếu dữ liệu gốc của máy.
- 54 ngày OK có hơn hai quẹt: chỉ lấy quẹt đầu và cuối theo quy định (các quẹt giữa bị bỏ qua).
