"""Tự kiểm đầu ra của agent KHÔNG cần đáp án (dùng được hằng tháng với dữ liệu thật).

Chạy:  python -X utf8 kiem_tra_dau_ra.py <thư_mục_đầu_ra> <thư_mục_an-danh> [--ten bang-ma-hoa.csv]
Kiểm (mỗi mục in ĐẠT / KHÔNG ĐẠT và lý do):
  1. Đủ dòng: số nhân viên x số ngày trong kỳ, không trùng khóa (ma_nv, ngay).
  2. trạng thái chỉ thuộc OK, PHEP, NGHI, CHO_XAC_NHAN; ngày OK có đủ giờ vào, giờ ra, giờ công (0 < giờ công <= 8,00).
  3. Mỗi ngày CHO_XAC_NHAN có ít nhất một dòng trong bat_thuong.csv (không có ngày "chờ" mà không ai biết vì sao).
  4. Mã loại hợp lệ; khóa (ma_nv, ngay, loai) không trùng; giải thích không trống; can_nguoi_quyet khớp quy ước (KHONG chỉ với QUET_TRUNG, DI_TRE, VE_SOM).
  5. Nhất quán chéo: phut_tre > 0 thì có DI_TRE và ngược lại; tương tự VE_SOM.
  6. tong_hop_nguoi khớp bảng ngày: ngày công, tổng giờ công, tổng phút trễ, tổng làm thêm, số ngày phép.
  7. (tùy chọn) không có họ tên nào từ bảng mã hóa xuất hiện trong đầu ra (tên đã ẩn danh).
Không thay thế người duyệt: tệp này chỉ bắt lỗi hình thức và tự mâu thuẫn, không biết quy định đúng hay sai.
"""
import csv, sys, re
from pathlib import Path
from collections import defaultdict, Counter

CODES = {"THIEU_RA", "THIEU_VAO", "THIEU_KHONG_RO", "QUET_TRUNG", "DI_TRE", "VE_SOM", "OT_VUOT_NGUONG", "OT_THANG_VUOT", "VANG_CHUA_GHI",
         "LAM_NGAY_LE", "LAM_NGAY_NGHI", "NGHI_QUET_HO", "CO_PHEP_NHUNG_QUET", "DU_LIEU_LOI"}
KHONG = {"QUET_TRUNG", "DI_TRE", "VE_SOM"}
STATES = {"OK", "PHEP", "NGHI", "CHO_XAC_NHAN"}

def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))

def num(x):
    try: return float(str(x).replace(",", "."))
    except Exception: return None

def kiem_tra(out, an, ten=None):
    out, an = Path(out), Path(an)
    loi = defaultdict(list)
    bc, bt, th = rd(out / "bang_cong_ngay.csv"), rd(out / "bat_thuong.csv"), rd(out / "tong_hop_nguoi.csv")
    nv = [r["ma_nv"] for r in rd(an / "nhan_vien.csv")]
    ngay = sorted({r["ngay"] for r in bc})
    # 1
    keys = Counter((r["ma_nv"], r["ngay"]) for r in bc)
    if len(bc) != len(nv) * len(ngay): loi["1 đủ dòng"].append(f"{len(bc)} dòng, cần {len(nv)} x {len(ngay)} = {len(nv)*len(ngay)}")
    for k, c in keys.items():
        if c > 1: loi["1 đủ dòng"].append(f"trùng khóa {k}")
    for m in nv:
        if sum(1 for r in bc if r["ma_nv"] == m) != len(ngay): loi["1 đủ dòng"].append(f"{m} không đủ {len(ngay)} ngày")
    # 2
    for r in bc:
        if r["trang_thai"] not in STATES: loi["2 trạng thái"].append(f"{r['ma_nv']} {r['ngay']}: '{r['trang_thai']}'")
        if r["trang_thai"] == "OK":
            g = num(r["gio_cong"])
            if not r["gio_vao"] or not r["gio_ra"] or g is None or not (0 < g <= 8.0001):
                loi["2 trạng thái"].append(f"{r['ma_nv']} {r['ngay']}: OK nhưng thiếu giờ hoặc giờ công không hợp lý ({r['gio_cong']})")
    # 3, 4, 5
    bk = Counter((r["ma_nv"], r["ngay"], r["loai"]) for r in bt)
    for k, c in bk.items():
        if c > 1: loi["4 bất thường"].append(f"trùng khóa {k}")
    by_day = defaultdict(set)
    for r in bt: by_day[(r["ma_nv"], r["ngay"])].add(r["loai"])
    for r in bc:
        if r["trang_thai"] == "CHO_XAC_NHAN" and not by_day.get((r["ma_nv"], r["ngay"])):
            loi["3 ngày chờ có lý do"].append(f"{r['ma_nv']} {r['ngay']}")
    for r in bt:
        if r["loai"] not in CODES: loi["4 bất thường"].append(f"loại lạ '{r['loai']}'")
        if not (r.get("giai_thich") or "").strip(): loi["4 bất thường"].append(f"{r['ma_nv']} {r['ngay']} {r['loai']}: giải thích trống")
        if (r["can_nguoi_quyet"].strip().upper() == "KHONG") != (r["loai"] in KHONG): loi["4 bất thường"].append(f"{r['ma_nv']} {r['ngay']} {r['loai']}: can_nguoi_quyet = {r['can_nguoi_quyet']}")
    for r in bc:
        d = by_day.get((r["ma_nv"], r["ngay"]), set())
        if (num(r["phut_tre"]) or 0) > 0 and "DI_TRE" not in d: loi["5 nhất quán"].append(f"{r['ma_nv']} {r['ngay']}: trễ mà không có DI_TRE")
        if (num(r["phut_ve_som"]) or 0) > 0 and "VE_SOM" not in d: loi["5 nhất quán"].append(f"{r['ma_nv']} {r['ngay']}: về sớm mà không có VE_SOM")
    for (m, d), s in by_day.items():
        row = next((r for r in bc if r["ma_nv"] == m and r["ngay"] == d), None)
        if row and "DI_TRE" in s and not (num(row["phut_tre"]) or 0) > 0: loi["5 nhất quán"].append(f"{m} {d}: có DI_TRE mà phut_tre = {row['phut_tre']}")
        if row and "VE_SOM" in s and not (num(row["phut_ve_som"]) or 0) > 0: loi["5 nhất quán"].append(f"{m} {d}: có VE_SOM mà phut_ve_som = {row['phut_ve_som']}")
    # 6
    for r in th:
        m = r["ma_nv"]; rows = [x for x in bc if x["ma_nv"] == m]; ok = [x for x in rows if x["trang_thai"] == "OK"]
        chk = {"ngay_cong": len(ok), "tong_gio_cong": sum(num(x["gio_cong"]) or 0 for x in ok),
               "tong_phut_tre": sum(num(x["phut_tre"]) or 0 for x in ok), "tong_ot_gio": sum(num(x["ot_phut"]) or 0 for x in ok) / 60,
               "so_ngay_phep": sum(1 for x in rows if x["trang_thai"] == "PHEP")}
        for c, v in chk.items():
            g = num(r.get(c, ""))
            if g is None or abs(g - v) > 0.011: loi["6 tổng hợp khớp bảng ngày"].append(f"{m} {c}: tổng hợp {r.get(c)} so với bảng ngày {round(v, 2)}")
    if {r["ma_nv"] for r in th} != set(nv): loi["6 tổng hợp khớp bảng ngày"].append("danh sách người không khớp nhan_vien.csv")
    # 7
    if ten:
        blob = "\n".join((out / f).read_text(encoding="utf-8", errors="replace") for f in ("bang_cong_ngay.csv", "bat_thuong.csv", "tong_hop_nguoi.csv"))
        if (out / "bao_cao.md").exists(): blob += (out / "bao_cao.md").read_text(encoding="utf-8", errors="replace")
        for r in rd(ten):
            if r["ho_ten"] and not r["ho_ten"].startswith("(") and r["ho_ten"] in blob: loi["7 rò rỉ tên"].append(r["ho_ten"])
    return loi

if __name__ == "__main__":
    a = sys.argv[1:]
    ten = a[a.index("--ten") + 1] if "--ten" in a else None
    loi = kiem_tra(a[0], a[1], ten)
    for m in ["1 đủ dòng", "2 trạng thái", "3 ngày chờ có lý do", "4 bất thường", "5 nhất quán", "6 tổng hợp khớp bảng ngày"] + (["7 rò rỉ tên"] if ten else []):
        print(("KHÔNG ĐẠT " if loi.get(m) else "ĐẠT       ") + m + (f"  ({len(loi[m])} lỗi, ví dụ: {loi[m][0]})" if loi.get(m) else ""))
    sys.exit(1 if loi else 0)
