"""So ý kiến của agent với "bộ vàng" bạn tự gán nhãn tay cho khoảng 50 bài (dùng được với dữ liệu thật).

Dùng:  python -X utf8 cham-bo-vang.py <y-kien.csv cua agent> <bo-vang.csv>
bo-vang.csv: cột ma, chu_de, sac_thai (mỗi ý một dòng; bài mỉa mai ghi sac_thai = CAN_NGUOI_DOC).
In ra: số cặp (bài, chủ đề) agent tìm đủ / sót / thừa, độ khớp sắc thái, và danh sách bài lệch để người xem.
Chỉ chấm các bài có trong bộ vàng; kết quả chỉ đúng cho đúng mẫu bài đó.
"""
import csv, sys
from collections import defaultdict

def load(f):
    d = defaultdict(set)
    for r in csv.DictReader(open(f, encoding="utf-8-sig")):
        if r["chu_de"].strip() != "khac": d[(r["ma"].strip(), r["chu_de"].strip())].add(r["sac_thai"].strip())
    return d

ag, vang = load(sys.argv[1]), load(sys.argv[2])
mas = {m for m, _ in vang}
ag = {k: v for k, v in ag.items() if k[0] in mas}
du = [k for k in vang if k in ag]; sot = [k for k in vang if k not in ag]; thua = [k for k in ag if k not in vang]
khop = [k for k in du if ag[k] & vang[k]]
lech = [(k, sorted(vang[k]), sorted(ag[k])) for k in du if not (ag[k] & vang[k])]
print(f"bài trong bộ vàng: {len(mas)} | cặp (bài, chủ đề) vàng: {len(vang)}")
print(f"agent tìm đủ: {len(du)} | sót: {len(sot)} | thừa: {len(thua)}")
print(f"sắc thái khớp: {len(khop)}/{len(du)}")
for k in sot: print("  SÓT ", k)
for k in thua: print("  THỪA", k)
for k, v, a in lech: print("  LỆCH", k, "vàng", v, "agent", a)
