"""Thêm một mã hàng bán theo mùa vào bộ dữ liệu giả (hạt giống cố định, chạy lại ra y hệt) và kiểm kết quả.

Sinh dữ liệu:  python -X utf8 them_hang_mua_vu.py sinh <thu-muc-7-file-goc> <thu-muc-dich>
  - Chép 7 file đầu vào sang thư mục đích, thêm mã TH025 "Bánh trung thu hộp 4 bánh":
    hầu như không bán từ 2025-11 đến 2026-07 (0 đến 3 hộp/tháng), rồi bán rộ: tháng 8 = 70, tháng 9 = 240,
    tháng 10 = 12 hộp. Có phiếu nhập, tồn đầu kỳ 30, tồn kiểm kê cuối kỳ tính bằng code (không bị hết hàng).
Kiểm kết quả:  python -X utf8 them_hang_mua_vu.py kiem <thu-muc-ket-qua-cua-agent>
  - In dòng của TH025 trong phan-loai-tinh-toan.csv và de-xuat-nhap.csv, so dự báo với cùng kỳ năm trước.
Không dùng agent, không dùng đáp án.
"""
import csv
import random
import shutil
import sys
import unicodedata
from datetime import date, timedelta
from pathlib import Path

MA = "TH025"
FILES = ["danh-muc-hang.csv", "nhat-ky-xuat-nhap.csv", "ton-dau-ky-2025-11-01.csv", "ton-kiem-ke-2026-10-31.csv",
         "hang-dang-ve.csv", "tham-so.json", "quy-uoc.md"]
BAN = {"2025-11": 1, "2025-12": 0, "2026-01": 1, "2026-02": 0, "2026-03": 1, "2026-04": 0, "2026-05": 1,
       "2026-06": 2, "2026-07": 3, "2026-08": 70, "2026-09": 240, "2026-10": 12}
TON_DAU = 30
NHAP = [("2026-07-20", 120), ("2026-09-01", 180), ("2026-09-10", 60)]
GIA_VON, GIA_BAN, QUY_CACH, GIAO = 90000, 120000, 6, 5
TEN = "Bánh trung thu hộp 4 bánh"


def ngay_trong_thang(thang, so_ngay, rng):
    y, m = map(int, thang.split("-"))
    cuoi = (date(y + (m == 12), m % 12 + 1, 1) - timedelta(days=1)).day
    toi_da = cuoi if thang != "2026-09" else 28
    return sorted(rng.sample(range(1, toi_da + 1), min(so_ngay, toi_da)))


def chia(tong, k, rng):
    """Chia tong thành k số nguyên dương, mỗi số khác nhau càng nhiều càng tốt."""
    cat = sorted(rng.sample(range(1, tong), k - 1)) if k > 1 else []
    mang = [b - a for a, b in zip([0] + cat, cat + [tong])]
    return mang


def sinh(nguon, dich):
    nguon, dich = Path(nguon), Path(dich)
    dich.mkdir(parents=True, exist_ok=True)
    for f in FILES:
        shutil.copy(nguon / f, dich / f)
    rng = random.Random(20261121)
    xuat = []
    for thang, n in BAN.items():
        if n == 0:
            continue
        k = 1 if n <= 3 else (min(n, 14) if n < 100 else 20)
        ngay = ngay_trong_thang(thang, k, rng)
        sl = chia(n, len(ngay), rng)
        for d, q in zip(ngay, sl):
            xuat.append((f"{thang}-{d:02d}", q))
    tong_ban = sum(q for _, q in xuat)
    kiem_ke = TON_DAU + sum(q for _, q in NHAP) - tong_ban
    # tồn chạy theo ngày phải luôn > 0
    ton, bien = TON_DAU, []
    for d, q in sorted([(d, -q) for d, q in xuat] + [(d, q) for d, q in NHAP]):
        ton += q
        bien.append(ton)
    assert min(bien) > 0 and ton == kiem_ke, (min(bien), ton, kiem_ke)

    def them(ten_file, dong):
        with open(dich / ten_file, "a", encoding="utf-8", newline="") as f:
            csv.writer(f, lineterminator="\r\n" if b"\r\n" in (dich / ten_file).read_bytes()[:3000] else "\n").writerow(dong)

    them("danh-muc-hang.csv", [MA, TEN, "Tạp hóa", "hộp", GIA_VON, GIA_BAN, QUY_CACH, GIAO, "NCC Giả A", "dang_ban", ""])
    them("ton-dau-ky-2025-11-01.csv", [MA, TON_DAU])
    them("ton-kiem-ke-2026-10-31.csv", [MA, kiem_ke])
    for i, (d, q) in enumerate(xuat, 1):
        them("nhat-ky-xuat-nhap.csv", [f"PX9{i:04d}", d, "XUAT", MA, TEN, q, GIA_BAN, ""])
    for i, (d, q) in enumerate(NHAP, 1):
        them("nhat-ky-xuat-nhap.csv", [f"PN9{i:03d}", d, "NHAP", MA, TEN, q, GIA_VON, f"PO-9{i:03d} NCC Giả A"])
    print(f"Da them {MA}: {len(xuat)} phieu xuat (tong {tong_ban} hop), {len(NHAP)} phieu nhap, ton dau {TON_DAU}, ton kiem ke {kiem_ke}")
    print(f"Ban theo thang: {BAN}")
    print(f"Gia tri nhap cung ky nam truoc (2025-11) = {BAN['2025-11']} hop")


def doc(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return {r["ma_hang"].strip(): r for r in csv.DictReader(f)}


def kiem(thu_muc):
    thu_muc = Path(thu_muc)
    pl = doc(thu_muc / "phan-loai-tinh-toan.csv").get(MA)
    dx = doc(thu_muc / "de-xuat-nhap.csv").get(MA)
    if not pl or not dx:
        print(f"KHONG THAY {MA} trong ket qua")
        return 1
    f, nam_truoc = float(pl["nhu_cau_du_bao_thang"]), pl["cung_ky_nam_truoc_2025_11"]
    print(f"{MA}: lop ABC {pl['lop_abc']} | du bao thang 11 = {f:.1f} hop | cung ky nam truoc (2025-11) = {nam_truoc} hop")
    print(f"  ton kiem ke {pl['ton_kiem_ke']} | canh bao {pl['canh_bao']} | can (chua xet ngan sach) {dx['sl_can_chua_xet_ngan_sach']} hop | de xuat {dx['sl_de_xuat']} hop = {dx['thanh_tien']} dong")
    print(f"  can nguoi quyet: {dx['can_nguoi_quyet']} | ly do: {dx['ly_do'][:160]}")
    try:
        ny = float(nam_truoc)
        print(f"  Du bao gap {f / max(ny, 1):.0f} lan cung ky nam truoc")
    except ValueError:
        print("  Khong co so cung ky nam truoc")
    ly_do = "".join(c for c in unicodedata.normalize("NFD", dx["ly_do"].lower()) if unicodedata.category(c) != "Mn")
    nhac_mua = any(t in ly_do for t in ("mua vu", "theo mua", "nam truoc", "cung ky"))
    dat = dx["can_nguoi_quyet"].strip().upper() == "CO" and nhac_mua
    print("  Tieu chi dat (can_nguoi_quyet = CO VA ly do nhac mua vu / cung ky nam truoc): " + ("DAT" if dat else "CHUA DAT"))
    return 0


if __name__ == "__main__":
    if len(sys.argv) == 4 and sys.argv[1] == "sinh":
        sinh(sys.argv[2], sys.argv[3])
    elif len(sys.argv) == 3 and sys.argv[1] == "kiem":
        sys.exit(kiem(sys.argv[2]))
    else:
        raise SystemExit(__doc__)
