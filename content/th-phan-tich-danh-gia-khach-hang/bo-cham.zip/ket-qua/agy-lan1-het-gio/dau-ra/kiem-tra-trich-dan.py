# -*- coding: utf-8 -*-
import csv
import os
import re
import sys

def get_paths():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    if os.path.exists(os.path.join(base_dir, '..', 'danh-gia.csv')):
        root_dir = os.path.abspath(os.path.join(base_dir, '..'))
        dau_ra_dir = base_dir
    else:
        root_dir = os.path.abspath('.')
        dau_ra_dir = os.path.join(root_dir, 'dau-ra')
    return root_dir, dau_ra_dir

def main():
    root_dir, dau_ra_dir = get_paths()
    danh_gia_path = os.path.join(root_dir, 'danh-gia.csv')
    y_kien_path = os.path.join(dau_ra_dir, 'y-kien.csv')
    nguy_cap_path = os.path.join(dau_ra_dir, 'nguy-cap.csv')
    bao_cao_path = os.path.join(dau_ra_dir, 'bao-cao.md')

    # Load danh-gia.csv
    noi_dung_map = {}
    with open(danh_gia_path, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            noi_dung_map[r['ma']] = r['noi_dung']

    all_passed = True

    # 1. Check y-kien.csv
    print("--- KIỂM TRA Y-KIEN.CSV ---")
    y_kien_failed = []
    y_kien_count = 0
    if os.path.exists(y_kien_path):
        with open(y_kien_path, encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for idx, r in enumerate(reader, 1):
                y_kien_count += 1
                ma = r['ma']
                quote = r['trich_dan']
                full_text = noi_dung_map.get(ma, "")
                if quote not in full_text:
                    y_kien_failed.append((idx, ma, quote, full_text))
        if y_kien_failed:
            all_passed = False
            print(f"FAILED: {len(y_kien_failed)}/{y_kien_count} dòng trong y-kien.csv không khớp nguyên văn!")
            for idx, ma, quote, full in y_kien_failed[:10]:
                print(f"  Dòng {idx} [{ma}]: {repr(quote)} KHÔNG CÓ TRONG {repr(full)}")
        else:
            print(f"PASSED: Toàn bộ {y_kien_count} dòng trong y-kien.csv đều khớp nguyên văn 100%.")
    else:
        print(f"ERROR: Không tìm thấy file {y_kien_path}")
        all_passed = False

    # 2. Check nguy-cap.csv
    print("\n--- KIỂM TRA NGUY-CAP.CSV ---")
    nguy_cap_failed = []
    nguy_cap_count = 0
    if os.path.exists(nguy_cap_path):
        with open(nguy_cap_path, encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for idx, r in enumerate(reader, 1):
                nguy_cap_count += 1
                ma = r['ma']
                quote = r['trich_dan']
                full_text = noi_dung_map.get(ma, "")
                if quote not in full_text:
                    nguy_cap_failed.append((idx, ma, quote, full_text))
        if nguy_cap_failed:
            all_passed = False
            print(f"FAILED: {len(nguy_cap_failed)}/{nguy_cap_count} dòng trong nguy-cap.csv không khớp nguyên văn!")
            for idx, ma, quote, full in nguy_cap_failed:
                print(f"  Dòng {idx} [{ma}]: {repr(quote)} KHÔNG CÓ TRONG {repr(full)}")
        else:
            print(f"PASSED: Toàn bộ {nguy_cap_count} dòng trong nguy-cap.csv đều khớp nguyên văn 100%.")
    else:
        print(f"ERROR: Không tìm thấy file {nguy_cap_path}")
        all_passed = False

    # 3. Check bao-cao.md
    print("\n--- KIỂM TRA BAO-CAO.MD ---")
    bao_cao_failed = []
    bao_cao_count = 0
    if os.path.exists(bao_cao_path):
        with open(bao_cao_path, encoding='utf-8') as f:
            content = f.read()
        # Find all quotes matching `> [ma] "quote"`
        pattern = r'>\s*\[([A-Za-z0-9]+)\]\s*"([^"]+)"'
        matches = re.findall(pattern, content)
        for ma, quote in matches:
            bao_cao_count += 1
            full_text = noi_dung_map.get(ma, "")
            if quote not in full_text:
                bao_cao_failed.append((ma, quote, full_text))
        if bao_cao_failed:
            all_passed = False
            print(f"FAILED: {len(bao_cao_failed)}/{bao_cao_count} trích dẫn trong bao-cao.md không khớp nguyên văn!")
            for ma, quote, full in bao_cao_failed:
                print(f"  [{ma}]: {repr(quote)} KHÔNG CÓ TRONG {repr(full)}")
        else:
            print(f"PASSED: Toàn bộ {bao_cao_count} trích dẫn trong bao-cao.md đều khớp nguyên văn 100%.")
    else:
        print(f"WARNING: Chưa tìm thấy file {bao_cao_path} (chưa tạo hoặc sai đường dẫn).")

    print("\n" + "="*50)
    if all_passed:
        print("KẾT QUẢ CUỐI CÙNG: TẤT CẢ TRÍCH DẪN ĐỀU QUA (PASSED)!")
    else:
        print("KẾT QUẢ CUỐI CÙNG: CÓ LỖI CẦN SỬA!")

if __name__ == '__main__':
    main()
