# Kiểm chéo tổng doanh thu từng chi nhánh: ra/ so với file gốc (tháng 10/2026)

Ngày chạy: 2026-11-21. Script: `kiem_cheo.py` (đọc thẳng `goc/*.xlsx`; từ `ra/` chỉ đọc `tong_hop_chi_nhanh.csv`, không dùng `hop_nhat.csv`). Mọi con số trong file này do script tính bằng số nguyên (đồng).

## Bảng đối chiếu

- **Tổng file ghi**: con số tổng chi nhánh tự ghi ở cuối bảng. Với ô công thức, lấy giá trị Excel đã tính sẵn và script tự tính lại công thức để kiểm.
- **Tổng dòng đọc được**: cộng thành tiền của MỌI dòng dữ liệu đọc được (kể cả dòng trùng, ngoài tháng 10, trả hàng); không cộng dòng tổng hay dòng cộng tuần.
- **Tổng trong ra/**: cột `doanh_thu` trong `ra/tong_hop_chi_nhanh.csv`. Chênh lệch = ra/ trừ số so sánh (âm nghĩa là ra/ ít hơn). Số trong ngoặc là số dòng.

| Chi nhánh | Tổng file ghi | Tổng dòng đọc được (số dòng) | Tổng trong ra/ (số dòng) | Chênh lệch ra/ − file ghi | Chênh lệch ra/ − dòng đọc được | Nguyên nhân |
|---|---:|---:|---:|---:|---:|---|
| HN (Hà Nội) | 263.036.000 | 262.936.000 (146) | 262.936.000 (146) | -100.000 | 0 | ra/ = tổng các dòng đọc được; tổng chi nhánh tự ghi cao hơn tổng các dòng 100.000 (file tự mâu thuẫn): CHƯA GIẢI THÍCH |
| HP (Hải Phòng) | 296.542.000 | 296.542.000 (171) | 279.155.000 (161) | -17.387.000 | -17.387.000 | ra/ ít hơn tổng dòng 17.387.000: khớp đến từng đồng với việc ra/ đã loại 3 dòng trùng y hệt = 7.196.000 + 4 dòng ngoài tháng 10 chắc chắn (đơn tháng 9) = 7.800.000 + 3 dòng ngày mơ hồ (10/09, có thể là 9/10) = 2.391.000; số dòng ra/ (161) cũng khớp |
| DN (Đà Nẵng) | 278.248.000 | 278.248.000 (159) | 278.248.000 (159) | 0 | 0 | Khớp cả ba số |
| CT (Cần Thơ) | 184.408.000 | 184.408.000 (114) | 184.408.000 (114) | 0 | 0 | Khớp cả ba số |
| BH (Biên Hòa) | 270.321.000 | 270.321.000 (157) | 270.321.000 (157) | 0 | 0 | Khớp cả ba số |
| NT (Nha Trang) | 250.545.000 | 250.545.000 (166) | 248.400.000 (164) | -2.145.000 | -2.145.000 | ra/ ít hơn tổng dòng 2.145.000: khớp đến từng đồng với việc ra/ đã loại 2 dòng trùng y hệt = 2.145.000; số dòng ra/ (164) cũng khớp |
| **Cộng 6 chi nhánh** | 1.543.100.000 | 1.543.000.000 | 1.523.468.000 | -19.632.000 | -19.532.000 | |

## Kết luận

1. 3/6 chi nhánh khớp cả ba số (file ghi = dòng đọc được = ra/): DN, CT, BH. 3/6 chi nhánh trong ra/ lệch so với số chi nhánh tự ghi: HN (-100.000), HP (-17.387.000), NT (-2.145.000).
2. HP giải thích được đến từng đồng và khớp số dòng (ra/ đã loại: dòng trùng y hệt, dòng ngoài tháng 10 chắc chắn (đơn tháng 9), dòng ngày mơ hồ (10/09, có thể là 9/10)); NT giải thích được đến từng đồng và khớp số dòng (ra/ đã loại: dòng trùng y hệt); HN CHƯA GIẢI THÍCH 100.000: tổng chi nhánh tự ghi ≠ cộng các dòng của chính file, ra/ khớp tổng dòng nên phần lệch nằm ở con số chi nhánh ghi, và không có dòng nào trong file gây ra.
3. Điểm KHÔNG CHẮC, cần người giữ file gốc xác nhận: HP: ra/ loại 3 dòng ngày mơ hồ (2.391.000) có thể là tháng 10 bị hoán đổi ngày↔tháng; BH: ra/ tính 3 dòng ngày lạ (5.026.000), có thể là tháng 10 bị hoán đổi ngày↔tháng nên nhiều khả năng đúng nhưng chưa chắc; NT: 2 dòng thành tiền ≠ SL×giá, chênh 100.000, không biết số nào đúng.

## Chi tiết từng chi nhánh

### HN — Hà Nội (`BC doanh thu T10 - HN.xlsx`)

- Đọc được 146 dòng dữ liệu (dòng Excel 5 đến 150); số dòng không đọc được: 0. Tổng chi nhánh ghi: 263.036.000 (dòng Excel 151, nhãn "TỔNG CỘNG"; số gõ cứng, không phải công thức).
- Ngày nằm ở ô gộp cột A: 115 dòng lấy ngày từ ô gộp; dòng thiếu ngày: 0; ngày tăng dần: có.
- Không tìm thấy dòng trùng mã, ngoài tháng, âm, hay thành tiền ≠ SL×giá.
- Tổng chi nhánh ghi − dòng đọc được = +100.000: số tổ hợp nhóm trong file giải thích đúng số này là 0 ([]). **CHƯA GIẢI THÍCH**: file không có dòng trùng, dòng ngoài tháng, dòng thành tiền ≠ SL×giá hay ngày lạ nào tạo ra đúng chênh lệch này; mã chứng từ liền số, không thiếu mã. Có thể con số tổng bị gõ nhầm hoặc có một dòng đã bị sửa/xóa sau khi tính tổng, nhưng đó chỉ là phỏng đoán.
- Ghi chú trong file: Ghi chú: Giá đã gồm VAT. Số liệu chưa trừ hàng trả lại. | Người lập: Kế toán chi nhánh (giả)      Ngày lập: 02/11/2026

### HP — Hải Phòng (`DoanhThu_HP_102026.xlsx`)

- Đọc được 171 dòng dữ liệu (dòng Excel 4 đến 174); số dòng không đọc được: 0. Tổng chi nhánh ghi: 296.542.000 (dòng Excel 175, nhãn "Tổng cộng:"; số gõ cứng, không phải công thức).
- Ngày là chuỗi; kiểu đọc áp cho cả file: ngày/tháng/năm (dd/mm) (loại trừ: cách đọc còn lại tạo ra ngày không tồn tại ở ít nhất một dòng). 57 dòng nếu đọc riêng lẻ có thể hiểu thành 2 ngày khác nhau; chốt theo quy ước chung của file; ngày không sắp tăng dần nên không có thêm thứ tự để đối chiếu.
- Nhóm `trung`: 3 dòng trùng y hệt dòng trước đó (cùng mã, ngày, hàng, SL, giá, tiền): HD59200, HD37858, HD64385. Cộng thành tiền các dòng này: 7.196.000. Chi tiết: HD59200 (dòng Excel 108, 02/10/2026, 1.320.000); HD37858 (dòng Excel 125, 16/10/2026, 5.800.000); HD64385 (dòng Excel 171, 03/10/2026, 76.000).
- Nhóm `ngoai_thang`: 4 dòng ngày ngoài tháng 10/2026, không có cách đọc nào đưa về tháng 10: HD60907, HD65097, HD28722, HD12045. Cộng thành tiền các dòng này: 7.800.000. Chi tiết: HD60907 (dòng Excel 25, 30/09/2026, 1.200.000); HD65097 (dòng Excel 28, 26/09/2026, 3.700.000); HD28722 (dòng Excel 66, 29/09/2026, 2.220.000); HD12045 (dòng Excel 82, 27/09/2026, 680.000).
- Nhóm `ngay_mo_ho`: 3 dòng có ngày ngoài tháng 10 nhưng nếu hoán đổi ngày↔tháng thì rơi vào tháng 10: HD89953, HD50470, HD47118. Cộng thành tiền các dòng này: 2.391.000. Chi tiết: HD89953 (dòng Excel 47, 10/09/2026, 195.000); HD50470 (dòng Excel 87, 10/09/2026, 1.380.000); HD47118 (dòng Excel 117, 10/09/2026, 816.000).
- Đối soát ra/ − dòng đọc được = -17.387.000: số tổ hợp nhóm có tổng tác động đúng bằng số này là 1 ([['trung', 'ngoai_thang', 'ngay_mo_ho']]); kiểm số dòng ra/ = 161: [True].
- Lưu ý: ra/ ĐÃ LOẠI 3 dòng ngày mơ hồ (tổng 2.391.000). Nếu thực ra là tháng 10 thì ra/ thiếu đúng 2.391.000. Chi tiết: HD89953 (dòng Excel 47): ghi 10/09/2026, nếu hoán đổi ngày↔tháng là 09/10/2026, 195.000đ; HD50470 (dòng Excel 87): ghi 10/09/2026, nếu hoán đổi ngày↔tháng là 09/10/2026, 1.380.000đ; HD47118 (dòng Excel 117): ghi 10/09/2026, nếu hoán đổi ngày↔tháng là 09/10/2026, 816.000đ.
- Ghi chú trong file: * Gồm 4 đơn tháng 9 nhập trễ (từ 26/09 đến 30/09).

### DN — Đà Nẵng (`Bao cao thang 10 - DN (final).xlsx`)

- Đọc được 159 dòng dữ liệu (dòng Excel 3 đến 161); số dòng không đọc được: 0. Tổng chi nhánh ghi: 278.248.000 (dòng Excel 162, nhãn "Total"; số gõ cứng, không phải công thức).
- Ngày là chuỗi; kiểu đọc áp cho cả file: tháng/ngày/năm (mm/dd) (loại trừ: cách đọc còn lại tạo ra ngày không tồn tại ở ít nhất một dòng). 55 dòng nếu đọc riêng lẻ có thể hiểu thành 2 ngày khác nhau; chốt theo quy ước chung của file, ngày tăng dần theo thứ tự dòng.
- Nhóm `tra_hang`: 1 dòng trả hàng (số âm): RT-0119. Cộng thành tiền các dòng này: -120.000. Chi tiết: RT-0119 (dòng Excel 122, 25/10/2026, -120.000).
- Lưu ý: ra/ và file đều đã trừ RT-0119 (-120.000) (dòng trả hàng, số âm), tức tính doanh thu thuần.
- Lưu ý: 1 cặp dòng GIỐNG nội dung nhưng KHÁC mã (DN-0001 & DN-0002 (2.220.000đ mỗi dòng)); không coi là trùng, ra/ và file đều giữ; không đủ căn cứ để kết luận trùng.
- Ghi chú trong file: Prepared by: Accounting (fake)

### CT — Cần Thơ (`CT_T10_DoanhThu.xlsx`)

- Đọc được 114 dòng dữ liệu (dòng Excel 8 đến 121); số dòng không đọc được: 0. Tổng chi nhánh ghi: 184.408.000 (dòng Excel 122, nhãn "Cộng"; ô là công thức `=SUM(F8:F121)`, lấy giá trị đã tính sẵn trong file).
- Script tự tính lại công thức đó: 184.408.000, khớp giá trị trong file.
- Ngày là ngày thật của Excel; tăng dần theo thứ tự dòng: có.
- Không tìm thấy dòng trùng mã, ngoài tháng, âm, hay thành tiền ≠ SL×giá.
- Ghi chú trong file: Ghi chú: Số liệu lấy từ phần mềm bán hàng.

### BH — Biên Hòa (`BienHoa-102026.xlsx`)

- Đọc được 157 dòng dữ liệu (dòng Excel 3 đến 163); số dòng không đọc được: 0. Tổng chi nhánh ghi: 270.321.000 (dòng Excel 165, nhãn "TỔNG THÁNG"; ô là công thức `=F37+F72+F112+F148+F164`, lấy giá trị đã tính sẵn trong file).
- Script tự tính lại công thức đó: 270.321.000, khớp giá trị trong file.
- Dòng cộng tuần (không tính vào tổng dòng vì sẽ cộng đôi): dòng 37: ghi 56.491.000, cộng 34 dòng phía trên 56.491.000, khớp; dòng 72: ghi 48.245.000, cộng 34 dòng phía trên 48.245.000, khớp; dòng 112: ghi 67.358.000, cộng 39 dòng phía trên 67.358.000, khớp; dòng 148: ghi 69.955.000, cộng 35 dòng phía trên 69.955.000, khớp; dòng 164: ghi 28.272.000, cộng 15 dòng phía trên 28.272.000, khớp. Tổng 5 tuần = 270.321.000.
- Ngày là ngày thật của Excel; tăng dần theo thứ tự dòng: không (bỏ các dòng ngày lạ ở dưới thì tăng dần: có).
- Nhóm `ngay_mo_ho`: 3 dòng có ngày ngoài tháng 10 nhưng nếu hoán đổi ngày↔tháng thì rơi vào tháng 10: PX-0016, PX-0021, PX-0035. Cộng thành tiền các dòng này: 5.026.000. Chi tiết: PX-0016 (dòng Excel 18, 10/04/2026, 180.000); PX-0021 (dòng Excel 23, 10/05/2026, 136.000); PX-0035 (dòng Excel 38, 10/08/2026, 4.710.000).
- Lưu ý: ra/ và file ĐỀU TÍNH 3 dòng có ngày lạ (tổng 5.026.000). Nếu thực sự không phải tháng 10 thì tổng tháng 10 bị thừa đúng 5.026.000. Chi tiết: PX-0016 (dòng Excel 18): ghi 10/04/2026, nếu hoán đổi ngày↔tháng là 04/10/2026, khớp vị trí giữa hai dòng liền kề (2026-10-04 .. 2026-10-04), 180.000đ; PX-0021 (dòng Excel 23): ghi 10/05/2026, nếu hoán đổi ngày↔tháng là 05/10/2026, khớp vị trí giữa hai dòng liền kề (2026-10-05 .. 2026-10-05), 136.000đ; PX-0035 (dòng Excel 38): ghi 10/08/2026, nếu hoán đổi ngày↔tháng là 08/10/2026, khớp vị trí giữa hai dòng liền kề (2026-10-07 .. 2026-10-08), 4.710.000đ.

### NT — Nha Trang (`NhaTrang_doanhthu_T10.xlsx`)

- Đọc được 166 dòng dữ liệu (dòng Excel 4 đến 169); số dòng không đọc được: 0. Tổng chi nhánh ghi: 250.545.000 (dòng Excel 170, nhãn "Tổng:"; số gõ cứng, không phải công thức).
- Ngày là chuỗi; kiểu đọc áp cho cả file: ngày/tháng/năm (dd/mm) (loại trừ: cách đọc còn lại tạo ra ngày không tồn tại ở ít nhất một dòng). 55 dòng nếu đọc riêng lẻ có thể hiểu thành 2 ngày khác nhau; chốt theo quy ước chung của file, ngày tăng dần theo thứ tự dòng.
- Nhóm `trung`: 2 dòng trùng y hệt dòng trước đó (cùng mã, ngày, hàng, SL, giá, tiền): NT/0060, NT/0138. Cộng thành tiền các dòng này: 2.145.000. Chi tiết: NT/0060 (dòng Excel 64, 13/10/2026, 1.425.000); NT/0138 (dòng Excel 143, 27/10/2026, 720.000).
- Nhóm `sl_gia`: 2 dòng thành tiền ghi ≠ SL×giá: NT/0132, NT/0160. Cộng thành tiền các dòng này: 2.470.000. Chi tiết: NT/0132 (dòng Excel 136, 26/10/2026, 1.160.000); NT/0160 (dòng Excel 165, 31/10/2026, 1.310.000).
- Đối soát ra/ − dòng đọc được = -2.145.000: số tổ hợp nhóm có tổng tác động đúng bằng số này là 1 ([['trung']]); kiểm số dòng ra/ = 164: [True].
- Lưu ý: 2 dòng có thành tiền ≠ SL×giá; ra/ và file đều giữ số tiền ghi, tổng chênh 100.000 (không biết số nào đúng: SL, giá hay tiền). NT/0132 (dòng 136): ghi 1.160.000, SL×giá = 6×185.000 = 1.110.000, thừa 50.000; NT/0160 (dòng 165): ghi 1.310.000, SL×giá = 6×210.000 = 1.260.000, thừa 50.000.
- Lưu ý: 3 cặp dòng GIỐNG nội dung nhưng KHÁC mã (NT/0055 & NT/0059 (5.550.000đ mỗi dòng); NT/0093 & NT/0095 (3.460.000đ mỗi dòng); NT/0156 & NT/0157 (2.400.000đ mỗi dòng)); không coi là trùng, ra/ và file đều giữ; không đủ căn cứ để kết luận trùng.
- Ghi chú trong file: Lưu ý: file xuất từ phần mềm cũ, mọi thắc mắc liên hệ kế toán CN.

## Đối chiếu ghi chú cuối file HP

Ghi chú nói có 4 đơn tháng 9 nhập trễ (26/09 đến 30/09). Script đếm được 4 dòng ngày tháng 9 không thể đọc khác đi: khớp ghi chú. Còn 3 dòng ngày 10/09/2026 mà ghi chú KHÔNG nhắc tới: đọc theo dd/mm là 10/9 (ngoài tháng), hoán đổi là 9/10 (trong tháng). Việc ghi chú chỉ nói 4 đơn nghiêng về cách hiểu 9/10, nhưng đó là suy luận chứ không phải bằng chứng.

## Phương pháp và giới hạn

- Sáu file có bố cục khác nhau (ngày là ô gộp, chuỗi `MM/DD/YYYY`, chuỗi `DD/MM/YYYY`, chuỗi `DD-MM-YY`, ngày thật; tiền là số hoặc chuỗi `165.000đ` / `1,800,000`; có hoặc không có dòng cộng tuần). Script chuẩn hóa về số nguyên đồng và ngày; giá trị lạ không đoán mà báo ra.
- Ngày dạng chuỗi: script thử các cách đọc, loại cách nào tạo ngày không tồn tại ở bất kỳ dòng nào trong file, rồi áp cách còn lại cho cả file. Đây là suy luận từ dữ liệu vì file không ghi rõ định dạng.
- Tìm nguyên nhân: script gom dòng bất thường thành nhóm (trùng y hệt, ngoài tháng chắc chắn, ngày mơ hồ, trả hàng, thành tiền ≠ SL×giá), rồi thử mọi tổ hợp nhóm xem tổng tác động có bằng đúng số chênh không. Khớp đến từng đồng và khớp số dòng là bằng chứng mạnh rằng script kia đã làm như vậy, nhưng vẫn là suy luận về việc script kia làm gì: tôi không đọc code hay `bao_cao.md` của nó.
- Chỉ kiểm tổng từng chi nhánh theo yêu cầu. Không kiểm doanh thu theo sản phẩm, không kiểm chuẩn hóa tên sản phẩm, không đối chiếu từng dòng với `ra/hop_nhat.csv` (lúc bắt đầu tôi có liếc 5 dòng đầu của file này để biết tên cột, không lấy số nào từ đó).
- Không sửa gì trong `goc/` và `ra/`: băm SHA-256 của 13 file trong hai thư mục, trước và sau khi chạy: giống hệt.
