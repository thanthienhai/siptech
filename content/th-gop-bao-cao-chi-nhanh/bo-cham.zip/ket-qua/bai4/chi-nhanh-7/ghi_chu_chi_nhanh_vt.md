# Ghi chú chi nhánh VT (Vũng Tàu) - tháng 11/2026

_File gốc: `goc/VungTau_T11_2026.xlsx` (chỉ đọc). Mọi con số dưới đây do code tính từ file gốc và từ các CSV trong `ra/`, không gõ tay._

## 1. File VT khác 6 file cũ ở điểm nào

| Điểm | 6 file cũ | File VT | Xử lý trong gop.py |
|---|---|---|---|
| Sheet | 1 sheet có dữ liệu | 1 sheet `BC T11`, A1:G158 | Không đổi |
| Hàng tiêu đề | dòng 1-7 tùy file | dòng 5 (dòng 1-3 là tiêu đề báo cáo, dòng 4 trống) | Không đổi: script tự dò |
| Số cột | 6 cột | 7 cột | Xem mục 2 (cột `Nhân viên`) |
| Tên cột | `Số HĐ`/`Ngày`/`Đơn giá`/`Thành tiền`... | `Ngày / Mã HĐ / Nhân viên / Sản phẩm / SL / Đơn giá (VND) / Thành tiền (VND)` | **Thêm** `Mã HĐ`, `Đơn giá (VND)`, `Thành tiền (VND)` vào bảng tên cột (`VAI_TRO`). Đây là lý do script cũ báo "không tìm thấy hàng tiêu đề": chỉ nhận ra 3/6 vai trò |
| Kiểu ngày | ngày thật, hoặc chữ `dd/mm/yyyy`, `mm/dd/yyyy`, `dd-mm-yy` | chữ `d.m.yyyy` dấu chấm, không đệm số 0 (150/150 ô là chữ, 0 ô là ngày thật) | Không đổi: bộ đọc ngày đã nhận dấu chấm; quy ước dd.mm suy từ dữ liệu (mục 2) |
| Kiểu số tiền | số thật, hoặc chữ `165.000đ`, `68,000` | chữ `138.000 VND` (dấu chấm ngăn nghìn, đuôi `VND`) ở cả đơn giá và thành tiền; SL là số nguyên thật | Không đổi: bộ đọc số đã bỏ được đuôi `VND` và dấu chấm nghìn. Mọi ô đều đúng dạng `nnn.nnn`, không có chỗ nào đọc nhập nhằng |
| Dòng tổng | cuối bảng, nhãn `Tổng cộng`/`Cộng tuần`... | dòng 156: nhãn `Tổng cộng:` nằm ở ô **F156** (cột Đơn giá), số ở ô G156, là chữ chứ không phải công thức | Không đổi: script tìm nhãn ở mọi cột rồi lấy số ở cột thành tiền |
| Cộng tuần / ô gộp / công thức / sheet ẩn | có ở một số file | không có | - |
| Ghi chú cuối bảng | có ở một số file | dòng 158: "Ghi chú: 2 dòng nhập lặp do lỗi máy in, chưa xóa." | Không đổi: script đã đưa vào `viec_can_hoi.csv` (loại KHAC) |
| Mã chứng từ | tùy chi nhánh | `VT00001` đến `VT00148`, liên tục, không nhảy số | - |
| Tên sản phẩm | nhiều cách viết | 24 cách viết cho 8 sản phẩm (hoa/thường, không dấu, viết tắt, 5 dòng có dấu cách thừa cuối tên) | Không đổi: quy tắc nhận diện sẵn có khớp hết, 0 dòng `CHUA_XAC_DINH` (xem mục 2) |

Ngoài ra đã thêm dòng `VT,Vũng Tàu` vào `danh_muc_chi_nhanh.csv` (giữ nguyên BOM và xuống dòng CRLF). Chi nhánh VT được nhận ra từ tên file và dòng tiêu đề `CHI NHÁNH VŨNG TÀU`.

## 2. Quyết định cho từng cột

| Cột | Nội dung | Quyết định |
|---|---|---|
| A `Ngày` | chữ `d.m.yyyy`, tất cả trong tháng 11/2026 | Đọc theo **ngày.tháng.năm**. Căn cứ: 86 ô có ngày > 12 chỉ đọc được là ngày/tháng, 0 ô chỉ đọc được là tháng/ngày; phần tháng của cả 150 ô đều là 11; tiêu đề file ghi `01/11/2026 - 30/11/2026`. 58 dòng có ngày <= 12 (trừ ngày 11) về lý thuyết đọc được 2 cách nên mang trạng thái `SUY_RA` (tổng 118.908.000 đ). **Cần xác nhận** (xem mục 4) |
| B `Mã HĐ` | 148 mã, `VT` + 5 số | Dùng làm số chứng từ |
| C `Nhân viên` | **cột lạ**: mã NV01, NV02, NV03, NV04 (4 giá trị) | **Bỏ qua** (khai báo trong `COT_BO_QUA`). Nghĩa rõ theo tiêu đề cột và không ảnh hưởng số tiền. 6 file đầu ra giữ nguyên như tháng trước nên không có chỗ để đưa mã nhân viên. Nếu sau này cần báo cáo theo nhân viên thì đó là yêu cầu mới, **CẦN NGƯỜI QUYẾT** có đưa vào hay không. Tạm thời: bỏ qua. Cột lạ khác (chưa khai báo) vẫn làm script dừng và báo lỗi |
| D `Sản phẩm` | 24 cách viết | Quy về mã theo quy tắc sẵn có, bảng ở mục 3 |
| E `SL` | số nguyên thật | Dùng nguyên |
| F `Đơn giá (VND)` | chữ `nnn.nnn VND` | Bỏ đuôi `VND` và dấu chấm nghìn, ra số nguyên đồng |
| G `Thành tiền (VND)` | chữ `nnn.nnn VND` | Như trên. Kiểm tra SL x đơn giá: 0 dòng lệch trong 150 dòng. Giữ số chi nhánh ghi |

## 3. Tên sản phẩm -> mã (do gop.py gán, đếm bằng code)

| Mã | Cách viết trong file VT | Số dòng | Đơn giá đã gặp (đ) |
|---|---|---:|---|
| SP01 | "Gao ST25 5kg" | 12 | 157.000, 165.000, 173.000 |
| SP01 | "GẠO ST25 5KG" | 5 | 157.000, 165.000 |
| SP01 | "ST25 5kg" | 4 | 157.000, 165.000, 173.000 |
| SP02 | "N.mắm TT 500ml" | 4 | 65.000, 68.000 |
| SP02 | "NƯỚC MẮM TRUYỀN THỐNG 500ML" | 8 | 65.000, 68.000, 71.000 |
| SP02 | "Nước mắm truyền thống chai 500ml" | 9 | 65.000, 68.000 |
| SP03 | "CF rang xay 500gr" | 5 | 138.000, 145.000, 152.000 |
| SP03 | "Cà phê rang xay 500g" | 6 | 145.000, 152.000 |
| SP03 | "Cà phê rang xay 500g " | 5 | 138.000, 145.000, 152.000 |
| SP04 | "TRÀ SEN 200G" | 9 | 114.000, 120.000, 126.000 |
| SP04 | "Trà sen (200g)" | 6 | 114.000, 120.000, 126.000 |
| SP04 | "Trà sen 200 g" | 8 | 114.000, 120.000, 126.000 |
| SP05 | "Mat ong rung 250ml" | 7 | 176.000, 185.000 |
| SP05 | "Mật ong 250ml" | 6 | 176.000, 185.000, 194.000 |
| SP05 | "Mật ong rừng 250 ml" | 12 | 176.000, 185.000, 194.000 |
| SP06 | "Hat dieu rang muoi 500g" | 3 | 200.000 |
| SP06 | "HẠT ĐIỀU RANG MUỐI 500G" | 6 | 200.000, 210.000, 220.000 |
| SP06 | "Hạt điều 500g" | 2 | 210.000, 220.000 |
| SP07 | "B.tráng muối tôm 250g" | 5 | 38.000, 40.000 |
| SP07 | "BÁNH TRÁNG MUỐI TÔM 250G" | 4 | 38.000, 40.000 |
| SP07 | "Bánh tráng MT 250g" | 2 | 38.000, 40.000 |
| SP08 | "Dau dua ep lanh 250ml" | 8 | 95.000, 100.000 |
| SP08 | "DẦU DỪA ÉP LẠNH 250ML" | 5 | 90.000, 95.000 |
| SP08 | "Dầu dừa ép lạnh 250 ml" | 7 | 95.000, 100.000 |

Đối chiếu tên chuẩn: SP01 = Gạo ST25 túi 5kg; SP02 = Nước mắm truyền thống chai 500ml; SP03 = Cà phê rang xay 500g; SP04 = Trà sen 200g; SP05 = Mật ong rừng 250ml; SP06 = Hạt điều rang muối 500g; SP07 = Bánh tráng muối tôm 250g; SP08 = Dầu dừa ép lạnh 250ml.

Kiểm tra chéo: với mọi cách viết, mọi đơn giá đều đã xuất hiện ở các cách viết còn lại cùng mã hoặc ở 6 chi nhánh khác cùng mã (không có dấu hiệu gán nhầm mã).

**Giả định cần biết:** các tên như `Mật ong 250ml` (thiếu chữ "rừng"), `Hạt điều 500g` (thiếu "rang muối"), `N.mắm TT 500ml`, `ST25 5kg` được gán về mã duy nhất trong danh mục cùng loại và quy cách. Quy tắc này đã dùng cho 6 chi nhánh cũ. Nếu sau này danh mục có thêm loại cùng quy cách (ví dụ mật ong loại khác 250ml), quy tắc `QUY_TAC_SAN_PHAM` phải sửa.

## 4. Việc còn mở (CẦN NGƯỜI QUYẾT / cần xác nhận) và cách tạm xử lý

1. **Quy ước ngày dd.mm.yyyy** (58 dòng, 118.908.000 đ): CẦN XÁC NHẬN với VT. Tạm: đọc ngày.tháng. Có trong `viec_can_hoi.csv`.
2. **2 chứng từ lặp** (VT00072, VT00128): cùng số chứng từ và cùng nội dung hoàn toàn. File tự ghi chú "Ghi chú: 2 dòng nhập lặp do lỗi máy in, chưa xóa.". Tạm: chỉ tính 1 lần, loại 2 dòng, tổng 645.000 đ. CẦN VT xác nhận và nên xóa dòng lặp trong file gốc. Có trong `viec_can_hoi.csv`.
3. **Cột `Nhân viên`**: bỏ qua, xem mục 2.
4. Độ mong manh nhỏ trong `gop.py` (chưa sửa vì không cần): ghi chú cuối bảng chỉ được đưa vào danh sách hỏi khi có một trong các từ khóa trong `GHI_CHU_QUAN_TRONG`. Ghi chú của VT được bắt nhờ từ "lỗi". Ghi chú tương tự không có từ khóa đó sẽ bị bỏ qua.

## 5. Đối chiếu tổng VT với bảng hợp nhất

| Chỉ tiêu | Số tiền (đ) | Nguồn |
|---|---:|---|
| Tổng chi nhánh tự ghi (ô G156) | 250.994.000 | `kiem_tra.csv` |
| Tổng 150 dòng đọc được | 250.994.000 | `kiem_tra.csv` |
| Tổng cộng tay độc lập từ file gốc (không qua gop.py) | 250.994.000 | script tạm đọc riêng |
| Trừ 2 dòng trùng | 645.000 | `viec_can_hoi.csv` |
| Tổng VT trong bảng hợp nhất (148 dòng) | 250.349.000 | `hop_nhat.csv`, `tong_hop_chi_nhanh.csv` |
| Chênh lệch (file ghi - hợp nhất) | 645.000 | `kiem_tra.csv` |

**Giải thích chênh lệch:** toàn bộ 645.000 đ là 2 dòng trùng bị loại (VT00072 dòng 78: 555.000 đ; VT00128 dòng 135: 90.000 đ). Tổng chi nhánh ghi bằng tổng 150 dòng đọc được, tức tổng của VT đã cộng cả 2 dòng nhập lặp. Không còn phần nào chưa giải thích: không có dòng ngoài kỳ, không có dòng cần người quyết (`CAN_NGUOI_QUYET`) và không có dòng lệch SL x đơn giá.

Trạng thái 148 dòng tính vào tổng hợp: OK 90, SUY_RA 58.

## 6. Kiểm tra 6 chi nhánh cũ không bị ảnh hưởng

Chạy `gop_truoc_khi_sua.py` trên 6 file cũ (danh mục 6 chi nhánh) rồi so với kết quả bản mới (7 chi nhánh) sau khi bỏ các dòng của VT:

- `hop_nhat.csv`: giống hệt từng dòng
- `tong_hop_chi_nhanh.csv`: giống hệt từng dòng
- `tong_hop_chi_nhanh_san_pham.csv`: giống hệt từng dòng
- `kiem_tra.csv`: giống hệt từng dòng
- `viec_can_hoi.csv`: giống hệt từng dòng
- Tổng doanh thu 6 chi nhánh cũ: 1.503.750.000 đ. Tổng 7 chi nhánh: 1.754.099.000 đ. Hiệu: 250.349.000 đ, bằng tổng VT trong bảng hợp nhất.
