"""Ẩn danh bảng chấm công TRƯỚC KHI đưa cho agent chạy trên đám mây.

Nguyên tắc: agent chỉ thấy mã ngẫu nhiên (NV-001...), không thấy họ tên, phòng ban, ghi chú đơn nghỉ.
Bảng đối chiếu mã <-> họ tên ở lại máy của bạn (ket-qua/bang-ma-hoa.csv), KHÔNG nằm trong thư mục agent làm việc.

Chạy:
  python -X utf8 an_danh.py                 -> đọc goc/, ghi an-danh/*.csv và ../ket-qua/bang-ma-hoa.csv, rồi tự kiểm rò rỉ
  python -X utf8 an_danh.py --dap-an        -> đổi ../ket-qua/dap-an-goc.json sang mã ẩn danh (dap-an.json), chỉ để chấm bài mẫu
  python -X utf8 an_danh.py --giai-ma <file.csv> <ra.csv>   -> gắn lại họ tên vào kết quả agent trả về (làm TRÊN MÁY BẠN)
"""
import csv, json, random, re, sys, unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent
GOC, AD, KQ = HERE / "goc", HERE / "an-danh", HERE.parent / "ket-qua"
SALT = 7777   # đổi số này ở công ty thật; giữ bí mật cùng bảng mã hóa

def strip_accents(s):
    s = unicodedata.normalize("NFD", s).replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in s if unicodedata.category(c) != "Mn")

def read(p):
    with open(p, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))

def write(p, rows, cols):
    with open(p, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)

def norm_id(x): return str(int(x.strip())) if x.strip().isdigit() else x.strip()

def build_mapping():
    nv = read(GOC / "nhan_vien.csv")
    ids = [norm_id(r["Mã NV"]) for r in nv]
    # các mã xuất hiện trong dữ liệu quẹt nhưng không có trong danh sách: vẫn phải được đặt mã ẩn danh
    extra = sorted({norm_id(r["Mã NV"]) for r in read(GOC / "xuat_may_cham_cong.csv")} - set(ids))
    allids = ids + extra
    rnd = random.Random(SALT); order = list(range(1, len(allids) + 1)); rnd.shuffle(order)
    m = {i: f"NV-{n:03d}" for i, n in zip(allids, order)}
    by_name = {r["Họ tên"]: norm_id(r["Mã NV"]) for r in nv}
    return m, by_name, nv, extra

def main():
    AD.mkdir(exist_ok=True); KQ.mkdir(exist_ok=True)
    m, by_name, nv, extra = build_mapping()
    # 1) quẹt: bỏ Họ tên, Phòng ban; giữ nguyên chuỗi thời gian (kể cả dòng lỗi, để agent tự phát hiện)
    rows = [dict(ma_may=r["Mã máy"], ma_nv=m[norm_id(r["Mã NV"])], thoi_gian=r["Thời gian"]) for r in read(GOC / "xuat_may_cham_cong.csv")]
    write(AD / "cham_cong.csv", rows, ["ma_may", "ma_nv", "thoi_gian"])
    # 2) lịch ca xoay: đổi họ tên -> mã
    write(AD / "lich_ca_xoay.csv", [dict(ma_nv=m[by_name[r["Họ tên"]]], ngay=r["Ngày"], ca=r["Ca"]) for r in read(GOC / "lich_ca_xoay.csv")],
          ["ma_nv", "ngay", "ca"])
    # 3) đơn nghỉ phép: bỏ Ghi chú (có thể chứa chuyện sức khỏe, gia đình), bỏ họ tên
    write(AD / "nghi_phep.csv", [dict(ma_nv=m[by_name[r["Họ tên"]]], tu_ngay=r["Từ ngày"], den_ngay=r["Đến ngày"], loai=r["Loại nghỉ"], trang_thai=r["Trạng thái"])
                                 for r in read(GOC / "don_nghi_phep.csv")], ["ma_nv", "tu_ngay", "den_ngay", "loai", "trang_thai"])
    # 4) danh sách nhân viên: chỉ mã, chi nhánh, loại ca
    write(AD / "nhan_vien.csv", sorted([dict(ma_nv=m[norm_id(r["Mã NV"])], chi_nhanh=r["Chi nhánh"], loai_ca=r["Loại ca"]) for r in nv], key=lambda r: r["ma_nv"]),
          ["ma_nv", "chi_nhanh", "loai_ca"])
    # 5) bảng mã hóa: Ở LẠI MÁY BẠN
    write(KQ / "bang-ma-hoa.csv", sorted([dict(ma_an_danh=m[norm_id(r["Mã NV"])], ma_goc=r["Mã NV"], ho_ten=r["Họ tên"], phong_ban=r["Phòng ban"]) for r in nv],
                                          key=lambda r: r["ma_an_danh"]) +
          [dict(ma_an_danh=m[e], ma_goc=e, ho_ten="(mã không có trong danh sách)", phong_ban="") for e in extra], ["ma_an_danh", "ma_goc", "ho_ten", "phong_ban"])
    # 6) tự kiểm rò rỉ: tên đầy đủ (có dấu, không dấu), từng từ của họ tên dài >= 3 ký tự, mã gốc
    blob = "\n".join((AD / f).read_text(encoding="utf-8") for f in ("cham_cong.csv", "lich_ca_xoay.csv", "nghi_phep.csv", "nhan_vien.csv"))
    blob_l = strip_accents(blob).lower()
    leaks = []
    for r in nv:
        full = r["Họ tên"]
        if full in blob or strip_accents(full).lower() in blob_l: leaks.append(("họ tên", full))
        mg = r["Mã NV"]
        if re.search(rf"(?<![\w-]){re.escape(mg)}(?![\w:/-])", blob): leaks.append(("mã gốc", mg))
    for kw in ["Kế toán", "Kinh doanh", "Chăm sóc", "đi du lịch", "khám bệnh", "con ốm", "về quê"]:
        if kw.lower() in blob.lower(): leaks.append(("từ khóa", kw))
    print(f"đã ẩn danh {len(m)} mã ({len(extra)} mã lạ ngoài danh sách). Rò rỉ phát hiện: {leaks if leaks else 'KHÔNG'}")
    if leaks: sys.exit(1)

def dap_an():
    m, *_ = build_mapping()
    d = json.loads((KQ / "dap-an-goc.json").read_text(encoding="utf-8"))
    mp = lambda x: m.get(x, x)
    for r in d["ngay"]: r["ma_nv"] = mp(r["ma_nv"])
    for r in d["bat_thuong"]: r["ma_nv"] = mp(r["ma_nv"])
    for r in d["so_do_bay"]: r["ma_nv"] = mp(r["ma_nv"])
    d["tong_hop"] = {mp(k): v for k, v in d["tong_hop"].items()}
    (KQ / "dap-an.json").write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    print("đã ghi", KQ / "dap-an.json")

def giai_ma(src, dst):
    tbl = {r["ma_an_danh"]: r["ho_ten"] for r in read(KQ / "bang-ma-hoa.csv")}
    rows = read(src); cols = list(rows[0].keys())
    for r in rows:
        r["ho_ten"] = tbl.get(r.get("ma_nv", ""), "")
        # câu giải thích do mô hình viết có thể nhắc mã: thay mã bằng tên khi in cho quản lý
        for k, v in r.items():
            if isinstance(v, str) and k != "ma_nv":
                r[k] = re.sub(r"NV-\d{3}", lambda mo: tbl.get(mo.group(0), mo.group(0)), v)
    write(dst, rows, cols + ["ho_ten"])
    print("đã gắn họ tên ->", dst)

if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["--dap-an"]: dap_an()
    elif a[:1] == ["--giai-ma"]: giai_ma(a[1], a[2])
    else: main()
