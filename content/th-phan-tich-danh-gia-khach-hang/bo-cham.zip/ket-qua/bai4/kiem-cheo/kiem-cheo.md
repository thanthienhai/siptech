# Kiểm chéo đầu ra (do kiem-cheo.py đếm)
Số dòng đã kiểm: y-kien.csv (trich_dan) 404; nguy-cap.csv (trich_dan) 18; bao-cao.md (dòng trích dẫn) 15; bao-cao.md (ô số trong bảng) 40.
Không qua: 3 dòng (bao-cao.md 2; y-kien.csv 1).
- y-kien.csv | R105 | "đồ uống rất ổn" | không phải chuỗi con nguyên văn: không tìm thấy trong noi_dung của mã này (diễn đạt lại hoặc sửa chữ)
- bao-cao.md | R170 | "tối cả hai vợ chồng nôn mửa và tiêu chảy, phải đi cấp cứu" | không phải chuỗi con nguyên văn: không tìm thấy trong noi_dung của mã này (diễn đạt lại hoặc sửa chữ)
- bao-cao.md | gia | "Tiêu cực = '48'" | bảng ghi 48, đếm lại từ y-kien.csv được 44
Script này KHÔNG kiểm được: ý nghĩa (chủ đề và sắc thái gán có đúng không, có sót ý hay loại bỏ/gắn nguy cấp nhầm không), cũng như văn xuôi, xu-huong-tuan.csv và cột ly_do, vì nó chỉ so chuỗi con và số đếm.
