import pandas as pd
import openpyxl, re, csv, unicodedata

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
df_orders['amount'] = df_orders['Tổng phải thu'].apply(clean_amount)
df_orders['kh_clean'] = df_orders['Khách hàng'].apply(strip_accents).str.upper()

print(f"Total orders: {len(df_orders)}")
for idx, r in df_orders.iterrows():
    print(f"{r['Mã đơn']} | {str(r['Ngày đặt'])[:10]} | {r['Khách hàng']:<18s} | {r['amount']:>9,d} | {r['Hình thức TT']:3s} | {r['Trạng thái']:<10s} | {r['Ghi chú']}")
