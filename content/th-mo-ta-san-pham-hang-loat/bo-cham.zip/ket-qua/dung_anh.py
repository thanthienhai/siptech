"""Dựng lại TOÀN BỘ ảnh trong ../anh/ từ log và file kết quả đã che.

Chạy:  python -X utf8 dung_anh.py [thư_mục_agentlab]
- thư_mục_agentlab: nơi có term.py (mặc định: ../../../../../siptech-video/agentlab so với file này,
  hoặc biến môi trường AGENTLAB_DIR).
Mọi chuỗi lấy từ log hoặc từ file đều đi qua term.scrub_text trước khi vào HTML (che đường dẫn máy, tên tổ chức, email).
Ảnh terminal là bản dựng lại từ log thật, không phải ảnh chụp trực tiếp cửa sổ TUI.
"""
import csv, html, json, os, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BAI = HERE.parent
ANH = BAI / "anh"
LOGS = BAI / "logs"
AGENTLAB = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(os.environ.get("AGENTLAB_DIR", HERE.parents[4] / "siptech-video" / "agentlab"))
sys.path.insert(0, str(AGENTLAB))
from term import render_blocks, shot_html, scrub_text  # noqa: E402

import re


def S(x):
    """scrub_text của term.py + che cột chủ sở hữu trong kết quả `ls -l` (tên người dùng Windows)."""
    if not isinstance(x, str):
        return x
    x = scrub_text(x)
    return re.sub(r"(?<=\s)PC(?=\s+\d{4,}\s)", "user", x)


def scrub_blocks(blocks):
    out = []
    for b in blocks:
        b = dict(b)
        for k in ("text", "output"):
            if k in b:
                b[k] = S(b[k])
        if isinstance(b.get("input"), (dict, list)):
            b["input"] = json.loads(S(json.dumps(b["input"], ensure_ascii=False)))
        out.append(b)
    return out

esc = lambda s: html.escape(S(s))


def terminal(log, out_png, title, a, b, maxlines, show_prompt=False, width=1280):
    t = json.loads((LOGS / f"{log}.json").read_text(encoding="utf-8"))
    h = render_blocks(scrub_blocks(t["blocks"][a:b]), S(title), S(t["prompt"]), maxlines, width, show_prompt)
    shot_html(h, ANH / out_png, width + 40, ".win")
    print("ảnh:", out_png)


def load_csv(rel):
    with open(BAI / rel, encoding="utf-8-sig", newline="") as f:
        return {r["sku"]: r for r in csv.DictReader(f)}


# 01: prompt giao việc (nguyên văn prompt-v1.txt)
def anh_prompt():
    p = (BAI / "ket-qua" / "prompt-v1.txt").read_text(encoding="utf-8")
    out = []
    for ln in p.splitlines():
        e = esc(ln)
        out.append(f'<div class=h>{e}</div>' if ln.startswith("# ") else f'<div>{e or "&nbsp;"}</div>')
    h = ('''<!doctype html><meta charset=utf-8><style>body{margin:0;background:#e9edf5;font-family:'Segoe UI',sans-serif}
.w{width:1180px;padding:20px 26px;background:#fff;border-left:6px solid #0b1f4d;font-size:15px;line-height:1.5;color:#1e293b}
.h{font-weight:700;color:#0b1f4d;margin-top:10px;font-size:16px}</style><div class=w>''' + "".join(out) + "</div>")
    shot_html(h, ANH / "01-prompt-giao-viec.png", 1240, ".w")
    print("ảnh: 01-prompt-giao-viec.png")


# 03-du-lieu-dau-vao: 8 dòng mẫu của thong_so.csv
def anh_du_lieu():
    rows = load_csv("du-lieu/thong_so.csv")
    pick = ["VN-004", "VN-007", "VN-009", "VN-012", "VN-019", "VN-024", "VN-027", "VN-029"]
    cols = ["sku", "ten_san_pham", "dung_tich", "thanh_phan_noi_bat", "xuat_xu", "han_su_dung", "so_phieu_cong_bo", "ghi_chu_noi_bo"]
    req = {"dung_tich", "thanh_phan_noi_bat", "xuat_xu", "han_su_dung"}
    miss = ("", "?", "chưa rõ", "liên hệ ncc", "n/a", "chưa có")

    def cell(c, v):
        s = v.strip()
        if c in req and s.lower() in miss:
            return f'<td class="m">{esc(s) if s else "(trống)"}</td>'
        return f"<td>{esc(v)}</td>"
    h = '''<!doctype html><meta charset=utf-8><style>body{margin:0;font-family:'Segoe UI',sans-serif;background:#fff}
.w{padding:18px;width:1500px}h3{margin:0 0 4px;font-size:18px;color:#0b1f4d}p{margin:0 0 10px;color:#475569;font-size:13px}
table{border-collapse:collapse;font-size:13px;width:100%}th{background:#0b1f4d;color:#fff;padding:7px 8px;text-align:left}
td{border:1px solid #cbd5e1;padding:6px 8px;vertical-align:top}td.m{background:#fee2e2;color:#991b1b;font-style:italic}
td:last-child{background:#fef9c3}</style><div class=w><h3>thong_so.csv - 8 trong 40 dòng (dữ liệu giả để học, shop "Vườn Nhỏ" không có thật)</h3>
<p>Ô đỏ: thông tin bắt buộc bị thiếu (ghi lẫn lộn: trống, ?, N/A, chưa rõ, liên hệ NCC). Cột vàng: ghi_chu_noi_bo - lời đồn chưa kiểm chứng, không phải sự thật.</p><table><tr>'''
    h += "".join(f"<th>{c}</th>" for c in cols) + "</tr>"
    for k in pick:
        h += "<tr>" + "".join(cell(c, rows[k][c]) for c in cols) + "</tr>"
    h += "</table></div>"
    shot_html(h, ANH / "03-du-lieu-dau-vao.png", 1540, ".w")
    print("ảnh: 03-du-lieu-dau-vao.png")


# 05: đầu ra thật của Claude lần 1
def anh_dau_ra():
    rows = load_csv("ket-qua/claude-v1-lan1/nhap_hang_loat.csv")

    def hl(s):
        return esc(s).replace("CẦN BỔ SUNG", "<mark>CẦN BỔ SUNG</mark>")

    def card(k):
        r = rows[k]
        g = "".join(f"<li>{hl(r[f'gach_{i}'])}</li>" for i in range(1, 6))
        return (f'<div class=c><div class=k>{k} · <span class="s {r["trang_thai"]}">{r["trang_thai"]}</span> {hl(r["truong_can_bo_sung"])}</div>'
                f'<div class=t>{hl(r["tieu_de"])}</div><div class=d>{hl(r["mo_ta"])}</div><ul>{g}</ul><div class=kw>từ khóa: {hl(r["tu_khoa"])}</div></div>')
    h = '''<!doctype html><meta charset=utf-8><style>body{margin:0;font-family:'Segoe UI',sans-serif;background:#fff}
.w{width:1500px;padding:18px}h3{margin:0 0 8px;color:#0b1f4d}.g{display:flex;gap:14px}.c{flex:1;border:1px solid #cbd5e1;border-radius:8px;padding:12px;font-size:13px;line-height:1.45}
.k{font-weight:700;color:#475569;margin-bottom:4px}.s{padding:1px 7px;border-radius:9px;color:#fff;font-size:12px}.SAN_SANG{background:#15803d}.CAN_BO_SUNG{background:#b45309}
.t{font-weight:700;color:#0b1f4d;margin-bottom:6px}.d{margin-bottom:6px}ul{margin:4px 0 6px 16px;padding:0}.kw{color:#64748b;font-size:12px}mark{background:#fde68a;font-weight:700}</style>
<div class=w><h3>Đầu ra thật của Claude Code (claude-v1-lan1): 3 trong 40 dòng nhập hàng loạt. Dữ liệu giả để học.</h3><div class=g>'''
    h += card("VN-004") + card("VN-019") + card("VN-007") + "</div></div>"
    shot_html(h, ANH / "05-ket-qua-dau-ra-claude.png", 1540, ".w")
    print("ảnh: 05-ket-qua-dau-ra-claude.png")


# 06: lỗi cụm ngoài bảng
def anh_loi():
    a2 = load_csv("ket-qua/agy-v1-lan2/nhap_hang_loat.csv")
    a1 = load_csv("ket-qua/agy-v1-lan1-mat-log/nhap_hang_loat.csv")
    c2 = load_csv("ket-qua/claude-v1-lan2/nhap_hang_loat.csv")

    def hl(s, terms):
        s = esc(s)
        for t in terms:
            s = s.replace(html.escape(t), f"<mark>{html.escape(t)}</mark>")
        return s

    def card(title, r, cols, terms, note, ok=False):
        body = "".join(f"<div class=f><b>{c}</b>: {hl(r[c], terms)}</div>" for c in cols)
        return f'<div class="c{" ok" if ok else ""}"><div class=h>{title}</div>{body}<div class=n>{note}</div></div>'
    h = '''<!doctype html><meta charset=utf-8><style>body{margin:0;font-family:'Segoe UI',sans-serif;background:#fff}
.w{width:1500px;padding:18px}h3{margin:0 0 8px;color:#0b1f4d}.g{display:flex;gap:14px}.c{flex:1;border:1px solid #cbd5e1;border-radius:8px;padding:12px;font-size:13px;line-height:1.45}
.h{font-weight:700;color:#0b1f4d;margin-bottom:6px}.f{margin-bottom:5px;white-space:pre-wrap}mark{background:#fca5a5;font-weight:700}.n{margin-top:8px;color:#991b1b;font-size:12.5px}.ok .n{color:#15803d}</style>
<div class=w><h3>Lỗi thật trong đầu ra: cụm KHÔNG có trong bảng thông số (dữ liệu giả để học)</h3><div class=g>'''
    h += card("agy lần 2, VN-001: mo_ta + tu_khoa", a2["VN-001"], ["mo_ta", "tu_khoa"], ["phân phối chính hãng", "chính hãng"], "Bảng không nói hàng chính hãng. Lỗi lặp: mô tả 40/40 SKU, từ khóa 37/40 SKU.")
    h += card("agy lần 1, VN-007: tu_khoa", a1["VN-007"], ["tu_khoa"], ["sản phẩm lành tính"], 'Bảng của VN-007 trống gần hết; "lành tính" là cụm tự thêm. Chỉ 1 dòng.')
    h += card("claude lần 2, VN-001: tu_khoa", c2["VN-001"], ["tu_khoa"], [], "Từ khóa chỉ lấy từ tên, thành phần, loại da, hương, xuất xứ có trong bảng.", True)
    h += "</div></div>"
    shot_html(h, ANH / "06-loi-cum-ngoai-bang.png", 1540, ".w")
    print("ảnh: 06-loi-cum-ngoai-bang.png")


# 07: bảng chấm
def anh_cham():
    d = json.loads((BAI / "ket-qua" / "bao-cao-cham.json").read_text(encoding="utf-8"))
    names = [("claude-v1-lan1", "Claude Code lần 1"), ("claude-v1-lan2", "Claude Code lần 2"),
             ("agy-v1-lan1-mat-log", "Antigravity lần 1 (mất log)"), ("agy-v1-lan2", "Antigravity lần 2")]
    rows = [("SKU sạch hoàn toàn (/40)", "sku_sach_hoan_toan"), ("Đủ 5 gạch (/40)", "dung_5_gach"),
            ("Vi phạm độ dài (SKU)", ["dai_tieu_de", "dai_mo_ta", "dai_gach", "dai_tukhoa"]), ("Có từ cấm (SKU)", "tu_cam"),
            ("Số ngoài bảng (SKU)", "so_bia"), ("Cụm ngoài bảng (SKU)", "lexicon_bia"), ("Rò ghi chú (SKU)", "ro_ghi_chu"),
            ("Công bố sai (SKU)", "cong_bo_sai"), ("Giọng sai (SKU)", "giong_sai"),
            ("SKU thiếu: gắn CẦN BỔ SUNG (/9)", "miss_flag_ok"), ("SKU thiếu: trường thiếu đúng hệt (/9)", "miss_fields_exact"),
            ("SKU đủ: báo động giả (/31)", "false_alarm")]
    t = "<tr><th></th>" + "".join(f"<th>{n}</th>" for _, n in names) + "</tr>"
    for lab, k in rows:
        t += f"<tr><td>{lab}</td>"
        for l, _ in names:
            T = d[l]["tong"]
            v = sum(T[x] for x in k) if isinstance(k, list) else T[k]
            bad = (k in ("tu_cam", "so_bia", "lexicon_bia", "ro_ghi_chu", "cong_bo_sai", "giong_sai", "false_alarm") or isinstance(k, list)) and v > 0
            t += f'<td class="{"b" if bad else ""}">{v}</td>'
        t += "</tr>"
    h = '''<!doctype html><meta charset=utf-8><style>body{margin:0;font-family:'Segoe UI',sans-serif;background:#fff}.w{width:1250px;padding:18px}h3{margin:0 0 4px;color:#0b1f4d}p{margin:0 0 10px;color:#475569;font-size:13px}
table{border-collapse:collapse;font-size:14px;width:100%}th{background:#0b1f4d;color:#fff;padding:8px;text-align:center}th:first-child,td:first-child{text-align:left}td{border:1px solid #cbd5e1;padding:7px 10px;text-align:center}td.b{background:#fee2e2;color:#991b1b;font-weight:700}</style>
<div class=w><h3>Kết quả chấm bằng code (cham.py), 40 SKU, 4 lần chạy</h3><p>[Đo được] 2026-11-20, n=2 lần mỗi agent. Dữ liệu giả để học. Cụm ngoài bảng do danh sách tay LEXICON, không phải kiểm toàn diện.</p><table>''' + t + "</table></div>"
    shot_html(h, ANH / "07-bang-cham.png", 1290, ".w")
    print("ảnh: 07-bang-cham.png")


if __name__ == "__main__":
    ANH.mkdir(exist_ok=True)
    anh_prompt()
    terminal("claude-v1-lan1", "02-claude-dang-lam.png", "claude · đang làm (trích các bước)", 1, 13, 5)
    terminal("agy-v1-lan2", "03-agy-dang-lam.png", "agy · đang làm (trích các bước)", 3, 16, 5)
    terminal("claude-v1-lan1", "04-claude-ket-qua-cuoi.png", "claude · báo cáo cuối", 17, 18, 40)
    terminal("agy-v1-lan2", "04b-agy-ket-qua-cuoi.png", "agy · báo cáo cuối", 42, 43, 40)
    anh_du_lieu()
    anh_dau_ra()
    anh_loi()
    anh_cham()
