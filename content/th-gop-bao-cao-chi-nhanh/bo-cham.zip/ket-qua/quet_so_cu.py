"""Bài 3: tìm mã chứng từ của THÁNG TRƯỚC còn nằm trong chữ giải thích của tháng này.

Dùng:  python -X utf8 quet_so_cu.py <thư_mục_ra_tháng_này> <thư_mục_ra_tháng_trước>
Ví dụ: python -X utf8 ket-qua\\quet_so_cu.py thang-11\\ra thang-10\\ra

Cách làm: lấy mọi số chứng từ trong ra_tháng_trước/hop_nhat.csv, bỏ những mã cũng có trong hop_nhat.csv của tháng này
(mã đánh số liền như HN-0001 tháng nào cũng có, không dùng để dò), rồi tìm các mã còn lại trong
kiem_tra.csv, bao_cao.md, viec_can_hoi.csv của tháng này. Mã còn sót nghĩa là script đã gõ cứng chữ giải thích của tháng cũ.
Không cần đáp án. Thoát mã 1 nếu còn sót.
"""
import csv
import sys
from pathlib import Path


def doc_ma(f):
    with open(f, encoding="utf-8-sig", newline="") as fh:
        return {r["so_chung_tu"].strip() for r in csv.DictReader(fh) if r.get("so_chung_tu", "").strip()}


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    nay, truoc = Path(sys.argv[1]), Path(sys.argv[2])
    dung_de_do = doc_ma(truoc / "hop_nhat.csv") - doc_ma(nay / "hop_nhat.csv")
    tong = 0
    for ten in ("kiem_tra.csv", "bao_cao.md", "viec_can_hoi.csv"):
        f = nay / ten
        if not f.exists():
            print(f"{ten}: không có file")
            continue
        van_ban = f.read_text(encoding="utf-8-sig")
        sot = sorted(m for m in dung_de_do if m in van_ban)
        tong += len(sot)
        print(f"{ten}: {len(sot)} mã của tháng trước còn sót" + (f" (ví dụ {', '.join(sot[:3])})" if sot else ""))
    print("KHÔNG ĐẠT: có chữ của tháng cũ" if tong else "ĐẠT: không thấy mã của tháng trước")
    sys.exit(1 if tong else 0)


if __name__ == "__main__":
    main()
