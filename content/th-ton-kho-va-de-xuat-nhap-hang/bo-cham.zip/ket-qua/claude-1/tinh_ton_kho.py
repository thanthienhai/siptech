#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tinh_ton_kho.py - chay tu dau den cuoi trong thu muc nay:  python tinh_ton_kho.py

Doc : nhat-ky-xuat-nhap.csv, danh-muc-hang.csv, ton-dau-ky-2025-11-01.csv,
      ton-kiem-ke-2026-10-31.csv, hang-dang-ve.csv, tham-so.json (+ quy-uoc.md la cong thuc)
Ghi : loi-du-lieu.csv, phan-loai-tinh-toan.csv, de-xuat-nhap.csv,
      giu-lai-do-loi.csv, bao-cao.md
Khong sua file du lieu goc. Chi dung thu vien chuan cua Python.

Cong thuc lay NGUYEN VAN tu quy-uoc.md (khong doi). Cac cho quy-uoc.md de ngo
(thang hop le, thu tu uu tien khi cat ngan sach, xu ly ca nghi ngo...) duoc ghi ro
trong muc "Gia dinh" cua bao-cao.md.
"""
import csv
import json
import math
import os
import re
import statistics
import sys
import unicodedata
from collections import defaultdict, Counter
from datetime import date, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))


def P(name):
    return os.path.join(HERE, name)


# ----------------------------------------------------------------------------
# 0. Tham so
# ----------------------------------------------------------------------------
PARAM = json.load(open(P("tham-so.json"), encoding="utf-8"))
Z = PARAM["z_tuong_ung"]                       # 1.645
NGAN_SACH = PARAM["ngan_sach_nhap_vnd"]        # 30.000.000
NGUONG_TON_LAU = PARAM["nguong_ton_lau_ngay"]  # 120
NGUONG_KHONG_BAN = PARAM["nguong_khong_ban_ngay"]  # 90
NGUONG_BAN_CHAM = PARAM["nguong_ban_cham_don_vi_thang"]  # 3
NGAY_CUT = PARAM["so_ngay_cut_hang_toi_thieu"]  # 7
END = date.fromisoformat(PARAM["ngay_cuoi_du_lieu"])  # 2026-10-31
START = date(2025, 11, 1)
THANG_DE_XUAT = PARAM["thang_de_xuat"]
HOLDOUT = PARAM["thang_giu_lai_do_loi"]


def month_range():
    out, y, m = [], 2025, 11
    while (y, m) <= (2026, 10):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


MONTHS = month_range()  # 12 thang


def read_csv(name):
    with open(P(name), encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(name, header, rows):
    with open(P(name), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            w.writerow([r.get(h, "") for h in header])


def strip_accent(s):
    s = s.lower().replace("đ", "d")
    s = unicodedata.normalize("NFD", s)
    return "".join(c for c in s if unicodedata.category(c) != "Mn").strip()


def ceil_(x):
    return int(math.ceil(round(x, 9)))


# ----------------------------------------------------------------------------
# 1. Doc du lieu
# ----------------------------------------------------------------------------
CAT = {r["ma_hang"]: r for r in read_csv("danh-muc-hang.csv")}
ITEMS = list(CAT.keys())
OPEN = {r["ma_hang"]: int(r["ton_dau_ky"]) for r in read_csv("ton-dau-ky-2025-11-01.csv")}
KK = {r["ma_hang"]: int(r["ton_thuc_te_kiem_ke"]) for r in read_csv("ton-kiem-ke-2026-10-31.csv")}
INCOMING = defaultdict(int)
INCOMING_DATE = {}
for r in read_csv("hang-dang-ve.csv"):
    INCOMING[r["ma_hang"]] += int(r["so_luong"])
    INCOMING_DATE[r["ma_hang"]] = r["ngay_du_kien_ve"]
NAME2CODE = {strip_accent(v["ten_hang"]): k for k, v in CAT.items()}
RAW = read_csv("nhat-ky-xuat-nhap.csv")


def parse_date(s):
    """yyyy-mm-dd, dd/mm/yyyy, d/m/yy  (kieu Viet Nam: NGAY truoc THANG)."""
    s = s.strip()
    if re.fullmatch(r"\d{4}-\d{1,2}-\d{1,2}", s):
        y, m, d = map(int, s.split("-"))
        return date(y, m, d), "yyyy-mm-dd"
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{2,4})", s)
    if not m:
        raise ValueError("ngay khong doc duoc: " + s)
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if y < 100:
        y += 2000
    return date(y, mo, d), "dd/mm/yyyy" if len(m.group(3)) == 4 else "d/m/yy"


def norm_code(c):
    return re.sub(r"[\s\-]", "", c).upper()


# ----------------------------------------------------------------------------
# 2. Lam sach + ghi loi
# ----------------------------------------------------------------------------
LOI = []  # moi phan tu: dict ma_phieu, loai_loi, ma_hang, xu_ly, ly_do


def add_loi(ma_phieu, loai, ma_hang, xu_ly, ly_do):
    LOI.append(dict(ma_phieu=ma_phieu, loai_loi=loai, ma_hang=ma_hang, xu_ly=xu_ly, ly_do=ly_do))


fmt_date_counter = Counter()
fmt_code_counter = Counter()
for i, r in enumerate(RAW):
    r["_i"] = i
    r["d"], fmt = parse_date(r["ngay"])
    fmt_date_counter[fmt] += 1
    raw_code = r["ma_hang"]
    r["fixed_code_by_name"] = False
    if raw_code.strip() == "":
        r["mh"] = NAME2CODE.get(strip_accent(r["ten_hang"]), "")
        r["fixed_code_by_name"] = True
    else:
        r["mh"] = norm_code(raw_code)
        if raw_code != r["mh"]:
            fmt_code_counter["lech chuan (thuong/gach/khoang trang)"] += 1
    r["q"] = int(r["so_luong"]) if r["so_luong"].strip() != "" else None

# ---- 2a. dong trung (cung ma_phieu): giu dong dau, bo dong sau
seen = {}
for r in RAW:
    r["dup"] = False
    if r["ma_phieu"] in seen:
        r["dup"] = True
        first = seen[r["ma_phieu"]]
        same = (first["mh"] == r["mh"] and first["q"] == r["q"] and first["d"] == r["d"] and first["loai"] == r["loai"])
        add_loi(r["ma_phieu"], "trung_dong", r["mh"], "BO",
                "Trung ma phieu voi dong dau (cung ma hang, so luong, ngay"
                + ("" if same else " - khac nhau") + "; chi khac cach viet ngay/ten). Giu dong dau, bo dong sau.")
    else:
        seen[r["ma_phieu"]] = r

# ---- 2b. dong thieu ma hang: do theo ten
for r in RAW:
    if r["fixed_code_by_name"]:
        if r["mh"]:
            add_loi(r["ma_phieu"], "khac", r["mh"], "SUA",
                    f"Thieu ma hang; do theo ten '{r['ten_hang']}' -> {r['mh']} (khop duy nhat voi danh muc).")
        else:
            add_loi(r["ma_phieu"], "khac", "", "CAN_NGUOI_QUYET", f"Thieu ma hang va khong do duoc theo ten '{r['ten_hang']}'.")

# ---- 2c. ngay o tuong lai (sau 2026-10-31)
# Dung lam moc: ngay cua phieu hop le ngay truoc trong cung loai (so phieu tang dan theo ngay).
valid_by_prefix = defaultdict(list)
for r in RAW:
    if not r["dup"] and r["d"] <= END:
        valid_by_prefix[r["ma_phieu"][:2]].append(r)
for r in RAW:
    r["d_eff"] = r["d"]
    r["future_fix"] = False
    if r["d"] > END and not r["dup"]:
        pre = r["ma_phieu"][:2]
        prev = [x for x in valid_by_prefix[pre] if x["ma_phieu"] < r["ma_phieu"]]
        prev.sort(key=lambda x: x["ma_phieu"])
        nxt = [x for x in valid_by_prefix[pre] if x["ma_phieu"] > r["ma_phieu"]]
        nxt.sort(key=lambda x: x["ma_phieu"])
        lo = prev[-1]["d"]
        hi = nxt[0]["d"] if nxt else END
        r["d_eff"] = lo
        r["future_fix"] = True
        add_loi(r["ma_phieu"], "ngay_o_tuong_lai", r["mh"], "CAN_NGUOI_QUYET",
                f"Ngay ghi {r['d'].isoformat()} (sau ngay cuoi du lieu {END}), nhung so phieu nam giua phieu ngay {lo} va {hi}. "
                f"Doi chieu kiem ke: ton kiem ke cao hon ton he thong dung {r['q']} don vi => hang co ve de nhan. "
                f"Tam dung ngay {lo} (can duoi) de tinh ton; xin chu xac nhan ngay that.")

# ---- 2d. so luong thieu
for r in RAW:
    if r["dup"]:
        continue
    if r["q"] is None:
        add_loi(r["ma_phieu"], "thieu_so_luong", r["mh"], "CAN_NGUOI_QUYET",
                "O so_luong de trong. Khong biet so that nen khong dien. Tam tinh 0 (khong tru ton, khong tinh nhu cau); xin chu cho so that.")

# ---- 2e. so am khong ghi chu (XUAT)
for r in RAW:
    if r["dup"] or r["q"] is None:
        continue
    if r["loai"] == "XUAT" and r["q"] < 0 and not r["ghi_chu"].strip():
        add_loi(r["ma_phieu"], "so_am_khong_ghi_chu", r["mh"], "CAN_NGUOI_QUYET",
                f"XUAT so am ({r['q']}) khong ghi 'khach tra'. Co the la khach tra hang quen ghi chu, hoac go nham dau. "
                f"Doi chieu kiem ke ung ho cach 'go nham dau, that ra la ban {abs(r['q'])}'. Tam tinh la ban {abs(r['q'])}; xin chu xac nhan.")
        r["sign_fix"] = True

# ---- 2f. so luong bat thuong / don si mot lan (chi xet dong XUAT ban hang so duong, khong ghi chu noi bo)
sales_qty = defaultdict(list)
for r in RAW:
    if (not r["dup"] and r["loai"] == "XUAT" and r["q"] is not None and r["q"] > 0 and r["mh"]
            and not r["ghi_chu"].strip()):
        sales_qty[r["mh"]].append(r["q"])
med = {k: statistics.median(v) for k, v in sales_qty.items()}
wholesale_in = [r for r in RAW if r["loai"] == "NHAP" and "don si" in r["ghi_chu"].lower() and not r["dup"]]
for r in RAW:
    r["kind"] = None
    if r["dup"] or r["loai"] != "XUAT" or r["q"] is None or r["q"] <= 0:
        continue
    note = r["ghi_chu"].lower()
    paired = any(w["mh"] == r["mh"] and abs((w["d_eff"] - r["d_eff"]).days) <= 3 for w in wholesale_in)
    if "khach si" in note or "dai ly" in note or (paired and r["q"] >= 50):
        r["kind"] = "SI"
        why = ("ghi chu 'Khach si - DH dai ly'" if "khach si" in note else "khong ghi chu nhung co phieu NHAP 'nhap cho don si' cung mat hang cung ngay")
        add_loi(r["ma_phieu"], "don_si_mot_lan", r["mh"], "CAN_NGUOI_QUYET",
                f"Don si {r['q']} (binh thuong ~{med.get(r['mh'], 0):g}/phieu): {why}. Hang that su da xuat (kiem ke khop) nen van tru ton; "
                f"tam KHONG tinh vao nhu cau thuong ngay vi la don mot lan; xin chu xac nhan.")
    elif not r["ghi_chu"].strip():
        m_ = med.get(r["mh"], 1)
        if r["q"] >= 20 and r["q"] >= 8 * m_:
            r["kind"] = "BAT_THUONG"

for w in wholesale_in:
    add_loi(w["ma_phieu"], "don_si_mot_lan", w["mh"], "GIU",
            f"Phieu NHAP {w['q']} ghi 'nhap cho don si' (nhap rieng cho mot don si). Hang that su ve nen van tinh vao ton.")

# so luong bat thuong: doi chieu voi kiem ke de goi y, nhung van de nguoi quyet.
# Mac dinh tam: chia 10 (loi go thua so 0) neu chia het cho 10 va ket qua nam trong khoang binh thuong cua mat hang.
for r in RAW:
    r["q_clean"] = r["q"]
    if r["kind"] == "BAT_THUONG":
        top = max(sales_qty[r["mh"]][:])  # chi de tham chieu
        cand = r["q"] // 10 if r["q"] % 10 == 0 else None
        p95 = sorted(sales_qty[r["mh"]])[int(len(sales_qty[r["mh"]]) * 0.95)]
        if cand is not None and cand <= max(p95, 5):
            r["q_clean"] = cand
            r["div10"] = True
            act = f"Tam tinh {cand} (nghi go thua so 0: {r['q']} -> {cand}); kiem ke ung ho: ton kiem ke cao hon ton he thong gan dung {r['q'] - cand} don vi neu tinh {r['q']}. Xin chu xac nhan."
        else:
            act = "Tam giu nguyen so ghi; xin chu xac nhan."
        add_loi(r["ma_phieu"], "so_luong_bat_thuong", r["mh"], "CAN_NGUOI_QUYET",
                f"Ban {r['q']} trong mot phieu, trong khi binh thuong ~{med[r['mh']]:g}/phieu (cao gap {r['q'] / max(med[r['mh']], 1):.0f} lan). {act}")

# so am khong ghi chu -> tam tinh ban |q|
for r in RAW:
    if r.get("sign_fix"):
        r["q_clean"] = abs(r["q"])

# ---- 2g. khong phai ban hang (giu trong ton, khong tinh nhu cau)
for r in RAW:
    r["nonsale"] = False
    if r["dup"]:
        continue
    note = r["ghi_chu"].lower()
    if r["loai"] == "DIEU_CHINH":
        r["nonsale"] = True
        add_loi(r["ma_phieu"], "khong_phai_ban_hang", r["mh"], "GIU",
                f"Dieu chinh kiem ke/hu hong ({r['ghi_chu']}), {r['q']}: tru vao ton, khong tinh vao nhu cau.")
    elif r["loai"] == "XUAT" and ("het han" in note or "noi bo" in note or "dung tai quan" in note):
        r["nonsale"] = True
        add_loi(r["ma_phieu"], "khong_phai_ban_hang", r["mh"], "GIU",
                f"Xuat '{r['ghi_chu']}' ({r['q']}): khong phai ban hang -> tru vao ton, khong tinh vao nhu cau.")

# ---- 2h. dong tong hop ve dinh dang
add_loi("(tong hop " + str(sum(v for k, v in fmt_date_counter.items() if k != 'yyyy-mm-dd')) + " dong)", "khac", "", "SUA",
        "Ngay viet lan lon: " + ", ".join(f"{k}={v}" for k, v in sorted(fmt_date_counter.items()))
        + ". Chuan hoa ve yyyy-mm-dd theo kieu Viet Nam (ngay truoc thang). Kiem tra: so phieu tang dan thi ngay khong giam => khong co dong nao bi dao ngay/thang.")
add_loi("(tong hop " + str(fmt_code_counter["lech chuan (thuong/gach/khoang trang)"]) + " dong)", "khac", "", "SUA",
        "Ma hang viet thuong / co dau gach / thua khoang trang (vd 'th017', 'TH-002', 'MP006 '). Chuan hoa ve dang in hoa, khong gach, khong khoang trang; tat ca khop danh muc.")


# ----------------------------------------------------------------------------
# 3. Dong chay ton + nhu cau theo thang
# ----------------------------------------------------------------------------
def month_of(d):
    return f"{d.year:04d}-{d.month:02d}"


# movements: item -> list of (date, stock_delta, demand_delta, sale_row_flag)
MOV = defaultdict(list)
RAWSALES = defaultdict(lambda: defaultdict(int))   # moc 1 tho: tong so_luong XUAT (chi chuan hoa ngay/ma), khong lam sach
for r in RAW:
    if r["mh"]:
        if r["loai"] == "XUAT" and r["q"] is not None:
            RAWSALES[r["mh"]][month_of(r["d"])] += r["q"] if r["d"] <= END else 0
    if r["dup"] or not r["mh"]:
        continue
    q = r["q_clean"]
    if q is None:
        continue
    d = r["d_eff"]
    if r["loai"] == "NHAP":
        MOV[r["mh"]].append((d, +q, 0, False))
    elif r["loai"] == "DIEU_CHINH":
        MOV[r["mh"]].append((d, q, 0, False))
    elif r["loai"] == "XUAT":
        if r["nonsale"]:
            MOV[r["mh"]].append((d, -q, 0, False))
        elif r["kind"] == "SI":
            MOV[r["mh"]].append((d, -q, 0, True))     # tru ton, KHONG tinh nhu cau, van la mot lan ban
        else:
            # ban hang binh thuong; so am co ghi 'khach tra' = tra hang: cong ton, tru nhu cau
            MOV[r["mh"]].append((d, -q, q, q > 0))

DAYS = [START + timedelta(days=i) for i in range((END - START).days + 1)]
SYS_STOCK = {}
OUT_DAYS = {}      # item -> {month: so ngay het hang}
DEMAND = {}        # item -> {month: nhu cau}
LAST_SALE = {}
for it in ITEMS:
    by_day = defaultdict(int)
    dem = defaultdict(int)
    last_sale = None
    for d, ds, dd, sale in MOV[it]:
        by_day[d] += ds
        if d <= END:
            dem[month_of(d)] += dd
        if sale and d <= END:
            if last_sale is None or d > last_sale:
                last_sale = d
    s = OPEN[it]
    outd = defaultdict(int)
    for d in DAYS:
        s += by_day.get(d, 0)
        if s <= 0:
            outd[month_of(d)] += 1
    SYS_STOCK[it] = s
    OUT_DAYS[it] = outd
    DEMAND[it] = {m: dem.get(m, 0) for m in MONTHS}
    LAST_SALE[it] = last_sale

# thang bat dau ban: hang moi co ghi chu 'ban tu thang yyyy-mm' trong danh muc; cac hang con lai ban tu dau ky
LAUNCH = {}
for it in ITEMS:
    m = re.search(r"ban tu thang (\d{4}-\d{2})", CAT[it]["ghi_chu"])
    LAUNCH[it] = m.group(1) if m else MONTHS[0]


def is_cut(it, m):
    return OUT_DAYS[it].get(m, 0) >= NGAY_CUT


def valid_months(it, before=None):
    """thang hop le (da ban + khong cut) theo thu tu thoi gian; before = chi lay thang < before"""
    out = []
    for m in MONTHS:
        if before is not None and m >= before:
            break
        if m < LAUNCH[it]:
            continue
        if is_cut(it, m):
            continue
        out.append(m)
    return out


def forecast(it, before=None, dem=None):
    """Tra ve (F, sigma, so_thang_dung, co_ngan)  theo quy-uoc muc 3, 4"""
    dem = DEMAND if dem is None else dem
    vm = valid_months(it, before)
    last3 = vm[-3:]
    if not last3:
        return 0.0, 0.0, 0, True
    F = sum(dem[it][m] for m in last3) / len(last3)
    last6 = [dem[it][m] for m in vm[-6:]]
    if len(vm) < 3:
        return F, 0.5 * F, len(vm), True
    sigma = statistics.stdev(last6) if len(last6) >= 2 else 0.0
    return F, sigma, len(vm), False


# ----------------------------------------------------------------------------
# 4. Tinh cho thang de xuat 2026-11
# ----------------------------------------------------------------------------
RES = {}
for it in ITEMS:
    c = CAT[it]
    T = int(c["thoi_gian_giao_ngay"])
    price = int(c["gia_von_hien_tai"])
    qc = int(c["quy_cach_dat_boi_so"])
    F, sigma, nvalid, short = forecast(it)
    SS = ceil_(Z * sigma * math.sqrt(T / 30))
    ROP = ceil_(F / 30 * T + SS)
    kk = KK[it]
    dv = INCOMING.get(it, 0)
    need = F + SS - kk - dv
    sl_need = 0 if need <= 0 else ceil_(need / qc) * qc
    dem12 = sum(DEMAND[it][m] for m in MONTHS)
    vm = valid_months(it)
    cut_months = [m for m in MONTHS if m >= LAUNCH[it] and is_cut(it, m)]
    # ngay ton
    if F > 0:
        so_ngay_ton = kk / (F / 30)
    else:
        so_ngay_ton = float("inf") if kk > 0 else 0.0
    start90 = END - timedelta(days=NGUONG_KHONG_BAN - 1)  # 90 ngay cuoi: 2026-08-03..2026-10-31
    khong_ban_90 = (LAST_SALE[it] is None or LAST_SALE[it] < start90)
    if kk == 0:
        canh_bao = "HET_HANG"
    elif kk <= ROP:
        canh_bao = "SAP_HET"
    elif so_ngay_ton > NGUONG_TON_LAU or (khong_ban_90 and kk > 0):
        canh_bao = "TON_LAU"
    elif F < NGUONG_BAN_CHAM:
        canh_bao = "BAN_CHAM"
    else:
        canh_bao = "OK"
    nam_truoc = None if (is_cut(it, "2025-11") or "2025-11" < LAUNCH[it]) else DEMAND[it]["2025-11"]
    RES[it] = dict(
        ma_hang=it, T=T, price=price, qc=qc, F=F, sigma=sigma, nvalid=nvalid, short=short, SS=SS, ROP=ROP,
        kk=kk, sys=SYS_STOCK[it], chenh=kk - SYS_STOCK[it], dv=dv, need=need, sl_need=sl_need,
        dem12=dem12, value=dem12 * price, valid=vm, cut_months=cut_months, so_ngay_ton=so_ngay_ton,
        khong_ban_90=khong_ban_90, canh_bao=canh_bao, nam_truoc=nam_truoc,
        trang_thai=c["trang_thai"], ten=c["ten_hang"],
    )

# ---- ABC (quy-uoc muc 8)
order = sorted(ITEMS, key=lambda k: (-RES[k]["value"], k))
total_value = sum(RES[k]["value"] for k in ITEMS)
cum = 0
for k in order:
    if cum < 0.80 * total_value:
        RES[k]["abc"] = "A"
    elif cum < 0.95 * total_value:
        RES[k]["abc"] = "B"
    else:
        RES[k]["abc"] = "C"
    cum += RES[k]["value"]

# ----------------------------------------------------------------------------
# 5. De xuat nhap + ngan sach
# ----------------------------------------------------------------------------
for it in ITEMS:
    r = RES[it]
    if r["trang_thai"] == "ngung_nhap":
        r["sl_chua_ngan_sach"] = 0
    else:
        r["sl_chua_ngan_sach"] = r["sl_need"]

tier_rank = {"HET_HANG": 1, "SAP_HET": 2}
need_items = [k for k in ITEMS if RES[k]["sl_chua_ngan_sach"] > 0]


def prio_key(k):
    r = RES[k]
    days = r["kk"] / (r["F"] / 30) if r["F"] > 0 else 9999
    return (tier_rank.get(r["canh_bao"], 3), "ABC".index(r["abc"]), days, k)


need_items.sort(key=prio_key)
uncapped_total = sum(RES[k]["sl_chua_ngan_sach"] * RES[k]["price"] for k in ITEMS)
remaining = NGAN_SACH
for rank, k in enumerate(need_items, 1):
    r = RES[k]
    r["uu_tien"] = rank
    full = r["sl_chua_ngan_sach"] * r["price"]
    if full <= remaining:
        r["sl"] = r["sl_chua_ngan_sach"]
    else:
        units_ok = int(remaining // r["price"])
        r["sl"] = (units_ok // r["qc"]) * r["qc"]
    remaining -= r["sl"] * r["price"]
for k in ITEMS:
    RES[k].setdefault("uu_tien", "")
    RES[k].setdefault("sl", 0)
    RES[k]["thanh_tien"] = RES[k]["sl"] * RES[k]["price"]
total_proposed = sum(RES[k]["thanh_tien"] for k in ITEMS)

# ---- loi anh huong tung ma (de gan can_nguoi_quyet)
ISSUE_ITEMS = defaultdict(list)
for e in LOI:
    if e["xu_ly"] == "CAN_NGUOI_QUYET" and e["ma_hang"]:
        ISSUE_ITEMS[e["ma_hang"]].append(e["loai_loi"])

for it in ITEMS:
    r = RES[it]
    reasons, quyet = [], False
    tag = {"HET_HANG": "het hang", "SAP_HET": "ton <= diem dat lai", "TON_LAU": "ton lau", "BAN_CHAM": "ban cham", "OK": "ton on"}[r["canh_bao"]]
    reasons.append(f"{r['canh_bao']} ({tag}); ABC={r['abc']}")
    reasons.append(f"F={r['F']:.1f}, SS={r['SS']}, ton kiem ke={r['kk']}, dang ve={r['dv']}, can={max(0, r['need']):.1f}")
    if r["trang_thai"] == "ngung_nhap":
        reasons.append("NGUNG NHAP: khong de xuat, can chu xac nhan co dung han khong; ton con " + str(r["kk"]))
        quyet = True
    if r["short"]:
        reasons.append(f"DU_LIEU_NGAN: chi co {r['nvalid']} thang hop le (sigma = 0.5 x F theo quy uoc, la gia dinh)")
        quyet = True
    if r["cut_months"]:
        reasons.append("thang cut hang (khong dua vao TB): " + ";".join(r["cut_months"]))
    if r["dv"] and INCOMING_DATE.get(it, "0") > "2026-11-30":
        reasons.append(f"hang dang ve du kien ngay {INCOMING_DATE[it]} (sau thang 11) nhung cong thuc van tru {r['dv']}; neu khong ve kip thang 11 thi can them")
        quyet = True
    if ISSUE_ITEMS.get(it):
        reasons.append("co ghi nhan can nguoi quyet: " + ",".join(sorted(set(ISSUE_ITEMS[it]))))
        quyet = True
    if r["sl_chua_ngan_sach"] > r["sl"]:
        reasons.append(f"BI CAT vi ngan sach: can {r['sl_chua_ngan_sach']}, de xuat {r['sl']}")
        quyet = True
    r["quyet"] = "CO" if quyet else "KHONG"
    r["ly_do"] = "; ".join(reasons)

write_csv("de-xuat-nhap.csv",
          ["ma_hang", "sl_can_chua_xet_ngan_sach", "sl_de_xuat", "quy_cach", "don_gia_von", "thanh_tien", "uu_tien", "can_nguoi_quyet", "ly_do"],
          [dict(ma_hang=k, sl_can_chua_xet_ngan_sach=RES[k]["sl_chua_ngan_sach"], sl_de_xuat=RES[k]["sl"], quy_cach=RES[k]["qc"],
                don_gia_von=RES[k]["price"], thanh_tien=RES[k]["thanh_tien"], uu_tien=RES[k]["uu_tien"],
                can_nguoi_quyet=RES[k]["quyet"], ly_do=RES[k]["ly_do"]) for k in ITEMS])


def fmt(x, nd=2):
    if x is None:
        return ""
    if isinstance(x, float):
        if math.isinf(x):
            return ""
        return f"{x:.{nd}f}"
    return x


write_csv("phan-loai-tinh-toan.csv",
          ["ma_hang", "lop_abc", "gia_tri_tieu_thu_nam", "so_thang_hop_le", "thang_cut_hang", "nhu_cau_du_bao_thang", "do_lech_chuan",
           "ton_an_toan", "diem_dat_lai", "ton_kiem_ke", "ton_he_thong", "chenh_kiem_ke", "hang_dang_ve", "so_ngay_ton",
           "cung_ky_nam_truoc_2025_11", "canh_bao"],
          [dict(ma_hang=k, lop_abc=RES[k]["abc"], gia_tri_tieu_thu_nam=RES[k]["value"], so_thang_hop_le=len(RES[k]["valid"]),
                thang_cut_hang=";".join(RES[k]["cut_months"]), nhu_cau_du_bao_thang=fmt(RES[k]["F"]), do_lech_chuan=fmt(RES[k]["sigma"]),
                ton_an_toan=RES[k]["SS"], diem_dat_lai=RES[k]["ROP"], ton_kiem_ke=RES[k]["kk"], ton_he_thong=RES[k]["sys"],
                chenh_kiem_ke=RES[k]["chenh"], hang_dang_ve=RES[k]["dv"], so_ngay_ton=fmt(RES[k]["so_ngay_ton"], 1),
                cung_ky_nam_truoc_2025_11=fmt(RES[k]["nam_truoc"]), canh_bao=RES[k]["canh_bao"]) for k in ITEMS])

# ----------------------------------------------------------------------------
# 6. Giu lai do loi (2026-09, 2026-10)
# ----------------------------------------------------------------------------
HO_ROWS = []
for it in ITEMS:
    for m in HOLDOUT:
        prev = MONTHS[MONTHS.index(m) - 1]
        actual = DEMAND[it][m]
        F, sigma, nvalid, short = forecast(it, before=m)
        naive = RAWSALES[it].get(prev, 0)
        naive_clean = DEMAND[it][prev]
        ok = (not is_cut(it, m)) and m >= LAUNCH[it] and nvalid >= 3
        HO_ROWS.append(dict(ma_hang=it, thang=m, thuc_te=actual, du_bao=round(F, 2), moc_thang_truoc=naive,
                            tinh_duoc="CO" if ok else "KHONG", _naive_clean=naive_clean, _lydo=(
                                "cụt hàng" if is_cut(it, m) else ("chưa đủ lịch sử (mới bán hoặc dưới 3 tháng hợp lệ)" if (m < LAUNCH[it] or nvalid < 3) else ""))))
write_csv("giu-lai-do-loi.csv", ["ma_hang", "thang", "thuc_te", "du_bao", "moc_thang_truoc", "tinh_duoc"], HO_ROWS)


def metrics(rows, key):
    a = [r["thuc_te"] for r in rows]
    n = len(a)
    if n == 0:
        return dict(n=0, mae=None, wape=None)
    e = [abs(r[key] - r["thuc_te"]) for r in rows]
    bias = sum(r[key] - r["thuc_te"] for r in rows) / n
    return dict(n=n, mae=sum(e) / n, wape=(sum(e) / sum(a) if sum(a) else None), bias=bias)


HO = {}
for label, sel in [("2026-09", ["2026-09"]), ("2026-10", ["2026-10"]), ("gop", HOLDOUT)]:
    rows = [r for r in HO_ROWS if r["tinh_duoc"] == "CO" and r["thang"] in sel]
    HO[label] = dict(
        n=len(rows),
        cong_thuc=metrics(rows, "du_bao"),
        moc1_tho=metrics(rows, "moc_thang_truoc"),
        moc1_sach=metrics(rows, "_naive_clean"),
        sum_thuc=sum(r["thuc_te"] for r in rows),
        thang_cong_thuc=sum(1 for r in rows if abs(r["du_bao"] - r["thuc_te"]) < abs(r["moc_thang_truoc"] - r["thuc_te"])),
        thua_cong_thuc=sum(1 for r in rows if abs(r["du_bao"] - r["thuc_te"]) > abs(r["moc_thang_truoc"] - r["thuc_te"])),
        hoa=sum(1 for r in rows if abs(r["du_bao"] - r["thuc_te"]) == abs(r["moc_thang_truoc"] - r["thuc_te"])),
    )
HO_EXCLUDED = [r for r in HO_ROWS if r["tinh_duoc"] == "KHONG"]

# ----------------------------------------------------------------------------
# 7. Ghi loi-du-lieu.csv
# ----------------------------------------------------------------------------
ORDER_LOAI = ["trung_dong", "so_am_khong_ghi_chu", "so_luong_bat_thuong", "thieu_so_luong", "don_si_mot_lan",
              "ngay_o_tuong_lai", "khong_phai_ban_hang", "khac"]
LOI.sort(key=lambda e: (ORDER_LOAI.index(e["loai_loi"]), e["ma_phieu"]))
write_csv("loi-du-lieu.csv", ["ma_phieu", "loai_loi", "ma_hang", "xu_ly", "ly_do"], LOI)

# ----------------------------------------------------------------------------
# 8. Tu kiem (in ra man hinh va dua vao bao cao)
# ----------------------------------------------------------------------------
CHECK = {}
CHECK["tong_von"] = total_proposed
CHECK["khong_vuot_ngan_sach"] = total_proposed <= NGAN_SACH
CHECK["boi_so_ok"] = all(RES[k]["sl"] % RES[k]["qc"] == 0 for k in ITEMS)
CHECK["thanh_tien_ok"] = sum(RES[k]["sl"] * RES[k]["price"] for k in ITEMS) == total_proposed
CHECK["so_ma"] = len(ITEMS)
CHECK["chenh"] = {k: RES[k]["chenh"] for k in ITEMS if RES[k]["chenh"] != 0}
CHECK["thieu_du_lieu"] = {k: RES[k]["nvalid"] for k in ITEMS if RES[k]["short"]}
CHECK["cut"] = {k: RES[k]["cut_months"] for k in ITEMS if RES[k]["cut_months"]}
CHECK["abc_count"] = Counter(RES[k]["abc"] for k in ITEMS)
CHECK["canh_bao_count"] = Counter(RES[k]["canh_bao"] for k in ITEMS)
CHECK["ma_chua_co_trong_danh_muc"] = sorted({r["mh"] for r in RAW if r["mh"] not in CAT})
CHECK["ma_khong_nhat_ky"] = [k for k in ITEMS if not any(True for r in RAW if r["mh"] == k)]
CHECK["ma_ngoai_danh_muc_dang_ve"] = [k for k in INCOMING if k not in CAT]

# ----------------------------------------------------------------------------
# 8b. Do nhay: neu chu quyet khac mac dinh tam thi so thay doi the nao
# ----------------------------------------------------------------------------
ALT = {it: {m: DEMAND[it][m] for m in MONTHS} for it in ITEMS}
for r in RAW:
    if r["dup"] or not r["mh"] or r["q"] is None or r["d_eff"] > END:
        continue
    m_ = month_of(r["d_eff"])
    if r["kind"] == "SI":
        ALT[r["mh"]][m_] += r["q"]                       # tinh don si vao nhu cau
    elif r["kind"] == "BAT_THUONG":
        ALT[r["mh"]][m_] += r["q"] - r["q_clean"]         # giu nguyen so ghi, khong chia 10
    elif r.get("sign_fix"):
        ALT[r["mh"]][m_] += -2 * abs(r["q"])              # coi la khach tra (so am that)
SENS = []
for it in ITEMS:
    if ALT[it] == DEMAND[it]:
        continue
    c = RES[it]
    F2, sg2, nv2, sh2 = forecast(it, None, ALT)
    SS2 = ceil_(Z * sg2 * math.sqrt(c["T"] / 30))
    need2 = F2 + SS2 - c["kk"] - c["dv"]
    sl2 = 0 if need2 <= 0 else ceil_(need2 / c["qc"]) * c["qc"]
    if c["trang_thai"] == "ngung_nhap":
        sl2 = 0
    if abs(F2 - c["F"]) > 1e-9 or sl2 != c["sl_chua_ngan_sach"]:
        SENS.append(dict(ma_hang=it, F=c["F"], F2=F2, sl=c["sl_chua_ngan_sach"], sl2=sl2, price=c["price"]))

# doi chieu ton: truoc khi xu ly cac ca can quyet (chi bo dong trung + chuan hoa ma/ngay, giu nguyen so ghi, bo phieu ngay tuong lai)
base_stock = dict(OPEN)
for r in RAW:
    if r["dup"] or not r["mh"] or r["q"] is None or r["d"] > END:
        continue
    if r["loai"] == "XUAT":
        base_stock[r["mh"]] -= r["q"]
    else:
        base_stock[r["mh"]] += r["q"]
CHENH_TRUOC = {k: KK[k] - base_stock[k] for k in ITEMS if KK[k] != base_stock[k]}
MISSING_BY_ITEM = defaultdict(list)
for r in RAW:
    if not r["dup"] and r["q"] is None and r["mh"]:
        MISSING_BY_ITEM[r["mh"]].append(r["ma_phieu"])

# dong gop sai so cua cong thuc (gop 2 thang)
_rows = [r for r in HO_ROWS if r["tinh_duoc"] == "CO"]
_err = defaultdict(float)
for r in _rows:
    _err[r["ma_hang"]] += abs(r["du_bao"] - r["thuc_te"])
_tot_err = sum(_err.values())
TOP_ERR = sorted(_err.items(), key=lambda kv: -kv[1])[:5]
TOP_ERR_SHARE = sum(v for _, v in TOP_ERR) / _tot_err if _tot_err else 0


# ----------------------------------------------------------------------------
# 9. Bao cao (sinh tu so lieu o tren de khong chep tay sai)
# ----------------------------------------------------------------------------
def vnd(x):
    return f"{int(round(x)):,}".replace(",", ".")


def pct(x):
    return f"{x * 100:.1f}%".replace(".", ",")


def num(x, nd=1):
    return f"{x:.{nd}f}".replace(".", ",")


def tbl(header, rows):
    out = ["| " + " | ".join(header) + " |", "|" + "|".join(["---"] * len(header)) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def viet_bao_cao():
    L = []
    w = L.append
    cut_items = [k for k in ITEMS if RES[k]["sl_chua_ngan_sach"] > RES[k]["sl"]]
    cut_total = uncapped_total - total_proposed
    funded = [k for k in need_items if RES[k]["sl"] > 0]
    n_quyet_phieu = sum(1 for e in LOI if e["xu_ly"] == "CAN_NGUOI_QUYET")
    cb = CHECK["canh_bao_count"]
    het = [k for k in ITEMS if RES[k]["canh_bao"] == "HET_HANG"]
    low_cut = [k for k in cut_items if RES[k]["so_ngay_ton"] < 30]
    low_cut_cost = sum((RES[k]["sl_chua_ngan_sach"] - RES[k]["sl"]) * RES[k]["price"] for k in low_cut)
    h = HO["gop"]
    late = [k for k in het if INCOMING.get(k) and INCOMING_DATE[k] > "2026-11-30"]

    w("# Báo cáo kho tháng 2026-11\n")
    w("_Dữ liệu GIẢ để học (60 mã hàng, 2025-11 đến 2026-10). Mọi con số dưới đây chỉ là ĐỀ XUẤT; chủ cửa hàng quyết định số cuối cùng. "
      "File chi tiết: `de-xuat-nhap.csv`, `phan-loai-tinh-toan.csv`, `giu-lai-do-loi.csv`, `loi-du-lieu.csv`; chương trình: `tinh_ton_kho.py`._\n")

    # ---- 1
    w("## 1. Tóm tắt\n")
    w(f"1. **Đề xuất nhập tháng 11:** {len(funded)} mã, tổng tiền vốn **{vnd(total_proposed)} đ**, bằng {pct(total_proposed / NGAN_SACH)} ngân sách {vnd(NGAN_SACH)} đ (không vượt).")
    w(f"2. **Phần bị cắt:** theo công thức cần nhập {vnd(uncapped_total)} đ, vượt ngân sách {vnd(uncapped_total - NGAN_SACH)} đ; đã cắt {vnd(cut_total)} đ ở {len(cut_items)} mã (mục 2). Chủ cần xem lại danh sách cắt.")
    w(f"3. **Đáng lo:** {cb['HET_HANG']} mã hết hàng ({', '.join(het)}), {cb['SAP_HET']} mã sắp hết, {cb['TON_LAU']} mã tồn lâu, {cb['BAN_CHAM']} mã bán chậm."
      + (f" Riêng **{', '.join(late)}** hết hàng mà hàng đang về dự kiến {', '.join(INCOMING_DATE[k] for k in late)} (sau tháng 11), nên đề xuất 0 của công thức có nguy cơ sai." if late else ""))
    w(f"4. **Dự báo:** trên 2 tháng giữ lại (09, 10), công thức trung bình 3 tháng **{'thua' if h['cong_thuc']['wape'] > h['moc1_tho']['wape'] else 'thắng'}** mốc \"bằng tháng liền trước\": "
      f"WAPE {pct(h['cong_thuc']['wape'])} so với {pct(h['moc1_tho']['wape'])} (n = {h['n']} mã-tháng, mẫu nhỏ).")
    w(f"5. **Dữ liệu:** ghi nhận {len(LOI)} dòng lỗi/ca đặc biệt, {n_quyet_phieu} dòng CẦN NGƯỜI QUYẾT. Tồn hệ thống khớp kiểm kê ở {len(ITEMS) - len(CHECK['chenh'])}/{len(ITEMS)} mã; "
      f"{len(CHECK['chenh'])} mã còn lệch ({', '.join(sorted(CHECK['chenh']))}).\n")

    # ---- 2
    w("## 2. Tổng tiền vốn đề xuất so với ngân sách\n")
    w(tbl(["Chỉ tiêu", "Số tiền (đ)"], [
        ["Ngân sách nhập tháng 2026-11 (tham số)", vnd(NGAN_SACH)],
        ["Cần nhập theo công thức, CHƯA xét ngân sách", vnd(uncapped_total)],
        ["**Tổng tiền vốn đề xuất**", f"**{vnd(total_proposed)}**"],
        ["Còn lại so với ngân sách", vnd(NGAN_SACH - total_proposed)],
        ["Phần bị cắt vì ngân sách", vnd(cut_total)],
    ]))
    w(f"\n(Phần cắt lớn hơn mức vượt ngân sách {vnd(cut_total - (uncapped_total - NGAN_SACH))} đ vì số lượng phải làm tròn theo bội số quy cách.)")
    w("\n**Cách ưu tiên** (đây là lựa chọn của tôi, quy ước không quy định thứ tự này): xếp các mã cần nhập theo (1) HET_HANG, rồi SAP_HET, rồi các mã còn lại; "
      "(2) trong cùng nhóm, hạng ABC A trước B trước C; (3) cùng hạng thì mã có ít ngày tồn hơn đi trước. Cấp đủ số lượng theo thứ tự đó cho đến khi hết ngân sách; "
      "mã nào không đủ tiền cho cả lô thì giảm xuống bội số quy cách lớn nhất còn mua được. Số thứ tự nằm ở cột `uu_tien` của `de-xuat-nhap.csv`.\n")
    w("**Danh sách đề xuất nhập (đã xét ngân sách):**\n")
    rows = []
    for k in funded:
        r = RES[k]
        rows.append([r["uu_tien"], k, r["ten"], r["canh_bao"], r["abc"], r["sl_chua_ngan_sach"], r["sl"], r["qc"], vnd(r["price"]), vnd(r["thanh_tien"])])
    rows.append(["", "", "**Tổng**", "", "", "", "", "", "", f"**{vnd(total_proposed)}**"])
    w(tbl(["Ưu tiên", "Mã", "Tên hàng", "Cảnh báo", "ABC", "Cần (chưa xét NS)", "Đề xuất", "Quy cách", "Giá vốn", "Thành tiền"], rows))
    w("\n**Phần bị cắt vì ngân sách** (mã cần nhập nhưng không được cấp đủ):\n")
    rows = []
    for k in sorted(cut_items, key=lambda x: RES[x]["uu_tien"]):
        r = RES[k]
        rows.append([r["uu_tien"], k, r["ten"], r["abc"], r["sl_chua_ngan_sach"], r["sl"], vnd((r["sl_chua_ngan_sach"] - r["sl"]) * r["price"]), num(r["so_ngay_ton"]) + " ngày"])
    w(tbl(["Ưu tiên", "Mã", "Tên hàng", "ABC", "Cần", "Đề xuất", "Tiền bị cắt (đ)", "Tồn hiện đủ bán"], rows))
    if low_cut:
        w(f"\n> Lưu ý: {len(low_cut)} mã bị cắt mà tồn chỉ đủ bán dưới 30 ngày ({', '.join(low_cut)}); tổng tiền bị cắt của nhóm này {vnd(low_cut_cost)} đ. "
          "Nếu chủ thấy nhóm này quan trọng hơn một số mã hạng A đã được cấp đủ thì có thể đổi thứ tự. Ngân sách chỉ là tham số, không phải số thật.")
    for k in late:
        w(f"\n> Công thức trừ toàn bộ hàng đang về vào số cần nhập. **{k}**: hàng đang về dự kiến {INCOMING_DATE[k]}, tức sau tháng 11, nhưng vẫn bị trừ nên đề xuất = 0 trong khi tồn = 0. "
          f"Nếu hàng không về kịp tháng 11 thì cần đặt thêm {RES[k]['qc']} đơn vị (khoảng {vnd(RES[k]['qc'] * RES[k]['price'])} đ, ngoài số đã đề xuất; "
          f"ngân sách còn {vnd(NGAN_SACH - total_proposed)} đ). Chủ quyết.")

    # ---- 3
    w("\n## 3. Hàng đáng lo: hết hàng, sắp hết, tồn lâu, bán chậm\n")
    w("Tồn hiện tại lấy theo kiểm kê 2026-10-31. \"Số ngày tồn\" = tồn / (dự báo tháng / 30); để trống nếu dự báo bằng 0 (không còn nhu cầu).\n")
    order_cb = {"HET_HANG": 0, "SAP_HET": 1, "TON_LAU": 2, "BAN_CHAM": 3}
    rows = []
    for k in sorted([k for k in ITEMS if RES[k]["canh_bao"] != "OK"], key=lambda x: (order_cb[RES[x]["canh_bao"]], x)):
        r = RES[k]
        note = []
        if r["dv"]:
            note.append(f"đang về {r['dv']} (dự kiến {INCOMING_DATE[k]})")
            if INCOMING_DATE[k] > "2026-11-30":
                note.append("về SAU tháng 11")
        if r["canh_bao"] == "TON_LAU":
            if r["khong_ban_90"]:
                note.append("không bán trong 90 ngày cuối" + (f" (lần bán cuối {LAST_SALE[k]})" if LAST_SALE[k] else ""))
            else:
                note.append("tồn > 120 ngày")
        if r["trang_thai"] == "ngung_nhap":
            note.append("đã ngừng nhập")
        if r["short"]:
            note.append("mã mới, dữ liệu ngắn")
        if r["sl_chua_ngan_sach"] > r["sl"]:
            note.append("bị cắt vì ngân sách")
        rows.append([k, r["ten"], r["canh_bao"], r["kk"], r["ROP"], num(r["F"]), (num(r["so_ngay_ton"]) if not math.isinf(r["so_ngay_ton"]) else ""), r["dv"], "; ".join(note)])
    w(tbl(["Mã", "Tên hàng", "Cảnh báo", "Tồn KK", "Điểm đặt lại", "Dự báo/tháng", "Số ngày tồn", "Đang về", "Ghi chú"], rows))

    # ---- 4
    w("\n## 4. Kết quả giữ lại 2 tháng cuối (09 và 10 năm 2026)\n")
    w("Cách làm: mỗi tháng chỉ dùng dữ liệu TRƯỚC tháng đó để dự báo bằng công thức (trung bình 3 tháng hợp lệ gần nhất); thực tế là nhu cầu đã làm sạch. "
      "Chỉ đo các mã-tháng không bị cụt hàng và có ít nhất 3 tháng hợp lệ trước đó. Mốc 1 = doanh số thô của tháng liền trước (không làm sạch, đúng quy ước). "
      "Tôi thêm một cột phụ \"mốc 1 sau làm sạch\" để xem mốc 1 có được lợi vì lỗi dữ liệu hay không.\n")
    rows = []
    for lbl, name in [("2026-09", "Tháng 09"), ("2026-10", "Tháng 10"), ("gop", "Gộp 2 tháng")]:
        v = HO[lbl]
        rows.append([name, v["n"], num(v["cong_thuc"]["mae"]), num(v["moc1_tho"]["mae"]), num(v["moc1_sach"]["mae"]),
                     pct(v["cong_thuc"]["wape"]), pct(v["moc1_tho"]["wape"]), pct(v["moc1_sach"]["wape"]),
                     num(v["cong_thuc"]["bias"]), f"{v['thang_cong_thuc']} / {v['thua_cong_thuc']} / {v['hoa']}"])
    w(tbl(["Giai đoạn", "n (mã-tháng)", "MAE công thức", "MAE mốc 1 (thô)", "MAE mốc 1 (sạch)", "WAPE công thức", "WAPE mốc 1 (thô)", "WAPE mốc 1 (sạch)",
           "Lệch TB công thức (dự báo - thực)", "Công thức thắng / thua / hòa mốc 1 thô"], rows))
    better = "thua" if h["cong_thuc"]["wape"] > h["moc1_tho"]["wape"] else "thắng"
    w(f"\n**Kết luận thẳng:** trên dữ liệu này công thức {better} mốc \"bằng tháng trước\" (WAPE {pct(h['cong_thuc']['wape'])} so với {pct(h['moc1_tho']['wape'])}; "
      f"MAE {num(h['cong_thuc']['mae'])} so với {num(h['moc1_tho']['mae'])} đơn vị). "
      f"Số mã thắng và thua gần ngang nhau ({h['thang_cong_thuc']} thắng, {h['thua_cong_thuc']} thua, {h['hoa']} hòa); sai số tổng lớn hơn vì một vài mã bán chạy và có mùa vụ: "
      f"{', '.join(k for k, _ in TOP_ERR)} chiếm {pct(TOP_ERR_SHARE)} tổng sai số tuyệt đối của công thức. "
      f"Công thức dự báo CAO hơn thực tế trung bình {num(h['cong_thuc']['bias'])} đơn vị/mã-tháng: nhiều mã (nước ngọt, nước suối...) lên đỉnh giữa năm rồi giảm, mà trung bình 3 tháng phản ứng chậm. "
      f"Mốc 1 sau làm sạch (WAPE {pct(h['moc1_sach']['wape'])}) gần bằng mốc 1 thô, nên khoảng cách này không đến từ lỗi dữ liệu trong mốc 1.\n")
    w("**Điều cần nhớ khi đọc con số này:**")
    w(f"- n nhỏ: chỉ {h['n']} mã-tháng từ 2 tháng; mỗi mã xuất hiện tối đa 2 lần và cả hai tháng cùng nằm trong giai đoạn nhu cầu giảm sau mùa hè, nên các điểm không độc lập. "
      "Không có kiểm định thống kê. Chưa đủ để kết luận công thức \"kém\" nói chung, chỉ cho biết nó kém trong 2 tháng này.")
    excl = Counter(r["_lydo"] for r in HO_EXCLUDED)
    w(f"- Bỏ ra ngoài {len(HO_EXCLUDED)} mã-tháng (không tính được): " + ", ".join(f"{v} vì {k}" for k, v in excl.items()) + ".")
    w("- **Mốc 2 \"cùng kỳ năm trước\" không làm được cho 2026-09 và 2026-10** (chỉ có 12 tháng dữ liệu, không có 2025-09, 2025-10). Mốc này chỉ làm được cho tháng 2026-11 "
      "(lấy 2025-11, cột `cung_ky_nam_truoc_2025_11` của `phan-loai-tinh-toan.csv`) nhưng chưa có thực tế 2026-11 nên không đo được.")
    w("- Chưa đo được: dự báo 2026-11 đúng bao nhiêu; tồn an toàn 95% có đạt tỷ lệ không hết hàng thật hay không; hiệu ứng mùa vụ (cần ít nhất 2 năm); độ lệch thời gian giao; "
      "hàng mới (MP010, MP014, MP015) vì chưa đủ lịch sử.")
    over = [k for k in ITEMS if RES[k]["F"] >= 50 and RES[k]["F"] >= 1.2 * max(DEMAND[k]["2026-10"], 1)]
    if over:
        w("- Vì công thức hay dự báo cao khi nhu cầu đang giảm, hãy dè dặt với dự báo của các mã bán chạy dưới đây: " + ", ".join(
            f"{k} (dự báo {num(RES[k]['F'], 0)} so với tháng 10 thực tế {DEMAND[k]['2026-10']})" for k in over) + ".")

    # ---- 5
    w("\n## 5. Lỗi dữ liệu và cách xử lý\n")
    w(f"Nhật ký có {len(RAW)} dòng. `loi-du-lieu.csv` ghi {len(LOI)} dòng. Ngày viết lẫn lộn và mã hàng sai dạng được chuẩn hóa hàng loạt nên ghi thành 2 dòng tổng hợp.\n")
    cnt = Counter((e["loai_loi"], e["xu_ly"]) for e in LOI)
    desc = {
        "trung_dong": "Trùng mã phiếu (cùng nội dung, chỉ khác cách viết ngày/tên) → BỎ dòng sau",
        "so_am_khong_ghi_chu": "XUẤT số âm nhưng không ghi \"khách trả\" → tạm tính là bán |số|, chủ quyết",
        "so_luong_bat_thuong": "Số lượng gấp bất thường trong 1 phiếu (nghi gõ thừa số 0) → tạm chia 10, chủ quyết",
        "thieu_so_luong": "Ô số lượng để trống → không điền, tạm tính 0, chủ quyết",
        "don_si_mot_lan": "Đơn sỉ một lần → vẫn trừ tồn, KHÔNG tính vào nhu cầu thường ngày, chủ quyết (phiếu nhập kèm đơn sỉ: GIỮ)",
        "ngay_o_tuong_lai": "Ngày sau 2026-10-31 → tạm đặt ngày theo số phiếu, chủ quyết",
        "khong_phai_ban_hang": "Hủy hết hạn, xuất dùng nội bộ, điều chỉnh kiểm kê → GIỮ (trừ tồn, không tính nhu cầu)",
        "khac": "Thiếu mã hàng (dò theo tên) và chuẩn hóa định dạng ngày/mã → SỬA",
    }
    rows = []
    for lo in ORDER_LOAI:
        for xl in ["BO", "SUA", "GIU", "CAN_NGUOI_QUYET"]:
            if cnt.get((lo, xl)):
                d_ = desc[lo]
                if lo == "don_si_mot_lan":
                    d_ = ("Phiếu NHẬP riêng cho đơn sỉ → GIỮ (vẫn cộng vào tồn)" if xl == "GIU"
                          else "Phiếu XUẤT đơn sỉ một lần → vẫn trừ tồn, KHÔNG tính vào nhu cầu thường ngày, chủ quyết")
                rows.append([lo, cnt[(lo, xl)], xl, d_])
    w(tbl(["Loại lỗi", "Số dòng", "Xử lý", "Cách làm"], rows))
    w(f"\n**Đối chiếu tồn hệ thống chạy với kiểm kê (kiểm kê − hệ thống):** nếu chỉ bỏ dòng trùng và chuẩn hóa mã/ngày, giữ nguyên số đã ghi, thì lệch {len(CHENH_TRUOC)} mã; "
      f"sau khi xử lý các ca ở trên còn lệch {len(CHECK['chenh'])} mã. Nghĩa là các ca nghi ngờ (gõ thừa số 0, số âm gõ nhầm, phiếu nhập ghi sai tháng) được kiểm kê ủng hộ, nhưng vẫn cần chủ xác nhận.\n")
    rows = []
    for k in sorted(CHECK["chenh"]):
        r = RES[k]
        ms = MISSING_BY_ITEM.get(k)
        if ms:
            gt = f"Có {len(ms)} phiếu thiếu số lượng ({', '.join(ms)}); phần lệch có thể là số bán bị thiếu đó. KHÔNG tự điền, chờ chủ."
        else:
            gt = "Chưa giải thích được bằng lỗi nhật ký; có thể hao hụt hoặc đếm sai. Chờ chủ kiểm lại."
        rows.append([k, r["ten"], r["sys"], r["kk"], r["chenh"], gt])
    w(tbl(["Mã", "Tên hàng", "Tồn hệ thống", "Kiểm kê", "Chênh", "Giải thích"], rows))
    w("\n(Số âm = kiểm kê ít hơn hệ thống. Tồn dùng để tính đề xuất là số KIỂM KÊ, không phải tồn hệ thống.)")
    ho_short = sorted({r["ma_hang"] for r in HO_EXCLUDED if not r["_lydo"].startswith("cụt")})
    w(f"\nMã thiếu dữ liệu: dưới 3 tháng hợp lệ = {', '.join(f'{k} ({v} tháng)' for k, v in CHECK['thieu_du_lieu'].items()) or 'không có'}; "
      f"chưa đủ lịch sử để đo giữ lại: {', '.join(ho_short)}. "
      f"Số mã có ít nhất 1 tháng cụt hàng: {len(CHECK['cut'])}/{len(ITEMS)} (cột `thang_cut_hang`).\n")

    # ---- 6
    w("## 6. Giả định đã dùng\n")
    for t in [
        "Công thức, ngưỡng, ngân sách lấy đúng từ `quy-uoc.md` và `tham-so.json`, không đổi (Z = 1,645; ngân sách 30.000.000 đ; cụt hàng = từ 7 ngày hết hàng).",
        "Ngày viết lẫn lộn đọc theo kiểu Việt Nam (ngày trước tháng). Đã kiểm: số phiếu tăng dần thì ngày không giảm, nên không có dòng nào đảo ngày/tháng.",
        "Mã hàng viết thường/có gạch/thừa khoảng trắng thì chuẩn hóa; dòng thiếu mã dò theo tên không dấu (4 dòng, khớp duy nhất).",
        "\"Tháng hợp lệ\" = tháng từ lúc mặt hàng bắt đầu bán (hàng thường: từ 2025-11; hàng mới: theo ghi chú trong danh mục) và không cụt hàng. Tháng bán 0 mà không cụt vẫn tính là hợp lệ (bán 0, không phải thiếu số liệu).",
        "Ngày hết hàng = tồn cuối ngày ≤ 0 theo tồn hệ thống chạy đã làm sạch. Trước ngày mở bán của hàng mới không tính là cụt.",
        "Số âm CÓ ghi \"khách trả\" = trả hàng (cộng lại tồn, trừ nhu cầu). Điều chỉnh kiểm kê (DIEU_CHINH) là số thay đổi tồn (âm = giảm), không tính nhu cầu.",
        "Đơn sỉ một lần và số lượng bất thường: hàng vẫn rời kho thật nên vẫn trừ tồn (kiểm kê khớp), nhưng đơn sỉ không tính vào nhu cầu thường ngày; số bất thường tạm chia 10. Đây là mặc định TẠM, xem mục 7.",
        "Số âm không ghi chú tạm coi là bán (gõ nhầm dấu), vì kiểm kê khớp hơn cách coi là trả hàng; thiếu số lượng tạm tính 0.",
        "Phiếu nhập ghi tháng 12/2026 tạm đặt theo ngày của phiếu đứng liền trước trong dãy số phiếu (2026-09-25); kiểm kê cho thấy hàng đã về.",
        "Dự báo F = trung bình 3 tháng hợp lệ gần nhất; σ = độ lệch chuẩn mẫu (n−1) của tối đa 6 tháng hợp lệ; dưới 3 tháng thì σ = 0,5 × F và gắn cờ DU_LIEU_NGAN (chỉ MP010). Thời gian giao cố định, nhu cầu các tháng độc lập.",
        "Số cần nhập = max(0, F + SS − tồn kiểm kê − hàng đang về), làm tròn LÊN theo bội số quy cách. Hàng đang về được trừ toàn bộ, kể cả hàng dự kiến về sau tháng 11.",
        "Mặt hàng ngừng nhập (TH021, VT017) không đề xuất nhập (số lượng 0); vẫn tính ABC và cảnh báo.",
        "\"Không bán ngày nào trong 90 ngày cuối\" = không có phiếu bán hàng nào từ 2026-08-03 đến 2026-10-31 (tính cả đơn sỉ).",
        "Mốc 1 thô = tổng số lượng XUẤT của tháng trước, chỉ chuẩn hóa ngày và mã, không bỏ trùng, không bỏ hủy/nội bộ/đơn sỉ/số bất thường. Thực tế để so sánh là nhu cầu đã làm sạch.",
        "Thứ tự ưu tiên khi cắt ngân sách (mục 2) là lựa chọn của tôi, không phải của quy ước.",
        "Chỉ có giá vốn hiện tại, dùng cho cả ABC 12 tháng và thành tiền.",
        "Cờ \"cụt hàng\" tính từ tồn hệ thống chạy; vì có vài mã lệch kiểm kê nên số ngày hết hàng của các mã đó có thể sai lệch nhẹ.",
    ]:
        w(f"- {t}")

    # ---- 7
    w("\n## 7. Danh sách CẦN NGƯỜI QUYẾT\n")
    w("**A. Ngân sách và thứ tự ưu tiên**\n")
    n = 1
    w(f"{n}. Chấp nhận cắt {vnd(cut_total)} đ ở {len(cut_items)} mã (bảng mục 2), hay tăng ngân sách, hay đổi thứ tự? Các mã bị cắt mà tồn dưới 30 ngày: {', '.join(low_cut) or 'không có'}.")
    n += 1
    w("\n**B. Mặt hàng**\n")
    for k in late:
        w(f"{n}. **{k}** (tồn 0, hàng về dự kiến {INCOMING_DATE[k]}): có đặt thêm cho tháng 11 không, hay xác nhận lại ngày về? Hiện đề xuất = 0.")
        n += 1
    ng = [k for k in ITEMS if RES[k]["trang_thai"] == "ngung_nhap"]
    w(f"{n}. **{', '.join(ng)}** đang ngừng nhập nhưng còn tồn ({', '.join(f'{k}: {RES[k]['kk']}' for k in ng)}), lần bán cuối {', '.join(f'{k}: {LAST_SALE[k]}' for k in ng)}: giữ không nhập, xả hàng tồn, hay đổi trạng thái?")
    n += 1
    dead = [k for k in ITEMS if RES[k]["khong_ban_90"] and RES[k]["kk"] > 0 and RES[k]["trang_thai"] != "ngung_nhap"]
    if dead:
        w(f"{n}. **{', '.join(dead)}** chưa ghi ngừng nhập nhưng không bán trong 90 ngày cuối (tồn {', '.join(f'{k}: {RES[k]['kk']}' for k in dead)}): có coi là hàng chết không?")
        n += 1
    w(f"{n}. **MP010** (hàng mới, chỉ 2 tháng bán): dự báo và tồn an toàn dựa trên giả định σ = 0,5 × F, chưa đáng tin; chủ nên tự xét. MP014 và MP015 cũng còn ít lịch sử.")
    n += 1
    if over:
        w(f"{n}. Các mã bán chạy có dấu hiệu giảm sau mùa hè ({', '.join(over)}): có muốn nhập ít hơn số công thức cho không?")
        n += 1
    w("\n**C. Phiếu nhật ký cần chủ xác nhận** (mặc định TẠM đã dùng để tính; lý do và gợi ý từ kiểm kê nằm trong `loi-du-lieu.csv`)\n")
    first = {}
    for r in RAW:
        first.setdefault(r["ma_phieu"], r)
    rows = []
    for e in LOI:
        if e["xu_ly"] != "CAN_NGUOI_QUYET":
            continue
        r = first[e["ma_phieu"]]
        lo = e["loai_loi"]
        if lo == "thieu_so_luong":
            df = "tính 0"
        elif lo == "so_am_khong_ghi_chu":
            df = f"tính là bán {abs(r['q'])}"
        elif lo == "so_luong_bat_thuong":
            df = f"tính {r['q_clean']}" + (" (chia 10)" if r.get("div10") else " (giữ nguyên)")
        elif lo == "don_si_mot_lan":
            df = "trừ tồn, không tính nhu cầu"
        elif lo == "ngay_o_tuong_lai":
            df = f"đặt ngày {r['d_eff']}"
        else:
            df = ""
        rows.append([e["ma_phieu"], e["ma_hang"], lo, r["d"].isoformat(), r["so_luong"] or "(trống)", df])
    w(tbl(["Mã phiếu", "Mã hàng", "Loại", "Ngày ghi", "Số ghi", "Mặc định tạm dùng"], rows))
    w(f"\n{n}. Với mỗi phiếu ở bảng trên: xác nhận số đúng / ngày đúng. Hai phiếu nhập ghi tháng 12 cần ngày thật.")
    n += 1
    w(f"{n}. {len(CHECK['chenh'])} mã còn lệch kiểm kê (bảng mục 5): kiểm lại thực tế hoặc tìm phiếu còn thiếu.\n")
    n += 1
    w("**D. Nếu chủ quyết khác mặc định, số cần nhập đổi thế nào** (tính lại dự báo, tồn an toàn, số cần nhập chưa xét ngân sách; không đổi cờ cụt hàng):\n")
    if SENS:
        rows = [[s_["ma_hang"], CAT[s_["ma_hang"]]["ten_hang"], num(s_["F"]), num(s_["F2"]), s_["sl"], s_["sl2"], vnd((s_["sl2"] - s_["sl"]) * s_["price"])] for s_ in SENS]
        w(tbl(["Mã", "Tên hàng", "Dự báo (mặc định)", "Dự báo (giữ nguyên số ghi, đơn sỉ tính vào, số âm là trả hàng)", "Cần nhập mặc định", "Cần nhập nếu quyết khác", "Chênh tiền (đ)"], rows))
    else:
        w("Không mã nào đổi số cần nhập; các ca nghi ngờ nằm ngoài 3 tháng hợp lệ gần nhất.")
    w("\n---\n_Báo cáo do `tinh_ton_kho.py` sinh ra từ dữ liệu; chạy lại script sẽ tạo lại toàn bộ file kết quả._")
    with open(P("bao-cao.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(L) + "\n")


viet_bao_cao()

# ---- in tom tat
print("So ma:", len(ITEMS), "| dong nhat ky:", len(RAW), "| dong loi ghi nhan:", len(LOI))
print("Tong can chua xet ngan sach:", vnd(uncapped_total), "VND | de xuat:", vnd(total_proposed), "VND | ngan sach:", vnd(NGAN_SACH))
print("Khong vuot ngan sach:", CHECK["khong_vuot_ngan_sach"], "| boi so dung:", CHECK["boi_so_ok"])
print("ABC:", dict(CHECK["abc_count"]), "| canh bao:", dict(CHECK["canh_bao_count"]))
print("Chenh kiem ke (kiem ke - he thong), so ma:", len(CHECK["chenh"]), CHECK["chenh"])
print("Thieu du lieu (<3 thang hop le):", CHECK["thieu_du_lieu"])
print("Thang cut hang:", {k: v for k, v in CHECK["cut"].items()})
for lbl, v in HO.items():
    print("Giu lai", lbl, "n=", v["n"], "MAE cong thuc=", v["cong_thuc"]["mae"], "WAPE=", v["cong_thuc"]["wape"],
          "| moc1 tho MAE=", v["moc1_tho"]["mae"], "WAPE=", v["moc1_tho"]["wape"],
          "| moc1 sach MAE=", v["moc1_sach"]["mae"], "WAPE=", v["moc1_sach"]["wape"],
          "| thang/thua/hoa:", v["thang_cong_thuc"], v["thua_cong_thuc"], v["hoa"])
