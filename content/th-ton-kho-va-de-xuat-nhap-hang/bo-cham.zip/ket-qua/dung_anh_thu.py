import json, sys, html
from pathlib import Path
import os
sys.path.insert(0, os.environ.get("AGENTLAB_DIR") or str(Path(__file__).resolve().parents[5] / "siptech-video" / "agentlab"))
from term import shot_html as _shot_html, scrub_text
def shot_html(h, *a, **k): return _shot_html(scrub_text(h), *a, **k)   # che duong dan/ ten to chuc truoc khi dung anh
ROOT = Path(__file__).resolve().parent.parent
d = json.loads((ROOT / "ket-qua/thu-chay-lai.json").read_text(encoding="utf-8"))
v = lambda x: f"{x:,}".replace(",", ".")
CSS = """body{margin:0;background:#fff;font-family:'Segoe UI',Arial,sans-serif}.w{padding:16px;width:1080px}h3{margin:0 0 6px;font-size:17px}p{margin:4px 0 8px;color:#475569;font-size:13px}
table{border-collapse:collapse;width:100%;font-size:14px;margin-bottom:14px}th{background:#e8edf5;border:1px solid #c5cedb;padding:5px 8px;text-align:left}td{border:1px solid #d6dce6;padding:4px 8px}td.n{text-align:right;font-family:Consolas,monospace}.ok{background:#dff3e0}.bad{background:#fde2e2}.warn{background:#fff3c4}"""
t = "<h3>Chạy lại tinh_ton_kho.py (do claude-1 viết) khi đổi ngân sách</h3><p>Dữ liệu GIẢ để học. Cùng dữ liệu, chỉ sửa ngan_sach_nhap_vnd trong tham-so.json.</p><table><tr><th>ngân sách (đ)</th><th>tổng tiền đề xuất (đ)</th><th>số mã được nhập</th><th>cần theo công thức, chưa xét ngân sách (đ)</th></tr>"
for r in d["doi_ngan_sach"]:
    t += f"<tr><td class=n>{v(r['ngan_sach'])}</td><td class=n>{v(r['tong_tien_de_xuat'])}</td><td class=n>{r['so_ma_duoc_nhap']}</td><td class=n>{v(r['can_theo_cong_thuc'])}</td></tr>"
t += "</table><h3>Thêm dòng lạ vào nhật ký rồi chạy lại</h3><table><tr><th>dòng thêm</th><th>script làm gì</th></tr>"
for r in d["them_dong_la_vao_nhat_ky"]:
    cls = "bad" if "DỪNG" in r["ket_qua"] else "ok"
    t += f"<tr class={cls}><td>{html.escape(r['dong_them'])}</td><td>{html.escape(r['ket_qua'])}</td></tr>"
t += "</table>"
shot_html(f"<!doctype html><meta charset=utf-8><style>{CSS}</style><div class=w id=w>{t}</div>", ROOT / "anh/10-thu-chay-lai.png", 1130, "#w")
