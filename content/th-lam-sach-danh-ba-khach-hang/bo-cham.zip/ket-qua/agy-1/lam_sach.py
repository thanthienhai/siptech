"""
lam_sach.py - Script chuẩn hóa, làm sạch và hợp nhất danh bạ khách hàng.
Thực hiện theo các quy tắc cố định, không gọi mô hình, không dùng mạng.
"""

import os
import re
import unicodedata
from collections import defaultdict
import pandas as pd

# Tập hợp ký tự tiếng Việt có dấu
VIETNAMESE_ACCENTS = set(
    "áàảãạăắằẳẵặâấầẩẫậéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵđ"
    "ÁÀẢÃẠĂẮẰẲẴẶÂẤẦẨẪẬÉÈẺẼẸÊẾỀỂỄỆÍÌỈĨỊÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢÚÙỦŨỤƯỨỪỬỮỰÝỲỶỸỴĐ"
)

def strip_accents(s: str) -> str:
    """Bỏ toàn bộ dấu tiếng Việt và chuẩn hóa về dạng chữ thường không dấu."""
    if not s:
        return ""
    s_norm = unicodedata.normalize('NFD', str(s))
    s_clean = ''.join(c for c in s_norm if unicodedata.category(c) != 'Mn')
    s_clean = s_clean.replace('đ', 'd').replace('Đ', 'D')
    return s_clean.lower()

def clean_phone(raw):
    """
    Chuẩn hóa số điện thoại theo quy tắc:
    - Chỉ giữ chữ số.
    - Đầu +84, 84 (>=11 số), 0084 đổi thành 0.
    - Ô số bị mất số 0 đầu (9 chữ số, không bắt đầu bằng 0) thì thêm 0.
    - Hợp lệ: 10 số (03, 05, 07, 08, 09) hoặc 11 số (02).
    - Còn lại: không hợp lệ (trả về None, lý do).
    """
    if raw is None or pd.isna(raw):
        return None, "Trống"
    raw_str = str(raw).strip()
    if '*' in raw_str:
        return None, f"Bị che dấu sao ({raw_str})"
    
    digits = re.sub(r'\D', '', raw_str)
    if not digits:
        return None, f"Không có chữ số ({raw_str})"
        
    # Xử lý tiền tố
    if len(digits) == 9 and not digits.startswith('0'):
        digits = '0' + digits
    elif digits.startswith('0084'):
        digits = '0' + digits[4:]
    elif raw_str.startswith('+84') or (digits.startswith('84') and len(digits) >= 11):
        digits = '0' + digits[2:]
        
    # Kiểm tra tính hợp lệ
    if len(digits) == 10 and re.match(r'^0[35789]\d{8}$', digits):
        return digits, "Di động hợp lệ"
    elif len(digits) == 11 and re.match(r'^02\d{9}$', digits):
        return digits, "Cố định hợp lệ"
    else:
        return None, f"Sai định dạng ({digits}, gốc: {raw_str})"

def clean_email(raw):
    """
    Chuẩn hóa email:
    - Cắt khoảng trắng hai đầu, đổi sang chữ thường.
    - Dấu phẩy trong tên miền đổi thành dấu chấm.
    - Kiểm tra cú pháp: thiếu @, thiếu đuôi tên miền, 2 @, khoảng trắng giữa, đuôi lạ (.con)...
    """
    if raw is None or pd.isna(raw):
        return None
    s = str(raw).strip().lower().replace(',', '.')
    if ' ' in s or s.count('@') != 1:
        return None
    user, dom = s.split('@')
    if not user or not dom or '.' not in dom:
        return None
    tld = dom.split('.')[-1]
    if tld == 'con' or tld not in ['com', 'org', 'net', 'vn']:
        return None
    return s

def clean_name(raw_name):
    """
    Chuẩn hóa họ tên:
    - Unicode NFC, bỏ khoảng trắng thừa, Viết Hoa Chữ Đầu Mỗi Từ.
    - Bỏ danh xưng ở đầu (anh, chị, cô, chú, bác; a, c; cả dạng không dấu) và tách ra.
    - Không đoán dấu cho tên không dấu.
    """
    if not raw_name or pd.isna(raw_name):
        return "", None
    norm = unicodedata.normalize('NFC', str(raw_name)).strip()
    words = norm.split()
    if not words:
        return "", None
        
    honorific = None
    first = words[0].lower()
    if first in ['anh', 'chị', 'cô', 'chú', 'bác', 'a', 'c', 'chi', 'co', 'chu', 'bac']:
        honorific = words[0]
        words = words[1:]
        
    cleaned_words = []
    for w in words:
        if '.' in w:
            parts = w.split('.')
            cleaned_words.append('.'.join(p.capitalize() for p in parts))
        else:
            cleaned_words.append(w.capitalize())
            
    return ' '.join(cleaned_words), honorific

def normalize_address(raw_addr):
    """
    Mở viết tắt địa chỉ về dạng: <số nhà> <đường>, Phường X, Quận Y, <thành phố>
    - P./p/F -> Phường, Q./q -> Quận, TP./Tp. -> Thành phố
    - HCM/TPHCM -> Thành phố Hồ Chí Minh, HN -> Hà Nội, ĐN -> Đà Nẵng, CT -> Cần Thơ, HP -> Hải Phòng
    - Bỏ chữ "Số", "đường", "đ." trước tên đường.
    - Viết Hoa Chữ Đầu Mỗi Từ. Không đoán dấu cho địa chỉ không dấu.
    """
    if not raw_addr or pd.isna(raw_addr):
        return ""
    text = unicodedata.normalize('NFC', str(raw_addr)).strip()
    text_lower = text.lower()
    
    # 1. Nhận diện và chuẩn hóa thành phố
    city = None
    pattern = None
    if re.search(r'[\s,]+(thành phố hồ chí minh|tp\.?\s*hcm|tphcm|hcm)$', text_lower):
        city = "Thành phố Hồ Chí Minh"
        pattern = r'[\s,]+(thành phố hồ chí minh|tp\.?\s*hcm|tphcm|hcm)$'
    elif re.search(r'[\s,]+(tp\.?\s*hà nội|hà nội|tp\.?\s*hn|tp\.?\s*ha noi|ha noi|hn)$', text_lower):
        city = "Hà Nội"
        pattern = r'[\s,]+(tp\.?\s*hà nội|hà nội|tp\.?\s*hn|tp\.?\s*ha noi|ha noi|hn)$'
    elif re.search(r'[\s,]+(tp\.?\s*đà nẵng|đà nẵng|tp\.?\s*da nang|da nang|đn|dn)$', text_lower):
        city = "Đà Nẵng"
        pattern = r'[\s,]+(tp\.?\s*đà nẵng|đà nẵng|tp\.?\s*da nang|da nang|đn|dn)$'
    elif re.search(r'[\s,]+(tp\.?\s*cần thơ|cần thơ|tp\.?\s*can tho|can tho|ct)$', text_lower):
        city = "Cần Thơ"
        pattern = r'[\s,]+(tp\.?\s*cần thơ|cần thơ|tp\.?\s*can tho|can tho|ct)$'
    elif re.search(r'[\s,]+(tp\.?\s*hải phòng|hải phòng|tp\.?\s*hai phong|hai phong|hp)$', text_lower):
        city = "Hải Phòng"
        pattern = r'[\s,]+(tp\.?\s*hải phòng|hải phòng|tp\.?\s*hai phong|hai phong|hp)$'

    if pattern:
        rem = re.sub(pattern, '', text, flags=re.IGNORECASE).strip().rstrip(',')
    else:
        rem = text.rstrip(',')
        
    # 2. Tách Quận ở cuối rem
    m_quan = re.search(r'[\s,]+(?:quận\s+|q\.\s*|q(?=\d)|q\s+)(.+)$', rem, re.IGNORECASE)
    if m_quan:
        quan_val = m_quan.group(1).strip()
        rem_before_quan = rem[:m_quan.start()].strip().rstrip(',')
    else:
        quan_val = ""
        rem_before_quan = rem
        
    # 3. Tách Phường ở cuối rem_before_quan
    m_phuong = re.search(r'[\s,]+(?:phường\s+|p\.\s*|p(?=\d)|f(?=\d)|f\s+|p\s+)(.+)$', rem_before_quan, re.IGNORECASE)
    if m_phuong:
        phuong_val = m_phuong.group(1).strip()
        street_part = rem_before_quan[:m_phuong.start()].strip().rstrip(',')
    else:
        phuong_val = ""
        street_part = rem_before_quan
        
    # 4. Chuẩn hóa tên đường và số nhà
    # Bỏ chữ "Số", "đường", "đ." trước tên đường
    st = re.sub(r'^\s*số\s+', '', street_part, flags=re.IGNORECASE).strip()
    st = re.sub(r'(^[\d/]+[a-zA-Z]?)\s+(?:đường|đ\.)\s*', r'\1 ', st, flags=re.IGNORECASE).strip()
    st = re.sub(r'(^[\d/]+[a-zA-Z]?)\s+(?:đường|đ\.)', r'\1 ', st, flags=re.IGNORECASE).strip()
    
    def cap_words(s):
        parts = s.split()
        res = []
        for p in parts:
            if '/' in p:
                res.append(p)
            elif '.' in p:
                res.append('.'.join(sub.capitalize() for sub in p.split('.')))
            else:
                res.append(p.capitalize())
        return ' '.join(res)
        
    st_clean = cap_words(st)
    phuong_clean = f"Phường {cap_words(phuong_val)}" if phuong_val else ""
    quan_clean = f"Quận {cap_words(quan_val)}" if quan_val else ""
    
    parts = [p for p in [st_clean, phuong_clean, quan_clean, city] if p]
    return ', '.join(parts)

def are_names_compatible(name1: str, name2: str):
    """
    Quy tắc so khớp Tên tương thích:
    - Sau khi bỏ danh xưng, bỏ dấu, bỏ hoa/thường:
      + Hai tên giống hệt
      + Hoặc chỉ khác nhau ở chữ đệm viết tắt bằng chữ cái đầu (Nguyễn V. An và Nguyễn Văn An)
    - Tên chỉ có 1 từ KHÔNG coi là tương thích với tên đầy đủ.
    - Hai tên khác chữ (Hùng và Hưng) là khác nhau.
    """
    w1 = [strip_accents(w) for w in name1.split()]
    w2 = [strip_accents(w) for w in name2.split()]
    
    if not w1 or not w2:
        return False, "Thiếu tên"
        
    if len(w1) == 1 or len(w2) == 1:
        if len(w1) == 1 and len(w2) == 1 and w1[0] == w2[0]:
            return True, "Cùng tên 1 từ"
        return False, "Tên một từ không tương thích với tên đầy đủ"
        
    if w1 == w2:
        return True, "Trùng khớp hoàn toàn"
        
    # So khớp chữ đệm viết tắt
    if len(w1) == len(w2) and len(w1) >= 3:
        if w1[0] == w2[0] and w1[-1] == w2[-1]:
            mismatch = False
            for i in range(1, len(w1) - 1):
                t1, t2 = w1[i].rstrip('.'), w2[i].rstrip('.')
                if t1 == t2:
                    continue
                if (len(t1) == 1 and len(t2) > 1 and t2.startswith(t1)) or (len(t2) == 1 and len(t1) > 1 and t1.startswith(t2)):
                    continue
                mismatch = True
                break
            if not mismatch:
                return True, "Chữ đệm viết tắt tương thích"
                
    return False, "Tên khác nhau"

def score_name(name: str) -> int:
    """Chấm điểm tên: ưu tiên tên đầy đủ, có dấu tiếng Việt, không viết tắt."""
    if not name:
        return -100
    score = 0
    words = name.split()
    has_abbr = any('.' in w or (len(w) == 1 and w.isalpha()) for w in words)
    if has_abbr:
        score -= 50
    accent_count = sum(1 for c in name if c in VIETNAMESE_ACCENTS)
    score += accent_count * 5
    score += len(name)
    return score

def score_address(addr: str) -> int:
    """Chấm điểm địa chỉ: ưu tiên địa chỉ có dấu đầy đủ và chi tiết hơn."""
    if not addr:
        return -100
    accent_count = sum(1 for c in addr if c in VIETNAMESE_ACCENTS)
    return accent_count * 5 + len(addr)

def main():
    print("=== BẮT ĐẦU QUÁ TRÌNH LÀM SẠCH VÀ HỢP NHẤT DANH BẠ ===")
    file_goc = 'danh-ba-goc.xlsx'
    if not os.path.exists(file_goc):
        raise FileNotFoundError(f"Không tìm thấy file {file_goc}")
        
    df = pd.read_excel(file_goc, sheet_name='DanhBa')
    print(f"1. Đã đọc file gốc: {len(df)} dòng.")
    print("Số ô trống mỗi cột:")
    for col, count in df.isnull().sum().items():
        print(f"   - {col}: {count} ô trống")

    sua_logs = []
    rows = []

    # BƯỚC 1: XỬ LÝ NHẬP NHẦM CỘT VÀ CHUẨN HÓA DỮ LIỆU TỪNG DÒNG
    for idx, r in df.iterrows():
        rid = r['Mã dòng']
        source = r['Nguồn']
        raw_name = str(r['Họ tên']) if pd.notna(r['Họ tên']) else ''
        raw_sdt = str(r['SĐT']) if pd.notna(r['SĐT']) else ''
        raw_email = str(r['Email']) if pd.notna(r['Email']) else ''
        raw_addr = str(r['Địa chỉ']) if pd.notna(r['Địa chỉ']) else ''
        raw_note = str(r['Ghi chú']) if pd.notna(r['Ghi chú']) else ''
        
        cur_name = raw_name
        cur_sdt = raw_sdt
        cur_email = raw_email
        cur_addr = raw_addr
        cur_note = raw_note
        
        # 1. Đổi chỗ Họ tên và Địa chỉ nếu bị nhập ngược
        # Nhận diện: Họ tên chứa số nhà/tên đường/phường và Địa chỉ là tên người
        is_name_addr = bool(re.match(r'^\s*(\d+|số\s+\d+)', raw_name, re.IGNORECASE))
        is_addr_name = bool(raw_addr and not re.search(r'\d', raw_addr))
        if is_name_addr and is_addr_name:
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'Họ tên',
                'gia_tri_cu': raw_name, 'gia_tri_moi': raw_addr,
                'quy_tac': 'Đổi cột Họ tên và Địa chỉ bị nhập nhầm'
            })
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'Địa chỉ',
                'gia_tri_cu': raw_addr, 'gia_tri_moi': raw_name,
                'quy_tac': 'Đổi cột Họ tên và Địa chỉ bị nhập nhầm'
            })
            cur_name, cur_addr = raw_addr, raw_name
            
        # 2. SĐT nằm ở cột Email (không có @ và toàn số)
        if cur_email and '@' not in cur_email and re.sub(r'\D', '', cur_email):
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'SĐT',
                'gia_tri_cu': cur_sdt, 'gia_tri_moi': cur_email,
                'quy_tac': 'Chuyển SĐT nhập nhầm ở cột Email sang SĐT'
            })
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'Email',
                'gia_tri_cu': cur_email, 'gia_tri_moi': '',
                'quy_tac': 'Xóa SĐT nhập nhầm ở cột Email'
            })
            cur_sdt = cur_email
            cur_email = ''
            
        # 3. Email nằm ở cột SĐT (chứa @ hoặc tên miền)
        if cur_sdt and ('@' in cur_sdt or any(dom in cur_sdt for dom in ['example', '.com', '.net', '.org', '.vn'])):
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'Email',
                'gia_tri_cu': cur_email, 'gia_tri_moi': cur_sdt,
                'quy_tac': 'Chuyển Email nhập nhầm ở cột SĐT sang Email'
            })
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'SĐT',
                'gia_tri_cu': cur_sdt, 'gia_tri_moi': '',
                'quy_tac': 'Xóa Email nhập nhầm ở cột SĐT'
            })
            cur_email = cur_sdt
            cur_sdt = ''
            
        # 4. SĐT nằm ở cột Ghi chú
        if cur_note and re.search(r'(\+?84\d+|\d[\d\.\s]{8,})', cur_note):
            m = re.search(r'(\+?84\d+|\d[\d\.\s]+)', cur_note)
            extracted_phone = m.group(1).strip() if m else cur_note
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'SĐT',
                'gia_tri_cu': cur_sdt, 'gia_tri_moi': extracted_phone,
                'quy_tac': 'Trích xuất SĐT nhập nhầm trong Ghi chú sang SĐT'
            })
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'Ghi chú',
                'gia_tri_cu': cur_note, 'gia_tri_moi': '',
                'quy_tac': 'Xóa SĐT nhập nhầm khỏi Ghi chú'
            })
            cur_sdt = extracted_phone
            cur_note = ''
            
        # 5. Chuẩn hóa Họ tên và tách Danh xưng
        c_name, hon = clean_name(cur_name)
        if c_name != cur_name:
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'Họ tên',
                'gia_tri_cu': cur_name, 'gia_tri_moi': c_name,
                'quy_tac': 'Chuẩn hóa Unicode NFC, bỏ danh xưng, viết hoa chữ cái đầu'
            })
        if hon:
            new_note = f"{hon}; {cur_note}" if cur_note else hon
            sua_logs.append({
                'ma_dong_goc': rid, 'cot': 'Ghi chú',
                'gia_tri_cu': cur_note, 'gia_tri_moi': new_note,
                'quy_tac': 'Chuyển danh xưng vào ghi chú'
            })
            cur_note = new_note
            
        # 6. Chuẩn hóa SĐT và tách ô có 2 SĐT
        valid_phones = []
        if cur_sdt:
            parts = re.split(r'[;/]|\s*,\s*', cur_sdt)
            invalid_phones = []
            for p in parts:
                cp, st = clean_phone(p)
                if cp:
                    valid_phones.append(cp)
                else:
                    invalid_phones.append((p, st))
                    
            if len(parts) > 1:
                clean_sdt_str = '; '.join(valid_phones)
                sua_logs.append({
                    'ma_dong_goc': rid, 'cot': 'SĐT',
                    'gia_tri_cu': cur_sdt, 'gia_tri_moi': clean_sdt_str,
                    'quy_tac': 'Tách 2 SĐT: số đầu vào sdt, số còn lại vào sdt_khac'
                })
            elif len(valid_phones) == 1:
                if valid_phones[0] != cur_sdt:
                    sua_logs.append({
                        'ma_dong_goc': rid, 'cot': 'SĐT',
                        'gia_tri_cu': cur_sdt, 'gia_tri_moi': valid_phones[0],
                        'quy_tac': 'Chuẩn hóa định dạng SĐT'
                    })
            else:
                sua_logs.append({
                    'ma_dong_goc': rid, 'cot': 'SĐT',
                    'gia_tri_cu': cur_sdt, 'gia_tri_moi': '',
                    'quy_tac': f'SĐT không hợp lệ ({invalid_phones[0][1]}): để trống cột sạch'
                })
                
        # 7. Chuẩn hóa Email
        c_email = None
        if cur_email:
            c_email = clean_email(cur_email)
            if c_email:
                if c_email != cur_email:
                    sua_logs.append({
                        'ma_dong_goc': rid, 'cot': 'Email',
                        'gia_tri_cu': cur_email, 'gia_tri_moi': c_email,
                        'quy_tac': 'Chuẩn hóa email: đổi dấu phẩy thành chấm, chữ thường, cắt khoảng trắng'
                    })
            else:
                sua_logs.append({
                    'ma_dong_goc': rid, 'cot': 'Email',
                    'gia_tri_cu': cur_email, 'gia_tri_moi': '',
                    'quy_tac': 'Email sai cú pháp: để trống cột sạch'
                })
                
        # 8. Chuẩn hóa Địa chỉ
        c_addr = ""
        if cur_addr:
            c_addr = normalize_address(cur_addr)
            if c_addr != cur_addr:
                sua_logs.append({
                    'ma_dong_goc': rid, 'cot': 'Địa chỉ',
                    'gia_tri_cu': cur_addr, 'gia_tri_moi': c_addr,
                    'quy_tac': 'Mở viết tắt địa chỉ về dạng chuẩn và viết hoa'
                })
                
        rows.append({
            'rid': rid,
            'source': source,
            'raw_name': raw_name,
            'c_name': c_name,
            'hon': hon,
            'phones': valid_phones,
            'email': c_email,
            'c_addr': c_addr,
            'note': cur_note
        })

    # BƯỚC 2: SO KHỚP VÀ GỘP DỮ LIỆU
    # Xây dựng đồ thị liên kết
    edges = defaultdict(list)
    
    # G1: Trùng SĐT hợp lệ và Tên tương thích
    phone_map = defaultdict(list)
    for r in rows:
        for p in r['phones']:
            phone_map[p].append(r)
            
    g1_edges = []
    q1_cases = []
    for p, group in phone_map.items():
        if len(group) > 1:
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    rA = group[i]
                    rB = group[j]
                    compat, reason = are_names_compatible(rA['c_name'], rB['c_name'])
                    if compat:
                        g1_edges.append((rA['rid'], rB['rid'], p, rA['c_name'], rB['c_name']))
                        edges[rA['rid']].append((rB['rid'], 'G1', f"Trùng SĐT {p}"))
                        edges[rB['rid']].append((rA['rid'], 'G1', f"Trùng SĐT {p}"))
                    else:
                        q1_cases.append((rA['rid'], rB['rid'], p, rA['c_name'], rB['c_name'], reason))

    # G2: Trùng Email hợp lệ và Tên tương thích
    email_map = defaultdict(list)
    for r in rows:
        if r['email']:
            email_map[r['email']].append(r)
            
    g2_edges = []
    for em, group in email_map.items():
        if len(group) > 1:
            for i in range(len(group)):
                for j in range(i + 1, len(group)):
                    rA = group[i]
                    rB = group[j]
                    compat, reason = are_names_compatible(rA['c_name'], rB['c_name'])
                    if compat:
                        g2_edges.append((rA['rid'], rB['rid'], em, rA['c_name'], rB['c_name']))
                        edges[rA['rid']].append((rB['rid'], 'G2', f"Trùng Email {em}"))
                        edges[rB['rid']].append((rA['rid'], 'G2', f"Trùng Email {em}"))

    # Tìm các thành phần liên thông (Gộp bắc cầu)
    visited = set()
    components = []
    for r in rows:
        rid = r['rid']
        if rid not in visited:
            comp = []
            queue = [rid]
            visited.add(rid)
            for curr in queue:
                comp.append(curr)
                for neighbor, rule, ev in edges[curr]:
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append(neighbor)
            components.append(sorted(comp))

    print(f"2. Đã phân cụm khách hàng: {len(components)} khách hàng sạch.")
    merged_groups = [c for c in components if len(c) > 1]
    print(f"   - Số nhóm đã gộp (từ 2 dòng trở lên): {len(merged_groups)} nhóm ({sum(len(c) for c in merged_groups)} dòng).")
    print(f"   - Số dòng giữ nguyên (1 dòng): {len(components) - len(merged_groups)} dòng.")

    # Tìm các ca Q2: trùng tên + trùng địa chỉ nhưng khác SĐT/Email hoặc một bên thiếu
    q2_cases = []
    for i in range(len(rows)):
        for j in range(i + 1, len(rows)):
            rA = rows[i]
            rB = rows[j]
            compA = next(c for c in components if rA['rid'] in c)
            compB = next(c for c in components if rB['rid'] in c)
            if compA == compB:
                continue
            if not rA['c_addr'] or not rB['c_addr']:
                continue
            addr_match = (rA['c_addr'] == rB['c_addr']) or (strip_accents(rA['c_addr']) == strip_accents(rB['c_addr']))
            if not addr_match:
                continue
            compat, _ = are_names_compatible(rA['c_name'], rB['c_name'])
            name_match = compat or (strip_accents(rA['c_name']) == strip_accents(rB['c_name']))
            if name_match:
                q2_cases.append((rA['rid'], rB['rid'], rA['c_name'], rB['c_name'], rA['c_addr'], rA['phones'], rB['phones'], rA['email'], rB['email']))

    # BƯỚC 3: TẠO FILE DANH BẠ SẠCH (danh-ba-sach.xlsx)
    customers = []
    for idx, comp in enumerate(components):
        ma_khach = f"KH{idx + 1:03d}"
        comp_rows = [next(r for r in rows if r['rid'] == rid) for rid in comp]
        
        # Họ tên tốt nhất
        names = [r['c_name'] for r in comp_rows if r['c_name']]
        best_name = max(names, key=score_name) if names else ""
        
        # SĐT chính và SĐT khác
        all_phones = []
        for r in comp_rows:
            for p in r['phones']:
                if p not in all_phones:
                    all_phones.append(p)
        sdt = all_phones[0] if all_phones else ""
        sdt_khac = '; '.join(all_phones[1:]) if len(all_phones) > 1 else ""
        
        # Email chính và Email khác
        all_emails = []
        for r in comp_rows:
            if r['email'] and r['email'] not in all_emails:
                all_emails.append(r['email'])
        email = all_emails[0] if all_emails else ""
        email_khac = '; '.join(all_emails[1:]) if len(all_emails) > 1 else ""
        
        # Địa chỉ tốt nhất
        addrs = [r['c_addr'] for r in comp_rows if r['c_addr']]
        best_addr = max(addrs, key=score_address) if addrs else ""
        
        # Nguồn
        sources = []
        for r in comp_rows:
            if r['source'] not in sources:
                sources.append(r['source'])
        nguon = '; '.join(sources)
        
        # Mã dòng gốc
        ma_dong_goc = '; '.join([r['rid'] for r in comp_rows])
        
        # Ghi chú tổng hợp
        notes = []
        for r in comp_rows:
            if r['hon'] and r['hon'] not in notes:
                notes.append(r['hon'])
            if r['note']:
                for n_part in r['note'].split(';'):
                    n_clean = n_part.strip()
                    if n_clean and n_clean not in notes:
                        notes.append(n_clean)
        ghi_chu = '; '.join(notes)
        
        customers.append({
            'ma_khach': ma_khach,
            'ho_ten': best_name,
            'sdt': sdt,
            'sdt_khac': sdt_khac,
            'email': email,
            'email_khac': email_khac,
            'dia_chi': best_addr,
            'nguon': nguon,
            'ma_dong_goc': ma_dong_goc,
            'ghi_chu': ghi_chu
        })

    df_clean = pd.DataFrame(customers)
    with pd.ExcelWriter('danh-ba-sach.xlsx', engine='openpyxl') as writer:
        df_clean.to_excel(writer, sheet_name='KhachHang', index=False)
    print("3. Đã tạo danh-ba-sach.xlsx (sheet KhachHang).")

    # BƯỚC 4: TẠO FILE NHẬT KÝ GỘP (nhat-ky-gop.csv)
    gop_logs = []
    for idx, comp in enumerate(components):
        ma_khach = f"KH{idx + 1:03d}"
        rep = comp[0]
        rep_row = next(r for r in rows if r['rid'] == rep)
        
        if len(comp) == 1:
            gop_logs.append({
                'ma_dong_goc': rep,
                'ma_khach': ma_khach,
                'hanh_dong': 'GIU_RIENG',
                'quy_tac': 'không',
                'bang_chung': 'Khách hàng duy nhất, không trùng SĐT hoặc email với dòng khác'
            })
        else:
            gop_logs.append({
                'ma_dong_goc': rep,
                'ma_khach': ma_khach,
                'hanh_dong': 'GIU_RIENG',
                'quy_tac': 'không',
                'bang_chung': f"Dòng đại diện cho nhóm khách hàng {ma_khach} (gồm {'; '.join(comp)})"
            })
            
            # BFS tìm đường đi từ rep đến các nút khác
            comp_set = set(comp)
            parent = {}
            edge_info = {}
            queue = [rep]
            visited_bfs = {rep}
            while queue:
                curr = queue.pop(0)
                for neighbor, rule, ev in edges[curr]:
                    if neighbor in comp_set and neighbor not in visited_bfs:
                        visited_bfs.add(neighbor)
                        parent[neighbor] = curr
                        edge_info[neighbor] = (rule, ev)
                        queue.append(neighbor)
                        
            for r in comp[1:]:
                r_row = next(x for x in rows if x['rid'] == r)
                p = parent[r]
                rule, ev = edge_info[r]
                p_row = next(x for x in rows if x['rid'] == p)
                
                if p == rep:
                    bang_chung = f"{ev} với {rep}, tên tương thích ({r_row['c_name']} và {rep_row['c_name']})"
                    gop_logs.append({
                        'ma_dong_goc': r,
                        'ma_khach': ma_khach,
                        'hanh_dong': 'GOP_VAO',
                        'quy_tac': rule,
                        'bang_chung': bang_chung
                    })
                else:
                    p_parent = parent[p]
                    p_rule, p_ev = edge_info[p]
                    bang_chung = f"Gộp bắc cầu qua {p} ({ev} với {p}; {p} {p_ev.lower()} với {p_parent})"
                    gop_logs.append({
                        'ma_dong_goc': r,
                        'ma_khach': ma_khach,
                        'hanh_dong': 'GOP_VAO',
                        'quy_tac': 'bắc cầu',
                        'bang_chung': bang_chung
                    })

    df_gop = pd.DataFrame(gop_logs)
    df_gop.to_csv('nhat-ky-gop.csv', index=False, encoding='utf-8-sig')
    print("4. Đã tạo nhat-ky-gop.csv (UTF-8 có BOM).")

    # BƯỚC 5: TẠO FILE NHẬT KÝ SỬA (nhat-ky-sua.csv)
    df_sua = pd.DataFrame(sua_logs)
    df_sua.to_csv('nhat-ky-sua.csv', index=False, encoding='utf-8-sig')
    print(f"5. Đã tạo nhat-ky-sua.csv (UTF-8 có BOM, {len(df_sua)} thay đổi ô).")

    # BƯỚC 6: TẠO FILE NGHI TRÙNG CẦN QUYẾT (nghi-trung-can-quyet.csv)
    nghi_trung = []
    nhom_id = 1
    
    # Ca Q1
    for r1, r2, p, n1, n2, reason in q1_cases:
        if "tên một từ" in reason.lower() or len(n1.split()) == 1 or len(n2.split()) == 1:
            ly_do = f"Trùng SĐT {p} nhưng một bên chỉ có tên một từ ({n1} vs {n2})"
            goi_y = f"Nghiêng về gộp nếu xác nhận tên gọi thân mật '{n1 if len(n1.split())==1 else n2}' chính là '{n2 if len(n1.split())==1 else n1}', cần gọi điện kiểm tra."
        else:
            ly_do = f"Trùng SĐT {p} nhưng họ tên khác hẳn nhau ({n1} vs {n2})"
            goi_y = "Không nên gộp vì họ tên khác nhau, có thể người thân dùng chung SĐT hoặc nhà mạng thu hồi SIM."
        nghi_trung.append({
            'nhom': nhom_id,
            'ma_dong_goc': f"{r1}; {r2}",
            'quy_tac': 'Q1',
            'ly_do': ly_do,
            'goi_y': goi_y
        })
        nhom_id += 1
        
    # Ca Q2
    for r1, r2, n1, n2, addr, p1, p2, e1, e2 in q2_cases:
        p1_str = p1[0] if p1 else "thiếu SĐT"
        p2_str = p2[0] if p2 else "thiếu SĐT"
        if not p1 or not p2:
            ly_do = f"Trùng tên ({n1}) và cùng địa chỉ ({addr}) nhưng một bên khuyết SĐT ({r1}: {p1_str}, {r2}: {p2_str})"
            goi_y = "Nghiêng về gộp vì trùng cả họ tên và địa chỉ nhà riêng cụ thể, dòng thiếu SĐT nhiều khả năng là đơn hàng chưa cập nhật."
        else:
            ly_do = f"Trùng tên ({n1}) và cùng địa chỉ ({addr}) nhưng khác SĐT ({r1}: {p1_str}, {r2}: {p2_str})"
            goi_y = "Nghiêng về gộp vì trùng họ tên và địa chỉ cụ thể, khả năng cao cùng một khách hàng sử dụng hai số điện thoại."
        nghi_trung.append({
            'nhom': nhom_id,
            'ma_dong_goc': f"{r1}; {r2}",
            'quy_tac': 'Q2',
            'ly_do': ly_do,
            'goi_y': goi_y
        })
        nhom_id += 1

    df_nghi = pd.DataFrame(nghi_trung)
    df_nghi.to_csv('nghi-trung-can-quyet.csv', index=False, encoding='utf-8-sig')
    print(f"6. Đã tạo nghi-trung-can-quyet.csv (UTF-8 có BOM, {len(df_nghi)} ca cần người quyết).")

    # BƯỚC 7: TỰ KIỂM TRA TÍNH TOÀN VẸN VÀ RÀNG BUỘC
    print("\n=== KẾT QUẢ TỰ KIỂM TRA (ASSERTIONS) ===")
    
    # Kiểm tra 1: Mỗi Mã dòng gốc xuất hiện đúng 1 lần trong nhat-ky-gop.csv
    assert len(df_gop) == len(df), f"Số dòng nhat-ky-gop ({len(df_gop)}) != số dòng gốc ({len(df)})"
    assert df_gop['ma_dong_goc'].nunique() == len(df), "Có mã dòng gốc bị lặp hoặc thiếu trong nhat-ky-gop.csv"
    print("✔ Kiểm tra 1: Mỗi Mã dòng gốc xuất hiện đúng 1 lần trong nhat-ky-gop.csv (400/400).")
    
    # Kiểm tra 2: Số dòng sạch + Số dòng bị gộp vào dòng khác = Số dòng gốc
    num_sach = len(df_clean)
    num_gop_vao = len(df_gop[df_gop['hanh_dong'] == 'GOP_VAO'])
    assert num_sach + num_gop_vao == len(df), f"Sai lệch: {num_sach} + {num_gop_vao} != {len(df)}"
    print(f"✔ Kiểm tra 2: Số dòng sạch ({num_sach}) + Số dòng bị gộp ({num_gop_vao}) = {len(df)} dòng gốc.")
    
    # Kiểm tra 3: Không SĐT sạch nào sai định dạng
    for idx, r in df_clean.iterrows():
        sdt_val = str(r['sdt']).strip()
        if sdt_val:
            assert re.match(r'^(0[35789]\d{8}|02\d{9})$', sdt_val), f"SĐT sạch không hợp lệ: {sdt_val} ở {r['ma_khach']}"
        sdt_khac_val = str(r['sdt_khac']).strip()
        if sdt_khac_val and pd.notna(r['sdt_khac']):
            for sub_p in sdt_khac_val.split(';'):
                p_c = sub_p.strip()
                if p_c:
                    assert re.match(r'^(0[35789]\d{8}|02\d{9})$', p_c), f"SĐT khác sạch không hợp lệ: {p_c} ở {r['ma_khach']}"
    print("✔ Kiểm tra 3: Toàn bộ 100% SĐT ở cột sạch đều đúng định dạng chuẩn di động (10 số 03/05/07/08/09) hoặc cố định (11 số 02).")
    print("\n=== HOÀN TẤT THÀNH CÔNG ===")

if __name__ == '__main__':
    main()
