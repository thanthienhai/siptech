"""Thử chính cái thước: tiêm lỗi biết trước vào bản sao của một file sạch, xem cham.py có bắt không.
Chạy: python -X utf8 cham_kiem_thu.py   (đọc claude-v1-lan1/nhap_hang_loat.csv, ghi cham-kiem-thu.json)"""
import csv, json, tempfile, os, copy
from pathlib import Path
import cham
H = Path(__file__).parent
rows = list(csv.DictReader(open(H / "claude-v1-lan1" / "nhap_hang_loat.csv", encoding="utf-8-sig")))
def idx(sku): return next(i for i, r in enumerate(rows) if r["sku"] == sku)
FAULTS = [  # (tên lỗi, sku, cột, hàm sửa, khoá lỗi mong đợi)
 ("từ cấm 'số 1'", "VN-004", "mo_ta", lambda v: v + " Đây là sản phẩm số 1.", "tu_cam"),
 ("từ cấm không dấu 'tot nhat'", "VN-005", "gach_1", lambda v: "Tot nhat thi truong. " + v, "tu_cam"),
 ("số bịa: đổi 150 ml thành 250 ml", "VN-004", "mo_ta", lambda v: v.replace("150 ml", "250 ml"), "so_ngoai_bang"),
 ("số từ ghi chú: 15%", "VN-012", "mo_ta", lambda v: v.replace("10%", "15%"), "so_ngoai_bang"),
 ("bịa chứng nhận FDA", "VN-008", "mo_ta", lambda v: v + " Đạt chuẩn FDA.", "cum_ngoai_bang"),
 ("bịa 'lành tính'", "VN-013", "tu_khoa", lambda v: v + ";lành tính", "cum_ngoai_bang"),
 ("bịa 'chính hãng'", "VN-014", "mo_ta", lambda v: v + " Hàng chính hãng.", "cum_ngoai_bang"),
 ("nói đã công bố khi đang chờ duyệt", "VN-001", "mo_ta", lambda v: v + " Vườn Nhỏ đã có phiếu công bố.", "cong_bo_khong_co_phieu"),
 ("tự điền dung tích cho SKU thiếu", "VN-029", "mo_ta", lambda v: v.replace("CẦN BỔ SUNG: dung_tich", "300 ml"), "so_ngoai_bang"),
 ("SKU thiếu mà trạng thái SAN_SANG", "VN-025", "trang_thai", lambda v: "SAN_SANG", "trang_thai_sai"),
 ("tiêu đề quá ngắn", "VN-010", "tieu_de", lambda v: "Vườn Nhỏ", "dai_tieu_de"),
 ("mô tả quá dài", "VN-011", "mo_ta", lambda v: v * 5, "dai_mo_ta"),
 ("emoji", "VN-015", "mo_ta", lambda v: v + " \U0001F60A", "giong"),
 ("gọi 'quý khách'", "VN-016", "mo_ta", lambda v: v + " Quý khách yên tâm.", "giong"),
 ("báo động giả CẦN BỔ SUNG ở SKU đủ", "VN-017", "mo_ta", lambda v: v + " CẦN BỔ SUNG: dung_tich.", "bao_dong_gia_CAN_BO_SUNG"),
 ("chép lời đồn 'bán chạy'", "VN-009", "mo_ta", lambda v: v + " Bán chạy khu vực.", "tu_cam"),
]
out = []
for name, sku, col, fn, key in FAULTS:
    rs = copy.deepcopy(rows); i = idx(sku); rs[i][col] = fn(rs[i][col])
    p = tempfile.mktemp(suffix=".csv")
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cham.COLS); w.writeheader(); w.writerows(rs)
    r = cham.cham(p, "t"); os.unlink(p)
    got = r["per_sku"][sku]["loi"]
    out.append({"loi": name, "sku": sku, "mong_doi": key, "bat_duoc": key in got, "chi_tiet": got.get(key)})
(H / "cham-kiem-thu.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
print(sum(o["bat_duoc"] for o in out), "/", len(out))
for o in out:
    if not o["bat_duoc"]: print("KHÔNG BẮT:", o["loi"])
