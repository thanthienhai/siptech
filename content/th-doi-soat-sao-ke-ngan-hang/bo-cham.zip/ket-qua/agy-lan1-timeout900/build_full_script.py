import pandas as pd
import openpyxl, re, csv, unicodedata, json

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

def parse_date_to_iso(val):
    if isinstance(val, pd.Timestamp):
        return val.strftime('%Y-%m-%d')
    s = str(val).strip()
    m = re.match(r'(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})', s)
    if m:
        d, mth, y = m.groups()
        return f"{int(y):04d}-{int(mth):02d}-{int(d):02d}"
    return s[:10]

# Let's write the complete doi_soat.py script!
