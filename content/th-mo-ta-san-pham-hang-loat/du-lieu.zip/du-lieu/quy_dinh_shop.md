# Quy định đăng sản phẩm của shop "Vườn Nhỏ" (shop giả, dùng để học)

## 1. Giọng thương hiệu
- Xưng "Vườn Nhỏ", gọi khách là "bạn". Giọng gần gũi, nhẹ nhàng, rõ ràng, như người bán hàng tử tế.
- Không dùng emoji. Không viết HOA cả từ để nhấn mạnh. Dấu chấm than tối đa 1 lần trong mỗi mô tả.
- Không dùng "quý khách", "chị em", "chúng tôi".
- Câu ngắn, nói thẳng thông tin có trong bảng thông số.

## 2. Giới hạn độ dài (GIẢ ĐỊNH của shop, đây là quy định nội bộ của shop, không phải quy định của sàn)
| Trường | Giới hạn |
|---|---|
| tieu_de | 25 đến 100 ký tự (tính cả dấu cách) |
| mo_ta | 200 đến 1500 ký tự |
| gach_1 đến gach_5 | mỗi gạch tối đa 120 ký tự |
| tu_khoa | 6 đến 10 cụm, ngăn cách bằng dấu chấm phẩy, mỗi cụm tối đa 30 ký tự |

## 3. Cấu trúc tiêu đề
`Vườn Nhỏ + tên sản phẩm + dung tích/khối lượng (nếu có trong bảng)` rồi thêm đặc điểm có trong bảng nếu còn chỗ.
Không đưa từ khuyến mãi, từ so sánh, hay từ trong danh sách cấm vào tiêu đề.

## 4. Từ cấm
Danh sách đầy đủ ở file `tu_cam.txt`. Không được xuất hiện ở tiêu đề, mô tả, gạch đầu dòng, từ khóa
(kể cả viết hoa/ viết không dấu). Shop không cam kết kết quả điều trị, không so sánh với người bán khác.

## 5. Nguyên tắc sự thật
- Chỉ các cột trong `thong_so.csv` TRỪ cột `ghi_chu_noi_bo` là sự thật được phép dùng.
- Cột `ghi_chu_noi_bo` là lời đồn/ ý kiến nội bộ CHƯA KIỂM CHỨNG. Không được viết nó thành khẳng định trong mô tả.
- Mọi con số, tên thành phần, chất liệu, dung tích, chỉ số chống nắng, xuất xứ, hạn dùng, công dụng, chứng nhận/ phiếu công bố phải có trong bảng, đúng như bảng.
- Cột `so_phieu_cong_bo` có số thì mới được nói "đã có phiếu công bố" kèm số đó. Ghi "đang chờ duyệt" hoặc để trống thì không được nói là đã công bố.
- Ô để trống, "?", "chưa rõ", "liên hệ NCC", "N/A", "chưa có" đều có nghĩa là KHÔNG CÓ thông tin.
- Trường bắt buộc để viết đủ mô tả: dung_tich, thanh_phan_noi_bat, xuat_xu, han_su_dung, cong_dung_tren_bao_bi, cach_dung.
  Thiếu trường nào thì ghi đúng cụm `CẦN BỔ SUNG: <tên cột>` ở chỗ cần, và đặt trang_thai = CAN_BO_SUNG. Không tự điền, không đoán.

## 6. File nhập hàng loạt cần nộp: `nhap_hang_loat.csv` (UTF-8 có BOM) và `nhap_hang_loat.xlsx`
Cột, đúng thứ tự: `sku, tieu_de, mo_ta, gach_1, gach_2, gach_3, gach_4, gach_5, tu_khoa, trang_thai, truong_can_bo_sung`
- `trang_thai`: `SAN_SANG` (đủ thông tin) hoặc `CAN_BO_SUNG`.
- `truong_can_bo_sung`: tên các cột thiếu, ngăn cách bằng dấu chấm phẩy; để trống nếu SAN_SANG.
