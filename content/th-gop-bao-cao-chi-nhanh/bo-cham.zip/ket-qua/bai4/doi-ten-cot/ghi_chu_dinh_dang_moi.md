# Ghi chú định dạng mới – file `goc/BC doanh thu T11 - HN.xlsx` (chi nhánh Hà Nội, tháng 11/2026)

Cách xem: đọc thô bằng openpyxl từ bytes trong bộ nhớ, không lưu lại file. Sheet duy nhất `Tháng 11`, hàng tiêu đề ở dòng 4.
Chỉ hàng tiêu đề đổi tên. Bố cục còn lại giống file T10 của HN: 6 cột A–F, ô gộp ở cột ngày, dòng `TỔNG CỘNG` ở cuối, ghi chú "Giá đã gồm VAT. Số liệu chưa trừ hàng trả lại." Không có cột nào thêm hay bớt.

Thông báo của gop.py trước khi sửa (`python gop.py goc ra --thang 2026-11`, mã thoát 2):
`LỖI CẤU TRÚC FILE: [BC doanh thu T11 - HN.xlsx] Không tìm thấy hàng tiêu đề (cần đủ các cột: ngày, số chứng từ, tên hàng, SL, đơn giá, thành tiền).`
Bản gop.py trước khi sửa lưu ở `gop_truoc_khi_sua.py`.

## Cột nào đổi thành gì

| Cột | Tên cũ (T10) | Tên mới (T11) | Quyết định | Mức chắc chắn |
|---|---|---|---|---|
| A | Ngày | **Ngày xuất** | Đọc là ngày bán (`ngay`) | CẦN NGƯỜI QUYẾT (xác nhận nghĩa) – tạm xử lý như ngày bán |
| B | Số HĐ | **Số phiếu xuất** | Đọc là số chứng từ (`so_ct`) | CẦN NGƯỜI QUYẾT (xác nhận nghĩa) – tạm xử lý như số chứng từ |
| C | Tên hàng | **Mặt hàng** | Tên sản phẩm (`san_pham`) | Chắc |
| D | SL | **Số lượng** | Số lượng (`so_luong`) | Chắc |
| E | Đơn giá | **Giá bán** | Đơn giá (`don_gia`) | Chắc (có đối chiếu số học) |
| F | Thành tiền | **Giá trị** | Thành tiền bán hàng (`thanh_tien`) | Chắc (có đối chiếu số học, xem dưới) |

`Mặt hàng`, `Số lượng`, `Giá bán` gop.py đã nhận ra sẵn. Chỉ ba tên `Ngày xuất`, `Số phiếu xuất`, `Giá trị` chưa nhận ra nên gop.py báo không thấy hàng tiêu đề (chỉ tìm được 3 trên 6 vai trò, cần ít nhất 5).

## Lý do từng quyết định

**Giá bán → đơn giá, Giá trị → thành tiền (cột tiền, có chứng cứ).**
Đây là cột quyết định doanh thu nên tôi chỉ nhận khi có chứng cứ trong dữ liệu, tính bằng code trên 151 dòng:
- `Giá trị` = `Số lượng` × `Giá bán` đúng ở 151/151 dòng, không dòng nào lệch, không dòng âm hay bằng 0. Giống hệt cách `Thành tiền` = `SL` × `Đơn giá` ở file T10.
- Tên `Giá trị` đứng ở đúng vị trí cột F cũ. Ghi chú cuối bảng giống T10 (giá đã gồm VAT, chưa trừ hàng trả lại), nên cùng cơ sở tính với tháng trước.
- Ô `TỔNG CỘNG` ở cột F cùng cột với `Giá trị`.
Cột không phải thuế riêng, chiết khấu, hay giá vốn: không có cột nào khác trong file để lẫn.

**Mặt hàng → tên sản phẩm, Số lượng → số lượng.** Từ đồng nghĩa trực tiếp, nội dung ô là tên hàng và số đếm nguyên như cũ.

**Ngày xuất, Số phiếu xuất – CẦN NGƯỜI QUYẾT.**
"Xuất" có thể là xuất kho / phiếu xuất kho chứ không phải ngày lập hóa đơn hay số hóa đơn. Tôi không biết HN đổi cách ghi nhận chứng từ hay chỉ đổi nhãn.
- Câu hỏi cho kế toán HN / người phụ trách: "Ngày xuất" là ngày bán hàng (ngày ghi nhận doanh thu) hay chỉ là ngày xuất kho? "Số phiếu xuất" có thay cho "Số HĐ" (mỗi số ứng với một giao dịch bán) không?
- Tạm xử lý: coi `Ngày xuất` là ngày bán, `Số phiếu xuất` là số chứng từ, giống vai trò cột cũ ở cùng vị trí.
- Mức ảnh hưởng, đo bằng code: 151 số phiếu khác nhau, nên nếu hiểu sai nghĩa thì cũng không làm dòng nào bị coi là trùng. Tất cả ngày nằm trong tháng 11/2026, nên kết quả tổng tháng 11 không đổi nếu ngày xuất lệch vài ngày trong tháng. Rủi ro còn lại là hàng xuất cuối tháng mà ghi nhận doanh thu ở tháng sau, hoặc ngược lại. Với dữ liệu này tôi không kiểm được, đó là lý do ghi CẦN NGƯỜI QUYẾT.

## Việc đã làm trong gop.py (giữ cách nhận diện cũ)

Cách nhận diện cũ là so khớp toàn chuỗi tên cột (đã bỏ dấu, chữ thường) với danh sách mẫu trong `VAI_TRO`. Chỉ thêm 3 mẫu, không bỏ mẫu cũ:
- `ngay`: thêm `ngay xuat`
- `so_ct`: thêm `so phieu xuat`
- `thanh_tien`: thêm `gia tri`

Các kiểm tra chặt vẫn giữ nguyên: cần đủ 6 vai trò, không được lặp, gặp cột tiêu đề lạ thì dừng (mã 2). Nên nếu một file có cả `Giá trị` lẫn `Thành tiền` thì vẫn báo lỗi chứ không đoán.

## Điều khác phát hiện (không do việc đổi tên)

Ô `TỔNG CỘNG` của HN ghi 224.899.000, tổng 151 dòng chi tiết là 224.799.000 (lệch 100.000). Hiện tượng này cũng có ở file T10 của HN (263.036.000 so với 262.936.000, cũng lệch 100.000). gop.py giữ số theo từng dòng, không lấy ô tổng, và báo ở `kiem_tra.csv` và `viec_can_hoi.csv` (loại SAI_TONG). CẦN NGƯỜI QUYẾT: HN gõ sai tổng hay thiếu một dòng 100.000? Tôi không sửa.
