import pandas as pd
from run_full_analysis import df_main, NGAN_SACH

# Let's inspect the two allocation schemes:
# Scheme 1: Greedy by rank (SAP_HET -> A -> B -> C, by so_ngay_ton)
# Items 1-9 full, Item 10 (TH001) partial (76/128), Items 11-26 zero.
# Total: 29,990,000 VND

# Scheme 2: Balanced Class A
# All 7 SAP_HET items full (14,406,000)
# All 8 Class A items in OK:
# VT005: 120 (6,240,000)
# MP005: 24 (2,352,000)
# TH002: 24 (1,104,000)
# TH009: 144 (460,800)
# TH008: 360 (2,700,000)
# MP003: 12 (1,056,000)
# MP012: 24 (744,000)
# TH001: 8 (736,000)
# Total: 29,798,800 VND

print('Scheme 1 total:', 14406000 + 6240000 + 2352000 + 76 * 92000)
print('Scheme 2 total:', 14406000 + 6240000 + 2352000 + 1104000 + 460800 + 2700000 + 1056000 + 744000 + 8 * 92000)
