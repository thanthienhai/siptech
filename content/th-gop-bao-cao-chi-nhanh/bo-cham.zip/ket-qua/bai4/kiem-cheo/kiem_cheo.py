#!/usr/bin/env python3
"""Kiểm chéo ĐỘC LẬP: tổng từng chi nhánh trong ra/ có khớp với file gốc trong goc/ không.

Nguyên tắc:
  * Đọc thẳng các file .xlsx trong goc/ (chỉ đọc, không ghi).
  * KHÔNG dùng ra/hop_nhat.csv. Từ ra/ chỉ đọc đúng file tong_hop_chi_nhanh.csv
    (số dòng + doanh thu từng chi nhánh) để đối chiếu.
  * Mọi phép cộng/trừ/so sánh tiền làm bằng số nguyên (đồng) trong code.
  * Kết quả ghi ra kiem_cheo.md cạnh script. Không đụng vào goc/ và ra/.

Chạy:  python -I -X utf8 kiem_cheo.py
"""
import csv
import datetime as dt
import itertools
import re
import sys
from collections import defaultdict
from pathlib import Path

import openpyxl
from openpyxl.utils import range_boundaries

BASE = Path(__file__).resolve().parent
GOC = BASE / "goc"
RA_TONG_HOP = BASE / "ra" / "tong_hop_chi_nhanh.csv"
OUT_MD = BASE / "kiem_cheo.md"

# file gốc -> mã chi nhánh (theo tiêu đề trong chính file; mã khớp cột chi_nhanh của ra/)
FILES = {
    "BC doanh thu T10 - HN.xlsx": ("HN", "Hà Nội"),
    "Bao cao thang 10 - DN (final).xlsx": ("DN", "Đà Nẵng"),
    "BienHoa-102026.xlsx": ("BH", "Biên Hòa"),
    "CT_T10_DoanhThu.xlsx": ("CT", "Cần Thơ"),
    "DoanhThu_HP_102026.xlsx": ("HP", "Hải Phòng"),
    "NhaTrang_doanhthu_T10.xlsx": ("NT", "Nha Trang"),
}
THANG = (2026, 10)

# nhãn của dòng "tổng" (không tính "Cộng tuần n": đó là dòng cộng tuần, xử lý riêng)
RE_TONG = re.compile(r"^\s*(tổng cộng|tổng tháng|tổng|total|cộng)\s*:?\s*$", re.I)
RE_TUAN = re.compile(r"^\s*cộng tuần\s*\d+\s*$", re.I)


# ----------------------------------------------------------------------------
# Tiện ích số tiền / ngày (toàn bộ dùng số nguyên, không dùng float cho tiền)
# ----------------------------------------------------------------------------
class KhongDoc(ValueError):
    pass


def doc_tien(v):
    """Ô tiền -> int đồng. Chấp nhận số, '165.000đ', '1,800,000'. Không đoán: lạ thì báo lỗi."""
    if isinstance(v, bool) or v is None:
        raise KhongDoc(repr(v))
    if isinstance(v, int):
        return v
    if isinstance(v, float):
        if v != int(v):
            raise KhongDoc(repr(v))
        return int(v)
    s = str(v).strip().replace("đ", "").replace("₫", "").strip()
    m = re.fullmatch(r"(-?)(\d{1,3}(?:[.,]\d{3})+|\d+)", s)
    if not m:
        raise KhongDoc(repr(v))
    return int(m.group(1) + re.sub(r"[.,]", "", m.group(2)))


def fmt(n):
    """int -> '1.234.567' (kiểu Việt Nam), có dấu +/- khi cần qua fmt_signed."""
    return f"{n:,}".replace(",", ".")


def fmt_signed(n):
    return ("+" if n > 0 else "") + fmt(n)


def phan_tich_ngay_chuoi(s):
    """Tách chuỗi ngày thành 3 số + dấu phân cách; trả về (sep, [a, b, c])."""
    m = re.fullmatch(r"\s*(\d{1,4})([/\-.])(\d{1,2})\2(\d{1,4})\s*", s)
    if not m:
        raise KhongDoc(repr(s))
    return m.group(2), [int(m.group(1)), int(m.group(3)), int(m.group(4))]


def thu_ngay(y, m, d):
    try:
        return dt.date(y, m, d)
    except ValueError:
        return None


def cac_cach_doc(sep, abc):
    """Các cách đọc có thể của một chuỗi ngày 3 phần: {tên_định_dạng: date|None}."""
    a, b, c = abc
    if c < 100:  # năm 2 chữ số
        c += 2000
    out = {}
    if a > 31 or a >= 1000:  # bắt đầu bằng năm: yyyy-mm-dd
        out["yyyy-mm-dd"] = thu_ngay(a, b, c if c < 100 else c)
        return out
    out["dd-mm-yy"] = thu_ngay(c, b, a)
    out["mm-dd-yy"] = thu_ngay(c, a, b)
    return out


# ----------------------------------------------------------------------------
# Đọc một file gốc
# ----------------------------------------------------------------------------
def doc_file(path, ma):
    wb_f = openpyxl.load_workbook(path)  # công thức
    wb_v = openpyxl.load_workbook(path, data_only=True)  # giá trị đã tính sẵn trong file
    if len(wb_f.worksheets) != 1:
        raise SystemExit(f"{path.name}: có {len(wb_f.worksheets)} sheet, cần xem tay")
    ws, wv = wb_f.worksheets[0], wb_v.worksheets[0]

    # ô gộp cột A (ngày): ô không phải góc trên-trái đọc ra None -> lấy giá trị ô góc
    gop = {}
    for rg in ws.merged_cells.ranges:
        c1, r1, c2, r2 = range_boundaries(str(rg))
        if c1 == 1 and c2 == 1 and r2 > r1:
            for r in range(r1, r2 + 1):
                gop[r] = (ws.cell(r1, 1).value, r1)

    res = {
        "ma": ma, "file": path.name, "sheet": ws.title, "tieu_de": [],
        "dong": [], "khong_doc": [], "tong_ghi": [], "cong_tuan": [], "khac": [],
        "an": {"hang": [r for r, d in ws.row_dimensions.items() if d.hidden],
               "cot": [c for c, d in ws.column_dimensions.items() if d.hidden]},
    }
    for row in ws.iter_rows():
        r = row[0].row
        a, b, c, d, e, f = [x.value for x in row[:6]]
        vals = [a, b, c, d, e, f]
        if all(v is None for v in vals):
            continue
        # dòng dữ liệu: có mã chứng từ (cột B), số lượng (D) và thành tiền (F)
        if isinstance(b, str) and b.strip() and d is not None and f is not None:
            ngay_goc, ngay_goc_dong = a, r
            tu_gop = False
            if a is None and r in gop:
                ngay_goc, ngay_goc_dong = gop[r]
                tu_gop = True
            rec = {"r": r, "id": b.strip(), "ngay_goc": ngay_goc, "ngay_tu_o_gop": tu_gop,
                   "sp": c, "sl_goc": d, "gia_goc": e, "tien_goc": f}
            try:
                rec["sl"] = doc_tien(d)
                rec["gia"] = doc_tien(e)
                rec["tien"] = doc_tien(f)
            except KhongDoc as ex:
                # trước dòng dữ liệu đầu tiên: đó là dòng tên cột; sau đó: dòng thật sự không đọc được
                if res["dong"]:
                    res["khong_doc"].append((r, vals, str(ex)))
                else:
                    res["tieu_de"].append((r, " | ".join(str(v) for v in vals if v is not None)))
                continue
            res["dong"].append(rec)
            continue
        # dòng tổng / cộng tuần: nhãn nằm ở A, C hoặc E, số ở F
        nhan = next((x for x in (a, c, e) if isinstance(x, str) and (RE_TONG.match(x) or RE_TUAN.match(x))), None)
        if nhan is not None and f is not None:
            cached = wv.cell(r, 6).value
            item = {"r": r, "nhan": nhan.strip(), "raw": f, "cached": cached}
            if RE_TUAN.match(nhan):
                res["cong_tuan"].append(item)
            else:
                res["tong_ghi"].append(item)
            continue
        # còn lại: tiêu đề, tên cột, ghi chú...
        txt = [str(v) for v in vals if v is not None]
        (res["tieu_de"] if r <= 8 and not res["dong"] else res["khac"]).append((r, " | ".join(txt)))
    return res


# ----------------------------------------------------------------------------
# Ngày: quyết định định dạng cho CẢ FILE rồi mới gán từng dòng
# ----------------------------------------------------------------------------
def gan_ngay(res):
    """Gán rec['ngay'] (date hoặc None) + ghi chú phương pháp. Trả về dict thông tin về ngày."""
    info = {"kieu": None, "mo_ho_rieng": 0, "khong_xac_dinh": [], "thieu_ngay": []}
    chuoi = [x for x in res["dong"] if isinstance(x["ngay_goc"], str)]
    if chuoi:
        # đếm số dòng mà mỗi cách đọc cho ngày hợp lệ -> loại cách đọc làm hỏng ngày nào đó
        hop_le = None
        phan_tich = {}
        for x in chuoi:
            sep, abc = phan_tich_ngay_chuoi(x["ngay_goc"])
            cach = cac_cach_doc(sep, abc)
            phan_tich[x["r"]] = cach
            ok = {k for k, v in cach.items() if v is not None}
            hop_le = ok if hop_le is None else (hop_le & ok)
        info["cach_con_lai"] = sorted(hop_le)
        if len(hop_le) == 1:
            info["kieu"] = next(iter(hop_le))
            info["can_cu"] = "loại trừ: cách đọc còn lại tạo ra ngày không tồn tại ở ít nhất một dòng"
        else:
            # cả hai cùng hợp lệ: chọn cách cho nhiều ngày trong tháng 10/2026 nhất — CHỈ LÀ SUY ĐOÁN
            dem = {k: sum(1 for x in chuoi if phan_tich[x["r"]][k] and (phan_tich[x["r"]][k].year, phan_tich[x["r"]][k].month) == THANG) for k in hop_le}
            info["kieu"] = max(dem, key=dem.get)
            info["can_cu"] = f"SUY ĐOÁN (cả hai cách đều hợp lệ): {dem}"
        for x in chuoi:
            cach = phan_tich[x["r"]]
            x["ngay"] = cach[info["kieu"]]
            # dòng đọc riêng lẻ có thể hiểu thành 2 ngày khác nhau (cả hai hợp lệ và khác nhau)
            ds = {v for v in cach.values() if v is not None}
            if len(ds) > 1:
                info["mo_ho_rieng"] += 1
                x["mo_ho_rieng"] = True
    for x in res["dong"]:
        g = x["ngay_goc"]
        if isinstance(g, dt.datetime):
            x["ngay"] = g.date()
        elif isinstance(g, dt.date):
            x["ngay"] = g
        elif g is None:
            x["ngay"] = None
            info["thieu_ngay"].append(x["r"])
        elif not isinstance(g, str):
            x["ngay"] = None
            info["khong_xac_dinh"].append(x["r"])
    # DN, HN, BH, CT sắp theo ngày: kiểm tra thứ tự tăng dần để chứng thực kiểu đọc ngày
    ds = [x["ngay"] for x in res["dong"] if x.get("ngay")]
    info["tang_dan"] = all(ds[i] <= ds[i + 1] for i in range(len(ds) - 1))
    return info


# ----------------------------------------------------------------------------
# Phân tích bất thường
# ----------------------------------------------------------------------------
def phan_tich(res):
    dong = res["dong"]
    kq = {}
    kq["n"] = len(dong)
    kq["tong_dong"] = sum(x["tien"] for x in dong)
    kq["tong_khong_doc"] = len(res["khong_doc"])

    # (1) thành tiền != SL x giá
    lech = []
    for x in dong:
        tinh = x["sl"] * x["gia"]
        if tinh != x["tien"]:
            lech.append({**x, "tinh": tinh, "hieu": tinh - x["tien"]})
    kq["lech_sl_gia"] = lech

    # (2) trùng mã chứng từ
    theo_id = defaultdict(list)
    for x in dong:
        theo_id[x["id"]].append(x)
    trung_y_het, trung_khac_noi_dung = [], []
    for k, ds in theo_id.items():
        if len(ds) > 1:
            dau, con_lai = ds[0], ds[1:]
            for y in con_lai:
                same = all(dau[f] == y[f] for f in ("ngay", "sp", "sl", "gia", "tien"))
                (trung_y_het if same else trung_khac_noi_dung).append((dau, y))
    kq["trung_y_het"] = trung_y_het
    kq["trung_khac_noi_dung"] = trung_khac_noi_dung

    # (3) ngoài tháng 10/2026; tách: chắc chắn ngoài tháng / có thể do hoán đổi ngày-tháng
    ngoai = [x for x in dong if x.get("ngay") and (x["ngay"].year, x["ngay"].month) != THANG]
    for x in ngoai:
        # đọc hoán đổi ngày<->tháng có rơi vào tháng 10/2026 không?
        x["ngay_hoan_doi"] = thu_ngay(x["ngay"].year, x["ngay"].day, x["ngay"].month)
        x["co_the_hoan_doi"] = bool(x["ngay_hoan_doi"] and (x["ngay_hoan_doi"].year, x["ngay_hoan_doi"].month) == THANG)
    kq["ngoai_thang"] = ngoai
    kq["ngoai_thang_chac"] = [x for x in ngoai if not x["co_the_hoan_doi"]]
    kq["ngoai_thang_mo_ho"] = [x for x in ngoai if x["co_the_hoan_doi"]]
    # với file có thứ tự ngày: ngày hoán đổi có nằm giữa ngày hai dòng liền kề không?
    cac_dong = res["dong"]
    ds_con_lai = [y["ngay"] for y in cac_dong if y.get("ngay") and not y.get("co_the_hoan_doi")]
    kq["tang_dan_tru_mo_ho"] = all(ds_con_lai[i] <= ds_con_lai[i + 1] for i in range(len(ds_con_lai) - 1))
    for i, x in enumerate(cac_dong):
        if x.get("co_the_hoan_doi") and kq["tang_dan_tru_mo_ho"]:
            truoc = next((y["ngay"] for y in reversed(cac_dong[:i]) if y.get("ngay") and not y.get("co_the_hoan_doi") and (y["ngay"].year, y["ngay"].month) == THANG), None)
            sau = next((y["ngay"] for y in cac_dong[i + 1:] if y.get("ngay") and not y.get("co_the_hoan_doi") and (y["ngay"].year, y["ngay"].month) == THANG), None)
            x["khop_vi_tri"] = bool(truoc and sau and truoc <= x["ngay_hoan_doi"] <= sau)
            x["lang_gieng"] = (truoc, sau)

    # (4) dòng trả hàng / âm
    kq["am"] = [x for x in dong if x["tien"] < 0 or x["sl"] < 0]

    # (5) cùng nội dung nhưng KHÁC mã (chỉ để biết, không coi là trùng)
    nhom = defaultdict(list)
    for x in dong:
        nhom[(x.get("ngay"), x["sp"], x["sl"], x["gia"], x["tien"])].append(x)
    kq["giong_noi_dung_khac_ma"] = [v for v in nhom.values() if len({y["id"] for y in v}) > 1]
    return kq


def kiem_tong_ghi(res, kq):
    """Lấy con số tổng chi nhánh tự ghi + tự kiểm tra con số đó có đúng với chính file không."""
    tg = res["tong_ghi"]
    out = {"so_dong_tong": len(tg), "ghi_chu": []}
    if len(tg) != 1:
        out["gia_tri"] = None
        out["ghi_chu"].append(f"tìm thấy {len(tg)} dòng tổng, cần xem tay")
        return out
    t = tg[0]
    out["r"] = t["r"]
    out["nhan"] = t["nhan"]
    raw, cached = t["raw"], t["cached"]
    if isinstance(raw, str) and raw.startswith("="):
        out["cong_thuc"] = raw
        out["gia_tri"] = doc_tien(cached)  # giá trị Excel đã tính sẵn trong file
        out["ghi_chu"].append(f"ô là công thức `{raw}`, lấy giá trị đã tính sẵn trong file")
    else:
        out["gia_tri"] = doc_tien(raw)

    # tự kiểm lại công thức bằng code
    if res["ma"] == "CT":
        m = re.fullmatch(r"=SUM\(F(\d+):F(\d+)\)", out["cong_thuc"])
        a, b = int(m.group(1)), int(m.group(2))
        tong = sum(x["tien"] for x in res["dong"] if a <= x["r"] <= b)
        out["tinh_lai_cong_thuc"] = tong
        out["cong_thuc_dung"] = tong == out["gia_tri"]
    if res["ma"] == "BH":
        refs = [int(i) for i in re.findall(r"F(\d+)", out["cong_thuc"])]
        ct = {x["r"]: doc_tien(x["cached"] if isinstance(x["raw"], str) else x["raw"]) for x in res["cong_tuan"]}
        out["tinh_lai_cong_thuc"] = sum(ct[i] for i in refs)
        out["cong_thuc_dung"] = out["tinh_lai_cong_thuc"] == out["gia_tri"]
        # từng tuần: số ghi vs tổng các dòng nằm giữa dòng cộng tuần trước và dòng này
        moc = sorted(ct)
        tuan = []
        truoc = 0
        for r in moc:
            s = sum(x["tien"] for x in res["dong"] if truoc < x["r"] < r)
            sl = sum(x["sl"] for x in res["dong"] if truoc < x["r"] < r)
            tuan.append({"r": r, "ghi": ct[r], "tinh": s, "sl_tinh": sl, "n": sum(1 for x in res["dong"] if truoc < x["r"] < r)})
            truoc = r
        out["tuan"] = tuan
        out["tong_cong_tuan_ghi"] = sum(ct.values())
        # dòng dữ liệu nằm sau dòng cộng tuần cuối (nếu có) sẽ không thuộc tuần nào
        out["dong_ngoai_tuan"] = [x["id"] for x in res["dong"] if x["r"] > moc[-1]]
    return out


def tim_giai_thich(muc_tieu, tac_dong):
    """Tìm tập con các nhóm nguyên nhân mà tổng tác động == mục tiêu (so khớp đến từng đồng).

    tac_dong: {ten: tác động lên tổng của ra/ nếu ra/ đã xử lý nhóm đó}.
    Trả về danh sách các tổ hợp khớp chính xác.
    """
    ten = [k for k, v in tac_dong.items() if v != 0]
    ket_qua = []
    for k in range(0, len(ten) + 1):
        for tohop in itertools.combinations(ten, k):
            if sum(tac_dong[t] for t in tohop) == muc_tieu:
                ket_qua.append(list(tohop))
    return ket_qua


def doc_ra():
    out = {}
    with open(RA_TONG_HOP, encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            out[r["chi_nhanh"]] = {"so_dong": int(r["so_dong"]), "doanh_thu": doc_tien(r["doanh_thu"])}
    return out




# ----------------------------------------------------------------------------
# Đối soát nguyên nhân (bằng code, khớp đến từng đồng)
# ----------------------------------------------------------------------------
def dung_nhom(res, kq):
    """Các nhóm nguyên nhân có thể làm một tổng khác tổng-các-dòng.

    tien    = tác động lên tổng NẾU người tính tổng đã xử lý nhóm đó
              (loại dòng -> âm; dùng SL×giá thay thành tiền ghi -> +Σ(SL×giá − tiền ghi)).
    so_dong = tác động lên số dòng.
    """
    ids = lambda ds: ", ".join(x["id"] for x in ds)
    nhom = {}
    if kq["trung_y_het"]:
        ds = [y for _, y in kq["trung_y_het"]]
        nhom["trung"] = {"dong": ds, "tien": -sum(x["tien"] for x in ds), "so_dong": -len(ds),
                         "mo_ta": f"{len(ds)} dòng trùng y hệt dòng trước đó (cùng mã, ngày, hàng, SL, giá, tiền): {ids(ds)}"}
    if kq["trung_khac_noi_dung"]:
        ds = [y for _, y in kq["trung_khac_noi_dung"]]
        nhom["trung_ma_khac_noi_dung"] = {"dong": ds, "tien": -sum(x["tien"] for x in ds), "so_dong": -len(ds),
                                          "mo_ta": f"{len(ds)} dòng trùng MÃ nhưng khác nội dung: {ids(ds)}"}
    if kq["ngoai_thang_chac"]:
        ds = kq["ngoai_thang_chac"]
        nhom["ngoai_thang"] = {"dong": ds, "tien": -sum(x["tien"] for x in ds), "so_dong": -len(ds),
                               "mo_ta": f"{len(ds)} dòng ngày ngoài tháng 10/2026, không có cách đọc nào đưa về tháng 10: {ids(ds)}"}
    if kq["ngoai_thang_mo_ho"]:
        ds = kq["ngoai_thang_mo_ho"]
        nhom["ngay_mo_ho"] = {"dong": ds, "tien": -sum(x["tien"] for x in ds), "so_dong": -len(ds),
                              "mo_ta": f"{len(ds)} dòng có ngày ngoài tháng 10 nhưng nếu hoán đổi ngày↔tháng thì rơi vào tháng 10: {ids(ds)}"}
    if kq["am"]:
        ds = kq["am"]
        nhom["tra_hang"] = {"dong": ds, "tien": -sum(x["tien"] for x in ds), "so_dong": -len(ds),
                            "mo_ta": f"{len(ds)} dòng trả hàng (số âm): {ids(ds)}"}
    if kq["lech_sl_gia"]:
        ds = kq["lech_sl_gia"]
        nhom["sl_gia"] = {"dong": ds, "tien": sum(x["hieu"] for x in ds), "so_dong": 0,
                          "mo_ta": f"{len(ds)} dòng thành tiền ghi ≠ SL×giá: {ids(ds)}"}
    return nhom


def doi_soat(muc_tieu, nhom):
    """Trả về danh sách tổ hợp nhóm khớp chính xác (Σ tác động == mục tiêu)."""
    return tim_giai_thich(muc_tieu, {k: v["tien"] for k, v in nhom.items()})


def sha_thu_muc(*thu_muc):
    import hashlib
    out = {}
    for d in thu_muc:
        for p in sorted(Path(d).rglob("*")):
            if p.is_file():
                out[str(p.relative_to(BASE))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return out


def chay():
    hash_truoc = sha_thu_muc(GOC, BASE / "ra")
    ra = doc_ra()
    ket = {}
    for ten_file, (ma, ten) in FILES.items():
        res = doc_file(GOC / ten_file, ma)
        ng = gan_ngay(res)
        kq = phan_tich(res)
        tg = kiem_tong_ghi(res, kq)
        nhom = dung_nhom(res, kq)
        r = ra[ma]
        d = {"res": res, "ngay": ng, "kq": kq, "tg": tg, "ten": ten, "nhom": nhom, "ra": r}
        d["ghi"] = tg["gia_tri"]
        d["dong"] = kq["tong_dong"]
        d["ra_tien"] = r["doanh_thu"]
        # ba phép trừ, tất cả do code
        d["ra_tru_ghi"] = d["ra_tien"] - d["ghi"]
        d["ra_tru_dong"] = d["ra_tien"] - d["dong"]
        d["ghi_tru_dong"] = d["ghi"] - d["dong"]
        d["khop_ra_dong"] = doi_soat(d["ra_tru_dong"], nhom)  # ra/ đã xử lý nhóm nào?
        d["khop_ghi_dong"] = doi_soat(d["ghi_tru_dong"], nhom)  # tổng file ghi đã xử lý nhóm nào?
        # xác nhận chéo bằng SỐ DÒNG: số dòng ra/ phải bằng số dòng đọc được + Σ tác động số dòng
        d["kiem_so_dong"] = [r["so_dong"] == kq["n"] + sum(nhom[t]["so_dong"] for t in tohop) for tohop in d["khop_ra_dong"]]
        ket[ma] = d
    hash_sau = sha_thu_muc(GOC, BASE / "ra")
    return ket, ra, hash_truoc == hash_sau, len(hash_truoc)


# ----------------------------------------------------------------------------
# Viết báo cáo
# ----------------------------------------------------------------------------
THU_TU = ["HN", "HP", "DN", "CT", "BH", "NT"]  # cùng thứ tự với tong_hop_chi_nhanh.csv

NHAN_KIEU_NGAY = {"dd-mm-yy": "ngày/tháng/năm (dd/mm)", "mm-dd-yy": "tháng/ngày/năm (mm/dd)", "yyyy-mm-dd": "năm-tháng-ngày"}

NHAN_NHOM = {
    "trung": "dòng trùng y hệt",
    "trung_ma_khac_noi_dung": "dòng trùng mã khác nội dung",
    "ngoai_thang": "dòng ngoài tháng 10 chắc chắn (đơn tháng 9)",
    "ngay_mo_ho": "dòng ngày mơ hồ (10/09, có thể là 9/10)",
    "tra_hang": "dòng trả hàng",
    "sl_gia": "dòng thành tiền ≠ SL×giá",
}


def giai_thich_duy_nhat(ks, kiem=None):
    return len(ks) == 1 and (kiem is None or all(kiem))


def nguyen_nhan_ngan(d):
    """Ô 'nguyên nhân' của bảng chính, ghép từ kết quả đối soát (không gõ tay con số)."""
    nhom = d["nhom"]
    mo_ta = []
    if d["ra_tru_dong"] != 0:
        ks = d["khop_ra_dong"]
        if len(ks) == 1:
            tohop = ks[0]
            phan = [f"{len(nhom[t]['dong'])} {NHAN_NHOM[t]} = {fmt(abs(nhom[t]['tien']))}" for t in tohop]
            ok_dong = all(d["kiem_so_dong"])
            mo_ta.append(
                f"ra/ ít hơn tổng dòng {fmt(-d['ra_tru_dong'])}: khớp đến từng đồng với việc ra/ đã loại " + " + ".join(phan)
                + (f"; số dòng ra/ ({d['ra']['so_dong']}) cũng khớp" if ok_dong else "; NHƯNG số dòng ra/ không khớp")
            )
        elif len(ks) > 1:
            mo_ta.append(f"ra/ lệch {fmt_signed(d['ra_tru_dong'])} so với tổng dòng, có {len(ks)} cách giải thích khớp ({ks}), không chọn được")
        else:
            mo_ta.append(f"ra/ lệch {fmt_signed(d['ra_tru_dong'])} so với tổng dòng: CHƯA GIẢI THÍCH")
    if d["ghi_tru_dong"] != 0:
        ks = d["khop_ghi_dong"]
        if d["ra_tru_dong"] == 0:
            mo_ta.append("ra/ = tổng các dòng đọc được")
        if giai_thich_duy_nhat(ks) and ks[0]:
            mo_ta.append(f"tổng file ghi lệch {fmt_signed(d['ghi_tru_dong'])} so với tổng dòng: khớp với nhóm {ks[0]}")
        elif d["ghi_tru_dong"] > 0:
            mo_ta.append(f"tổng chi nhánh tự ghi cao hơn tổng các dòng {fmt(d['ghi_tru_dong'])} (file tự mâu thuẫn): CHƯA GIẢI THÍCH")
        else:
            mo_ta.append(f"tổng chi nhánh tự ghi thấp hơn tổng các dòng {fmt(-d['ghi_tru_dong'])}: CHƯA GIẢI THÍCH")
    if not mo_ta:
        mo_ta.append("Khớp cả ba số")
    return "; ".join(mo_ta)


def ghi_chu_khong_chac(d):
    """Điểm đáng lưu ý nằm NGOÀI chênh lệch giữa ba số, hoặc ra/ đã quyết định thay người đọc."""
    nhom, kq = d["nhom"], d["kq"]
    out = []
    da_loai = set(d["khop_ra_dong"][0]) if len(d["khop_ra_dong"]) == 1 else set()
    if "ngay_mo_ho" in nhom:
        ds = nhom["ngay_mo_ho"]["dong"]
        tong = sum(x["tien"] for x in ds)
        chi_tiet = "; ".join(
            f"{x['id']} (dòng Excel {x['r']}): ghi {x['ngay_goc'] if isinstance(x['ngay_goc'], str) else x['ngay'].strftime('%d/%m/%Y')}"
            f", nếu hoán đổi ngày↔tháng là {x['ngay_hoan_doi'].strftime('%d/%m/%Y')}"
            + (f", {'khớp' if x.get('khop_vi_tri') else 'KHÔNG khớp'} vị trí giữa hai dòng liền kề ({x['lang_gieng'][0]} .. {x['lang_gieng'][1]})" if "khop_vi_tri" in x else "")
            + f", {fmt(x['tien'])}đ"
            for x in ds
        )
        if "ngay_mo_ho" in da_loai:
            out.append(f"ra/ ĐÃ LOẠI {len(ds)} dòng ngày mơ hồ (tổng {fmt(tong)}). Nếu thực ra là tháng 10 thì ra/ thiếu đúng {fmt(tong)}. Chi tiết: {chi_tiet}.")
        else:
            out.append(f"ra/ và file ĐỀU TÍNH {len(ds)} dòng có ngày lạ (tổng {fmt(tong)}). Nếu thực sự không phải tháng 10 thì tổng tháng 10 bị thừa đúng {fmt(tong)}. Chi tiết: {chi_tiet}.")
    if "sl_gia" in nhom:
        ds = nhom["sl_gia"]["dong"]
        chi = "; ".join(f"{x['id']} (dòng {x['r']}): ghi {fmt(x['tien'])}, SL×giá = {fmt(x['sl'])}×{fmt(x['gia'])} = {fmt(x['tinh'])}, thừa {fmt(-x['hieu'])}" for x in ds)
        out.append(f"{len(ds)} dòng có thành tiền ≠ SL×giá; ra/ và file đều giữ số tiền ghi, tổng chênh {fmt(-nhom['sl_gia']['tien'])} (không biết số nào đúng: SL, giá hay tiền). {chi}.")
    if "tra_hang" in nhom and "tra_hang" not in da_loai:
        ds = nhom["tra_hang"]["dong"]
        out.append("ra/ và file đều đã trừ " + ", ".join(f"{x['id']} ({fmt(x['tien'])})" for x in ds) + " (dòng trả hàng, số âm), tức tính doanh thu thuần.")
    if kq["giong_noi_dung_khac_ma"]:
        gs = [" & ".join(x["id"] for x in g) + f" ({fmt(g[0]['tien'])}đ mỗi dòng)" for g in kq["giong_noi_dung_khac_ma"]]
        out.append(f"{len(gs)} cặp dòng GIỐNG nội dung nhưng KHÁC mã ({'; '.join(gs)}); không coi là trùng, ra/ và file đều giữ; không đủ căn cứ để kết luận trùng.")
    return out


def viet_md(ket, ra, hash_ok, so_file_hash):
    L = []
    L.append("# Kiểm chéo tổng doanh thu từng chi nhánh: ra/ so với file gốc (tháng 10/2026)")
    L.append("")
    L.append(f"Ngày chạy: {dt.date.today().isoformat()}. Script: `kiem_cheo.py` (đọc thẳng `goc/*.xlsx`; từ `ra/` chỉ đọc `tong_hop_chi_nhanh.csv`, không dùng `hop_nhat.csv`). "
             "Mọi con số trong file này do script tính bằng số nguyên (đồng).")
    L.append("")
    L.append("## Bảng đối chiếu")
    L.append("")
    L.append("- **Tổng file ghi**: con số tổng chi nhánh tự ghi ở cuối bảng. Với ô công thức, lấy giá trị Excel đã tính sẵn và script tự tính lại công thức để kiểm.")
    L.append("- **Tổng dòng đọc được**: cộng thành tiền của MỌI dòng dữ liệu đọc được (kể cả dòng trùng, ngoài tháng 10, trả hàng); không cộng dòng tổng hay dòng cộng tuần.")
    L.append("- **Tổng trong ra/**: cột `doanh_thu` trong `ra/tong_hop_chi_nhanh.csv`. Chênh lệch = ra/ trừ số so sánh (âm nghĩa là ra/ ít hơn). Số trong ngoặc là số dòng.")
    L.append("")
    L.append("| Chi nhánh | Tổng file ghi | Tổng dòng đọc được (số dòng) | Tổng trong ra/ (số dòng) | Chênh lệch ra/ − file ghi | Chênh lệch ra/ − dòng đọc được | Nguyên nhân |")
    L.append("|---|---:|---:|---:|---:|---:|---|")
    for ma in THU_TU:
        d = ket[ma]
        L.append(f"| {ma} ({d['ten']}) | {fmt(d['ghi'])} | {fmt(d['dong'])} ({d['kq']['n']}) | {fmt(d['ra_tien'])} ({d['ra']['so_dong']}) "
                 f"| {fmt_signed(d['ra_tru_ghi'])} | {fmt_signed(d['ra_tru_dong'])} | {nguyen_nhan_ngan(d)} |")
    tong = lambda k: sum(ket[m][k] for m in THU_TU)
    L.append(f"| **Cộng 6 chi nhánh** | {fmt(tong('ghi'))} | {fmt(tong('dong'))} | {fmt(tong('ra_tien'))} | {fmt_signed(tong('ra_tru_ghi'))} | {fmt_signed(tong('ra_tru_dong'))} | |")
    L.append("")

    # ---- kết luận 3 dòng ----
    khop3 = [m for m in THU_TU if ket[m]["ra_tru_ghi"] == 0 and ket[m]["ra_tru_dong"] == 0 and ket[m]["ghi_tru_dong"] == 0]
    lech_ra = [m for m in THU_TU if ket[m]["ra_tru_ghi"] != 0]
    giai_thich = [m for m in lech_ra if ket[m]["ra_tru_dong"] != 0 and giai_thich_duy_nhat(ket[m]["khop_ra_dong"], ket[m]["kiem_so_dong"])]
    chua = [m for m in THU_TU if ket[m]["ghi_tru_dong"] != 0 and not (giai_thich_duy_nhat(ket[m]["khop_ghi_dong"]) and ket[m]["khop_ghi_dong"][0])]
    mo_ho_loai = [m for m in THU_TU if "ngay_mo_ho" in ket[m]["nhom"] and len(ket[m]["khop_ra_dong"]) == 1 and "ngay_mo_ho" in ket[m]["khop_ra_dong"][0]]
    mo_ho_giu = [m for m in THU_TU if "ngay_mo_ho" in ket[m]["nhom"] and m not in mo_ho_loai]
    L.append("## Kết luận")
    L.append("")
    L.append(f"1. {len(khop3)}/6 chi nhánh khớp cả ba số (file ghi = dòng đọc được = ra/): {', '.join(khop3)}. {len(lech_ra)}/6 chi nhánh trong ra/ lệch so với số chi nhánh tự ghi: "
             + ", ".join(f"{m} ({fmt_signed(ket[m]['ra_tru_ghi'])})" for m in lech_ra) + ".")
    parts = []
    for m in giai_thich:
        parts.append(f"{m} giải thích được đến từng đồng và khớp số dòng (ra/ đã loại: " + ", ".join(NHAN_NHOM[t] for t in ket[m]["khop_ra_dong"][0]) + ")")
    for m in chua:
        parts.append(f"{m} CHƯA GIẢI THÍCH {fmt(abs(ket[m]['ghi_tru_dong']))}: tổng chi nhánh tự ghi ≠ cộng các dòng của chính file, ra/ khớp tổng dòng nên phần lệch nằm ở con số chi nhánh ghi, và không có dòng nào trong file gây ra")
    L.append("2. " + "; ".join(parts) + ".")
    kc = []
    for m in mo_ho_loai:
        x = ket[m]["nhom"]["ngay_mo_ho"]
        kc.append(f"{m}: ra/ loại {len(x['dong'])} dòng ngày mơ hồ ({fmt(-x['tien'])}) có thể là tháng 10 bị hoán đổi ngày↔tháng")
    for m in mo_ho_giu:
        x = ket[m]["nhom"]["ngay_mo_ho"]
        kc.append(f"{m}: ra/ tính {len(x['dong'])} dòng ngày lạ ({fmt(-x['tien'])}), có thể là tháng 10 bị hoán đổi ngày↔tháng nên nhiều khả năng đúng nhưng chưa chắc")
    for m in [m for m in THU_TU if "sl_gia" in ket[m]["nhom"]]:
        kc.append(f"{m}: {len(ket[m]['nhom']['sl_gia']['dong'])} dòng thành tiền ≠ SL×giá, chênh {fmt(-ket[m]['nhom']['sl_gia']['tien'])}, không biết số nào đúng")
    L.append("3. Điểm KHÔNG CHẮC, cần người giữ file gốc xác nhận: " + "; ".join(kc) + ".")
    L.append("")

    # ---- chi tiết ----
    L.append("## Chi tiết từng chi nhánh")
    L.append("")
    for ma in THU_TU:
        d = ket[ma]
        res, kq, tg, ng = d["res"], d["kq"], d["tg"], d["ngay"]
        L.append(f"### {ma} — {d['ten']} (`{res['file']}`)")
        L.append("")
        L.append(f"- Đọc được {kq['n']} dòng dữ liệu (dòng Excel {res['dong'][0]['r']} đến {res['dong'][-1]['r']}); số dòng không đọc được: {kq['tong_khong_doc']}. "
                 f"Tổng chi nhánh ghi: {fmt(d['ghi'])} (dòng Excel {tg['r']}, nhãn \"{tg['nhan']}\""
                 + (f"; {tg['ghi_chu'][0]}" if tg['ghi_chu'] else "; số gõ cứng, không phải công thức") + ").")
        if "cong_thuc_dung" in tg:
            L.append(f"- Script tự tính lại công thức đó: {fmt(tg['tinh_lai_cong_thuc'])}, {'khớp' if tg['cong_thuc_dung'] else 'KHÔNG khớp'} giá trị trong file.")
        if "tuan" in tg:
            L.append("- Dòng cộng tuần (không tính vào tổng dòng vì sẽ cộng đôi): " + "; ".join(
                f"dòng {t['r']}: ghi {fmt(t['ghi'])}, cộng {t['n']} dòng phía trên {fmt(t['tinh'])}, {'khớp' if t['ghi'] == t['tinh'] else 'LỆCH ' + fmt_signed(t['tinh'] - t['ghi'])}" for t in tg["tuan"])
                     + f". Tổng 5 tuần = {fmt(tg['tong_cong_tuan_ghi'])}.")
        if ng["kieu"]:
            L.append(f"- Ngày là chuỗi; kiểu đọc áp cho cả file: {NHAN_KIEU_NGAY[ng['kieu']]} ({ng['can_cu']}). {ng['mo_ho_rieng']} dòng nếu đọc riêng lẻ có thể hiểu thành 2 ngày khác nhau; "
                     "chốt theo quy ước chung của file" + (", ngày tăng dần theo thứ tự dòng." if ng["tang_dan"] else "; ngày không sắp tăng dần nên không có thêm thứ tự để đối chiếu."))
        elif any(x["ngay_tu_o_gop"] for x in res["dong"]):
            L.append(f"- Ngày nằm ở ô gộp cột A: {sum(1 for x in res['dong'] if x['ngay_tu_o_gop'])} dòng lấy ngày từ ô gộp; dòng thiếu ngày: {len(ng['thieu_ngay'])}; ngày tăng dần: {'có' if ng['tang_dan'] else 'không'}.")
        else:
            L.append(f"- Ngày là ngày thật của Excel; tăng dần theo thứ tự dòng: {'có' if ng['tang_dan'] else 'không'}"
                     + ("" if ng["tang_dan"] else f" (bỏ các dòng ngày lạ ở dưới thì tăng dần: {'có' if kq['tang_dan_tru_mo_ho'] else 'không'})") + ".")
        for t, v in d["nhom"].items():
            tong_n = sum(x["tien"] for x in v["dong"])
            dong_ct = "; ".join(f"{x['id']} (dòng Excel {x['r']}, {x['ngay'].strftime('%d/%m/%Y') if x.get('ngay') else '?'}, {fmt(x['tien'])})" for x in v["dong"])
            L.append(f"- Nhóm `{t}`: {v['mo_ta']}. Cộng thành tiền các dòng này: {fmt(tong_n)}. Chi tiết: {dong_ct}.")
        if not d["nhom"]:
            L.append("- Không tìm thấy dòng trùng mã, ngoài tháng, âm, hay thành tiền ≠ SL×giá.")
        if d["ra_tru_dong"] != 0:
            ks = d["khop_ra_dong"]
            L.append(f"- Đối soát ra/ − dòng đọc được = {fmt_signed(d['ra_tru_dong'])}: số tổ hợp nhóm có tổng tác động đúng bằng số này là {len(ks)} ({ks}); kiểm số dòng ra/ = {d['ra']['so_dong']}: {d['kiem_so_dong']}.")
        if d["ghi_tru_dong"] != 0:
            ok = giai_thich_duy_nhat(d["khop_ghi_dong"]) and d["khop_ghi_dong"][0]
            L.append(f"- Tổng chi nhánh ghi − dòng đọc được = {fmt_signed(d['ghi_tru_dong'])}: số tổ hợp nhóm trong file giải thích đúng số này là {len(d['khop_ghi_dong'])} ({d['khop_ghi_dong']}). "
                     + ("" if ok else "**CHƯA GIẢI THÍCH**: file không có dòng trùng, dòng ngoài tháng, dòng thành tiền ≠ SL×giá hay ngày lạ nào tạo ra đúng chênh lệch này; "
                        "mã chứng từ liền số, không thiếu mã. Có thể con số tổng bị gõ nhầm hoặc có một dòng đã bị sửa/xóa sau khi tính tổng, nhưng đó chỉ là phỏng đoán."))
        for g in ghi_chu_khong_chac(d):
            L.append(f"- Lưu ý: {g}")
        if res["khac"]:
            L.append("- Ghi chú trong file: " + " | ".join(t for _, t in res["khac"]))
        L.append("")

    # ---- HP: ghi chú trong file đối chiếu số đơn tháng 9 ----
    hp = ket["HP"]
    m = None
    for _, t in hp["res"]["khac"]:
        m = m or re.search(r"Gồm (\d+) đơn tháng 9", t)
    if m:
        so_ghi = int(m.group(1))
        chac = [x for x in hp["kq"]["ngoai_thang_chac"] if x["ngay"].month == 9]
        L.append("## Đối chiếu ghi chú cuối file HP")
        L.append("")
        L.append(f"Ghi chú nói có {so_ghi} đơn tháng 9 nhập trễ (26/09 đến 30/09). Script đếm được {len(chac)} dòng ngày tháng 9 không thể đọc khác đi: "
                 f"{'khớp ghi chú' if len(chac) == so_ghi else 'KHÔNG khớp ghi chú'}. "
                 f"Còn {len(hp['kq']['ngoai_thang_mo_ho'])} dòng ngày 10/09/2026 mà ghi chú KHÔNG nhắc tới: đọc theo dd/mm là 10/9 (ngoài tháng), hoán đổi là 9/10 (trong tháng). "
                 "Việc ghi chú chỉ nói 4 đơn nghiêng về cách hiểu 9/10, nhưng đó là suy luận chứ không phải bằng chứng.")
        L.append("")

    L.append("## Phương pháp và giới hạn")
    L.append("")
    L.append("- Sáu file có bố cục khác nhau (ngày là ô gộp, chuỗi `MM/DD/YYYY`, chuỗi `DD/MM/YYYY`, chuỗi `DD-MM-YY`, ngày thật; tiền là số hoặc chuỗi `165.000đ` / `1,800,000`; có hoặc không có dòng cộng tuần). Script chuẩn hóa về số nguyên đồng và ngày; giá trị lạ không đoán mà báo ra.")
    L.append("- Ngày dạng chuỗi: script thử các cách đọc, loại cách nào tạo ngày không tồn tại ở bất kỳ dòng nào trong file, rồi áp cách còn lại cho cả file. Đây là suy luận từ dữ liệu vì file không ghi rõ định dạng.")
    L.append("- Tìm nguyên nhân: script gom dòng bất thường thành nhóm (trùng y hệt, ngoài tháng chắc chắn, ngày mơ hồ, trả hàng, thành tiền ≠ SL×giá), rồi thử mọi tổ hợp nhóm xem tổng tác động có bằng đúng số chênh không. "
             "Khớp đến từng đồng và khớp số dòng là bằng chứng mạnh rằng script kia đã làm như vậy, nhưng vẫn là suy luận về việc script kia làm gì: tôi không đọc code hay `bao_cao.md` của nó.")
    L.append("- Chỉ kiểm tổng từng chi nhánh theo yêu cầu. Không kiểm doanh thu theo sản phẩm, không kiểm chuẩn hóa tên sản phẩm, không đối chiếu từng dòng với `ra/hop_nhat.csv` (lúc bắt đầu tôi có liếc 5 dòng đầu của file này để biết tên cột, không lấy số nào từ đó).")
    L.append(f"- Không sửa gì trong `goc/` và `ra/`: băm SHA-256 của {so_file_hash} file trong hai thư mục, trước và sau khi chạy: {'giống hệt' if hash_ok else 'KHÁC NHAU, cần xem lại'}.")
    L.append("")
    return "\n".join(L)


def main():
    ket, ra, hash_ok, n_hash = chay()
    md = viet_md(ket, ra, hash_ok, n_hash)
    OUT_MD.write_text(md, encoding="utf-8")
    print(md)
    print(f"\n[đã ghi {OUT_MD.name}; goc/ và ra/ không đổi: {hash_ok}]")


if __name__ == "__main__":
    main()
