"""In kết quả chấm NGẮN (bọc cham.py và chay_lai.py, không đổi cách chấm).

Dùng:
  python -X utf8 tom_tat_cham.py bai2 <thư_mục_agent_đã_làm>            bài 2: chấm tháng 10
  python -X utf8 tom_tat_cham.py bai3 <gop.py> <T10|T11|T11dd>           bài 3: chạy lại gop.py cho tháng khác (không gọi agent)
  python -X utf8 tom_tat_cham.py <bt1|bt2> <gop.py> [thư_mục_làm_việc]   bài 4: bài tập 1, 2
Ví dụ:
  python -X utf8 ket-qua\\tom_tat_cham.py bai2 ket-qua\\claude-bai1-2
  python -X utf8 ket-qua\\tom_tat_cham.py bai3 ket-qua\\agy-bai1-2\\gop.py T11
  python -X utf8 ket-qua\\tom_tat_cham.py bt1 lan-chay-1\\gop.py

T11 = tháng 11 cùng định dạng; T11dd = tháng 11, chi nhánh NT đổi định dạng.
Chạy gop.py: chép dữ liệu + gop.py vào một thư mục tạm, chạy `python gop.py goc ra --thang AAAA-MM`, chấm bằng đáp án.
Thoát mã 0 nếu ĐẠT, mã 1 nếu KHÔNG ĐẠT (bai2 chỉ in, luôn mã 0).
"""
import csv
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
BAI = AQUI.parent
# tên -> (thư mục dữ liệu, đáp án, tháng chạy, đáp án của tháng khác để dò số chứng từ còn sót)
CAU_HINH = {
    "bt1": ("du-lieu/bai-tap/bt1-chi-nhanh-thu-7", "dap-an-bt1.json", "2026-11", None),
    "bt2": ("du-lieu/bai-tap/bt2-doi-ten-cot", "dap-an-T11.json", "2026-11", None),
    "T10": ("du-lieu/thang-10", "dap-an-T10.json", "2026-10", "dap-an-T11.json"),
    "T11": ("du-lieu/thang-11", "dap-an-T11.json", "2026-11", "dap-an-T10.json"),
    "T11dd": ("du-lieu/thang-11-doi-dinh-dang", "dap-an-T11-doi-dinh-dang.json", "2026-11", "dap-an-T10.json"),
}


def doc_tong(path):
    if not path.exists():
        return {}
    with open(path, encoding="utf-8-sig", newline="") as f:
        out = {}
        for r in csv.DictReader(f):
            try:
                out[r["chi_nhanh"].strip().upper()] = int(float(r["doanh_thu"]))
            except (KeyError, ValueError):
                pass
        return out


def tom_tat_bai2(thu_muc):
    sys.path.insert(0, str(AQUI))
    from cham import cham
    thu_muc = Path(thu_muc)
    if not (thu_muc / "ra" / "hop_nhat.csv").exists():
        print(f"Không thấy ra/hop_nhat.csv trong '{thu_muc}'. Kiểm tra đường dẫn: thư mục phải chứa thư mục ra/ do agent tạo.")
        sys.exit(1)
    C = cham(thu_muc, AQUI / "dap-an-T10.json", BAI / "du-lieu/thang-10/goc")
    print(f"Chấm {thu_muc.name} với dap-an-T10.json")
    if (thu_muc / "goc").is_dir():
        print("File gốc nguyên vẹn:", "có" if C["file_goc"]["nguyen_ven"] else "KHÔNG")
    else:
        print("File gốc: thư mục này không có goc/ nên chưa so mã băm (so mã băm bằng lệnh ở Bước 2, bài 2)")
    print(f"Dòng đúng cả 5 trường: {C['dong_dung_het_cac_truong']}/{C['dong_dung_ky_vong']}; bỏ sót: {len(C['bo_sot'])}; "
          f"dòng thừa: {len(C['dong_thua_khong_co_trong_dap_an'])}; còn trùng khóa: {C['dong_trung_khoa_con_lai']}")
    print(f"Tổng từng chi nhánh đúng: {C['tong_chi_nhanh_dung']}/6 (tổng {C['tong_cong_agent']:,.0f} đ, đáp án {C['tong_cong_dap_an']:,.0f} đ)")
    print(f"Tổng từng sản phẩm đúng: {C['tong_san_pham_dung']}/{C['tong_san_pham_ky_vong']}")
    print(f"Ô chi nhánh x sản phẩm đúng: {C['o_chi_nhanh_san_pham_dung']}/{C['o_chi_nhanh_san_pham_ky_vong']}")
    mo = [x["ket_qua"] for x in C["dong_ngay_mo_ho"]]
    print(f"Dòng ngày mơ hồ để CAN_NGUOI_QUYET và có trong việc cần hỏi: {sum(1 for x in mo if x == 'DUNG_CAN_NGUOI_QUYET')}/{len(mo)}")
    cb = C["viec_can_hoi_bao_dung"]
    cb_dung = sum(1 for k, v in cb.items() if v >= (1 if k in ("CT_thieu_tuan", "HN_sai_tong") else int(k.rsplit("_", 1)[1])))
    print(f"Việc cần hỏi nêu đủ: {cb_dung}/{len(cb)} loại")
    kt = C["kiem_tra"]
    print(f"kiem_tra.csv: {sum(1 for v in kt.values() if v['tong_file_ghi_dung'] and v['tong_dong_doc_duoc_dung'] and v['chenh_lech_dung'])}/{len(kt)} chi nhánh đúng cả ba số")


def chay_va_cham(gop, ten, work=None):
    data, truth_f, thang, khac = CAU_HINH[ten]
    data, truth = BAI / data, AQUI / truth_f
    # Nếu cạnh gop.py có file danh mục (ví dụ bạn đã thêm chi nhánh mới vào danh_muc_chi_nhanh.csv), dùng chúng thay bản gốc.
    tam = Path(tempfile.mkdtemp(prefix="du_lieu_")) / data.name
    shutil.copytree(data, tam)
    for ten_dm in ("danh_muc_chi_nhanh.csv", "danh_muc_san_pham.csv"):
        if (Path(gop).resolve().parent / ten_dm).is_file():
            shutil.copy(Path(gop).resolve().parent / ten_dm, tam / ten_dm)
    data = tam
    work = Path(work) if work else Path(tempfile.mkdtemp(prefix=f"cham_{ten}_"))
    out_json = Path(tempfile.mkdtemp()) / "kq.json"
    lenh = [sys.executable, "-X", "utf8", str(AQUI / "chay_lai.py"), str(Path(gop).resolve()), str(data), str(truth), str(work), thang, "--out", str(out_json)]
    if khac:
        lenh += ["--so-voi-thang-khac", str(AQUI / khac)]
    subprocess.run(lenh, capture_output=True, text=True, encoding="utf-8", errors="replace")
    R = json.loads(out_json.read_text(encoding="utf-8"))
    ok = True
    print(f"Chạy `{R['lenh']}`: mã thoát {R['returncode']}")
    if R["returncode"] != 0:
        dong = [x for x in (R["stderr_tail"] or R["stdout_tail"]).strip().splitlines() if x.strip()]
        print("  Script dừng, thông báo cuối:", dong[-1] if dong else "(không có)")
        print("KHÔNG ĐẠT")
        sys.exit(1)
    C = R["cham"]
    T = json.loads(truth.read_text(encoding="utf-8"))
    dung, ky_vong = C["dong_dung_het_cac_truong"], C["dong_dung_ky_vong"]
    print(f"Dòng đúng cả 5 trường: {dung}/{ky_vong}; bỏ sót: {len(C['bo_sot'])}; dòng thừa: {len(C['dong_thua_khong_co_trong_dap_an'])}; còn trùng khóa: {C['dong_trung_khoa_con_lai']}")
    ok &= dung == ky_vong and not C["bo_sot"] and not C["dong_thua_khong_co_trong_dap_an"] and C["dong_trung_khoa_con_lai"] == 0
    got = doc_tong(work / "ra" / "tong_hop_chi_nhanh.csv")
    want = T["tong_chi_nhanh_xac_nhan"]
    sai_cn = [c for c, v in want.items() if got.get(c) != v]
    print(f"Tổng từng chi nhánh đúng: {len(want) - len(sai_cn)}/{len(want)}" + (f" (sai hoặc thiếu: {', '.join(sai_cn)})" if sai_cn else ""))
    ok &= not sai_cn
    print("File gốc nguyên vẹn:", "có" if C["file_goc"]["nguyen_ven"] else "KHÔNG")
    ok &= C["file_goc"]["nguyen_ven"]
    mo = [x["ket_qua"] for x in C.get("dong_ngay_mo_ho", [])]
    if mo:
        print(f"(Thông tin) Dòng ngày mơ hồ để CAN_NGUOI_QUYET và có trong việc cần hỏi: {sum(1 for x in mo if x == 'DUNG_CAN_NGUOI_QUYET')}/{len(mo)}")
    if "so_chung_tu_thang_khac_con_sot" in R:
        s = R["so_chung_tu_thang_khac_con_sot"]
        print("Mã chứng từ của THÁNG KHÁC còn trong chữ giải thích: " + ", ".join(f"{k} {len(v)} mã" for k, v in s.items()))
        ok &= not any(s.values())
    print("ĐẠT" if ok else "KHÔNG ĐẠT")
    sys.exit(0 if ok else 1)


def main():
    a = sys.argv[1:]
    if len(a) == 2 and a[0] == "bai2":
        return tom_tat_bai2(a[1])
    if len(a) == 3 and a[0] == "bai3" and a[2] in ("T10", "T11", "T11dd"):
        return chay_va_cham(a[1], a[2])
    if len(a) >= 2 and a[0] in ("bt1", "bt2"):
        return chay_va_cham(a[1], a[0], a[2] if len(a) > 2 else None)
    raise SystemExit(__doc__)


if __name__ == "__main__":
    main()
