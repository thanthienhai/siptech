# BÁO CÁO KIỂM TRA NỘI DUNG ĐĂNG BÁN SHOP "VƯỜN NHỎ"

> **Báo cáo nội bộ dành cho Quản lý sàn và Đội ngũ Vận hành Shop Vườn Nhỏ**  
> **Bộ dữ liệu:** 40 sản phẩm mỹ phẩm (`VN-001` đến `VN-040`)  
> **File xuất bản bàn giao:** `nhap_hang_loat.csv` (UTF-8 có BOM), `nhap_hang_loat.xlsx`, script tự kiểm `kiem.py`

---

## 1. TỔNG QUAN TÌNH TRẠNG SẢN PHẨM

Toàn bộ 40 sản phẩm trong file `thong_so.csv` đã được rà soát, đối chiếu thông số và biên soạn nội dung hoàn chỉnh theo đúng quy định tại `quy_dinh_shop.md` và danh mục `tu_cam.txt`.

| Chỉ số | Số lượng | Tỷ lệ | Diễn giải |
|---|---|---|---|
| **Tổng số sản phẩm xử lý** | **40** | **100%** | Toàn bộ danh mục sản phẩm của shop |
| **Sẵn sàng đăng bán (`SAN_SANG`)** | **31** | **77.5%** | Đầy đủ 6 trường thông tin bắt buộc, đạt chuẩn xuất sàn ngay |
| **Cần bổ sung thông tin (`CAN_BO_SUNG`)** | **9** | **22.5%** | Thiếu từ 1 đến 6 trường bắt buộc, đã gắn cờ và đánh dấu vị trí |

---

## 2. DANH SÁCH CHI TIẾT CÁC SẢN PHẨM CẦN BỔ SUNG THÔNG TIN

Theo Mục 5 của `quy_dinh_shop.md`, 6 trường bắt buộc để viết đầy đủ mô tả bao gồm: `dung_tich`, `thanh_phan_noi_bat`, `xuat_xu`, `han_su_dung`, `cong_dung_tren_bao_bi`, `cach_dung`. 

Các ô có giá trị trống, `"?"`, `"chưa rõ"`, `"liên hệ NCC"`, `"N/A"`, `"chưa có"` đều được xác định là **THIẾU THÔNG TIN**. Dưới đây là danh sách chi tiết 9 SKU chưa đủ dữ liệu:

| STT | SKU | Tên sản phẩm | Trạng thái | Trường cần bổ sung | Chi tiết giá trị gốc trong bảng thông số |
|:---:|:---:|---|:---:|---|---|
| 1 | **VN-007** | Nước cân bằng da Mầm Xanh | `CAN_BO_SUNG` | `dung_tich; thanh_phan_noi_bat; xuat_xu; han_su_dung; cong_dung_tren_bao_bi; cach_dung` | Bị trống toàn bộ thông số kỹ thuật (cả `loai_da_phu_hop` và `mui_huong` cũng trống) |
| 2 | **VN-009** | Tinh chất dưỡng da Suối Mát | `CAN_BO_SUNG` | `xuat_xu` | Cột `xuat_xu` để trống |
| 3 | **VN-014** | Kem dưỡng ẩm Suối Mát | `CAN_BO_SUNG` | `xuat_xu; han_su_dung` | `xuat_xu = N/A`, `han_su_dung = ?` |
| 4 | **VN-019** | Kem chống nắng Mầm Xanh | `CAN_BO_SUNG` | `thanh_phan_noi_bat; cong_dung_tren_bao_bi` | `thanh_phan_noi_bat = liên hệ NCC`, `cong_dung_tren_bao_bi = ?` |
| 5 | **VN-025** | Son dưỡng môi Suối Mát | `CAN_BO_SUNG` | `thanh_phan_noi_bat` | `thanh_phan_noi_bat = chưa rõ` |
| 6 | **VN-027** | Dầu gội Đồi Chè | `CAN_BO_SUNG` | `cach_dung` | `cach_dung = chưa có` |
| 7 | **VN-029** | Dầu gội Mầm Xanh | `CAN_BO_SUNG` | `dung_tich` | Cột `dung_tich` để trống |
| 8 | **VN-034** | Kem dưỡng da tay Đồi Chè | `CAN_BO_SUNG` | `dung_tich; han_su_dung` | `dung_tich = ?`, `han_su_dung = N/A` |
| 9 | **VN-038** | Nước tẩy trang Đồi Chè | `CAN_BO_SUNG` | `dung_tich` | Cột `dung_tich` để trống |

> [!IMPORTANT]
> **Xử lý kỹ thuật trên file đăng bán:**
> - Tại cột `trang_thai`: Ghi rõ `CAN_BO_SUNG`.
> - Tại cột `truong_can_bo_sung`: Liệt kê chính xác tên các cột thiếu, phân tách bằng dấu chấm phẩy `; `.
> - Trong phần `mo_ta` và các gạch đầu dòng tương ứng: Đã chèn đúng thẻ cú pháp `CẦN BỔ SUNG: <tên cột>`, tuyệt đối không tự ý suy đoán hay bịa thông số.

---

## 3. CÁC ĐIỂM NGHI NGỜ VÀ VẤN ĐỀ CẦN QUẢN LÝ / NGƯỜI CÓ THẨM QUYỀN QUYẾT ĐỊNH

Trong quá trình đối soát dữ liệu gốc, phát hiện 15 trường hợp có `ghi_chu_noi_bo` chứa lời đồn, thông tin chưa được kiểm chứng, đề xuất vi phạm từ cấm, hoặc mâu thuẫn kỹ thuật với bảng thông số chính thức. Nhân viên nội dung đã tuân thủ triệt để nguyên tắc sự thật (loại bỏ hoàn toàn các lời đồn này khỏi nội dung đăng bán) và tổng hợp tại đây để xin ý kiến quyết định:

### 3.1. Nhóm mâu thuẫn kỹ thuật & chất lượng sản phẩm

1. **VN-012 (Tinh chất dưỡng da Sương Mai): Mâu thuẫn nồng độ hoạt chất Vitamin C**
   - *Thông số chính thức:* `thanh_phan_noi_bat` ghi `"vitamin C 10%, glycerin"`. Đã có số phiếu công bố `DEMO-2644`.
   - *Ghi chú nội bộ:* `"kỹ thuật nói thực ra nồng độ 15%, chờ phiếu kiểm nghiệm"`.
   - *Hành động đã làm:* Giữ nguyên con số 10% theo phiếu công bố và bảng thông số chính thức.
   - *Cần người quyết:* Kiểm tra lại với bộ phận R&D / NCC xem lô hàng thực tế xuất bán là 10% hay 15%. Nếu là 15%, phải cập nhật lại hồ sơ công bố trước khi sửa thông số niêm yết.

2. **VN-010 (Tinh chất dưỡng da Mầm Xanh): Nghi ngờ cồn trong thành phần**
   - *Ghi chú nội bộ:* `"chưa chắc cồn hay không, hỏi lại NCC"`.
   - *Hành động đã làm:* Chỉ nêu các thành phần có trong bảng (`niacinamide 5%, glycerin`), không khẳng định "không cồn" hay "có cồn".
   - *Cần người quyết:* Đề nghị NCC cung cấp bảng thành phần đầy đủ (Full INCI list) để trả lời khi khách hàng hỏi.

3. **VN-011 (Tinh chất dưỡng da Nắng Sớm): Nghi ngờ hạn mở nắp (PAO)**
   - *Ghi chú nội bộ:* `"bản cũ ghi 15 tháng bảo quản sau khi mở, chưa chắc"`.
   - *Hành động đã làm:* Chỉ ghi hạn dùng tổng thể `"30 tháng kể từ ngày sản xuất"`.
   - *Cần người quyết:* Xác nhận lại ký hiệu PAO (Period After Opening) trên bao bì thực tế (thường là 6M, 12M) để bổ sung hướng dẫn bảo quản.

4. **VN-014 (Kem dưỡng ẩm Suối Mát): Khẳng định không paraben bằng miệng**
   - *Ghi chú nội bộ:* `"NCC nói miệng là không paraben, chưa có giấy"`.
   - *Hành động đã làm:* Không đưa thông tin "không paraben" vào bài đăng vì thiếu chứng từ.
   - *Cần người quyết:* Yêu cầu NCC gửi giấy kiểm nghiệm (COA) chứng minh không chứa paraben nếu muốn truyền thông điểm này.

5. **VN-039 (Nước tẩy trang Suối Mát): Lời đồn đạt chuẩn FDA Mỹ**
   - *Ghi chú nội bộ:* `"nghe NCC nói đạt chuẩn FDA Mỹ, chưa có giấy"`.
   - *Hành động đã làm:* Bỏ qua hoàn toàn, không nhắc đến FDA.
   - *Cần người quyết:* Thu hồi chứng nhận FDA từ NCC (nếu có thật) để làm căn cứ truyền thông hợp pháp.

### 3.2. Nhóm sai lệch xuất xứ & đối tượng sử dụng

6. **VN-018 (Kem chống nắng Suối Mát): Xuất xứ Việt Nam nhưng gợi ý ghi hàng nhập khẩu**
   - *Thông số chính thức:* `xuat_xu = Việt Nam`.
   - *Ghi chú nội bộ:* `"có thể nói là hàng nhập khẩu chính ngạch"`.
   - *Hành động đã làm:* Khẳng định xuất xứ Việt Nam đúng theo bảng thông số.
   - *Cần người quyết:* Chấn chỉnh thông tin nội bộ; tuyệt đối không quảng cáo sai xuất xứ hàng hóa (vi phạm pháp luật bảo vệ người tiêu dùng).

7. **VN-003 (Sữa rửa mặt gel Mầm Xanh): Đề xuất tự ý ghi phù hợp da nhạy cảm**
   - *Thông số chính thức:* `loai_da_phu_hop = mọi loại da`.
   - *Ghi chú nội bộ:* `"chưa test da nhạy cảm nhưng cứ ghi phù hợp da nhạy cảm"`.
   - *Hành động đã làm:* Chỉ ghi "phù hợp cho mọi loại da", không khẳng định chuyên biệt cho da nhạy cảm.
   - *Cần người quyết:* Thực hiện kiểm nghiệm kích ứng da nếu muốn truyền thông nhãn "dành riêng cho da nhạy cảm".

8. **VN-020 (Kem chống nắng Nắng Sớm): Chưa kiểm tra an toàn cho mẹ bầu và trẻ nhỏ**
   - *Ghi chú nội bộ:* `"dùng được cho bà bầu và em bé (chưa kiểm tra)"`.
   - *Hành động đã làm:* Không đưa thông tin mẹ bầu / em bé vào nội dung.
   - *Cần người quyết:* Cần có ý kiến của chuyên gia da liễu / chứng nhận an toàn lâm sàng trước khi hướng tới đối tượng nhạy cảm này.

### 3.3. Nhóm vi phạm quy định sàn & từ cấm quảng cáo

9. **VN-009:** Đề xuất ghi `"bán chạy số 1 khu vực"` -> Vi phạm từ cấm (`bán chạy`, `số 1`). Đã loại bỏ.
10. **VN-019:** Đề xuất ghi `"trắng da sau 7 ngày"` -> Vi phạm từ cấm (`trắng da sau`), cam kết thời gian vô căn cứ. Đã loại bỏ.
11. **VN-022:** Kinh doanh muốn ghi `"tốt nhất thị trường"` -> Vi phạm từ cấm (`tốt nhất`), so sánh tuyệt đối. Đã loại bỏ.
12. **VN-024:** Đề xuất ghi `"chữa khỏi viêm da nếu dùng đều"` -> Vi phạm nghiêm trọng từ cấm (`chữa khỏi`), biến mỹ phẩm thành thuốc chữa bệnh. Đã loại bỏ.
13. **VN-028:** Đề xuất ghi phản hồi khách `"dùng 2 tuần hết mụn hẳn"` -> Vi phạm từ cấm (`hết mụn`), đưa con số chưa kiểm chứng. Đã loại bỏ.
14. **VN-030:** Đề xuất ghi `"rẻ hơn đối thủ 30%"` -> Vi phạm từ cấm (`đối thủ`), so sánh cạnh tranh không lành mạnh. Đã loại bỏ.
15. **VN-033:** Khách VIP nói `"dùng 1 chai là hết nám"` -> Vi phạm từ cấm (`hết nám`), quảng cáo sai công dụng mỹ phẩm. Đã loại bỏ.

### 3.4. Vấn đề Phiếu công bố sản phẩm

- **Có số phiếu công bố hợp lệ (10 SKU):** `VN-004`, `VN-008`, `VN-012`, `VN-020`, `VN-021`, `VN-023`, `VN-024`, `VN-025`, `VN-026`, `VN-035`. Các sản phẩm này đã được ghi rõ số phiếu công bố trong phần mô tả.
- **Trạng thái "đang chờ duyệt" (4 SKU):** `VN-001`, `VN-027`, `VN-028`, `VN-034`. Nội dung tuân thủ không tự nhận là "đã công bố". *Cần người quyết:* Bộ phận pháp chế cập nhật ngay số phiếu chính thức khi cơ quan y tế phê duyệt.
- **Chưa có thông tin phiếu công bố (26 SKU):** Cần rà soát lộ trình nộp hồ sơ công bố mỹ phẩm cho toàn bộ các SKU còn lại.

---

## 4. KẾT QUẢ THỰC THI SCRIPT TỰ KIỂM `kiem.py`

Script kiểm tra độc lập `kiem.py` đã được thiết kế và thực thi trực tiếp trên hai file kết quả `nhap_hang_loat.csv` và `nhap_hang_loat.xlsx`. Toàn bộ các tiêu chí kiểm tra đều đạt chuẩn tuyệt đối.

### Chi tiết các hạng mục kiểm tra tự động:

```text
======================================================================
KHỞI CHẠY KIỂM TRA CHẤT LƯỢNG NỘI DUNG SHOP VƯỜN NHỎ
======================================================================
Cột chuẩn (11 cột): sku, tieu_de, mo_ta, gach_1, gach_2, gach_3, gach_4, gach_5, tu_khoa, trang_thai, truong_can_bo_sung
Tổng số từ cấm nạp vào: 28 cụm từ
Tổng số SKU trong bảng thông số: 40
[PASS] nhap_hang_loat.csv có UTF-8 BOM hợp lệ.
[PASS] Tính đồng bộ CSV và XLSX đạt chuẩn 100%.
----------------------------------------------------------------------
KẾT QUẢ TỔNG HỢP KIỂM TRA:
- Tổng số SKU kiểm tra: 40/40
- Số sản phẩm SẴN SÀNG (SAN_SANG): 31
- Số sản phẩm CẦN BỔ SUNG (CAN_BO_SUNG): 9
- Tổng số lỗi phát hiện: 0
- Tổng số cảnh báo: 0
----------------------------------------------------------------------
[THÀNH CÔNG] DỮ LIỆU HOÀN TOÀN SẠCH VÀ TUÂN THỦ 100% QUY ĐỊNH SHOP VƯỜN NHỎ!
```

### Đánh giá thông số kỹ thuật nội dung:
1. **Độ dài Tiêu đề (`tieu_de`):** Nằm hoàn toàn trong khoảng `47` đến `81` ký tự (giới hạn cho phép: 25 - 100 ký tự). Tất cả tiêu đề đều bắt đầu bằng cụm `"Vườn Nhỏ"`, kế tiếp là tên sản phẩm, dung tích (nếu có) và công dụng/chỉ số theo bảng.
2. **Độ dài Mô tả (`mo_ta`):** Nằm trong khoảng `508` đến `675` ký tự (giới hạn cho phép: 200 - 1500 ký tự). Cấu trúc đồng nhất, xưng "Vườn Nhỏ", gọi "bạn", không có emoji, không dấu chấm than thừa (0 dấu chấm than).
3. **Độ dài 5 Gạch đầu dòng (`gach_1` đến `gach_5`):** 
   - `gach_1`: 25 - 70 ký tự (<= 120)
   - `gach_2`: 40 - 61 ký tự (<= 120)
   - `gach_3`: 32 - 56 ký tự (<= 120)
   - `gach_4`: 57 - 70 ký tự (<= 120)
   - `gach_5`: 42 - 101 ký tự (<= 120)
   Tất cả 40 sản phẩm đều đủ 5 gạch đầu dòng, không bị trống.
4. **Từ khóa (`tu_khoa`):** Mỗi sản phẩm có từ 6 đến 10 cụm từ khóa có nghĩa, ngăn cách bằng `; `, mỗi cụm đều <= 30 ký tự. Không chứa từ cấm.
5. **Kiểm tra từ cấm:** Quét tự động cả bản có dấu và không dấu của 28 từ cấm. Kết quả: **0 vi phạm**.
6. **Kiểm tra tính xác thực con số:** Mọi con số (dung tích, phần trăm nồng độ, chỉ số chống nắng, số phiếu công bố, thời hạn sử dụng, khoảng cách xịt, thời gian đắp mặt nạ) xuất hiện trong nội dung đều được đối soát 1:1 với dòng dữ liệu tương ứng trong `thong_so.csv`. Không có bất kỳ con số lạ nào bị tự ý thêm vào.
7. **Định dạng file:** 
   - `nhap_hang_loat.csv` được mã hóa chuẩn `UTF-8 có BOM` (byte đầu tiên: `\xef\xbb\xbf`), tương thích tốt khi mở trực tiếp bằng Microsoft Excel trên Windows.
   - `nhap_hang_loat.xlsx` được xuất chuẩn với đúng định dạng bảng tính Excel.

---

## 5. KẾT LUẬN & KIẾN NGHỊ BƯỚC TIẾP THEO

1. **Về phía nội dung:** Dữ liệu đã hoàn tất 100%, sẵn sàng nhập hàng loạt lên sàn thương mại điện tử đối với 31 sản phẩm `SAN_SANG`.
2. **Về phía vận hành & thu mua:**
   - Ưu tiên liên hệ NCC bổ sung ngay dung tích và thành phần cho các sản phẩm bán chạy thuộc nhóm `CAN_BO_SUNG` (như VN-019, VN-029, VN-038).
   - Kiểm tra lại toàn diện SKU `VN-007` do hiện tại đang trống toàn bộ dữ liệu thuộc tính.
   - Thống nhất các điểm nghi ngờ nêu tại Mục 3 với bộ phận R&D và Pháp chế trước khi mở bán chính thức.
