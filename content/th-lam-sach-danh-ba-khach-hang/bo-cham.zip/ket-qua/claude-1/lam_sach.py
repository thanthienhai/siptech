# -*- coding: utf-8 -*-
"""
lam_sach.py - Làm sạch danh bạ khách hàng bằng quy tắc cố định.

- Không gọi mô hình, không gọi mạng; chạy lại cho đúng kết quả cũ.
- Chỉ đọc danh-ba-goc.xlsx (không sửa), ghi các file kết quả vào cùng thư mục với script.
- Chạy:  python -X utf8 lam_sach.py

Ra:  danh-ba-sach.xlsx, nhat-ky-gop.csv, nhat-ky-sua.csv, nghi-trung-can-quyet.csv
(bao-cao.md do người viết dựa trên số liệu in ra ở cuối).
"""
import csv
import json
import re
import sys
import unicodedata
from collections import Counter, OrderedDict, defaultdict, deque
from pathlib import Path

import openpyxl
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

THU_MUC = Path(__file__).resolve().parent
FILE_GOC = THU_MUC / "danh-ba-goc.xlsx"

# ----------------------------------------------------------------------------
# Tiện ích chuỗi
# ----------------------------------------------------------------------------


def nfc(s):
    return unicodedata.normalize("NFC", s)


def bo_dau(s):
    """Bỏ dấu tiếng Việt (đ -> d), giữ nguyên hoa/thường."""
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s.replace("đ", "d").replace("Đ", "D")


def gap_trang(s):
    return re.sub(r"\s+", " ", s).strip()


def viet_hoa_dau_tu(s):
    """Viết Hoa Chữ Đầu Mỗi Từ. Token có chữ số (12a, 58/4/4) thì viết hoa hết."""
    out = []
    for tok in s.split(" "):
        if not tok:
            continue
        if re.search(r"\d", tok):
            out.append(tok.upper())
        else:
            t = tok.lower()
            out.append(t[0].upper() + t[1:])
    return " ".join(out)


def so_dau(s):
    """Số ký tự có dấu (khác ASCII sau khi tách) - dùng để chọn giá trị 'đầy đủ dấu' nhất."""
    return sum(1 for c in s if c.isalpha() and bo_dau(c) != c)


def chuoi_o(v):
    """Giá trị ô -> chuỗi (None -> '')."""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return nfc(str(v))


# ----------------------------------------------------------------------------
# SĐT
# ----------------------------------------------------------------------------

RE_SDT_HOP_LE_DI_DONG = re.compile(r"^0[35789]\d{8}$")
RE_SDT_HOP_LE_BAN = re.compile(r"^02\d{9}$")
RE_CHI_GOM_KY_TU_SDT = re.compile(r"^[\d\s+().\-]+$")
RE_DAY_SO_TRONG_CHU = re.compile(r"\+?\(?\+?\d[\d\s().\-]{7,}\d")


def sdt_hop_le(d):
    return bool(RE_SDT_HOP_LE_DI_DONG.match(d) or RE_SDT_HOP_LE_BAN.match(d))


def chuan_hoa_sdt(raw):
    """Trả về (gia_tri_sach_hoac_rong, hop_le, [ma_quy_tac])."""
    quy_tac = []
    s = raw.strip()
    if "*" in s:
        return "", False, ["SDT-KHONG-HOP-LE"]  # bị che
    co_cong = s.startswith("+") or s.startswith("(+")
    d = re.sub(r"\D", "", s)
    if re.sub(r"\s", "", s) != d:
        quy_tac.append("SDT-BO-KY-TU")
    if d.startswith("0084"):
        d = "0" + d[4:]
        quy_tac.append("SDT-DOI-DAU-84")
    elif co_cong and d.startswith("84"):
        d = "0" + d[2:]
        quy_tac.append("SDT-DOI-DAU-84")
    elif len(d) == 9 and not d.startswith("0"):
        d = "0" + d
        quy_tac.append("SDT-THEM-SO-0")
    elif d.startswith("84") and len(d) in (11, 12):
        d = "0" + d[2:]
        quy_tac.append("SDT-DOI-DAU-84")
    if sdt_hop_le(d):
        return d, True, quy_tac
    return "", False, ["SDT-KHONG-HOP-LE"]


# ----------------------------------------------------------------------------
# Email
# ----------------------------------------------------------------------------

DUOI_EMAIL_HOP_LE = {"com", "net", "org", "vn", "edu", "gov", "info", "biz", "io", "co"}
RE_EMAIL = re.compile(
    r"^[a-z0-9](?:[a-z0-9._%+\-]*[a-z0-9])?@[a-z0-9\-]+(?:\.[a-z0-9\-]+)*\.([a-z]{2,})$"
)


def chuan_hoa_email(raw):
    """Trả về (gia_tri_sach_hoac_rong, hop_le)."""
    s = raw.strip().lower()
    if s.count("@") == 1:
        local, dom = s.split("@")
        s = local + "@" + dom.replace(",", ".")
    m = RE_EMAIL.match(s)
    if m and ".." not in s and m.group(1) in DUOI_EMAIL_HOP_LE:
        return s, True
    return "", False


# ----------------------------------------------------------------------------
# Họ tên
# ----------------------------------------------------------------------------

DANH_XUNG = {"anh", "chi", "co", "chu", "bac", "a", "c"}  # so khớp sau khi bỏ dấu, hạ chữ thường


def tach_danh_xung(ten):
    """Trả về (ten_con_lai, danh_xung_goc_viet_thuong)."""
    tu = ten.split(" ")
    if len(tu) >= 2 and bo_dau(tu[0]).lower() in DANH_XUNG:
        return " ".join(tu[1:]), tu[0].lower()
    return ten, ""


def giong_chu_dia_chi(s):
    """Chuỗi trông như địa chỉ (có chữ số hoặc dấu phẩy)."""
    return bool(re.search(r"[\d,]", s))


def tokens_ten(ten):
    return [t.rstrip(".").lower() for t in ten.split(" ") if t]


def tu_bang_nhau(x, y):
    """Hai từ bằng nhau: giống hệt, hoặc khác nhau chỉ vì một bên KHÔNG có dấu nào.
    Hai từ cùng có dấu mà khác nhau (Hùng/Hưng) là hai từ khác nhau."""
    if x == y:
        return True
    if bo_dau(x) != bo_dau(y):
        return False
    return x == bo_dau(x) or y == bo_dau(y)


def chu_dem_viet_tat(x, y):
    """Một bên là chữ cái đầu (K), bên kia là từ đầy đủ bắt đầu bằng chữ đó."""
    if len(x) == 1 and len(y) > 1:
        return bo_dau(y)[0] == bo_dau(x)
    if len(y) == 1 and len(x) > 1:
        return bo_dau(x)[0] == bo_dau(y)
    return False


def ten_giong_nhau(a, b):
    """'Tên giống nhau' (dùng cho Q2): cùng số từ, từng từ bằng nhau (không mở chữ đệm viết tắt)."""
    ta, tb = tokens_ten(a), tokens_ten(b)
    return len(ta) == len(tb) and all(tu_bang_nhau(x, y) for x, y in zip(ta, tb))


def ten_tuong_thich(a, b):
    """'Tên tương thích' (dùng cho G1/G2). a, b: tên đã bỏ danh xưng."""
    ta, tb = tokens_ten(a), tokens_ten(b)
    if not ta or not tb:
        return False
    if len(ta) == 1 or len(tb) == 1:
        # một từ chỉ tương thích với chính nó (hai bên cùng một từ, giống hệt)
        return len(ta) == len(tb) and tu_bang_nhau(ta[0], tb[0])
    if len(ta) != len(tb):
        return False
    n = len(ta)
    for i, (x, y) in enumerate(zip(ta, tb)):
        if tu_bang_nhau(x, y):
            continue
        if 0 < i < n - 1 and chu_dem_viet_tat(x, y):
            continue
        return False
    return True


def ten_co_viet_tat(ten):
    t = tokens_ten(ten)
    return any(len(x) == 1 for x in t[1:-1]) if len(t) > 2 else False


def khoa_ten(ten):
    return " ".join(bo_dau(x) for x in tokens_ten(ten))


# ----------------------------------------------------------------------------
# Địa chỉ
# ----------------------------------------------------------------------------

THANH_PHO = {"ho chi minh", "ha noi", "da nang", "can tho", "hai phong"}
VIET_TAT_TP = {"hcm": "Hồ Chí Minh", "hn": "Hà Nội", "đn": "Đà Nẵng", "ct": "Cần Thơ", "hp": "Hải Phòng"}


def chuan_hoa_dia_chi(raw):
    s = gap_trang(nfc(raw))
    if not s:
        return ""
    # bỏ chữ "Số" ở đầu, bỏ "đường"/"đ." sau số nhà
    s = re.sub(r"(?i)^(?:số|so)\s+(?=\d)", "", s)
    s = re.sub(r"(?i)^(\d[\w/]*)\s*(?:đường|duong|đ\.)\s*", r"\1 ", s)
    s = s.replace(",", "|")
    # thành phố
    s = re.sub(r"(?i)(?<![\w])TPHCM(?![\w])", "Thành phố Hồ Chí Minh", s)
    s = re.sub(r"(?i)(?<![\w])(?:TP\.?|Thành phố|Thanh pho)\s*(?=\S)", "Thành phố ", s)

    def mo_viet_tat(m):
        co_tp, vt = m.group(1), m.group(2).lower()
        ten = VIET_TAT_TP[vt]
        if vt == "hcm" and not co_tp:
            return "Thành phố " + ten
        return (co_tp + " " if co_tp else "") + ten

    s = re.sub(r"(?i)(?:(Thành phố)\s+)?(?<![\w])(HCM|HN|ĐN|CT|HP)\s*$", mo_viet_tat, s)
    # phường / quận: P., F., p12, f8, Phường ; Q., q11, Quận
    s = re.sub(r"(?i)(?<![\w])(?:Phường\s*|[PF]\.\s*|[PF](?=\d))", "|Phường ", s)
    s = re.sub(r"(?i)(?<![\w])(?:Quận\s*|Q\.\s*|Q(?=\d))", "|Quận ", s)
    s = re.sub(r"(?<![\w])Thành phố\b", "|Thành phố", s)
    phan = [gap_trang(p) for p in s.split("|")]
    phan = [p for p in phan if p]
    # thành phố viết đầy đủ nhưng dính liền sau tên quận (không có dấu phẩy)
    if len(phan) >= 2:
        toks = phan[-1].split(" ")
        for k in (3, 2):  # "Hồ Chí Minh" 3 từ; "Hà Nội", "Đà Nẵng", "Cần Thơ", "Hải Phòng" 2 từ
            if len(toks) > k and bo_dau(" ".join(toks[-k:])).lower() in THANH_PHO and phan[-1].startswith(
                ("Phường", "Quận")
            ):
                phan[-1:] = [" ".join(toks[:-k]), " ".join(toks[-k:])]
                break
    return ", ".join(viet_hoa_dau_tu(p) for p in phan)


def khoa_dia_chi(dc):
    s = bo_dau(dc).lower()
    s = re.sub(r"\bthanh pho\b", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return gap_trang(s)


# ----------------------------------------------------------------------------
# Đọc dữ liệu gốc
# ----------------------------------------------------------------------------

COT_GOC = ["Mã dòng", "Nguồn", "Họ tên", "SĐT", "Email", "Địa chỉ", "Ghi chú"]


def doc_goc():
    wb = openpyxl.load_workbook(FILE_GOC, read_only=True)
    ws = wb["DanhBa"]
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    assert list(rows[0]) == COT_GOC, rows[0]
    return [dict(zip(COT_GOC, r)) for r in rows[1:]]


# ----------------------------------------------------------------------------
# Làm sạch từng dòng
# ----------------------------------------------------------------------------


NGUON_SDT = {"Email": "SDT-TU-COT-EMAIL", "Ghi chú": "SDT-TU-GHI-CHU"}
NGUON_EMAIL = {"SĐT": "EMAIL-TU-COT-SDT", "Ghi chú": "EMAIL-TU-GHI-CHU"}
QT_MAC_DINH = {
    "Họ tên": "TEN-CHUAN-HOA",
    "SĐT": "SDT-CHUAN-HOA",
    "sdt_khac": "SDT-CHUAN-HOA",
    "Email": "EMAIL-CHUAN-HOA",
    "Địa chỉ": "DIA-CHI-CHUAN-HOA",
    "Ghi chú": "GHI-CHU-CHUAN-HOA",
}


def lam_sach_dong(r, nhat_ky_sua, thong_ke):
    ma = r["Mã dòng"]
    goc = {c: chuoi_o(r[c]) for c in COT_GOC}
    goc_nguyen = {c: ("" if r[c] is None else str(r[c])) for c in COT_GOC}  # đúng từng byte, để hoàn tác
    quy_tac = defaultdict(list)  # cột -> các mã quy tắc

    def them(cot, *ma_qt):
        for m in ma_qt:
            if m not in quy_tac[cot]:
                quy_tac[cot].append(m)

    ten, dia_chi = goc["Họ tên"], goc["Địa chỉ"]
    # --- tên và địa chỉ bị đổi chỗ
    if ten and giong_chu_dia_chi(ten) and dia_chi and not giong_chu_dia_chi(dia_chi):
        ten, dia_chi = dia_chi, ten
        them("Họ tên", "DOI-CHO-TEN-DIA-CHI")
        them("Địa chỉ", "DOI-CHO-TEN-DIA-CHI")
        thong_ke["doi_cho_ten_dia_chi"] += 1

    # --- tên
    ten_goc_sau_doi = gap_trang(ten)
    ten_con, danh_xung = tach_danh_xung(ten_goc_sau_doi)
    ten_sach = viet_hoa_dau_tu(ten_con)
    if danh_xung:
        them("Họ tên", "TEN-BO-DANH-XUNG")
    if ten_sach != goc["Họ tên"]:
        them("Họ tên", "TEN-CHUAN-HOA")

    # --- địa chỉ
    dia_chi_sach = chuan_hoa_dia_chi(dia_chi)
    if dia_chi_sach != goc["Địa chỉ"] and "DOI-CHO-TEN-DIA-CHI" not in quy_tac["Địa chỉ"]:
        them("Địa chỉ", "DIA-CHI-CHUAN-HOA")
    elif dia_chi_sach != dia_chi:
        them("Địa chỉ", "DIA-CHI-CHUAN-HOA")

    # --- gom các mảnh SĐT / email từ ba cột SĐT, Email, Ghi chú
    manh_sdt = []  # (chuỗi_thô, cột_nguồn)
    manh_email = []
    ghi_chu_con_lai = []
    ghi_chu = goc["Ghi chú"]

    def phan_loai_o(txt, cot):
        txt = txt.strip()
        if not txt:
            return
        if "@" in txt or (cot == "Email" and not RE_CHI_GOM_KY_TU_SDT.match(txt)):
            manh_email.append((txt, cot))
            return
        if RE_CHI_GOM_KY_TU_SDT.match(txt) or cot == "SĐT":
            for p in re.split(r"[;/,]", txt):
                if p.strip():
                    manh_sdt.append((p.strip(), cot))
            return
        ghi_chu_con_lai.append(txt)

    phan_loai_o(goc["SĐT"], "SĐT")
    phan_loai_o(goc["Email"], "Email")
    if ghi_chu:
        m = RE_DAY_SO_TRONG_CHU.search(ghi_chu)
        if m and len(re.sub(r"\D", "", m.group())) >= 9:
            trai = re.sub(r"(?i)(liên hệ|liên lạc|sđt|sdt)\s*:?\s*$", "", ghi_chu[: m.start()])
            phai = ghi_chu[m.end():]
            con_lai = gap_trang((trai + " " + phai).strip(" ;,:"))
            manh_sdt.append((m.group().strip(), "Ghi chú"))
            if con_lai:
                ghi_chu_con_lai.append(con_lai)
        else:
            ghi_chu_con_lai.append(ghi_chu)
        em = re.findall(r"\S+@\S+", " ".join(ghi_chu_con_lai))
        if em:  # email nhập vào ô ghi chú
            for e in em:
                manh_email.append((e, "Ghi chú"))
            ghi_chu_con_lai = [gap_trang(re.sub(r"\S+@\S+", "", c)) for c in ghi_chu_con_lai]
            ghi_chu_con_lai = [c for c in ghi_chu_con_lai if c]

    # --- SĐT
    sdt_hl, sdt_loi = [], []
    for raw, cot in manh_sdt:
        gt, ok, qt = chuan_hoa_sdt(raw)
        if cot != "SĐT":
            them("SĐT", NGUON_SDT[cot])
            them(cot, NGUON_SDT[cot])
        if ok:
            if gt not in sdt_hl:
                sdt_hl.append(gt)
            for q in qt:
                them("SĐT", q)
        else:
            sdt_loi.append(raw)
            them("SĐT", "SDT-KHONG-HOP-LE")
    if len(manh_sdt) >= 2:
        them("SĐT", "SDT-TACH-HAI-SO")
        them("sdt_khac", "SDT-TACH-HAI-SO")
    if sdt_loi:
        thong_ke["sdt_khong_hop_le"].append((ma, sdt_loi))

    # --- email
    email_hl, email_loi = [], []
    for raw, cot in manh_email:
        gt, ok = chuan_hoa_email(raw)
        if cot != "Email":
            them("Email", NGUON_EMAIL[cot])
            them(cot, NGUON_EMAIL[cot])
        if ok:
            if gt not in email_hl:
                email_hl.append(gt)
            if cot == "Email" and gt != goc["Email"]:
                them("Email", "EMAIL-CHUAN-HOA")
        else:
            email_loi.append(raw)
            them("Email", "EMAIL-KHONG-HOP-LE")
    if email_loi:
        thong_ke["email_khong_hop_le"].append((ma, email_loi))

    # --- ghi chú sạch của dòng
    ghi_chu_dong = [gap_trang(c) for c in ghi_chu_con_lai if gap_trang(c)]
    ghi_chu_sach = "; ".join(ghi_chu_dong + (["Danh xưng: " + danh_xung] if danh_xung else []))
    if danh_xung:
        them("Ghi chú", "TEN-BO-DANH-XUNG")
    if ghi_chu_sach != goc["Ghi chú"] and not quy_tac["Ghi chú"]:
        them("Ghi chú", "GHI-CHU-CHUAN-HOA")

    moi = {
        "Họ tên": ten_sach,
        "SĐT": sdt_hl[0] if sdt_hl else "",
        "sdt_khac": ";".join(sdt_hl[1:]),
        "Email": email_hl[0] if email_hl else "",
        "Địa chỉ": dia_chi_sach,
        "Ghi chú": ghi_chu_sach,
    }
    # --- nhật ký sửa: mọi ô thay đổi
    for cot in ["Họ tên", "SĐT", "sdt_khac", "Email", "Địa chỉ", "Ghi chú"]:
        cu = goc_nguyen.get(cot, "")
        if cu != moi[cot]:
            qt = "+".join(quy_tac[cot]) if quy_tac[cot] else QT_MAC_DINH[cot]
            nhat_ky_sua.append([ma, cot, cu, moi[cot], qt])
    return {
        "ma": ma,
        "nguon": goc["Nguồn"],
        "ten": ten_sach,
        "danh_xung": danh_xung,
        "sdt": sdt_hl,
        "email": email_hl,
        "dia_chi": dia_chi_sach,
        "ghi_chu": ghi_chu_dong,
        "cot_goc": goc,
    }


# ----------------------------------------------------------------------------
# Gộp
# ----------------------------------------------------------------------------


def gop(dong):
    n = len(dong)
    chi_so = {d["ma"]: i for i, d in enumerate(dong)}
    cha = list(range(n))

    def tim(x):
        while cha[x] != x:
            cha[x] = cha[cha[x]]
            x = cha[x]
        return x

    def hop(a, b):
        ra, rb = tim(a), tim(b)
        if ra != rb:
            cha[max(ra, rb)] = min(ra, rb)

    theo_sdt, theo_email = defaultdict(list), defaultdict(list)
    for i, d in enumerate(dong):
        for p in d["sdt"]:
            theo_sdt[p].append(i)
        for e in d["email"]:
            theo_email[e].append(i)

    canh = defaultdict(lambda: {"G1": set(), "G2": set()})  # (i,j) i<j
    for p, ds in theo_sdt.items():
        for a in range(len(ds)):
            for b in range(a + 1, len(ds)):
                i, j = ds[a], ds[b]
                if ten_tuong_thich(dong[i]["ten"], dong[j]["ten"]):
                    canh[(i, j)]["G1"].add(p)
                    hop(i, j)
    for e, ds in theo_email.items():
        for a in range(len(ds)):
            for b in range(a + 1, len(ds)):
                i, j = ds[a], ds[b]
                if ten_tuong_thich(dong[i]["ten"], dong[j]["ten"]):
                    canh[(i, j)]["G2"].add(e)
                    hop(i, j)

    cum = defaultdict(list)
    for i in range(n):
        cum[tim(i)].append(i)
    cum = [sorted(v) for v in cum.values()]
    cum.sort(key=lambda v: v[0])

    ke = defaultdict(list)
    for (i, j) in canh:
        ke[i].append(j)
        ke[j].append(i)
    return cum, canh, ke, tim, theo_sdt, theo_email


def cau_bang_chung_canh(dong, i, j, canh):
    c = canh[(min(i, j), max(i, j))]
    phan = []
    if c["G1"]:
        phan.append("SĐT " + ", ".join(sorted(c["G1"])))
    if c["G2"]:
        phan.append("email " + ", ".join(sorted(c["G2"])))
    return "khớp %s giữa %s và %s (tên '%s' ~ '%s')" % (
        " và ".join(phan),
        dong[i]["ma"],
        dong[j]["ma"],
        dong[i]["ten"],
        dong[j]["ten"],
    )


# ----------------------------------------------------------------------------
# Chính
# ----------------------------------------------------------------------------


def chon_nhieu_nhat(gia_tri_theo_dong):
    """gia_tri_theo_dong: list các list giá trị (mỗi dòng gốc một list). Trả về list sắp theo
    (số dòng chứa giá trị, giảm dần; xuất hiện sớm hơn trước)."""
    dem, lan_dau = Counter(), {}
    k = 0
    for ds in gia_tri_theo_dong:
        for v in ds:
            if v not in lan_dau:
                lan_dau[v] = k
                k += 1
            dem[v] += 1
    return sorted(dem, key=lambda v: (-dem[v], lan_dau[v]))


def main():
    goc = doc_goc()
    thong_ke = defaultdict(int)
    thong_ke["sdt_khong_hop_le"] = []
    thong_ke["email_khong_hop_le"] = []
    nhat_ky_sua = []
    dong = [lam_sach_dong(r, nhat_ky_sua, thong_ke) for r in goc]
    n = len(dong)
    cum, canh, ke, tim, theo_sdt, theo_email = gop(dong)

    # ---- mã khách, đại diện
    ma_khach_cua = {}
    for k, v in enumerate(cum, 1):
        for i in v:
            ma_khach_cua[i] = "KH%03d" % k

    # ---- nghi trùng (Q1, Q2) - tính trước để ghi vào bằng chứng
    nghi = []  # (quy_tac, [chỉ số dòng], lý do, gợi ý)
    cum_cua = {}
    for k, v in enumerate(cum):
        for i in v:
            cum_cua[i] = k

    # Q1: SĐT hợp lệ nằm ở >= 2 khách khác nhau
    for p in sorted(theo_sdt, key=lambda p: min(theo_sdt[p])):
        ds = theo_sdt[p]
        if len({cum_cua[i] for i in ds}) >= 2:
            ten_ds = sorted({dong[i]["ten"] for i in ds})
            ly_do = "SĐT %s trùng ở %d dòng nhưng tên không tương thích: %s" % (
                p,
                len(ds),
                " / ".join("'%s'" % t for t in ten_ds),
            )
            nghi.append(("Q1", sorted(ds), ly_do, goi_y_q1(dong, sorted(ds), cum_cua)))

    # Q2: cùng tên + cùng địa chỉ nhưng thuộc >= 2 khách khác nhau
    theo_ten_dc = defaultdict(list)
    for i, d in enumerate(dong):
        if d["dia_chi"]:
            theo_ten_dc[(khoa_ten(d["ten"]), khoa_dia_chi(d["dia_chi"]))].append(i)
    # gom theo "giống nhau" thật sự: khoa_ten đã bỏ dấu nên Hùng/Hưng cùng khóa; tách lại bằng ten_giong_nhau
    for (kt, kd), ds in sorted(theo_ten_dc.items(), key=lambda kv: min(kv[1])):
        if len(ds) < 2:
            continue
        nhom_nho = []  # tách ds thành các lớp 'tên giống nhau'
        for i in ds:
            for lop in nhom_nho:
                if ten_giong_nhau(dong[lop[0]]["ten"], dong[i]["ten"]):
                    lop.append(i)
                    break
            else:
                nhom_nho.append([i])
        for lop in nhom_nho:
            if len({cum_cua[i] for i in lop}) >= 2:
                ly_do = "Tên giống nhau ('%s') và địa chỉ giống nhau ('%s') nhưng SĐT/email khác nhau hoặc thiếu: %s" % (
                    dong[lop[0]]["ten"],
                    dong[lop[0]]["dia_chi"],
                    "; ".join(
                        "%s [SĐT: %s | email: %s]"
                        % (dong[i]["ma"], ",".join(dong[i]["sdt"]) or "-", ",".join(dong[i]["email"]) or "-")
                        for i in sorted(lop)
                    ),
                )
                nghi.append(("Q2", sorted(lop), ly_do, goi_y_q2(dong, sorted(lop))))
    # đánh số nhóm: Q1 trước rồi Q2, mỗi loại theo Mã dòng đầu
    nghi.sort(key=lambda x: (x[0], x[1][0]))
    nhom_cua_dong = defaultdict(list)
    for k, (qt, ds, _, _) in enumerate(nghi, 1):
        for i in ds:
            nhom_cua_dong[i].append("%d (%s)" % (k, qt))

    # ---- nhật ký gộp
    nhat_ky_gop = []
    khach = []  # mỗi cụm một dòng khách
    canh_bao = []
    for k, v in enumerate(cum, 1):
        ma_kh = "KH%03d" % k
        dai_dien = v[0]
        # BFS từ đại diện để biết đường đi của từng dòng
        cha_bfs, hang = {dai_dien: None}, deque([dai_dien])
        while hang:
            x = hang.popleft()
            for y in sorted(ke[x]):
                if y not in cha_bfs:
                    cha_bfs[y] = x
                    hang.append(y)
        for i in v:
            if i == dai_dien:
                if len(v) == 1:
                    bc = "Không có dòng nào khác khớp theo G1 (SĐT) hoặc G2 (email) với tên tương thích."
                else:
                    bc = "Giữ làm dòng đại diện của %s, nhận thêm %d dòng: %s." % (
                        ma_kh,
                        len(v) - 1,
                        ", ".join(dong[j]["ma"] for j in v[1:]),
                    )
                if nhom_cua_dong.get(i):
                    bc += " Có trong nhóm nghi trùng cần người quyết: " + ", ".join(nhom_cua_dong[i]) + "."
                nhat_ky_gop.append([dong[i]["ma"], ma_kh, "GIU_RIENG", "không", bc])
                continue
            duong = []
            x = i
            while x is not None:
                duong.append(x)
                x = cha_bfs[x]
            duong.reverse()  # từ đại diện đến i
            buoc = [cau_bang_chung_canh(dong, duong[t], duong[t + 1], canh) for t in range(len(duong) - 1)]
            if len(duong) == 2:
                c = canh[(min(duong[0], i), max(duong[0], i))]
                qt = "G1" if c["G1"] else "G2"
                bc = "Gộp vào %s: %s." % (dong[dai_dien]["ma"], buoc[0])
            else:
                qt = "bắc cầu"
                bc = "Gộp vào %s qua %d bước: %s." % (dong[dai_dien]["ma"], len(buoc), "; ".join(buoc))
            if nhom_cua_dong.get(i):
                bc += " Có trong nhóm nghi trùng: " + ", ".join(nhom_cua_dong[i]) + "."
            nhat_ky_gop.append([dong[i]["ma"], ma_kh, "GOP_VAO", qt, bc])

        # ---- giá trị gộp
        mem = [dong[i] for i in v]
        # tên: có dấu đầy đủ, không viết tắt
        tot = max(
            range(len(mem)),
            key=lambda t: (not ten_co_viet_tat(mem[t]["ten"]), so_dau(mem[t]["ten"]), len(mem[t]["ten"].split()), -t),
        )
        ho_ten = mem[tot]["ten"]
        ten_khac = []
        for m in mem:
            if m["ten"] != ho_ten and khoa_ten(m["ten"]) != khoa_ten(ho_ten) and m["ten"] not in ten_khac:
                ten_khac.append(m["ten"])
        # cảnh báo: cụm chứa hai tên không tương thích với nhau (do bắc cầu)
        for a in range(len(mem)):
            for b in range(a + 1, len(mem)):
                if not ten_tuong_thich(mem[a]["ten"], mem[b]["ten"]):
                    canh_bao.append(
                        "%s: %s '%s' và %s '%s' bị gộp bắc cầu dù tên không tương thích trực tiếp"
                        % (ma_kh, mem[a]["ma"], mem[a]["ten"], mem[b]["ma"], mem[b]["ten"])
                    )
        sdts = chon_nhieu_nhat([m["sdt"] for m in mem])
        emails = chon_nhieu_nhat([m["email"] for m in mem])
        # địa chỉ: có dấu nhiều nhất, đủ cấp nhất, dài nhất
        dcs = [m["dia_chi"] for m in mem if m["dia_chi"]]
        dia_chi, dc_khac = "", []
        if dcs:
            dia_chi = max(
                dcs,
                key=lambda s: (so_dau(s), s.count(","), len(s)),
            )
            for s in dcs:
                if khoa_dia_chi(s) != khoa_dia_chi(dia_chi) and s not in dc_khac:
                    dc_khac.append(s)
        ghi_chu = []
        for m in mem:
            for g in m["ghi_chu"]:
                if g not in ghi_chu:
                    ghi_chu.append(g)
        dx = []
        for m in mem:
            if m["danh_xung"] and m["danh_xung"] not in dx:
                dx.append(m["danh_xung"])
        if dx:
            ghi_chu.append("Danh xưng: " + ", ".join(dx))
        if ten_khac:
            ghi_chu.append("Tên khác: " + " | ".join(ten_khac))
        if dc_khac:
            ghi_chu.append("Địa chỉ khác: " + " | ".join(dc_khac))
        nguon = []
        for m in mem:
            if m["nguon"] not in nguon:
                nguon.append(m["nguon"])
        khach.append(
            OrderedDict(
                ma_khach=ma_kh,
                ho_ten=ho_ten,
                sdt=sdts[0] if sdts else "",
                sdt_khac=";".join(sdts[1:]),
                email=emails[0] if emails else "",
                email_khac=";".join(emails[1:]),
                dia_chi=dia_chi,
                nguon=";".join(nguon),
                ma_dong_goc=";".join(m["ma"] for m in mem),
                ghi_chu="; ".join(ghi_chu),
            )
        )

    # ---- ghi file
    ghi_csv(THU_MUC / "nhat-ky-gop.csv", ["ma_dong_goc", "ma_khach", "hanh_dong", "quy_tac", "bang_chung"], nhat_ky_gop)
    ghi_csv(THU_MUC / "nhat-ky-sua.csv", ["ma_dong_goc", "cot", "gia_tri_cu", "gia_tri_moi", "quy_tac"], nhat_ky_sua)
    ghi_csv(
        THU_MUC / "nghi-trung-can-quyet.csv",
        ["nhom", "ma_dong_goc", "quy_tac", "ly_do", "goi_y"],
        [[k, ";".join(dong[i]["ma"] for i in ds), qt, ly, gy] for k, (qt, ds, ly, gy) in enumerate(nghi, 1)],
    )
    ghi_xlsx(THU_MUC / "danh-ba-sach.xlsx", khach)

    kiem_tra(goc, khach, nhat_ky_gop)
    in_thong_ke(goc, dong, khach, cum, nghi, nhat_ky_sua, thong_ke, canh_bao)


# ----------------------------------------------------------------------------
# Gợi ý (chỉ để ghi vào nghi-trung-can-quyet.csv; KHÔNG dùng để gộp)
# ----------------------------------------------------------------------------


def goi_y_q1(dong, ds, cum_cua):
    ten = [tokens_ten(dong[i]["ten"]) for i in ds]
    mot_tu = [t for t in ten if len(t) == 1]
    day_du = [t for t in ten if len(t) > 1]
    if mot_tu and day_du:
        if any(tu_bang_nhau(m[0], d[-1]) for m in mot_tu for d in day_du):
            return "Nghiêng về GỘP: tên một từ trùng tên riêng của dòng đầy đủ và cùng SĐT; cần người xác nhận."
        return "Không chắc: một bên chỉ có tên một từ không khớp tên riêng bên kia; nghiêng về KHÔNG gộp."
    # cả hai đầy đủ: so sánh tên riêng (từ cuối) và họ (từ đầu)
    cuoi = {bo_dau(t[-1]) for t in ten}
    dau = {bo_dau(t[0]) for t in ten}
    if len(cuoi) == 1 and len(dau) == 1:
        return "Nghiêng về GỘP có điều kiện: cùng họ, cùng tên riêng, chỉ khác chữ đệm/chữ có dấu; cần người xác nhận."
    return "Nghiêng về KHÔNG gộp: cùng SĐT nhưng tên khác hẳn (có thể người nhà dùng chung số)."


def goi_y_q2(dong, ds):
    co_thieu = any((not dong[i]["sdt"] and not dong[i]["email"]) for i in ds)
    sdt_khac_nhau = len({tuple(dong[i]["sdt"]) for i in ds if dong[i]["sdt"]}) >= 2
    if co_thieu and not sdt_khac_nhau:
        return "Nghiêng về GỘP: cùng tên, cùng địa chỉ, một bên thiếu SĐT/email nên không mâu thuẫn."
    if sdt_khac_nhau:
        return "Không chắc: cùng tên và địa chỉ nhưng SĐT khác nhau (có thể đổi số hoặc hai người trùng tên cùng nhà); nghiêng về KHÔNG gộp nếu chưa xác nhận."
    return "Nghiêng về GỘP: cùng tên, cùng địa chỉ; cần người xác nhận."


# ----------------------------------------------------------------------------
# Ghi file & kiểm tra
# ----------------------------------------------------------------------------


def ghi_csv(path, tieu_de, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(tieu_de)
        w.writerows(rows)


def ghi_xlsx(path, khach):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "KhachHang"
    cot = list(khach[0].keys())
    ws.append(cot)
    for k in khach:
        ws.append([k[c] for c in cot])
    for c in ws[1]:
        c.font = Font(bold=True)
    ws.freeze_panes = "A2"
    rong = {"ma_khach": 9, "ho_ten": 26, "sdt": 14, "sdt_khac": 22, "email": 30, "email_khac": 30, "dia_chi": 58,
            "nguon": 24, "ma_dong_goc": 22, "ghi_chu": 50}
    for j, c in enumerate(cot, 1):
        ws.column_dimensions[get_column_letter(j)].width = rong[c]
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.number_format = "@"  # giữ số 0 đầu của SĐT
    wb.save(path)


def kiem_tra(goc, khach, nhat_ky_gop):
    """Tự kiểm theo bước 3 của đề bài. Lỗi -> dừng."""
    ma_goc = [r["Mã dòng"] for r in goc]
    assert len(set(ma_goc)) == len(ma_goc), "Mã dòng gốc bị trùng"
    ma_log = [x[0] for x in nhat_ky_gop]
    assert sorted(ma_log) == sorted(ma_goc), "Mỗi Mã dòng gốc phải xuất hiện đúng 1 lần trong nhat-ky-gop.csv"
    n_gop = sum(1 for x in nhat_ky_gop if x[2] == "GOP_VAO")
    n_giu = sum(1 for x in nhat_ky_gop if x[2] == "GIU_RIENG")
    assert n_giu == len(khach) and len(khach) + n_gop == len(goc), "Số dòng sạch + số dòng bị gộp != số dòng gốc"
    # phân hoạch: ma_dong_goc của các khách phủ đúng tập gốc, không lặp
    tat_ca = [m for k in khach for m in k["ma_dong_goc"].split(";")]
    assert sorted(tat_ca) == sorted(ma_goc), "ma_dong_goc trong danh bạ sạch không khớp bản gốc"
    for k in khach:
        for p in [k["sdt"]] + [x for x in k["sdt_khac"].split(";") if x]:
            if p:
                assert sdt_hop_le(p), "SĐT sạch sai định dạng: %s %s" % (k["ma_khach"], p)
        for e in [k["email"]] + [x for x in k["email_khac"].split(";") if x]:
            if e:
                assert RE_EMAIL.match(e), "email sạch sai cú pháp: %s %s" % (k["ma_khach"], e)
    # khớp giữa nhật ký gộp và danh bạ sạch
    theo_kh = defaultdict(list)
    for ma, kh, *_ in nhat_ky_gop:
        theo_kh[kh].append(ma)
    for k in khach:
        assert sorted(theo_kh[k["ma_khach"]]) == sorted(k["ma_dong_goc"].split(";"))


def in_thong_ke(goc, dong, khach, cum, nghi, nhat_ky_sua, thong_ke, canh_bao):
    def rong(vals):
        return sum(1 for v in vals if not v)

    ket = OrderedDict()
    ket["so_dong_goc"] = len(goc)
    ket["so_khach_sau"] = len(khach)
    ket["so_dong_bi_gop_vao_dong_khac"] = len(goc) - len(khach)
    ket["so_nhom_da_gop(>=2 dong)"] = sum(1 for v in cum if len(v) >= 2)
    ket["phan_bo_kich_thuoc_nhom"] = dict(sorted(Counter(len(v) for v in cum).items()))
    ket["o_trong_truoc"] = {c: rong(chuoi_o(r[c]) for r in goc) for c in COT_GOC[2:]}
    ket["o_trong_sau"] = {
        c: rong(k[c] for k in khach) for c in ["ho_ten", "sdt", "sdt_khac", "email", "email_khac", "dia_chi", "ghi_chu"]
    }
    ket["so_nhom_nghi_trung"] = dict(Counter(x[0] for x in nghi))
    ket["so_dong_trong_nhom_nghi_trung"] = len({i for x in nghi for i in x[1]})
    ket["so_o_da_sua"] = len(nhat_ky_sua)
    ket["so_o_sua_theo_cot"] = dict(Counter(x[1] for x in nhat_ky_sua))
    ket["doi_cho_ten_dia_chi"] = thong_ke["doi_cho_ten_dia_chi"]
    ket["sdt_khong_hop_le"] = thong_ke["sdt_khong_hop_le"]
    ket["email_khong_hop_le"] = thong_ke["email_khong_hop_le"]
    ket["ten_mot_tu"] = [d["ma"] + ":" + d["ten"] for d in dong if len(d["ten"].split()) == 1]
    ket["ten_khong_dau_hoan_toan"] = sum(1 for d in dong if d["ten"] and so_dau(d["ten"]) == 0)
    ket["canh_bao_cum"] = canh_bao
    print(json.dumps(ket, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    main()
