"""Sinh dữ liệu GIẢ để tập dùng coding agent (nhóm bài 00).

Tên người, sản phẩm, giá đều bịa. Hạt giống cố định nên chạy lại luôn ra đúng bản cũ.
Chạy:  python -X utf8 sinh_du_lieu_thu.py
Ghi ra (cạnh script): don-hang-thu.csv, ghi-chu-thu.txt
"""
import csv
import random
from pathlib import Path

SEED = 20261121
random.seed(SEED)
here = Path(__file__).parent

KHACH = ["Nguyễn Thị Hoa", "Trần Văn Minh", "Lê Thu Trang", "Phạm Quốc Bảo", "Đỗ Ngọc Lan", "Vũ Hải Đăng"]
HANG = [  # (tên sản phẩm, đơn giá đồng)
    ("Nồi cơm điện 1,8L", 890000),
    ("Bình đun siêu tốc", 350000),
    ("Máy xay sinh tố", 720000),
    ("Chảo chống dính 26cm", 280000),
    ("Bộ dao nhà bếp", 195000),
    ("Hộp đựng thực phẩm", 85000),
    ("Quạt mini để bàn", 240000),
]

rows = []
ma = 1
for i in range(1, 13):                      # 12 đơn
    ngay = f"2026-11-{random.randint(1, 20):02d}"
    khach = KHACH[(i * 5 + random.randint(0, 2)) % len(KHACH)]
    for ten, gia in random.sample(HANG, random.choice([1, 1, 2, 2, 3])):   # 1-3 dòng hàng mỗi đơn
        rows.append([f"DH2611-{i:03d}", ngay, khach, ten, random.randint(1, 3), gia])
rows.sort(key=lambda r: (r[0], r[3]))

with open(here / "don-hang-thu.csv", "w", newline="", encoding="utf-8-sig") as f:
    w = csv.writer(f)
    w.writerow(["ma_don", "ngay", "khach", "san_pham", "so_luong", "don_gia"])
    w.writerows(rows)

(here / "ghi-chu-thu.txt").write_text(
    "Ghi chú giao hàng tháng 11/2026 (dữ liệu giả để học)\n"
    "- DH2611-002: khách dặn gọi trước khi giao.\n"
    "- DH2611-005: giao buổi chiều, sau 17 giờ.\n"
    "- DH2611-009: đổi địa chỉ nhận hàng, xem lại với khách.\n"
    "- DH2611-011: khách hẹn thanh toán khi nhận hàng.\n",
    encoding="utf-8-sig")

print(f"Đã ghi {len(rows)} dòng hàng, {len({r[0] for r in rows})} đơn, {len({r[2] for r in rows})} khách (hạt giống {SEED}).")
