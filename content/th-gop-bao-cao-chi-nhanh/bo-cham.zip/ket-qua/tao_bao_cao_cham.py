"""Gom toàn bộ kết quả chấm của bài 08 vào ket-qua/bao-cao-cham.json (chạy lại cham.py / chay_lai.py cho từng lần chạy).
Chạy:  python -X utf8 tao_bao_cao_cham.py <thư_mục_bài> <thư_mục_scratch_agentlab/08>
Bố cục LAB: runs/t10-<agent>/ (bài 1-2), runs/p-<agent>/ (bài 3: agent sửa định dạng mới), logs/*.json (giây, token)
"""
import sys, json, subprocess
from pathlib import Path
BAI = Path(sys.argv[1]); LAB = Path(sys.argv[2]); KQ = BAI / "ket-qua"; DL = BAI / "du-lieu"
sys.path.insert(0, str(KQ))
from cham import cham

OUT = {"ghi_chu": "Mọi số do cham.py/chay_lai.py tính từ file kết quả thật, ngày chạy 2026-11-20. Dữ liệu giả. n=1 lần chạy hợp lệ mỗi agent mỗi tình huống.", "bai1_2": {}, "bai3": {}}


def meta(name):
    d = json.loads((LAB / "logs" / f"{name}.json").read_text(encoding="utf-8"))
    return {"giay": d["seconds"], "so_luot": d.get("turns"), "returncode": d["returncode"], "usage": d.get("usage"), "cost_usd": d.get("cost_usd"), "status": d.get("status")}


def sh(*args):
    p = subprocess.run([sys.executable, "-X", "utf8", str(KQ / "chay_lai.py"), *map(str, args)], capture_output=True, text=True, encoding="utf-8", errors="replace")
    return p


for ag in ("claude", "agy"):
    m = meta(f"t10-{ag}")
    c = cham(LAB / "runs" / f"t10-{ag}", KQ / "dap-an-T10.json", DL / "thang-10" / "goc")
    OUT["bai1_2"][ag] = {**m, "cham": c}
    # bài 3a: chạy lại gop.py gốc (chưa sửa) cho T11 và T11 đổi định dạng, không gọi agent
    gop = LAB / "runs" / f"t10-{ag}" / "gop.py"
    b = {}
    for tag, data, truth, thang in (("T11", "thang-11", "dap-an-T11.json", "2026-11"), ("T11_doi_dinh_dang", "thang-11-doi-dinh-dang", "dap-an-T11-doi-dinh-dang.json", "2026-11")):
        out = KQ / f"bai3-{ag}-{tag.replace('_', '-')}.json"
        sh(gop, DL / data, KQ / truth, LAB / "runs" / f"w-{ag}-{tag}", thang, "--so-voi-thang-khac", KQ / "dap-an-T10.json", "--out", out)
        b[tag] = json.loads(out.read_text(encoding="utf-8"))
    OUT["bai3"].setdefault(ag, {})["gop_cu_thang_moi"] = b
    # bài 3b: sau khi agent sửa
    pr = LAB / "runs" / f"p-{ag}"
    if (LAB / "logs" / f"p-{ag}.json").exists():
        OUT["bai3"][ag]["agent_sua"] = {"meta": meta(f"p-{ag}"), "cham_chinh_run": cham(pr, KQ / "dap-an-T11-doi-dinh-dang.json", DL / "thang-11-doi-dinh-dang" / "goc")}
        reg = {}
        for tag, data, truth, thang in (("T11_doi_dinh_dang", "thang-11-doi-dinh-dang", "dap-an-T11-doi-dinh-dang.json", "2026-11"), ("T11_cu", "thang-11", "dap-an-T11.json", "2026-11"), ("T10_cu", "thang-10", "dap-an-T10.json", "2026-10")):
            out = KQ / f"bai3-{ag}-sua-{tag.replace('_', '-')}.json"
            sh(pr / "gop.py", DL / data, KQ / truth, LAB / "runs" / f"w-{ag}-sua-{tag}", thang, "--so-voi-thang-khac", KQ / ("dap-an-T10.json" if thang == "2026-11" else "dap-an-T11.json"), "--out", out)
            reg[tag] = json.loads(out.read_text(encoding="utf-8"))
        OUT["bai3"][ag]["agent_sua"]["chay_lai_gop_da_sua"] = reg

(KQ / "bao-cao-cham.json").write_text(json.dumps(OUT, ensure_ascii=False, indent=1), encoding="utf-8")
print("đã ghi", KQ / "bao-cao-cham.json")
