"""Tự kiểm một thư mục kết quả làm sạch danh bạ, KHÔNG cần đáp án (dùng được cả với dữ liệu thật của bạn).

Dùng:  python -X utf8 tu_kiem.py <thư_mục_có_danh-ba-goc.xlsx_và_các_file_kết_quả>
Kiểm (5 phép, thêm 1 cảnh báo SĐT bị bỏ sót):
  1. Mỗi Mã dòng gốc xuất hiện đúng 1 lần trong nhat-ky-gop.csv (không mất, không trùng, không lạ).
  2. Các cụm trong nhat-ky-gop.csv khớp với cột ma_dong_goc của danh-ba-sach.xlsx (hoàn tác được).
  3. SĐT sạch đúng định dạng; email sạch đúng cú pháp.
  4. Cùng một SĐT/email mà nằm ở hai khách KHÁC nhau thì phải có mặt trong nghi-trung-can-quyet.csv.
  5. Mỗi 'gia_tri_cu' trong nhat-ky-sua.csv phải có thật trong file gốc (nhật ký không bịa).
Thoát mã 0 nếu mọi thứ đạt, 1 nếu có mục trượt.
"""
import sys, csv, re
from pathlib import Path
import openpyxl

PHONE = re.compile(r"^(0[35789]\d{8}|02\d{9})$")
EMAIL = re.compile(r"^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)+$")

def read_csv(p):
    return list(csv.DictReader(Path(p).read_text(encoding="utf-8-sig").splitlines()))

def main(d):
    d = Path(d); fails = []
    def check(name, ok, detail=""):
        print(("ĐẠT   " if ok else "TRƯỢT ") + name + (f"  [{detail}]" if detail else ""))
        if not ok: fails.append(name)
    goc_ws = openpyxl.load_workbook(d / "danh-ba-goc.xlsx").active
    goc_rows = {str(r[0]): [("" if v is None else str(v)) for v in r] for r in list(goc_ws.iter_rows(values_only=True))[1:] if r[0]}
    gop = read_csv(d / "nhat-ky-gop.csv")
    ids = [g["ma_dong_goc"].strip() for g in gop]
    miss = sorted(set(goc_rows) - set(ids)); dup = sorted({i for i in ids if ids.count(i) > 1}); odd = sorted(set(ids) - set(goc_rows))
    check("1. mỗi dòng gốc đúng 1 lần trong nhật ký gộp", not (miss or dup or odd), f"{len(ids)}/{len(goc_rows)} dòng; thiếu {len(miss)}, trùng {len(dup)}, lạ {len(odd)}")
    ws = openpyxl.load_workbook(d / "danh-ba-sach.xlsx")["KhachHang"]
    rows = list(ws.iter_rows(values_only=True)); hd = rows[0]
    clean = [dict(zip(hd, ["" if v is None else str(v) for v in r])) for r in rows[1:] if any(r)]
    cl_a = {}
    for g in gop: cl_a.setdefault(g["ma_khach"], set()).add(g["ma_dong_goc"].strip())
    cl_b = {c["ma_khach"]: set(x for x in re.split(r"[;,\s]+", c["ma_dong_goc"]) if x) for c in clean}
    check("2. nhật ký gộp khớp file sạch (hoàn tác được)", cl_a == cl_b, f"{len(cl_a)} cụm so với {len(cl_b)} khách")
    badp = [c["ma_khach"] for c in clean for v in [c["sdt"].strip()] if v and not PHONE.match(v)]
    bade = [c["ma_khach"] for c in clean for v in [c["email"].strip()] if v and not EMAIL.match(v)]
    check("3a. SĐT sạch đúng định dạng", not badp, f"sai: {badp[:5]}")
    check("3b. email sạch đúng cú pháp", not bade, f"sai: {bade[:5]}")
    # 4. chung SĐT/email giữa hai khách khác nhau
    rev = read_csv(d / "nghi-trung-can-quyet.csv") if (d / "nghi-trung-can-quyet.csv").exists() else []
    rev_sets = [set(x for x in re.split(r"[;,\s]+", r["ma_dong_goc"]) if x) for r in rev]
    shared = {}
    for c in clean:
        for col in ("sdt", "sdt_khac", "email", "email_khac"):
            for v in re.split(r"[;,\s]+", c.get(col, "")):
                if v: shared.setdefault(v, set()).add(c["ma_khach"])
    uncovered = []
    for v, ks in shared.items():
        if len(ks) > 1:
            union = set().union(*[cl_b[k] for k in ks])
            if not any(len(x & union) >= 2 for x in rev_sets):
                uncovered.append(v)
    check("4. giá trị dùng chung giữa 2 khách khác nhau đều nằm trong danh sách cần quyết", not uncovered, f"chưa có trong danh sách: {uncovered[:5]}; số giá trị dùng chung: {sum(1 for ks in shared.values() if len(ks) > 1)}")
    sua = read_csv(d / "nhat-ky-sua.csv")
    allgoc = "\n".join("\n".join(r) for r in goc_rows.values())
    bad_old = [s for s in sua if s["gia_tri_cu"] and s["gia_tri_cu"] not in allgoc]
    check("5. giá trị cũ trong nhật ký sửa có thật trong file gốc", not bad_old, f"{len(sua)} dòng nhật ký; không khớp {len(bad_old)}")
    # 6. CẢNH BÁO (không tính trượt): khách không có SĐT sạch nhưng dòng gốc của họ có chuỗi >= 9 chữ số.
    #    Một phần là SĐT sai thật (bị che, thiếu số), phần còn lại có thể là SĐT bị bỏ sót: cần mắt người xem.
    sus = []
    for c in clean:
        if c["sdt"].strip() or c.get("sdt_khac", "").strip(): continue
        for rid in cl_b[c["ma_khach"]]:
            for v in goc_rows.get(rid, [])[2:]:
                if len(re.sub(r"\D", "", v)) >= 9: sus.append((c["ma_khach"], rid, v[:60]))
    print(f"\nCẢNH BÁO 6. khách không có SĐT sạch nhưng dòng gốc có chuỗi >= 9 chữ số: {len(sus)} chỗ (cần xem tay)")
    for x in sus[:15]: print("      ", x)
    print("\nTỔNG:", "ĐẠT TẤT CẢ" if not fails else f"TRƯỢT {len(fails)} mục", "(chưa tính cảnh báo 6)")
    return 1 if fails else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
