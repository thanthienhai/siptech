# -*- coding: utf-8 -*-
"""
doi_soat.py - Đối soát sao kê ngân hàng T10/2026 với sổ đơn hàng.

Chạy:  python -X utf8 doi_soat.py        (trong thư mục chứa hai file đầu vào)

Đầu vào (chỉ đọc):  sao-ke-t10-2026.csv, so-don-hang-t10-2026.xlsx
Đầu ra (ghi đè):    bang_ghep.csv, ngoai_le.csv, tong_kiem.json, bao_cao.md

Nguyên tắc: mọi phép cộng/trừ/so sánh tiền đều do code làm; không chắc thì
ghi CAN NGUOI QUYET kèm ứng viên, không đoán.
"""
import csv
import json
import re
import sys
import unicodedata
from datetime import date, datetime
from pathlib import Path

import openpyxl

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

BASE = Path(__file__).resolve().parent
SAO_KE = BASE / "sao-ke-t10-2026.csv"
SO_DON = BASE / "so-don-hang-t10-2026.xlsx"

LOAI_DA_GHEP = ("khop_du", "thieu", "thua", "trung", "nhieu_don")
TAT_CA_LOAI = ("khop_du", "thieu", "thua", "trung", "nhieu_don", "hoan_tien",
               "cod_gop", "phi_lai_ngan_hang", "chi_khac", "khong_ro_nguon")
CAO, TB, THAP, CNQ = "CAO", "TRUNG BINH", "THAP", "CAN NGUOI QUYET"


# --------------------------------------------------------------------------
# Tiện ích chuẩn hóa
# --------------------------------------------------------------------------
def bo_dau(s):
    s = str(s).replace("Đ", "D").replace("đ", "d")
    s = unicodedata.normalize("NFD", s)
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def so_tien(v):
    """'1,250,000' | '5.550.000 đ' | 1250000 | 1250000.0 -> int (đồng)."""
    if v is None or v == "":
        return 0
    if isinstance(v, (int, float)):
        return int(round(v))
    digits = re.sub(r"[^\d]", "", str(v))
    return int(digits) if digits else 0


def to_date(v):
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    s = str(v).strip()
    for f in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, f).date()
        except ValueError:
            pass
    raise ValueError(f"Không đọc được ngày: {v!r}")


def vnd(n):
    return f"{n:,}".replace(",", ".") + "đ"


def dm(d):
    return d.strftime("%d/%m")


def ma(n):
    return f"DH2610-{int(n):03d}"


# --------------------------------------------------------------------------
# Đọc dữ liệu
# --------------------------------------------------------------------------
def doc_so_don():
    wb = openpyxl.load_workbook(SO_DON, data_only=True)
    ws = wb.worksheets[0]
    rows = list(ws.iter_rows(values_only=True))
    head = [str(h).strip() for h in rows[0]]
    idx = {h: i for i, h in enumerate(head)}
    orders = {}
    canh_bao = []
    for r in rows[1:]:
        if not r or r[idx["Mã đơn"]] in (None, ""):
            continue
        code = str(r[idx["Mã đơn"]]).strip()
        tt = bo_dau(r[idx["Trạng thái"]]).lower().strip()
        o = {
            "code": code,
            "date": to_date(r[idx["Ngày đặt"]]),
            "ten": str(r[idx["Khách hàng"]]).strip(),
            "sdt": str(r[idx["SĐT"]]).strip(),
            "tien_hang": so_tien(r[idx["Tiền hàng"]]),
            "ship": so_tien(r[idx["Phí ship"]]),
            "tong": so_tien(r[idx["Tổng phải thu"]]),
            "httt": str(r[idx["Hình thức TT"]]).strip().upper(),
            "tt": tt,  # huy | hoan tien | dang giao | da giao
            "tt_goc": str(r[idx["Trạng thái"]]).strip(),
            "ghi_chu": r[idx["Ghi chú"]],
        }
        if o["tien_hang"] + o["ship"] != o["tong"]:
            canh_bao.append(f"{code}: tiền hàng + ship = {o['tien_hang'] + o['ship']} "
                            f"khác tổng phải thu {o['tong']}")
        orders[code] = o
    return orders, canh_bao


def doc_sao_ke():
    with open(SAO_KE, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.reader(f))
    info = {}
    txs = []
    in_table = False
    for r in rows:
        if not r or not any(c.strip() for c in r):
            continue
        k = bo_dau(r[0]).strip().lower()
        if k.startswith("ngay gd"):
            in_table = True
            continue
        if in_table and re.fullmatch(r"\d{2}/\d{2}/\d{4}", r[0].strip()):
            txs.append({
                "so_ct": r[1].strip(),
                "ngay": to_date(r[0]),
                "no": so_tien(r[2]),
                "co": so_tien(r[3]),
                "so_du": so_tien(r[4]),
                "nd": r[5].strip(),
            })
            continue
        # dòng thông tin đầu file hoặc dòng tổng cuối file: không phải giao dịch
        if k.startswith("so du dau"):
            info["so_du_dau"] = so_tien(r[1])
        elif k.startswith("tong phat sinh no"):
            info["tong_no"] = so_tien(r[1])
        elif k.startswith("tong phat sinh co"):
            info["tong_co"] = so_tien(r[1])
        elif k.startswith("so du cuoi"):
            info["so_du_cuoi"] = so_tien(r[1])
    return info, txs


# --------------------------------------------------------------------------
# Rút mã đơn / tên từ nội dung chuyển khoản
# --------------------------------------------------------------------------
# DH2610-054 | DH-2610-065 | DH2610061 | DH 2610 067 | dh2610-42 | DH261O-028
DH_RE = re.compile(r"(?<![A-Z])D\s*H[\s\-]*2\s*6\s*1\s*[0O][\s\-]*([0-9O]{1,3})(?![0-9])")
STOP = {"CK", "TT", "DON", "HANG", "SO", "CHUYEN", "TIEN", "KHOAN", "MUA", "VA",
        "LAI", "GUI", "HD", "DH", "TRA", "THANH", "ZALO"}


def rut_noi_dung(nd, max_code):
    t = bo_dau(nd).upper()
    codes = []
    for m in DH_RE.finditer(t):
        n = int(m.group(1).replace("O", "0"))
        if 1 <= n <= max_code:
            codes.append(n)
    n_explicit = len(codes)
    rest = DH_RE.sub(" ", t)
    count_hint = None
    m = re.search(r"(\d+)\s*DON\b", rest)
    if m:
        count_hint = int(m.group(1))
    hint = bool(re.search(r"\b(DON|SO)\b", rest)) or n_explicit > 0
    bare_used = []
    if hint:
        for m in re.finditer(r"(?<![0-9])(\d{1,3})(?![0-9])", rest):
            after = rest[m.end():].lstrip()
            before = rest[:m.start()].rstrip()
            if after.startswith("DON") or before.endswith("HD"):
                continue  # '3 don' là số lượng đơn; 'HD 0087' là số hóa đơn
            n = int(m.group(1))
            if 1 <= n <= max_code:
                codes.append(n)
                bare_used.append(m.span())
    seen, uniq = set(), []
    for n in codes:
        if n not in seen:
            seen.add(n)
            uniq.append(n)
    name_txt = re.sub(r"THANH\s+TOAN", " ", rest)
    name_txt = re.sub(r"[^A-Z ]", " ", name_txt)
    name = [w for w in name_txt.split() if w not in STOP]
    hd_pseudo = bool(re.search(r"\bHD\s*\d+", t))
    return {"codes": [ma(n) for n in uniq], "n_explicit": n_explicit,
            "count_hint": count_hint, "name": name, "hd_pseudo": hd_pseudo}


def khop_ten(memo_tokens, cust_name):
    """None = nội dung không có tên; True/False = khớp / không khớp tên khách.
    Cho phép viết tắt chữ cái đầu (T K QUYNH) và bỏ đệm (NGO DUNG)."""
    if not memo_tokens:
        return None
    ct = bo_dau(cust_name).upper().split()
    pos = 0
    for tok in memo_tokens:
        found = False
        while pos < len(ct):
            c = ct[pos]
            pos += 1
            if c == tok or (len(tok) == 1 and c.startswith(tok)):
                found = True
                break
        if not found:
            return False
    return pos == len(ct)  # token cuối phải trùng tên gọi cuối của khách


def tim_tong_tap_con(items, target, gioi_han=50):
    """Mọi tập con của items [(ma, tien)] có tổng = target."""
    items = sorted(items, key=lambda x: -x[1])
    suffix = [0] * (len(items) + 1)
    for i in range(len(items) - 1, -1, -1):
        suffix[i] = suffix[i + 1] + items[i][1]
    out = []

    def rec(i, remain, chosen):
        if len(out) >= gioi_han:
            return
        if remain == 0:
            out.append(tuple(sorted(chosen)))
            return
        if i == len(items) or remain < 0 or suffix[i] < remain:
            return
        chosen.append(items[i][0])
        rec(i + 1, remain - items[i][1], chosen)
        chosen.pop()
        rec(i + 1, remain, chosen)

    rec(0, target, [])
    return out


# --------------------------------------------------------------------------
# Đối soát
# --------------------------------------------------------------------------
def main():
    orders, canh_bao_so_don = doc_so_don()
    info, txs = doc_sao_ke()
    max_code = max(int(c.split("-")[1]) for c in orders)

    ket_qua = {}        # so_ct -> dict
    ngoai_le = []
    paid = {}           # mã đơn -> [(so_ct, số tiền)] các dòng đã ghép (không tính dòng trùng)
    cod_da_ghep = {}    # mã đơn COD -> so_ct
    ung_vien_cua = {}   # mã đơn -> [so_ct] các dòng CAN NGUOI QUYET đang trỏ tới đơn
    cod_chon = []       # diagnostics
    kieu_cnq = {}       # so_ct -> sai_ma | cod | khac
    cod_mo_ho = set()   # đơn COD nằm trong tổ hợp chưa chốt được

    def ex(loai, so_ct, ma_don, mo_ta, de_xuat):
        ngoai_le.append({"loai_ngoai_le": loai, "so_ct": so_ct or "",
                         "ma_don": ";".join(ma_don) if isinstance(ma_don, (list, tuple)) else (ma_don or ""),
                         "mo_ta": mo_ta, "de_xuat": de_xuat})

    def dat(tx, loai, muc, ly_do, ma_don=(), phan_bo=()):
        ket_qua[tx["so_ct"]] = {
            "so_ct": tx["so_ct"], "ngay": tx["ngay"].isoformat(),
            "chieu": "co" if tx["co"] else "no", "so_tien": tx["co"] or tx["no"],
            "ma_don": ";".join(ma_don), "phan_bo": ";".join(f"{c}:{a}" for c, a in phan_bo),
            "loai": loai, "muc_chac_chan": muc, "ly_do": ly_do,
        }

    def eligible(o, d):
        return (o["httt"] == "CK" and o["tt"] != "huy" and o["code"] not in paid
                and o["date"] <= d)

    def theo_ten_tien(ntoks, amt, d):
        return [o for o in orders.values()
                if eligible(o, d) and o["tong"] == amt and khop_ten(ntoks, o["ten"]) is True]

    def mo_ta_don(o):
        return f"{o['code']} ({o['ten']}, {vnd(o['tong'])}, đặt {dm(o['date'])})"

    def cnq(tx, ly_do, cands=(), loai="khong_ro_nguon", kieu="khac"):
        cands = list(cands)
        kieu_cnq[tx["so_ct"]] = kieu
        for c in cands:
            ung_vien_cua.setdefault(c, []).append(tx["so_ct"])
        dat(tx, loai, CNQ, ly_do)
        if cands:
            ex("can_nguoi_quyet", tx["so_ct"], cands,
               f"Dòng ghi có {vnd(tx['co'])} ngày {dm(tx['ngay'])} \"{tx['nd']}\": {ly_do}",
               "Hỏi khách/kiểm tra lại rồi chọn đơn đúng; chưa ghép dòng này vào đơn nào.")
        else:
            ex("khong_ro_nguon", tx["so_ct"], "",
               f"Dòng ghi có {vnd(tx['co'])} ngày {dm(tx['ngay'])} \"{tx['nd']}\": {ly_do}",
               "Hỏi ngân hàng/khách về người chuyển; nếu không xác định được thì ghi nhận là thu nhập khác.")

    # ---------------- xử lý ghi nợ ----------------
    BANK_KW = ("PHI SMS", "PHI DUY TRI", "PHI CHUYEN KHOAN", "PHI QUAN LY TAI KHOAN", "LAI TIEN GUI")
    NHOM_CHI = [
        ("LUONG", "chi lương nhân viên"), ("THUE MAT BANG", "chi thuê mặt bằng"),
        ("TIEN DIEN", "chi tiền điện"), ("INTERNET", "chi internet"), ("BHXH", "chi bảo hiểm xã hội"),
        ("PHI SAN TMDT", "phí sàn thương mại điện tử"), ("QUANG CAO", "chi quảng cáo"),
        ("NCC", "thanh toán tiền hàng cho nhà cung cấp"), ("SHIP", "chi vận chuyển nội thành"),
        ("XANG", "chi xăng giao hàng"), ("NHA XE", "chi gửi hàng nhà xe"),
        ("BAO BI", "chi bao bì đóng gói"), ("CARTON", "chi mua vật tư đóng gói"),
        ("BANG DINH", "chi mua vật tư đóng gói"), ("VAN PHONG PHAM", "chi văn phòng phẩm"),
    ]

    def xu_ly_no(tx):
        t = bo_dau(tx["nd"]).upper()
        if "HOAN TIEN" in t:
            r = rut_noi_dung(tx["nd"], max_code)
            if len(r["codes"]) == 1 and r["codes"][0] in orders and r["codes"][0] in paid:
                c = r["codes"][0]
                o = orders[c]
                da_thu = sum(a for _, a in paid[c])
                if tx["no"] == da_thu:
                    dat(tx, "hoan_tien", CAO,
                        f"Hoàn đủ {vnd(tx['no'])} cho đơn {c}, khớp số đã thu và trạng thái đơn là '{o['tt_goc']}'.",
                        [c], [(c, tx["no"])])
                else:
                    chenh = da_thu - tx["no"]
                    them = (f", phần giữ lại {vnd(chenh)} đúng bằng phí ship của đơn" if chenh == o["ship"] else "")
                    dat(tx, "hoan_tien", TB,
                        f"Hoàn một phần {vnd(tx['no'])} trên {vnd(da_thu)} đã thu của đơn {c}{them}.",
                        [c], [(c, tx["no"])])
                    ex("hoan_tien_mot_phan", tx["so_ct"], [c],
                       f"Đơn {c} đã thu {vnd(da_thu)}, hoàn khách {vnd(tx['no'])}, shop giữ lại {vnd(chenh)}"
                       f"{' (bằng phí ship ' + vnd(o['ship']) + ')' if chenh == o['ship'] else ''}.",
                       "Xác nhận chính sách giữ phí ship với khách và ghi nhận khoản giữ lại vào doanh thu.")
                return
            dat(tx, "hoan_tien", CNQ, "Nội dung hoàn tiền nhưng không xác định được đơn đã thu tương ứng.")
            ex("can_nguoi_quyet", tx["so_ct"], "", f"Hoàn tiền {vnd(tx['no'])}: \"{tx['nd']}\" không gắn được đơn.",
               "Kiểm tra đơn/khách được hoàn.")
            return
        if any(k in t for k in BANK_KW):
            dat(tx, "phi_lai_ngan_hang", TB, "Phí/lãi ngân hàng nhận diện theo từ khóa, không gắn đơn hàng.")
            return
        for k, nhom in NHOM_CHI:
            if k in t:
                dat(tx, "chi_khac", TB, f"Khoản chi không gắn đơn hàng ({nhom}), phân loại theo từ khóa trong nội dung.")
                return
        dat(tx, "chi_khac", THAP, "Khoản chi không nhận diện được nhóm, tạm xếp chi khác; chưa gắn đơn.")

    # ---------------- xử lý ghi có ----------------
    def xu_ly_cod(tx):
        ung = [(c, o["tong"]) for c, o in orders.items()
               if o["httt"] == "COD" and o["tt"] == "da giao" and o["date"] <= tx["ngay"]
               and c not in cod_da_ghep]
        sol = tim_tong_tap_con(ung, tx["co"])
        cod_chon.append((tx["so_ct"], len(ung), len(sol)))
        if len(sol) == 1:
            codes = list(sol[0])
            pb = [(c, orders[c]["tong"]) for c in codes]
            for c in codes:
                cod_da_ghep[c] = tx["so_ct"]
            dat(tx, "cod_gop", TB,
                f"Hãng vận chuyển đối soát COD gộp {len(codes)} đơn; chỉ có đúng 1 tổ hợp đơn COD đã giao "
                f"(đặt đến {dm(tx['ngay'])}) cộng lại bằng {vnd(tx['co'])}.", codes, pb)
        elif len(sol) == 0:
            kieu_cnq[tx["so_ct"]] = "cod"
            dat(tx, "cod_gop", CNQ, "Đối soát COD gộp nhưng không có tổ hợp đơn COD nào cộng lại khớp số tiền.")
            ex("can_nguoi_quyet", tx["so_ct"], "", f"COD gộp {vnd(tx['co'])} không khớp tổ hợp đơn COD nào.",
               "Xin bảng kê đối soát chi tiết từ hãng vận chuyển.")
        else:
            kieu_cnq[tx["so_ct"]] = "cod"
            hop = sorted({c for s_ in sol for c in s_})
            cod_mo_ho.update(hop)
            ds = " HOẶC ".join("{" + ", ".join(x.replace("DH2610-", "") for x in s_) + "}" for s_ in sol)
            dat(tx, "cod_gop", CNQ,
                f"Đối soát COD gộp có {len(sol)} tổ hợp đơn COD cùng cộng lại bằng {vnd(tx['co'])}: {ds}; không chọn được.")
            ex("can_nguoi_quyet", tx["so_ct"], hop,
               f"COD gộp {vnd(tx['co'])} ngày {dm(tx['ngay'])} khớp {len(sol)} tổ hợp đơn khác nhau: {ds}.",
               "Xin bảng kê đối soát chi tiết từ hãng vận chuyển để biết đúng đơn nào nằm trong đợt này.")

    def xu_ly_co(tx, cuoi):
        """Trả về False nếu cần hoãn sang lượt 2 (chỉ có số tiền, không mã, không tên)."""
        t = bo_dau(tx["nd"]).upper()
        if "DOI SOAT COD" in t:
            xu_ly_cod(tx)
            return True
        if any(k in t for k in BANK_KW):
            dat(tx, "phi_lai_ngan_hang", TB, "Lãi/phí ngân hàng nhận diện theo từ khóa, không gắn đơn hàng.")
            return True
        r = rut_noi_dung(tx["nd"], max_code)
        codes, ntoks, amt, d = r["codes"], r["name"], tx["co"], tx["ngay"]

        # ---- có mã đơn ----
        if len(codes) == 1:
            c = codes[0]
            o = orders[c]
            nm = khop_ten(ntoks, o["ten"])
            eq = amt == o["tong"]
            da_tra = c in paid
            if o["httt"] != "CK" or o["tt"] == "huy":
                cnq(tx, f"mã {c} là đơn {'COD' if o['httt'] != 'CK' else 'đã hủy'}, không phải đơn chờ khách chuyển khoản.", [c])
                return True
            if eq and nm is not False:
                if not da_tra:
                    ghi = "" if d >= o["date"] else f" (lưu ý: chuyển {dm(d)} trước ngày đặt đơn {dm(o['date'])})"
                    muc = CAO if d >= o["date"] else TB
                    ten = f", tên {' '.join(ntoks)} khớp khách" if nm else ""
                    paid[c] = [(tx["so_ct"], amt)]
                    dat(tx, "khop_du", muc, f"Mã {c} và số tiền {vnd(amt)} khớp đơn{ten}{ghi}.", [c], [(c, amt)])
                else:
                    dat(tx, "trung", TB,
                        f"Đơn {c} đã được trả đủ bởi dòng {paid[c][0][0]}; dòng này trùng mã và số tiền nên là lần chuyển thứ hai.",
                        [c], [(c, amt)])
                    ex("chuyen_trung", tx["so_ct"], [c],
                       f"Khách chuyển {vnd(amt)} lần 2 cho đơn {c} (đã trả đủ ở dòng {paid[c][0][0]}).",
                       f"Hoàn lại {vnd(amt)} cho khách hoặc trừ vào đơn sau sau khi xác nhận với khách.")
                return True
            if eq and nm is False:
                if da_tra:
                    cnq(tx, f"mã {c} khớp số tiền nhưng đơn đã được trả và tên '{' '.join(ntoks)}' khác khách {o['ten']}.", [c])
                    return True
                paid[c] = [(tx["so_ct"], amt)]
                dat(tx, "khop_du", TB,
                    f"Mã {c} và số tiền {vnd(amt)} khớp đơn nhưng tên người chuyển '{' '.join(ntoks)}' khác khách {o['ten']}.",
                    [c], [(c, amt)])
                ex("ten_khac_khach", tx["so_ct"], [c],
                   f"Dòng ghi có {vnd(amt)} ghi tên '{' '.join(ntoks)}', còn đơn {c} là của {o['ten']} (mã và tiền khớp).",
                   "Hỏi khách xem có chuyển hộ không; nếu đúng thì giữ ghép này.")
                return True
            # ---- số tiền khác tổng đơn ----
            if nm is False:
                cands = theo_ten_tien(ntoks, amt, d)
                ten_ung = "; ".join(mo_ta_don(x) for x in cands)
                tinh_trang = "đã có dòng trả tiền khác" if da_tra else f"cần {vnd(o['tong'])}"
                ly = (f"nội dung ghi mã {c} (của {o['ten']}, {tinh_trang}) mâu thuẫn với tên '{' '.join(ntoks)}' và số tiền {vnd(amt)}")
                if cands:
                    ly += f"; tên và số tiền khớp {ten_ung}"
                else:
                    ly += "; không có đơn nào khớp cả tên lẫn số tiền"
                cnq(tx, ly + ".", [x["code"] for x in cands] + [c], kieu="sai_ma")
                return True
            alt = [x for x in orders.values() if eligible(x, d) and x["tong"] == amt and x["code"] != c]
            if da_tra or (alt and nm is None):
                cnq(tx, f"mã {c} nhưng số tiền {vnd(amt)} không khớp {vnd(o['tong'])}"
                        f"{' và đơn đã có dòng trả khác' if da_tra else ''}; còn đơn khác cùng số tiền: "
                        f"{'; '.join(mo_ta_don(x) for x in alt) or 'không'}.", [c] + [x["code"] for x in alt])
                return True
            chenh = abs(amt - o["tong"])
            paid[c] = [(tx["so_ct"], amt)]
            ten = f", tên {' '.join(ntoks)} khớp khách" if nm else ""
            if amt < o["tong"]:
                dat(tx, "thieu", TB, f"Mã {c}{ten} khớp nhưng khách chuyển {vnd(amt)} thấp hơn phải thu {vnd(o['tong'])} (thiếu {vnd(chenh)}).", [c], [(c, amt)])
                ex("chuyen_thieu", tx["so_ct"], [c],
                   f"Đơn {c} ({o['ten']}) phải thu {vnd(o['tong'])}, mới nhận {vnd(amt)}, còn thiếu {vnd(chenh)}.",
                   f"Liên hệ khách thu nốt {vnd(chenh)} hoặc xác nhận giảm giá.")
            else:
                dat(tx, "thua", TB, f"Mã {c}{ten} khớp nhưng khách chuyển {vnd(amt)} cao hơn phải thu {vnd(o['tong'])} (thừa {vnd(chenh)}).", [c], [(c, amt)])
                ex("chuyen_thua", tx["so_ct"], [c],
                   f"Đơn {c} ({o['ten']}) phải thu {vnd(o['tong'])}, khách chuyển {vnd(amt)}, thừa {vnd(chenh)}.",
                   f"Hoàn {vnd(chenh)} cho khách hoặc trừ vào đơn sau sau khi xác nhận.")
            return True

        if len(codes) >= 2:
            thieu_ma = [c for c in codes if c not in orders]
            xau = [c for c in codes if orders[c]["httt"] != "CK" or orders[c]["tt"] == "huy" or c in paid]
            tong = sum(orders[c]["tong"] for c in codes)
            if xau:
                cnq(tx, f"ghi nhiều mã {', '.join(codes)} nhưng {', '.join(xau)} không còn là đơn CK chờ thu.", codes)
                return True
            if tong != amt:
                cnq(tx, f"ghi nhiều mã {', '.join(codes)} có tổng phải thu {vnd(tong)} khác số tiền {vnd(amt)}.", codes)
                return True
            ten_sai = [c for c in codes if khop_ten(ntoks, orders[c]["ten"]) is False]
            pb = [(c, orders[c]["tong"]) for c in codes]
            for c in codes:
                paid[c] = [(tx["so_ct"], orders[c]["tong"])]
            if ten_sai:
                dat(tx, "nhieu_don", TB, f"Một lần chuyển trả {len(codes)} đơn, tổng phải thu khớp {vnd(amt)} nhưng tên không khớp đơn {', '.join(ten_sai)}.", codes, pb)
            else:
                dat(tx, "nhieu_don", CAO, f"Một lần chuyển trả {len(codes)} đơn {', '.join(codes)}, tổng phải thu cộng lại đúng {vnd(amt)}.", codes, pb)
            return True

        # ---- không có mã: ghép theo tên + số tiền ----
        if ntoks:
            cands = theo_ten_tien(ntoks, amt, d)
            if len(cands) == 1:
                o = cands[0]
                paid[o["code"]] = [(tx["so_ct"], amt)]
                dat(tx, "khop_du", TB,
                    f"Không có mã đơn; tên '{' '.join(ntoks)}' khớp khách {o['ten']} và số tiền {vnd(amt)} khớp đúng một đơn chưa thu.",
                    [o["code"]], [(o["code"], amt)])
                return True
            if len(cands) > 1:
                cnq(tx, f"không có mã đơn; tên '{' '.join(ntoks)}' và số tiền khớp nhiều đơn: {'; '.join(mo_ta_don(x) for x in cands)}.",
                    [x["code"] for x in cands])
                return True
            # nhiều đơn theo số lượng "2 don"
            if r["count_hint"] and r["count_hint"] >= 2:
                kh = [o for o in orders.values() if eligible(o, d) and khop_ten(ntoks, o["ten"]) is True]
                sol = [s for s in tim_tong_tap_con([(o["code"], o["tong"]) for o in kh], amt) if len(s) == r["count_hint"]]
                if len(sol) == 1:
                    codes = list(sol[0])
                    pb = [(c, orders[c]["tong"]) for c in codes]
                    for c in codes:
                        paid[c] = [(tx["so_ct"], orders[c]["tong"])]
                    dat(tx, "nhieu_don", TB,
                        f"Ghi '{r['count_hint']} don' và tên khách {orders[codes[0]]['ten']}; chỉ có đúng một cặp đơn chưa thu của khách này cộng lại bằng {vnd(amt)}.",
                        codes, pb)
                    return True
                if len(sol) > 1:
                    cnq(tx, f"ghi '{r['count_hint']} don' nhưng có {len(sol)} tổ hợp đơn của khách khớp số tiền.",
                        sorted({c for s in sol for c in s}))
                    return True
        return False  # chỉ còn số tiền -> lượt 2

    def xu_ly_co_luot2(tx):
        r = rut_noi_dung(tx["nd"], max_code)
        amt = tx["co"]
        ntoks = r["name"]
        khach = [o for o in orders.values() if ntoks and khop_ten(ntoks, o["ten"]) is True]
        theo_tien = [o for o in orders.values() if o["httt"] == "CK" and o["tt"] != "huy" and o["tong"] == amt]
        chua_tra = [o for o in theo_tien if o["code"] not in paid]
        ung = []
        for o in chua_tra:
            ung.append(f"{o['code']} ({o['ten']}, đặt {dm(o['date'])}"
                       f"{', SAU ngày chuyển' if o['date'] > tx['ngay'] else ''}, trạng thái {o['tt_goc']})")
        ly = []
        if r["hd_pseudo"]:
            ly.append("nội dung ghi số hóa đơn (HD), không phải mã đơn DH2610")
        elif ntoks and not khach:
            ly.append(f"tên '{' '.join(ntoks)}' không trùng khách nào trong sổ")
        elif ntoks and khach:
            ly.append(f"tên '{' '.join(ntoks)}' trùng khách trong sổ nhưng không có đơn nào đúng số tiền")
        else:
            ly.append("nội dung không có mã đơn lẫn tên người chuyển")
        if ung:
            ly.append(f"đơn CK chưa có dòng trả cùng số tiền {vnd(amt)}: {'; '.join(ung)}")
        else:
            ly.append(f"không có đơn CK chưa thu nào tổng {vnd(amt)}")
        cnq(tx, "; ".join(ly) + ".", [o["code"] for o in chua_tra] if chua_tra else [])

    # -------- lượt 1: theo thứ tự sao kê --------
    hoan = []
    luot2 = []
    for tx in txs:
        if tx["no"]:
            if "HOAN TIEN" in bo_dau(tx["nd"]).upper():
                hoan.append(tx)  # xử lý sau khi đã biết các đơn đã thu
            else:
                xu_ly_no(tx)
        else:
            if not xu_ly_co(tx, False):
                luot2.append(tx)
    for tx in hoan:
        xu_ly_no(tx)
    for tx in luot2:
        xu_ly_co_luot2(tx)

    # -------- đơn CK chưa thu --------
    don_chua_thu = []
    for c, o in orders.items():
        if o["httt"] == "CK" and o["tt"] != "huy" and c not in paid:
            uv = ung_vien_cua.get(c)
            if uv:
                de = f"Xác nhận dòng {', '.join(uv)} có phải tiền của đơn này không (xem mục can_nguoi_quyet)."
                them = f" Có dòng sao kê ứng viên: {', '.join(uv)}, chưa được chốt."
            elif o["tt"] == "dang giao":
                de = "Đơn đang giao: theo dõi, nhắc khách chuyển khoản nếu quá hạn."
                them = " Đơn đang giao."
            else:
                de = "Nhắc khách chuyển khoản hoặc kiểm tra xem khách đã trả bằng cách khác chưa."
                them = ""
            ex("don_chua_thu", "", [c],
               f"Đơn CK {c} ({o['ten']}, {vnd(o['tong'])}, đặt {dm(o['date'])}, trạng thái {o['tt_goc']}) chưa có dòng sao kê nào trả tiền.{them}", de)
            don_chua_thu.append(c)

    cod_chua = [c for c, o in orders.items() if o["httt"] == "COD" and o["tt"] in ("da giao", "dang giao") and c not in cod_da_ghep and c not in cod_mo_ho]
    if cod_chua:
        tong_cod = sum(orders[c]["tong"] for c in cod_chua)
        ex("cod_chua_doi_soat", "", cod_chua,
           f"{len(cod_chua)} đơn COD (tổng {vnd(tong_cod)}) chưa nằm trong đợt đối soát COD nào của hãng vận chuyển (chưa tính các đơn thuộc đợt COD chưa chốt được).",
           "Theo dõi đợt đối soát COD kỳ sau; không cần tiền chuyển khoản trực tiếp.")

    # -------- tổng kiểm --------
    so_du_dau = info["so_du_dau"]
    tong_co = sum(t["co"] for t in txs)
    tong_no = sum(t["no"] for t in txs)
    so_du_cuoi = so_du_dau + tong_co - tong_no
    chay = so_du_dau
    sai_so_du = []
    for t in txs:
        chay = chay + t["co"] - t["no"]
        if chay != t["so_du"]:
            sai_so_du.append(t["so_ct"])
    so_ct_trung = len(txs) - len({t["so_ct"] for t in txs})
    khop = (so_du_cuoi == info["so_du_cuoi"] and tong_co == info["tong_co"]
            and tong_no == info["tong_no"] and not sai_so_du and so_ct_trung == 0)
    theo_loai = {k: 0 for k in TAT_CA_LOAI}
    for t in txs:
        if t["co"]:
            theo_loai[ket_qua[t["so_ct"]]["loai"]] += t["co"]
    da_ghep = sum(theo_loai[k] for k in LOAI_DA_GHEP)
    chua_ghep = sum(v for k, v in theo_loai.items() if k not in LOAI_DA_GHEP)
    assert da_ghep + chua_ghep == tong_co, "tổng ghi có theo loại không khớp tổng ghi có"
    tong_kiem = {
        "so_dong": len(txs),
        "so_du_dau": so_du_dau,
        "tong_ghi_co": tong_co,
        "tong_ghi_no": tong_no,
        "so_du_cuoi": so_du_cuoi,
        "kiem_so_du_khop": khop,
        "tong_co_theo_loai": theo_loai,
        "tong_co_da_ghep_don": da_ghep,
        "tong_co_chua_ghep_hoac_can_nguoi_quyet": chua_ghep,
        "doi_chieu_dong_tong_sao_ke": {
            "so_du_cuoi_tren_sao_ke": info["so_du_cuoi"],
            "tong_co_tren_sao_ke": info["tong_co"],
            "tong_no_tren_sao_ke": info["tong_no"],
            "so_dong_sai_so_du_luy_ke": sai_so_du,
            "so_ct_bi_trung": so_ct_trung,
        },
        "ghi_chu": "da_ghep = loai khop_du/thieu/thua/trung/nhieu_don; chua_ghep = phan con lai cua tong ghi co "
                   "(cod_gop, phi_lai_ngan_hang, khong_ro_nguon gom ca cac dong CAN NGUOI QUYET). Hai so cong lai bang tong_ghi_co.",
    }

    # -------- ghi file --------
    rows = [ket_qua[t["so_ct"]] for t in txs]
    assert len(rows) == len(txs)
    with open(BASE / "bang_ghep.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["so_ct", "ngay", "chieu", "so_tien", "ma_don", "phan_bo",
                                          "loai", "muc_chac_chan", "ly_do"])
        w.writeheader()
        w.writerows(rows)
    thu_tu = {"can_nguoi_quyet": 0, "khong_ro_nguon": 1, "ten_khac_khach": 2, "chuyen_thieu": 3, "chuyen_thua": 4,
              "chuyen_trung": 5, "hoan_tien_mot_phan": 6, "don_chua_thu": 7, "cod_chua_doi_soat": 8}
    ngoai_le.sort(key=lambda e: thu_tu.get(e["loai_ngoai_le"], 99))
    with open(BASE / "ngoai_le.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["loai_ngoai_le", "so_ct", "ma_don", "mo_ta", "de_xuat"])
        w.writeheader()
        w.writerows(ngoai_le)
    with open(BASE / "tong_kiem.json", "w", encoding="utf-8") as f:
        json.dump(tong_kiem, f, ensure_ascii=False, indent=2)

    # -------- báo cáo (số liệu lấy từ code) --------
    def dem(loai=None, muc=None, chieu=None):
        return [r for r in rows if (loai is None or r["loai"] == loai) and (muc is None or r["muc_chac_chan"] == muc)
                and (chieu is None or r["chieu"] == chieu)]

    co_rows = [r for r in rows if r["chieu"] == "co"]
    n_cao = len([r for r in co_rows if r["muc_chac_chan"] == CAO])
    n_tb = len([r for r in co_rows if r["muc_chac_chan"] == TB])
    cnq_rows = [r for r in co_rows if r["muc_chac_chan"] == CNQ]
    n_cnq = len(cnq_rows)
    tien_cnq = sum(r["so_tien"] for r in cnq_rows)
    k = lambda kieu: len([r for r in cnq_rows if kieu_cnq.get(r["so_ct"]) == kieu])
    cod_ok = [r for r in rows if r["loai"] == "cod_gop" and r["muc_chac_chan"] != CNQ]
    tien_cod_ok = sum(r["so_tien"] for r in cod_ok)
    ten_tb = len([r for r in co_rows if r["loai"] == "khop_du" and r["muc_chac_chan"] == TB and "Không có mã đơn" in r["ly_do"]])
    sdt_khac = sorted({o["ten"] for o in orders.values()
                       if len({x["sdt"] for x in orders.values() if x["ten"] == o["ten"]}) > 1})
    chua_dang_giao = [c for c in don_chua_thu if orders[c]["tt"] == "dang giao"]

    def tien_loai(loai):
        return sum(r["so_tien"] for r in dem(loai))

    bc = [
        "# Báo cáo đối soát sao kê T10/2026",
        f"- Tổng kiểm: {len(txs)} dòng; dư đầu {vnd(so_du_dau)} + có {vnd(tong_co)} − nợ {vnd(tong_no)} = dư cuối {vnd(so_du_cuoi)}; "
        f"khớp dòng tổng và số dư lũy kế từng dòng: {'ĐÚNG' if khop else 'SAI'}.",
        f"- Tiền vào {vnd(tong_co)}: ghép đơn CK {vnd(da_ghep)}; COD gộp chốt được {vnd(tien_cod_ok)}; lãi ngân hàng {vnd(theo_loai['phi_lai_ngan_hang'])}; "
        f"còn lại {vnd(tien_cnq)} ({n_cnq} dòng) cần người quyết.",
        f"- {len(co_rows)} dòng ghi có: CAO {n_cao}, TRUNG BINH {n_tb}, CAN NGUOI QUYET {n_cnq}. CAO chỉ dùng khi mã đơn và số tiền cùng khớp.",
        f"- Cần người quyết {n_cnq} dòng: {k('sai_ma')} dòng ghi sai mã đơn (tên + tiền khớp đơn khác), {k('cod')} đợt COD có 2 tổ hợp đơn, "
        f"{k('khac')} dòng tiền không rõ nguồn (1 dòng trong đó có đơn ứng viên đặt sau ngày chuyển).",
        f"- Chuyển thiếu {len(dem('thieu'))} dòng ({vnd(tien_loai('thieu'))} đã nhận), thừa {len(dem('thua'))} dòng, "
        f"trùng {len(dem('trung'))} dòng ({vnd(tien_loai('trung'))} cần hoàn/đối trừ); số thiếu/thừa từng đơn nằm trong ngoai_le.csv.",
        f"- Đơn CK chưa thu: {len(don_chua_thu)} đơn, trong đó {len(chua_dang_giao)} đơn đang giao; còn {len(cod_chua)} đơn COD chưa vào đợt đối soát nào.",
        f"- Hoàn tiền {len(dem('hoan_tien'))} dòng (1 dòng hoàn một phần, shop giữ phí ship); chi không gắn đơn {len(dem('chi_khac'))} dòng; phí/lãi ngân hàng {len(dem('phi_lai_ngan_hang'))} dòng.",
        f"- Không chắc 1: {ten_tb} dòng ghép chỉ theo tên viết tắt + số tiền (không có mã), mức TRUNG BINH, nên liếc lại.",
        f"- Không chắc 2: COD gộp ghép bằng tổ hợp số tiền vì không có bảng kê hãng vận chuyển; đợt 1 có {cod_chon[0][2]} tổ hợp, đợt 2 có {cod_chon[1][2]} tổ hợp.",
        f"- Không chắc 3: khách trùng tên khác SĐT ({', '.join(sdt_khac) or 'không có'}) được ghép theo thứ tự ngày; dòng 'trùng' cũng xác định theo thứ tự ngày.",
        "- Quy ước: phan_bo ghi toàn bộ số tiền của dòng (kể cả dòng thừa/thiếu/trùng); phần chênh nằm ở ngoai_le.csv.",
        "- CSV ghi UTF-8 không BOM; mở bằng Excel bị lỗi dấu thì dùng Data > From Text/CSV, chọn UTF-8.",
    ]
    assert len(bc) <= 15
    with open(BASE / "bao_cao.md", "w", encoding="utf-8") as f:
        f.write("\n".join(bc) + "\n")

    # -------- diagnostics ra màn hình --------
    print("Cảnh báo sổ đơn:", canh_bao_so_don or "không có")
    print("COD (so_ct, số đơn ứng viên, số tổ hợp):", cod_chon)
    print("so_dong", len(txs), "khop_so_du", khop, "sai_so_du", sai_so_du)
    print("theo loai:", theo_loai)
    print("da_ghep", da_ghep, "chua_ghep", chua_ghep)


if __name__ == "__main__":
    main()
