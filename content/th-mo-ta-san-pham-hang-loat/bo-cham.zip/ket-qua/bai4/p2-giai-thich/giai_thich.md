# Giải thích kiem.py

Script đối chiếu file nhập hàng với `thong_so.csv`, rồi in lỗi.

## 1. Script kiểm gì
- Số dòng: file có 39 sản phẩm thì báo "cần 40".
- Độ dài: tiêu đề 120 ký tự thì báo (cần 25–100); mô tả, gạch, từ khóa cũng có giới hạn.
- Từ cấm: nội dung có từ trong danh sách cấm, kể cả không dấu, thì báo.
- Con số: mô tả ghi "50" mà bảng sản phẩm không có số 50 thì báo.
- Trạng thái: bảng thiếu hạn dùng mà dòng ghi SAN_SANG thì báo.
- Giá trị thật: bảng có xuất xứ mà mô tả không chép đúng chữ đó thì báo.
- Giá trị thiếu: nội dung chép "chưa rõ" thì báo.
- Phiếu công bố: nói "đã công bố" mà bảng không có số phiếu thì báo.
- Rò ghi chú nội bộ: nội dung có "vip" thì báo.
- Giọng shop: tiêu đề không mở đầu "Vườn Nhỏ" thì báo.
- CSV và XLSX: hai file khác một ô thì báo.

## 2. Script KHÔNG kiểm
- Chính tả, câu văn lủng củng.
- Số đúng nhưng sai chỗ: "hạn dùng 50 tháng" vẫn qua nếu dung tích là 50.
- Số viết bằng chữ ("năm mươi").
- Lời khoe, thành phần bịa bằng chữ, nếu không nằm trong danh sách cấm.
- Ghi chú nội bộ diễn đạt khác đi.
- `thong_so.csv` tự sai.
- `quy_dinh_shop.md`: được nhắc tới, nhưng code không mở.

## 3. Danh sách người viết tự đặt
- `tu_cam.txt`: file riêng (dòng 26, 238); nội dung tôi chưa xem.
- `LEAK_TERMS`, dòng 35–38: 17 cụm.
- Dòng 30, 34, 162, 211: cụm "thiếu", chữ HOA được phép, cụm cấm giọng ("quý khách"...).
