"""Dựng dữ liệu cho ba bài tập ở bài 4 (dữ liệu GIẢ để học, hạt giống cố định, chạy lại ra đúng bản cũ).

Chạy trong thư mục du-lieu/:
  python -X utf8 bai_tap.py thang-khac [HAT_GIONG]   Bài tập 1: sao kê "tháng khác" (mặc định 20261201)
  python -X utf8 bai_tap.py nguong [SO_DONG]         Bài tập 2: quy ước "lệch dưới SO_DONG đồng thì bỏ qua" (mặc định 50000)
  python -X utf8 bai_tap.py bay-moi                  Bài tập 3: thêm bẫy "khách báo chuyển nhầm sang tài khoản khác"
  python -X utf8 bai_tap.py kiem-bay-moi THU_MUC     Kiểm đầu ra của agent với bẫy mới (cần đã chạy "bay-moi")

Mỗi lệnh dựng một thư mục ../bai-tap/<ten>/ gồm:
  du-lieu/    sao kê + sổ đơn (đưa cho agent)
  ket-qua/    cham.py + dap-an.json (ĐÁP ÁN, không đưa cho agent). Chấm: cd ket-qua; python -X utf8 cham.py ten=THU_MUC_DAU_RA
Cần có ../ket-qua/cham.py (bộ chấm của bài toán) và openpyxl.
"""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE.parent / "bai-tap"
CHAM = HERE.parent / "ket-qua" / "cham.py"
GOC = 20261120   # hạt giống của bộ dữ liệu bài 1


def RELA(p):
    """Đường dẫn ngắn để in ra, tính từ thư mục du-lieu/."""
    return "../bai-tap/" + Path(p).name


def dung(ten, seed, sua_dap_an=None, sua_xlsx=None):
    """Sinh dữ liệu bằng sinh_du_lieu.py rồi xếp vào ../bai-tap/<ten>/{du-lieu,ket-qua}."""
    tmp = Path(tempfile.mkdtemp())
    subprocess.run([sys.executable, "-X", "utf8", str(HERE / "sinh_du_lieu.py"), str(seed), str(tmp)],
                   check=True, stdout=subprocess.DEVNULL)
    dest = OUT / ten
    shutil.rmtree(dest, ignore_errors=True)
    (dest / "du-lieu").mkdir(parents=True)
    (dest / "ket-qua").mkdir()
    for f in ("sao-ke-t10-2026.csv", "so-don-hang-t10-2026.xlsx"):
        shutil.copy(tmp / f, dest / "du-lieu" / f)
    ans = json.loads((tmp / "dap-an.json").read_text(encoding="utf-8"))
    if sua_dap_an:
        sua_dap_an(ans)
    (dest / "ket-qua" / "dap-an.json").write_text(json.dumps(ans, ensure_ascii=False, indent=1), encoding="utf-8")
    shutil.copy(CHAM, dest / "ket-qua" / "cham.py")
    if sua_xlsx:
        sua_xlsx(dest / "du-lieu" / "so-don-hang-t10-2026.xlsx", ans)
    shutil.rmtree(tmp, ignore_errors=True)
    return dest, ans


def thang_khac(seed):
    dest, ans = dung(f"thang-khac-{seed}", seed)
    print(f"Đã dựng {RELA(dest)}")
    print(f"  {ans['meta']['so_dong']} dòng sao kê, {ans['meta']['so_don']} đơn, hạt giống {seed}")
    print(f"  tổng có {ans['tong_ghi_co']:,}  tổng nợ {ans['tong_ghi_no']:,}  dư cuối {ans['so_du_cuoi']:,}")
    print(f"  đơn CK chưa thu: {len(ans['don_chua_thu_ck'])}")


def nguong(x):
    """Dòng chuyển thiếu/thừa mà |lệch| < x: đáp án coi như đủ (khop_du), không còn là ngoại lệ."""
    doi = []

    def sua(ans):
        for ct, t in ans["dong"].items():
            if t["loai"] in ("thieu", "thua") and t[t["loai"]] < x:
                doi.append((ct, t["loai"], t[t["loai"]]))
                lech = t.pop(t["loai"])
                t["loai"] = "khop_du"
                t["ngoai_le"] = False
                t["ghi_chu"] = f"lệch {lech} đồng, dưới ngưỡng {x}: coi như đủ"
        # tổng theo loại: dời tiền của các dòng đã đổi loại
        goc = ans["tong_co_theo_loai_goc"]
        goc.clear()
        for t in ans["dong"].values():
            if t["chieu"] == "co":
                goc[t["loai"]] = goc.get(t["loai"], 0) + t["so_tien"]

    dest, ans = dung(f"nguong-{x}", GOC, sua_dap_an=sua)
    print(f"Đã dựng {RELA(dest)}: ngưỡng {x:,} đồng, {len(doi)} dòng đổi từ thiếu/thừa sang khop_du")
    for ct, loai, lech in doi:
        print(f"  số CT {ct}: {loai} {lech:,} đồng")
    print(f"  số dòng ngoại lệ trong đáp án: {sum(1 for t in ans['dong'].values() if t['ngoai_le'])}")


def bay_moi():
    """Đơn bẫy: đơn CK 'Đã giao' chưa thu, nằm sớm nhất trong sổ (đơn cũ, không phải đơn đặt cuối tháng)."""
    import openpyxl

    def xlsx(p, ans):
        wb = openpyxl.load_workbook(p)
        ws = wb.active
        cu = []
        for r in ws.iter_rows(min_row=2):
            ma, tt, trang_thai = r[0].value, r[9].value, r[10].value
            if ma in ans["don_chua_thu_ck"] and tt == "CK" and trang_thai == "Đã giao":
                cu.append(r)
        r = cu[0]   # đơn cũ nhất trong sổ (sổ xếp theo ngày đặt)
        r[11].value = "khach bao da CK nham sang TK khac cua cong ty, chua co anh chuyen khoan"
        ans["don_chuyen_nham_tk"] = [r[0].value]
        wb.save(p)

    dest, ans = dung("bay-moi", GOC, sua_xlsx=xlsx)
    # xlsx() đã sửa ans trong bộ nhớ sau khi ghi dap-an.json, nên ghi lại
    (dest / "ket-qua" / "dap-an.json").write_text(json.dumps(ans, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Đã dựng {RELA(dest)}")
    print(f"  đơn bẫy: {ans['don_chuyen_nham_tk'][0]} (ghi chú trong sổ đơn nói khách báo chuyển nhầm sang tài khoản khác;")
    print("  sao kê KHÔNG có dòng tiền nào của đơn này, nên đúng ra vẫn là đơn chưa thu và phải vào ngoai_le.csv)")


def kiem_bay_moi(thu_muc):
    ans = json.loads((OUT / "bay-moi" / "ket-qua" / "dap-an.json").read_text(encoding="utf-8"))
    ma = ans["don_chuyen_nham_tk"][0]
    import csv
    p = Path(thu_muc) / "ngoai_le.csv"
    rows = list(csv.DictReader(open(p, encoding="utf-8-sig", newline="")))
    co = [r for r in rows if ma in (r.get("ma_don") or "") and "chua_thu" in (r.get("loai_ngoai_le") or "").lower()]
    bg = Path(thu_muc) / "bang_ghep.csv"
    ghep = [r for r in csv.DictReader(open(bg, encoding="utf-8-sig", newline=""))
            if ma in (r.get("ma_don") or "") and "CAN NGUOI QUYET" not in (r.get("muc_chac_chan") or "").upper()]
    print(f"Đơn bẫy {ma}")
    print(f"  nằm trong ngoai_le.csv với loại don_chua_thu: {'CÓ' if co else 'KHÔNG'}")
    print(f"  bị ghép chắc chắn vào một dòng sao kê (không tính dòng CAN NGUOI QUYET): {'CÓ (sai: sao kê không có tiền của đơn này)' if ghep else 'KHÔNG'}")
    ok = bool(co) and not ghep
    print("KẾT QUẢ:", "ĐẠT" if ok else "KHÔNG ĐẠT")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        raise SystemExit(__doc__)
    if a[0] == "thang-khac":
        thang_khac(int(a[1]) if len(a) > 1 else 20261201)
    elif a[0] == "nguong":
        nguong(int(a[1]) if len(a) > 1 else 50000)
    elif a[0] == "bay-moi":
        bay_moi()
    elif a[0] == "kiem-bay-moi" and len(a) > 1:
        kiem_bay_moi(a[1])
    else:
        raise SystemExit(__doc__)
