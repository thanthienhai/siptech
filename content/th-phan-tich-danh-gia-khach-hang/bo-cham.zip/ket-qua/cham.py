"""Chấm kết quả phân tích đánh giá của agent bằng đáp án (dap-an.json). Mọi con số do code tính.

Dùng:
  python -X utf8 cham.py <nhan>=<thu_muc_dau_ra> [<nhan>=<thu_muc_dau_ra> ...] [--out bao-cao-cham.json]
Ví dụ:
  python -X utf8 cham.py claude-lan1=claude-lan1/dau-ra agy-lan1=agy-lan1/dau-ra

Đường dẫn <thu_muc_dau_ra> tính từ thư mục chứa cham.py (ket-qua/). danh-gia.csv lấy từ ../du-lieu/.
Ghi chú chấm (đọc kỹ trước khi diễn giải):
  * Chủ đề/sắc thái chấm theo cặp (mã bài, chủ đề). Chủ đề "khac" không bị phạt. Đáp án 'a|b' = chấp nhận a hoặc b.
  * Bài mỉa mai: đáp án yêu cầu agent xếp CAN_NGUOI_DOC; bài mơ hồ (mo_ho), ca nguy cấp ranh giới hoặc 'nghi', bài đáng loại bỏ: xếp CAN_NGUOI_DOC không bị tính là 'xếp thừa' ở mục mỉa mai (bài đáng loại bỏ vẫn bị tính ở mục loại bỏ).
  * Sắc thái: một ý tính là đúng nếu CÓ ÍT NHẤT MỘT dòng của agent cùng (bài, chủ đề) mang sắc thái đúng; dòng thừa không bị phạt (nên con số này lạc quan, xem độ lệch số đếm tuần).
  * Trích dẫn: so khớp chuỗi con NGUYÊN VĂN (chỉ chuẩn hóa Unicode NFC, không chuẩn hóa khoảng trắng).
"""
import csv, json, re, sys, unicodedata, subprocess, shutil, tempfile, datetime as dt
from collections import Counter, defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
GOLD = json.loads((HERE / "dap-an.json").read_text(encoding="utf-8"))
G = {r["ma"]: r for r in GOLD["reviews"]}
DG = {r["ma"]: r for r in csv.DictReader(open(HERE.parent / "du-lieu" / "danh-gia.csv", encoding="utf-8"))}
TOPICS = ["gia", "phuc_vu", "chat_luong", "giao_hang", "khong_gian", "ve_sinh"]
SENTS = ["tich_cuc", "tieu_cuc", "trung_tinh"]
nfc = lambda s: unicodedata.normalize("NFC", s or "")

def read_csv(p, cols):
    p = Path(p)
    if not p.exists(): return None, f"thiếu file {p.name}"
    try:
        rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
    except Exception as e:
        return None, f"lỗi đọc {p.name}: {e}"
    if rows and not set(cols) <= set(rows[0].keys()):
        return rows, f"{p.name}: thiếu cột {sorted(set(cols) - set(rows[0].keys()))}; có {list(rows[0].keys())}"
    return rows, None

def norm_sent(s):
    s = (s or "").strip()
    return "CAN_NGUOI_DOC" if s.upper() == "CAN_NGUOI_DOC" else s.lower()

def ok(q, ma): return bool(q) and ma in DG and nfc(q) in nfc(DG[ma]["noi_dung"])

def f1(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0; r = tp / (tp + fn) if tp + fn else 0.0
    return {"tp": tp, "fp": fp, "fn": fn, "precision": round(p, 3), "recall": round(r, 3), "f1": round(2 * p * r / (p + r), 3) if p + r else 0.0}

def gold_table():
    t = defaultdict(Counter)
    for g in GOLD["reviews"]:
        if g["loai_bo"]: continue
        for a in g["aspects"]:
            k = (g["tuan"], a["chu_de"].split("|")[0])
            t[k]["can_nguoi_doc" if g["mia_mai"] else a["sac_thai"]] += 1
    return t

def table_from_labels(yk, loai):
    """Đếm lại từ nhãn của chính agent, dùng tuần ĐÚNG (từ đáp án). Dùng để tách lỗi ngày/đếm khỏi lỗi gán nhãn."""
    t = defaultdict(Counter)
    for r in yk:
        ma = r["ma"].strip()
        if ma in loai or ma not in G: continue
        s = norm_sent(r["sac_thai"]); c = r["chu_de"].strip().lower()
        t[(G[ma]["tuan"], c)]["can_nguoi_doc" if s == "CAN_NGUOI_DOC" else s] += 1
    return t

def cham(label, d):
    d = HERE / d; rep = {"nhan": label, "thu_muc": str(d.relative_to(HERE)), "loi": []}
    lb, e = read_csv(d / "loai-bo.csv", ["ma", "ly_do"]); e and rep["loi"].append(e)
    yk, e = read_csv(d / "y-kien.csv", ["ma", "chu_de", "sac_thai", "trich_dan"]); e and rep["loi"].append(e)
    nc, e = read_csv(d / "nguy-cap.csv", ["ma", "loai", "trich_dan"]); e and rep["loi"].append(e)
    xh, e = read_csv(d / "xu-huong-tuan.csv", ["tuan", "chu_de", "tich_cuc", "tieu_cuc", "trung_tinh"]); e and rep["loi"].append(e)
    bc_path = d / "bao-cao.md"; bc = bc_path.read_text(encoding="utf-8") if bc_path.exists() else None
    if bc is None: rep["loi"].append("thiếu bao-cao.md")
    for f in ("tong-hop.py", "kiem-tra-trich-dan.py"):
        if not (d / f).exists(): rep["loi"].append(f"thiếu {f}")
    lb = lb or []; yk = yk or []; nc = nc or []; xh = xh or []
    # ---- 1. loại bỏ
    gold_lb = {m: g["loai_bo"] for m, g in G.items() if g["loai_bo"]}
    ag_lb = {r["ma"].strip(): r for r in lb}
    tp = [m for m in ag_lb if m in gold_lb]; fp = [m for m in ag_lb if m not in gold_lb]; fn = [m for m in gold_lb if m not in ag_lb]
    ly_do_dung = sum(1 for m in tp if ag_lb[m]["ly_do"].strip() == gold_lb[m]["ly_do"])
    goc_dung = sum(1 for m in tp if gold_lb[m]["ly_do"] == "trung_lap" and (ag_lb[m].get("ma_goc") or "").strip() == gold_lb[m]["ma_goc"])
    rep["loai_bo"] = {**f1(len(tp), len(fp), len(fn)), "gold": len(gold_lb), "ly_do_dung": ly_do_dung,
                      "ma_goc_dung": goc_dung, "ma_goc_can": sum(1 for v in gold_lb.values() if v["ly_do"] == "trung_lap"),
                      "bo_nham_bai_that": fp, "bo_sot": fn}
    # ---- 2. chủ đề + sắc thái
    pairs = defaultdict(list)  # (ma) -> list (chu_de, sac_thai)
    for r in yk:
        pairs[r["ma"].strip()].append((r["chu_de"].strip().lower(), norm_sent(r["sac_thai"])))
    unknown_ma = [m for m in pairs if m not in G]
    cho_bai_loai = [m for m in pairs if m in gold_lb]
    tp = fp = fn = 0; fp_list = []; fn_list = []
    s_ok = s_bad = s_def = 0; sent_bad = []; conf = Counter(); gold_sent_total = Counter()
    for m, g in G.items():
        if g["loai_bo"] or g["mo_ho"]: continue
        ag = pairs.get(m, [])
        ag_topics = {c for c, _ in ag if c != "khac"}
        gold_groups = {}
        for a in g["aspects"]:
            gold_groups.setdefault(a["chu_de"], []).append(a["sac_thai"])
        covered = set()
        for gk, sents in gold_groups.items():
            alts = gk.split("|")
            hit = [c for c in alts if c in ag_topics]
            if not hit: fn += 1; fn_list.append((m, gk)); continue
            tp += 1; covered.add(hit[0])
            if g["mia_mai"]: continue  # bài mỉa mai chấm ở mục riêng
            agsents = [s for c, s in ag if c in alts]
            gold_sent_total[tuple(sorted(set(sents)))] += 1
            if all(s == "CAN_NGUOI_DOC" for s in agsents): s_def += 1; continue
            if any(s in sents for s in agsents): s_ok += 1; conf[(sents[0], [s for s in agsents if s in sents][0])] += 1
            else:
                s_bad += 1; conf[(sents[0], agsents[0])] += 1; sent_bad.append((m, gk, sents, agsents))
        alts_union = {c for gk in gold_groups for c in gk.split("|")}
        for c in ag_topics - alts_union:
            fp += 1; fp_list.append((m, c))
    rep["chu_de"] = {**f1(tp, fp, fn), "chu_de_thua_vi_du": fp_list[:12], "chu_de_sot_vi_du": fn_list[:12]}
    tot = s_ok + s_bad
    rep["sac_thai"] = {"dung": s_ok, "sai": s_bad, "hoan_CAN_NGUOI_DOC": s_def,
                       "chinh_xac_tren_cac_y_da_gan_nhan": round(s_ok / tot, 3) if tot else None,
                       "chinh_xac_neu_hoan_tinh_la_sai": round(s_ok / (tot + s_def), 3) if tot + s_def else None,
                       "ma_tran_dap_an_x_agent": {f"{a}->{b}": n for (a, b), n in sorted(conf.items())},
                       "sai_vi_du": [[m, gk, g_, a_] for m, gk, g_, a_ in sent_bad[:12]]}
    rep["y_kien_ma_la_hoac_bai_phai_loai"] = {"ma_khong_co_trong_du_lieu": unknown_ma, "y_kien_cho_bai_phai_loai": cho_bai_loai}
    # ---- 3. mỉa mai
    mia = [m for m, g in G.items() if g["mia_mai"]]
    flagged = {m for m, v in pairs.items() if any(s == "CAN_NGUOI_DOC" for _, s in v)}
    tp_m = [m for m in mia if m in flagged]; fn_m = [m for m in mia if m not in flagged]
    def _khong_phat(m):
        g = G.get(m, {}); return g.get("mia_mai") or g.get("mo_ho") or g.get("loai_bo") or (g.get("nguy_cap") or {}).get("muc") in ("ranh_gioi", "nghi")
    fp_m = [m for m in flagged if not _khong_phat(m)]
    fn_detail = {m: sorted({s for _, s in pairs.get(m, [])}) + (["(bị loại bỏ)"] if m in ag_lb else []) for m in fn_m}
    rep["mia_mai"] = {**f1(len(tp_m), len(fp_m), len(fn_m)), "gold": len(mia), "bo_sot_agent_gan_nhan": fn_detail,
                      "bi_lo_bang_khen": [m for m in fn_m if "tich_cuc" in fn_detail[m]],
                      "xep_CAN_NGUOI_DOC_thua": [{"ma": m, "bay_tu_khoa": G[m]["bay_tu_khoa"] if m in G else None, "noi_dung": DG[m]["noi_dung"][:90]} for m in fp_m],
                      "mo_ho_duoc_xep_CAN_NGUOI_DOC": [m for m in flagged if G.get(m, {}).get("mo_ho")],
                      "ranh_gioi_hoac_nghi_duoc_xep_CAN_NGUOI_DOC_khong_phat": [m for m in flagged if (G.get(m, {}).get("nguy_cap") or {}).get("muc") in ("ranh_gioi", "nghi")],
                      "bai_phai_loai_nhung_xep_CAN_NGUOI_DOC_khong_phat_o_day": [m for m in flagged if G.get(m, {}).get("loai_bo")]}
    # ---- 4. nguy cấp
    ag_nc = defaultdict(list)
    for r in nc: ag_nc[r["ma"].strip()].append(r)
    must = {m: g["nguy_cap"] for m, g in G.items() if g["nguy_cap"] and g["nguy_cap"]["muc"] in ("chac", "nghi")}
    edge = {m for m, g in G.items() if g["nguy_cap"] and g["nguy_cap"]["muc"] == "ranh_gioi"}
    tp_c = [m for m in must if m in ag_nc]; fn_c = [m for m in must if m not in ag_nc]
    fp_c = [m for m in ag_nc if m not in must and m not in edge]
    dung_loai = sum(1 for m in tp_c if any(r["loai"].strip() == must[m]["loai"] for r in ag_nc[m]))
    per_type = {}
    for t in ("ngo_doc", "thai_do", "lua_dao"):
        gm = [m for m, v in must.items() if v["loai"] == t]
        per_type[t] = {"gold": len(gm), "bat_duoc": sum(1 for m in gm if m in ag_nc), "dung_loai": sum(1 for m in gm if any(r["loai"].strip() == t for r in ag_nc.get(m, [])))}
    rep["nguy_cap"] = {**f1(len(tp_c), len(fp_c), len(fn_c)), "dung_loai_trong_so_bat_duoc": dung_loai, "theo_loai": per_type, "bo_sot": fn_c,
                       "bao_thua": [{"ma": m, "bay_tu_khoa": G[m]["bay_tu_khoa"] if m in G else None, "noi_dung": DG[m]["noi_dung"][:90] if m in DG else None} for m in fp_c],
                       "ca_ranh_gioi_agent_bao": [m for m in edge if m in ag_nc],
                       "nghi_ghi_dung": sum(1 for m, v in must.items() if v["muc"] == "nghi" and m in ag_nc and any("nghi" in (r.get("ly_do") or "").lower()[:12] for r in ag_nc[m]))}
    # ---- 5. xu hướng
    gt = gold_table()
    ag_tab = {}; parse_err = []
    for r in xh:
        try:
            ag_tab[(r["tuan"].strip(), r["chu_de"].strip().lower())] = {"tich_cuc": int(r["tich_cuc"]), "tieu_cuc": int(r["tieu_cuc"]), "trung_tinh": int(r["trung_tinh"]),
                                                                       "can_nguoi_doc": int(r.get("can_nguoi_doc") or 0)}
        except Exception: parse_err.append(r)
    cols = ["tich_cuc", "tieu_cuc", "trung_tinh", "can_nguoi_doc"]
    weeks = sorted({k[0] for k in gt})
    cells = [(w, t, c) for w in weeks for t in TOPICS for c in cols]
    absd = sum(abs(ag_tab.get((w, t), {}).get(c, 0) - gt.get((w, t), Counter()).get(c, 0)) for w, t, c in cells)
    gsum = sum(gt.get((w, t), Counter()).get(c, 0) for w, t, c in cells)
    exact = sum(1 for w, t, c in cells if ag_tab.get((w, t), {}).get(c, 0) == gt.get((w, t), Counter()).get(c, 0))
    own = table_from_labels(yk, ag_lb)
    own_cells = [(w, t, c) for w in weeks for t in TOPICS for c in cols]
    own_diff = sum(abs(ag_tab.get((w, t), {}).get(c, 0) - own.get((w, t), Counter()).get(c, 0)) for w, t, c in own_cells)
    own_bad = [(w, t, c, ag_tab.get((w, t), {}).get(c, 0), own.get((w, t), Counter()).get(c, 0)) for w, t, c in own_cells
               if ag_tab.get((w, t), {}).get(c, 0) != own.get((w, t), Counter()).get(c, 0)]
    tuan_la = sorted({k[0] for k in ag_tab} - set(weeks))
    gneg_tot = sum(gt.get((w, t), Counter())["tieu_cuc"] for w, t, c in [(w, t, "tieu_cuc") for w in weeks for t in TOPICS])
    rep["xu_huong"] = {"so_dong_agent": len(ag_tab), "dong_loi_dinh_dang": len(parse_err), "tuan_la_khong_co_trong_dap_an": tuan_la,
                       "tong_sai_lech_tuyet_doi_so_voi_dap_an": absd, "tong_so_dem_dap_an": gsum, "o_khop_chinh_xac": f"{exact}/{len(cells)}",
                       "sai_lech_so_voi_chinh_nhan_cua_agent_(tuan_dung)": own_diff, "o_lech_vi_du": own_bad[:10],
                       "tieu_cuc_dap_an_tong": gneg_tot}
    # tái lặp: chạy lại tong-hop.py của agent trên bản sao
    rep["tai_lap_tong_hop"] = rerun(d)
    # ---- 6. trích dẫn
    def chk_rows(rows, name):
        bad = []
        for r in rows:
            q = (r.get("trich_dan") or ""); m = r["ma"].strip()
            if not ok(q, m):
                other = [k for k, v in DG.items() if q and nfc(q) in nfc(v["noi_dung"])][:2]
                bad.append({"ma": m, "trich_dan": q[:100], "thuoc_bai_khac": other})
        return {"tong": len(rows), "khong_nguyen_van": len(bad), "vi_du": bad[:8]}
    rep["trich_dan_y_kien"] = chk_rows(yk, "y-kien"); rep["trich_dan_nguy_cap"] = chk_rows(nc, "nguy-cap")
    # ---- 7. báo cáo 5 việc
    if bc:
        quotes = re.findall(r'^\s*>\s*\[?(R\d{3})\]?\s*[:\-]?\s*["“«]?(.+?)["”»]?\s*$', bc, flags=re.M)
        qbad = [{"ma": m, "trich_dan": q[:100]} for m, q in quotes if not ok(q, m)]
        parts = re.split(r"^##\s*Việc\s*\d+", bc, flags=re.M)
        items = parts[1:]
        item_tags = []
        for it in items:
            ms = re.findall(r"^\s*>\s*\[?(R\d{3})", it, flags=re.M)
            tags = sorted({v for m in ms for v in G.get(m, {}).get("van_de", [])})
            item_tags.append({"ma": ms, "van_de_cai": tags, "tieu_de": it.strip().splitlines()[0][:90] if it.strip() else ""})
        covered = sorted({t for it in item_tags for t in it["van_de_cai"] if t in ("I1", "I2", "I3", "I4", "I5")})
        rep["bao_cao"] = {"so_muc_viec": len(items), "so_trich_dan": len(quotes), "trich_dan_khong_nguyen_van": len(qbad), "vi_du_sai": qbad[:8],
                          "van_de_cai_sao_duoc_phu": covered, "so_van_de_phu_tren_5": len(covered), "van_de_cai_sao_bi_thieu": sorted({"I1", "I2", "I3", "I4", "I5"} - set(covered)),
                          "cac_muc": item_tags}
    return rep

def rerun(d):
    """Chạy lại tong-hop.py trên bản sao; so với xu-huong-tuan.csv đã có. Chỉ đo 'chạy lại có ra cùng số không'."""
    src = d / "tong-hop.py"
    if not src.exists(): return {"chay_lai": "không có tong-hop.py"}
    tmp = Path(tempfile.mkdtemp(prefix="cham_"))
    try:
        shutil.copy(HERE.parent / "du-lieu" / "danh-gia.csv", tmp / "danh-gia.csv")
        (tmp / "dau-ra").mkdir()
        for f in d.iterdir():
            if f.is_file(): shutil.copy(f, tmp / "dau-ra" / f.name)
        before = (tmp / "dau-ra" / "xu-huong-tuan.csv").read_text(encoding="utf-8") if (tmp / "dau-ra" / "xu-huong-tuan.csv").exists() else ""
        (tmp / "dau-ra" / "xu-huong-tuan.csv").unlink(missing_ok=True)
        p = subprocess.run([sys.executable, "-X", "utf8", "dau-ra/tong-hop.py"], cwd=tmp, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
        out = tmp / "dau-ra" / "xu-huong-tuan.csv"
        if not out.exists():
            p2 = subprocess.run([sys.executable, "-X", "utf8", "tong-hop.py"], cwd=tmp / "dau-ra", capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120)
            return {"chay_lai": "không tạo lại được xu-huong-tuan.csv", "rc_tu_thu_muc_goc": p.returncode, "loi_goc": p.stderr[-200:], "rc_tu_dau_ra": p2.returncode}
        def norm(t): return sorted(l.strip() for l in t.splitlines() if l.strip())
        return {"chay_lai": "ra file", "rc": p.returncode, "giong_ban_cu_theo_dong": norm(before) == norm(out.read_text(encoding="utf-8"))}
    except Exception as e:
        return {"chay_lai": f"lỗi: {e}"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

if __name__ == "__main__":
    args = sys.argv[1:]; out = "bao-cao-cham.json"
    if "--out" in args:
        i = args.index("--out"); out = args[i + 1]; del args[i:i + 2]
    res = {}
    for a in args:
        label, d = a.split("=", 1)
        res[label] = cham(label, d)
    (HERE / out).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    for label, r in res.items():
        print("==", label, "lỗi:", r["loi"])
        for k in ("loai_bo", "chu_de", "sac_thai", "mia_mai", "nguy_cap"):
            v = r.get(k, {})
            print(" ", k, {x: v[x] for x in v if not isinstance(v[x], (list, dict))})
        print("  xu_huong", {x: r["xu_huong"][x] for x in ("tong_sai_lech_tuyet_doi_so_voi_dap_an", "tong_so_dem_dap_an", "o_khop_chinh_xac", "sai_lech_so_voi_chinh_nhan_cua_agent_(tuan_dung)")}, r["tai_lap_tong_hop"])
        print("  trich_dan", r["trich_dan_y_kien"]["khong_nguyen_van"], "/", r["trich_dan_y_kien"]["tong"], "|", r["trich_dan_nguy_cap"]["khong_nguyen_van"], "/", r["trich_dan_nguy_cap"]["tong"],
              "| bao_cao", {x: r["bao_cao"][x] for x in ("so_muc_viec", "so_trich_dan", "trich_dan_khong_nguyen_van", "van_de_cai_sao_duoc_phu")} if "bao_cao" in r else None)
