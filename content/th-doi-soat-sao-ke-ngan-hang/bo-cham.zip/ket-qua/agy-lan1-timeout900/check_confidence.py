import pandas as pd
import openpyxl, re, csv, unicodedata

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
df_orders['amount'] = df_orders['Tổng phải thu'].apply(clean_amount)
df_orders['kh_clean'] = df_orders['Khách hàng'].apply(strip_accents).str.upper()

# Let's inspect all non-explicit order matches
# Let's see:
# 1. 'don 003 HOANG KIM VY' -> code is 'don 003', amount 1,320,000. Customer in order is Hoang Minh Dat (note: 'khach bao CK sang nay').
# Is it CAO or TRUNG BINH?
# Prompt: 'Chỉ dùng CAO khi mã đơn và số tiền đều khớp rõ ràng.'
# Here code is 'don 003' and amount 1,320,000 matches DH2610-003.

# 2. 'B Q BINH thanh toan' -> no code! Name is B Q BINH, amount 1,550,000 matches DH2610-010.
# Prompt: 'khớp theo tên (không dấu/viết tắt) và số tiền khi không có mã.'
# Since there is NO order code, it CANNOT be CAO! It is TRUNG BINH!

# 3. 'T K QUYNH CK' -> no code! Name T K Quynh, amount 2,580,000 matches DH2610-030. TRUNG BINH!

# 4. 'CK mua hang LE NGOC THAO' -> no code! Le Ngoc Thao, amount 730,000 matches DH2610-038. TRUNG BINH!

# 5. 'D V PHUC thanh toan' -> no code! D V Phuc, amount 3,320,000 matches DH2610-059. TRUNG BINH!

# 6. 'CK mua hang VU AN' -> no code! Vu An, amount 240,000 matches DH2610-051. TRUNG BINH!

# 7. 'NGO DUNG chuyen tien mua hang' -> no code! Ngo Dung, amount 1,170,000 matches DH2610-070. TRUNG BINH!

# 8. 'TRAN VAN BINH CK' -> no code! Tran Van Binh, amount 920,000 matches DH2610-066. TRUNG BINH!

# 9. 'CK mua hang VU KHANH' -> no code! Vu Khanh, amount 2,580,000 matches DH2610-087. TRUNG BINH!

# 10. 'LE N THAO chuyen tien mua hang' -> no code! Le N Thao, amount 240,000 matches DH2610-099. TRUNG BINH!

# 11. 'TRAN VAN BINH chuyen tien mua hang' -> no code! Tran Van Binh, amount 920,000 matches DH2610-101. TRUNG BINH!

# 12. 'D V LONG CK' -> no code! D V Long, amount 140,000 matches DH2610-110. TRUNG BINH!

# 13. 'CK mua hang DO TRANG' -> no code! Do Trang, amount 140,000 matches DH2610-115. TRUNG BINH!

# 14. 'TRAN HUU DAT CK 2 don' -> no explicit codes! Tran Huu Dat, amount 1,350,000 matches DH2610-013 (900k) + DH2610-120 (450k). TRUNG BINH!

# 15. All 4 'thieu':
# DH2610-011 (110k vs 210k), DH2610-021 (430k vs 460k), DH2610-036 (260k vs 280k), DH2610-074 (2,480k vs 2,580k).
# 'Chỉ dùng CAO khi mã đơn và số tiền đều khớp rõ ràng.'
# Since amount does NOT match order amount, these are TRUNG BINH!

# 16. All 4 'thua':
# DH2610-005 (3,900k vs 3,700k), DH2610-023 (370k vs 360k), DH2610-016 (480k vs 280k), DH2610-113 (1,310k vs 1,290k).
# Since amount does NOT match order amount, these are TRUNG BINH!

print("Verified all TRUNG BINH cases!")
