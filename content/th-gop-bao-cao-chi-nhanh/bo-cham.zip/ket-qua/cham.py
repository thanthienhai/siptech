"""Chấm kết quả của agent bài 08 bằng đáp án (do code, không dùng mắt).

Dùng:
  python -X utf8 cham.py <thư_mục_run> <dap-an.json> <thư_mục_du_lieu_goc_ban_dau> [--ra ra] [--out bao-cao.json] [--rerun-thang 2026-10]

  <thư_mục_run>              thư mục agent đã làm việc (có goc/, ra/, gop.py)
  <thư_mục_du_lieu_goc_ban_dau>  thư mục du-lieu/thang-XX/goc ban đầu, để kiểm tra file gốc có bị sửa không
  --rerun-thang              chạy lại `python gop.py goc <ra_chấm> --thang ...` trong bản sao rồi chấm lại (kiểm script chạy lại được)
"""
import csv, json, sys, hashlib, re, shutil, subprocess, unicodedata, argparse, tempfile
from pathlib import Path

CODES = ["HN", "HP", "DN", "CT", "BH", "NT"]
NAMES = {"hanoi": "HN", "haiphong": "HP", "danang": "DN", "cantho": "CT", "bienhoa": "BH", "nhatrang": "NT"}


def noacc(s):
    s = unicodedata.normalize("NFD", str(s)).replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower().replace(" ", "")


def code_of(v):
    v = str(v).strip()
    if v.upper() in CODES: return v.upper()
    return NAMES.get(noacc(v), v)


def num(v):
    s = str(v).strip().replace(" ", "")
    if s == "" or s.lower() in ("nan", "none"): return None
    try: return float(s)
    except ValueError:
        t = re.sub(r"[^\d\-]", "", s)
        try: return float(t)
        except ValueError: return None


def read_csv(p):
    p = Path(p)
    if not p.exists(): return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def sha_dir(d):
    d = Path(d); return {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.glob("*")) if p.is_file()}


def cham(run, truth, orig_goc, ra="ra"):
    run = Path(run); T = json.loads(Path(truth).read_text(encoding="utf-8")); R = {}
    # 0. file gốc có bị sửa không
    o, n = sha_dir(orig_goc), sha_dir(run / "goc")
    R["file_goc"] = {"nguyen_ven": o == n, "thieu": sorted(set(o) - set(n)), "them": sorted(set(n) - set(o)),
                     "doi": sorted(k for k in o if k in n and o[k] != n[k])}
    # 1. hợp nhất
    hn = read_csv(run / ra / "hop_nhat.csv")
    R["co_hop_nhat"] = hn is not None
    conf = {(r["branch"], r["inv"]): r for r in T["rows"] if r["status"] in ("OK", "INFER")}
    ask = {(a["branch"], a["inv"]): a for a in T["ask_rows"]}
    oop = {(a["branch"], a["inv"]) for a in T["oop_rows"]}
    dupk = {(a["branch"], a["inv"]) for a in T["dup_rows"]}
    viec = read_csv(run / ra / "viec_can_hoi.csv") or []
    viec_txt = " ".join(" ".join(str(v) for v in r.values()) for r in viec)
    if hn:
        by = {}
        for r in hn: by.setdefault((code_of(r.get("chi_nhanh")), str(r.get("so_chung_tu")).strip()), []).append(r)
        R["so_dong_hop_nhat"] = len(hn)
        R["dong_trung_khoa_con_lai"] = sum(1 for k, v in by.items() if len(v) > 1)
        found = {k: v[0] for k, v in by.items() if k in conf and v[0].get("trang_thai", "").strip().upper() != "CAN_NGUOI_QUYET"}
        R["dong_dung_ky_vong"] = len(conf)
        R["tim_thay"] = len(found)
        R["bo_sot"] = sorted(f"{k[0]}:{k[1]}" for k in conf if k not in found and k not in {x for x in by if x in ask})
        R["bo_sot_vi_danh_CNQ"] = sorted(f"{k[0]}:{k[1]}" for k in conf if k in by and k not in found)
        R["dong_thua_khong_co_trong_dap_an"] = sorted(f"{k[0]}:{k[1]}" for k in by if k not in conf and k not in ask and k not in oop and k not in dupk)
        R["dong_ngoai_ky_lot_vao"] = sorted(f"{k[0]}:{k[1]}" for k in by if k in oop)
        fld = {"ngay": 0, "ma_san_pham": 0, "so_luong": 0, "don_gia": 0, "doanh_thu": 0}; allok = 0; wrong = []
        for k, v in found.items():
            t = conf[k]; ok = {}
            ok["ngay"] = str(v.get("ngay", "")).strip()[:10] == t["date"]
            ok["ma_san_pham"] = v.get("ma_san_pham", "").strip().upper().replace("-", "_") == t["prod"]
            ok["so_luong"] = num(v.get("so_luong")) == t["qty"]
            ok["don_gia"] = num(v.get("don_gia")) == t["price"]
            ok["doanh_thu"] = num(v.get("doanh_thu")) == t["amount"]
            for f, b in ok.items(): fld[f] += b
            if all(ok.values()): allok += 1
            else: wrong.append({"khoa": f"{k[0]}:{k[1]}", "sai": [f for f, b in ok.items() if not b],
                                "agent": {f: v.get(f) for f in ok}, "dap_an": {"ngay": t["date"], "ma_san_pham": t["prod"], "so_luong": t["qty"], "don_gia": t["price"], "doanh_thu": t["amount"]}})
        R["dong_dung_het_cac_truong"] = allok
        R["dung_theo_truong"] = fld
        R["dong_sai_chi_tiet"] = wrong[:40]
        # trạng thái SUY_RA cho 3 dòng BH đảo ngày
        inf = [k for k, t in conf.items() if t["status"] == "INFER"]
        R["dong_suy_ra_ky_vong"] = len(inf)
        R["dong_suy_ra_dung_ngay"] = sum(1 for k in inf if k in found and str(found[k].get("ngay", ""))[:10] == conf[k]["date"])
        R["dong_suy_ra_co_ghi_SUY_RA"] = sum(1 for k in inf if k in found and found[k].get("trang_thai", "").strip().upper() == "SUY_RA")
        # dòng mơ hồ
        res = []
        for k, a in ask.items():
            v = by.get(k, [None])[0]
            flagged = (k[1] in viec_txt)
            if v is None: kq = "khong_co_trong_hop_nhat" + ("_nhung_co_trong_viec_can_hoi" if flagged else "")
            elif v.get("trang_thai", "").strip().upper() == "CAN_NGUOI_QUYET": kq = "DUNG_CAN_NGUOI_QUYET" + ("" if flagged else "_nhung_khong_co_trong_viec_can_hoi")
            else: kq = ("tu_quyet_co_bao_trong_viec_can_hoi" if flagged else "DOAN_THAM") + f"(ngay={v.get('ngay')},{v.get('trang_thai')})"
            res.append({"khoa": f"{k[0]}:{k[1]}", "doc_theo_dd_mm": a["doc_ngay_theo_dd_mm"], "doc_theo_mm_dd": a["doc_ngay_theo_mm_dd"], "ket_qua": kq})
        R["dong_ngay_mo_ho"] = res
    # 2. tổng hợp chi nhánh
    th = read_csv(run / ra / "tong_hop_chi_nhanh.csv")
    if th:
        got = {code_of(r["chi_nhanh"]): num(r["doanh_thu"]) for r in th}
        R["tong_chi_nhanh"] = {c: {"agent": got.get(c), "dap_an": T["tong_chi_nhanh_xac_nhan"][c],
                                   "dung": got.get(c) == T["tong_chi_nhanh_xac_nhan"][c],
                                   "bang_so_neu_tinh_ca_mo_ho": got.get(c) == T["tong_chi_nhanh_neu_tinh_ca_mo_ho"][c] and T["tong_chi_nhanh_neu_tinh_ca_mo_ho"][c] != T["tong_chi_nhanh_xac_nhan"][c]}
                               for c in CODES}
        R["tong_chi_nhanh_dung"] = sum(v["dung"] for v in R["tong_chi_nhanh"].values())
        R["tong_cong_agent"] = sum(v for v in got.values() if v is not None); R["tong_cong_dap_an"] = T["tong_xac_nhan"]
    else: R["tong_chi_nhanh"] = None
    sp = read_csv(run / ra / "tong_hop_san_pham.csv")
    if sp:
        got = {r["ma_san_pham"].strip().upper(): num(r["doanh_thu"]) for r in sp}
        exp = T["tong_san_pham_xac_nhan"]
        R["tong_san_pham"] = {c: {"agent": got.get(c), "dap_an": v, "dung": got.get(c) == v} for c, v in exp.items()}
        R["tong_san_pham_dung"] = sum(x["dung"] for x in R["tong_san_pham"].values()); R["tong_san_pham_ky_vong"] = len(exp)
    cs = read_csv(run / ra / "tong_hop_chi_nhanh_san_pham.csv")
    if cs:
        got = {(code_of(r["chi_nhanh"]), r["ma_san_pham"].strip().upper()): num(r["doanh_thu"]) for r in cs}
        exp = {tuple(k.split("|")): v for k, v in T["tong_chi_nhanh_san_pham"].items()}
        R["o_chi_nhanh_san_pham_dung"] = sum(1 for k, v in exp.items() if got.get(k) == v); R["o_chi_nhanh_san_pham_ky_vong"] = len(exp)
    # 3. việc cần hỏi
    chk = {}
    chk["HP_ngay_mo_ho_3"] = sum(1 for a in ask if a[1] in viec_txt)
    chk["HP_trung_3"] = sum(1 for k in dupk if k[0] == "HP" and k[1] in viec_txt)
    chk["NT_trung_2"] = sum(1 for k in dupk if k[0] == "NT" and k[1] in viec_txt)
    chk["HP_ngoai_ky_4"] = sum(1 for k in oop if k[1] in viec_txt)
    unk = [k for k, t in conf.items() if "san_pham_la" in t["flags"]]
    chk["CT_san_pham_la_2"] = sum(1 for k in unk if k[1] in viec_txt)
    mis = [k for k, t in conf.items() if "lech_thanh_tien" in t["flags"]]
    chk["NT_lech_thanh_tien_2"] = sum(1 for k in mis if k[1] in viec_txt)
    miss = T["missing_days"].get("CT", [])
    chk["CT_thieu_tuan"] = int(any(code_of(r.get("chi_nhanh")) == "CT" and (r.get("loai", "").upper() == "THIEU_DU_LIEU" or "15" in r.get("mo_ta", "") and "21" in r.get("mo_ta", "")) for r in viec))
    chk["HN_sai_tong"] = int(any(code_of(r.get("chi_nhanh")) == "HN" and (r.get("loai", "").upper() == "SAI_TONG" or "100000" in r.get("mo_ta", "").replace(".", "").replace(",", "")) for r in viec))
    R["viec_can_hoi_bao_dung"] = chk; R["so_dong_viec_can_hoi"] = len(viec)
    # 4. kiểm tra
    kt = read_csv(run / ra / "kiem_tra.csv")
    if kt:
        res = {}
        for r in kt:
            c = code_of(r["chi_nhanh"]); f = T["files"].get(c)
            if not f: continue
            exp_diff = f["tong_file_ghi"] - T["tong_chi_nhanh_xac_nhan"][c]
            res[c] = {"tong_file_ghi_dung": num(r.get("tong_file_ghi")) == f["tong_file_ghi"],
                      "tong_dong_doc_duoc_dung": num(r.get("tong_dong_doc_duoc")) == f["tong_moi_dong_doc_duoc"],
                      "chenh_lech_dung": num(r.get("chenh_lech")) == exp_diff, "chenh_lech_dap_an": exp_diff,
                      "chenh_lech_agent": num(r.get("chenh_lech")), "giai_thich": (r.get("giai_thich") or "")[:300]}
        R["kiem_tra"] = res
    for fn in ("bao_cao.md",):
        R["co_" + fn] = (run / ra / fn).exists()
    R["co_gop_py"] = (run / "gop.py").exists()
    return R


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run"); ap.add_argument("truth"); ap.add_argument("orig_goc")
    ap.add_argument("--ra", default="ra"); ap.add_argument("--out"); ap.add_argument("--rerun-thang")
    a = ap.parse_args()
    R = {"chay": cham(a.run, a.truth, a.orig_goc, a.ra)}
    if a.rerun_thang:
        tmp = Path(tempfile.mkdtemp(prefix="rerun_"))
        shutil.copytree(a.run, tmp / "w", ignore=shutil.ignore_patterns("ra", "ra_chay_lai", "__pycache__"))
        p = subprocess.run([sys.executable, "-X", "utf8", "gop.py", "goc", "ra", "--thang", a.rerun_thang], cwd=tmp / "w", capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
        R["chay_lai"] = {"returncode": p.returncode, "stderr_tail": p.stderr[-500:], "stdout_tail": p.stdout[-300:]}
        if p.returncode == 0: R["chay_lai"]["cham"] = cham(tmp / "w", a.truth, a.orig_goc, "ra")
    s = json.dumps(R, ensure_ascii=False, indent=1)
    if a.out: Path(a.out).write_text(s, encoding="utf-8")
    print(s)


if __name__ == "__main__":
    main()
