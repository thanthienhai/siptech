"""Chấm đầu ra của agent bằng đáp án (dap-an.json). Không dùng AI để chấm số liệu.

Dùng:  python -X utf8 cham.py <tên_lần_chạy> <thư_mục_dau-ra> [--out bao-cao-cham.json]
Agent phải ghi, cho mỗi yêu cầu Rxx:  Rxx-bao-gia.xlsx, Rxx-email.txt, Rxx-cau-hoi.txt  (trong thư mục dau-ra).

Chấm gì:
 - dòng hàng: đúng mã + số lượng (theo ĐVT gốc) + đơn giá bậc + thành tiền; thiếu; sai giá trị; BỊA (có giá cho hàng không có/mã sai)
 - các tổng: tiền hàng, chiết khấu, phí giao, cộng trước VAT, VAT (theo tham số 10), tổng cộng
 - trạng thái SAN_SANG / THIEU_THONG_TIN / CAN_NGUOI_QUYET
 - từ khóa: câu hỏi làm rõ / ca CẦN NGƯỜI QUYẾT có được nêu trong email + câu hỏi + ghi chú (so khớp từ khóa đã bỏ dấu => chỉ là ước lượng,
   người chấm đọc lại bằng tay các ca khớp/không khớp)
 - cờ hứa ngày giao (tự động, chỉ là cờ để đọc tay)
"""
import json, re, sys, unicodedata
from pathlib import Path
from openpyxl import load_workbook

HERE = Path(__file__).resolve().parent
ANS = json.loads((HERE / "dap-an.json").read_text(encoding="utf-8"))
KEYS = ANS["meta"]["tu_khoa"]
TOTAL_LABELS = [("tien_hang", r"cong tien hang|tong tien hang|tien hang"), ("chiet_khau", r"^chiet khau"), ("phi_giao", r"phi giao|phi van chuyen|phi ship"),
                ("cong_truoc_vat", r"cong truoc vat|truoc vat|tong truoc thue"), ("vat", r"^vat|thue gtgt"), ("tong_cong", r"^tong cong|tong thanh toan|tong cong thanh toan")]

def fold(s):
    s = unicodedata.normalize("NFD", str(s).lower().replace("đ", "d"))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")

def num(v):
    if v is None: return None
    if isinstance(v, (int, float)): return float(v)
    s = re.sub(r"[^\d,.\-]", "", str(v))
    if not s: return None
    if re.fullmatch(r"-?\d{1,3}([.,]\d{3})+", s): s = re.sub(r"[.,]", "", s)
    else: s = s.replace(",", ".")
    try: return float(s)
    except ValueError: return None

def _template_texts():
    p = HERE.parent / "du-lieu" / "mau-bao-gia.xlsx"
    if not p.exists(): return set()
    wb = load_workbook(p)
    return {c.value for ws in wb.worksheets for r in ws.iter_rows() for c in r if isinstance(c.value, str)}
TEMPLATE_TEXTS = _template_texts()

def parse_xlsx(path):
    wb = load_workbook(path, data_only=True)
    ws = wb["Báo giá"] if "Báo giá" in wb.sheetnames else wb.worksheets[0]
    rows = [[c.value for c in r] for r in ws.iter_rows()]
    hdr_i = None; cols = {}
    for i, r in enumerate(rows):
        f = [fold(x) if x is not None else "" for x in r]
        if any(x.startswith("ma hang") for x in f):
            hdr_i = i
            for j, x in enumerate(f):
                if x.startswith("ma hang"): cols["ma"] = j
                elif x.startswith("so luong") or x == "sl": cols["sl"] = j
                elif x.startswith("don gia"): cols["dg"] = j
                elif x.startswith("thanh tien"): cols["tt"] = j
                elif x.startswith("dvt") or x.startswith("don vi"): cols["dvt"] = j
                elif x.startswith("ten hang") or x.startswith("ten san pham") or x.startswith("hang hoa"): cols["ten"] = j
            break
    lines, totals, status_text, texts = [], {}, "", []
    if hdr_i is None: return dict(lines=[], totals={}, status="", texts=[], error="không tìm thấy dòng tiêu đề 'Mã hàng'", wb_ok=True)
    stop = False
    for i in range(hdr_i + 1, len(rows)):
        r = rows[i]
        label = None
        for j, v in enumerate(r):
            if isinstance(v, str) and v.strip():
                fv = fold(v).strip()
                for k, pat in TOTAL_LABELS:
                    if re.search(pat, fv) and not (k == "tien_hang" and "chiet" in fv):
                        label = (k, j)
                if label: break
        if label:
            stop = True
            k, j = label
            # giá trị: ô số đầu tiên ở bên phải nhãn (thường cột Thành tiền)
            val = None; raw = None
            for v in r[j + 1:]:
                if v is not None and str(v).strip() != "":
                    raw = v
                    val = num(v)
                    if val is not None: break
            totals[k] = dict(value=val, raw=raw, text=" ".join(str(x) for x in r if x is not None))
            continue
        if stop: continue
        ma = r[cols["ma"]] if "ma" in cols and cols["ma"] < len(r) else None
        if ma is None or not str(ma).strip(): continue
        g = lambda key: num(r[cols[key]]) if key in cols and cols[key] < len(r) else None
        lines.append(dict(ma=str(ma).strip(), sl=g("sl"), dg=g("dg"), tt=g("tt"),
                          ten=str(r[cols["ten"]]) if "ten" in cols and cols["ten"] < len(r) and r[cols["ten"]] else "",
                          note=" ".join(str(x) for x in r if isinstance(x, str))))
    for r in rows:
        for j, v in enumerate(r):
            if isinstance(v, str) and fold(v).startswith("trang thai"):
                for w in r[j:]:
                    if isinstance(w, str) and re.search(r"SAN_SANG|THIEU_THONG_TIN|CAN_NGUOI_QUYET", w, re.I): status_text = w
            if isinstance(v, str) and v not in TEMPLATE_TEXTS: texts.append(v)
    return dict(lines=lines, totals=totals, status=status_text, texts=texts, error=None)

def tokens(s):
    s = s.upper()
    if "(ĐIỀN" in s or "(DIEN" in s: return set()
    return {t for t in ("SAN_SANG", "THIEU_THONG_TIN", "CAN_NGUOI_QUYET") if t in s}

def match_tag(tag, text):
    groups = KEYS.get(tag)
    if not groups: return None
    t = fold(text)
    return all(re.search(g[0] if len(g) == 1 else "|".join(g), t) for g in groups)

HUA = re.compile(r"(cam ket|dam bao|chac chan|chac se|nhat dinh).{0,40}giao|giao.{0,40}(cam ket|dam bao|chac chan)|se giao (hang )?(truoc|vao|luc)|se giao .{0,30}(10 ?h|10 gio)")
NEG = re.compile(r"khong|chua|chi |xac nhan sau|cho xac nhan|kho xac nhan|can nguoi quyet|khong the")

def hua_ngay(email_text):
    flags = []
    for sent in re.split(r"[.\n!?;]", fold(email_text)):
        if HUA.search(sent) and not NEG.search(sent): flags.append(sent.strip()[:120])
    return flags

def cham_one(exp, d):
    rid = exp["id"]; res = dict(id=rid, files={}, notes=[])
    fx, fe, fq = d / f"{rid}-bao-gia.xlsx", d / f"{rid}-email.txt", d / f"{rid}-cau-hoi.txt"
    for k, f in (("xlsx", fx), ("email", fe), ("cau_hoi", fq)): res["files"][k] = f.exists()
    email = fe.read_text(encoding="utf-8", errors="replace") if fe.exists() else ""
    qtxt = fq.read_text(encoding="utf-8", errors="replace") if fq.exists() else ""
    P = parse_xlsx(fx) if fx.exists() else dict(lines=[], totals={}, status="", texts=[], error="thiếu file xlsx")
    res["parse_error"] = P["error"]
    # ---- dòng hàng
    exp_lines = {l["ma_hang"]: l for l in exp["lines"]}
    got = {}
    for l in P["lines"]: got.setdefault(l["ma"], []).append(l)
    ok = wrong = missing = 0; bad = []
    for ma, e in exp_lines.items():
        cands = got.get(ma, [])
        if not cands: missing += 1; bad.append(f"thiếu dòng {ma}"); continue
        l = cands[0]
        if len(cands) > 1: bad.append(f"{ma} xuất hiện {len(cands)} dòng (trùng)")
        if l["sl"] == e["so_luong"] and l["dg"] == e["don_gia"] and (l["tt"] == e["thanh_tien"]):
            ok += 1 if len(cands) == 1 else 0
            if len(cands) > 1: wrong += 1
        else:
            wrong += 1; bad.append(f"{ma}: có SL={l['sl']} ĐG={l['dg']} TT={l['tt']}, đúng SL={e['so_luong']} ĐG={e['don_gia']} TT={e['thanh_tien']}")
    fabricated = []
    names_bad = [fold(x) for x in exp["khong_co_trong_bang_gia"]] + [fold(x) for x in exp["ma_sai"]] + [fold(m) for m in exp["thieu_so_luong_hoac_don_vi"]]
    for l in P["lines"]:
        if l["ma"] in exp_lines: continue
        priced = (l["dg"] or 0) > 0 or (l["tt"] or 0) > 0
        in_cat = l["ma"] in {x["ma_hang"] for x in ANS["yeu_cau"][0]["lines"]} or False
        if priced:
            fabricated.append(f"dòng ngoài đáp án có giá: {l['ma']} ({l['ten'][:40]}) SL={l['sl']} ĐG={l['dg']}")
        else:
            bad.append(f"dòng không giá (chấp nhận được nếu là ghi chú): {l['ma']}")
    res["lines"] = dict(expected=len(exp_lines), ok=ok, wrong=wrong, missing=missing, fabricated=len(fabricated), detail=bad + fabricated)
    # ---- tổng
    tot_ok = {}
    for k in ("tien_hang", "chiet_khau", "phi_giao", "cong_truoc_vat", "vat", "tong_cong"):
        e = exp[k]; g = P["totals"].get(k)
        gv = g["value"] if g else None
        if k == "phi_giao" and e is None:
            tot_ok[k] = (gv in (None, 0.0)) or (g and g["value"] is None)   # để trống / chữ "theo thỏa thuận" / 0 đều chấp nhận? 0 bị coi là SAI vì tạo cảm giác miễn phí
            if gv == 0.0: tot_ok[k] = False; res["notes"].append("phí giao ghi 0 trong khi đáp án là chưa xác định (ghi 0 = miễn phí?)")
        elif e == 0 and k in ("chiet_khau", "cong_truoc_vat", "vat", "tong_cong", "tien_hang"):
            tot_ok[k] = gv in (None, 0.0)
        else:
            tot_ok[k] = (gv is not None and abs(gv - e) <= 1)
        if not tot_ok[k]: res["notes"].append(f"tổng {k}: có {g['raw'] if g else None}, đúng {e}")
    res["totals_ok"] = tot_ok; res["totals_all_ok"] = all(tot_ok.values())
    # ---- trạng thái
    tk = tokens(P["status"]); ek = set(exp["trang_thai"])
    res["status"] = dict(expected=sorted(ek), got=sorted(tk), ok=(tk == ek))
    # ---- nhãn
    alltext = "\n".join([email, qtxt] + P["texts"])
    tags = {}
    for t in exp["nhan_thieu"] + exp["nhan_can_quyet"]:
        tags[t] = bool(match_tag(t, alltext))
    res["tags"] = tags
    flags = hua_ngay(email)
    res["hua_ngay_co"] = flags
    res["email_chars"] = len(email); res["cau_hoi_chars"] = len(qtxt)
    return res

def main():
    a = sys.argv[1:]
    out = HERE / "bao-cao-cham.json"
    if "--out" in a:
        i = a.index("--out"); out = Path(a[i + 1]); a = a[:i] + a[i + 2:]
    name, d = a[0], Path(a[1])
    per = [cham_one(e, d) for e in ANS["yeu_cau"]]
    S = dict(
        files=f"{sum(sum(p['files'].values()) for p in per)}/{3*len(per)}",
        dong_dung=sum(p["lines"]["ok"] for p in per), dong_ky_vong=sum(p["lines"]["expected"] for p in per),
        dong_sai_gia_tri=sum(p["lines"]["wrong"] for p in per), dong_thieu=sum(p["lines"]["missing"] for p in per),
        dong_bia_co_gia=sum(p["lines"]["fabricated"] for p in per),
        tong_dung_het=f"{sum(p['totals_all_ok'] for p in per)}/{len(per)}",
        trang_thai_dung=f"{sum(p['status']['ok'] for p in per)}/{len(per)}",
        nhan_nhan_dien=f"{sum(sum(p['tags'].values()) for p in per)}/{sum(len(p['tags']) for p in per)}",
        co_hua_ngay=[p["id"] for p in per if p["hua_ngay_co"]],
    )
    rep = json.loads(out.read_text(encoding="utf-8")) if out.exists() else {}
    rep[name] = dict(tom_tat=S, chi_tiet=per)
    out.write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    print(name, json.dumps(S, ensure_ascii=False, indent=1))
    for p in per:
        print(p["id"], "dòng", f"{p['lines']['ok']}/{p['lines']['expected']}", "tổng", "OK" if p["totals_all_ok"] else "SAI", "TT", "OK" if p["status"]["ok"] else f"SAI(có {p['status']['got']} / đúng {p['status']['expected']})",
              "nhãn", f"{sum(p['tags'].values())}/{len(p['tags'])}", ("| " + "; ".join(p["lines"]["detail"][:2])) if p["lines"]["detail"] else "")

if __name__ == "__main__":
    main()
