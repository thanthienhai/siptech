# BÁO CÁO PHÂN TÍCH ĐÁNH GIÁ KHÁCH HÀNG & ĐỀ XUẤT CẢI THIỆN

**Kính gửi:** Chủ quán Cà phê  
**Người thực hiện:** Chuyên viên Chăm sóc Khách hàng  
**Dữ liệu phân tích:** 250 đánh giá thu thập từ Google Maps, Shopee Food và Facebook  

---

## 1. Tổng quan dữ liệu & Loại bỏ đánh giá không hợp lệ

- **Tổng số đánh giá thu thập ban đầu:** 250 bài đánh giá.
- **Số bài loại bỏ không đưa vào phân tích:** 7 bài (chi tiết lưu tại [loai-bo.csv](file:///dau-ra/loai-bo.csv)):
  - **Trùng lặp nguyên văn (giữ lại bài có ngày sớm nhất):** 4 bài
    - `R117` (trùng nguyên văn với `R055`)
    - `R171` (trùng nguyên văn với `R111`)
    - `R177` (trùng nguyên văn với `R142`)
    - `R205` (trùng nguyên văn với `R132`)
  - **Quảng cáo / Spam:** 2 bài
    - `R070` (chạy quảng cáo Facebook, tăng like fanpage)
    - `R122` (spam đường dẫn nhận quà 500k)
  - **Không phải đánh giá:** 1 bài
    - `R228` (chỉ đặt câu hỏi về giờ mở cửa của quán)
- **Số bài đánh giá hợp lệ đưa vào phân tích chuyên sâu:** 243 bài.
- **Tổng số ý kiến được tách chi tiết:** 413 ý kiến (lưu tại [y-kien.csv](file:///dau-ra/y-kien.csv)).

---

## 2. Bảng tổng hợp Chủ đề x Sắc thái

*(Số liệu được tổng hợp và đếm bằng code từ file [tong-hop.py](file:///dau-ra/tong-hop.py), ghi nhận tại [xu-huong-tuan.csv](file:///dau-ra/xu-huong-tuan.csv))*

| Chủ đề | Tích cực | Tiêu cực | Trung tính | CẦN NGƯỜI ĐỌC | Tổng cộng |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Chất lượng** (đồ uống, món ăn, bánh) | 58 | 27 | 10 | 4 | **99** |
| **Phục vụ** (thái độ, tốc độ lên món) | 39 | 34 | 9 | 3 | **85** |
| **Giá cả** (giá món, phụ thu, khuyến mãi) | 14 | 47 | 11 | 2 | **74** |
| **Không gian** (chỗ ngồi, nhạc, wifi, gửi xe) | 31 | 19 | 7 | 3 | **60** |
| **Giao hàng** (đóng gói, shipper, thời gian giao) | 19 | 30 | 6 | 2 | **57** |
| **Vệ sinh** (bàn ghế, sàn nhà, nhà vệ sinh, côn trùng) | 4 | 19 | 4 | 1 | **28** |
| **Khác** (thông tin chung, trải nghiệm bên lề) | 3 | 0 | 3 | 4 | **10** |
| **TỔNG CỘNG** | **168** | **176** | **50** | **19** | **413** |

---

## 3. Nhận xét xu hướng theo tuần

Dữ liệu ghi nhận trong 12 tuần (từ ngày 24/08/2026 đến ngày 15/11/2026):

1. **Giai đoạn ổn định (Tháng 8 và Tháng 9/2026 - Tuần 24/08 đến 28/09):**
   - Quán vận hành khá tốt với tỷ lệ ý kiến tích cực chiếm ưu thế (15 - 19 ý kiến tích cực mỗi tuần, so với 10 - 14 ý kiến tiêu cực).
   - Khách hàng dành nhiều lời khen cho hương vị đồ uống đặc trưng (trà đào cam sả, matcha latte, cà phê muối béo ngậy), không gian ban công ngắm hàng cây yên tĩnh và sự nhiệt tình, nhớ mặt khách quen của đội ngũ nhân viên.

2. **Giai đoạn đảo chiều và khủng hoảng tiêu cực (Tháng 10 và đầu Tháng 11/2026 - Tuần 05/10 đến 09/11):**
   - Tình hình kinh doanh và trải nghiệm khách hàng sụt giảm nghiêm trọng. Ý kiến tiêu cực tăng vọt và áp đảo ý kiến tích cực (đặc biệt tuần 05/10 có 24 tiêu cực / 18 tích cực; tuần 19/10 có 20 tiêu cực / 11 tích cực; tuần 26/10 tiêu cực gấp gần 4 lần tích cực: 18 tiêu cực / 5 tích cực).
   - **3 nguyên nhân chính tạo nên làn sóng tẩy chay:**
     - **Tăng giá bất ngờ & phụ thu mập mờ:** Đầu tháng 10, quán tăng giá đồng loạt (~10.000đ/món, nhiều món lên 55k - 65k) trong khi dung tích ly có xu hướng nhỏ đi, đồng thời xuất hiện tình trạng tự ý cộng 10% phí dịch vụ vào hóa đơn.
     - **Sự cố an toàn thực phẩm liên tiếp:** Từ giữa tháng 10, liên tục xuất hiện các phản hồi ngộ độc nghiêm trọng (nhập viện cấp cứu vì bánh mì chả, trẻ em nôn sốt vì tiramisu, đau bụng dữ dội do sữa chua cacao hỏng, có gián trong nước cam).
     - **Khâu giao hàng Shopee Food xuống cấp:** Tỷ lệ đồ uống bị đổ tràn ra túi, giao thiếu món, bánh bẹp dúm và shipper giao trễ cả tiếng đồng hồ diễn ra thường xuyên.

---

## 4. Đúng 5 việc nên sửa trước (Xếp theo mức độ khẩn cấp)

Dưới đây là 5 vấn đề cốt lõi quán cần tập trung khắc phục ngay lập tức, xếp theo thứ tự ưu tiên từ nguy cấp tới mức độ ảnh hưởng diện rộng:

## Việc 1: Khắc phục triệt để an toàn vệ sinh thực phẩm, thu hồi và kiểm soát nguyên liệu tươi & bánh ngọt

- **Vì sao:** Đây là vấn đề **NGUY CẤP NHẤT** vì đe dọa trực tiếp tới sức khỏe người tiêu dùng, uy tín thương hiệu và tiềm ẩn rủi ro bị cơ quan chức năng đình chỉ hoạt động kinh doanh. Quán đã ghi nhận trường hợp cả hai vợ chồng phải đi cấp cứu sau khi ăn bánh mì chả, trẻ em 6 tuổi bị sốt và nôn mửa sau khi ăn bánh tiramisu, khách bị đau bụng quặn tiêu chảy cả ngày nghi do sữa hỏng, và phát hiện gián trong ly nước ép.
- **Đề xuất hành động:**
  1. Lập tức rà soát, tạm ngưng hợp tác hoặc đổi nhà cung cấp chả và nguyên liệu bánh mì; kiểm tra toàn bộ hạn sử dụng và điều kiện bảo quản của bánh tiramisu, croissant, sữa chua và sữa tươi pha chế.
  2. Tổng vệ sinh toàn bộ khu vực pha chế, quầy bánh, tủ lạnh; lắp đặt chụp chắn và lưới bảo vệ tránh ruồi bọ bu quầy bánh; phun khử côn trùng (đặc biệt là gián).
  3. Quản lý/chủ quán cần chủ động liên hệ trực tiếp với các khách hàng gặp sự cố ngộ độc để thăm hỏi chân thành, hỗ trợ chi phí y tế và xử lý khủng hoảng truyền thông.
- **Bằng chứng:**
  > [R170] "Ăn bánh mì chả ở đây trưa thứ Ba, tối cả hai vợ chồng nôn mửa với tiêu chảy, phải đi cấp cứu. Bác sĩ nói nghi ngộ độc thực phẩm. Quán kiểm tra lại nguồn chả giùm."
  > [R175] "Đặt trà sữa với bánh tiramisu giao tận nhà, con mình 6 tuổi ăn xong 2 tiếng sau nôn và sốt. Hoang mang quá, ai ăn tiramisu hôm đó nhớ để ý."
  > [R178] "mình thấy 1 con gián nhỏ nổi trong ly nước ép cam, chụp hình rồi. ghê quá, hết dám uống luôn"

## Việc 2: Chấn chỉnh đạo đức dịch vụ, kỷ luật nghiêm và đào tạo lại thái độ ứng xử của nhân viên và quản lý

- **Vì sao:** Mức độ **NGUY CẤP VỀ THƯƠNG HIỆU**. Khách hàng phản ánh nhân viên thu ngân và quản lý ca trực có thái độ vô văn hóa, lăng mạ và xúc phạm khách hàng một cách công khai (mắng khách "mù hả không đọc menu à", ném menu, liếc xéo đuổi "không mua thì ra", quản lý đứng quát khách xối xả trước mặt khách nước ngoài, nhân viên quát "đừng hỏi nhiều"). Hành vi này biến khách hàng thân thiết thành người quay lưng tẩy chay.
- **Đề xuất hành động:**
  1. Kiểm tra camera và ca trực, áp dụng chế tài kỷ luật nghiêm khắc (đình chỉ công tác, phạt trừ thưởng hoặc chấm dứt hợp đồng) đối với những nhân sự có lời lẽ xúc phạm, quát tháo hoặc đuổi khách.
  2. Xây dựng quy chuẩn giao tiếp chuẩn mực (SOP phục vụ): luôn giữ thái độ lịch sự, biết cảm ơn và xin lỗi, tuyệt đối không đôi co hay thể hiện thái độ tiêu cực khi quán đông khách.
  3. Bố trí lại lịch trực giờ cao điểm để tránh tình trạng quá tải khiến nhân viên cáu gắt và phục vụ chậm trễ.
- **Bằng chứng:**
  > [R039] "Mình hỏi lại giá ly bạc xỉu thì bạn thu ngân chửi luôn 'mù hả không đọc menu à' trước mặt cả quán. Nói chuyện kiểu đó với khách thì thôi, khỏi quay lại."
  > [R057] "Bạn nam ca tối ném menu xuống bàn rồi quay đi, hỏi gì cũng trả lời trống không. Xin thêm ly nước lọc thì liếc xéo nói 'không mua thì ra'."
  > [R083] "Quản lý đứng quầy quát khách vì để xe sai chỗ, dùng từ rất khó nghe, có cả khách nước ngoài đứng nhìn. Quá thất vọng về cách đối xử với khách."

## Việc 3: Minh bạch hóa hóa đơn, chấm dứt phụ thu tự động và các chiêu trò khuyến mãi ảo

- **Vì sao:** Mức độ **NGUY CẤP VỀ PHÁP LÝ & NIỀM TIN**. Việc nhân viên tự ý tính dôi món rồi ép khách trả tiền ("máy tính tự tính nên cứ trả đủ"), tự cộng 10% phí dịch vụ mà menu không thông báo, giao ly size M nhưng tính tiền size L, hoặc treo biển khuyến mãi "mua 1 tặng 1" trên mạng nhưng đến nơi từ chối áp dụng khiến khách hàng cảm thấy bị "móc túi" và lừa đảo trắng trợn.
- **Đề xuất hành động:**
  1. Kiểm tra lại toàn bộ phần mềm POS bán hàng; nghiêm cấm thu ngân tự ý cộng tiền sai hoặc ép khách trả tiền cho món không gọi; yêu cầu in bill rõ ràng và hoàn tiền ngay nếu có sai lệch.
  2. Bỏ ngay tính năng tự động cộng 10% phí dịch vụ; nếu có phụ thu bắt buộc phải niêm yết công khai trên bảng giá/menu và nhân viên phải thông báo trước khi khách thanh toán.
  3. Đồng bộ thông tin khuyến mãi giữa Fanpage và quầy bar, đảm bảo khuyến mãi chạy đúng cam kết, không dùng chiêu trò "câu khách bằng khuyến mãi ảo".
- **Bằng chứng:**
  > [R149] "Bill ghi 2 ly bạc xỉu mà mình chỉ gọi 1, báo thì nhân viên bảo máy tính tự tính nên cứ trả đủ. Mình thấy như bị móc túi, ai thanh toán nhớ soi bill kỹ."
  > [R216] "Cuối bill tự cộng 10% phí dịch vụ, menu không ghi chỗ nào, hỏi thì nói quy định mới. Báo trước một câu cũng không."
  > [R183] "Fanpage đăng mua 1 tặng 1 cuối tuần, ra quán thì nói hết chương trình dù bảng vẫn dán ngay quầy. Câu khách bằng khuyến mãi ảo vậy sao?"

## Việc 4: Chuẩn hóa quy trình đóng gói chống tràn và kiểm soát chất lượng giao hàng (Shopee Food)

- **Vì sao:** Mức độ **ẢNH HƯỞNG CAO TRÊN KÊNH ONLINE**. Khâu giao hàng nhận tới 30 ý kiến tiêu cực (chiếm hơn phân nửa đánh giá về giao hàng). Các vấn đề lớn nhất gồm: đồ uống giao đến bị bung nắp đổ lênh láng ra túi (gặp ở rất nhiều đơn), bánh bị đè bẹp dúm do đóng gói sơ sài, đơn hàng bị thiếu món, đồ ăn nguội ngắt và giao trễ gần 1 tiếng. Nếu không khắc phục, quán sẽ mất toàn bộ doanh thu giao hàng trực tuyến.
- **Đề xuất hành động:**
  1. Đầu tư ngay máy dập màng seal nắp ly hoặc nắp nút chống tràn chuyên dụng; sử dụng khay định hình ly nước khi giao hàng bằng túi.
  2. Dùng hộp giấy/hộp nhựa cứng bảo vệ cho các loại bánh ngọt (croissant, tiramisu) để tránh việc bị nén ép biến dạng trong quá trình tài xế vận chuyển.
  3. Áp dụng quy trình kiểm soát 2 bước trước khi bàn giao cho shipper: kiểm đếm đủ số lượng món, đồ ăn nóng, kèm đầy đủ ống hút, muỗng và khăn giấy.
- **Bằng chứng:**
  > [R101] "Nước giao tới bị đổ ra túi, dính đầy 👎"
  > [R143] "giao nhanh lắm, 20p là có rồi. vị trà đào thì ngon nhưng đóng gói ẩu nên đổ hết 1/3 ra túi 😤"
  > [R215] "Đắt quá, 65k cho ly trà đào cam sả thì thôi với bánh bị bẹp dí do đóng gói sơ sài. Hôm đó trời mưa. 😞"

## Việc 5: Đánh giá lại cơ cấu giá bán, dung tích món và truyền thông giá trị tương xứng

- **Vì sao:** Mức độ **ẢNH HƯỞNG DIỆN RỘNG NHẤT**. Giá cả là chủ đề có lượng phản hồi tiêu cực áp đảo nhất toàn quán (47 ý kiến tiêu cực). Việc tăng giá đột ngột thêm 10.000đ/món trong khi dung tích ly lại bị thu nhỏ ("uống 3 ngụm là hết") đã tạo ra cảm giác "bị hớ", đắt đỏ vô lý, đẩy nhóm khách hàng trung thành (học sinh, sinh viên, người ngồi làm việc) sang các quán cà phê lân cận.
- **Đề xuất hành động:**
  1. Khảo sát lại mặt bằng giá khu vực; giữ nguyên mức dung tích ly đầy đặn nếu định giá từ 49k - 65k, hoặc phân chia rõ các kích cỡ ly (Size S, M, L) tương ứng với từng mức giá hợp lý.
  2. Bổ sung các combo tiết kiệm (nước + bánh) hoặc chính sách ưu đãi khung giờ / thẻ tích điểm cho tệp khách quen và sinh viên.
  3. Nâng cấp chất lượng dịch vụ và không gian (wifi mạnh hơn, vệ sinh bàn ghế sạch sẽ, tẩy sạch vết son trên ly tách) để trải nghiệm thực tế hoàn toàn xứng đáng với số tiền khách bỏ ra.
- **Bằng chứng:**
  > [R102] "menu mới tăng khoảng 10k mỗi món, uống hơi xót ví nhưng hương vị trà đào cam sả ngonnn hơn mong đợi. Ghé buổi chiều tối."
  > [R151] "Giá lên mà ly thì nhỏ lại?? 55k 1 ly cf muối mà uống 3 ngụm hết, ko đáng tiền, nhưng cf thì vẫn ngon"
  > [R250] "Giá lên hoài, giờ đắt hơn quán bên cạnh nhưng ghế êm, có ổ cắm ở mỗi bàn"
