"""Dựng ảnh PNG 'như mở bằng Excel' từ file .xlsx giả (HTML -> PNG bằng Edge). Dùng cho ảnh dữ liệu đầu vào.
Dùng:  python -X utf8 dung_anh_du_lieu.py <file.xlsx> <ra.png> [--rows 14] [--tail 0] [--title "..."]
--tail N: hiện thêm N dòng cuối của bảng (để thấy dòng tổng/ghi chú).
"""
import sys, html, argparse, datetime as dt
from pathlib import Path
import os; AGENTLAB = os.environ.get("AGENTLAB") or str(Path(__file__).resolve().parents[5] / "siptech-video" / "agentlab")  # thư mục chứa term.py (đường dẫn tương đối từ bài)
sys.path.insert(0, AGENTLAB)
import openpyxl
from openpyxl.utils import get_column_letter
from term import shot_html, scrub_text

CSS = """body{margin:0;background:#fff;font-family:Calibri,'Segoe UI',sans-serif}
.wrap{padding:14px 16px;width:1100px}
.ttl{font:600 15px 'Segoe UI';color:#1f2937;margin-bottom:6px}
table{border-collapse:collapse;font-size:14px}
td,th{border:1px solid #d1d5db;padding:3px 8px;white-space:nowrap;height:22px}
th{background:#f3f4f6;color:#6b7280;font-weight:600;text-align:center}
td.rn{background:#f3f4f6;color:#6b7280;text-align:center;min-width:34px}
td.mg{background:#fef3c7;font-weight:600}
td.num{text-align:right} td.txt{text-align:left}
td.gap{background:#f9fafb;color:#9ca3af;text-align:center;font-style:italic}
.note{font:12px 'Segoe UI';color:#6b7280;margin-top:6px}
"""


def fmt(v, nf):
    if v is None: return ""
    if isinstance(v, (dt.datetime, dt.date)): return v.strftime("%d/%m/%Y")
    if isinstance(v, bool): return str(v)
    if isinstance(v, (int, float)): return f"{v:,.0f}" if isinstance(v, float) and v == int(v) or isinstance(v, int) else str(v)
    return str(v)


def render(path, rows=14, tail=0, title=None):
    wb = openpyxl.load_workbook(path, data_only=True); ws = wb.active
    wbf = openpyxl.load_workbook(path, data_only=False); wsf = wbf.active
    maxc = ws.max_column; maxr = ws.max_row
    merged = {}; covered = set()
    for m in ws.merged_cells.ranges:
        merged[(m.min_row, m.min_col)] = (m.max_row - m.min_row + 1, m.max_col - m.min_col + 1)
        for r in range(m.min_row, m.max_row + 1):
            for c in range(m.min_col, m.max_col + 1):
                if (r, c) != (m.min_row, m.min_col): covered.add((r, c))
    show = list(range(1, min(rows, maxr) + 1))
    if tail and maxr > rows:
        t0 = max(rows + 1, maxr - tail + 1)
        if t0 > rows + 1: show.append(None)
        show += list(range(t0, maxr + 1))
    shown_set = {r for r in show if r}
    runlen = {}
    for (r0, c0), (nr, nc) in merged.items():
        k = 0
        while k < nr and (r0 + k) in shown_set and (k == 0 or (r0 + k - 1) in shown_set): k += 1
        runlen[(r0, c0)] = (max(k, 1), nc)
    skip = set()
    for m in ws.merged_cells.ranges:
        k = runlen[(m.min_row, m.min_col)][0]
        for r in range(m.min_row, m.min_row + k):
            for c in range(m.min_col, m.max_col + 1):
                if (r, c) != (m.min_row, m.min_col): skip.add((r, c))
    out = ['<table><tr><th></th>' + "".join(f"<th>{get_column_letter(c)}</th>" for c in range(1, maxc + 1)) + "</tr>"]
    for r in show:
        if r is None:
            out.append(f'<tr><td class="rn">⋮</td><td class="gap" colspan="{maxc}">… {maxr - rows - tail} dòng dữ liệu ở giữa …</td></tr>'); continue
        cells = [f'<td class="rn">{r}</td>']
        for c in range(1, maxc + 1):
            if (r, c) in skip: continue
            if (r, c) in covered:
                cells.append('<td class="mg"></td>'); continue
            v = ws.cell(r, c).value; f = wsf.cell(r, c).value
            span = runlen.get((r, c)); attr = ""; cls = "txt"
            if span:
                attr = f' rowspan="{span[0]}" colspan="{span[1]}"'; cls = "mg"
            elif isinstance(v, (int, float)): cls = "num"
            txt = html.escape(scrub_text(fmt(v, None)))
            if isinstance(f, str) and f.startswith("="): txt += f' <span style="color:#2563eb;font-size:11px">[{html.escape(f)}]</span>'
            cells.append(f'<td class="{cls}"{attr}>{txt}</td>')
        out.append("<tr>" + "".join(cells) + "</tr>")
    out.append("</table>")
    t = title or f"{Path(path).name}  (trang tính: {ws.title})"
    return f'<!doctype html><meta charset="utf-8"><style>{CSS}</style><div class="wrap"><div class="ttl">{html.escape(scrub_text(t))}</div>{"".join(out)}<div class="note">Dựng lại từ file .xlsx giả bằng code (không phải ảnh chụp cửa sổ Excel). Dữ liệu giả để học.</div></div>'


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("xlsx"); ap.add_argument("out")
    ap.add_argument("--rows", type=int, default=14); ap.add_argument("--tail", type=int, default=0); ap.add_argument("--title")
    a = ap.parse_args()
    shot_html(render(a.xlsx, a.rows, a.tail, a.title), a.out, width=1140, selector=".wrap")
    print("OK", a.out)
