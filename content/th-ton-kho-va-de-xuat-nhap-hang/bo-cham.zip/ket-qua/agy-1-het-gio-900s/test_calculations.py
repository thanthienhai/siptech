import pandas as pd
import numpy as np
import math
import json

# Load files
with open('tham-so.json', 'r', encoding='utf-8') as f:
    tham_so = json.load(f)

dm = pd.read_csv('danh-muc-hang.csv')
nk = pd.read_csv('nhat-ky-xuat-nhap.csv')
td = pd.read_csv('ton-dau-ky-2025-11-01.csv')
tk = pd.read_csv('ton-kiem-ke-2026-10-31.csv')
hve = pd.read_csv('hang-dang-ve.csv')

def parse_date(d_str):
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d/%m/%y'):
        try:
            return pd.to_datetime(d_str, format=fmt)
        except ValueError:
            pass
    return pd.to_datetime(d_str, dayfirst=True, errors='coerce')

nk['parsed_date'] = nk['ngay'].apply(parse_date)
nk['ma_hang_raw'] = nk['ma_hang']
nk['ma_hang_clean'] = nk['ma_hang'].str.strip().str.upper().str.replace('-', '')

name_to_sku = {
    'Nuoc mam chai 500ml': 'TH003',
    'Nuoc suoi chai 500ml': 'TH009',
    'Son duong moi thoi': 'MP006',
    'Khan giay hop': 'VT006'
}
for name, sku in name_to_sku.items():
    nk.loc[nk['ten_hang'] == name, 'ma_hang_clean'] = sku

# Deduplicate
dup_mask = nk.duplicated(subset=['ma_phieu'], keep='first')
nk_dedup = nk[~dup_mask].copy()

# Date filter: within 2025-11-01 to 2026-10-31
nk_period = nk_dedup[nk_dedup['parsed_date'] <= pd.to_datetime('2026-10-31')].copy()

print(f'Total rows original: {len(nk)}')
print(f'Duplicates dropped: {dup_mask.sum()}')
print(f'Rows in period: {len(nk_period)}')
