# -*- coding: utf-8 -*-
"""Tự kiểm nhap_hang_loat.csv / .xlsx theo quy_dinh_shop.md.

Chạy:  python kiem.py
Thoát mã 0 nếu sạch, mã 1 nếu còn lỗi. Chỉ đọc file trong thư mục chứa script.
"""
import csv
import re
import sys
import unicodedata
from pathlib import Path

from openpyxl import load_workbook

DIR = Path(__file__).resolve().parent
COLS = ["sku", "tieu_de", "mo_ta", "gach_1", "gach_2", "gach_3", "gach_4",
        "gach_5", "tu_khoa", "trang_thai", "truong_can_bo_sung"]
GACH = [f"gach_{i}" for i in range(1, 6)]
TEXT_COLS = ["tieu_de", "mo_ta"] + GACH + ["tu_khoa"]
MISSING = {"", "?", "chưa rõ", "liên hệ ncc", "n/a", "chưa có"}
REQUIRED = ["dung_tich", "thanh_phan_noi_bat", "xuat_xu", "han_su_dung",
            "cong_dung_tren_bao_bi", "cach_dung"]
# Từ viết hoa được phép (viết tắt trong bảng, mã phiếu, và cụm CẦN ... bắt buộc)
CAPS_OK = {"SPF", "PA", "UV", "DEMO", "CẦN", "BỔ", "SUNG", "NGƯỜI", "QUYẾT"}
# Nội dung chỉ có trong ghi_chu_noi_bo hoặc là khẳng định bảng không có
CLAIMS = ["fda", "paraben", "cồn", "nhạy cảm", "bà bầu", "em bé", "nhập khẩu",
          "chính ngạch", "bảo quản sau khi mở", "khu vực", "thị trường", "vip",
          "hút khách", "rẻ hơn", "viêm da", "an toàn", "lành tính", "kích ứng",
          "kiểm nghiệm", "da liễu", "thuần chay", "chính hãng", "hiệu quả",
          "mờ thâm", "chống lão hóa", "kháng khuẩn", "chống nước", "chứng nhận",
          "khuyến mãi", "ưu đãi", "rẻ", "giá"]
PROMO_IN_TITLE = ["khuyến mãi", "giảm", "ưu đãi", "rẻ", "so với", "hơn"]
COUNTRIES = ["Thái Lan", "Hàn Quốc", "Việt Nam", "Nhật Bản", "Mỹ", "Pháp",
             "Trung Quốc", "Đài Loan", "Úc", "Đức", "Ý", "Anh"]
TERMS = ["yến mạch", "glycerin", "trà xanh", "cúc la mã", "rau má", "lô hội",
         "niacinamide", "vitamin c", "vitamin e", "hyaluronic", "bơ hạt mỡ",
         "jojoba", "bồ kết", "nước khoáng", "màng lọc", "chanh sả", "bưởi",
         "hoa cúc", "gỗ", "da dầu", "da khô", "da hỗn hợp", "tóc dầu", "tóc thường"]
EMOJI = re.compile("[\U0001F000-\U0001FFFF☀-➿⬀-⯿️‍]")
NUM = re.compile(r"\d+(?:[.,]\d+)?")

errors = []


def err(sku, msg):
    errors.append(f"[{sku}] {msg}")


def nfc(s):
    return unicodedata.normalize("NFC", s or "")


def bo_dau(s):
    s = unicodedata.normalize("NFD", s.replace("Đ", "D").replace("đ", "d"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def thieu(v):
    return (v or "").strip().lower() in MISSING


def co_tu(text, word):
    """Có từ/cụm `word` trong `text` (đã hạ chữ thường), ranh giới theo chữ cái."""
    return re.search(r"(?<!\w)" + re.escape(word) + r"(?!\w)", text) is not None


def doc_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.reader(f))


def main():
    # --- đọc dữ liệu ---
    raw = (DIR / "nhap_hang_loat.csv").read_bytes()
    if not raw.startswith(b"\xef\xbb\xbf"):
        err("FILE", "nhap_hang_loat.csv không có BOM UTF-8")
    rows = doc_csv(DIR / "nhap_hang_loat.csv")
    if rows[0] != COLS:
        err("FILE", f"tiêu đề cột sai: {rows[0]}")
    mau = doc_csv(DIR / "mau_dau_ra.csv")[0]
    if mau != COLS:
        err("FILE", "tiêu đề cột khác mau_dau_ra.csv")
    out = []
    for i, r in enumerate(rows[1:], start=2):
        if len(r) != len(COLS):
            err("FILE", f"dòng {i} có {len(r)} cột, cần {len(COLS)}")
            continue
        out.append(dict(zip(COLS, (nfc(x) for x in r))))

    with open(DIR / "thong_so.csv", encoding="utf-8-sig", newline="") as f:
        ts = list(csv.DictReader(f))
    forb = [nfc(x.strip()) for x in (DIR / "tu_cam.txt").read_text(encoding="utf-8-sig").splitlines()
            if x.strip()]

    if len(out) != len(ts):
        err("FILE", f"có {len(out)} dòng, bảng thông số có {len(ts)}")
    if [o["sku"] for o in out] != [t["sku"] for t in ts]:
        err("FILE", "danh sách/ thứ tự SKU không khớp thong_so.csv")

    # --- xlsx khớp csv ---
    ws = load_workbook(DIR / "nhap_hang_loat.xlsx").active
    xl = [["" if c is None else nfc(str(c)) for c in row] for row in ws.iter_rows(values_only=True)]
    if xl[0] != COLS:
        err("XLSX", "tiêu đề cột xlsx sai")
    if len(xl) - 1 != len(out):
        err("XLSX", f"xlsx có {len(xl) - 1} dòng, csv có {len(out)}")
    for a, b in zip(xl[1:], out):
        if a != [b[c] for c in COLS]:
            diff = [c for c, x in zip(COLS, a) if x != b[c]]
            err(b["sku"], f"xlsx khác csv ở cột {diff}")

    # --- từng sản phẩm ---
    n_ok = n_bs = 0
    for o, t in zip(out, ts):
        sku = o["sku"]
        t = {k: nfc(v) for k, v in t.items()}
        thieu_that = [k for k in REQUIRED if thieu(t[k])]

        # độ dài
        n = len(o["tieu_de"])
        if not 25 <= n <= 100:
            err(sku, f"tieu_de dài {n} (cần 25-100)")
        n = len(o["mo_ta"])
        if not 200 <= n <= 1500:
            err(sku, f"mo_ta dài {n} (cần 200-1500)")
        for g in GACH:
            if not o[g].strip():
                err(sku, f"{g} trống (cần đủ 5 gạch)")
            elif len(o[g]) > 120:
                err(sku, f"{g} dài {len(o[g])} (tối đa 120)")
            elif o[g].lstrip()[:1] in "-•*–—":
                err(sku, f"{g} còn ký tự gạch đầu dòng ở đầu")
        kws = [k.strip() for k in o["tu_khoa"].split(";")]
        if any(not k for k in kws):
            err(sku, "tu_khoa có cụm rỗng")
        if not 6 <= len(kws) <= 10:
            err(sku, f"tu_khoa có {len(kws)} cụm (cần 6-10)")
        if len(set(kws)) != len(kws):
            err(sku, "tu_khoa có cụm trùng")
        for k in kws:
            if len(k) > 30:
                err(sku, f"cụm từ khóa dài {len(k)} (tối đa 30): {k!r}")

        # từ cấm (kể cả không dấu / viết hoa)
        for col in TEXT_COLS:
            low = o[col].lower()
            un = bo_dau(low)
            for w in forb:
                if co_tu(low, w.lower()) or co_tu(un, bo_dau(w.lower())):
                    err(sku, f"{col} chứa từ cấm {w!r}")

        # tiêu đề
        if not o["tieu_de"].startswith("Vườn Nhỏ"):
            err(sku, "tieu_de không bắt đầu bằng 'Vườn Nhỏ'")
        if t["ten_san_pham"] not in o["tieu_de"]:
            err(sku, "tieu_de thiếu tên sản phẩm")
        if not thieu(t["dung_tich"]) and t["dung_tich"] not in o["tieu_de"]:
            err(sku, "tieu_de thiếu dung tích có trong bảng")
        for w in PROMO_IN_TITLE:
            if co_tu(o["tieu_de"].lower(), w):
                err(sku, f"tieu_de có từ khuyến mãi/so sánh {w!r}")

        # giọng thương hiệu
        body = " ".join(o[c] for c in ["tieu_de", "mo_ta"] + GACH + ["tu_khoa"])
        if EMOJI.search(body):
            err(sku, "có emoji/ký hiệu hình")
        for w in ["quý khách", "chị em", "chúng tôi"]:
            if co_tu(body.lower(), w):
                err(sku, f"dùng từ không đúng giọng: {w!r}")
        if o["mo_ta"].count("!") > 1:
            err(sku, "mo_ta có hơn 1 dấu chấm than")
        for tok in re.findall(r"[^\W\d_]{2,}", body):
            if tok.isupper() and tok not in CAPS_OK:
                err(sku, f"viết HOA cả từ: {tok!r}")
        if "bạn" not in o["mo_ta"].lower():
            err(sku, "mo_ta không gọi khách là 'bạn'")
        if "Vườn Nhỏ" not in o["mo_ta"]:
            err(sku, "mo_ta không xưng 'Vườn Nhỏ'")

        # con số phải có trong bảng của đúng sản phẩm (trừ sku và ghi_chu_noi_bo)
        cho_phep = set()
        for k, v in t.items():
            if k not in ("sku", "ghi_chu_noi_bo"):
                cho_phep.update(NUM.findall(v or ""))
        for col in ["tieu_de", "mo_ta"] + GACH:
            for num in NUM.findall(o[col]):
                if num not in cho_phep:
                    err(sku, f"{col} có số {num!r} không có trong bảng thông số của sản phẩm")

        # đúng sự thật: giá trị trong bảng phải xuất hiện đúng như bảng
        for k in REQUIRED:
            if not thieu(t[k]) and t[k].rstrip(".") not in o["mo_ta"]:
                err(sku, f"mo_ta không chứa đúng giá trị {k} = {t[k]!r}")
        if not thieu(t["chi_so_chong_nang"]):
            if t["chi_so_chong_nang"] not in o["mo_ta"]:
                err(sku, "mo_ta thiếu chỉ số chống nắng đúng như bảng")
        elif re.search(r"\bspf\b|\bpa\+", body.lower()):
            err(sku, "nhắc chỉ số chống nắng nhưng bảng không có")

        # nước/ thành phần/ mùi hương/ loại da không có trong bảng
        hay = " ".join(v.lower() for k, v in t.items() if k not in ("sku", "ghi_chu_noi_bo"))
        low_all = " ".join(o[c] for c in ["tieu_de", "mo_ta"] + GACH + ["tu_khoa"]).lower()
        for term in TERMS:
            if co_tu(low_all, term) and term not in hay:
                err(sku, f"nhắc {term!r} nhưng bảng thông số của sản phẩm không có")
        for c in COUNTRIES:
            if co_tu(body, c) and c != t["xuat_xu"]:
                err(sku, f"nhắc xuất xứ {c!r} khác bảng ({t['xuat_xu']!r})")

        # không để lọt nội dung từ ghi_chu_noi_bo / khẳng định bảng không có
        for w in CLAIMS:
            if co_tu(low_all, w) and w not in hay:
                err(sku, f"có cụm {w!r} không thấy trong bảng thông số (nghi từ ghi chú nội bộ)")

        # phiếu công bố
        so = t["so_phieu_cong_bo"].strip()
        co_so = (not thieu(so)) and so.lower() != "đang chờ duyệt"
        if co_so:
            if f"phiếu công bố số {so}" not in o["mo_ta"]:
                err(sku, f"có số phiếu {so} nhưng mo_ta không nêu đúng")
        else:
            if re.search(r"công bố|phiếu", low_all):
                err(sku, "nói đến phiếu/ công bố nhưng bảng không có số phiếu")

        # trạng thái
        mong_doi = "CAN_BO_SUNG" if thieu_that else "SAN_SANG"
        if o["trang_thai"] != mong_doi:
            err(sku, f"trang_thai={o['trang_thai']!r}, cần {mong_doi!r}")
        ghi = [x.strip() for x in o["truong_can_bo_sung"].split(";") if x.strip()]
        if sorted(ghi) != sorted(thieu_that):
            err(sku, f"truong_can_bo_sung={ghi}, cần {thieu_that}")
        if thieu_that:
            n_bs += 1
            for k in thieu_that:
                if f"CẦN BỔ SUNG: {k}" not in o["mo_ta"]:
                    err(sku, f"mo_ta thiếu cụm 'CẦN BỔ SUNG: {k}'")
        else:
            n_ok += 1
            if "CẦN BỔ SUNG" in body or "CẦN NGƯỜI QUYẾT" in body:
                err(sku, "SAN_SANG nhưng còn cụm CẦN ...")
            if o["truong_can_bo_sung"].strip():
                err(sku, "SAN_SANG nhưng truong_can_bo_sung không trống")
        # cụm CẦN BỔ SUNG chỉ được nêu tên cột thật sự thiếu
        for m in re.findall(r"CẦN BỔ SUNG: (\w+)", body):
            if m not in thieu_that:
                err(sku, f"'CẦN BỔ SUNG: {m}' nhưng cột đó có thông tin")

    # --- kết quả ---
    print(f"Đã kiểm {len(out)} sản phẩm: {n_ok} SAN_SANG, {n_bs} CAN_BO_SUNG.")
    if errors:
        print(f"CÒN {len(errors)} LỖI:")
        for e in errors:
            print(" -", e)
        return 1
    print("SẠCH: 0 lỗi (độ dài, từ cấm, số liệu, 5 gạch, từ khóa, trạng thái, xlsx = csv).")
    return 0


if __name__ == "__main__":
    # Console Windows hay dùng cp1252/cp437: ép UTF-8 để in được tiếng Việt.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    sys.exit(main())
