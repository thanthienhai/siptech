"""Sinh dữ liệu chấm công GIẢ (100% bịa) cho bài 06: một tháng, ~25 nhân viên, 2 chi nhánh.

Chạy:  python -X utf8 sinh_du_lieu.py
Ra:    goc/                      (dữ liệu "thô" như xuất từ máy, CÓ họ tên giả; KHÔNG đưa cho agent đám mây)
         xuat_may_cham_cong.csv, lich_ca_xoay.csv, don_nghi_phep.csv, nhan_vien.csv
       an-danh/quy_dinh_cong_ty.md  (quy định + tham số giả định; đưa cho agent)
       ../ket-qua/dap-an-goc.json  (đáp án theo mã gốc; an_danh.py đổi sang mã ẩn danh)
Hạt giống cố định. Mọi tên, mã đều bịa. Đáp án do một "bộ tính tham chiếu" (hàm tinh() bên dưới) tính ra,
rồi đối chiếu với sổ "bẫy đã cài": hai bên phải khớp tuyệt đối, nếu không script báo lỗi.
Mọi ngưỡng bên dưới là THAM SỐ GIẢ ĐỊNH của công ty giả, không phải quy định pháp luật.
"""
import csv, json, random, datetime as dt, unicodedata
from pathlib import Path

SEED = 20260920
rng = random.Random(SEED)
HERE = Path(__file__).resolve().parent
GOC = HERE / "goc"; AD = HERE / "an-danh"; KQ = HERE.parent / "ket-qua"
for p in (GOC, AD, KQ): p.mkdir(parents=True, exist_ok=True)

Y, M = 2026, 9
DAYS = [dt.date(Y, M, d) for d in range(1, 31)]
HOLIDAYS = [dt.date(2026, 9, 1), dt.date(2026, 9, 2)]          # GIẢ ĐỊNH: công ty khai báo
SHIFTS = {"HC": (dt.time(8, 0), dt.time(17, 0)), "S": (dt.time(6, 0), dt.time(14, 0)), "C": (dt.time(14, 0), dt.time(22, 0))}
LUNCH = (dt.time(12, 0), dt.time(13, 0))                         # chỉ ca HC
P = dict(GRACE=5, DUP=3, HO=10, OT_MIN=30, OT_DAY=180, OT_MONTH=2400, SIDE=120)
MACHINES = {"A": "MAY-A1", "B": "MAY-B1"}

# ---------------------------------------------------------------- nhân viên giả
HO_ = ["Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Vũ", "Đặng", "Bùi", "Đỗ", "Ngô", "Dương", "Lý"]
DEM = ["Văn", "Thị", "Minh", "Quốc", "Ngọc", "Thanh", "Hữu", "Thu", "Đức", "Mai", "Gia", "Anh"]
TEN = ["An", "Bình", "Chi", "Dũng", "Giang", "Hà", "Hiếu", "Hoa", "Khánh", "Lan", "Linh", "Long", "Mạnh", "Nga", "Nam",
       "Phúc", "Quân", "Sơn", "Thảo", "Trang", "Tuấn", "Vy", "Yến", "Huy", "Oanh", "Tâm", "Việt", "Cường"]
names = set()
while len(names) < 25:
    names.add(f"{rng.choice(HO_)} {rng.choice(DEM)} {rng.choice(TEN)}")
names = sorted(names); rng.shuffle(names)

EMPS = []   # id, name, phong, chi_nhanh, loai
spec = [("HC", "A", "Kế toán"), ("HC", "A", "Kinh doanh"), ("HC", "A", "Hành chính"), ("HC", "A", "Chăm sóc khách hàng")] * 2 + \
       [("HC", "A", "Kinh doanh"), ("HC", "A", "Kế toán")] + \
       [("HC", "B", "Kinh doanh"), ("HC", "B", "Chăm sóc khách hàng"), ("HC", "B", "Hành chính")] * 2 + \
       [("XOAY", "A", "Kho")] * 5 + [("XOAY", "B", "Cửa hàng")] * 4
assert len(spec) == 25
for i, (loai, cn, pb) in enumerate(spec):
    EMPS.append(dict(id=str(1001 + i), name=names[i], phong=pb, cn=cn, loai=loai))
E = {e["id"]: e for e in EMPS}
HC_IDS = [e["id"] for e in EMPS if e["loai"] == "HC"]; XOAY_IDS = [e["id"] for e in EMPS if e["loai"] == "XOAY"]

# ---------------------------------------------------------------- lịch ca xoay
def roster_for(k, d):
    if d in HOLIDAYS: return "OFF"
    wk = d.isocalendar()[1]
    if d.weekday() == (k * 2 + wk) % 7: return "OFF"
    return "S" if (k + wk) % 2 == 0 else "C"
ROSTER = {}   # (id, date) -> ca
for k, eid in enumerate(XOAY_IDS):
    for d in DAYS: ROSTER[(eid, d)] = roster_for(k, d)

def day_type(eid, d):
    if d in HOLIDAYS: return "LE"
    if E[eid]["loai"] == "HC": return "HC" if d.weekday() < 5 else "OFF"
    return ROSTER[(eid, d)]

# ---------------------------------------------------------------- sinh quẹt
PUNCH = []     # dict(eid, ts(datetime, có giây), mach 'A'|'B')
BAD_ROWS = []  # dòng lỗi định dạng (không vào PUNCH)
LEDGER = []    # sổ bẫy đã cài: (eid, ngày|'THANG'|'*', loai)
LEAVES = []    # (eid, từ, đến, loại)

def at(d, tm, off=0, sec=None):
    return dt.datetime.combine(d, tm) + dt.timedelta(minutes=off, seconds=rng.randint(0, 59) if sec is None else sec)

def add(eid, ts, mach=None):
    PUNCH.append(dict(eid=eid, ts=ts, mach=mach or E[eid]["cn"]))

def normal(eid, d, ca, in_off=None, out_off=None, lunch=None):
    s, e = SHIFTS[ca]
    in_off = rng.randint(-25, 4) if in_off is None else in_off
    out_off = rng.randint(-4, 25) if out_off is None else out_off
    add(eid, at(d, s, in_off)); add(eid, at(d, e, out_off))
    if lunch is None: lunch = ca == "HC" and rng.random() < 0.2
    if lunch:
        add(eid, at(d, LUNCH[0], rng.randint(0, 8))); add(eid, at(d, LUNCH[1], rng.randint(-3, 6)))

# ô (nhân viên, ngày) làm việc
work_cells = [(eid, d, day_type(eid, d)) for eid in E for d in DAYS if day_type(eid, d) in ("HC", "S", "C")]
off_cells = [(eid, d, day_type(eid, d)) for eid in E for d in DAYS if day_type(eid, d) == "OFF" and d not in HOLIDAYS]
used = set()
RESERVED = {HC_IDS[2], HC_IDS[12]}   # 2 nhân viên cho kịch bản làm thêm nhiều (một vượt ngưỡng tháng, một sát ngưỡng)
CHRONIC, NEARLY = HC_IDS[2], HC_IDS[12]

def pick(pred, n=1):
    cand = [c for c in work_cells if (c[0], c[1]) not in used and c[0] not in RESERVED and pred(c)]
    rng.shuffle(cand)
    out = cand[:n]
    assert len(out) == n, "không đủ ô"
    for c in out: used.add((c[0], c[1]))
    return out

def pick_off(pred, n=1):
    cand = [c for c in off_cells if (c[0], c[1]) not in used and c[0] not in RESERVED and pred(c)]
    rng.shuffle(cand); out = cand[:n]; assert len(out) == n
    for c in out: used.add((c[0], c[1]))
    return out

plan = {}   # (eid,d) -> ("kind", tham số)
def sched(kind, n, pred=lambda c: True, **kw):
    for c in pick(pred, n): plan[(c[0], c[1])] = (kind, c[2], kw)

# nghỉ phép đã duyệt (không quẹt): 7 đơn
leave_types = ["Phép năm", "Nghỉ ốm có giấy", "Phép năm", "Việc riêng không lương", "Phép năm", "Nghỉ ốm có giấy", "Phép năm"]
for lt in leave_types:
    c = pick(lambda c: True)[0]
    eid, d0, ca = c
    n = rng.choice([1, 1, 2, 3]); d1 = d0
    k = 1
    while k < n:   # kéo dài sang ngày làm việc kế tiếp (nếu ô trống)
        nxt = d1 + dt.timedelta(days=1)
        if nxt > DAYS[-1]: break
        if day_type(eid, nxt) in ("HC", "S", "C") and (eid, nxt) not in used and nxt not in HOLIDAYS:
            used.add((eid, nxt)); d1 = nxt; k += 1
        elif day_type(eid, nxt) in ("OFF", "LE"): d1 = nxt   # ngày nghỉ nằm giữa đơn
        else: break
    plan[(eid, d0)] = ("phep", ca, {})
    for x in range((d1 - d0).days + 1):
        dd = d0 + dt.timedelta(days=x)
        if day_type(eid, dd) in ("HC", "S", "C"): plan[(eid, dd)] = ("phep", day_type(eid, dd), {})
    LEAVES.append((eid, d0, d1, lt))

sched("thieu_ra", 5, lambda c: True)
sched("thieu_vao", 3, lambda c: True)
sched("thieu_ko_ro", 3, lambda c: True)
sched("trung", 4)
sched("trung3", 1)
sched("trung_bien3", 1)
sched("trung_bien4", 1)          # bẫy KHÔNG phải lỗi (4 phút > ngưỡng 3)
sched("tre", 8)
sched("tre_bien5", 2)            # trễ đúng 5 phút: KHÔNG tính trễ
sched("tre_bien6", 2)            # trễ 6 phút: tính trễ
sched("ve_som", 5)
sched("ve_bien5", 1)             # KHÔNG tính
sched("ve_bien6", 1)
sched("ot", 6)
sched("ot_bien29", 2)            # 29 phút: KHÔNG tính làm thêm
sched("ot_bien30", 2)            # 30 phút: tính
sched("ot_lon", 3, lambda c: c[2] != "C")               # > 3 giờ
sched("tre_ve_ot", 2)            # kết hợp: trễ + ra sớm không thể... dùng trễ + làm thêm
sched("vang", 6)
sched("phep_co_quet", 2)
sched("ho", 4)
sched("xbranch", 2)              # bẫy KHÔNG phải lỗi: vào ở chi nhánh nhà, ra ở chi nhánh kia (cách hàng giờ)
sched("bon_quet", 3, lambda c: c[2] == "HC")  # 4 quẹt (quẹt giờ nghỉ trưa): KHÔNG phải lỗi
sched("loi_gio", 1)              # có một dòng thời gian không hợp lệ cho người này (ngày vẫn bình thường)
off_plan = {}
for c in pick_off(lambda c: E[c[0]]["loai"] == "HC", 2): off_plan[(c[0], c[1])] = "nghi_lam"
for c in pick_off(lambda c: E[c[0]]["loai"] == "XOAY", 2): off_plan[(c[0], c[1])] = "nghi_lam"
le_emps = [HC_IDS[0], HC_IDS[5], XOAY_IDS[1]]
LE_WORK = [(le_emps[0], dt.date(2026, 9, 2)), (le_emps[1], dt.date(2026, 9, 1)), (le_emps[2], dt.date(2026, 9, 2))]

# các ô còn lại: quẹt bình thường
def led(eid, d, loai): LEDGER.append((eid, d if isinstance(d, str) else d.isoformat(), loai))

phep_leave_cells = {(l[0], l[1] + dt.timedelta(days=x)) for l in LEAVES for x in range((l[2] - l[1]).days + 1)}

for (eid, d), (kind, ca, kw) in plan.items():
    s, e = SHIFTS[ca]; home = E[eid]["cn"]; other = "B" if home == "A" else "A"
    if kind == "phep": continue
    elif kind == "thieu_ra":      # chỉ có quẹt vào
        add(eid, at(d, s, rng.randint(-20, 3))); led(eid, d, "THIEU_RA")
    elif kind == "thieu_vao":     # chỉ có quẹt ra
        add(eid, at(d, e, rng.randint(-3, 20))); led(eid, d, "THIEU_VAO")
    elif kind == "thieu_ko_ro":   # một quẹt giữa ca
        base = {"HC": [dt.time(11, 40), dt.time(12, 5), dt.time(13, 20)], "S": [dt.time(10, 15)], "C": [dt.time(18, 10)]}[ca]
        add(eid, at(d, rng.choice(base), rng.randint(0, 3))); led(eid, d, "THIEU_KHONG_RO")
    elif kind in ("trung", "trung3", "trung_bien3", "trung_bien4"):
        i_o, o_o = rng.randint(-20, 3), rng.randint(-3, 20)
        tin, tout = at(d, s, i_o), at(d, e, o_o)
        add(eid, tin); add(eid, tout)
        side = rng.choice([tin, tout])
        if kind == "trung":
            add(eid, side + dt.timedelta(minutes=rng.randint(0, 2), seconds=rng.randint(5, 50)))
            led(eid, d, "QUET_TRUNG")
        elif kind == "trung3":
            add(eid, tin + dt.timedelta(minutes=1)); add(eid, tin + dt.timedelta(minutes=2, seconds=30)); led(eid, d, "QUET_TRUNG")
        elif kind == "trung_bien3":
            # đúng 3 phút (theo phút đã bỏ giây) => vẫn là quẹt trùng
            add(eid, tout.replace(second=0) + dt.timedelta(minutes=3, seconds=rng.randint(0, 59))); led(eid, d, "QUET_TRUNG")
        else:
            add(eid, tin.replace(second=0) + dt.timedelta(minutes=4, seconds=rng.randint(0, 59)))   # 4 phút: KHÔNG phải trùng
    elif kind.startswith("tre") and kind != "tre_ve_ot":
        off = {"tre": rng.choice([7, 12, 18, 25, 33, 41, 55, 62]), "tre_bien5": 5, "tre_bien6": 6}[kind]
        normal(eid, d, ca, in_off=off, lunch=False)
        if off > 5: led(eid, d, "DI_TRE")
    elif kind == "tre_ve_ot":
        normal(eid, d, ca, in_off=rng.randint(10, 30), out_off=rng.randint(40, 90), lunch=False); led(eid, d, "DI_TRE")
    elif kind.startswith("ve"):
        off = {"ve_som": -rng.choice([8, 15, 30, 45, 75, 120]), "ve_bien5": -5, "ve_bien6": -6}[kind]
        normal(eid, d, ca, out_off=off, lunch=False)
        if off < -5: led(eid, d, "VE_SOM")
    elif kind == "ot":
        normal(eid, d, ca, out_off=rng.randint(31, 115 if ca == "C" else 150), lunch=False)
    elif kind == "ot_bien29": normal(eid, d, ca, out_off=29, lunch=False)
    elif kind == "ot_bien30": normal(eid, d, ca, out_off=30, lunch=False)
    elif kind == "ot_lon":
        normal(eid, d, ca, out_off=rng.randint(185, 240), lunch=False); led(eid, d, "OT_VUOT_NGUONG")
    elif kind == "vang": led(eid, d, "VANG_CHUA_GHI")
    elif kind == "phep_co_quet":
        normal(eid, d, ca, lunch=False)
        LEAVES.append((eid, d, d, "Phép năm")); led(eid, d, "CO_PHEP_NHUNG_QUET")
    elif kind == "ho":
        normal(eid, d, ca, in_off=rng.randint(-15, 0), lunch=False)
        # quẹt thêm ở máy chi nhánh kia, cách quẹt vào 2..9 phút (người khác quẹt hộ mã này)
        t_in = min(p["ts"] for p in PUNCH if p["eid"] == eid and p["ts"].date() == d)
        add(eid, t_in + dt.timedelta(minutes=rng.randint(2, 9), seconds=rng.randint(0, 40)), other); led(eid, d, "NGHI_QUET_HO")
    elif kind == "xbranch":
        s_, e_ = SHIFTS[ca]
        add(eid, at(d, s_, rng.randint(-20, 3))); add(eid, at(d, e_, rng.randint(-3, 20)), other)
    elif kind == "bon_quet":
        normal(eid, d, ca, lunch=True)
    elif kind == "loi_gio":
        normal(eid, d, ca, lunch=False)
        BAD_ROWS.append(dict(eid=eid, mach="B", raw_time="31/09/2026 08:00")); led(eid, "*", "DU_LIEU_LOI")

# ngày nghỉ/lễ có quẹt
for (eid, d), kind in off_plan.items():
    add(eid, at(d, dt.time(8, 0), rng.randint(-10, 20))); add(eid, at(d, dt.time(12, 0) if rng.random() < .5 else dt.time(17, 0), rng.randint(0, 30)))
    led(eid, d, "LAM_NGAY_NGHI")
for eid, d in LE_WORK:
    add(eid, at(d, dt.time(8, 0), rng.randint(-10, 10))); add(eid, at(d, dt.time(16, 30), rng.randint(0, 40)))
    led(eid, d, "LAM_NGAY_LE")
# dòng lỗi khác: mã thẻ lạ và dòng rỗng giờ
BAD_ROWS.append(dict(eid="9001", mach="A", raw_time=at(DAYS[10], dt.time(9, 20)).strftime("%Y-%m-%d %H:%M:%S")))
led("9001", "*", "DU_LIEU_LOI")
bad_empty_emp = [e for e in HC_IDS if e not in (CHRONIC, NEARLY)][4]
BAD_ROWS.append(dict(eid=bad_empty_emp, mach="A", raw_time="" ))
led(bad_empty_emp, "*", "DU_LIEU_LOI")

# làm thêm nhiều: CHRONIC vượt 40h/tháng, NEARLY sát ngưỡng nhưng không vượt
for eid, lo, hi in ((CHRONIC, 125, 150), (NEARLY, 100, 115)):
    for d in DAYS:
        if day_type(eid, d) == "HC" and (eid, d) not in used:
            normal(eid, d, "HC", in_off=rng.randint(-20, 3), out_off=rng.randint(lo, hi), lunch=False); used.add((eid, d))
led(CHRONIC, "THANG", "OT_THANG_VUOT")

# ngày làm việc còn lại: bình thường
for eid, d, ca in work_cells:
    if (eid, d) in used or (eid, d) in plan or (eid, d) in phep_leave_cells: continue
    normal(eid, d, ca); used.add((eid, d))

# ---------------------------------------------------------------- bộ tính tham chiếu (độc lập với đoạn sinh ở trên)
def tm(x): return x.hour * 60 + x.minute

def tinh(punches, bad_rows, leaves):
    leave_days = {(l[0], l[1] + dt.timedelta(days=i)) for l in leaves for i in range((l[2] - l[1]).days + 1)}
    by = {}
    for p in punches: by.setdefault((p["eid"], p["ts"].date()), []).append(p)
    rows, anom = [], []
    A = lambda eid, d, loai, nq=True: anom.append(dict(ma_nv=eid, ngay=d if isinstance(d, str) else d.isoformat(), loai=loai, can_nguoi_quyet=nq))
    for eid in E:
        ot_thang = 0
        for d in DAYS:
            dtp = day_type(eid, d); iso = d.isoformat()
            r = dict(ma_nv=eid, ngay=iso, loai_ngay=dtp, gio_vao="", gio_ra="", gio_cong="", phut_tre=0, phut_ve_som=0, ot_phut=0, trang_thai="")
            ps = sorted(by.get((eid, d), []), key=lambda p: p["ts"])
            # nghi quẹt hộ: hai quẹt khác máy cách <= HO phút
            ho = any(a["mach"] != b["mach"] and (b["ts"].replace(second=0) - a["ts"].replace(second=0)).total_seconds() / 60 <= P["HO"]
                     for a, b in zip(ps, ps[1:]))
            kept = []
            for p in ps:   # loại quẹt trùng cùng máy <= DUP phút so với quẹt giữ lại gần nhất
                if kept and kept[-1]["mach"] == p["mach"] and (p["ts"].replace(second=0) - kept[-1]["ts"].replace(second=0)).total_seconds() / 60 <= P["DUP"] \
                        and not ho:
                    A(eid, d, "QUET_TRUNG", False); continue
                kept.append(p)
            if kept:
                r["gio_vao"] = kept[0]["ts"].strftime("%H:%M"); r["gio_ra"] = kept[-1]["ts"].strftime("%H:%M") if len(kept) > 1 else ""
            if (eid, d) in leave_days and dtp in ("HC", "S", "C"):
                if ps: r["trang_thai"] = "CHO_XAC_NHAN"; A(eid, d, "CO_PHEP_NHUNG_QUET"); r["gio_vao"] = r["gio_ra"] = ""
                else: r["trang_thai"] = "PHEP"
                rows.append(r); continue
            if ho:
                r["trang_thai"] = "CHO_XAC_NHAN"; A(eid, d, "NGHI_QUET_HO"); r["gio_vao"] = r["gio_ra"] = ""; rows.append(r); continue
            if dtp in ("OFF", "LE"):
                if kept:
                    r["trang_thai"] = "CHO_XAC_NHAN"; A(eid, d, "LAM_NGAY_LE" if dtp == "LE" else "LAM_NGAY_NGHI")
                    r["gio_cong"] = 0.0
                    r["gio_vao"] = r["gio_ra"] = ""
                else: r["trang_thai"] = "NGHI"
                rows.append(r); continue
            s, e = SHIFTS[dtp]; s_m, e_m = tm(s), tm(e)
            if not kept:
                r["trang_thai"] = "CHO_XAC_NHAN"; A(eid, d, "VANG_CHUA_GHI"); rows.append(r); continue
            if len(kept) == 1:
                t = tm(kept[0]["ts"]); r["gio_vao"] = r["gio_ra"] = ""
                if t <= s_m + P["SIDE"]: A(eid, d, "THIEU_RA")
                elif t >= e_m - P["SIDE"]: A(eid, d, "THIEU_VAO")
                else: A(eid, d, "THIEU_KHONG_RO")
                r["trang_thai"] = "CHO_XAC_NHAN"; rows.append(r); continue
            vao, ra = tm(kept[0]["ts"]), tm(kept[-1]["ts"])
            tre = vao - s_m; tre = tre if tre > P["GRACE"] else 0
            som = e_m - ra; som = som if som > P["GRACE"] else 0
            ot = ra - e_m; ot = ot if ot >= P["OT_MIN"] else 0
            es = s_m if vao <= s_m + P["GRACE"] else vao
            ee = e_m if ra >= e_m - P["GRACE"] else min(ra, e_m)
            span = max(0, ee - es)
            if dtp == "HC":
                lo, hi = tm(LUNCH[0]), tm(LUNCH[1]); span -= max(0, min(ee, hi) - max(es, lo))
            r.update(gio_vao=kept[0]["ts"].strftime("%H:%M"), gio_ra=kept[-1]["ts"].strftime("%H:%M"), gio_cong=round(max(span, 0) / 60, 2),
                     phut_tre=tre, phut_ve_som=som, ot_phut=ot, trang_thai="OK")
            if tre: A(eid, d, "DI_TRE", False)
            if som: A(eid, d, "VE_SOM", False)
            if ot > P["OT_DAY"]: A(eid, d, "OT_VUOT_NGUONG")
            ot_thang += ot
            rows.append(r)
        if ot_thang > P["OT_MONTH"]: A(eid, "THANG", "OT_THANG_VUOT")
    for b in bad_rows: A(b["eid"], "*", "DU_LIEU_LOI")
    seen, ded = set(), []
    for a in anom:
        k = (a["ma_nv"], a["ngay"], a["loai"])
        if k not in seen: seen.add(k); ded.append(a)
    anom = ded
    # tổng hợp
    tong = {}
    for eid in E:
        rr = [r for r in rows if r["ma_nv"] == eid]
        ok = [r for r in rr if r["trang_thai"] == "OK"]
        tong[eid] = dict(ngay_cong=len(ok), tong_gio_cong=round(sum(r["gio_cong"] for r in ok), 2),
                         so_lan_tre=sum(1 for r in ok if r["phut_tre"]), tong_phut_tre=sum(r["phut_tre"] for r in ok),
                         so_lan_ve_som=sum(1 for r in ok if r["phut_ve_som"]), tong_phut_ve_som=sum(r["phut_ve_som"] for r in ok),
                         tong_ot_phut=sum(r["ot_phut"] for r in ok), tong_ot_gio=round(sum(r["ot_phut"] for r in ok) / 60, 2),
                         so_ngay_phep=sum(1 for r in rr if r["trang_thai"] == "PHEP"),
                         so_ngay_vang_chua_ghi=sum(1 for a in anom if a["ma_nv"] == eid and a["loai"] == "VANG_CHUA_GHI"),
                         so_ngay_cho_xac_nhan=sum(1 for r in rr if r["trang_thai"] == "CHO_XAC_NHAN"),
                         so_bat_thuong=sum(1 for a in anom if a["ma_nv"] == eid))
    return rows, anom, tong

rows, anom, tong = tinh(PUNCH, BAD_ROWS, LEAVES)
# đối chiếu: bộ tính tham chiếu phải ra đúng tập bẫy đã cài (mọi thứ đã cài đều phát hiện, không có thừa)
got = {(a["ma_nv"], a["ngay"], a["loai"]) for a in anom}
want = set(LEDGER)
want = {w for w in want}
miss, extra = want - got, got - want
assert not miss and not extra, f"LỆCH: thiếu {sorted(miss)} thừa {sorted(extra)}"

# ---------------------------------------------------------------- ghi file thô
def strip_accents(s):
    s = unicodedata.normalize("NFD", s).replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in s if unicodedata.category(c) != "Mn")

def fmt_ts(mach, ts): return ts.strftime("%Y-%m-%d %H:%M:%S") if mach == "A" else ts.strftime("%d/%m/%Y %H:%M")
def fmt_id(mach, eid): return f"{int(eid):05d}" if mach == "A" else str(int(eid))

out = []
for p in PUNCH:
    e = E[p["eid"]]; nm = e["name"]
    if rng.random() < 0.04: nm = strip_accents(nm).upper()
    out.append((p["mach"], p["ts"], [MACHINES[p["mach"]], fmt_id(p["mach"], p["eid"]), nm, e["phong"], fmt_ts(p["mach"], p["ts"])]))
for b in BAD_ROWS:
    if b["eid"] == "9001": nm, pb = "The tam 01", ""
    else: nm, pb = E[b["eid"]]["name"], E[b["eid"]]["phong"]
    out.append((b["mach"], dt.datetime(Y, M, 15), [MACHINES[b["mach"]], fmt_id(b["mach"], b["eid"]), nm, pb, b["raw_time"]]))
out.sort(key=lambda x: (x[0], x[1]))
rows_csv = [o[2] for o in out]
for _ in range(25):   # xáo nhẹ thứ tự cục bộ
    i = rng.randrange(len(rows_csv) - 1); rows_csv[i], rows_csv[i + 1] = rows_csv[i + 1], rows_csv[i]
with open(GOC / "xuat_may_cham_cong.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["Mã máy", "Mã NV", "Họ tên", "Phòng ban", "Thời gian"]); w.writerows(rows_csv)

with open(GOC / "lich_ca_xoay.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["Họ tên", "Ngày", "Ca"])
    for (eid, d), ca in sorted(ROSTER.items(), key=lambda x: (x[0][0], x[0][1])):
        w.writerow([E[eid]["name"], d.strftime("%d/%m/%Y"), ca])

NOTES = {"Phép năm": ["đi du lịch gia đình", "về quê", ""], "Nghỉ ốm có giấy": ["sốt, có giấy khám", "khám bệnh", "con ốm"],
         "Việc riêng không lương": ["việc gia đình", ""]}
with open(GOC / "don_nghi_phep.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["Họ tên", "Từ ngày", "Đến ngày", "Loại nghỉ", "Ghi chú", "Trạng thái"])
    for eid, a, b, lt in sorted(LEAVES, key=lambda x: (x[1], x[0])):
        w.writerow([E[eid]["name"], a.strftime("%d/%m/%Y"), b.strftime("%d/%m/%Y"), lt, rng.choice(NOTES[lt]), "Đã duyệt"])

with open(GOC / "nhan_vien.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f); w.writerow(["Mã NV", "Họ tên", "Phòng ban", "Chi nhánh", "Loại ca"])
    for e in EMPS: w.writerow([f"{int(e['id']):05d}", e["name"], e["phong"], e["cn"], e["loai"]])

# ---------------------------------------------------------------- quy định công ty (đưa cho agent)
QD = f"""# Quy định chấm công của Công ty giả (dùng cho bài thực hành)

> Đây là công ty GIẢ. Mọi ngưỡng dưới đây là THAM SỐ GIẢ ĐỊNH để làm bài, không phải quy định pháp luật.
> Quy định pháp luật về giờ làm thêm, nghỉ lễ, nghỉ phép: cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự. Bài này không trích điều luật.

## 1. Kỳ chấm công
Tháng 09/2026 (từ 2026-09-01 đến 2026-09-30). Tính theo ngày dương lịch của giờ quẹt, không có ca qua đêm.

## 2. Ca làm việc
| Ca | Giờ vào | Giờ ra | Ghi chú |
|----|---------|--------|---------|
| HC (hành chính) | 08:00 | 17:00 | Làm thứ Hai đến thứ Sáu. Nghỉ trưa 12:00-13:00 không tính công. Thứ Bảy, Chủ nhật là ngày nghỉ (OFF). |
| S (ca sáng, ca xoay) | 06:00 | 14:00 | Theo `lich_ca_xoay.csv`. Không trừ giờ nghỉ. |
| C (ca chiều, ca xoay) | 14:00 | 22:00 | Theo `lich_ca_xoay.csv`. Không trừ giờ nghỉ. |

- Nhân viên loại `HC` trong `nhan_vien.csv` theo ca HC. Nhân viên loại `XOAY` theo `lich_ca_xoay.csv` (giá trị S, C hoặc OFF = ngày nghỉ).
- Ngày lễ (công ty khai báo, giả định): 2026-09-01 và 2026-09-02. Ngày lễ là ngày nghỉ (LE) với mọi nhân viên, kể cả khi lịch xoay có ghi ca.
- Mọi so sánh giờ tính theo PHÚT: bỏ phần giây của giờ quẹt (08:05:59 xem là 08:05).

## 3. Máy chấm công
Hai máy: `MAY-A1` (chi nhánh A), `MAY-B1` (chi nhánh B). Mỗi nhân viên thuộc một chi nhánh (cột Chi nhánh trong `nhan_vien.csv`). Máy B xuất giờ dạng `dd/mm/yyyy hh:mm`, máy A xuất `yyyy-mm-dd hh:mm:ss`.

## 4. Tham số (giả định)
| Tham số | Giá trị |
|---------|---------|
| Dung sai đi trễ / về sớm | {P['GRACE']} phút (trễ hoặc sớm ĐÚNG {P['GRACE']} phút vẫn tính đủ; từ {P['GRACE']+1} phút trở lên là trễ/ sớm) |
| Quẹt trùng | hai quẹt CÙNG MÁY cách nhau <= {P['DUP']} phút: giữ quẹt đầu, bỏ quẹt sau, ghi nhận QUET_TRUNG |
| Nghi quẹt hộ | cùng một mã NV có hai quẹt Ở HAI MÁY KHÁC NHAU cách nhau <= {P['HO']} phút trong cùng ngày |
| Làm thêm giờ | chỉ tính khi quẹt ra muộn hơn giờ ra của ca >= {P['OT_MIN']} phút; tính bằng số phút chênh (quẹt ra - giờ ra ca) |
| Ngưỡng làm thêm trong NGÀY | > {P['OT_DAY']} phút ({P['OT_DAY']//60} giờ) thì cảnh báo OT_VUOT_NGUONG |
| Ngưỡng làm thêm trong THÁNG | tổng phút làm thêm của ngày làm việc thường > {P['OT_MONTH']} phút ({P['OT_MONTH']//60} giờ) thì cảnh báo OT_THANG_VUOT |
| Quẹt đơn lẻ (chỉ có một quẹt trong ngày) | quẹt <= giờ vào + {P['SIDE']} phút: coi là quẹt vào, THIEU_RA. quẹt >= giờ ra - {P['SIDE']} phút: coi là quẹt ra, THIEU_VAO. Còn lại: THIEU_KHONG_RO (không đoán) |

## 5. Cách tính một ngày làm việc (ca HC, S, C)
1. Gom quẹt theo (mã NV, ngày), sắp theo giờ. Bỏ quẹt trùng như mục 4.
2. Có từ hai quẹt: giờ vào = quẹt đầu, giờ ra = quẹt cuối. Các quẹt ở giữa (ví dụ quẹt đi ăn trưa) bỏ qua, KHÔNG phải lỗi.
3. phut_tre = giờ vào - giờ vào ca, nếu > dung sai, ngược lại 0. phut_ve_som = giờ ra ca - giờ ra, nếu > dung sai, ngược lại 0.
4. ot_phut theo mục 4.
5. gio_cong = số giờ nằm trong khung ca: bắt đầu tính từ giờ vào ca nếu vào không quá dung sai, ngược lại từ giờ vào thực tế; kết thúc tính tại giờ ra ca nếu ra không sớm quá dung sai, ngược lại tại giờ ra thực tế (không vượt quá giờ ra ca). Ca HC trừ phần giao với 12:00-13:00. Làm tròn 2 chữ số thập phân. Ví dụ ca HC vào 08:00 ra 17:00 đủ giờ: 8.00 giờ.
6. Ngày làm việc không có quẹt nào, không có đơn nghỉ: VANG_CHUA_GHI.
7. Ngày nằm trong đơn nghỉ phép đã duyệt (`nghi_phep.csv`) và không có quẹt: trạng thái PHEP, không phải bất thường. Có đơn nghỉ mà vẫn có quẹt: CO_PHEP_NHUNG_QUET (không tính giờ, chờ xác nhận).
8. Ngày nghỉ (OFF) hoặc ngày lễ (LE) mà có quẹt: LAM_NGAY_NGHI hoặc LAM_NGAY_LE, chờ xác nhận, không tính giờ công thường.
9. Ngày có NGHI_QUET_HO: không tự tính giờ, chờ xác nhận (không kết luận ai quẹt hộ).
10. Quẹt có mã NV không có trong `nhan_vien.csv`, hoặc thời gian trống/ không phải ngày giờ hợp lệ: DU_LIEU_LOI, ghi nhận, không dùng để tính.

## 6. Trạng thái ngày
OK (đã tính giờ; kể cả có trễ, sớm, làm thêm); PHEP; NGHI (ngày nghỉ không quẹt); CHO_XAC_NHAN (cần người quyết, chưa tính giờ).
Giá trị trạng thái chỉ là một trong 4 từ trên.

## 7. Mã bất thường (loai)
THIEU_RA, THIEU_VAO, THIEU_KHONG_RO, QUET_TRUNG, DI_TRE, VE_SOM, OT_VUOT_NGUONG, OT_THANG_VUOT, VANG_CHUA_GHI, LAM_NGAY_LE, LAM_NGAY_NGHI, NGHI_QUET_HO, CO_PHEP_NHUNG_QUET, DU_LIEU_LOI.
Cột `can_nguoi_quyet` = CO với mọi mã, trừ QUET_TRUNG, DI_TRE, VE_SOM (KHONG).
"""
(AD).mkdir(exist_ok=True)
(AD / "quy_dinh_cong_ty.md").write_text(QD, encoding="utf-8")

(KQ / "dap-an-goc.json").write_text(json.dumps(dict(
    thong_so=P, ngay_le=[d.isoformat() for d in HOLIDAYS], ngay=rows, bat_thuong=anom, tong_hop=tong,
    so_do_bay=[dict(ma_nv=a, ngay=b, loai=c) for a, b, c in sorted(LEDGER)], so_dong_quet=len(rows_csv)),
    ensure_ascii=False, indent=1), encoding="utf-8")
from collections import Counter
print("dòng quẹt:", len(rows_csv), "| số bất thường:", len(anom), dict(Counter(a["loai"] for a in anom)))
print("tổng OT CHRONIC/NEARLY (giờ):", tong[CHRONIC]["tong_ot_gio"], tong[NEARLY]["tong_ot_gio"], "| đối chiếu bộ tính với sổ bẫy: KHỚP")
