"""Làm hỏng CÓ CHỦ ĐÍCH 3 chỗ trong BẢN SAO của dau-ra/ để thử xem bộ kiểm chéo có bắt được không (bài 4, prompt 3).

Dùng:  python -X utf8 lam-hong-ban-sao.py <thu_muc_dau_ra_goc> <thu_muc_dau_ra_ban_sao>
Chép các file dữ liệu và báo cáo (không chép file .py, để bộ kiểm cũ của agent không lọt vào) sang bản sao rồi sửa 3 chỗ (chỉ khớp với dau-ra của lần chạy claude-lan1; thư mục khác sẽ báo lỗi):
  1. y-kien.csv  : trích dẫn "đồ uống ổn" của R105 thành "đồ uống rất ổn"       (thêm chữ)
  2. bao-cao.md  : trích dẫn của R170 đổi "với tiêu chảy" thành "và tiêu chảy"   (đổi một chữ)
  3. bao-cao.md  : ô "giá, tiêu cực" của bảng đổi từ 44 thành 48                   (sửa một số)
Không bao giờ chạy trên thư mục gốc. Không sửa file gốc.
"""
import shutil
import sys
from pathlib import Path

if len(sys.argv) != 3:
    raise SystemExit(__doc__)
src, dst = Path(sys.argv[1]), Path(sys.argv[2])
if src.resolve() == dst.resolve():
    raise SystemExit("Bản sao phải là thư mục khác với bản gốc.")
shutil.copytree(src, dst, ignore=shutil.ignore_patterns("*.py"))  # không chép script của agent (kể cả bộ kiểm cũ)


def sua(ten, cu, moi):
    p = dst / ten
    d = p.read_bytes()
    a, b = cu.encode("utf-8"), moi.encode("utf-8")
    if d.count(a) != 1:
        raise SystemExit(f"{ten}: không thấy đúng 1 chỗ '{cu}' (thư mục này không phải dau-ra của claude-lan1?)")
    p.write_bytes(d.replace(a, b))
    print(f"đã sửa {ten}: '{cu}' -> '{moi}'")


sua("y-kien.csv", "R105,chat_luong,trung_tinh,đồ uống ổn", "R105,chat_luong,trung_tinh,đồ uống rất ổn")
sua("bao-cao.md", "nôn mửa với tiêu chảy, phải đi cấp cứu\"", "nôn mửa và tiêu chảy, phải đi cấp cứu\"")
sua("bao-cao.md", "| gia | 14 | 44 | 11 | 2 | 71 |", "| gia | 14 | 48 | 11 | 2 | 71 |")
