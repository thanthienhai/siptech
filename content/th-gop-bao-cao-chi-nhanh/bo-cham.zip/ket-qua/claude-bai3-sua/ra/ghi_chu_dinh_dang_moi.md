# Ghi chú định dạng mới của file Nha Trang (T11/2026)

File: `goc/NhaTrang_doanhthu_T11.xlsx` (chỉ đọc, không sửa). So với file cũ `thang-truoc/goc/NhaTrang_doanhthu_T10.xlsx`.
Mọi con số dưới đây lấy từ kết quả chạy `gop.py` (`ra/kiem_tra.csv`, `ra/viec_can_hoi.csv`) hoặc từ đoạn code kiểm độc lập đọc thẳng file thô; không gõ tay.

## 1. Script báo gì khi chưa sửa

`python gop.py goc ra --thang 2026-11` dừng, mã thoát 2:
`LỖI CẤU TRÚC FILE: [NhaTrang_doanhthu_T11.xlsx] Không tìm thấy hàng tiêu đề (cần đủ các cột: ngày, số chứng từ, tên hàng, SL, đơn giá, thành tiền).`
Nguyên nhân: 3 trong 7 tên cột mới (`Mã chứng từ`, `Giá niêm yết`, `Doanh số (VNĐ)`) không nằm trong bảng tên cột script biết, nên chỉ nhận được 3/6 vai trò (cần >= 5). Script dừng chứ không đọc sai.

## 2. Khác biệt giữa file cũ (T10) và file mới (T11)

| Điểm | Cũ (T10) | Mới (T11) |
|---|---|---|
| Hàng tiêu đề | Dòng 3. Dòng 2 là hàng nhóm gộp ô ("THÔNG TIN BÁN HÀNG" A2:C2, "SỐ LIỆU" D2:F2) | Dòng 2, một hàng duy nhất, không gộp ô. Dữ liệu từ dòng 3 |
| Cột | A Ngày GD, B Chứng từ, C Hàng hóa, D SL, E Đơn giá, F Thành tiền (6 cột) | A Mã chứng từ, B Ngày, **C Kênh bán**, D Hàng hóa, E Số lượng, F Giá niêm yết, G Doanh số (VNĐ) (7 cột) |
| Vị trí số chứng từ | Cột B | **Cột A** |
| Kiểu ngày | Chữ `dd-mm-yy`, ví dụ `01-10-26` (ngày <= 12 đọc được 2 cách) | Chữ ISO `yyyy-mm-dd`, ví dụ `2026-11-01` (không mơ hồ). Vẫn là chữ, không phải ngày thật của Excel |
| Kiểu số | Đơn giá, thành tiền là **chữ** (`68,000`, `680,000`); SL là số | SL, giá, doanh số đều là **số thật** (nguyên) |
| Dòng tổng | Nhãn `Tổng:` ở E170, số ở F170 | Nhãn `Tổng:` ở F160, số ở G160 (số gõ cứng, không công thức) |
| Dòng ghi chú cuối | `Lưu ý: file xuất từ phần mềm cũ, mọi thắc mắc liên hệ kế toán CN.` ở A172 | Nguyên văn câu đó ở A162 (xem mục 5) |
| Tên hàng | 24 cách viết khác nhau (HOA, không dấu, viết tắt) | Vẫn 24 cách viết (`N.mắm TT 500ml`, `CF rang xay 500gr`, `Điều rang muối 500g`...). Không cần sửa quy tắc sản phẩm: 155 dòng đều ra mã SP01-SP08, không có `CHUA_XAC_DINH` |

## 3. Quyết định cho từng cột mới / cột đổi tên

| Cột mới | Xử lý | Lý do | Chắc chắn? |
|---|---|---|---|
| `Mã chứng từ` | = số chứng từ | Giá trị dạng `NT/0001`, đúng cột `Chứng từ` cũ | Chắc |
| `Ngày` | = ngày bán | Cùng ý nghĩa `Ngày GD`; ISO nên không còn mơ hồ dd/mm | Chắc |
| `Hàng hóa`, `Số lượng` | = tên hàng, SL | Chỉ đổi tên / thứ tự cột | Chắc |
| `Kênh bán` (Online / Đại lý / Tại quầy) | **Bỏ qua**, không vào doanh thu, không thêm cột đầu ra | Là nhãn phân loại, không phải tiền. Đầu ra phải giữ nguyên như tháng trước. Script in ghi chú ra màn hình và thêm 1 dòng vào mục 7 của `bao_cao.md` để việc bỏ qua không thầm lặng | Chắc là không phải tiền. Nếu muốn báo cáo theo kênh thì cần thêm cột đầu ra, **CẦN NGƯỜI QUYẾT** (hiện chưa ai yêu cầu) |
| `Giá niêm yết` | = đơn giá (chỉ để ghi cột `don_gia` và đối chiếu SL x giá). **Không dùng để tính doanh thu** | Tên gợi "giá công bố", có thể khác giá bán thực. Nhưng 155/157 dòng có Doanh số = SL x Giá niêm yết đúng từng đồng, và cùng một sản phẩm có nhiều mức giá ngay trong một kênh (mật ong 250ml, kênh Online: 185.000 và 194.000), nên nó hành xử như giá của từng dòng bán chứ không phải bảng giá cố định | **CẦN NGƯỜI QUYẾT**: kế toán NT xác nhận đây là giá bán thực tế của dòng, không phải giá trước chiết khấu. Tạm xử lý như trên, không ảnh hưởng tổng doanh thu vì tổng lấy từ Doanh số |
| `Doanh số (VNĐ)` | = thành tiền, được tính vào doanh thu | Căn cứ: tên nói rõ là doanh số bằng đồng; tổng cuối bảng G160 = 261.425.000 đúng bằng tổng cột này (157 dòng); 155/157 dòng bằng SL x giá; thang đơn vị là đồng chứ không phải nghìn đồng (giá cà phê 145.000 như T10; tổng T10 là 250.545.000, T11 là 261.425.000) | Khá chắc là tiền bán hàng. **CẦN NGƯỜI QUYẾT** nhỏ: file không cho biết số này trước hay sau VAT/chiết khấu, có cùng cơ sở với cột `Thành tiền` tháng 10 không. Tạm xử lý như `Thành tiền` cũ |

## 4. Hai dòng Doanh số lệch SL x Giá niêm yết (CẦN NGƯỜI QUYẾT)

Đều lệch đúng +50.000: `NT/0068` (dòng 70, Đại lý, 20 x 194.000 = 3.880.000, ghi 3.930.000) và `NT/0143` (dòng 147, Online, 30 x 220.000 = 6.600.000, ghi 6.650.000). Không biết là phí cộng thêm hay gõ sai (hai dòng khác kênh, khác sản phẩm).
Tạm xử lý: giữ số chi nhánh ghi (cùng quy tắc mọi chi nhánh khác), đưa vào `viec_can_hoi.csv` loại `LECH_THANH_TIEN`. Tổng ảnh hưởng: doanh thu NT sau bỏ lặp là 255.545.000, nếu tính theo SL x giá thì 255.445.000 (thấp hơn 100.000).

## 5. Điểm nhỏ khác

- Dòng ghi chú cuối vẫn nói "file xuất từ phần mềm cũ" dù file đã từ phần mềm mới. Có vẻ là câu mẫu chưa sửa; không chứa thông tin số liệu, script bỏ qua như tháng trước. Không cần quyết định gì, chỉ nêu để biết.
- Chi nhánh được nhận diện từ tên file (`NhaTrang`) và tiêu đề `NHA TRANG - T11/2026`; không đổi.

## 6. Đã sửa gì trong `gop.py`

1. Thêm tên cột mới vào bảng nhận diện (giữ nguyên tên cũ): `ma chung tu`, `gia niem yet`, `doanh so (vnd)`.
2. Thêm danh sách `COT_BO_QUA` (hiện chỉ `kenh ban`): cột này được phép có trong hàng tiêu đề và bị bỏ qua có báo. **Mọi cột lạ khác vẫn làm script dừng** (không đoán thầm).
3. Sửa một lỗi mà định dạng mới làm lộ ra: ở định dạng mới số chứng từ nằm cột A, cũng là cột chứa dòng ghi chú cuối bảng, nên dòng `Lưu ý: ...` bị tính nhầm thành một dòng dữ liệu thiếu số liệu (lần chạy đầu cho NT thêm 1 dòng `CAN_NGUOI_QUYET` 0 đồng và 1 việc cần hỏi vô nghĩa). Nay dòng chỉ có đúng một ô chữ dài từ 3 từ trở lên được xếp là ghi chú tự do. Số chứng từ thật (`NT/0001`, `HD89632`) không có khoảng trắng nên không bị nhầm; dòng chỉ có số chứng từ mà thiếu dữ liệu vẫn báo `THIEU_DU_LIEU` như cũ.

## 7. Kết quả kiểm tra

- Tháng 11 (`python gop.py goc ra --thang 2026-11`): chạy được, tổng doanh thu 1.503.750.000 đ, NT 155 dòng, 255.545.000 đ.
- Tổng NT file ghi (G160) 261.425.000, tổng hợp nhất 255.545.000, chênh 5.880.000 = đúng 2 dòng trùng hoàn toàn bị loại: `NT/0087` (dòng 90, 3.480.000) và `NT/0142` (dòng 146, 2.400.000). Tổng cuối bảng của chi nhánh đã gồm cả hai bản lặp. Đây là chênh lệch được giải thích hết, không còn dư.
- Kiểm độc lập (đọc file thô, bỏ mã chứng từ lặp, cộng cột Doanh số) cho 255.545.000, trùng khớp.
- Tháng 10 chạy lại bằng bản đã sửa (`python gop.py thang-truoc/goc ra_thu_thang10 --thang 2026-10`): 6 file, 913 dòng, tổng 1.523.468.000 đ, 27 việc cần hỏi. So với bản `gop.py` trước khi sửa chạy trên cùng dữ liệu, cả 7 file đầu ra giống hệt từng byte.
