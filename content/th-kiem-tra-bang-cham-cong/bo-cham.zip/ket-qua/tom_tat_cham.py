"""In tóm tắt kết quả chấm (gọi cham.py, không thay đổi cách chấm).

Chạy:
  python -X utf8 ket-qua/tom_tat_cham.py                         -> bảng của cả 7 lần chạy (đọc ket-qua/bao-cao-cham.json)
  python -X utf8 ket-qua/tom_tat_cham.py ket-qua/claude-lan1     -> chấm một thư mục đầu ra và in 4 dòng tóm tắt
"""
import json, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import cham as C

def dong(nhan, r):
    b, g, t = r["bat_thuong"], r["bang_cong_ngay"], r["tong_hop_nguoi"]
    return f"{nhan:<22} bất thường {b['dung']}/{b['dap_an']} (bịa {b['bia']}) | trạng thái ngày {g['trang_thai_dung']} | người đúng hết cột {t['dung_het_cot']}"

if len(sys.argv) > 1:
    d = Path(sys.argv[1]); print(dong(d.name, C.cham(d)))
else:
    for nhan, r in json.loads((HERE / "bao-cao-cham.json").read_text(encoding="utf-8")).items():
        print(dong(nhan, r))
