# -*- coding: utf-8 -*-
"""
tinh_bao_gia.py - Tính báo giá NHÁP cho 12 yêu cầu R01..R12 (công ty giả An Phát Demo).

Chạy:  python tinh_bao_gia.py            -> tạo dau-ra/Rxx-bao-gia.xlsx, Rxx-email.txt, Rxx-cau-hoi.txt, rồi kiểm tra
       python tinh_bao_gia.py --kiem-tra -> chỉ chạy phần kiểm tra trên các file đã tạo

Quy ước:
- Mọi phép tính tiền (bậc giá, thành tiền, chiết khấu, phí giao, VAT) do code này làm.
- Ghi vào xlsx GIÁ TRỊ SỐ, không dùng công thức.
- Làm tròn đến đồng, 0,5 làm tròn lên (ROUND_HALF_UP). Chiết khấu làm tròn MỘT lần trên tổng tiền
  hàng của các dòng được chiết khấu.
- Việc cần phán đoán (đọc yêu cầu, quy đổi đơn vị khách ghi, hàng không có mã, đề nghị vượt thẩm quyền)
  được nhập tay trong REQUESTS bên dưới; script chỉ quy đổi khi sheet QuyDoi có.
"""
import math
import re
import shutil
import sys
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "dau-ra"
F_BANGGIA = ROOT / "bang-gia.xlsx"
F_MAU = ROOT / "mau-bao-gia.xlsx"

# ----- Quy định lấy từ chinh-sach-chiet-khau.docx và dieu-kien-giao-hang.txt -----
NHOM_THIET_BI = "Thiết bị"
NGUONG_CK_2 = 10_000_000      # từ mức này: 2%
NGUONG_CK_4 = 30_000_000      # từ mức này: 4%
CK_NV_TOI_DA_THEM = 2         # % NV được đồng ý thêm
CK_NV_TONG_TOI_DA = 5         # % tổng NV được tự quyết
NGUONG_MIEN_PHI = 3_000_000   # nội thành: sau chiết khấu, trước VAT
PHI_GIAO_NOI_THANH = 40_000

HN_QUAN = ["ba đình", "hoàn kiếm", "đống đa", "hai bà trưng", "cầu giấy", "thanh xuân", "tây hồ",
           "long biên", "hoàng mai", "nam từ liêm", "bắc từ liêm", "hà đông"]
HCM_QUAN_SO = {1, 3, 5, 7, 10}
HCM_QUAN_TEN = ["bình thạnh", "phú nhuận", "tân bình", "gò vấp"]


def lam_tron(x):
    """Làm tròn đến đồng, 0,5 làm tròn lên."""
    return int(Decimal(x).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def so(n):
    """Định dạng số tiền kiểu Việt Nam: 1.234.567"""
    return f"{int(n):,}".replace(",", ".")


# ----------------------------------------------------------------------------------------
# Đọc dữ liệu nguồn
# ----------------------------------------------------------------------------------------
def doc_bang_gia():
    wb = openpyxl.load_workbook(F_BANGGIA, data_only=True)
    ws = wb["BangGia"]
    gia = {}
    for r in range(4, ws.max_row + 1):
        ma = ws.cell(r, 1).value
        if not ma:
            continue
        gia[ma] = dict(
            ten=ws.cell(r, 2).value, nhom=ws.cell(r, 3).value, dvt=ws.cell(r, 4).value,
            g1=ws.cell(r, 5).value, t2=ws.cell(r, 6).value, g2=ws.cell(r, 7).value,
            t3=ws.cell(r, 8).value, g3=ws.cell(r, 9).value, kho=ws.cell(r, 10).value,
        )
    qd = {}
    ws = wb["QuyDoi"]
    for r in range(3, ws.max_row + 1):
        ma, dv, k = ws.cell(r, 1).value, ws.cell(r, 2).value, ws.cell(r, 3).value
        if ma:
            qd[(ma, dv)] = k
    return gia, qd


def doc_tham_so():
    wb = openpyxl.load_workbook(F_MAU, data_only=True)
    ws = wb["Tham số"]
    p = {ws.cell(r, 1).value: ws.cell(r, 2).value for r in range(2, ws.max_row + 1)}
    ngay = date.fromisoformat(str(p["ngay_bao_gia"])[:10])
    return dict(vat=Decimal(str(p["vat_percent"])), ngay=ngay, hieu_luc=int(p["hieu_luc_ngay"]))


GIA, QUYDOI = doc_bang_gia()
THAM_SO = doc_tham_so()


# ----------------------------------------------------------------------------------------
# Tính tiền
# ----------------------------------------------------------------------------------------
def tra_bac(ma, sl):
    g = GIA[ma]
    if sl >= g["t3"]:
        return 3, g["g3"], f"Bậc 3 (từ {g['t3']} {g['dvt']})"
    if sl >= g["t2"]:
        return 2, g["g2"], f"Bậc 2 (từ {g['t2']} {g['dvt']})"
    return 1, g["g1"], f"Bậc 1 (dưới {g['t2']} {g['dvt']})"


def khu_vuc(dia_chi):
    """noi_thanh | ngoai_tinh | chua_biet - đối chiếu danh sách quận trong dieu-kien-giao-hang.txt"""
    if not dia_chi:
        return "chua_biet"
    s = dia_chi.lower()
    hn = "hà nội" in s or re.search(r"\bhn\b", s) is not None
    hcm = any(k in s for k in ("hồ chí minh", "tphcm", "tp.hcm", "hcm"))
    if hn and any(q in s for q in HN_QUAN):
        return "noi_thanh"
    if hcm:
        m = re.search(r"quận\s*(\d+)", s)
        if m and int(m.group(1)) in HCM_QUAN_SO:
            return "noi_thanh"
        if any(q in s for q in HCM_QUAN_TEN):
            return "noi_thanh"
    return "ngoai_tinh"


def tinh(lines, dia_chi, ck_them=0):
    """
    lines: danh sách (ma, so_luong, dvt_khach[, ghi_chu_them]); dvt_khach là đơn vị khách ghi.
    Quy đổi sang ĐVT gốc CHỈ khi sheet QuyDoi có; gộp dòng trùng mã; áp bậc theo SL của chính mã đó.
    ck_them: % chiết khấu thêm NV quyết (0..2).
    """
    gop = {}
    for ln in lines:
        ma, sl, dv = ln[0], ln[1], ln[2]
        extra = ln[3] if len(ln) > 3 else None
        if ma not in GIA:
            raise ValueError(f"Mã {ma} không có trong bảng giá")
        goc = GIA[ma]["dvt"]
        if dv == goc:
            sl_goc, qd_txt = sl, None
        elif (ma, dv) in QUYDOI:
            sl_goc = sl * QUYDOI[(ma, dv)]
            qd_txt = f"{sl} {dv} = {sl_goc} {goc}"
        else:
            raise ValueError(f"Không có quy đổi {dv}->{goc} cho {ma}")
        d = gop.setdefault(ma, dict(sl=0, phan=[], extra=[]))
        d["sl"] += sl_goc
        d["phan"].append((sl, dv, qd_txt))
        if extra:
            d["extra"].append(extra)

    dong = []
    for ma, d in gop.items():
        g = GIA[ma]
        sl = d["sl"]
        bac, don_gia, bac_txt = tra_bac(ma, sl)
        tt = sl * don_gia
        ghi = [bac_txt]
        if len(d["phan"]) > 1:
            ghi.append("Gộp dòng trùng: " + " + ".join(
                (f"{s} {v}" + (f" (= {qd.split('= ')[1]})" if qd else "")) for s, v, qd in d["phan"])
                + f" = {sl} {g['dvt']}")
        elif d["phan"][0][2]:
            ghi.append("Quy đổi: " + d["phan"][0][2])
        if g["kho"] != "Còn hàng":
            ghi.append(f"Kho: {g['kho']} - ngày có hàng do thủ kho/phòng mua hàng xác nhận")
        next_t = g["t3"] if bac == 2 else (g["t2"] if bac == 1 else None)
        if next_t and 0 < next_t - sl <= 1:
            ghi.append(f"Thiếu {next_t - sl} {g['dvt']} để đạt bậc giá tiếp theo")
        ghi += d["extra"]
        dong.append(dict(ma=ma, ten=g["ten"], dvt=g["dvt"], sl=sl, don_gia=don_gia, tt=tt,
                         nhom=g["nhom"], bac=bac, ghi="; ".join(ghi)))

    tien_hang = sum(x["tt"] for x in dong)
    co_thiet_bi = any(x["nhom"] == NHOM_THIET_BI for x in dong)
    co_ck_nhom = any(x["nhom"] != NHOM_THIET_BI for x in dong)
    co_so_tiet = sum(x["tt"] for x in dong if x["nhom"] != NHOM_THIET_BI)   # tiền hàng được chiết khấu
    if tien_hang >= NGUONG_CK_4:
        pct_don = 4
    elif tien_hang >= NGUONG_CK_2:
        pct_don = 2
    else:
        pct_don = 0
    assert 0 <= ck_them <= CK_NV_TOI_DA_THEM
    pct = pct_don + ck_them
    assert pct <= CK_NV_TONG_TOI_DA, "Chiết khấu vượt thẩm quyền NV"
    ck = lam_tron(Decimal(co_so_tiet) * Decimal(pct) / 100)

    kv = khu_vuc(dia_chi)
    sau_ck = tien_hang - ck
    if kv == "noi_thanh":
        phi = 0 if sau_ck >= NGUONG_MIEN_PHI else PHI_GIAO_NOI_THANH
    else:
        phi = None                                   # theo thỏa thuận / chưa biết địa chỉ
    truoc_vat = sau_ck + (phi or 0)
    vat = lam_tron(Decimal(truoc_vat) * THAM_SO["vat"] / 100)
    tong = truoc_vat + vat
    return dict(dong=dong, tien_hang=tien_hang, pct_don=pct_don, ck_them=ck_them, pct=pct, ck=ck,
                co_so_ck=co_so_tiet, co_thiet_bi=co_thiet_bi, co_ck_nhom=co_ck_nhom, kv=kv, phi=phi,
                sau_ck=sau_ck, truoc_vat=truoc_vat, vat=vat, tong=tong)


# ----------------------------------------------------------------------------------------
# 12 yêu cầu - phần đọc hiểu do người/agent nhập (không có phép tính tiền ở đây)
# ----------------------------------------------------------------------------------------
REQUESTS = [
    dict(id="R01",
         khach="Chị Lan - Phòng Hành chính, Công ty TNHH Cơ khí Ánh Dương (lan.mua.hang@example.com)",
         chao="chị Lan",
         dia_chi="12 Đường Số 5, Quận Hà Đông, Hà Nội",
         lines=[("GIAY-A4-80", 25, "ram"), ("BUT-BI-TL027-XANH", 3, "hộp"), ("BANGKEO-TRONG-48", 10, "cuộn")],
         ck_them=2,
         ck_them_txt="khách xin giảm 2% (khách quen) - trong thẩm quyền NV, tổng chiết khấu không vượt 5%",
         chua=[], quyet=[], hoi=[], luu_y=[]),
    dict(id="R02",
         khach="Anh Dung Phat (Zalo)", chao="anh Dung Phat", dia_chi=None,
         lines=[("MUC-HP-12A", 6, "hộp")],
         chua=[("Giấy A4 80gsm (GIAY-A4-80)", "khách chưa nêu số lượng")],
         quyet=[],
         hoi=["Anh cần giấy A4 80gsm với số lượng bao nhiêu ram?",
              "Anh cho biết địa chỉ giao hàng (quận/huyện, tỉnh/thành phố) để chúng tôi tính phí giao hàng.",
              "Anh nói \"chiều anh cần\": anh cần nhận báo giá trong chiều nay hay cần nhận hàng trong chiều nay? "
              "(Nếu cần hàng gấp, chúng tôi sẽ chuyển trưởng kho/giám đốc xem xét; chưa thể hứa ngày giờ giao.)",
              "Anh cho biết tên công ty/đơn vị để ghi vào báo giá."],
         luu_y=[]),
    dict(id="R03",
         khach="Quý khách (hanh.vp@example.com) - chưa rõ tên/đơn vị", chao="Quý khách",
         dia_chi="Tòa nhà Mẫu số 3, đường Demo, Quận Cầu Giấy, Hà Nội",
         lines=[("GIAY-A4-80", 10, "ram"), ("MUC-HP-12A", 3, "hộp")],
         chua=[("MUC-HP-12C - 4 hộp", "mã này không có trong bảng giá, chưa tự đoán sang mã khác"),
               ("BUT-GEL-05-XANH (bút gel xanh) - 2 hộp",
                "mã này không có trong bảng giá (bảng giá chỉ có bút gel mực đen BUT-GEL-05-DEN), chưa tự thay hàng khác")],
         quyet=[],
         hoi=["Mã MUC-HP-12C không có trong bảng giá của chúng tôi. Anh/chị vui lòng kiểm tra lại mã/loại mực cần mua "
              "và số lượng.",
              "Mã BUT-GEL-05-XANH không có trong bảng giá (hiện chỉ có bút gel mực đen 0.5 mm, mã BUT-GEL-05-DEN). "
              "Anh/chị cho biết đúng mã hàng cần mua và số lượng (hộp hay cây).",
              "Anh/chị cho biết tên công ty/đơn vị để ghi vào báo giá."],
         luu_y=["Nếu mã MUC-HP-12C thực chất trùng mặt hàng đã báo, chúng tôi sẽ gộp số lượng và tính lại bậc giá."]),
    dict(id="R04",
         khach="Quý trường (mai.hanhchinh@example.com)", chao="Quý trường",
         dia_chi="25 Đường Mẫu, Quận 7, TP. Hồ Chí Minh",
         lines=[("GIAY-A4-70", 30, "ram")],
         chua=[("Máy photocopy A3 đa năng - 1 cái", "chưa có trong bảng giá"),
               ("Máy chiếu độ phân giải 4K - 2 cái", "chưa có trong bảng giá")],
         quyet=["Hai mặt hàng chưa có trong bảng giá: sẽ chuyển phòng mua hàng xem có nhập được không. "
                "Sẽ có xác nhận sau; chúng tôi không tự đặt giá hay thay bằng hàng khác.",
                "Yêu cầu giao gấp trong tuần: sẽ chuyển trưởng kho/giám đốc xem xét. Sẽ có xác nhận lịch giao của "
                "kho bằng văn bản; chúng tôi chưa thể hứa ngày, giờ giao cụ thể."],
         hoi=[], luu_y=[]),
    dict(id="R05",
         khach="Quý khách (quan.vt@example.com)", chao="Quý khách",
         dia_chi="88 Đường Demo, Quận Thanh Xuân, Hà Nội",
         lines=[("MAY-IN-LASER-3100", 3, "cái"), ("MUC-HP-78A", 10, "hộp"), ("GIAY-A4-80", 40, "ram")],
         chua=[],
         quyet=["Đề nghị giảm 25% tổng đơn vượt thẩm quyền của nhân viên: sẽ chuyển trưởng phòng/giám đốc kinh doanh. "
                "Sẽ có xác nhận. Báo giá này chỉ áp chiết khấu theo chính sách."],
         hoi=[], luu_y=["Máy in laser là hàng đặt: ngày có hàng sẽ do kho/phòng mua hàng xác nhận bằng văn bản."]),
    dict(id="R06",
         khach="Chị Thu - NT Phu Gia (Zalo)", chao="chị Thu",
         dia_chi="5 Đường Mẫu, Quận 10, TP. Hồ Chí Minh",
         lines=[("GIAY-A4-70", 2, "thùng"), ("BUT-BI-TL027-XANH", 5, "tá"), ("BANGKEO-2MAT-24", 3, "lốc"),
                ("BUT-GEL-05-DEN", 2, "hộp")],
         chua=[("1 thùng mực HP 12A (MUC-HP-12A)",
                "bảng quy đổi chưa có quy đổi \"thùng\" cho mã này nên chưa tự suy ra số hộp")],
         quyet=[],
         hoi=["1 thùng mực HP 12A gồm bao nhiêu hộp? Chị cho biết số lượng cần mua tính theo hộp "
              "(bảng giá của chúng tôi tính theo hộp)."],
         luu_y=[]),
    dict(id="R07",
         khach="Quý khách (kien.kho@example.com)", chao="Quý khách",
         dia_chi="15 Đường Mẫu, Quận Gò Vấp, TP. Hồ Chí Minh",
         lines=[("BUT-BI-TL027-XANH", 50, "cây"), ("SO-CARO-A4-200", 49, "quyển"), ("FILE-COC-7P", 100, "cái")],
         chua=[],
         quyet=["Đề nghị giữ giá cũ 3.500 đ/cây cho bút bi xanh TL027: chúng tôi báo theo bảng giá hiện hành "
                "(4.000 đ/cây ở số lượng này) và sẽ chuyển trưởng phòng kinh doanh xem xét. Sẽ có xác nhận; "
                "chúng tôi chưa thể xác nhận mức giá đã báo trước đó."],
         hoi=[],
         luu_y=["Sổ caro A4 200 trang: bảng giá có bậc giá thấp hơn từ 50 quyển (khách đặt 49 quyển)."]),
    dict(id="R08",
         khach="Quý khách - Xưởng (phuong.xuong@example.com)", chao="Quý khách",
         dia_chi="Lô B2, Khu công nghiệp Mẫu, Bắc Ninh",
         lines=[("THUNG-CARTON-30X20X20", 300, "cái"), ("MANG-BOC-PE-50CM", 24, "cuộn"),
                ("BANGKEO-TRONG-48", 72, "cuộn")],
         chua=[],
         quyet=["Giao hàng đến Bắc Ninh (ngoại tỉnh): phí vận chuyển theo cước của đơn vị vận chuyển, do nhân viên "
                "điều phối báo sau; báo giá ghi \"phí giao hàng theo thỏa thuận\". Sẽ có xác nhận.",
                "Yêu cầu giao trước 10 giờ sáng thứ Sáu: sẽ chuyển trưởng kho/giám đốc xem xét. Sẽ có xác nhận lịch "
                "giao của kho bằng văn bản; chúng tôi chưa thể cam kết ngày, giờ giao."],
         hoi=[], luu_y=[]),
    dict(id="R09",
         khach="Chu Son (Zalo)", chao="chú", dia_chi=None,
         lines=[],
         chua=[("Toàn bộ yêu cầu", "chưa biết mặt hàng, số lượng \"đợt trước\" và địa chỉ giao; chưa có dữ liệu để lập dòng hàng")],
         quyet=[],
         hoi=["Chú vui lòng gửi lại danh sách mặt hàng (mã hàng) và số lượng của đợt trước, hoặc số báo giá/đơn hàng cũ.",
              "\"Tăng gấp đôi\" là gấp đôi số lượng từng mặt hàng của đợt trước, đúng không ạ? Chú xác nhận số lượng mới cho từng mặt hàng.",
              "\"Chỗ cũ\" là địa chỉ nào? Chú cho biết địa chỉ giao hàng cụ thể (quận/huyện, tỉnh/thành phố).",
              "Chú có yêu cầu giữ nguyên đơn giá của đợt trước không? (Báo giá của chúng tôi theo bảng giá hiện hành; "
              "nếu chú muốn giữ giá cũ, chúng tôi sẽ chuyển trưởng phòng kinh doanh xem xét.)"],
         luu_y=[]),
    dict(id="R10",
         khach="Ngoc SaoMai (Zalo)", chao="Ngoc SaoMai",
         dia_chi="30 Đường Demo, Cầu Giấy, Hà Nội",
         lines=[("MUC-HP-78A", 4, "hộp"), ("GIAY-A4-70", 10, "ram"), ("MAY-HUY-GIAY-S12", 1, "cái"),
                ("GHE-XOAY-LUOI-01", 6, "cái"), ("MUC-EPS-664-DEN", 12, "chai"),
                ("MUC-HP-78A", 2, "hộp"), ("GIAY-A4-70", 1, "thùng")],
         ck_them=2,
         ck_them_txt="khách xin giảm thêm 2% - trong thẩm quyền NV, tổng chiết khấu 4% không vượt 5%; "
                     "chỉ áp cho dòng không thuộc nhóm Thiết bị",
         chua=[], quyet=[], hoi=[], luu_y=[]),
    dict(id="R11",
         khach="Quý khách (hung.mua@example.com) - văn phòng mới", chao="Quý khách",
         dia_chi="200 Đường Mẫu, Quận Hoàng Mai, Hà Nội",
         lines=[("MAY-IN-LASER-3100", 6, "cái"), ("MAY-SCAN-A4-100", 2, "cái"),
                ("CC-VANTAY-01", 4, "cái",
                 "Khách không ghi mẫu; bảng giá chỉ có mẫu 01 - người duyệt xác nhận"),
                ("GIAY-A4-80", 60, "ram"), ("MUC-CANON-325", 12, "hộp")],
         chua=[],
         quyet=["Đề nghị giảm 10% toàn đơn vượt thẩm quyền của nhân viên: sẽ chuyển trưởng phòng/giám đốc. Sẽ có xác nhận. "
                "Báo giá này chỉ áp chiết khấu theo chính sách.",
                "Đề nghị mua 10 ram giấy tặng 1 ram (quà tặng/khuyến mại): chỉ giám đốc quyết, sẽ chuyển lên. Sẽ có xác nhận."],
         hoi=[],
         luu_y=["Mực Canon 325 hiện tạm hết hàng, chờ nhập; các máy in, máy scan là hàng đặt: ngày có hàng do "
                "thủ kho/phòng mua hàng xác nhận bằng văn bản.",
                "Máy chấm công vân tay: chúng tôi báo theo mẫu 01 (mẫu duy nhất trong bảng giá); nếu cần mẫu khác xin báo lại."]),
    dict(id="R12",
         khach="Vy Sohong (Zalo)", chao="Vy Sohong",
         dia_chi="7 Đường Mẫu, Quận Bắc Từ Liêm, Hà Nội",
         lines=[("GIAY-A4-70", 5, "thùng"), ("BUT-BI-TL027-XANH", 2, "tá"), ("DECAL-A4-100", 3, "xấp"),
                ("MANG-BOC-PE-50CM", 2, "cuộn"), ("KEP-BUOM-32", 4, "hộp")],
         chua=[],
         quyet=["Đề nghị công nợ 30 ngày: chỉ giám đốc duyệt, sẽ chuyển lên. Sẽ có xác nhận; mặc định thanh toán "
                "chuyển khoản trước khi giao hàng."],
         hoi=["Để xuất hóa đơn công ty, anh/chị vui lòng cung cấp: tên công ty, mã số thuế, địa chỉ xuất hóa đơn."],
         luu_y=["Mức thuế và cách xuất hóa đơn do kế toán xác nhận."]),
]


def trang_thai(r):
    st = []
    if r["hoi"]:
        st.append("THIEU_THONG_TIN")
    if r["quyet"]:
        st.append("CAN_NGUOI_QUYET")
    return st or ["SAN_SANG"]


# ----------------------------------------------------------------------------------------
# Ghi xlsx theo mẫu
# ----------------------------------------------------------------------------------------
HANG_DAU, HANG_CUOI = 14, 28
ROW_TONG = dict(hang=29, ck=30, phi=31, truoc_vat=32, vat=33, tong=34)


def ngay_str(d):
    return d.strftime("%d/%m/%Y")


def so_dong(text, width):
    return max(1, math.ceil(len(str(text)) / width)) if text else 1


def ghi_chu_ck(r, kq):
    if kq["ck"] == 0 and kq["pct"] == 0:
        if kq["tien_hang"] < NGUONG_CK_2:
            return "Không có chiết khấu theo giá trị đơn (đơn dưới 10.000.000 đ)"
        return "Không có chiết khấu (chỉ có dòng nhóm Thiết bị)"
    parts = []
    if kq["pct_don"]:
        parts.append(f"{kq['pct_don']}% theo giá trị đơn hàng")
    if kq["ck_them"]:
        parts.append(f"{kq['ck_them']}% NV quyết thêm ({r.get('ck_them_txt', '')})")
    txt = f"{kq['pct']}% = " + " + ".join(parts) + f", tính trên {so(kq['co_so_ck'])} đ tiền hàng không thuộc nhóm Thiết bị. Số tiền trừ vào giá."
    if kq["co_thiet_bi"]:
        txt += " Dòng nhóm Thiết bị giữ giá bảng giá."
    return txt


def ghi_chu_phi(kq):
    kv = kq["kv"]
    if kv == "noi_thanh":
        if kq["phi"] == 0:
            return f"Miễn phí (nội thành, đơn sau chiết khấu từ {so(NGUONG_MIEN_PHI)} đ)"
        return (f"Nội thành, đơn sau chiết khấu dưới {so(NGUONG_MIEN_PHI)} đ: {so(PHI_GIAO_NOI_THANH)} đ/đơn "
                "(cộng vào trước VAT; kế toán kiểm cách tính thuế dòng phí này)")
    if kv == "ngoai_tinh":
        return "Phí giao hàng theo thỏa thuận (ngoại thành/ngoại tỉnh, theo cước vận chuyển) - CẦN NGƯỜI QUYẾT; chưa tính vào tổng cộng"
    return "Chưa tính phí giao hàng vì chưa biết địa chỉ giao - đã hỏi khách; chưa tính vào tổng cộng"


def ghi_xlsx(r, kq, status):
    dst = OUT / f"{r['id']}-bao-gia.xlsx"
    shutil.copyfile(F_MAU, dst)
    wb = openpyxl.load_workbook(dst)
    ws = wb["Báo giá"]
    top_wrap = Alignment(wrap_text=True, vertical="top")

    ws["C5"] = r["khach"]
    ws["C6"] = r["dia_chi"] or "(chưa có - cần hỏi khách)"
    ws["C7"] = f"{r['id']} (yeu-cau/{r['id']}.txt)"
    d0 = THAM_SO["ngay"]
    ws["C8"] = (f"{ngay_str(d0)} / hiệu lực {THAM_SO['hieu_luc']} ngày "
                f"(đến hết {ngay_str(d0 + timedelta(days=THAM_SO['hieu_luc']))})")
    ws["C9"] = ";".join(status)
    ws["C10"] = None                                   # để trống, người thật điền

    # Ghi chú trên bảng: mục chưa báo giá / việc chờ quyết (dùng 2 dòng trống 11-12 của mẫu)
    if r["chua"]:
        txt = "Mục CHƯA báo giá: " + "; ".join(f"{a} - {b}" for a, b in r["chua"]) + "."
        ws["A11"] = txt
        ws.merge_cells("A11:H11")
        ws["A11"].alignment = top_wrap
        ws.row_dimensions[11].height = 15 * so_dong(txt, 140)
    if r["quyet"] or r["hoi"]:
        parts = []
        if r["quyet"]:
            parts.append("CẦN NGƯỜI QUYẾT: " + " | ".join(r["quyet"]))
        if r["hoi"]:
            parts.append(f"CẦN HỎI KHÁCH: {len(r['hoi'])} câu (xem {r['id']}-cau-hoi.txt)")
        txt = " ".join(parts)
        ws["A12"] = txt
        ws.merge_cells("A12:H12")
        ws["A12"].alignment = top_wrap
        ws.row_dimensions[12].height = 15 * so_dong(txt, 140)

    assert len(kq["dong"]) <= HANG_CUOI - HANG_DAU + 1
    for i, x in enumerate(kq["dong"]):
        row = HANG_DAU + i
        vals = [i + 1, x["ma"], x["ten"], x["dvt"], x["sl"], x["don_gia"], x["tt"], x["ghi"]]
        for c, v in enumerate(vals, start=1):
            cell = ws.cell(row, c, v)
            cell.alignment = top_wrap
        ws.cell(row, 6).number_format = "#,##0"
        ws.cell(row, 7).number_format = "#,##0"
        ws.row_dimensions[row].height = 15 * max(so_dong(x["ghi"], 36), so_dong(x["ten"], 40))

    vat_pct = THAM_SO["vat"].normalize()
    muc = {
        "hang": (kq["tien_hang"], "Tổng tiền hàng các dòng đã báo giá" if r["chua"] else "Tổng tiền hàng"),
        "ck": (kq["ck"], ghi_chu_ck(r, kq)),
        "phi": (kq["phi"], ghi_chu_phi(kq)),
        "truoc_vat": (kq["truoc_vat"], "Cộng tiền hàng - Chiết khấu + Phí giao hàng"),
        "vat": (kq["vat"], f"{vat_pct:f}% - mức VAT theo tham số, cần kiểm với kế toán trước khi gửi"),
        "tong": (kq["tong"], "Cộng trước VAT + VAT"
                 + ("; CHƯA gồm phí giao hàng và các mục chưa báo giá" if (kq["phi"] is None or r["chua"]) else "")),
    }
    for k, (val, note) in muc.items():
        row = ROW_TONG[k]
        ws.cell(row, 7, val).number_format = "#,##0"
        ws.cell(row, 8, note).alignment = top_wrap
        ws.cell(row, 7).alignment = Alignment(vertical="top")
        ws.cell(row, 6).alignment = Alignment(horizontal="right", vertical="top")
        ws.row_dimensions[row].height = 15 * so_dong(note, 36)
    wb.save(dst)


# ----------------------------------------------------------------------------------------
# Email nháp và câu hỏi
# ----------------------------------------------------------------------------------------
def viet_email(r, kq, status):
    d0 = THAM_SO["ngay"]
    han = d0 + timedelta(days=THAM_SO["hieu_luc"])
    vat_pct = f"{THAM_SO['vat'].normalize():f}"
    L = []
    L.append("[NHÁP - chờ người duyệt, chưa gửi khách]")
    L.append(f"Tiêu đề: Báo giá theo yêu cầu {r['id']} - An Phát Demo")
    L.append("")
    L.append(f"Kính gửi {r['chao']},")
    L.append("")
    L.append("Cảm ơn anh/chị đã gửi yêu cầu báo giá cho An Phát Demo. Chúng tôi xin gửi báo giá "
             f"(file đính kèm {r['id']}-bao-gia.xlsx) như sau:")
    L.append("")
    L.append("1. Mặt hàng đã báo giá")
    if kq["dong"]:
        for x in kq["dong"]:
            L.append(f"- {x['ten']} ({x['ma']}): {x['sl']} {x['dvt']} x {so(x['don_gia'])} đ = {so(x['tt'])} đ"
                     + (f" [{x['ghi'].split('; ')[1]}]" if "; " in x["ghi"] and x["ghi"].split("; ")[1].startswith(("Quy đổi", "Gộp")) else ""))
        L.append(f"- Cộng tiền hàng: {so(kq['tien_hang'])} đ")
        if kq["ck"]:
            L.append(f"- Chiết khấu {kq['pct']}% (áp cho hàng không thuộc nhóm Thiết bị): -{so(kq['ck'])} đ")
        else:
            L.append("- Chiết khấu: không có (theo chính sách hiện hành)")
        if kq["phi"] is None:
            L.append("- Phí giao hàng: " + ("theo thỏa thuận (giao ngoại tỉnh, tính theo cước vận chuyển), sẽ có xác nhận"
                                          if kq["kv"] == "ngoai_tinh" else "chưa tính vì chưa có địa chỉ giao"))
        elif kq["phi"] == 0:
            L.append("- Phí giao hàng: miễn phí (nội thành)")
        else:
            L.append(f"- Phí giao hàng (nội thành): {so(kq['phi'])} đ")
        L.append(f"- Cộng trước VAT: {so(kq['truoc_vat'])} đ")
        L.append(f"- VAT {vat_pct}% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi): {so(kq['vat'])} đ")
        L.append(f"- Tổng cộng: {so(kq['tong'])} đ"
                 + (" (chưa gồm phí giao hàng và các mục chưa báo giá bên dưới)" if (kq["phi"] is None or r["chua"]) else ""))
    else:
        L.append("- Hiện chưa có mặt hàng nào đủ thông tin để báo giá (chưa tính tiền hàng, phí giao hàng, VAT).")
        L.append(f"- VAT khi báo giá sẽ tính theo mức {vat_pct}% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi).")
    n = 2
    if r["chua"]:
        L.append("")
        L.append(f"{n}. Mặt hàng chưa báo giá")
        for a, b in r["chua"]:
            L.append(f"- {a}: {b}.")
        n += 1
    if r["quyet"]:
        L.append("")
        L.append(f"{n}. Nội dung đang chờ cấp có thẩm quyền")
        for q in r["quyet"]:
            L.append(f"- {q}")
        n += 1
    if r["hoi"]:
        L.append("")
        L.append(f"{n}. Anh/chị vui lòng cho chúng tôi biết thêm")
        for i, q in enumerate(r["hoi"], 1):
            L.append(f"   {i}) {q}")
        n += 1
    L.append("")
    L.append("Lưu ý chung:")
    for lu in r["luu_y"]:
        L.append(f"- {lu}")
    L.append("- Thời gian giao hàng sẽ có xác nhận của kho bằng văn bản; báo giá này không phải cam kết ngày giao.")
    L.append("- Thanh toán mặc định: chuyển khoản trước khi giao hàng.")
    L.append(f"- Báo giá có hiệu lực {THAM_SO['hieu_luc']} ngày, từ {ngay_str(d0)} đến hết {ngay_str(han)}.")
    L.append("")
    L.append("Trân trọng,")
    L.append("[Tên người xử lý - người duyệt điền] | Công ty TNHH An Phát Demo")
    return "\n".join(L) + "\n"


def viet_cau_hoi(r):
    if not r["hoi"]:
        return "Không có câu hỏi\n"
    return "\n".join(f"{i}. {q}" for i, q in enumerate(r["hoi"], 1)) + "\n"


# ----------------------------------------------------------------------------------------
# Kiểm tra độc lập: đọc lại các file xlsx đã ghi
# ----------------------------------------------------------------------------------------
def kiem_tra():
    loi = []
    tom_tat = []
    vat_pct = THAM_SO["vat"]
    for r in REQUESTS:
        rid = r["id"]
        p = OUT / f"{rid}-bao-gia.xlsx"
        for suffix in ("email.txt", "cau-hoi.txt"):
            if not (OUT / f"{rid}-{suffix}").exists():
                loi.append(f"{rid}: thiếu file {suffix}")
        wb = openpyxl.load_workbook(p)                      # không data_only: phải là số, không phải công thức
        ws = wb["Báo giá"]
        # tiêu đề cột và nhãn dòng tổng còn nguyên
        hdr = [ws.cell(13, c).value for c in range(1, 9)]
        if hdr != ["STT", "Mã hàng", "Tên hàng", "ĐVT", "Số lượng", "Đơn giá (VNĐ)", "Thành tiền (VNĐ)", "Ghi chú"]:
            loi.append(f"{rid}: tiêu đề cột sai {hdr}")
        for k, lab in zip(ROW_TONG.values(), ["Cộng tiền hàng", "Chiết khấu", "Phí giao hàng", "Cộng trước VAT", "VAT", "Tổng cộng"]):
            if ws.cell(k, 6).value != lab:
                loi.append(f"{rid}: nhãn dòng {k} sai")
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, str) and c.value.startswith("="):
                    loi.append(f"{rid}: có công thức ở {c.coordinate}")
        # dòng hàng
        lines = []
        for row in range(HANG_DAU, HANG_CUOI + 1):
            if ws.cell(row, 2).value:
                lines.append([ws.cell(row, c).value for c in range(1, 9)])
        if len(lines) != len({l[1] for l in lines}):
            loi.append(f"{rid}: còn dòng trùng mã")
        # số dòng kỳ vọng = số mã khác nhau trong yêu cầu đã nhập
        ky_vong = len({ln[0] for ln in r["lines"]})
        if len(lines) != ky_vong:
            loi.append(f"{rid}: số dòng {len(lines)} != {ky_vong}")
        tong_hang = 0
        co_so = 0
        for stt, ma, ten, dvt, sl, dg, tt, ghi in lines:
            g = GIA.get(ma)
            if g is None:
                loi.append(f"{rid}: mã {ma} không có trong bảng giá")
                continue
            exp = g["g3"] if sl >= g["t3"] else g["g2"] if sl >= g["t2"] else g["g1"]
            if dg != exp:
                loi.append(f"{rid} {ma}: đơn giá {dg} != bậc giá {exp}")
            if tt != sl * dg:
                loi.append(f"{rid} {ma}: thành tiền {tt} != {sl}x{dg}")
            if dvt != g["dvt"]:
                loi.append(f"{rid} {ma}: ĐVT {dvt} != ĐVT gốc {g['dvt']}")
            tong_hang += tt
            if g["nhom"] != NHOM_THIET_BI:
                co_so += tt
        v = {k: ws.cell(row, 7).value for k, row in ROW_TONG.items()}
        if v["hang"] != tong_hang:
            loi.append(f"{rid}: Cộng tiền hàng {v['hang']} != tổng dòng {tong_hang}")
        pd = 4 if tong_hang >= NGUONG_CK_4 else 2 if tong_hang >= NGUONG_CK_2 else 0
        cho_phep = {lam_tron(Decimal(co_so) * (pd + t) / 100) for t in (0, CK_NV_TOI_DA_THEM)}
        if v["ck"] not in cho_phep:
            loi.append(f"{rid}: chiết khấu {v['ck']} không thuộc {sorted(cho_phep)}")
        if v["ck"] > lam_tron(Decimal(co_so) * CK_NV_TONG_TOI_DA / 100):
            loi.append(f"{rid}: chiết khấu vượt 5%")
        phi = v["phi"]
        if phi not in (None, 0, PHI_GIAO_NOI_THANH):
            loi.append(f"{rid}: phí giao lạ {phi}")
        if phi == 0 and tong_hang - v["ck"] < NGUONG_MIEN_PHI:
            loi.append(f"{rid}: miễn phí giao sai ngưỡng")
        if phi == PHI_GIAO_NOI_THANH and tong_hang - v["ck"] >= NGUONG_MIEN_PHI:
            loi.append(f"{rid}: thu phí giao sai ngưỡng")
        tv = tong_hang - v["ck"] + (phi or 0)
        if v["truoc_vat"] != tv:
            loi.append(f"{rid}: Cộng trước VAT {v['truoc_vat']} != {tv}")
        vat = lam_tron(Decimal(tv) * vat_pct / 100)
        if v["vat"] != vat:
            loi.append(f"{rid}: VAT {v['vat']} != {vat}")
        if v["tong"] != tv + vat:
            loi.append(f"{rid}: Tổng cộng {v['tong']} != {tv + vat}")
        for k, x in v.items():
            if k != "phi" and not isinstance(x, int):
                loi.append(f"{rid}: ô tổng {k} không phải số nguyên: {x!r}")
        # phí giao đúng khu vực
        kv = khu_vuc(r["dia_chi"])
        if kv != "noi_thanh" and phi is not None:
            loi.append(f"{rid}: có phí giao dù khu vực {kv}")
        if kv == "noi_thanh" and phi is None:
            loi.append(f"{rid}: nội thành mà thiếu phí giao")
        # trạng thái
        st = str(ws["C9"].value).split(";")
        if not st or any(s not in ("SAN_SANG", "THIEU_THONG_TIN", "CAN_NGUOI_QUYET") for s in st):
            loi.append(f"{rid}: trạng thái lạ {st}")
        if "SAN_SANG" in st and len(st) > 1:
            loi.append(f"{rid}: SAN_SANG lẫn trạng thái khác")
        if (OUT / f"{rid}-cau-hoi.txt").exists():
            ch = (OUT / f"{rid}-cau-hoi.txt").read_text(encoding="utf-8").strip().splitlines()
            if ("THIEU_THONG_TIN" in st) == (ch == ["Không có câu hỏi"]):
                loi.append(f"{rid}: file câu hỏi không khớp trạng thái")
        email = (OUT / f"{rid}-email.txt").read_text(encoding="utf-8") if (OUT / f"{rid}-email.txt").exists() else ""
        if "mức VAT theo tham số, cần kiểm với kế toán trước khi gửi" not in email:
            loi.append(f"{rid}: email thiếu câu về VAT")
        if "mức VAT theo tham số, cần kiểm với kế toán trước khi gửi" not in str(ws["H33"].value):
            loi.append(f"{rid}: báo giá thiếu câu về VAT")
        tom_tat.append((rid, ";".join(st), v["tong"], len(lines)))
    return loi, tom_tat


def in_tom_tat(tom_tat):
    print(f"{'Mã':<5} {'Trạng thái':<34} {'Số dòng':>7} {'Tổng cộng (VNĐ)':>17}")
    print("-" * 66)
    for rid, st, tong, n in tom_tat:
        print(f"{rid:<5} {st:<34} {n:>7} {so(tong):>17}")


def main():
    if "--kiem-tra" not in sys.argv:
        OUT.mkdir(exist_ok=True)
        for r in REQUESTS:
            kq = tinh(r["lines"], r["dia_chi"], r.get("ck_them", 0))
            st = trang_thai(r)
            ghi_xlsx(r, kq, st)
            (OUT / f"{r['id']}-email.txt").write_text(viet_email(r, kq, st), encoding="utf-8")
            (OUT / f"{r['id']}-cau-hoi.txt").write_text(viet_cau_hoi(r), encoding="utf-8")
            print(f"{r['id']}: khu vực={kq['kv']}, tiền hàng={so(kq['tien_hang'])}, CK={so(kq['ck'])} ({kq['pct']}%), "
                  f"phí={kq['phi']}, VAT={so(kq['vat'])}, tổng={so(kq['tong'])}")
    loi, tom_tat = kiem_tra()
    print()
    if loi:
        print("LỖI KIỂM TRA:")
        for x in loi:
            print(" -", x)
    else:
        print("Kiểm tra: ĐẠT (số dòng, thành tiền = SL x đơn giá, bậc giá, tổng khớp, không có công thức).")
    print()
    in_tom_tat(tom_tat)
    return 1 if loi else 0


if __name__ == "__main__":
    sys.exit(main())
