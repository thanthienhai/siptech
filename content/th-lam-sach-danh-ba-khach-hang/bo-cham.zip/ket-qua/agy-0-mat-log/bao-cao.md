# Báo Cáo Làm Sạch & Hợp Nhất Danh Bạ Khách Hàng

## 1. Số liệu tổng quan trước và sau làm sạch
- **Dữ liệu gốc (`danh-ba-goc.xlsx`)**: 400 dòng gom từ 5 nguồn (Zalo, Shopee, TikTok Shop, Sổ tay, Phần mềm bán hàng).
  - *Tình trạng khuyết dữ liệu gốc*: SĐT trống 24 ô, Email trống 217 ô, Địa chỉ trống 122 ô, Ghi chú trống 218 ô.
  - *Lỗi cấu trúc*: 3 dòng bị đảo cột Họ tên và Địa chỉ (R185, R241, R345); 2 dòng Email nằm ở SĐT (R045, R291); 4 dòng SĐT nằm ở Email (R152, R202, R325, R376); 7 dòng SĐT nằm ở Ghi chú (R014, R077, R199, R226, R285, R342, R390).
- **Dữ liệu sạch (`danh-ba-sach.xlsx`)**: Còn **343 khách hàng** duy nhất (`KH001` – `KH343`).
  - *Tự kiểm tra toàn vẹn*: 343 dòng sạch + 57 dòng gộp = 400 dòng gốc (đạt 100%).
  - *Định dạng SĐT*: 100% SĐT trong danh bạ sạch đúng chuẩn di động 10 số (03, 05, 07, 08, 09) hoặc cố định 11 số (02).
  - *Nhật ký sửa ô (`nhat-ky-sua.csv`)**: Ghi nhận **862 lượt chỉnh sửa** ở mức ô, đầy đủ giá trị cũ/mới và mã quy tắc.

## 2. Kết quả gộp khách hàng trùng lặp
Tổng cộng có **57 dòng** được gộp vào **51 nhóm khách hàng** (45 nhóm 2 dòng và 6 nhóm 3 dòng):
- **Quy tắc G1 (Trùng SĐT hợp lệ + Tên tương thích)**: 40 dòng được gộp trực tiếp.
- **Quy tắc G2 (Trùng Email hợp lệ + Tên tương thích)**: 14 dòng được gộp trực tiếp.
- **Quy tắc Bắc cầu (A-B và B-C)**: 3 dòng:
  - `R288` gộp vào `R009` qua `R378` (R288 khớp SĐT với R378, R378 khớp email với R009).
  - `R217` gộp vào `R122` qua `R126` (R217 khớp SĐT với R126, R126 khớp email với R122).
  - `R347` gộp vào `R282` qua `R340` (R347 khớp email với R340, R340 khớp SĐT với R282).
*Nguyên tắc bảo toàn*: Giá trị chuẩn nhất (đầy đủ dấu, không viết tắt) được đưa vào cột chính; các giá trị SĐT/email hợp lệ phát sinh được lưu vào cột `sdt_khac`, `email_khac`, không mất thông tin.

## 3. Các ca nghi trùng cần người quyết (`nghi-trung-can-quyet.csv`)
Ghi nhận đúng **21 ca nghi trùng** (không tự tiện gộp theo đúng ràng buộc):
- **13 ca Q1 (Trùng SĐT nhưng tên không tương thích)**:
  - *5 ca tên một từ* (`c Linh` - Huỳnh Thanh Linh; `Cô Trang` - Lê Thanh Trang; `anh Phát` - Ngô Anh Phát; `Anh Lộc` - Hoàng Xuân Lộc; `Cô Giang` - Trần Kim Giang): Nghiêng về **GỘP** nếu người duyệt xác nhận tên một từ là cách gọi tắt của khách quen.
  - *8 ca tên khác hẳn*: Nghiêng về **KHÔNG GỘP** (khả năng người trong cùng gia đình dùng chung số hoặc nhân viên nhập nhầm số).
- **8 ca Q2 (Trùng họ tên và địa chỉ đã mở viết tắt, nhưng khác hoặc khuyết SĐT)**:
  - *3 ca khuyết SĐT ở một dòng* (R157 - R240; R212 - R383; R261 - R349): Nghiêng về **GỘP** vì cùng họ tên và địa chỉ cư trú chi tiết, dòng thiếu SĐT do lúc ghi chép chưa kịp lấy số.
  - *5 ca khác SĐT* (R036 - R138; R041 - R257; R097 - R299; R160 - R267; R356 - R388): Nghiêng về **GỘP** nếu một khách dùng hai số điện thoại khác nhau.

## 4. Những lỗi không sửa được (đã làm sạch thành ô trống, lưu vết ở nhật ký)
- **13 SĐT không hợp lệ**: 7 số bị che dấu `*` (R055, R086, R131, R258, R286, R320, R353); 2 số đầu số cũ 11 số 01x (R057: 01295550449, R362: 01295550548); 4 số bị thiếu chữ số (R083: 081555039, R218: 036555061, R227: 094555036, R266: 076555012).
- **31 Email sai cú pháp**: 3 email thiếu `@` (R049, R322, R366); 5 email thiếu tên miền cấp cao (R038, R077, R108, R164, R304); 8 email có hai dấu `@@` (R047, R057, R087, R090, R142, R155, R272, R358); 3 email có khoảng trắng ở giữa (R144, R379, R398); 12 email có đuôi lạ gõ nhầm `.con` (R079, R083, R095, R241, R249, R270, R273, R279, R297, R308, R342, R372).

## 5. Đề xuất quy tắc bổ sung (kiến nghị cho cửa hàng)
1. **Bổ sung quy tắc chuyển đổi đầu số cũ 11 số sang 10 số**: Ví dụ đầu `0129` chuyển thành `082` theo bảng chuyển đổi chính thức của Bộ TT&TT (sẽ cứu được 2 số của R057 và R362).
2. **Quy tắc tự sửa đuôi tên miền phổ biến**: Cho phép chuyển `.con` thành `.com` nếu tên miền là `example.con` hoặc `gmail.con` sau khi cửa hàng thống nhất chính sách.
