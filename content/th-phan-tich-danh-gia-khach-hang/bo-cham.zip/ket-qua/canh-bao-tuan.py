"""Cảnh báo tuần: so tuần mới nhất với trung bình 4 tuần trước, từ xu-huong-tuan.csv của agent.

Dùng:  python -X utf8 canh-bao-tuan.py <xu-huong-tuan.csv> [tuan_can_xet YYYY-MM-DD] [he_so=2.0] [toi_thieu=3]
Cảnh báo chủ đề khi số ý TIÊU CỰC của tuần đó >= toi_thieu VÀ >= he_so x trung bình 4 tuần trước.
Ngưỡng 2.0 và 3 là [Đề xuất] tùy ý, hãy chỉnh theo lượng đánh giá của quán. Tuần ít ý thì chỉ là dấu hiệu, không phải kết luận.
"""
import csv, sys
from collections import defaultdict

def main():
    f = sys.argv[1]; tuan = sys.argv[2] if len(sys.argv) > 2 else None
    he_so = float(sys.argv[3]) if len(sys.argv) > 3 else 2.0; toi_thieu = int(sys.argv[4]) if len(sys.argv) > 4 else 3
    neg = defaultdict(dict)
    for r in csv.DictReader(open(f, encoding="utf-8-sig")):
        neg[r["chu_de"]][r["tuan"]] = int(r["tieu_cuc"])
    weeks = sorted({w for d in neg.values() for w in d}); tuan = tuan or weeks[-1]
    i = weeks.index(tuan); truoc = weeks[max(0, i - 4):i]
    print(f"Tuần xét: {tuan} | so với {len(truoc)} tuần trước: {truoc[0] if truoc else '-'} .. {truoc[-1] if truoc else '-'}")
    n_warn = 0
    for t, d in sorted(neg.items()):
        if t == "khac": continue
        now = d.get(tuan, 0); base = sum(d.get(w, 0) for w in truoc) / len(truoc) if truoc else 0
        flag = now >= toi_thieu and now >= he_so * max(base, 0.5)
        n_warn += flag
        print(f"  {t:11s} tiêu cực tuần này {now:2d} | TB các tuần trước {base:4.1f} {'<-- CẢNH BÁO' if flag else ''}")
    print("Số cảnh báo:", n_warn)

if __name__ == "__main__":
    main()
