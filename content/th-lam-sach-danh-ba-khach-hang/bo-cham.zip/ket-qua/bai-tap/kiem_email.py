"""Chấm bài tập 2 (bài 4): quy tắc Q3, email trùng nhưng tên khác hẳn thì không gộp, đưa vào danh sách cần quyết.

Dùng:  python -X utf8 kiem_email.py <thư_mục_kết_quả> [ca-email-dap-an.json]
Thư mục kết quả: nơi bạn chạy lam_sach.py trên du-lieu/bai-tap-email/danh-ba-goc.xlsx (405 dòng).
Kiểm:
  1. Mỗi trong 5 cặp (dòng cũ, dòng mới) nằm trong cùng một nhóm của nghi-trung-can-quyet.csv.
  2. Hai dòng của mỗi cặp KHÔNG bị gộp (khác ma_khach trong nhat-ky-gop.csv).
  3. Các nhóm gộp cũ giữ nguyên: đúng 52 nhóm có từ 2 dòng trở lên, 347 khách, 405 dòng trong nhật ký gộp.
  4. Các nhóm cũ trong danh sách cần quyết còn đủ: ít nhất 25 nhóm không phải của 5 cặp trên, và tổng 30 nhóm.
Chạy thêm tu_kiem.py: phép 4 của nó phải ĐẠT (trước khi thêm Q3, nó TRƯỢT đúng 5 email này).
Thoát mã 0 nếu mọi phép đạt.
"""
import csv, json, re, sys
from pathlib import Path


def rd(p):
    return list(csv.DictReader(Path(p).read_text(encoding="utf-8-sig").splitlines()))


def main(d, ans=None):
    d = Path(d)
    ans = Path(ans) if ans else Path(__file__).resolve().parent / "ca-email-dap-an.json"
    pairs = json.loads(ans.read_text(encoding="utf-8"))["cap_email_trung_ten_khac"]
    gop = rd(d / "nhat-ky-gop.csv"); rev = rd(d / "nghi-trung-can-quyet.csv")
    kh = {g["ma_dong_goc"].strip(): g["ma_khach"].strip() for g in gop}
    groups = [set(x for x in re.split(r"[;,\s]+", r["ma_dong_goc"]) if x) for r in rev]
    fails = []

    def check(name, ok, detail=""):
        print(("ĐẠT   " if ok else "TRƯỢT ") + name + (f"  [{detail}]" if detail else ""))
        if not ok: fails.append(name)

    found = [p for p in pairs if any({p["dong_cu"], p["dong_moi"]} <= g for g in groups)]
    check("1. cả 5 cặp email trùng nằm trong danh sách cần quyết", len(found) == len(pairs), f"{len(found)}/{len(pairs)}")
    merged = [p for p in pairs if kh.get(p["dong_cu"]) == kh.get(p["dong_moi"])]
    check("2. không cặp nào bị gộp", not merged, f"bị gộp: {[p['dong_moi'] for p in merged]}")
    cl = {}
    for m, k in kh.items(): cl.setdefault(k, set()).add(m)
    n_gop = sum(1 for v in cl.values() if len(v) > 1)
    check("3. nhóm gộp cũ giữ nguyên", n_gop == 52 and len(cl) == 347 and len(kh) == 405, f"{n_gop} nhóm gộp, {len(cl)} khách, {len(kh)} dòng")
    pair_sets = [{p["dong_cu"], p["dong_moi"]} for p in pairs]
    old = [g for g in groups if not any(g == s for s in pair_sets)]
    check("4. danh sách cần quyết còn đủ nhóm cũ", len(old) >= 25 and len(groups) == 30, f"{len(old)} nhóm cũ, {len(groups)} nhóm tổng")
    print("\nTỔNG:", "ĐẠT TẤT CẢ" if not fails else f"TRƯỢT {len(fails)} mục")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None))
