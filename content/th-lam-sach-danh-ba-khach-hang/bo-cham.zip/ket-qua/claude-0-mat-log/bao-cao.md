# Báo cáo làm sạch danh bạ (dữ liệu giả để tập)

Chạy `python lam_sach.py`: không mô hình, không mạng, chạy lại ra đúng kết quả cũ (đã so hash hai lần chạy). `danh-ba-goc.xlsx` không bị sửa.

## Số liệu trước / sau
| | Trước | Sau |
|---|---|---|
| Số dòng / khách | 400 dòng | **342 khách** (58 dòng gộp vào dòng khác) |
| Nhóm đã gộp (≥ 2 dòng) | – | **52 nhóm**: G1 = 40 dòng, G2 = 15, bắc cầu = 3 |
| SĐT | 376 ô có giá trị, nhiều định dạng | 372 dòng có SĐT hợp lệ; 314 khách có SĐT |
| Email | 183 ô có giá trị | 150 dòng có email hợp lệ; 126 khách có email |
| Địa chỉ | 278 dòng có, viết tắt lộn xộn | 278 dòng đã mở viết tắt, đủ phường–quận–thành phố |
| Sửa mức ô | – | 852 thay đổi trên 376 dòng (`nhat-ky-sua.csv`) |

Việc đã làm thêm: 3 dòng đổi chỗ tên/địa chỉ (R185, R241, R345); 11 SĐT nằm sai cột (4 ở cột Email, 7 ở Ghi chú) đưa về cột SĐT; 2 email nằm ở cột SĐT (R045, R291) đưa về cột Email; 5 dòng có hai SĐT (R089, R110, R279, R308, R312) tách sang `sdt_khac`; 30 danh xưng ghi vào `ghi_chu`.

## Cần người quyết: 25 nhóm (`nghi-trung-can-quyet.csv`)
- **Q1 (13 nhóm)**: cùng SĐT, tên không tương thích. 5 nhóm là tên một từ (Linh, Phát, Lộc, Trang, Giang) → gợi ý gộp; 8 nhóm tên khác hẳn → gợi ý không gộp (có thể người thân dùng chung số).
- **Q2 (12 nhóm)**: cùng tên, cùng địa chỉ, SĐT khác hoặc thiếu. Cả 12 gợi ý gộp; 4 nhóm một bên thiếu SĐT (khá chắc), 8 nhóm hai SĐT khác nhau (nên xác nhận).
- Gợi ý do script sinh theo quy tắc cố định, tôi đã đọc lại cả 25 nhóm và không có nhóm nào muốn đổi chiều gợi ý. Chưa gộp nhóm nào.

## Lỗi không sửa được (để trống ở cột sạch, giá trị cũ giữ trong `nhat-ky-sua.csv`)
- **13 SĐT không hợp lệ**: 7 bị che `***`, 4 thiếu số (R083, R218, R227, R266), 2 đầu số cũ 11 số (R057, R362).
- **31 email sai cú pháp**: `@@`, đuôi `.con`, thiếu đuôi miền, thiếu `@`, có khoảng trắng giữa (R144, R379, R398).
- 28 khách không có SĐT hợp lệ; **23 khách không có cả SĐT lẫn email** (không liên lạc được). 81 khách không có địa chỉ.
- 80 tên và khoảng 59 địa chỉ không dấu: không đoán dấu nên giữ nguyên.
- 5 dòng tên một từ không thể gộp tự động; cặp "Hưng/Hùng" (R007/R109) và "Hạ/Hà" (R111/R188) giữ riêng đúng quy tắc.

## Cách tôi hiểu những chỗ quy tắc chưa nói rõ (đổi được nếu bạn muốn khác)
1. So khớp dùng **mọi** SĐT/email hợp lệ của dòng (cả số thứ hai, cả số lấy từ cột sai chỗ).
2. "Bỏ dấu" so từng chữ: chữ không dấu khớp chữ có dấu tương ứng; hai chữ cùng có dấu mà khác nhau (Hùng/Hưng) là khác. Viết tắt chỉ áp cho chữ đệm.
3. Địa chỉ trong Q2 so không phân biệt dấu. Thành phố: giữ "Thành phố" chỉ với Hồ Chí Minh; Hà Nội, Đà Nẵng, Cần Thơ, Hải Phòng viết không tiền tố cho thống nhất.
4. Danh xưng `a` → Anh, `c` → Chị. Họ "Chu" viết hoa không bị coi là danh xưng "chú".
5. Tên chính của khách gộp: ưu tiên không viết tắt, rồi nhiều dấu hơn (nên "Huynh Huu Dung" thắng "Huỳnh H. Dũng"). Bản sạch không có cột `ho_ten_khac`/`dia_chi_khac`, nên tên và địa chỉ khác được ghi vào `ghi_chu` ("Tên khác: …", 32 khách; "Địa chỉ khác: …", 2 khách).
6. SĐT/email nhập nhầm trong Ghi chú được chuyển đi và xóa khỏi Ghi chú (7 dòng); thông tin vẫn có trong cột đúng và trong nhật ký.

## Quy tắc đề xuất thêm (CHƯA áp dụng)
- Q3: trùng email nhưng tên khác (dữ liệu này không có ca nào, nhưng nên có sẵn quy tắc).
- Cặp tên gần giống và SĐT lệch một chữ số (R007 0895550132 / R109 0895550131) có thể là gõ nhầm; hiện chỉ trùng tên nên không báo.
- Cho phép tên một từ gộp với tên đầy đủ khi trùng SĐT và trùng địa chỉ (5 ca Q1 đang chờ người quyết).

## Hoàn tác
Từ `nhat-ky-gop.csv` tách từng khách về các dòng gốc theo `ma_khach`; giá trị gốc từng ô lấy từ `gia_tri_cu` trong `nhat-ky-sua.csv`.
