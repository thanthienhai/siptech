# Giải thích script gop.py (dành cho kế toán)

## 1. Script làm gì
- Gộp file Excel doanh thu tháng của từng chi nhánh thành một bảng chung, tính tổng theo chi nhánh và theo sản phẩm. Chỗ nào không chắc, script không đoán mà đưa vào danh sách "việc cần hỏi lại".
- **Đọc:** mọi file `.xlsx` trong thư mục `goc/` (mỗi chi nhánh một file), cùng `danh_muc_san_pham.csv` và `danh_muc_chi_nhanh.csv`. Người chạy phải nhập tháng cần gộp (ví dụ `--thang 2026-10`).
- **Ghi** vào thư mục `ra/` (CSV là file bảng, Excel mở được): `hop_nhat.csv` (từng dòng bán hàng), `tong_hop_chi_nhanh.csv`, `tong_hop_san_pham.csv`, `tong_hop_chi_nhanh_san_pham.csv`, `kiem_tra.csv` (đối chiếu tổng), `viec_can_hoi.csv`, `bao_cao.md` (báo cáo bằng chữ).
- File gốc không bị sửa (script nạp vào bộ nhớ, không lưu lại); script từ chối chạy nếu `ra/` nằm trong `goc/`.

## 2. Các bước theo thứ tự
1. Kiểm tra tháng nhập vào, hai file danh mục và thư mục; thiếu thứ nào là dừng.
2. Mở từng file Excel (mỗi file phải có đúng 1 sheet đang hiện và có dữ liệu), tìm dòng tiêu đề; thiếu cột hoặc có cột lạ thì dừng và báo lỗi.
3. Xác định chi nhánh qua tên file hoặc phần tiêu đề phía trên bảng.
4. Phân loại từng dòng: dòng bán hàng, dòng "Cộng tuần", dòng tổng cuối bảng (phải có đúng 1), hoặc ghi chú.
5. Đọc ngày và số tiền của từng dòng bán hàng, đối chiếu tên hàng với danh mục sản phẩm.
6. Gán mỗi dòng một trạng thái: OK, SUY_RA (ngày phải suy ra), CAN_NGUOI_QUYET (chờ người quyết), TRUNG, NGOAI_KY (ngoài tháng).
7. Đối chiếu: thành tiền với SL × đơn giá, từng "Cộng tuần", tổng cuối bảng với tổng các dòng, ngày trong tháng không có dòng nào, chi nhánh thiếu file.
8. Ghi các file kết quả; tự kiểm ba cách cộng (theo chi nhánh, theo sản phẩm, theo bảng chi nhánh × sản phẩm) phải bằng nhau, lệch thì báo lỗi.

## 3. Chỗ script TỰ QUYẾT thay người
- **Dòng trùng:** cùng số chứng từ VÀ cùng ngày, tên hàng, SL, đơn giá, thành tiền → bỏ bản lặp, giữ dòng đầu. Cùng số chứng từ nhưng nội dung khác → dòng sau không tính, chờ hỏi. Khác số chứng từ nhưng giống hệt nội dung → vẫn tính là hai giao dịch (chỉ nhắc trong báo cáo).
- **Ngày dạng chữ đọc được 2 cách (như 05/10):** nếu trong file có ô chỉ đọc được một cách (như 25/10) thì coi cả file theo kiểu đó, miễn cách đọc kia nằm ngoài tháng. Không được thì xét thứ tự dòng (file sắp theo ngày, có từ 10 dòng ngày chắc chắn, ngày nằm giữa dòng trước và dòng sau). Vẫn không chắc → để trống ngày, không tính vào tổng.
- **Ngày Excel nằm ngoài tháng:** thử đảo ngày/tháng, nếu thứ tự dòng ủng hộ thì dùng ngày đảo; nếu không thì loại khỏi tổng vì ngoài tháng. Ô ngày bị gộp thì lấy ngày của ô đầu.
- **Số tiền:** "1.250.000đ" hay "68,000" đọc dấu chấm/phẩy là dấu ngăn nghìn; số trong ngoặc hoặc có dấu trừ là số âm (trả hàng, vẫn trừ vào doanh thu). Chuỗi không khớp kiểu nào → dòng chờ hỏi.
- **Tên hàng:** bỏ dấu, chữ thường, so với tên chuẩn, rồi so với bộ từ khóa viết cứng trong script cho SP01–SP08. Không khớp → `CHUA_XAC_DINH`, vẫn tính doanh thu.
- **Thành tiền lệch SL × đơn giá:** giữ số thành tiền chi nhánh ghi, chỉ báo.
- **Ghi chú cuối bảng:** chỉ ghi chú có từ khóa (trả lại, nhập trễ, VAT, chưa tính, sai, lỗi...) mới được đưa vào danh sách hỏi; ghi chú khác bị bỏ qua.
- **Ô tổng:** lấy giá trị Excel đã lưu sẵn; chỉ khi thiếu mới tự tính công thức đơn giản (SUM, cộng, trừ).

## 4. Nên nhờ người kiểm lại
- Các dòng SUY_RA (lý do ở cột `ghi_chu` của `hop_nhat.csv`): xác nhận ngày đúng.
- Dòng TRUNG, NGOAI_KY, CAN_NGUOI_QUYET không nằm trong tổng: xem số tiền bị loại ở `kiem_tra.csv`.
- Dòng `CHUA_XAC_DINH`; sản phẩm mới phải nhờ người sửa code vì từ khóa chỉ có 8 sản phẩm.
- Chữ "CHƯA GIẢI THÍCH" trong `kiem_tra.csv`: tổng chi nhánh ghi khác tổng dòng mà script không tìm ra nguyên nhân.
- Tiêu đề `bao_cao.md` ghi cứng "Công ty Mẫu An Phát" trong code. Dòng bị ẩn trong Excel: không thấy trong code xử lý riêng (đọc như dòng thường). Kiểm giá theo bảng giá, thuế, tiền tệ khác đồng: không thấy trong code.
- Tôi chỉ đọc code, chưa chạy thử.
