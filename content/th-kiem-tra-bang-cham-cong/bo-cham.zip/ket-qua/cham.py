"""Chấm kết quả của agent bằng đáp án (dap-an.json). Không dùng mô hình để chấm.

Chạy:  python -X utf8 cham.py <thư_mục_kết_quả_của_agent> <nhãn> [--ghi bao-cao-cham.json]
Đọc:   bang_cong_ngay.csv, bat_thuong.csv, tong_hop_nguoi.csv trong thư mục đó.
Đo:
  1. Bất thường: khớp theo (ma_nv, ngay, loai). Đúng / bỏ sót / bịa (báo mà đáp án không có), theo từng loại.
     OT_THANG_VUOT khớp theo (ma_nv, loai); DU_LIEU_LOI khớp theo (ma_nv, loai) vì đáp án không gắn ngày.
  2. Bảng công ngày: trạng thái; với ngày đáp án = OK so từng cột (giờ vào, giờ ra, giờ công, phút trễ, phút về sớm, làm thêm).
     "Đoán số": ngày đáp án là CHO_XAC_NHAN mà agent vẫn điền giờ công > 0 (đáng lẽ để trống).
  3. Tổng hợp theo người: so từng cột số với đáp án.
  4. can_nguoi_quyet đúng/ sai trên các dòng bất thường đã khớp; số dòng thiếu lời giải thích.
"""
import csv, json, sys, re, datetime as dt
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
TRUTH = json.loads((HERE / "dap-an.json").read_text(encoding="utf-8"))

def rd(p):
    if not Path(p).exists(): return None
    with open(p, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))

def nd(x):
    x = (x or "").strip()
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", x)
    if m: return f"{m[3]}-{int(m[2]):02d}-{int(m[1]):02d}"
    return x

def num(x):
    try: return float(str(x).strip().replace(",", "."))
    except Exception: return None

def tm(x):
    x = (x or "").strip()
    m = re.fullmatch(r"(\d{1,2}):(\d{2})(:\d{2})?", x)
    return f"{int(m[1]):02d}:{m[2]}" if m else x

def cham(d):
    d = Path(d); res = {}
    bt, bc, th = rd(d / "bat_thuong.csv"), rd(d / "bang_cong_ngay.csv"), rd(d / "tong_hop_nguoi.csv")
    res["co_du_3_tep"] = {k: v is not None for k, v in (("bat_thuong", bt), ("bang_cong_ngay", bc), ("tong_hop_nguoi", th))}

    # ---- 1. bất thường
    def key(ma, ngay, loai):
        ma, loai = ma.strip().upper(), loai.strip().upper()
        if loai == "DU_LIEU_LOI": return (ma, "*", loai)
        if loai == "OT_THANG_VUOT": return (ma, "THANG", loai)
        return (ma, nd(ngay), loai)
    truth = {key(a["ma_nv"], a["ngay"], a["loai"]): a for a in TRUTH["bat_thuong"]}
    got = {}
    for r in bt or []: got.setdefault(key(r.get("ma_nv", ""), r.get("ngay", ""), r.get("loai", "")), r)
    tp, fn, fp = set(truth) & set(got), set(truth) - set(got), set(got) - set(truth)
    per = defaultdict(lambda: dict(dung=0, bo_sot=0, bia=0))
    for k in tp: per[k[2]]["dung"] += 1
    for k in fn: per[k[2]]["bo_sot"] += 1
    for k in fp: per[k[2]]["bia"] += 1
    res["bat_thuong"] = dict(dap_an=len(truth), agent_bao=len(got), dung=len(tp), bo_sot=len(fn), bia=len(fp),
                             theo_loai={k: v for k, v in sorted(per.items())},
                             ds_bo_sot=sorted(map(list, fn)), ds_bia=sorted(map(list, fp)))
    # nhãn sai loại: cùng (ma, ngay) nhưng khác loại
    mis = []
    tmap = defaultdict(set); gmap = defaultdict(set)
    for k in truth: tmap[k[:2]].add(k[2])
    for k in got: gmap[k[:2]].add(k[2])
    for kk in set(tmap) & set(gmap):
        if tmap[kk] != gmap[kk]: mis.append(dict(ma_nv=kk[0], ngay=kk[1], dap_an=sorted(tmap[kk]), agent=sorted(gmap[kk])))
    res["bat_thuong"]["nhan_khac_loai"] = mis
    ok_q = [k for k in tp if (got[k].get("can_nguoi_quyet", "").strip().upper() == "CO") == truth[k]["can_nguoi_quyet"]]
    res["bat_thuong"]["can_nguoi_quyet_dung"] = f"{len(ok_q)}/{len(tp)}"
    res["bat_thuong"]["thieu_giai_thich"] = sum(1 for r in bt or [] if not (r.get("giai_thich") or "").strip())

    # ---- 2. bảng công ngày
    tr = {(r["ma_nv"], r["ngay"]): r for r in TRUTH["ngay"]}
    ga = {}
    for r in bc or []: ga[(r.get("ma_nv", "").strip().upper(), nd(r.get("ngay", "")))] = r
    f = dict(so_dong_dap_an=len(tr), so_dong_agent=len(ga), thieu_dong=len(set(tr) - set(ga)))
    st_ok = sum(1 for k in tr if k in ga and ga[k].get("trang_thai", "").strip().upper() == tr[k]["trang_thai"])
    f["trang_thai_dung"] = f"{st_ok}/{len(tr)}"
    ok_days = [k for k, r in tr.items() if r["trang_thai"] == "OK"]
    cols = {"gio_vao": lambda a, b: tm(a) == tm(b), "gio_ra": lambda a, b: tm(a) == tm(b),
            "gio_cong": lambda a, b: num(a) is not None and abs(num(a) - float(b)) <= 0.011,
            "phut_tre": lambda a, b: num(a) is not None and int(num(a)) == int(b),
            "phut_ve_som": lambda a, b: num(a) is not None and int(num(a)) == int(b),
            "ot_phut": lambda a, b: num(a) is not None and int(num(a)) == int(b)}
    cnt = {c: 0 for c in cols}; full = 0; wrong = []
    for k in ok_days:
        g = ga.get(k)
        if not g: continue
        allok = True
        for c, fn_ in cols.items():
            if fn_(g.get(c, ""), tr[k][c]): cnt[c] += 1
            else: allok = False
        full += allok
        if not allok and len(wrong) < 15: wrong.append(dict(ma_nv=k[0], ngay=k[1], dap_an={c: tr[k][c] for c in cols}, agent={c: g.get(c) for c in cols}))
    f["ngay_OK_dap_an"] = len(ok_days)
    f["ngay_OK_dung_het_cot"] = f"{full}/{len(ok_days)}"
    f["tung_cot_ngay_OK"] = {c: f"{v}/{len(ok_days)}" for c, v in cnt.items()}
    guess = [k for k, r in tr.items() if r["trang_thai"] == "CHO_XAC_NHAN" and k in ga and (num(ga[k].get("gio_cong", "")) or 0) > 0]
    f["doan_so_o_ngay_cho_xac_nhan"] = len(guess)
    f["vi_du_sai"] = wrong
    res["bang_cong_ngay"] = f

    # ---- 3. tổng hợp theo người
    tt = TRUTH["tong_hop"]; gt = {r.get("ma_nv", "").strip().upper(): r for r in th or []}
    fields = ["ngay_cong", "tong_gio_cong", "so_lan_tre", "tong_phut_tre", "so_lan_ve_som", "tong_phut_ve_som", "tong_ot_gio",
              "so_ngay_phep", "so_ngay_vang_chua_ghi", "so_ngay_cho_xac_nhan", "so_bat_thuong"]
    cc = {x: 0 for x in fields}; per_full = 0; saic = []
    for ma, t in tt.items():
        g = gt.get(ma); ok_all = True
        for x in fields:
            tv = t[x]; gv = num(g.get(x, "")) if g else None
            good = gv is not None and abs(gv - tv) <= (0.011 if isinstance(tv, float) else 0)
            cc[x] += good; ok_all &= good
            if not good and len(saic) < 12: saic.append(dict(ma_nv=ma, cot=x, dap_an=tv, agent=None if g is None else g.get(x)))
        per_full += ok_all
    res["tong_hop_nguoi"] = dict(so_nguoi=len(tt), dung_het_cot=f"{per_full}/{len(tt)}", tung_cot={x: f"{v}/{len(tt)}" for x, v in cc.items()}, vi_du_sai=saic)
    return res

if __name__ == "__main__":
    a = sys.argv[1:]
    d, label = a[0], a[1]
    r = cham(d)
    print(json.dumps(r, ensure_ascii=False, indent=1))
    if "--ghi" in a:
        out = Path(a[a.index("--ghi") + 1]); cur = json.loads(out.read_text(encoding="utf-8")) if out.exists() else {}
        cur[label] = r; out.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding="utf-8")
