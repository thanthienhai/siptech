"""Dung anh ket qua tu file THAT agent da tao (ket-qua/<nhan>/...) va bao-cao-cham.json. Du lieu GIA."""
import csv, json, sys, html
from pathlib import Path
import os
sys.path.insert(0, os.environ.get("AGENTLAB_DIR") or str(Path(__file__).resolve().parents[5] / "siptech-video" / "agentlab"))
from term import shot_html as _shot_html, scrub_text
def shot_html(h, *a, **k): return _shot_html(scrub_text(h), *a, **k)   # che duong dan/ ten to chuc truoc khi dung anh
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams["font.family"] = "Segoe UI"
ROOT = Path(__file__).resolve().parent.parent
KQ = ROOT / "ket-qua"
ans = json.loads((KQ / "dap-an.json").read_text(encoding="utf-8"))
cham = json.loads((KQ / "bao-cao-cham.json").read_text(encoding="utf-8"))
CSS = """body{margin:0;background:#fff;font-family:'Segoe UI',Arial,sans-serif}.w{padding:16px;width:1100px}
h3{margin:0 0 6px;font-size:17px;color:#0f172a}p{margin:4px 0 8px;color:#475569;font-size:13px}
table{border-collapse:collapse;width:100%;font-size:14px}th{background:#e8edf5;border:1px solid #c5cedb;padding:5px 8px;text-align:left}
td{border:1px solid #d6dce6;padding:4px 8px;font-size:13.5px}td.n{text-align:right;font-family:Consolas,monospace}.bad{background:#fde2e2}.ok{background:#dff3e0}.warn{background:#fff3c4}
.tot td{font-weight:700;background:#f1f5f9}.f{color:#64748b;font-size:12px;margin-top:8px}"""
def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as f: return list(csv.DictReader(f))
def vnd(x): return f"{float(x):,.0f}".replace(",", ".")

def shot(body, out, w=1150):
    shot_html(f"<!doctype html><meta charset=utf-8><style>{CSS}</style><div class=w id=w>{body}</div>", out, w + 40, "#w")

def anh_de_xuat(label, out, run):
    D = rd(KQ / label / "de-xuat-nhap.csv")
    names = {c: s["ten"] for c, s in ans["sku"].items()}
    P = {r["ma_hang"]: r for r in rd(KQ / label / "phan-loai-tinh-toan.csv")}
    rows = [r for r in D if float(r["sl_de_xuat"] or 0) > 0]
    rows.sort(key=lambda r: float(r["uu_tien"] or 999))
    tong = sum(float(r["thanh_tien"] or 0) for r in D)
    chua = sum(float(r["sl_can_chua_xet_ngan_sach"] or 0) * float(r["don_gia_von"] or 0) for r in D)
    t = f"<h3>de-xuat-nhap.csv do agent tạo ({run}) · các mã được đề xuất nhập</h3><p>Dữ liệu GIẢ để học. Ngân sách tham số: {vnd(ans['ngan_sach'])} đ.</p>"
    t += "<table><tr><th>ưu tiên</th><th>mã</th><th>tên</th><th>cảnh báo</th><th>lớp</th><th>SL cần (chưa xét NS)</th><th>SL đề xuất</th><th>giá vốn</th><th>thành tiền (đ)</th><th>cần người quyết</th></tr>"
    for r in rows[:16]:
        p = P.get(r["ma_hang"], {})
        cut = float(r["sl_de_xuat"]) < float(r["sl_can_chua_xet_ngan_sach"] or 0)
        t += (f"<tr class='{'warn' if cut else ''}'><td class=n>{r['uu_tien']}</td><td>{r['ma_hang']}</td><td>{html.escape(names.get(r['ma_hang'], ''))}</td><td>{p.get('canh_bao', '')}</td><td>{p.get('lop_abc', '')}</td>"
              f"<td class=n>{r['sl_can_chua_xet_ngan_sach']}</td><td class=n>{r['sl_de_xuat']}</td><td class=n>{vnd(r['don_gia_von'])}</td><td class=n>{vnd(r['thanh_tien'])}</td><td>{r['can_nguoi_quyet']}</td></tr>")
    t += f"<tr class=tot><td colspan=8>Tổng tiền vốn đề xuất ({len(rows)} mã) · cần theo công thức chưa xét ngân sách: {vnd(chua)} đ</td><td class=n>{vnd(tong)}</td><td></td></tr></table>"
    t += "<div class=f>Hàng vàng = bị cắt một phần vì ngân sách. Chỉ hiện tối đa 16 dòng đầu theo thứ tự ưu tiên của agent.</div>"
    shot(t, out)

def anh_so_sanh(labels, out):
    keys = [("Lỗi dữ liệu phát hiện (28 lỗi cài sẵn)", lambda r: r["loi_du_lieu"]["phat_hien"]),
            ("  xử lý đúng (BỎ/ SỬA/ CẦN NGƯỜI QUYẾT)", lambda r: r["loi_du_lieu"]["xu_ly_dung"]),
            ("  báo nhầm (mã phiếu không phải lỗi/ ca hợp lệ)", lambda r: r["loi_du_lieu"]["bao_nham"]["so_ma_phieu"]),
            ("Phân loại ABC khớp đáp án", lambda r: r["abc"]["khop"]),
            ("Dự báo F khớp tham chiếu (46 mã không mơ hồ)", lambda r: r["F_khop_tham_chieu"]["dung_dung_sai"]),
            ("Tháng cụt hàng: đúng / báo thừa / bỏ sót", lambda r: f"{r['thang_cut_hang']['dung']} / {r['thang_cut_hang']['bao_thua']} / {r['thang_cut_hang']['bo_sot']}"),
            ("Nhãn cảnh báo khớp", lambda r: r["canh_bao"]["khop"]),
            ("Tổng tiền đề xuất (đ)", lambda r: vnd(r["de_xuat"]["tong_tien_tinh_lai_tu_sl_x_gia_dung"])),
            ("Không vượt ngân sách 30.000.000 đ", lambda r: "ĐÚNG" if r["de_xuat"]["khong_vuot_ngan_sach"] else "SAI"),
            ("Hàng hết/ sắp hết lớp A-B được đề xuất nhập", lambda r: r["de_xuat"]["hang_het/sap_het_lop_A_B_can_nhap"]),
            ("WAPE hold-out 2026-09: công thức / mốc tháng trước", lambda r: f"{r['giu_lai']['2026-09']['WAPE_agent(tinh lai)']*100:.1f}% / {r['giu_lai']['2026-09']['WAPE_moc_thang_truoc(tinh lai)']*100:.1f}%"),
            ("WAPE hold-out 2026-10: công thức / mốc tháng trước", lambda r: f"{r['giu_lai']['2026-10']['WAPE_agent(tinh lai)']*100:.1f}% / {r['giu_lai']['2026-10']['WAPE_moc_thang_truoc(tinh lai)']*100:.1f}%")]
    t = "<h3>Chấm bằng code (cham.py): so sánh các lần chạy trên cùng dữ liệu và cùng prompt</h3><p>Dữ liệu GIẢ để học. Mỗi cột là 1 lần chạy (n = 1), chưa đo được độ ổn định.</p><table><tr><th>chỉ tiêu</th>" + "".join(f"<th>{l}</th>" for l in labels) + "</tr>"
    for name, fn in keys:
        t += f"<tr><td>{html.escape(name)}</td>" + "".join(f"<td class=n>{fn(cham[l])}</td>" for l in labels) + "</tr>"
    t += "</table><div class=f>Điểm không có nghĩa là \"agent A hơn agent B\": chỉ là 1 lần chạy mỗi bên.</div>"
    shot(t, out, 1150)

def chart_holdout(labels, out):
    fig, ax = plt.subplots(1, 2, figsize=(10.5, 4.2), dpi=150)
    for a, h in zip(ax, ("2026-09", "2026-10")):
        vals = [(l, cham[l]["giu_lai"][h]["WAPE_agent(tinh lai)"] * 100) for l in labels]
        moc = [cham[l]["giu_lai"][h]["WAPE_moc_thang_truoc(tinh lai)"] * 100 for l in labels]
        x = range(len(labels)); w = 0.36
        b1 = a.bar([i - w / 2 for i in x], [v for _, v in vals], w, color="#1d4ed8", label="công thức (trung bình trượt 3 tháng)")
        b2 = a.bar([i + w / 2 for i in x], moc, w, color="#9ca3af", label="mốc ngây thơ (bằng tháng trước)", hatch="//", edgecolor="white")
        for bars in (b1, b2):
            for b in bars: a.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.6, f"{b.get_height():.1f}".replace(".", ","), ha="center", fontsize=9)
        a.set_xticks(list(x)); a.set_xticklabels(labels); a.set_title(f"Tháng {h} (giữ lại)", fontsize=11); a.set_ylabel("WAPE (%), thấp hơn là tốt hơn")
        a.spines[["top", "right"]].set_visible(False)
    h, l = ax[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=2, fontsize=9, frameon=False)
    fig.suptitle("Công thức có hơn mốc ngây thơ không? Dữ liệu giả, chỉ 2 tháng, n ≈ 50 mã mỗi tháng", fontsize=11)
    fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(out); plt.close(fig)

def chart_seasonal(out, codes=("TH008", "MP001")):
    months = ans["thang"]
    fig, axs = plt.subplots(1, len(codes), figsize=(10.5, 4), dpi=150)
    for a, c in zip(axs, codes):
        s = ans["sku"][c]; t = s["truth_thang"]
        net = [t["sold"][m] - t["returns"][m] for m in range(12)]
        a.plot(range(12), net, "-o", color="#111827", label="bán thực tế (đã trừ trả hàng)", ms=4)
        cut = [m for m in range(12) if t["zero_days"][m] >= 7]
        for m in cut: a.axvspan(m - .4, m + .4, color="#fca5a5", alpha=.5, lw=0)
        for h, mark in ((10, "o"), (11, "o")):
            ho = s["ref"]["holdout"][months[h]]
            a.scatter([h], [ho["f_ref"]], marker="s", color="#1d4ed8", zorder=5, label="dự báo công thức" if h == 10 else None)
            a.scatter([h], [ho["naive"]], marker="^", color="#6b7280", zorder=5, label="mốc tháng trước" if h == 10 else None)
        a.axvspan(9.5, 11.5, color="#e0e7ff", alpha=.35, lw=0)
        a.set_xticks(range(12)); a.set_xticklabels([m[2:] for m in months], rotation=60, fontsize=8)
        a.set_title(f"{c} · {s['ten']}", fontsize=10); a.spines[["top", "right"]].set_visible(False)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=3, fontsize=9, frameon=False); axs[0].set_ylabel("đơn vị / tháng")
    fig.suptitle("Mã có mùa vụ: trung bình trượt 'đuổi theo sau'. Vùng đỏ = tháng cụt hàng, vùng xanh = hai tháng giữ lại. Dữ liệu giả.", fontsize=10)
    fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(out); plt.close(fig)

if __name__ == "__main__":
    labels = sys.argv[1].split(",")      # vi du: claude-1,agy-1
    main_label = sys.argv[2]
    anh_de_xuat(main_label, ROOT / "anh/06-ket-qua-de-xuat-nhap.png", main_label)
    anh_so_sanh(labels, ROOT / "anh/07-so-sanh-cham.png")
    chart_holdout(labels, ROOT / "anh/08-holdout-wape.png")
    chart_seasonal(ROOT / "anh/09-mua-vu-trung-binh-truot.png")
    print("ok")
