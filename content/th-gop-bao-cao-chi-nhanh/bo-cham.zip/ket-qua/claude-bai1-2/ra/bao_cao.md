# Báo cáo doanh thu tháng 10/2026 - Công ty Mẫu An Phát

_Tạo tự động bởi `gop.py` từ 6 file chi nhánh trong `goc/`. Mọi số liệu do script tính, đơn vị đồng, không làm tròn._

## 1. Tóm tắt cho giám đốc

- **Tổng doanh thu tháng 10/2026: 1.523.468.000 đ** (901 dòng bán hàng đã xác định: 736 dòng OK, 165 dòng SUY_RA).
- Chưa tính vì cần người quyết: **2.391.000 đ** (3 dòng CAN_NGUOI_QUYET).
- Đã loại khỏi bảng hợp nhất: 5 dòng trùng (9.341.000 đ) và 4 dòng ngoài kỳ (7.800.000 đ).
- Tổng các chi nhánh tự ghi ở cuối bảng: 1.543.100.000 đ; tổng các dòng đọc được: 1.543.000.000 đ; tổng bảng hợp nhất: 1.523.468.000 đ.
- Việc cần hỏi lại chi nhánh: **27 mục** (KHAC: 2, LECH_THANH_TIEN: 2, NGAY_MO_HO: 9, NGOAI_KY: 4, SAI_TONG: 1, SAN_PHAM_LA: 2, THIEU_DU_LIEU: 2, TRUNG: 5).

## 2. Doanh thu theo chi nhánh

| Mã | Chi nhánh | Số dòng | Doanh thu (đ) | Tỷ trọng |
|---|---|---:|---:|---:|
| HN | Hà Nội | 146 | 262.936.000 | 17.26% |
| HP | Hải Phòng | 161 | 279.155.000 | 18.32% |
| DN | Đà Nẵng | 159 | 278.248.000 | 18.26% |
| CT | Cần Thơ | 114 | 184.408.000 | 12.10% |
| BH | Biên Hòa | 157 | 270.321.000 | 17.74% |
| NT | Nha Trang | 164 | 248.400.000 | 16.30% |
| **Tổng** |  | 901 | **1.523.468.000** | 100.00% |

## 3. Doanh thu theo sản phẩm

| Mã | Sản phẩm | Số lượng | Doanh thu (đ) | Tỷ trọng |
|---|---|---:|---:|---:|
| SP01 | Gạo ST25 túi 5kg | 1.190 | 195.958.000 | 12.86% |
| SP02 | Nước mắm truyền thống chai 500ml | 1.667 | 112.858.000 | 7.41% |
| SP03 | Cà phê rang xay 500g | 1.634 | 236.664.000 | 15.53% |
| SP04 | Trà sen 200g | 1.448 | 173.610.000 | 11.40% |
| SP05 | Mật ong rừng 250ml | 1.489 | 275.092.000 | 18.06% |
| SP06 | Hạt điều rang muối 500g | 1.694 | 354.330.000 | 23.26% |
| SP07 | Bánh tráng muối tôm 250g | 1.213 | 45.916.000 | 3.01% |
| SP08 | Dầu dừa ép lạnh 250ml | 1.228 | 116.040.000 | 7.62% |
| CHUA_XAC_DINH | Chưa xác định (ngoài danh mục) | 20 | 13.000.000 | 0.85% |
| **Tổng** |  | 11.583 | **1.523.468.000** | 100.00% |

_Dòng `CHUA_XAC_DINH` là hàng ngoài danh mục sản phẩm; vẫn tính vào doanh thu vì ngày và số tiền rõ ràng, chỉ mã sản phẩm chưa xác định._

## 4. Đối chiếu tổng từng file với bảng hợp nhất

| Chi nhánh | Tổng file ghi | Tổng dòng đọc được | Tổng hợp nhất | Chênh lệch (ghi - hợp nhất) |
|---|---:|---:|---:|---:|
| HN | 263.036.000 | 262.936.000 | 262.936.000 | 100.000 |
| HP | 296.542.000 | 296.542.000 | 279.155.000 | 17.387.000 |
| DN | 278.248.000 | 278.248.000 | 278.248.000 | 0 |
| CT | 184.408.000 | 184.408.000 | 184.408.000 | 0 |
| BH | 270.321.000 | 270.321.000 | 270.321.000 | 0 |
| NT | 250.545.000 | 250.545.000 | 248.400.000 | 2.145.000 |
| **Tổng** | 1.543.100.000 | 1.543.000.000 | 1.523.468.000 | 19.632.000 |

Giải thích chênh lệch:

- **HN**: Chênh lệch 100.000 = Tổng chi nhánh ghi (ô F151) cao hơn 100.000 so với tổng các dòng đọc được (262.936.000): lệch 100.000. CHƯA GIẢI THÍCH (không do dòng trùng/ngoài kỳ/lệch thành tiền; cần chi nhánh xác nhận, xem SAI_TONG trong viec_can_hoi.csv)
- **HP**: Chênh lệch 17.387.000 = Dòng trùng bị loại: 3 dòng, tổng 7.196.000 [HD59200 (dòng 108: 1.320.000), HD37858 (dòng 125: 5.800.000), HD64385 (dòng 171: 76.000)]; Dòng ngoài kỳ 10/2026 bị loại: 4 dòng, tổng 7.800.000 [HD60907 (dòng 25: 1.200.000), HD65097 (dòng 28: 3.700.000), HD28722 (dòng 66: 2.220.000), HD12045 (dòng 82: 680.000)]; Dòng CAN_NGUOI_QUYET chưa tính vào tổng hợp: 3 dòng, tổng 2.391.000 [HD89953 (dòng 47: 195.000), HD50470 (dòng 87: 1.380.000), HD47118 (dòng 117: 816.000)]
- **DN**: Khớp: tổng chi nhánh ghi bằng tổng bảng hợp nhất
- **CT**: Khớp: tổng chi nhánh ghi bằng tổng bảng hợp nhất
- **BH**: Khớp: tổng chi nhánh ghi bằng tổng bảng hợp nhất
- **NT**: Chênh lệch 2.145.000 = Dòng trùng bị loại: 2 dòng, tổng 2.145.000 [NT/0060 (dòng 64: 1.425.000), NT/0138 (dòng 143: 720.000)]

## 5. Vấn đề dữ liệu (theo loại)

| Loại | Số mục | Chi nhánh (số mục) |
|---|---:|---|
| SAI_TONG | 1 | HN (1) |
| KHAC | 2 | HN (1), HP (1) |
| NGAY_MO_HO | 9 | HP (4), DN (1), BH (3), NT (1) |
| THIEU_DU_LIEU | 2 | HP (1), CT (1) |
| NGOAI_KY | 4 | HP (4) |
| TRUNG | 5 | HP (3), NT (2) |
| SAN_PHAM_LA | 2 | CT (2) |
| LECH_THANH_TIEN | 2 | NT (2) |

## 6. Việc cần hỏi lại chi nhánh


### HN - Hà Nội

- **SAI_TONG** [dòng 151] - 100.000 đ: Tổng cuối bảng chi nhánh ghi 263.036.000 (ô F151) khác tổng 146 dòng đọc được 262.936.000: lệch 100.000  
  Câu hỏi: Tổng cuối bảng 263.036.000 khác tổng các dòng chi tiết 262.936.000 (chênh 100.000). Vui lòng kiểm tra lại: thiếu/thừa dòng hay gõ sai tổng?
- **KHAC** [dòng 153]: Ghi chú của chi nhánh (dòng 153): "Ghi chú: Giá đã gồm VAT. Số liệu chưa trừ hàng trả lại."  
  Câu hỏi: Ghi chú này ảnh hưởng thế nào đến số liệu tháng 10/2026 (số tiền, chứng từ liên quan)? Xin gửi bản điều chỉnh nếu cần.

### HP - Hải Phòng

- **NGAY_MO_HO** [HD89953, dòng 47] - 195.000 đ: Ngày bán mơ hồ, chưa tính vào tổng hợp: ô '10/09/2026' đọc được 2 cách: 2026-09-10 (ngày/tháng) hoặc 2026-10-09 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-09-10 nhưng cách còn lại 2026-10-09 nằm trong kỳ, không có căn cứ chắc chắn để chọn  
  Câu hỏi: Chứng từ HD89953 (dòng Excel 47): ngày bán đúng là ngày nào? (ô '10/09/2026' đọc được 2 cách: 2026-09-10 (ngày/tháng) hoặc 2026-10-09 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-09-10 nhưng cách còn lại 2026-10-09 nằm trong kỳ, không có căn cứ chắc chắn để chọn)
- **NGAY_MO_HO** [HD50470, dòng 87] - 1.380.000 đ: Ngày bán mơ hồ, chưa tính vào tổng hợp: ô '10/09/2026' đọc được 2 cách: 2026-09-10 (ngày/tháng) hoặc 2026-10-09 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-09-10 nhưng cách còn lại 2026-10-09 nằm trong kỳ, không có căn cứ chắc chắn để chọn  
  Câu hỏi: Chứng từ HD50470 (dòng Excel 87): ngày bán đúng là ngày nào? (ô '10/09/2026' đọc được 2 cách: 2026-09-10 (ngày/tháng) hoặc 2026-10-09 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-09-10 nhưng cách còn lại 2026-10-09 nằm trong kỳ, không có căn cứ chắc chắn để chọn)
- **NGAY_MO_HO** [HD47118, dòng 117] - 816.000 đ: Ngày bán mơ hồ, chưa tính vào tổng hợp: ô '10/09/2026' đọc được 2 cách: 2026-09-10 (ngày/tháng) hoặc 2026-10-09 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-09-10 nhưng cách còn lại 2026-10-09 nằm trong kỳ, không có căn cứ chắc chắn để chọn  
  Câu hỏi: Chứng từ HD47118 (dòng Excel 117): ngày bán đúng là ngày nào? (ô '10/09/2026' đọc được 2 cách: 2026-09-10 (ngày/tháng) hoặc 2026-10-09 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-09-10 nhưng cách còn lại 2026-10-09 nằm trong kỳ, không có căn cứ chắc chắn để chọn)
- **NGAY_MO_HO** - 93.500.000 đ: File ghi ngày dạng chữ theo dd/mm/yyyy; 52 dòng có ngày đọc được 2 cách (ngày <= 12) đã được đọc theo dd/mm/yyyy (căn cứ: 107 ô chỉ đọc được là ngày/tháng, 0 ô chỉ đọc được là tháng/ngày)  
  Câu hỏi: Xin xác nhận file dùng định dạng ngày dd/mm/yyyy cho toàn bộ cột ngày. Từ kỳ sau đề nghị nhập ngày dạng ngày thật của Excel hoặc yyyy-mm-dd.
- **THIEU_DU_LIEU**: Không có dòng bán hàng nào có ngày xác định trong khoảng 2026-10-09 đến 2026-10-09; chỉ có các dòng ngày mơ hồ có thể thuộc khoảng này: HD89953 (dòng 47), HD50470 (dòng 87), HD47118 (dòng 117)  
  Câu hỏi: Chi nhánh có bán hàng trong khoảng 09/10/2026 - 09/10/2026 không? Nếu có xin gửi bổ sung dữ liệu (không tự điền số).
- **NGOAI_KY** [HD60907, dòng 25] - 1.200.000 đ: Dòng có ngày 2026-09-30, ngoài kỳ báo cáo 2026-10; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD60907 ngày 30/09/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 10/2026 không?
- **NGOAI_KY** [HD65097, dòng 28] - 3.700.000 đ: Dòng có ngày 2026-09-26, ngoài kỳ báo cáo 2026-10; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD65097 ngày 26/09/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 10/2026 không?
- **NGOAI_KY** [HD28722, dòng 66] - 2.220.000 đ: Dòng có ngày 2026-09-29, ngoài kỳ báo cáo 2026-10; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD28722 ngày 29/09/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 10/2026 không?
- **NGOAI_KY** [HD12045, dòng 82] - 680.000 đ: Dòng có ngày 2026-09-27, ngoài kỳ báo cáo 2026-10; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD12045 ngày 27/09/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 10/2026 không?
- **TRUNG** [HD59200, dòng 108] - 1.320.000 đ: Dòng trùng hoàn toàn với dòng 60 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 60  
  Câu hỏi: Chứng từ HD59200 xuất hiện 2 lần (dòng 60 và 108). Xin xác nhận chỉ tính 1 lần?
- **TRUNG** [HD37858, dòng 125] - 5.800.000 đ: Dòng trùng hoàn toàn với dòng 119 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 119  
  Câu hỏi: Chứng từ HD37858 xuất hiện 2 lần (dòng 119 và 125). Xin xác nhận chỉ tính 1 lần?
- **TRUNG** [HD64385, dòng 171] - 76.000 đ: Dòng trùng hoàn toàn với dòng 133 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 133  
  Câu hỏi: Chứng từ HD64385 xuất hiện 2 lần (dòng 133 và 171). Xin xác nhận chỉ tính 1 lần?
- **KHAC** [dòng 177]: Ghi chú của chi nhánh (dòng 177): "* Gồm 4 đơn tháng 9 nhập trễ (từ 26/09 đến 30/09)."  
  Câu hỏi: Ghi chú này ảnh hưởng thế nào đến số liệu tháng 10/2026 (số tiền, chứng từ liên quan)? Xin gửi bản điều chỉnh nếu cần.

### DN - Đà Nẵng

- **NGAY_MO_HO** - 95.472.000 đ: File ghi ngày dạng chữ theo mm/dd/yyyy; 55 dòng có ngày đọc được 2 cách (ngày <= 12) đã được đọc theo mm/dd/yyyy (căn cứ: 0 ô chỉ đọc được là ngày/tháng, 97 ô chỉ đọc được là tháng/ngày)  
  Câu hỏi: Xin xác nhận file dùng định dạng ngày mm/dd/yyyy cho toàn bộ cột ngày. Từ kỳ sau đề nghị nhập ngày dạng ngày thật của Excel hoặc yyyy-mm-dd.

### CT - Cần Thơ

- **THIEU_DU_LIEU**: Không có dòng bán hàng nào có ngày xác định trong khoảng 2026-10-15 đến 2026-10-21; số chứng từ liền kề khoảng thiếu là CT-0065 (dòng 72) và CT-0066 (dòng 73) liên tục nên không thấy chỗ nhảy số  
  Câu hỏi: Chi nhánh có bán hàng trong khoảng 15/10/2026 - 21/10/2026 không? Nếu có xin gửi bổ sung dữ liệu (không tự điền số).
- **SAN_PHAM_LA** [CT-0070, dòng 77] - 6.500.000 đ: Sản phẩm 'Combo quà Tết 2026' không có trong danh mục; ghi CHUA_XAC_DINH, vẫn tính vào doanh thu chi nhánh  
  Câu hỏi: Chứng từ CT-0070 bán 'Combo quà Tết 2026': đây là sản phẩm gì, có mã chuẩn nào trong danh mục không?
- **SAN_PHAM_LA** [CT-0072, dòng 79] - 6.500.000 đ: Sản phẩm 'Combo quà Tết 2026' không có trong danh mục; ghi CHUA_XAC_DINH, vẫn tính vào doanh thu chi nhánh  
  Câu hỏi: Chứng từ CT-0072 bán 'Combo quà Tết 2026': đây là sản phẩm gì, có mã chuẩn nào trong danh mục không?

### BH - Biên Hòa

- **NGAY_MO_HO** [PX-0016, dòng 18] - 180.000 đ: Ô ngày lưu 2026-04-10 (ngoài kỳ) đã được đọc là 2026-10-04 (đảo ngày/tháng) và tính vào tháng; căn cứ: file sắp theo thứ tự ngày; dòng trước (PX-0015) là 2026-10-04 và dòng sau (PX-0017) là 2026-10-04 nên chỉ cách đọc 2026-10-04 hợp lý  
  Câu hỏi: Chứng từ PX-0016 (dòng Excel 18): xin xác nhận ngày bán đúng là 04/10/2026, không phải 10/04/2026?
- **NGAY_MO_HO** [PX-0021, dòng 23] - 136.000 đ: Ô ngày lưu 2026-05-10 (ngoài kỳ) đã được đọc là 2026-10-05 (đảo ngày/tháng) và tính vào tháng; căn cứ: file sắp theo thứ tự ngày; dòng trước (PX-0020) là 2026-10-05 và dòng sau (PX-0022) là 2026-10-05 nên chỉ cách đọc 2026-10-05 hợp lý  
  Câu hỏi: Chứng từ PX-0021 (dòng Excel 23): xin xác nhận ngày bán đúng là 05/10/2026, không phải 10/05/2026?
- **NGAY_MO_HO** [PX-0035, dòng 38] - 4.710.000 đ: Ô ngày lưu 2026-08-10 (ngoài kỳ) đã được đọc là 2026-10-08 (đảo ngày/tháng) và tính vào tháng; căn cứ: file sắp theo thứ tự ngày; dòng trước (PX-0034) là 2026-10-07 và dòng sau (PX-0036) là 2026-10-08 nên chỉ cách đọc 2026-10-08 hợp lý  
  Câu hỏi: Chứng từ PX-0035 (dòng Excel 38): xin xác nhận ngày bán đúng là 08/10/2026, không phải 10/08/2026?

### NT - Nha Trang

- **NGAY_MO_HO** - 93.104.000 đ: File ghi ngày dạng chữ theo dd/mm/yyyy; 55 dòng có ngày đọc được 2 cách (ngày <= 12) đã được đọc theo dd/mm/yyyy (căn cứ: 107 ô chỉ đọc được là ngày/tháng, 0 ô chỉ đọc được là tháng/ngày)  
  Câu hỏi: Xin xác nhận file dùng định dạng ngày dd/mm/yyyy cho toàn bộ cột ngày. Từ kỳ sau đề nghị nhập ngày dạng ngày thật của Excel hoặc yyyy-mm-dd.
- **LECH_THANH_TIEN** [NT/0132, dòng 136] - 50.000 đ: Thành tiền 1.160.000 khác SL x đơn giá (6 x 185.000 = 1.110.000), lệch 50.000; giữ số chi nhánh ghi  
  Câu hỏi: Chứng từ NT/0132: SL 6 x giá 185.000 = 1.110.000 nhưng thành tiền ghi 1.160.000. Số nào đúng (SL, giá hay thành tiền)?
- **LECH_THANH_TIEN** [NT/0160, dòng 165] - 50.000 đ: Thành tiền 1.310.000 khác SL x đơn giá (6 x 210.000 = 1.260.000), lệch 50.000; giữ số chi nhánh ghi  
  Câu hỏi: Chứng từ NT/0160: SL 6 x giá 210.000 = 1.260.000 nhưng thành tiền ghi 1.310.000. Số nào đúng (SL, giá hay thành tiền)?
- **TRUNG** [NT/0060, dòng 64] - 1.425.000 đ: Dòng trùng hoàn toàn với dòng 63 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 63  
  Câu hỏi: Chứng từ NT/0060 xuất hiện 2 lần (dòng 63 và 64). Xin xác nhận chỉ tính 1 lần?
- **TRUNG** [NT/0138, dòng 143] - 720.000 đ: Dòng trùng hoàn toàn với dòng 142 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 142  
  Câu hỏi: Chứng từ NT/0138 xuất hiện 2 lần (dòng 142 và 143). Xin xác nhận chỉ tính 1 lần?

## 7. Cách xử lý và giả định

- Mỗi dòng bán hàng một dòng trong `hop_nhat.csv`; trạng thái `OK` (đọc rõ), `SUY_RA` (ngày đọc được 2 cách nhưng có căn cứ, căn cứ ghi ở cột ghi_chu), `CAN_NGUOI_QUYET` (không chắc, để trống ngày nếu liên quan ngày, không tính vào tổng hợp).
- Số tiền giữ đúng thành tiền chi nhánh ghi (kể cả dòng âm); dòng lệch SL x đơn giá giữ số chi nhánh ghi và đưa vào việc cần hỏi.
- Dòng trùng (cùng chi nhánh, cùng số chứng từ, cùng nội dung): chỉ giữ dòng đầu. Dòng ngoài kỳ 10/2026 không đưa vào bảng hợp nhất.
- Tên sản phẩm được quy về mã chuẩn theo quy tắc trong `gop.py` (bỏ dấu, chữ hoa/thường, viết tắt, kèm quy cách); không khớp thì ghi `CHUA_XAC_DINH`.
- Dòng trả hàng (số âm) giữ nguyên và trừ vào doanh thu: 1 dòng, tổng -120.000 đ (DN RT-0119).
- 7 nhóm dòng cùng chi nhánh, cùng ngày, cùng sản phẩm, SL, đơn giá và thành tiền nhưng KHÁC số chứng từ (HD43408 / HD15887; HD58994 / HD59320; HD44893 / HD59974; DN-0001 / DN-0002; NT/0055 / NT/0059; NT/0093 / NT/0095; NT/0156 / NT/0157). Theo quy tắc dòng trùng phải cùng số chứng từ nên vẫn tính là giao dịch riêng; chưa có căn cứ để cho là nhập hai lần.
- DN: 55 dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`).
- BH: 3 dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`).
- HP: 52 dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`).
- NT: 55 dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`).
