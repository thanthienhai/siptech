"""Đếm ý kiến theo tuần x chủ đề x sắc thái.

Đọc: ../danh-gia.csv (lấy ngày), loai-bo.csv (bài bị loại, không đếm), y-kien.csv (từng ý kiến).
Ghi: xu-huong-tuan.csv  (tuan = ngày thứ Hai đầu tuần, YYYY-MM-DD)
In ra màn hình: tổng số đánh giá, số bài loại, bảng chủ đề x sắc thái, số bài CAN_NGUOI_DOC.
Chạy: python tong-hop.py
"""
import csv
import os
import re
from collections import Counter
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
GOC = os.path.join(HERE, "..", "danh-gia.csv")

CHU_DE = ["gia", "phuc_vu", "chat_luong", "giao_hang", "khong_gian", "ve_sinh", "khac"]
SAC_THAI = ["tich_cuc", "tieu_cuc", "trung_tinh", "CAN_NGUOI_DOC"]


def doc_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def parse_ngay(s):
    s = s.strip()
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return datetime.strptime(s, "%Y-%m-%d").date()
    return datetime.strptime(s, "%d/%m/%Y").date()  # kiểu Việt Nam: ngày/tháng/năm


def thu_hai(d):
    return d - timedelta(days=d.weekday())


danh_gia = doc_csv(GOC)
loai_bo = doc_csv(os.path.join(HERE, "loai-bo.csv"))
y_kien = doc_csv(os.path.join(HERE, "y-kien.csv"))

ngay = {r["ma"]: parse_ngay(r["ngay"]) for r in danh_gia}
ma_loai = {r["ma"] for r in loai_bo}

dem = Counter()          # (tuan, chu_de, sac_thai) -> số ý
tong_cd_st = Counter()   # (chu_de, sac_thai) -> số ý
bai_can_doc = set()
bai_co_y = set()
bo_qua = 0
for r in y_kien:
    ma = r["ma"]
    if ma in ma_loai:     # bài đã loại bỏ thì không đếm
        bo_qua += 1
        continue
    if ma not in ngay:
        raise SystemExit(f"y-kien.csv có mã không có trong danh-gia.csv: {ma}")
    if r["chu_de"] not in CHU_DE or r["sac_thai"] not in SAC_THAI:
        raise SystemExit(f"Giá trị sai ở {ma}: {r['chu_de']} / {r['sac_thai']}")
    tuan = thu_hai(ngay[ma])
    dem[(tuan, r["chu_de"], r["sac_thai"])] += 1
    tong_cd_st[(r["chu_de"], r["sac_thai"])] += 1
    bai_co_y.add(ma)
    if r["sac_thai"] == "CAN_NGUOI_DOC":
        bai_can_doc.add(ma)

# ghi đủ mọi tuần liên tục từ tuần đầu đến tuần cuối, mọi chủ đề (có số 0)
tuan_dau = thu_hai(min(ngay.values()))
tuan_cuoi = thu_hai(max(ngay.values()))
cac_tuan = []
t = tuan_dau
while t <= tuan_cuoi:
    cac_tuan.append(t)
    t += timedelta(days=7)

with open(os.path.join(HERE, "xu-huong-tuan.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["tuan", "chu_de", "tich_cuc", "tieu_cuc", "trung_tinh", "can_nguoi_doc"])
    for t in cac_tuan:
        for cd in CHU_DE:
            w.writerow([t.isoformat(), cd] + [dem[(t, cd, s)] for s in SAC_THAI])

# ---- in tóm tắt ----
tong_bai = len(danh_gia)
print(f"Tong so danh gia: {tong_bai}")
print(f"So bai loai bo: {len(ma_loai)}  (trong do dem theo ly do: "
      f"{dict(Counter(r['ly_do'] for r in loai_bo))})")
print(f"So bai phan tich: {tong_bai - len(ma_loai)}  | bai co it nhat 1 y kien: {len(bai_co_y)}")
print(f"Tong so y kien (da loai bai bi loai): {sum(tong_cd_st.values())}  | y kien bi bo qua do bai bi loai: {bo_qua}")
print(f"So bai co it nhat 1 y CAN_NGUOI_DOC: {len(bai_can_doc)} -> {sorted(bai_can_doc)}")
print(f"So tuan: {len(cac_tuan)} ({cac_tuan[0]} -> {cac_tuan[-1]})")
print()
print("| chu_de | tich_cuc | tieu_cuc | trung_tinh | CAN_NGUOI_DOC | tong |")
print("|---|---:|---:|---:|---:|---:|")
tong_cot = Counter()
for cd in CHU_DE:
    so = [tong_cd_st[(cd, s)] for s in SAC_THAI]
    for s, n in zip(SAC_THAI, so):
        tong_cot[s] += n
    print(f"| {cd} | " + " | ".join(map(str, so)) + f" | {sum(so)} |")
print("| **tong** | " + " | ".join(str(tong_cot[s]) for s in SAC_THAI) + f" | {sum(tong_cot.values())} |")
