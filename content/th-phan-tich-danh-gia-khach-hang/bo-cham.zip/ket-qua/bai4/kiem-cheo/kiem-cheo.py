#!/usr/bin/env python3
"""Kiểm chéo độc lập đầu ra của agent khác. Chỉ đọc, không sửa file nào có sẵn.

Kiểm (a): mọi trích dẫn (y-kien.csv, nguy-cap.csv, các dòng "> [mã]" trong
bao-cao.md) phải là chuỗi con NGUYÊN VĂN của noi_dung đúng mã trong danh-gia.csv.
Kiểm (b): bảng chủ đề x sắc thái trong bao-cao.md phải khớp số đếm lại từ
y-kien.csv sau khi bỏ các mã trong loai-bo.csv.

Chỉ ghi một file: kiem-cheo.md (trong thư mục chứa script).
"""
import csv
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path

GOC = Path(__file__).resolve().parent
DANH_GIA = GOC / "danh-gia.csv"
Y_KIEN = GOC / "dau-ra" / "y-kien.csv"
NGUY_CAP = GOC / "dau-ra" / "nguy-cap.csv"
LOAI_BO = GOC / "dau-ra" / "loai-bo.csv"
BAO_CAO = GOC / "dau-ra" / "bao-cao.md"
KET_QUA = GOC / "kiem-cheo.md"
TOI_DA_DONG_MD = 15

SAC_THAI = {  # tên cột trong bảng -> giá trị trong y-kien.csv
    "Tích cực": "tich_cuc",
    "Tiêu cực": "tieu_cuc",
    "Trung tính": "trung_tinh",
    "Cần người đọc": "CAN_NGUOI_DOC",
}


def doc_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def rut(s, n=90):
    s = s.replace("\n", "\\n")
    return s if len(s) <= n else s[: n - 1] + "…"


def goi_y(trich, goc):
    """Gợi ý nguyên nhân khi KHÔNG phải chuỗi con. Chỉ để chẩn đoán, không nới tiêu chuẩn."""
    nfc = lambda s: unicodedata.normalize("NFC", s)
    ws = lambda s: re.sub(r"\s+", " ", s).strip()
    if nfc(trich) in nfc(goc):
        return "khác ở dạng mã hoá Unicode (NFC/NFD)"
    if ws(trich) in ws(goc):
        return "khác ở khoảng trắng/xuống dòng"
    if trich.lower() in goc.lower():
        return "khác ở chữ hoa/thường"
    if trich.strip(" .,;…") in goc:
        return "khác ở dấu câu/ký tự rìa"
    if "..." in trich or "…" in trich:
        return "có dấu ba chấm (ghép/rút gọn nhiều đoạn)"
    return "không tìm thấy trong noi_dung của mã này (diễn đạt lại hoặc sửa chữ)"


def kiem_trich_dan(ten_file, ma, trich, noi_dung, loi):
    """Trả True nếu qua; ngược lại ghi vào `loi`."""
    if trich is None or trich == "":
        loi.append((ten_file, ma, "(rỗng)", "trích dẫn rỗng"))
        return False
    if ma not in noi_dung:
        loi.append((ten_file, ma, trich, f"mã {ma} không có trong danh-gia.csv"))
        return False
    if trich in noi_dung[ma]:
        return True
    loi.append((ten_file, ma, trich, "không phải chuỗi con nguyên văn: " + goi_y(trich, noi_dung[ma])))
    return False


def phan_tich_trich_dan_md(dong):
    """Từ dòng '> [R170] "..."' tách (mã, câu). Bỏ đúng một cặp dấu ngoặc kép bao ngoài."""
    m = re.match(r"^>\s*\[([^\]]+)\]\s?(.*)$", dong)
    if not m:
        return None
    ma, cau = m.group(1).strip(), m.group(2).rstrip("\r\n")
    cau = cau.strip()
    for mo, dong_ in (('"', '"'), ("“", "”")):
        if len(cau) >= 2 and cau[0] == mo and cau[-1] == dong_:
            cau = cau[1:-1]
            break
    return ma, cau


def phan_tich_bang(dong_md):
    """Tìm bảng có tiêu đề 'Chủ đề | Tích cực | ...'; trả (hàng, số dòng bắt đầu)."""
    for i, d in enumerate(dong_md):
        if d.lstrip().startswith("|") and "Chủ đề" in d and "Tích cực" in d:
            tieu_de = [c.strip() for c in d.strip().strip("|").split("|")]
            hang = {}
            for d2 in dong_md[i + 2 :]:
                if not d2.lstrip().startswith("|"):
                    break
                o = [c.strip().replace("*", "") for c in d2.strip().strip("|").split("|")]
                hang[o[0]] = dict(zip(tieu_de[1:], o[1:]))
            return tieu_de, hang
    return None, None


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    loi = []        # (file, mã, nội dung nghi sai, lý do)
    so_dong = {}      # loại -> số dòng đã kiểm

    danh_gia = {r["ma"]: r["noi_dung"] for r in doc_csv(DANH_GIA)}

    # ---- (a) trích dẫn ----
    y_kien = doc_csv(Y_KIEN)
    for r in y_kien:
        kiem_trich_dan("y-kien.csv", r["ma"], r["trich_dan"], danh_gia, loi)
    so_dong["y-kien.csv (trich_dan)"] = len(y_kien)

    nguy_cap = doc_csv(NGUY_CAP)
    for r in nguy_cap:
        kiem_trich_dan("nguy-cap.csv", r["ma"], r["trich_dan"], danh_gia, loi)
    so_dong["nguy-cap.csv (trich_dan)"] = len(nguy_cap)

    dong_md = BAO_CAO.read_text(encoding="utf-8-sig").splitlines()
    n_md = 0
    for i, d in enumerate(dong_md, 1):
        if not d.startswith(">"):
            continue
        n_md += 1
        kq = phan_tich_trich_dan_md(d)
        if kq is None:
            loi.append(("bao-cao.md", f"dòng {i}", d, "dòng bắt đầu bằng '>' nhưng không đúng dạng '> [mã] \"câu\"'"))
            continue
        ma, cau = kq
        kiem_trich_dan("bao-cao.md", ma, cau, danh_gia, loi)
    so_dong["bao-cao.md (dòng trích dẫn)"] = n_md

    # ---- (b) bảng chủ đề x sắc thái ----
    loai_bo = {r["ma"] for r in doc_csv(LOAI_BO)}
    dem = Counter()
    n_bo = 0
    for r in y_kien:
        if r["ma"] in loai_bo:
            n_bo += 1
            continue
        dem[(r["chu_de"], r["sac_thai"])] += 1
    chu_de_csv = sorted({r["chu_de"] for r in y_kien if r["ma"] not in loai_bo})

    tieu_de, bang = phan_tich_bang(dong_md)
    n_o = 0
    if bang is None:
        loi.append(("bao-cao.md", "bảng", "(không thấy)", "không tìm thấy bảng 'Chủ đề | Tích cực | ...'"))
    else:
        hang_chu_de = [k for k in bang if k != "Tổng"]
        for cd in sorted(set(chu_de_csv) - set(hang_chu_de)):
            loi.append(("bao-cao.md", cd, "(thiếu hàng)", f"chủ đề '{cd}' có trong y-kien.csv nhưng không có hàng trong bảng"))
        for cd in sorted(set(hang_chu_de) - set(chu_de_csv)):
            loi.append(("bao-cao.md", cd, "(hàng thừa)", f"hàng '{cd}' trong bảng không có ý kiến nào trong y-kien.csv"))

        def so(s):
            return int(s) if re.fullmatch(r"\d+", s or "") else None

        for cd, o in bang.items():
            la_tong = cd == "Tổng"
            tong_hang_that = 0
            for cot, gia_tri in SAC_THAI.items():
                if la_tong:
                    that = sum(v for (c, s), v in dem.items() if s == gia_tri)
                else:
                    that = dem[(cd, gia_tri)]
                tong_hang_that += that
                n_o += 1
                ghi = so(o.get(cot))
                if ghi != that:
                    loi.append(("bao-cao.md", cd, f"{cot} = {o.get(cot)!r}", f"bảng ghi {o.get(cot)}, đếm lại từ y-kien.csv được {that}"))
            n_o += 1
            ghi = so(o.get("Tổng"))
            if ghi != tong_hang_that:
                loi.append(("bao-cao.md", cd, f"Tổng = {o.get('Tổng')!r}", f"bảng ghi {o.get('Tổng')}, đếm lại được {tong_hang_that}"))
    so_dong["bao-cao.md (ô số trong bảng)"] = n_o

    # ---- in kết quả ----
    print("SỐ DÒNG ĐÃ KIỂM:")
    for k, v in so_dong.items():
        print(f"  {k}: {v}")
    print(f"  (y-kien.csv: {n_bo} dòng thuộc mã có trong loai-bo.csv, không tính vào bảng đếm lại)")
    print(f"  danh-gia.csv: {len(danh_gia)} mã; loai-bo.csv: {len(loai_bo)} mã; y-kien.csv sau loại bỏ: {sum(dem.values())} ý")
    print(f"\nDÒNG KHÔNG QUA: {len(loi)}")
    for f, ma, nd, ly in loi:
        print(f"  [{f}] mã={ma} | nội dung: {rut(nd, 200)} | lý do: {ly}")

    # ---- ghi kiem-cheo.md (tối đa 15 dòng) ----
    cuoi = ("Script này KHÔNG kiểm được: ý nghĩa (chủ đề và sắc thái gán có đúng không, có sót ý hay "
            "loại bỏ/gắn nguy cấp nhầm không), cũng như văn xuôi, xu-huong-tuan.csv và cột ly_do, "
            "vì nó chỉ so chuỗi con và số đếm.")
    kiem_ma = Counter(f for f, *_ in loi)
    md = [
        "# Kiểm chéo đầu ra (do kiem-cheo.py đếm)",
        "Số dòng đã kiểm: " + "; ".join(f"{k} {v}" for k, v in so_dong.items()) + ".",
        f"Không qua: {len(loi)} dòng"
        + (" (" + "; ".join(f"{k} {v}" for k, v in sorted(kiem_ma.items())) + ")." if loi else "."),
    ]
    ngan_sach = TOI_DA_DONG_MD - len(md) - 1  # chừa 1 dòng cho câu cuối
    hien = loi
    if len(loi) > ngan_sach:
        hien = loi[: ngan_sach - 1]
    for f, ma, nd, ly in hien:
        md.append(f"- {f} | {ma} | \"{rut(nd.replace('|', '/'), 60)}\" | {ly}")
    if len(hien) < len(loi):
        md.append(f"- … và {len(loi) - len(hien)} dòng nữa: xem đầu ra đầy đủ khi chạy `python kiem-cheo.py`.")
    md.append(cuoi)
    assert len(md) <= TOI_DA_DONG_MD
    KET_QUA.write_text("\n".join(md) + "\n", encoding="utf-8")
    return 1 if loi else 0


if __name__ == "__main__":
    sys.exit(main())
