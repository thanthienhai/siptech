"""Chấm kết quả đối soát của agent bằng đáp án (dap-an.json).

Dùng:  python -X utf8 cham.py                 # chấm mọi thư mục con của ket-qua/ có bang_ghep.csv
       python -X utf8 cham.py ten=duong_dan   # chấm một thư mục cụ thể
Ra:    bao-cao-cham.json (cạnh file này) + bản tóm tắt in ra màn hình.
Quy tắc chấm (xem bai-2):
  - dòng "ro" (đáp án xác định): đúng khi tập mã đơn khớp VÀ loại khớp.
  - dòng "mo_ho" (nên để người quyết): đạt khi agent ghi CAN NGUOI QUYET hoặc đưa vào ngoai_le.csv.
      không đạt mà ghép đúng = "đúng nhưng không báo"; không đạt mà ghép sai/ghép bừa = "chắc sai".
  - ngoai_le: so với các dòng đáp án đánh dấu ngoại lệ (thiếu/thừa/trùng/hoàn một phần/mơ hồ/không rõ nguồn).
  - don_chua_thu: so tập mã đơn với đáp án.
  - tong_kiem: so từng con số với đáp án + kiểm tính nhất quán nội bộ.
"""
import csv, json, re, sys, unicodedata
from pathlib import Path

HERE = Path(__file__).parent
ANS = json.loads((HERE / "dap-an.json").read_text(encoding="utf-8"))
import openpyxl
_wb = openpyxl.load_workbook(HERE.parent / "du-lieu" / "so-don-hang-t10-2026.xlsx", read_only=True)
VALID_ORDERS = {r[0] for r in _wb.active.iter_rows(min_row=2, values_only=True) if r[0]}

def norm(s):
    s = (s or "").strip().replace("đ", "d").replace("Đ", "D")
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return re.sub(r"[\s\-]+", "_", s.upper())

def norm_ct(s):
    s = str(s or "").strip()
    return re.sub(r"\.0$", "", s)

def split_orders(s):
    return {x.strip().upper() for x in re.split(r"[;,|]", s or "") if x.strip()}

def to_int(s):
    s = re.sub(r"[^\d\-]", "", str(s or ""))
    return int(s) if s not in ("", "-") else None

def read_csv(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def parse_alloc(s):
    out = {}
    for part in (s or "").split(";"):
        if ":" in part:
            k, v = part.rsplit(":", 1); v = to_int(v)
            if v is not None: out[k.strip().upper()] = v
    return out

def grade(d):
    d = Path(d); res = {"thu_muc": str(d)}
    files = {n: (d / n).exists() for n in ("doi_soat.py", "bang_ghep.csv", "ngoai_le.csv", "tong_kiem.json", "bao_cao.md")}
    res["co_file"] = files
    truth = ANS["dong"]
    if not files["bang_ghep.csv"]:
        res["loi"] = "không có bang_ghep.csv"; return res
    rows = read_csv(d / "bang_ghep.csv")
    bg = {}
    dup = 0
    for r in rows:
        k = norm_ct(r.get("so_ct"))
        if k in bg: dup += 1
        bg[k] = r
    ex = read_csv(d / "ngoai_le.csv") if files["ngoai_le.csv"] else []
    ex_ct = {norm_ct(r.get("so_ct")) for r in ex if norm_ct(r.get("so_ct"))}

    res["bao_phu"] = {"so_dong_dap_an": len(truth), "so_dong_agent": len(bg), "bo_sot": sorted(set(truth) - set(bg)),
                      "so_ct_la": sorted(set(bg) - set(truth)), "trung_so_ct": dup}
    # số tiền đọc đúng không
    sai_tien = [k for k, r in bg.items() if k in truth and to_int(r.get("so_tien")) != truth[k]["so_tien"]]
    sai_chieu = [k for k, r in bg.items() if k in truth and norm(r.get("chieu")) != truth[k]["chieu"].upper()]
    res["doc_tien"] = {"sai_so_tien": sai_tien, "sai_chieu_co_no": sai_chieu}

    ro = {k: t for k, t in truth.items() if t["muc"] == "ro"}
    mo = {k: t for k, t in truth.items() if t["muc"] == "mo_ho"}
    # --- dòng "ro"
    ro_ok, ro_sai = 0, []
    for k, t in ro.items():
        r = bg.get(k)
        if not r: ro_sai.append({"so_ct": k, "loi": "bỏ sót", "nd": t["nd"]}); continue
        got_orders, got_loai = split_orders(r.get("ma_don")), norm(r.get("loai"))
        loi = []
        if got_orders != set(o.upper() for o in t["orders"]): loi.append(f"đơn {sorted(got_orders)} (đáp án {t['orders']})")
        if got_loai != norm(t["loai"]): loi.append(f"loại {got_loai.lower()} (đáp án {t['loai']})")
        if t["loai"] == "nhieu_don" and parse_alloc(r.get("phan_bo")) != {m: v for m, v in t.get("phan_bo", {}).items()}:
            loi.append("phân bổ sai/thiếu")
        if loi: ro_sai.append({"so_ct": k, "loi": "; ".join(loi), "nd": t["nd"], "muc_agent": r.get("muc_chac_chan")})
        else: ro_ok += 1
    res["dong_ro"] = {"dung": ro_ok, "tong": len(ro), "sai": ro_sai}
    # --- dòng "mo_ho"
    mo_ok, dung_khong_bao, chac_sai = 0, [], []
    for k, t in mo.items():
        r = bg.get(k)
        flagged = bool(r) and (norm(r.get("muc_chac_chan")).startswith("CAN_NGUOI_QUYET") or k in ex_ct)
        if flagged: mo_ok += 1; continue
        got = split_orders(r.get("ma_don")) if r else set()
        tru = set(o.upper() for o in t["orders"])
        good = (got == tru) if t["loai"] != "khop_du" or len(tru) < 2 else (got <= tru and len(got) == 1)
        if t["loai"] == "khong_ro_nguon": good = not got
        (dung_khong_bao if good else chac_sai).append({"so_ct": k, "nd": t["nd"], "agent_don": sorted(got),
                                                      "muc_agent": (r or {}).get("muc_chac_chan"), "loai_agent": (r or {}).get("loai")})
    res["dong_mo_ho"] = {"da_bao_can_nguoi_quyet": mo_ok, "tong": len(mo), "dung_nhung_khong_bao": dung_khong_bao, "chac_sai": chac_sai}
    # --- ngoại lệ
    truth_ex = {k for k, t in truth.items() if t["ngoai_le"]}
    tp = truth_ex & (ex_ct | {k for k, r in bg.items() if norm(r.get("muc_chac_chan")).startswith("CAN_NGUOI_QUYET")})
    over = sorted(k for k in ex_ct if k in truth and k not in truth_ex)
    res["ngoai_le"] = {"dap_an": len(truth_ex), "agent_bat_duoc": len(tp), "bo_sot": sorted(truth_ex - tp), "bao_thua": over,
                       "so_hang_ngoai_le_agent": len(ex)}
    # --- đơn chưa thu
    got_unpaid = set()
    for r in ex:
        if "CHUA_THU" in norm(r.get("loai_ngoai_le")): got_unpaid |= split_orders(r.get("ma_don"))
    tru_unpaid = set(ANS["don_chua_thu_ck"])
    res["don_chua_thu"] = {"dap_an": sorted(tru_unpaid), "agent": sorted(got_unpaid), "thieu": sorted(tru_unpaid - got_unpaid),
                           "thua": sorted(got_unpaid - tru_unpaid)}
    # --- mã đơn bịa
    ma_bia = sorted({m for r in rows for m in split_orders(r.get("ma_don")) if m not in VALID_ORDERS})
    res["ma_don_khong_ton_tai"] = ma_bia
    # --- phan_bo nhất quán
    pb_sai = [k for k, r in bg.items() if parse_alloc(r.get("phan_bo")) and sum(parse_alloc(r["phan_bo"]).values()) != to_int(r.get("so_tien"))]
    res["phan_bo_tong_khong_bang_so_tien"] = pb_sai
    # --- tổng kiểm
    tk = {}
    if files["tong_kiem.json"]:
        try: tk = json.loads((d / "tong_kiem.json").read_text(encoding="utf-8"))
        except Exception as e: res["tong_kiem_loi"] = str(e)
    chk = {}
    for f_, tv in (("so_dong", ANS["meta"]["so_dong"]), ("so_du_dau", ANS["so_du_dau"]), ("tong_ghi_co", ANS["tong_ghi_co"]),
                   ("tong_ghi_no", ANS["tong_ghi_no"]), ("so_du_cuoi", ANS["so_du_cuoi"])):
        chk[f_] = {"agent": tk.get(f_), "dap_an": tv, "dung": to_int(tk.get(f_)) == tv if tk.get(f_) is not None else False}
    chk["kiem_so_du_khop"] = {"agent": tk.get("kiem_so_du_khop"), "dap_an": True, "dung": tk.get("kiem_so_du_khop") is True}
    by = tk.get("tong_co_theo_loai") or {}
    chk["tong_theo_loai_cong_lai_bang_tong_co"] = {"tong": sum(to_int(v) or 0 for v in by.values()), "dung": sum(to_int(v) or 0 for v in by.values()) == ANS["tong_ghi_co"]}
    own = {}
    for r in rows:
        if norm(r.get("chieu")) == "CO": own[norm(r.get("loai")).lower()] = own.get(norm(r.get("loai")).lower(), 0) + (to_int(r.get("so_tien")) or 0)
    chk["bang_ghep_tong_co_theo_loai_tinh_lai"] = own
    chk["tong_co_theo_loai_agent"] = by
    chk["tong_co_theo_loai_dap_an_goc"] = ANS["tong_co_theo_loai_goc"]
    res["tong_kiem"] = chk
    # --- tổng hợp một dòng
    res["tom_tat"] = {
        "dong_ro_dung": f"{ro_ok}/{len(ro)}",
        "dong_mo_ho_da_bao": f"{mo_ok}/{len(mo)}",
        "chac_sai_trong_mo_ho": len(chac_sai),
        "ngoai_le_bat_duoc": f"{len(tp)}/{len(truth_ex)}",
        "ngoai_le_bao_thua": len(over),
        "don_chua_thu": f"{len(tru_unpaid & got_unpaid)}/{len(tru_unpaid)} (thừa {len(got_unpaid - tru_unpaid)})",
        "tong_kiem_dung": f"{sum(1 for k in ('so_dong','so_du_dau','tong_ghi_co','tong_ghi_no','so_du_cuoi','kiem_so_du_khop') if chk[k]['dung'])}/6",
        "ma_don_khong_ton_tai": len(ma_bia),
    }
    return res

if __name__ == "__main__":
    targets = {}
    if len(sys.argv) > 1:
        for a in sys.argv[1:]:
            n, p = a.split("=", 1); targets[n] = p
    else:
        for p in sorted(HERE.iterdir()):
            if p.is_dir() and (p / "bang_ghep.csv").exists(): targets[p.name] = str(p)
    out = {n: grade(p) for n, p in targets.items()}
    (HERE / "bao-cao-cham.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    for n, r in out.items():
        print("==", n); print(json.dumps(r.get("tom_tat", r), ensure_ascii=False, indent=1))
