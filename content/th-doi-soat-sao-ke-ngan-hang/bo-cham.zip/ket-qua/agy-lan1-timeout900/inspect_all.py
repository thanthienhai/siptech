import pandas as pd
import openpyxl, re, csv, unicodedata

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

# Load orders
df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
df_orders['amount'] = df_orders['Tổng phải thu'].apply(clean_amount)
df_orders['kh_clean'] = df_orders['Khách hàng'].apply(strip_accents).str.upper()

# Load sao ke
with open('sao-ke-t10-2026.csv', encoding='utf-8-sig') as f:
    rows = list(csv.reader(f))

txs = [r for r in rows[8:] if r and r[0] and 'Tong phat sinh' not in r[0] and 'So du cuoi' not in r[0]]

print(f"=== CHECKING TRANSACTIONS WITHOUT EXPLICIT ORDERS OR SPECIAL CASES ===")
# Let's inspect each transaction in detail
for idx, r in enumerate(txs):
    so_ct, ngay, no, co, du, nd = r[1], r[0], r[2], r[3], r[4], r[5]
    chieu = 'no' if no.strip() else 'co'
    st = int(no.replace(',', '')) if chieu == 'no' else int(co.replace(',', ''))
    
    # Check potential matching orders by amount
    same_amt_orders = df_orders[df_orders['amount'] == st]
    
    # Check potential matching orders by name
    nd_clean = strip_accents(nd).upper()
    matching_name_orders = []
    for _, o in df_orders.iterrows():
        # check if full name or initials match
        kh_parts = o['kh_clean'].split()
        initials = ''.join(p[0] for p in kh_parts)
        # check if kh_clean in nd_clean or initials in nd_clean
        if o['kh_clean'] in nd_clean:
            matching_name_orders.append((o['Mã đơn'], o['Khách hàng'], o['amount'], o['Hình thức TT']))
        elif initials in nd_clean.split() or f"{initials} " in nd_clean or f" {initials}" in nd_clean:
            matching_name_orders.append((o['Mã đơn'], o['Khách hàng'], o['amount'], o['Hình thức TT']))
            
    print(f"\nTX #{idx+1} | {so_ct} | {ngay} | {chieu} | {st:,d} | {nd}")
    if matching_name_orders:
        print(f"  Name matches: {matching_name_orders}")
    if len(same_amt_orders) > 0 and len(same_amt_orders) <= 5:
        print(f"  Amt matches ({len(same_amt_orders)}): {[(o['Mã đơn'], o['Khách hàng'], o['amount'], o['Hình thức TT']) for _, o in same_amt_orders.iterrows()]}")
    elif len(same_amt_orders) > 5:
        print(f"  Amt matches ({len(same_amt_orders)} orders with amount {st:,d})")
