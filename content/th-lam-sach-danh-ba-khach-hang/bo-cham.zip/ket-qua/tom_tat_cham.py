"""In bảng tóm tắt từ file JSON do cham.py ghi ra (mặc định bao-cao-cham.json cạnh script).

Dùng:  python -X utf8 tom_tat_cham.py [file.json]
"""
import json, sys
from pathlib import Path

p = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent / "bao-cao-cham.json"
kq = json.loads(p.read_text(encoding="utf-8"))["ket_qua"]
rows = [
    ("Nhóm gộp đúng trọn vẹn", lambda r: f"{r['gop_chac']['gop_dung_tron_ven']}/{r['gop_chac']['tong_nhom']}"),
    ("Cặp bị gộp nhầm", lambda r: str(r["gop_nham"]["tong_cap_nham"])),
    ("Ca cần người quyết, báo đúng", lambda r: f"{r['ca_can_nguoi_quyet']['bao_dung_va_khong_gop']}/{r['ca_can_nguoi_quyet']['tong']}"),
    ("SĐT đúng", lambda r: r["truong"]["sdt_dung"]),
    ("Email đúng", lambda r: r["truong"]["email_dung"]),
    ("Địa chỉ khớp", lambda r: r["truong"]["dia_chi_khop_sau_mo_viet_tat"]),
    ("SĐT lạ (bịa)", lambda r: str(r["bia_hoac_doan"]["sdt_la"])),
    ("Chạy lại ra file giống", lambda r: "có" if all(r.get("chay_lai_script", {}).get("giong_het", {"x": False}).values()) else "không"),
    ("File gốc nguyên vẹn", lambda r: "có" if r["file_goc_nguyen_ven"] else "không"),
]
w = max(len(a) for a, _ in rows)
print(" " * w, " | ".join(f"{k:>16}" for k in kq))
for a, f in rows:
    print(f"{a:<{w}}", " | ".join(f"{f(r):>16}" for r in kq.values()))
