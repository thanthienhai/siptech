"""Cham ket qua cua agent bang dap-an (ket-qua/dap-an.json). Khong dung mo hinh de cham.

Chay:  python -X utf8 cham.py <nhan>=<thu_muc_chay> [<nhan>=<thu_muc_chay> ...]
Vi du: python -X utf8 cham.py claude-1=../../runs/claude agy-1=../../runs/agy
Ghi/ cap nhat ket-qua/bao-cao-cham.json (moi nhan mot muc).

Cham:
 1. dung dinh dang file/ cot
 2. phat hien loi nhap lieu da cai (recall theo loai) + xu ly co dung khong + bao nham
 3. ABC khop dap-an
 4. du bao F / ton an toan / diem dat lai so voi ket qua tham chieu (cong thuc co dinh tren du lieu sach)
 5. thang cut hang (ma-thang) khop
 6. nhan canh bao khop
 7. de xuat nhap: tong tien <= ngan sach, thanh tien dung, boi so quy cach, hang het/ sap het lop A-B co duoc nhap, hang e khong bi nhap
 8. giu lai (hold-out): tinh lai MAE/WAPE tu so du bao cua agent so voi thuc te that, so voi moc thang truoc
"""
import csv, json, sys, re, math
from pathlib import Path

HERE = Path(__file__).parent
ANS = json.loads((HERE / "dap-an.json").read_text(encoding="utf-8"))
SKU = ANS["sku"]; BUDGET = ANS["ngan_sach"]

COLS = {
    "loi-du-lieu.csv": ["ma_phieu", "loai_loi", "ma_hang", "xu_ly", "ly_do"],
    "phan-loai-tinh-toan.csv": ["ma_hang", "lop_abc", "gia_tri_tieu_thu_nam", "so_thang_hop_le", "thang_cut_hang", "nhu_cau_du_bao_thang", "do_lech_chuan",
                                "ton_an_toan", "diem_dat_lai", "ton_kiem_ke", "ton_he_thong", "chenh_kiem_ke", "hang_dang_ve", "so_ngay_ton",
                                "cung_ky_nam_truoc_2025_11", "canh_bao"],
    "de-xuat-nhap.csv": ["ma_hang", "sl_can_chua_xet_ngan_sach", "sl_de_xuat", "quy_cach", "don_gia_von", "thanh_tien", "uu_tien", "can_nguoi_quyet", "ly_do"],
    "giu-lai-do-loi.csv": ["ma_hang", "thang", "thuc_te", "du_bao", "moc_thang_truoc", "tinh_duoc"],
}

def num(x, default=None):
    try:
        s = str(x).strip().replace(" ", "")
        if s == "" or s.lower() in ("nan", "none", "inf"): return default
        return float(s)
    except Exception:
        return default

def read(p):
    if not p.exists(): return None
    with open(p, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def norm(c): return (c or "").strip().upper().replace("-", "").replace(" ", "")

def close(a, b, rel, absu):
    return a is not None and abs(a - b) <= max(absu, rel * abs(b))

def cham(run: Path):
    R = {"thu_muc": str(run)}
    tabs = {}
    fmt = {}
    for fn, cols in COLS.items():
        rows = read(run / fn)
        if rows is None: fmt[fn] = "THIEU FILE"; continue
        got = list(rows[0].keys()) if rows else []
        miss = [c for c in cols if c not in got]
        fmt[fn] = {"so_dong": len(rows), "thieu_cot": miss}
        tabs[fn] = rows
    R["dinh_dang"] = fmt
    R["co_bao_cao_md"] = (run / "bao-cao.md").exists(); R["co_script"] = (run / "tinh_ton_kho.py").exists()

    # ---------- 2. loi nhap lieu
    must = {"trung_dong", "so_am_khong_ghi_chu", "so_luong_gap_10_lan", "thieu_so_luong", "ngay_nhap_o_tuong_lai"}
    truth_err = {}
    for e in ANS["loi"]:
        if e["loai_loi"] in must: truth_err.setdefault(e["loai_loi"], {})[e["ma_phieu"]] = e
    legit = {e["ma_phieu"] for e in ANS["loi"] if e["loai_loi"] not in must and e["loai_loi"] != "dong_bi_mat"}
    bulk = {e["ma_phieu"] for e in ANS["loi"] if e["loai_loi"] == "don_si_mot_lan"}
    deleted = {e["ma_phieu"] for e in ANS["loi"] if e["loai_loi"] == "dong_bi_mat"}
    L = tabs.get("loi-du-lieu.csv")
    if L is not None:
        flagged = {}
        for r in L: flagged.setdefault((r.get("ma_phieu") or "").strip().upper(), []).append(r)
        ok_xl = {"trung_dong": {"BO"}, "so_am_khong_ghi_chu": {"SUA", "CAN_NGUOI_QUYET"}, "so_luong_gap_10_lan": {"SUA", "BO", "CAN_NGUOI_QUYET"},
                 "thieu_so_luong": {"CAN_NGUOI_QUYET"}, "ngay_nhap_o_tuong_lai": {"SUA", "CAN_NGUOI_QUYET"}}
        det = {}; tot_det = tot = tot_ok = 0; miss_list = []; wrong_xl = []
        for k, d in truth_err.items():
            hit = ok = 0
            for mp in d:
                tot += 1
                rs = flagged.get(mp.upper())
                if rs:
                    hit += 1; tot_det += 1
                    xl = {(x.get("xu_ly") or "").strip().upper() for x in rs}
                    if xl & ok_xl[k]: ok += 1; tot_ok += 1
                    else: wrong_xl.append((mp, k, sorted(xl)))
                else: miss_list.append((mp, k))
            det[k] = {"phat_hien": hit, "tong": len(d), "xu_ly_dung": ok}
        R["loi_du_lieu"] = {"theo_loai": det, "phat_hien": f"{tot_det}/{tot}", "xu_ly_dung": f"{tot_ok}/{tot}",
                            "bo_sot": miss_list, "xu_ly_sai": wrong_xl,
                            "don_si_phat_hien": f"{sum(1 for m in bulk if m.upper() in flagged)}/{len(bulk)}",
                            "dong_bi_mat_duoc_phat_hien(khong_the_thay_trong_nhat_ky)": sum(1 for m in deleted if m.upper() in flagged)}
        known = set(truth_err_k for d in truth_err.values() for truth_err_k in (x.upper() for x in d)) | {m.upper() for m in legit | bulk | deleted}
        # ca hop le nhung de nham: dong thieu ma hang (chi co ten), phieu nhap "nhap cho don si"; dong tong hop (ma_phieu khong phai PX/PN/DC) khong tinh
        raw = list(csv.DictReader(open(HERE.parent / "du-lieu/nhat-ky-xuat-nhap.csv", encoding="utf-8-sig")))
        known |= {r["ma_phieu"].upper() for r in raw if not (r["ma_hang"] or "").strip() or "nhap cho don si" in (r["ghi_chu"] or "")}
        pat = re.compile(r"^(PX|PN|DC)\d+$")
        summ = [m for m in flagged if not pat.match(m)]
        fake = [m for m in flagged if m not in known and pat.match(m)]
        R["loi_du_lieu"]["bao_nham"] = {"so_ma_phieu": len(fake), "vi_du": fake[:10], "dong_tong_hop_khong_tinh": len(summ)}
    # ---------- 3-6 phan loai / tinh toan
    P = tabs.get("phan-loai-tinh-toan.csv")
    amb = set(ANS["sku_mo_ho"])
    clean = [c for c in SKU if c not in amb]
    if P is not None:
        pr = {norm(r.get("ma_hang")): r for r in P}
        R["so_ma_hang"] = f"{sum(1 for c in SKU if norm(c) in pr)}/{len(SKU)}"
        abc_ok = [c for c in SKU if norm(c) in pr and (pr[norm(c)].get("lop_abc") or "").strip().upper() == SKU[c]["abc"]]
        abc_bad = [(c, SKU[c]["abc"], (pr.get(norm(c), {}).get("lop_abc") or "").strip().upper()) for c in SKU if c not in abc_ok]
        R["abc"] = {"khop": f"{len(abc_ok)}/{len(SKU)}", "sai": abc_bad}
        for key, label, rel, absu in (("nhu_cau_du_bao_thang", "F", 0.10, 1.0), ("ton_an_toan", "SS", 0.25, 2.0), ("diem_dat_lai", "ROP", 0.25, 2.0)):
            refk = {"nhu_cau_du_bao_thang": "F", "ton_an_toan": "ss", "diem_dat_lai": "rop"}[key]
            good = 0; bad = []
            for c in clean:
                v = num(pr.get(norm(c), {}).get(key)); t = SKU[c]["ref"][refk]
                if close(v, t, rel, absu): good += 1
                else: bad.append((c, v, round(t, 1)))
            R[f"{label}_khop_tham_chieu"] = {"dung_dung_sai": f"{good}/{len(clean)}", "dung_sai": f"{int(rel*100)}% hoac {absu} don vi", "lech_nhieu": bad[:12]}
        # cut months
        tp = fp = fn = 0
        for c in SKU:
            ref = set(SKU[c]["ref"]["cut_months"])
            got = {m.strip() for m in re.split(r"[;,\s]+", pr.get(norm(c), {}).get("thang_cut_hang") or "") if re.match(r"\d{4}-\d{2}", m.strip())}
            tp += len(ref & got); fp += len(got - ref); fn += len(ref - got)
        R["thang_cut_hang"] = {"dung": tp, "bao_thua": fp, "bo_sot": fn, "tong_tham_chieu": tp + fn}
        conf = {}; same = 0
        for c in SKU:
            a = (pr.get(norm(c), {}).get("canh_bao") or "").strip().upper(); t = SKU[c]["ref"]["canh_bao"]
            conf[f"{t}->{a}"] = conf.get(f"{t}->{a}", 0) + 1; same += (a == t)
        R["canh_bao"] = {"khop": f"{same}/{len(SKU)}", "ma_tran(tham_chieu->agent)": dict(sorted(conf.items()))}
        # chenh kiem ke
        R["ton_he_thong_vs_kiem_ke"] = {"so_ma_agent_bao_chenh": sum(1 for r in P if (num(r.get("chenh_kiem_ke"), 0) or 0) != 0)}
    # ---------- 7 de xuat
    md_text = (run / "bao-cao.md").read_text(encoding="utf-8", errors="replace") if (run / "bao-cao.md").exists() else ""
    D = tabs.get("de-xuat-nhap.csv")
    if D is not None:
        dr = {norm(r.get("ma_hang")): r for r in D}
        tong = sum(num(r.get("thanh_tien"), 0) or 0 for r in D)
        tong_tinh_lai = sum((num(r.get("sl_de_xuat"), 0) or 0) * SKU[c]["gia_von"] for r in D for c in [next((k for k in SKU if norm(k) == norm(r.get("ma_hang"))), None)] if c)
        sai_tien = [r["ma_hang"] for r in D if abs((num(r.get("sl_de_xuat"), 0) or 0) * (num(r.get("don_gia_von"), 0) or 0) - (num(r.get("thanh_tien"), 0) or 0)) > 1]
        sai_gia = [r["ma_hang"] for r in D if num(r.get("don_gia_von")) is not None and next((k for k in SKU if norm(k) == norm(r.get("ma_hang"))), None)
                   and num(r.get("don_gia_von")) != SKU[next(k for k in SKU if norm(k) == norm(r.get("ma_hang")))]["gia_von"]]
        sai_boi = [r["ma_hang"] for r in D if next((k for k in SKU if norm(k) == norm(r.get("ma_hang"))), None)
                   and (num(r.get("sl_de_xuat"), 0) or 0) % SKU[next(k for k in SKU if norm(k) == norm(r.get("ma_hang")))]["pack"] != 0]
        hetA = [c for c in SKU if SKU[c]["ref"]["canh_bao"] in ("HET_HANG", "SAP_HET") and SKU[c]["abc"] in ("A", "B") and SKU[c]["ref"]["qty"] > 0]
        hetA_ok = [c for c in hetA if (num(dr.get(norm(c), {}).get("sl_de_xuat"), 0) or 0) > 0]
        e_bi_nhap = [c for c in SKU if SKU[c]["ref"]["canh_bao"] == "TON_LAU" and (num(dr.get(norm(c), {}).get("sl_de_xuat"), 0) or 0) > 0]
        chua_cat_khop = sum(1 for c in clean if close(num(dr.get(norm(c), {}).get("sl_can_chua_xet_ngan_sach")), SKU[c]["ref"]["qty"], 0.2, SKU[c]["pack"])) if D else 0
        tong_chua_cat = sum(num(r.get("sl_can_chua_xet_ngan_sach"), 0) * SKU[next(k for k in SKU if norm(k) == norm(r["ma_hang"]))]["gia_von"] for r in D
                            if next((k for k in SKU if norm(k) == norm(r.get("ma_hang"))), None) and num(r.get("sl_can_chua_xet_ngan_sach")) is not None)
        R["de_xuat"] = {"tong_tien_agent_ghi": tong, "tong_tien_tinh_lai_tu_sl_x_gia_dung": tong_tinh_lai, "ngan_sach": BUDGET,
                        "khong_vuot_ngan_sach": bool(tong_tinh_lai <= BUDGET), "tong_chua_cat_agent(tinh lai)": tong_chua_cat, "tong_chua_cat_tham_chieu": ANS["tong_tien_chua_cat"],
                        "thanh_tien_sai": sai_tien, "don_gia_sai": sai_gia, "sl_khong_la_boi_quy_cach": sai_boi,
                        "hang_het/sap_het_lop_A_B_can_nhap": f"{len(hetA_ok)}/{len(hetA)}", "hang_ton_lau_ma_bi_de_xuat_nhap": e_bi_nhap,
                        "sl_chua_cat_khop_tham_chieu_(20%_hoac_1_quy_cach)": f"{chua_cat_khop}/{len(clean)}"}
        # bay: MP002 het hang, hang dang ve den ngay 2026-12-27 (sau thang de xuat). Cong thuc van tru 12 -> de xuat 0. Agent co bao cho nguoi quyet khong?
        m = dr.get("MP002", {})
        txt = (m.get("ly_do") or "") + " " + md_text
        R["de_xuat"]["bay_MP002_hang_ve_27/12_duoc_bao_can_nguoi_quyet"] = bool((m.get("can_nguoi_quyet") or "").upper() == "CO" and re.search(r"27/12|2026-12-27|12-27", txt))
        R["de_xuat"]["MP002_sl_de_xuat"] = m.get("sl_de_xuat")
    # ---------- 8 hold-out
    H = tabs.get("giu-lai-do-loi.csv")
    if H is not None:
        res = {}
        for h in ("2026-09", "2026-10"):
            rows = [r for r in H if (r.get("thang") or "").strip() == h and (r.get("tinh_duoc") or "").strip().upper() == "CO"]
            A = F = N = 0.0; AE_F = AE_N = 0.0; n = 0; sai_thuc_te = 0
            for r in rows:
                c = next((k for k in SKU if norm(k) == norm(r.get("ma_hang"))), None)
                if not c: continue
                t = SKU[c]["ref"]["holdout"][h]
                f = num(r.get("du_bao")); nv = num(r.get("moc_thang_truoc"))
                if f is None or nv is None: continue
                n += 1; A += t["actual"]; AE_F += abs(f - t["actual"]); AE_N += abs(t["naive"] - t["actual"]) if False else abs(nv - t["actual"])
                if num(r.get("thuc_te")) != t["actual"]: sai_thuc_te += 1
            ref_rows = [(c, SKU[c]["ref"]["holdout"][h]) for c in SKU if SKU[c]["ref"]["holdout"][h]["eligible"]]
            rA = sum(x["actual"] for _, x in ref_rows)
            res[h] = {"n_agent_tinh_duoc": n, "n_tham_chieu": len(ref_rows), "thuc_te_khac_that": sai_thuc_te,
                      "WAPE_agent(tinh lai)": round(AE_F / A, 4) if A else None, "WAPE_moc_thang_truoc(tinh lai)": round(AE_N / A, 4) if A else None,
                      "MAE_agent": round(AE_F / n, 3) if n else None, "MAE_moc": round(AE_N / n, 3) if n else None,
                      "WAPE_tham_chieu_ma_dap_an": round(sum(abs(x["f_ref"] - x["actual"]) for _, x in ref_rows) / rA, 4),
                      "WAPE_moc_tham_chieu": round(sum(abs(x["naive"] - x["actual"]) for _, x in ref_rows) / rA, 4)}
        R["giu_lai"] = res
    # ---------- bao cao md
    md = (run / "bao-cao.md").read_text(encoding="utf-8", errors="replace") if (run / "bao-cao.md").exists() else ""
    R["bao_cao_noi_ve"] = {"CAN NGUOI QUYET": bool(re.search(r"CẦN NGƯỜI QUYẾT|CAN NGUOI QUYET|CAN_NGUOI_QUYET", md, re.I)),
                           "ngan_sach": "ngân sách" in md.lower(), "cung_ky_khong_lam_duoc_cho_hold-out": bool(re.search(r"cùng kỳ", md, re.I)),
                           "n_nho": bool(re.search(r"n nhỏ|mẫu nhỏ|ít dữ liệu|chỉ \d+ tháng|chưa đủ", md, re.I)), "so_ky_tu": len(md)}
    return R

if __name__ == "__main__":
    out = HERE / "bao-cao-cham.json"
    allr = json.loads(out.read_text(encoding="utf-8")) if out.exists() else {}
    for a in sys.argv[1:]:
        label, path = a.split("=", 1)
        allr[label] = cham(Path(path).resolve())
        print("==", label); print(json.dumps(allr[label], ensure_ascii=False, indent=1)[:6000])
    out.write_text(json.dumps(allr, ensure_ascii=False, indent=1), encoding="utf-8")
