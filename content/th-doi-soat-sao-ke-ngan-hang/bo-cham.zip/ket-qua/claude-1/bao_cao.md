# Báo cáo đối soát tháng 10/2026
- Sao kê 144 dòng (ghi có 130.898.650 đ, ghi nợ 75.116.000 đ); số dư cuối 95.782.650 đ, kiểm số dư khớp dòng tổng: ĐÚNG.
- Mức chắc chắn: 65 CAO, 70 TRUNG BINH, 9 CAN NGUOI QUYET (dòng chi/phí phân loại theo từ khóa nên ghi TRUNG BINH, không cần xử lý).
- Ghi có đã ghép đơn 112.810.000 đ; chưa ghép/cần người quyết 18.088.650 đ (trong đó COD gộp 7.750.000 đ, lãi ngân hàng 18.650 đ, còn lại 10.320.000 đ cần người quyết).
- Cần người quyết: 9 dòng ghi có (3 có đơn ứng viên: mã trong nội dung mâu thuẫn với tên/số tiền; 6 tiền không rõ nguồn). Chi tiết ở ngoai_le.csv.
- Chuyển thiếu 4 dòng (tổng thiếu 250.000 đ); chuyển thừa 4 dòng (thừa 430.000 đ); chuyển trùng 3 dòng (2.880.000 đ); nhiều đơn một lần chuyển 6 dòng.
- Hoàn tiền 3 dòng, trong đó 1 ca hoàn một phần (giữ lại một khoản).
- Đơn CK chưa có tiền và chưa hủy: 13 đơn, tổng 7.350.000 đ; 8 đơn đang giao (đặt cuối tháng), 3 đơn là ứng viên của dòng đang chờ người quyết.
- COD: 2 lô đối soát của hãng ghép khớp tổng với dãy đơn COD liên tiếp; còn 8 đơn COD đã giao (9.350.000 đ) chờ đối soát lô sau.
- Không chắc: (1) ghép lô COD chỉ dựa vào tổng tiền và thứ tự đơn, cần bảng kê hãng; (2) ca 'don 003 HOANG KIM VY' ghép theo mã+số tiền dù tên khác khách trên đơn;
  (3) hai khách trùng tên Trần Văn Bình (2 SĐT) ghép theo ngày đặt đơn; (4) 3 dòng sai mã đơn (nghiêng về đơn khớp tên+số tiền) tôi không tự chốt, theo đúng quy tắc.
- Quy ước: dòng CAN NGUOI QUYET ghi loai=khong_ro_nguon, ma_don là ứng viên, phan_bo để trống, chưa tính vào 'đã ghép'.
