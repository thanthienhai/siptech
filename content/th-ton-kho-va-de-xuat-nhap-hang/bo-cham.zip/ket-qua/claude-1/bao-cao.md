# Báo cáo kho tháng 2026-11

_Dữ liệu GIẢ để học (60 mã hàng, 2025-11 đến 2026-10). Mọi con số dưới đây chỉ là ĐỀ XUẤT; chủ cửa hàng quyết định số cuối cùng. File chi tiết: `de-xuat-nhap.csv`, `phan-loai-tinh-toan.csv`, `giu-lai-do-loi.csv`, `loi-du-lieu.csv`; chương trình: `tinh_ton_kho.py`._

## 1. Tóm tắt

1. **Đề xuất nhập tháng 11:** 9 mã, tổng tiền vốn **29.936.000 đ**, bằng 99,8% ngân sách 30.000.000 đ (không vượt).
2. **Phần bị cắt:** theo công thức cần nhập 41.104.400 đ, vượt ngân sách 11.104.400 đ; đã cắt 11.168.400 đ ở 16 mã (mục 2). Chủ cần xem lại danh sách cắt.
3. **Đáng lo:** 2 mã hết hàng (MP002, MP011), 9 mã sắp hết, 5 mã tồn lâu, 1 mã bán chậm. Riêng **MP002** hết hàng mà hàng đang về dự kiến 2026-12-27 (sau tháng 11), nên đề xuất 0 của công thức có nguy cơ sai.
4. **Dự báo:** trên 2 tháng giữ lại (09, 10), công thức trung bình 3 tháng **thua** mốc "bằng tháng liền trước": WAPE 35,8% so với 26,4% (n = 109 mã-tháng, mẫu nhỏ).
5. **Dữ liệu:** ghi nhận 133 dòng lỗi/ca đặc biệt, 22 dòng CẦN NGƯỜI QUYẾT. Tồn hệ thống khớp kiểm kê ở 54/60 mã; 6 mã còn lệch (MP012, TH011, TH012, TH023, VT007, VT019).

## 2. Tổng tiền vốn đề xuất so với ngân sách

| Chỉ tiêu | Số tiền (đ) |
|---|---|
| Ngân sách nhập tháng 2026-11 (tham số) | 30.000.000 |
| Cần nhập theo công thức, CHƯA xét ngân sách | 41.104.400 |
| **Tổng tiền vốn đề xuất** | **29.936.000** |
| Còn lại so với ngân sách | 64.000 |
| Phần bị cắt vì ngân sách | 11.168.400 |

(Phần cắt lớn hơn mức vượt ngân sách 64.000 đ vì số lượng phải làm tròn theo bội số quy cách.)

**Cách ưu tiên** (đây là lựa chọn của tôi, quy ước không quy định thứ tự này): xếp các mã cần nhập theo (1) HET_HANG, rồi SAP_HET, rồi các mã còn lại; (2) trong cùng nhóm, hạng ABC A trước B trước C; (3) cùng hạng thì mã có ít ngày tồn hơn đi trước. Cấp đủ số lượng theo thứ tự đó cho đến khi hết ngân sách; mã nào không đủ tiền cho cả lô thì giảm xuống bội số quy cách lớn nhất còn mua được. Số thứ tự nằm ở cột `uu_tien` của `de-xuat-nhap.csv`.

**Danh sách đề xuất nhập (đã xét ngân sách):**

| Ưu tiên | Mã | Tên hàng | Cảnh báo | ABC | Cần (chưa xét NS) | Đề xuất | Quy cách | Giá vốn | Thành tiền |
|---|---|---|---|---|---|---|---|---|---|
| 1 | MP015 | Serum vitamin C chai 30ml | SAP_HET | B | 12 | 12 | 6 | 185.000 | 2.220.000 |
| 2 | MP008 | Nước tẩy trang chai 300ml | SAP_HET | B | 12 | 12 | 12 | 82.000 | 984.000 |
| 3 | VT016 | Dây điện nối dài ổ cắm 5m | SAP_HET | C | 4 | 4 | 2 | 95.000 | 380.000 |
| 4 | VT018 | Keo dán đa năng tuýp | SAP_HET | C | 4 | 4 | 4 | 28.000 | 112.000 |
| 5 | MP003 | Dầu gội chai 650ml | OK | A | 36 | 36 | 12 | 88.000 | 3.168.000 |
| 6 | VT005 | Giấy vệ sinh lốc 10 cuộn | OK | A | 120 | 120 | 12 | 52.000 | 6.240.000 |
| 7 | MP005 | Sữa tắm chai 900ml | OK | A | 24 | 24 | 12 | 98.000 | 2.352.000 |
| 8 | MP001 | Kem chống nắng tuýp 50g | OK | A | 24 | 24 | 12 | 128.000 | 3.072.000 |
| 9 | TH001 | Gạo thơm túi 5kg | OK | A | 128 | 124 | 4 | 92.000 | 11.408.000 |
|  |  | **Tổng** |  |  |  |  |  |  | **29.936.000** |

**Phần bị cắt vì ngân sách** (mã cần nhập nhưng không được cấp đủ):

| Ưu tiên | Mã | Tên hàng | ABC | Cần | Đề xuất | Tiền bị cắt (đ) | Tồn hiện đủ bán |
|---|---|---|---|---|---|---|---|
| 9 | TH001 | Gạo thơm túi 5kg | A | 128 | 124 | 368.000 | 21,7 ngày |
| 10 | TH009 | Nước suối chai 500ml | A | 144 | 0 | 460.800 | 26,9 ngày |
| 11 | MP006 | Son dưỡng môi thỏi | A | 24 | 0 | 1.080.000 | 27,1 ngày |
| 12 | TH008 | Nước ngọt có ga lon 330ml | A | 360 | 0 | 2.700.000 | 28,0 ngày |
| 13 | VT007 | Nước rửa chén chai 750ml | B | 24 | 0 | 576.000 | 15,2 ngày |
| 14 | TH012 | Sữa đặc có đường lon 380g | B | 24 | 0 | 576.000 | 16,5 ngày |
| 15 | TH010 | Trà xanh đóng chai 455ml | B | 48 | 0 | 297.600 | 20,4 ngày |
| 16 | TH013 | Cà phê hòa tan hộp 20 gói | B | 12 | 0 | 456.000 | 31,5 ngày |
| 17 | VT001 | Bóng đèn LED 9W | B | 20 | 0 | 440.000 | 32,6 ngày |
| 18 | VT013 | Ô gấp | B | 10 | 0 | 850.000 | 33,8 ngày |
| 19 | TH006 | Mì gói thùng 30 gói | B | 6 | 0 | 588.000 | 45,0 ngày |
| 20 | TH020 | Bột ngọt gói 400g | C | 20 | 0 | 560.000 | 18,0 ngày |
| 21 | VT020 | Bút bi hộp 20 cây | C | 20 | 0 | 560.000 | 21,8 ngày |
| 22 | MP013 | Bàn chải đánh răng (cây) | C | 48 | 0 | 576.000 | 27,8 ngày |
| 23 | VT012 | Áo mưa bộ | C | 20 | 0 | 720.000 | 36,8 ngày |
| 24 | VT002 | Pin AA vỉ 4 viên | C | 20 | 0 | 360.000 | 37,3 ngày |

> Lưu ý: 10 mã bị cắt mà tồn chỉ đủ bán dưới 30 ngày (TH001, TH008, TH009, TH010, TH012, TH020, VT007, VT020, MP006, MP013); tổng tiền bị cắt của nhóm này 7.754.400 đ. Nếu chủ thấy nhóm này quan trọng hơn một số mã hạng A đã được cấp đủ thì có thể đổi thứ tự. Ngân sách chỉ là tham số, không phải số thật.

> Công thức trừ toàn bộ hàng đang về vào số cần nhập. **MP002**: hàng đang về dự kiến 2026-12-27, tức sau tháng 11, nhưng vẫn bị trừ nên đề xuất = 0 trong khi tồn = 0. Nếu hàng không về kịp tháng 11 thì cần đặt thêm 12 đơn vị (khoảng 744.000 đ, ngoài số đã đề xuất; ngân sách còn 64.000 đ). Chủ quyết.

## 3. Hàng đáng lo: hết hàng, sắp hết, tồn lâu, bán chậm

Tồn hiện tại lấy theo kiểm kê 2026-10-31. "Số ngày tồn" = tồn / (dự báo tháng / 30); để trống nếu dự báo bằng 0 (không còn nhu cầu).

| Mã | Tên hàng | Cảnh báo | Tồn KK | Điểm đặt lại | Dự báo/tháng | Số ngày tồn | Đang về | Ghi chú |
|---|---|---|---|---|---|---|---|---|
| MP002 | Sữa rửa mặt tuýp 100g | HET_HANG | 0 | 6 | 9,0 | 0,0 | 12 | đang về 12 (dự kiến 2026-12-27); về SAU tháng 11 |
| MP011 | Lăn khử mùi chai 50ml | HET_HANG | 0 | 9 | 10,7 | 0,0 | 24 | đang về 24 (dự kiến 2026-11-05) |
| MP008 | Nước tẩy trang chai 300ml | SAP_HET | 4 | 5 | 4,0 | 30,0 | 0 |  |
| MP010 | Toner pad hộp 60 miếng | SAP_HET | 9 | 12 | 13,5 | 20,0 | 24 | đang về 24 (dự kiến 2026-11-08); mã mới, dữ liệu ngắn |
| MP014 | Dầu dưỡng tóc chai 100ml | SAP_HET | 6 | 7 | 11,7 | 15,4 | 24 | đang về 24 (dự kiến 2026-11-08) |
| MP015 | Serum vitamin C chai 30ml | SAP_HET | 9 | 9 | 12,7 | 21,3 | 0 |  |
| TH014 | Trà túi lọc hộp 25 túi | SAP_HET | 7 | 7 | 9,3 | 22,5 | 24 | đang về 24 (dự kiến 2026-11-07) |
| VT004 | Túi rác cuộn trung | SAP_HET | 5 | 7 | 15,0 | 10,0 | 30 | đang về 30 (dự kiến 2026-11-04) |
| VT008 | Bột giặt túi 3kg | SAP_HET | 21 | 21 | 46,0 | 13,7 | 60 | đang về 60 (dự kiến 2026-11-06) |
| VT016 | Dây điện nối dài ổ cắm 5m | SAP_HET | 2 | 3 | 2,3 | 25,7 | 0 |  |
| VT018 | Keo dán đa năng tuýp | SAP_HET | 2 | 2 | 2,3 | 25,7 | 0 |  |
| MP016 | Gel rửa tay khô chai 500ml | TON_LAU | 27 | 1 | 0,0 |  | 0 | không bán trong 90 ngày cuối (lần bán cuối 2026-05-10) |
| TH016 | Mứt tết hộp 400g | TON_LAU | 9 | 2 | 0,7 | 405,0 | 0 | tồn > 120 ngày |
| TH019 | Hạt dưa gói 200g | TON_LAU | 11 | 2 | 0,3 | 990,0 | 0 | tồn > 120 ngày |
| TH021 | Nước tương chai 500ml (mã cũ) | TON_LAU | 61 | 1 | 0,0 |  | 0 | không bán trong 90 ngày cuối (lần bán cuối 2026-05-29); đã ngừng nhập |
| VT017 | Bóng đèn tròn sợi đốt 40W | TON_LAU | 46 | 1 | 0,0 |  | 0 | không bán trong 90 ngày cuối (lần bán cuối 2026-05-13); đã ngừng nhập |
| MP004 | Dầu xả chai 650ml | BAN_CHAM | 3 | 2 | 1,3 | 67,5 | 0 |  |

## 4. Kết quả giữ lại 2 tháng cuối (09 và 10 năm 2026)

Cách làm: mỗi tháng chỉ dùng dữ liệu TRƯỚC tháng đó để dự báo bằng công thức (trung bình 3 tháng hợp lệ gần nhất); thực tế là nhu cầu đã làm sạch. Chỉ đo các mã-tháng không bị cụt hàng và có ít nhất 3 tháng hợp lệ trước đó. Mốc 1 = doanh số thô của tháng liền trước (không làm sạch, đúng quy ước). Tôi thêm một cột phụ "mốc 1 sau làm sạch" để xem mốc 1 có được lợi vì lỗi dữ liệu hay không.

| Giai đoạn | n (mã-tháng) | MAE công thức | MAE mốc 1 (thô) | MAE mốc 1 (sạch) | WAPE công thức | WAPE mốc 1 (thô) | WAPE mốc 1 (sạch) | Lệch TB công thức (dự báo - thực) | Công thức thắng / thua / hòa mốc 1 thô |
|---|---|---|---|---|---|---|---|---|---|
| Tháng 09 | 54 | 19,6 | 18,0 | 17,4 | 33,3% | 30,7% | 29,7% | 13,3 | 27 / 21 / 6 |
| Tháng 10 | 55 | 21,0 | 11,9 | 11,8 | 38,5% | 21,8% | 21,6% | 12,4 | 22 / 27 / 6 |
| Gộp 2 tháng | 109 | 20,3 | 14,9 | 14,6 | 35,8% | 26,4% | 25,8% | 12,9 | 49 / 48 / 12 |

**Kết luận thẳng:** trên dữ liệu này công thức thua mốc "bằng tháng trước" (WAPE 35,8% so với 26,4%; MAE 20,3 so với 14,9 đơn vị). Số mã thắng và thua gần ngang nhau (49 thắng, 48 thua, 12 hòa); sai số tổng lớn hơn vì một vài mã bán chạy và có mùa vụ: TH008, TH009, TH001, TH018, VT005 chiếm 76,6% tổng sai số tuyệt đối của công thức. Công thức dự báo CAO hơn thực tế trung bình 12,9 đơn vị/mã-tháng: nhiều mã (nước ngọt, nước suối...) lên đỉnh giữa năm rồi giảm, mà trung bình 3 tháng phản ứng chậm. Mốc 1 sau làm sạch (WAPE 25,8%) gần bằng mốc 1 thô, nên khoảng cách này không đến từ lỗi dữ liệu trong mốc 1.

**Điều cần nhớ khi đọc con số này:**
- n nhỏ: chỉ 109 mã-tháng từ 2 tháng; mỗi mã xuất hiện tối đa 2 lần và cả hai tháng cùng nằm trong giai đoạn nhu cầu giảm sau mùa hè, nên các điểm không độc lập. Không có kiểm định thống kê. Chưa đủ để kết luận công thức "kém" nói chung, chỉ cho biết nó kém trong 2 tháng này.
- Bỏ ra ngoài 11 mã-tháng (không tính được): 7 vì cụt hàng, 4 vì chưa đủ lịch sử (mới bán hoặc dưới 3 tháng hợp lệ).
- **Mốc 2 "cùng kỳ năm trước" không làm được cho 2026-09 và 2026-10** (chỉ có 12 tháng dữ liệu, không có 2025-09, 2025-10). Mốc này chỉ làm được cho tháng 2026-11 (lấy 2025-11, cột `cung_ky_nam_truoc_2025_11` của `phan-loai-tinh-toan.csv`) nhưng chưa có thực tế 2026-11 nên không đo được.
- Chưa đo được: dự báo 2026-11 đúng bao nhiêu; tồn an toàn 95% có đạt tỷ lệ không hết hàng thật hay không; hiệu ứng mùa vụ (cần ít nhất 2 năm); độ lệch thời gian giao; hàng mới (MP010, MP014, MP015) vì chưa đủ lịch sử.
- Vì công thức hay dự báo cao khi nhu cầu đang giảm, hãy dè dặt với dự báo của các mã bán chạy dưới đây: TH008 (dự báo 1154 so với tháng 10 thực tế 905), TH009 (dự báo 368 so với tháng 10 thực tế 281), TH017 (dự báo 55 so với tháng 10 thực tế 30), TH018 (dự báo 60 so với tháng 10 thực tế 45), MP012 (dự báo 69 so với tháng 10 thực tế 57).

## 5. Lỗi dữ liệu và cách xử lý

Nhật ký có 11128 dòng. `loi-du-lieu.csv` ghi 133 dòng. Ngày viết lẫn lộn và mã hàng sai dạng được chuẩn hóa hàng loạt nên ghi thành 2 dòng tổng hợp.

| Loại lỗi | Số dòng | Xử lý | Cách làm |
|---|---|---|---|
| trung_dong | 11 | BO | Trùng mã phiếu (cùng nội dung, chỉ khác cách viết ngày/tên) → BỎ dòng sau |
| so_am_khong_ghi_chu | 6 | CAN_NGUOI_QUYET | XUẤT số âm nhưng không ghi "khách trả" → tạm tính là bán |số|, chủ quyết |
| so_luong_bat_thuong | 6 | CAN_NGUOI_QUYET | Số lượng gấp bất thường trong 1 phiếu (nghi gõ thừa số 0) → tạm chia 10, chủ quyết |
| thieu_so_luong | 3 | CAN_NGUOI_QUYET | Ô số lượng để trống → không điền, tạm tính 0, chủ quyết |
| don_si_mot_lan | 5 | GIU | Phiếu NHẬP riêng cho đơn sỉ → GIỮ (vẫn cộng vào tồn) |
| don_si_mot_lan | 5 | CAN_NGUOI_QUYET | Phiếu XUẤT đơn sỉ một lần → vẫn trừ tồn, KHÔNG tính vào nhu cầu thường ngày, chủ quyết |
| ngay_o_tuong_lai | 2 | CAN_NGUOI_QUYET | Ngày sau 2026-10-31 → tạm đặt ngày theo số phiếu, chủ quyết |
| khong_phai_ban_hang | 89 | GIU | Hủy hết hạn, xuất dùng nội bộ, điều chỉnh kiểm kê → GIỮ (trừ tồn, không tính nhu cầu) |
| khac | 6 | SUA | Thiếu mã hàng (dò theo tên) và chuẩn hóa định dạng ngày/mã → SỬA |

**Đối chiếu tồn hệ thống chạy với kiểm kê (kiểm kê − hệ thống):** nếu chỉ bỏ dòng trùng và chuẩn hóa mã/ngày, giữ nguyên số đã ghi, thì lệch 15 mã; sau khi xử lý các ca ở trên còn lệch 6 mã. Nghĩa là các ca nghi ngờ (gõ thừa số 0, số âm gõ nhầm, phiếu nhập ghi sai tháng) được kiểm kê ủng hộ, nhưng vẫn cần chủ xác nhận.

| Mã | Tên hàng | Tồn hệ thống | Kiểm kê | Chênh | Giải thích |
|---|---|---|---|---|---|
| MP012 | Kem đánh răng tuýp 180g | 86 | 83 | -3 | Chưa giải thích được bằng lỗi nhật ký; có thể hao hụt hoặc đếm sai. Chờ chủ kiểm lại. |
| TH011 | Sữa tươi hộp 1L | 24 | 20 | -4 | Chưa giải thích được bằng lỗi nhật ký; có thể hao hụt hoặc đếm sai. Chờ chủ kiểm lại. |
| TH012 | Sữa đặc có đường lon 380g | 22 | 18 | -4 | Chưa giải thích được bằng lỗi nhật ký; có thể hao hụt hoặc đếm sai. Chờ chủ kiểm lại. |
| TH023 | Trứng gà vỉ 10 quả | 25 | 13 | -12 | Có 2 phiếu thiếu số lượng (PX02391, PX09402); phần lệch có thể là số bán bị thiếu đó. KHÔNG tự điền, chờ chủ. |
| VT007 | Nước rửa chén chai 750ml | 18 | 15 | -3 | Có 1 phiếu thiếu số lượng (PX01404); phần lệch có thể là số bán bị thiếu đó. KHÔNG tự điền, chờ chủ. |
| VT019 | Tập học sinh 96 trang | 103 | 100 | -3 | Chưa giải thích được bằng lỗi nhật ký; có thể hao hụt hoặc đếm sai. Chờ chủ kiểm lại. |

(Số âm = kiểm kê ít hơn hệ thống. Tồn dùng để tính đề xuất là số KIỂM KÊ, không phải tồn hệ thống.)

Mã thiếu dữ liệu: dưới 3 tháng hợp lệ = MP010 (2 tháng); chưa đủ lịch sử để đo giữ lại: MP010, MP015. Số mã có ít nhất 1 tháng cụt hàng: 22/60 (cột `thang_cut_hang`).

## 6. Giả định đã dùng

- Công thức, ngưỡng, ngân sách lấy đúng từ `quy-uoc.md` và `tham-so.json`, không đổi (Z = 1,645; ngân sách 30.000.000 đ; cụt hàng = từ 7 ngày hết hàng).
- Ngày viết lẫn lộn đọc theo kiểu Việt Nam (ngày trước tháng). Đã kiểm: số phiếu tăng dần thì ngày không giảm, nên không có dòng nào đảo ngày/tháng.
- Mã hàng viết thường/có gạch/thừa khoảng trắng thì chuẩn hóa; dòng thiếu mã dò theo tên không dấu (4 dòng, khớp duy nhất).
- "Tháng hợp lệ" = tháng từ lúc mặt hàng bắt đầu bán (hàng thường: từ 2025-11; hàng mới: theo ghi chú trong danh mục) và không cụt hàng. Tháng bán 0 mà không cụt vẫn tính là hợp lệ (bán 0, không phải thiếu số liệu).
- Ngày hết hàng = tồn cuối ngày ≤ 0 theo tồn hệ thống chạy đã làm sạch. Trước ngày mở bán của hàng mới không tính là cụt.
- Số âm CÓ ghi "khách trả" = trả hàng (cộng lại tồn, trừ nhu cầu). Điều chỉnh kiểm kê (DIEU_CHINH) là số thay đổi tồn (âm = giảm), không tính nhu cầu.
- Đơn sỉ một lần và số lượng bất thường: hàng vẫn rời kho thật nên vẫn trừ tồn (kiểm kê khớp), nhưng đơn sỉ không tính vào nhu cầu thường ngày; số bất thường tạm chia 10. Đây là mặc định TẠM, xem mục 7.
- Số âm không ghi chú tạm coi là bán (gõ nhầm dấu), vì kiểm kê khớp hơn cách coi là trả hàng; thiếu số lượng tạm tính 0.
- Phiếu nhập ghi tháng 12/2026 tạm đặt theo ngày của phiếu đứng liền trước trong dãy số phiếu (2026-09-25); kiểm kê cho thấy hàng đã về.
- Dự báo F = trung bình 3 tháng hợp lệ gần nhất; σ = độ lệch chuẩn mẫu (n−1) của tối đa 6 tháng hợp lệ; dưới 3 tháng thì σ = 0,5 × F và gắn cờ DU_LIEU_NGAN (chỉ MP010). Thời gian giao cố định, nhu cầu các tháng độc lập.
- Số cần nhập = max(0, F + SS − tồn kiểm kê − hàng đang về), làm tròn LÊN theo bội số quy cách. Hàng đang về được trừ toàn bộ, kể cả hàng dự kiến về sau tháng 11.
- Mặt hàng ngừng nhập (TH021, VT017) không đề xuất nhập (số lượng 0); vẫn tính ABC và cảnh báo.
- "Không bán ngày nào trong 90 ngày cuối" = không có phiếu bán hàng nào từ 2026-08-03 đến 2026-10-31 (tính cả đơn sỉ).
- Mốc 1 thô = tổng số lượng XUẤT của tháng trước, chỉ chuẩn hóa ngày và mã, không bỏ trùng, không bỏ hủy/nội bộ/đơn sỉ/số bất thường. Thực tế để so sánh là nhu cầu đã làm sạch.
- Thứ tự ưu tiên khi cắt ngân sách (mục 2) là lựa chọn của tôi, không phải của quy ước.
- Chỉ có giá vốn hiện tại, dùng cho cả ABC 12 tháng và thành tiền.
- Cờ "cụt hàng" tính từ tồn hệ thống chạy; vì có vài mã lệch kiểm kê nên số ngày hết hàng của các mã đó có thể sai lệch nhẹ.

## 7. Danh sách CẦN NGƯỜI QUYẾT

**A. Ngân sách và thứ tự ưu tiên**

1. Chấp nhận cắt 11.168.400 đ ở 16 mã (bảng mục 2), hay tăng ngân sách, hay đổi thứ tự? Các mã bị cắt mà tồn dưới 30 ngày: TH001, TH008, TH009, TH010, TH012, TH020, VT007, VT020, MP006, MP013.

**B. Mặt hàng**

2. **MP002** (tồn 0, hàng về dự kiến 2026-12-27): có đặt thêm cho tháng 11 không, hay xác nhận lại ngày về? Hiện đề xuất = 0.
3. **TH021, VT017** đang ngừng nhập nhưng còn tồn (TH021: 61, VT017: 46), lần bán cuối TH021: 2026-05-29, VT017: 2026-05-13: giữ không nhập, xả hàng tồn, hay đổi trạng thái?
4. **MP016** chưa ghi ngừng nhập nhưng không bán trong 90 ngày cuối (tồn MP016: 27): có coi là hàng chết không?
5. **MP010** (hàng mới, chỉ 2 tháng bán): dự báo và tồn an toàn dựa trên giả định σ = 0,5 × F, chưa đáng tin; chủ nên tự xét. MP014 và MP015 cũng còn ít lịch sử.
6. Các mã bán chạy có dấu hiệu giảm sau mùa hè (TH008, TH009, TH017, TH018, MP012): có muốn nhập ít hơn số công thức cho không?

**C. Phiếu nhật ký cần chủ xác nhận** (mặc định TẠM đã dùng để tính; lý do và gợi ý từ kiểm kê nằm trong `loi-du-lieu.csv`)

| Mã phiếu | Mã hàng | Loại | Ngày ghi | Số ghi | Mặc định tạm dùng |
|---|---|---|---|---|---|
| PX00679 | MP003 | so_am_khong_ghi_chu | 2025-11-23 | -4 | tính là bán 4 |
| PX01374 | VT007 | so_am_khong_ghi_chu | 2025-12-14 | -3 | tính là bán 3 |
| PX03573 | TH023 | so_am_khong_ghi_chu | 2026-02-22 | -3 | tính là bán 3 |
| PX04140 | MP012 | so_am_khong_ghi_chu | 2026-03-13 | -3 | tính là bán 3 |
| PX05950 | TH018 | so_am_khong_ghi_chu | 2026-05-17 | -3 | tính là bán 3 |
| PX10062 | TH003 | so_am_khong_ghi_chu | 2026-10-11 | -3 | tính là bán 3 |
| PX04209 | MP013 | so_luong_bat_thuong | 2026-03-15 | 30 | tính 3 (chia 10) |
| PX05025 | TH023 | so_luong_bat_thuong | 2026-04-12 | 40 | tính 4 (chia 10) |
| PX05126 | MP001 | so_luong_bat_thuong | 2026-04-17 | 30 | tính 3 (chia 10) |
| PX07009 | TH011 | so_luong_bat_thuong | 2026-06-24 | 30 | tính 3 (chia 10) |
| PX08283 | MP006 | so_luong_bat_thuong | 2026-08-10 | 30 | tính 3 (chia 10) |
| PX10382 | TH002 | so_luong_bat_thuong | 2026-10-22 | 50 | tính 5 (chia 10) |
| PX01404 | VT007 | thieu_so_luong | 2025-12-15 | (trống) | tính 0 |
| PX02391 | TH023 | thieu_so_luong | 2026-01-17 | (trống) | tính 0 |
| PX09402 | TH023 | thieu_so_luong | 2026-09-18 | (trống) | tính 0 |
| PX02983 | VT008 | don_si_mot_lan | 2026-02-04 | 90 | trừ tồn, không tính nhu cầu |
| PX04450 | TH007 | don_si_mot_lan | 2026-03-23 | 2500 | trừ tồn, không tính nhu cầu |
| PX05227 | MP012 | don_si_mot_lan | 2026-04-20 | 420 | trừ tồn, không tính nhu cầu |
| PX06046 | VT007 | don_si_mot_lan | 2026-05-21 | 140 | trừ tồn, không tính nhu cầu |
| PX07668 | VT015 | don_si_mot_lan | 2026-07-17 | 260 | trừ tồn, không tính nhu cầu |
| PN0349 | VT001 | ngay_o_tuong_lai | 2026-12-11 | 20 | đặt ngày 2026-09-25 |
| PN0350 | MP015 | ngay_o_tuong_lai | 2026-12-13 | 18 | đặt ngày 2026-09-25 |

7. Với mỗi phiếu ở bảng trên: xác nhận số đúng / ngày đúng. Hai phiếu nhập ghi tháng 12 cần ngày thật.
8. 6 mã còn lệch kiểm kê (bảng mục 5): kiểm lại thực tế hoặc tìm phiếu còn thiếu.

**D. Nếu chủ quyết khác mặc định, số cần nhập đổi thế nào** (tính lại dự báo, tồn an toàn, số cần nhập chưa xét ngân sách; không đổi cờ cụt hàng):

| Mã | Tên hàng | Dự báo (mặc định) | Dự báo (giữ nguyên số ghi, đơn sỉ tính vào, số âm là trả hàng) | Cần nhập mặc định | Cần nhập nếu quyết khác | Chênh tiền (đ) |
|---|---|---|---|---|---|---|
| TH002 | Dầu ăn đậu nành chai 1L | 39,0 | 54,0 | 0 | 24 | 1.104.000 |
| TH003 | Nước mắm chai 500ml | 12,3 | 10,3 | 0 | 0 | 0 |
| VT007 | Nước rửa chén chai 750ml | 29,7 | 29,7 | 24 | 60 | 864.000 |
| VT015 | Khẩu trang y tế hộp 50 cái | 4,7 | 4,7 | 0 | 80 | 1.920.000 |
| MP001 | Kem chống nắng tuýp 50g | 37,7 | 37,7 | 24 | 36 | 1.536.000 |
| MP006 | Son dưỡng môi thỏi | 21,0 | 30,0 | 24 | 24 | 0 |
| MP012 | Kem đánh răng tuýp 180g | 69,3 | 69,3 | 0 | 120 | 3.720.000 |

---
_Báo cáo do `tinh_ton_kho.py` sinh ra từ dữ liệu; chạy lại script sẽ tạo lại toàn bộ file kết quả._
