# Báo cáo kho – đề xuất nhập hàng tháng 2026-11

*Dữ liệu GIẢ để học (60 mã, 2025-11 → 2026-10). Mọi số dưới đây là **đề xuất**; chủ cửa hàng quyết định số cuối cùng.*

## 1. Tóm tắt

1. Đề xuất nhập **10 mã, tổng tiền vốn 29.956.800 đ**, trong ngân sách 30.000.000 đ (còn dư 43.200 đ).
2. Nếu không có ngân sách, công thức cần **40.216.400 đ**. Vì vậy **15 mã bị cắt hoàn toàn hoặc một phần, tổng 10.259.600 đ** (xem mục 2).
3. Đáng lo nhất: **2 mã hết hàng** (MP002, MP011), **11 mã sắp hết**, trong đó MP002 có hàng về ngày 27/12 – gần như chắc chắn hết cả tháng 11 nếu ngày đó đúng.
4. Công thức dự báo của chủ **thua** cách đoán đơn giản "bằng tháng trước" trên 2 tháng giữ lại (sai số WAPE 37,8% so với 26,6%). Chỉ có 2 tháng, nên chưa kết luận chắc, nhưng không nên tin dự báo của những mặt hàng có mùa vụ (xem mục 4).
5. Có **28 mã cần chủ xem lại** vì dữ liệu chưa chắc hoặc bị cắt ngân sách (mục 7); 15 mã có tồn hệ thống lệch kiểm kê, phần lớn giải thích được bằng lỗi nhập liệu (mục 5).

## 2. Tiền vốn so với ngân sách

| | Số tiền (đ) |
|---|---|
| Cần nhập theo công thức (chưa xét ngân sách) | 40.216.400 |
| **Đề xuất nhập (đã xét ngân sách)** | **29.956.800** |
| Ngân sách tháng 2026-11 | 30.000.000 |
| Bị cắt vì ngân sách | 10.259.600 |

**Cách ưu tiên** (do tôi chọn, chủ có thể đổi): (1) mã hết hàng / sắp hết trước; (2) rồi theo lớp ABC (A trước, vì A là mặt hàng đem lại nhiều giá trị nhất); (3) trong cùng lớp, mã còn ít ngày hàng hơn đi trước. Đi lần lượt từ trên xuống, mã nào hết ngân sách giữa chừng thì nhập một phần (đúng bội số quy cách), phần còn lại cắt.

**Được nhập (theo thứ tự ưu tiên):**

| # | Mã | Tên | Số lượng | Tiền (đ) |
|---|---|---|---|---|
| 1 | MP015 | Serum vitamin C chai 30ml | 18 | 3.330.000 |
| 2 | MP008 | Nước tẩy trang chai 300ml | 12 | 984.000 |
| 3 | VT016 | Dây điện nối dài ổ cắm 5m | 2 | 190.000 |
| 4 | VT018 | Keo dán đa năng tuýp | 4 | 112.000 |
| 5 | VT005 | Giấy vệ sinh lốc 10 cuộn | 120 | 6.240.000 |
| 6 | MP005 | Sữa tắm chai 900ml | 24 | 2.352.000 |
| 7 | MP001 | Kem chống nắng tuýp 50g | 24 | 3.072.000 |
| 8 | TH001 | Gạo thơm túi 5kg | 128 | 11.776.000 |
| 9 | TH009 | Nước suối chai 500ml | 144 | 460.800 |
| 10 | TH008 | Nước ngọt có ga lon 330ml | 192 (cần 360, nhập 53%) | 1.440.000 |
| | | **Tổng** | | **29.956.800** |

**Bị cắt (15 mã, 10.259.600 đ):** TH008 (cắt 168 lon, 1.260.000 đ) và hoàn toàn: MP006 (1.080.000), MP003 (1.056.000), VT013 (850.000), MP012 (744.000), VT012 (720.000), TH006 (588.000), TH012 (576.000), VT007 (576.000), MP013 (576.000), TH020 (560.000), VT020 (560.000), TH013 (456.000), VT002 (360.000), TH010 (297.600).

Rủi ro khi cắt: TH012 (còn ~16 ngày hàng), VT007 (~15 ngày), TH010 (~20 ngày), MP006/MP003 (~28–30 ngày) sẽ tới điểm đặt lại sớm trong tháng. Nếu chủ nâng ngân sách, nên bổ sung các mã này trước. TH008 đang cần 360 theo công thức nhưng xem lưu ý mùa vụ ở mục 4 – có thể dự báo đang quá cao.

## 3. Hàng đáng lo (tồn kiểm kê 2026-10-31)

**HẾT_HÀNG (2 mã)**

| Mã | Tên | Tồn | Hàng đang về | Ghi chú |
|---|---|---|---|---|
| MP002 | Sữa rửa mặt tuýp 100g | 0 | 12 (dự kiến **27/12/2026**) | Công thức cho ra 0 vì đã trừ 12 cái đang về. Nếu ngày 27/12 đúng, hết hàng suốt tháng 11 (giao hàng mất 10 ngày). **Cần chủ quyết.** |
| MP011 | Lăn khử mùi chai 50ml | 0 | 24 (05/11) | Sắp có hàng, không cần nhập thêm |

**SẮP_HẾT (11 mã; tồn ≤ điểm đặt lại)**

| Mã | Tên | Tồn / Điểm đặt lại | Đang về |
|---|---|---|---|
| MP008 | Nước tẩy trang chai 300ml | 4 / 5 | – |
| MP010 | Toner pad hộp 60 miếng | 9 / 12 | 24 (08/11) |
| MP014 | Dầu dưỡng tóc chai 100ml | 6 / 7 | 24 (08/11) |
| MP015 | Serum vitamin C chai 30ml | 9 / 13 | – |
| TH014 | Trà túi lọc hộp 25 túi | 7 / 7 | 24 (07/11) |
| TH016 | Mứt tết hộp 400g | 9 / 9 | – |
| TH019 | Hạt dưa gói 200g | 11 / 11 | – |
| VT004 | Túi rác cuộn trung | 5 / 7 | 30 (04/11) |
| VT008 | Bột giặt túi 3kg | 21 / 21 | 60 (06/11) |
| VT016 | Dây điện nối dài ổ cắm 5m | 2 / 2 | – |
| VT018 | Keo dán đa năng tuýp | 2 / 2 | – |

Lưu ý TH016 và TH019 (hàng Tết): nhãn SẮP_HẾT là do công thức (độ lệch chuẩn bị đẩy lên bởi mùa Tết), nhưng thực tế bán ~1 đơn vị/tháng và còn đủ hàng 270–330 ngày. **Không cần nhập**. Ngược lại, 2 mã này bán mạnh vào dịp Tết (tháng 1–2 vừa rồi: 19–20 đơn vị/tháng với TH016, 30–31 với TH019; tháng 12: 6 và 12); công thức không thấy mùa vụ, chủ nên tự xem lại đầu tháng 12.

**TỒN_LÂU (3 mã)** – đều không bán ngày nào trong 90 ngày cuối: MP016 Gel rửa tay khô (tồn 27, ~116 ngày hàng; công thức vẫn dùng nhu cầu cũ 7/tháng nên thực tế còn tồn lâu hơn), TH021 Nước tương mã cũ (tồn 61, **ngừng nhập**), VT017 Bóng đèn sợi đốt 40W (tồn 46, ~166 ngày, **ngừng nhập**). Chủ nên cân nhắc xả hàng.

**BÁN_CHẬM (1 mã):** MP004 Dầu xả chai 650ml (dự báo 1,3 đơn vị/tháng, tồn 3).

Còn lại 43 mã nhãn OK.

**Hàng từng bị cụt:** 20 mã có ít nhất một tháng hết hàng từ 7 ngày trở lên (tổng 29 mã-tháng), ví dụ MP002 (3 tháng), MP004 (3 tháng), TH002/TH008/TH013/VT002/VT005 (2 tháng). Các tháng đó đã bị loại khỏi trung bình theo quy ước (coi là thiếu số liệu, không phải 0). Chi tiết ở `phan-loai-tinh-toan.csv`.

## 4. Kết quả "giữ lại 2 tháng cuối" (2026-09, 2026-10)

Cách làm: dự báo mỗi tháng chỉ dùng dữ liệu **trước** tháng đó; chỉ đo mã-tháng không cụt hàng và có ≥ 3 tháng hợp lệ trước. Có **110 mã-tháng** (57 mã; 55 ở mỗi tháng), 10 mã-tháng không đo được (`tinh_duoc = KHONG`). So với mốc 1 "bằng tháng liền trước" (doanh số thô).

| | MAE công thức | MAE mốc 1 | WAPE công thức | WAPE mốc 1 |
|---|---|---|---|---|
| 2026-09 (n=55) | 20,96 | 18,20 | 36,2% | 31,4% |
| 2026-10 (n=55) | 21,35 | 11,66 | 39,4% | 21,5% |
| **Cả hai tháng (n=110)** | **21,16** | **14,93** | **37,8%** | **26,6%** |

**Công thức thua mốc ngây thơ.** Công thức tốt hơn ở 48 mã-tháng, kém hơn ở 57 (5 mã-tháng hòa). Công thức dự báo **cao hơn thực tế** tổng cộng 1.517 đơn vị trên 6.163 thực bán (+25%). Nguyên nhân chính là trung bình 3 tháng "đuổi theo sau" khi bán đang giảm theo mùa: nhiều nhất ở TH008 (nước ngọt, đỉnh tháng 6–8 rồi giảm: dự báo 1.633 / 1.455, thực tế 1.039 / 905) và TH009 (nước suối). 5 mã-tháng lớn nhất chiếm 67% tổng sai số. Nếu bỏ 4 mã lớn nhất (TH008, TH009, TH001, VT005) thì công thức vẫn kém nhẹ (WAPE 28,1% so với 26,2%; MAE 6,64 so với 6,17).

Cần nói rõ giới hạn:
- **n nhỏ**: chỉ 2 tháng, cùng một chiều (cuối mùa nóng). Không thể kết luận công thức "luôn thua"; chỉ có thể nói trong 2 tháng này nó thua. Tôi không chạy kiểm định thống kê vì sai số dồn vào vài mã lớn.
- **Mốc 2 "cùng kỳ năm trước" không đo được** cho 2026-09 và 2026-10 vì chỉ có 12 tháng dữ liệu. Với tháng đề xuất 2026-11 mốc này có (cột `cung_ky_nam_truoc_2025_11`) nhưng chưa có thực tế tháng 11 để chấm.
- **Chưa đo được** mức phục vụ 95% có thật sự đạt hay không (không có dữ liệu thiếu hàng đủ dài), và tồn an toàn có hợp lý không.
- Mốc 1 ở bảng là doanh số thô (chưa làm sạch) đúng như quy ước. Tôi cũng tính mốc 1 trên số đã làm sạch để công bằng: kết quả gần như không đổi (WAPE 26,1%).
- So sánh dự báo tháng 11 với cùng kỳ năm trước, vài mã lệch lớn đáng xem: TH008 (dự báo 1.154, năm ngoái 738), TH017 (55 so 20), VT019 (62 so 34), TH013 (6,7 so 17), TH003 (11 so 6).

Chi tiết từng mã-tháng: `giu-lai-do-loi.csv`.

## 5. Lỗi dữ liệu và cách xử lý

Chi tiết từng dòng ở `loi-du-lieu.csv` (71 dòng); chênh lệch tồn ở `kiem-tra-doi-chieu.csv`.

| Loại lỗi | Số dòng | Xử lý | Ghi chú |
|---|---|---|---|
| Trùng dòng (cùng mã phiếu, cùng nội dung) | 11 | **BỎ** dòng thứ hai | Ví dụ PN0018, PX00814 |
| Thiếu mã hàng | 4 | **SỬA** (dò theo tên, ra đúng 1 mã) | PX00136→TH003, PX00267→TH009, PX00775→MP006, PX01980→VT006 |
| Hủy hết hạn / xuất dùng tại quán | 34 | **GIỮ**: không tính vào nhu cầu, vẫn trừ tồn | |
| Xuất số âm không ghi chú | 6 | **CẦN NGƯỜI QUYẾT**. Tạm: không tính vào tồn lẫn nhu cầu | Đối chiếu kiểm kê cho thấy nhiều khả năng là bán thật, gõ nhầm dấu trừ |
| Số lượng bất thường (gấp ≥10 lần bình thường) | 6 | **CẦN NGƯỜI QUYẾT**. Tạm: không tính nhu cầu, không trừ tồn | TH002 (50), TH023 (40), MP001/MP006/MP013/TH011 (30). Kiểm kê khớp với việc số thật chỉ khoảng 1/10 (gõ thừa số 0) |
| Đơn sỉ một lần | 5 | **CẦN NGƯỜI QUYẾT**. Tạm: loại khỏi nhu cầu, vẫn trừ tồn | TH007 (2.500), MP012 (420), VT008 (90), VT015 (260), VT007 (140); hai mã sau không ghi chú nhưng cùng ngày có phiếu "nhập cho đơn sỉ" |
| Thiếu số lượng | 3 | **CẦN NGƯỜI QUYẾT**. Không tự điền số | TH023 (2 phiếu), VT007 (1 phiếu) |
| Ngày ở tương lai | 2 | **CẦN NGƯỜI QUYẾT**. Tạm: không tính vào tồn | PN0349 VT001 (+20, 11/12/2026), PN0350 MP015 (+18, 13/12/2026). Kiểm kê chênh đúng +20 và +18 nên hàng gần như chắc chắn đã về trước 31/10 và ngày bị gõ sai |

Chuẩn hóa không ghi từng dòng (là lỗi định dạng, không phải lỗi số liệu): 809 dòng mã hàng viết thường / có gạch / có khoảng trắng; 3.341 dòng ngày không theo kiểu yyyy-mm-dd (đọc theo kiểu Việt Nam, ngày trước tháng). Trả hàng (30 dòng, số âm có ghi chú "khách trả") được giữ và trừ khỏi nhu cầu.

**Đối chiếu tồn hệ thống với kiểm kê 2026-10-31:** 45 mã khớp hoàn toàn, **15 mã lệch**:
- Giải thích được bằng lỗi nhập liệu (nếu các giả thuyết ở mục trên đúng): TH002 (−5), TH003 (−3), TH018 (−3), MP001 (−3), MP003 (−4), MP006 (−3), MP013 (−3), VT001 (+20), MP015 (+18).
- Giải thích một phần: TH011 (−7, còn −4), TH023 (−19, còn −12 do 2 phiếu thiếu số lượng), VT007 (−6, còn −3), MP012 (−6, còn −3).
- **Không có dòng lỗi nào liên quan**: TH012 (−4), VT019 (−3), có thể là hao hụt chưa ghi.

Quan trọng: nếu trừ nguyên các số bất thường (ví dụ xuất 30 thay vì 3) vào tồn chạy, tồn hệ thống sẽ âm giả trong nhiều tháng và biến 5 mã thành "cụt hàng" sai (MP013 tới 8 tháng, TH023 6 tháng), làm dự báo lệch mạnh. Vì vậy tôi chọn không trừ chúng; chủ xác nhận số thật thì kết quả có thể thay đổi.

## 6. Giả định đã dùng

1. Công thức, ngưỡng, ngân sách lấy đúng `quy-uoc.md` và `tham-so.json` (Z = 1,645; giao hàng cố định; nhu cầu các tháng độc lập).
2. Tháng "hợp lệ" = đã bán (> 0) và không cụt hàng. Một tháng của mặt hàng cũ mà không bán được gì bị coi là thiếu số liệu chứ không phải 0, nên với mã bán rất chậm dự báo có thể bị cao.
3. Mặt hàng mới (tồn đầu 0: MP010, MP014, MP015): các ngày **trước lần nhập đầu tiên** không bị coi là hết hàng.
4. Số bất thường, đơn sỉ, số âm không ghi chú, thiếu số lượng, ngày tương lai: cách xử lý tạm thời như mục 5 (đều chờ chủ quyết).
5. Hàng đang về luôn được trừ khỏi số cần nhập, kể cả MP002 về ngày 27/12 (sau tháng đề xuất), vì công thức quy định vậy.
6. ABC tính cho cả mặt hàng ngừng nhập (TH021, VT017); hai mã này không được đề xuất nhập.
7. "Không bán ngày nào trong 90 ngày cuối" = 03/08 → 31/10, tính trên các lần bán đã làm sạch.
8. Thứ tự ưu tiên khi cắt ngân sách là đề xuất của tôi (mục 2); công thức không quy định.
9. Dữ liệu là GIẢ; ngân sách 30 triệu chỉ là tham số học tập.

## 7. Danh sách CẦN NGƯỜI QUYẾT

**A. Quyết định kinh doanh**
1. **MP002 (HẾT_HÀNG):** 12 cái về 27/12 – ngày đó đúng không? Nếu đúng, muốn nhập thêm 12 (744.000 đ) cho tháng 11 thì phải rút từ mã khác hoặc tăng ngân sách (còn dư 43.200 đ).
2. **Ngân sách:** bị cắt 10.259.600 đ (15 mã). Giữ nguyên, tăng ngân sách, hay đổi thứ tự ưu tiên? Đặc biệt cân nhắc TH012, VT007, TH010 (ít ngày hàng nhất trong số bị cắt).
3. **TH008 (nước ngọt):** công thức cần 360 nhưng bán đang giảm theo mùa (cùng kỳ năm ngoái 738, dự báo 1.154). Có muốn nhập đủ, hay ít hơn 192?
4. **Hàng Tết (TH016 mứt, TH019 hạt dưa):** không nhập tháng 11, nhưng có kế hoạch cho tháng 12–2 không (công thức không thấy mùa vụ)?
5. **Hàng ngừng nhập / tồn lâu:** TH021, VT017, MP016 – xả hàng hay giữ?

**B. Xác nhận dữ liệu** (chi tiết `loi-du-lieu.csv`)
6. 6 dòng số lượng bất thường: số thật là bao nhiêu (TH002 PX10382, TH023 PX05025, MP001 PX05126, MP006 PX08283, MP013 PX04209, TH011 PX07009)?
7. 6 dòng xuất số âm không ghi chú (PX00679 MP003, PX01374 VT007, PX03573 TH023, PX04140 MP012, PX05950 TH018, PX10062 TH003): là trả hàng, hay bán gõ nhầm dấu?
8. 3 phiếu thiếu số lượng (PX01404 VT007, PX02391 TH023, PX09402 TH023): số bán là bao nhiêu?
9. 5 đơn sỉ (PX04450 TH007, PX05227 MP012, PX02983 VT008, PX07668 VT015, PX06046 VT007): có lặp lại không? Nếu có, cần tính vào nhu cầu.
10. 2 phiếu nhập ngày tương lai (PN0349 VT001, PN0350 MP015): ngày về thật là ngày nào? (Ảnh hưởng tồn hệ thống và việc VT001, MP015 có bị tính "cụt hàng" tháng 10 hay không.)
11. Lệch kiểm kê chưa giải thích: TH012 (−4), VT019 (−3), phần còn lại của TH023 (−12), TH011 (−4), VT007 (−3), MP012 (−3): hao hụt thật hay thiếu phiếu?
12. Mặt hàng mới **MP010, MP015** chỉ có 2 tháng dữ liệu (độ lệch chuẩn là giả định 0,5×dự báo): kết quả của hai mã này kém chắc chắn; MP014 có 5 tháng nhưng mới bán từ 2026-06.

## File kết quả (cùng thư mục)

`loi-du-lieu.csv`, `phan-loai-tinh-toan.csv`, `de-xuat-nhap.csv`, `giu-lai-do-loi.csv`, `tinh_ton_kho.py` (chạy lại: `python tinh_ton_kho.py`). File phụ: `kiem-tra-doi-chieu.csv` (lệch kiểm kê từng mã), `tom-tat-ket-qua.json` (số liệu tổng hợp). File dữ liệu gốc không bị sửa.
