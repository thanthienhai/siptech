# Báo cáo tuần

**Kết luận:** Tuần này lo an toàn đồ ăn trước, rồi tới tính tiền; khách chê giá tăng mạnh.

**1. Đồ ăn có vấn đề.** Từ 15 đến 28/10 có 7 khách báo nôn, tiêu chảy, mùi lạ hoặc gián. Hãy tạm ngừng bán tiramisu (hai khách ăn xong đều bệnh), kiểm tra nguồn chả và sữa.

> [R170] "tối cả hai vợ chồng nôn mửa với tiêu chảy, phải đi cấp cứu"

**2. Tính tiền sai.** Từ 9/10 đến 5/11 có 6 khách bị tính thừa tiền, khuyến mãi ảo hoặc không nhận được hàng. Hãy soát máy tính tiền, ghi mọi khoản phí lên menu và hoàn tiền đơn bị bỏ.

> [R216] "Cuối bill tự cộng 10% phí dịch vụ, menu không ghi chỗ nào"

**3. Giá tăng.** Từ 28/9 có 36 khách chê giá, nhiều người nói giá tăng mà ly vẫn vậy. Hãy xem lại giá các món bị chê và báo trước khi tăng giá.

> [R097] "Dạo này quán tăng giá, cà phê muối lên 55k mà ly vẫn vậy"

Chưa chắc: dữ liệu không cho biết ca đau bụng có do quán hay không; 36 lượt chê giá chỉ có 21 câu khác nhau nên có thể chưa phải 36 khách riêng.
