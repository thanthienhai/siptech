#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tinh_ton_kho.py - Tinh ton kho / de xuat nhap hang thang 2026-11 cho cua hang (du lieu GIA).

Chay:  python tinh_ton_kho.py        (trong thu muc chua cac file du lieu; chi dung thu vien chuan)

Doc:   nhat-ky-xuat-nhap.csv, danh-muc-hang.csv, ton-dau-ky-2025-11-01.csv,
       ton-kiem-ke-2026-10-31.csv, hang-dang-ve.csv, tham-so.json
Ghi:   loi-du-lieu.csv, phan-loai-tinh-toan.csv, de-xuat-nhap.csv, giu-lai-do-loi.csv,
       kiem-tra-doi-chieu.csv (phu: chenh lech ton he thong - kiem ke), tom-tat-ket-qua.json (phu: so lieu cho bao cao)
KHONG sua file du lieu goc. Cong thuc theo quy-uoc.md (khong doi).
"""
import csv
import json
import math
import re
import statistics
import sys
import unicodedata
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent

# ----------------------------------------------------------------------------
# Cach xu ly MAC DINH cho cac ca KHONG CHAC (tat ca deu duoc ghi CAN_NGUOI_QUYET).
# Chon theo huong "khong bia so": khong de ca khong chac lam sai nhu cau du bao.
#   dem_vao_ton  = co tru/cong vao ton he thong hay khong
#   dem_vao_cau  = co tinh vao nhu cau ban hang hay khong
# ----------------------------------------------------------------------------
XU_LY_MAC_DINH = {
    "thieu_so_luong":       dict(dem_vao_ton=False, dem_vao_cau=False),
    "so_am_khong_ghi_chu":  dict(dem_vao_ton=False, dem_vao_cau=False),
    "so_luong_bat_thuong":  dict(dem_vao_ton=False, dem_vao_cau=False),
    "don_si_mot_lan":       dict(dem_vao_ton=True,  dem_vao_cau=False),
    "ngay_o_tuong_lai":     dict(dem_vao_ton=False, dem_vao_cau=False),
}
NGUONG_BAT_THUONG_LAN = 10   # so luong >= 10 x trung vi cua ma do (cac phieu ban le binh thuong) ...
NGUONG_BAT_THUONG_MIN = 10   # ... va >= 10 don vi


# ----------------------------------------------------------------------------
# Tien ich
# ----------------------------------------------------------------------------
def doc_csv(ten):
    with open(HERE / ten, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def ghi_csv(ten, cot, dong):
    with open(HERE / ten, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cot, extrasaction="ignore")
        w.writeheader()
        for r in dong:
            w.writerow(r)


def bo_dau(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D"))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", s).strip().lower()


def chuan_hoa_ma(s):
    return re.sub(r"[\s\-_]", "", s or "").upper()


def doc_ngay(s):
    """yyyy-mm-dd, dd/mm/yyyy, d/m/yy (kieu Viet Nam: ngay truoc thang)."""
    s = (s or "").strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        return date(int(m[1]), int(m[2]), int(m[3]))
    m = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{2,4})", s)
    if m:
        y = int(m[3])
        y += 2000 if y < 100 else 0
        return date(y, int(m[2]), int(m[1]))
    raise ValueError("Khong doc duoc ngay: %r" % s)


def so_nguyen(s):
    s = (s or "").strip()
    if s == "":
        return None
    return int(float(s))


def ceil_an_toan(x):
    return int(math.ceil(round(x, 9)))


def lam_tron_len_boi_so(x, boi):
    if x <= 0:
        return 0
    return int(math.ceil(round(x / boi, 9))) * boi


def thang_cua(d):
    return "%04d-%02d" % (d.year, d.month)


def danh_sach_thang(bat_dau, so_thang):
    y, m = int(bat_dau[:4]), int(bat_dau[5:])
    out = []
    for _ in range(so_thang):
        out.append("%04d-%02d" % (y, m))
        m += 1
        if m == 13:
            y, m = y + 1, 1
    return out


# ----------------------------------------------------------------------------
# 1. Doc + lam sach nhat ky
# ----------------------------------------------------------------------------
def lam_sach(tham_so, danh_muc, xu_ly=XU_LY_MAC_DINH):
    ngay_cuoi = date.fromisoformat(tham_so["ngay_cuoi_du_lieu"])

    # tu dien ten (bo dau) -> ma, de do ma cho dong thieu ma
    ten2ma = defaultdict(set)
    for ma, r in danh_muc.items():
        ten2ma[bo_dau(r["ten_hang"])].add(ma)

    raw = doc_csv("nhat-ky-xuat-nhap.csv")
    ev = []
    for i, r in enumerate(raw):
        ev.append(dict(
            stt=i + 2,                      # so dong trong file (dong 1 la tieu de)
            ma_phieu=r["ma_phieu"].strip(),
            ngay_goc=r["ngay"], loai=r["loai"].strip(), ma_goc=r["ma_hang"],
            ten=r["ten_hang"], sl_goc=r["so_luong"], ghi_chu=(r["ghi_chu"] or "").strip(),
            ma=chuan_hoa_ma(r["ma_hang"]), ngay=doc_ngay(r["ngay"]), sl=so_nguyen(r["so_luong"]),
            loi=[],  # list (loai_loi, xu_ly, ly_do)
            dem_ton=True, dem_cau=False, la_ban=False, bo=False,
        ))
    for e in ev:
        if e["ma"]:
            ten2ma[bo_dau(e["ten"])].add(e["ma"])

    n_chuan_hoa_ma = sum(1 for e in ev if e["ma"] and e["ma"] != e["ma_goc"])
    n_ngay_khac_dang = sum(1 for e in ev if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", e["ngay_goc"].strip()))

    # dong thieu ma -> do theo ten
    for e in ev:
        if not e["ma"]:
            cands = ten2ma.get(bo_dau(e["ten"]), set())
            if len(cands) == 1:
                e["ma"] = next(iter(cands))
                e["loi"].append(("khac", "SUA", "Thieu ma hang; do theo ten '%s' ra duy nhat ma %s" % (e["ten"], e["ma"])))
            else:
                e["loi"].append(("khac", "CAN_NGUOI_QUYET", "Thieu ma hang, khong do duoc ma tu ten '%s'" % e["ten"]))
                e["dem_ton"] = False

    # trung dong: cung ma_phieu + cung noi dung -> bo ban sau
    thay = {}
    for e in ev:
        k = e["ma_phieu"]
        if k in thay:
            g = thay[k]
            if (g["ngay"], g["ma"], g["loai"], g["sl"], g["ghi_chu"]) == (e["ngay"], e["ma"], e["loai"], e["sl"], e["ghi_chu"]):
                e["loi"].append(("trung_dong", "BO", "Trung phieu %s (dong %d); giu dong dau (dong %d), bo dong nay" % (k, e["stt"], g["stt"])))
                e["bo"] = True
            else:
                e["loi"].append(("trung_dong", "CAN_NGUOI_QUYET", "Trung ma phieu %s nhung noi dung khac dong %d" % (k, g["stt"])))
        else:
            thay[k] = e

    # trung vi so luong ban le binh thuong theo ma (de bat so luong gap bat thuong)
    le = defaultdict(list)
    for e in ev:
        if e["loai"] == "XUAT" and e["sl"] is not None and e["sl"] > 0 and not e["ghi_chu"] and not e["bo"]:
            le[e["ma"]].append(e["sl"])
    trung_vi = {m: statistics.median(v) for m, v in le.items()}

    nhap_si = defaultdict(set)
    for e in ev:
        if e["loai"] == "NHAP" and "don si" in bo_dau(e["ghi_chu"]):
            nhap_si[e["ma"]].add(e["ngay"])

    GHI_CHU_KHONG_BAN = {"xuat dung tai quan", "huy hang het han"}
    for e in ev:
        if e["bo"]:
            e["dem_ton"] = False
            continue
        loai, sl, gc = e["loai"], e["sl"], bo_dau(e["ghi_chu"])
        if e["ngay"] > ngay_cuoi:
            e["loi"].append(("ngay_o_tuong_lai", "CAN_NGUOI_QUYET",
                             "Ngay %s sau ngay cuoi du lieu %s (%s %s %s); khong tinh vao ton den 31/10" % (e["ngay"], ngay_cuoi, loai, e["ma"], sl)))
            e["dem_ton"] = xu_ly["ngay_o_tuong_lai"]["dem_vao_ton"]
            continue
        if sl is None:
            e["loi"].append(("thieu_so_luong", "CAN_NGUOI_QUYET", "Phieu %s %s thieu so luong; khong tu dien so" % (loai, e["ma"])))
            e["dem_ton"] = xu_ly["thieu_so_luong"]["dem_vao_ton"]
            continue
        if loai in ("DIEU_CHINH", "NHAP"):
            continue                     # DIEU_CHINH: tru vao ton, khong tinh vao nhu cau
        if loai == "XUAT":
            if sl < 0:
                if "khach tra" in gc:
                    e["dem_cau"], e["la_ban"] = True, True   # tra hang: cong lai ton, tru nhu cau
                else:
                    e["loi"].append(("so_am_khong_ghi_chu", "CAN_NGUOI_QUYET",
                                     "Xuat so am (%d) khong ghi chu 'khach tra'; co the la tra hang hoac go sai dau" % sl))
                    e["dem_ton"] = xu_ly["so_am_khong_ghi_chu"]["dem_vao_ton"]
                    e["dem_cau"] = xu_ly["so_am_khong_ghi_chu"]["dem_vao_cau"]
                    e["la_ban"] = e["dem_cau"]
                continue
            if gc in GHI_CHU_KHONG_BAN:
                e["loi"].append(("khong_phai_ban_hang", "GIU",
                                 "'%s': khong tinh vao nhu cau, van tru ton" % e["ghi_chu"]))
                continue
            if "khach si" in gc or "don si" in gc:
                e["loi"].append(("don_si_mot_lan", "CAN_NGUOI_QUYET",
                                 "Don si/dai ly %d don vi (ghi chu '%s'); loai khoi nhu cau, van tru ton" % (sl, e["ghi_chu"])))
                e["dem_ton"] = xu_ly["don_si_mot_lan"]["dem_vao_ton"]
                e["dem_cau"] = e["la_ban"] = xu_ly["don_si_mot_lan"]["dem_vao_cau"]
                continue
            med = trung_vi.get(e["ma"], 1)
            if sl >= NGUONG_BAT_THUONG_MIN and sl >= NGUONG_BAT_THUONG_LAN * max(med, 1):
                if e["ngay"] in nhap_si.get(e["ma"], ()):
                    e["loi"].append(("don_si_mot_lan", "CAN_NGUOI_QUYET",
                                     "Xuat %d (trung vi ban le %.0f) cung ngay co phieu 'nhap cho don si' -> nhieu kha nang don si khong ghi chu" % (sl, med)))
                    k = "don_si_mot_lan"
                else:
                    e["loi"].append(("so_luong_bat_thuong", "CAN_NGUOI_QUYET",
                                     "Xuat %d, gap %.0f lan trung vi ban le (%.0f); co the go du so 0 hoac don lon" % (sl, sl / max(med, 1), med)))
                    k = "so_luong_bat_thuong"
                e["dem_ton"] = xu_ly[k]["dem_vao_ton"]
                e["dem_cau"] = e["la_ban"] = xu_ly[k]["dem_vao_cau"]
                continue
            e["dem_cau"] = e["la_ban"] = True
    stats = dict(n_dong=len(ev), n_chuan_hoa_ma=n_chuan_hoa_ma, n_ngay_khac_dang=n_ngay_khac_dang)
    return ev, stats


# ----------------------------------------------------------------------------
# 2. Ton chay theo ngay, ngay het hang, nhu cau theo thang
# ----------------------------------------------------------------------------
def dong_tien_ton(e):
    if e["loai"] == "NHAP":
        return e["sl"]
    if e["loai"] == "XUAT":
        return -e["sl"]          # XUAT am (khach tra) -> cong ton
    return e["sl"]               # DIEU_CHINH da co dau


def tinh_ton_theo_ngay(ev, ton_dau, ds_ma, d0, d1):
    delta = defaultdict(lambda: defaultdict(int))
    for e in ev:
        if e["dem_ton"] and e["sl"] is not None and e["ma"] in ds_ma and d0 <= e["ngay"] <= d1:
            delta[e["ma"]][e["ngay"]] += dong_tien_ton(e)
    ngay = [d0 + timedelta(days=i) for i in range((d1 - d0).days + 1)]
    cuoi_ngay = {}
    for ma in ds_ma:
        t = ton_dau[ma]
        arr = {}
        for d in ngay:
            t += delta[ma].get(d, 0)
            arr[d] = t
        cuoi_ngay[ma] = arr
    return cuoi_ngay


def ngay_het_hang_theo_thang(cuoi_ngay, ton_dau, ev, ds_ma, d0):
    """Dem so ngay ton cuoi ngay <= 0 moi thang.
    Gia dinh: mat hang moi (ton dau 0) chua co hang truoc ngay NHAP dau tien thi KHONG tinh la 'het hang'
    (chua ban, khong phai cut hang)."""
    dau_tien = {}
    for ma in ds_ma:
        if ton_dau[ma] > 0:
            dau_tien[ma] = d0
        else:
            ds = [e["ngay"] for e in ev if e["ma"] == ma and e["loai"] == "NHAP" and e["dem_ton"] and e["sl"]]
            dau_tien[ma] = min(ds) if ds else None
    kq = {ma: defaultdict(int) for ma in ds_ma}
    for ma in ds_ma:
        for d, t in cuoi_ngay[ma].items():
            if t <= 0 and dau_tien[ma] is not None and d >= dau_tien[ma]:
                kq[ma][thang_cua(d)] += 1
    return kq, dau_tien


def nhu_cau_theo_thang(ev, ds_ma, thang_ds):
    nc = {ma: {t: 0 for t in thang_ds} for ma in ds_ma}
    tho = {ma: {t: 0 for t in thang_ds} for ma in ds_ma}   # doanh so tho: cong het XUAT, khong lam sach
    for e in ev:
        t = thang_cua(e["ngay"])
        if e["ma"] not in ds_ma or t not in thang_ds:
            continue
        if e["loai"] == "XUAT" and e["sl"] is not None:
            tho[e["ma"]][t] += e["sl"]
        if e["dem_cau"] and e["la_ban"] and e["sl"] is not None and not e["bo"]:
            nc[e["ma"]][t] += e["sl"]       # tra hang la so am -> tru di
    return nc, tho


# ----------------------------------------------------------------------------
# 3. Du bao, an toan, ROP (cong thuc co dinh)
# ----------------------------------------------------------------------------
def thang_hop_le(nc, cut, thang_ds, truoc_thang=None):
    """Hop le = da ban (>0) + khong cut hang. Chi xet cac thang < truoc_thang (neu co)."""
    out = []
    for t in thang_ds:
        if truoc_thang is not None and t >= truoc_thang:
            continue
        if nc[t] > 0 and t not in cut:
            out.append(t)
    return out


def du_bao(nc, hop_le, Z, T):
    """Tra ve (F, sigma, SS, ROP, co)."""
    co = []
    gan = hop_le[-3:]
    if not gan:
        return None, None, None, None, ["KHONG_CO_THANG_HOP_LE"]
    F = sum(nc[t] for t in gan) / len(gan)
    if len(gan) < 3:
        co.append("DU_LIEU_NGAN")
    s6 = [nc[t] for t in hop_le[-6:]]
    if len(s6) >= 3:
        sigma = statistics.stdev(s6)
    else:
        sigma = 0.5 * F
        if "DU_LIEU_NGAN" not in co:
            co.append("DU_LIEU_NGAN")
        co.append("SIGMA_GIA_DINH")
    SS = ceil_an_toan(Z * sigma * math.sqrt(T / 30.0))
    ROP = ceil_an_toan(F / 30.0 * T + SS)
    return F, sigma, SS, ROP, co


def chay(xu_ly=XU_LY_MAC_DINH):
    ts = json.load(open(HERE / "tham-so.json", encoding="utf-8"))
    Z = ts["z_tuong_ung"]
    ngay_cuoi = date.fromisoformat(ts["ngay_cuoi_du_lieu"])
    d0 = date(2025, 11, 1)
    thang_ds = danh_sach_thang("2025-11", 12)
    nguong_cut = ts["so_ngay_cut_hang_toi_thieu"]

    dm_rows = doc_csv("danh-muc-hang.csv")
    danh_muc = {r["ma_hang"]: r for r in dm_rows}
    ds_ma = [r["ma_hang"] for r in dm_rows]
    ton_dau = {r["ma_hang"]: int(r["ton_dau_ky"]) for r in doc_csv("ton-dau-ky-2025-11-01.csv")}
    kiem_ke = {r["ma_hang"]: int(r["ton_thuc_te_kiem_ke"]) for r in doc_csv("ton-kiem-ke-2026-10-31.csv")}
    dang_ve_rows = doc_csv("hang-dang-ve.csv")
    dang_ve = defaultdict(int)
    for r in dang_ve_rows:
        dang_ve[r["ma_hang"]] += int(r["so_luong"])

    ev, st_lam_sach = lam_sach(ts, danh_muc, xu_ly)
    ma_la = {e["ma"] for e in ev if e["ma"] and e["ma"] not in danh_muc}
    if ma_la:
        raise SystemExit("Co ma khong co trong danh muc: %s" % sorted(ma_la))

    cuoi_ngay = tinh_ton_theo_ngay(ev, ton_dau, set(ds_ma), d0, ngay_cuoi)
    ton_he_thong = {ma: cuoi_ngay[ma][ngay_cuoi] for ma in ds_ma}
    het, dau_tien = ngay_het_hang_theo_thang(cuoi_ngay, ton_dau, ev, ds_ma, d0)
    nc, tho = nhu_cau_theo_thang(ev, set(ds_ma), set(thang_ds))
    cut = {ma: sorted(t for t in thang_ds if het[ma].get(t, 0) >= nguong_cut) for ma in ds_ma}

    pc = {}
    for ma in ds_ma:
        T = int(danh_muc[ma]["thoi_gian_giao_ngay"])
        hop_le = thang_hop_le(nc[ma], set(cut[ma]), thang_ds)
        F, sigma, SS, ROP, co = du_bao(nc[ma], hop_le, Z, T)
        pc[ma] = dict(T=T, hop_le=hop_le, F=F, sigma=sigma, SS=SS, ROP=ROP, co=co)
    return dict(ts=ts, ev=ev, st_lam_sach=st_lam_sach, danh_muc=danh_muc, ds_ma=ds_ma, ton_dau=ton_dau,
                kiem_ke=kiem_ke, dang_ve=dict(dang_ve), dang_ve_rows=dang_ve_rows, cuoi_ngay=cuoi_ngay,
                ton_he_thong=ton_he_thong, het=het, nc=nc, tho=tho, cut=cut, pc=pc, thang_ds=thang_ds,
                dau_tien=dau_tien, Z=Z)


# ----------------------------------------------------------------------------
# 4. ABC, canh bao, de xuat nhap, ngan sach, giu lai, doi chieu
# ----------------------------------------------------------------------------
def phan_loai(kq):
    ts, ds_ma, dm, nc, pc, ev = kq["ts"], kq["ds_ma"], kq["danh_muc"], kq["nc"], kq["pc"], kq["ev"]
    ngay_cuoi = date.fromisoformat(ts["ngay_cuoi_du_lieu"])
    gia_tri = {ma: sum(nc[ma].values()) * float(dm[ma]["gia_von_hien_tai"]) for ma in ds_ma}
    tong = sum(gia_tri.values())
    lop, truoc = {}, 0.0
    for ma in sorted(ds_ma, key=lambda m: (-gia_tri[m], m)):
        lop[ma] = "A" if truoc < 0.80 * tong - 1e-9 else ("B" if truoc < 0.95 * tong - 1e-9 else "C")
        truoc += gia_tri[ma]
    moc90 = ngay_cuoi - timedelta(days=ts["nguong_khong_ban_ngay"] - 1)
    ban_90 = defaultdict(int)
    for e in ev:
        if e["dem_cau"] and e["la_ban"] and e["sl"] and e["sl"] > 0 and e["ngay"] >= moc90 and not e["bo"]:
            ban_90[e["ma"]] += 1
    for ma in ds_ma:
        p = pc[ma]
        F, tk = p["F"], kq["kiem_ke"][ma]
        p["so_ngay_ton"] = tk / (F / 30.0) if (F is not None and F > 0) else None
        if tk == 0:
            cb = "HET_HANG"
        elif p["ROP"] is not None and tk <= p["ROP"]:
            cb = "SAP_HET"
        elif (F is None or F <= 0 or (p["so_ngay_ton"] is not None and p["so_ngay_ton"] > ts["nguong_ton_lau_ngay"])
              or ban_90[ma] == 0):
            cb = "TON_LAU"
        elif F < ts["nguong_ban_cham_don_vi_thang"]:
            cb = "BAN_CHAM"
        else:
            cb = "OK"
        p["canh_bao"] = cb
    kq["gia_tri"], kq["lop"], kq["ban_90"] = gia_tri, lop, ban_90


def dong_can_nguoi_quyet_theo_ma(ev):
    d = defaultdict(list)
    for e in ev:
        for (lk, xl, ld) in e["loi"]:
            if xl == "CAN_NGUOI_QUYET" and e["ma"]:
                d[e["ma"]].append((e["ma_phieu"], lk))
    return d


GIA_THUYET = {  # tac dong len (kiem ke - he thong) neu gia thuyet dung; CHI DE GIAI THICH, KHONG dung de tinh
    "so_am_khong_ghi_chu": lambda e: -abs(e["sl"]),                 # thuc ra la mot lan ban, go nham dau tru
    "so_luong_bat_thuong": lambda e: -int(round(e["sl"] / 10.0)),   # go thua mot so 0: so that ~ 1/10
    "ngay_o_tuong_lai": lambda e: +e["sl"],                         # hang da ve truoc 31/10, go sai ngay
}


def doi_chieu(kq):
    ev, ds_ma = kq["ev"], kq["ds_ma"]
    rows = []
    for ma in ds_ma:
        ths, kk = kq["ton_he_thong"][ma], kq["kiem_ke"][ma]
        chenh = kk - ths
        lien_quan, gt, co_thieu = [], 0, False
        for e in ev:
            if e["ma"] != ma:
                continue
            for (lk, xl, ld) in e["loi"]:
                if xl != "CAN_NGUOI_QUYET":
                    continue
                if lk in GIA_THUYET and e["sl"] is not None:
                    h = GIA_THUYET[lk](e)
                    gt += h
                    lien_quan.append("%s %s %s sl=%s (gia thuyet %+d)" % (e["ma_phieu"], lk, e["ngay"], e["sl"], h))
                else:
                    if lk == "thieu_so_luong":
                        co_thieu = True
                    lien_quan.append("%s %s %s sl=%s" % (e["ma_phieu"], lk, e["ngay"], e["sl"]))
        con_lai = chenh - gt
        if chenh == 0:
            gt_txt = "Khop"
        elif not lien_quan:
            gt_txt = "Khong co dong loi nao lien quan; co the hao hut/ban chua ghi, CAN NGUOI QUYET"
        elif con_lai == 0:
            gt_txt = "Giai thich het neu cac gia thuyet tren dung"
        else:
            gt_txt = "Giai thich duoc %+d, con lai %+d%s" % (
                gt, con_lai, " (co phieu thieu so luong nen khong cong duoc)" if co_thieu else " chua giai thich duoc")
        rows.append(dict(ma_hang=ma, ton_he_thong=ths, ton_kiem_ke=kk, chenh_kiem_ke=chenh,
                         dong_loi_lien_quan="; ".join(lien_quan),
                         chenh_giai_thich_boi_gia_thuyet=gt if lien_quan else "",
                         chenh_con_lai=con_lai if lien_quan else chenh, ghi_chu=gt_txt))
    return rows


def giu_lai(kq):
    ts, ds_ma, nc, tho, cut, thang_ds = kq["ts"], kq["ds_ma"], kq["nc"], kq["tho"], kq["cut"], kq["thang_ds"]
    rows = []
    for m in ts["thang_giu_lai_do_loi"]:
        truoc_thang = thang_ds[thang_ds.index(m) - 1]
        for ma in ds_ma:
            hl = thang_hop_le(nc[ma], set(cut[ma]), thang_ds, truoc_thang=m)   # chi dung thang < m
            F = sum(nc[ma][t] for t in hl[-3:]) / len(hl[-3:]) if hl else None
            ok = (m not in cut[ma]) and len(hl) >= 3
            rows.append(dict(ma_hang=ma, thang=m, thuc_te=nc[ma][m],
                             du_bao="" if F is None else round(F, 2),
                             moc_thang_truoc=tho[ma][truoc_thang],
                             moc_thang_truoc_sach=nc[ma][truoc_thang],
                             tinh_duoc="CO" if ok else "KHONG", _F=F))
    return rows


def do_loi(rows):
    def chi_so(rs, f_moc):
        n = len(rs)
        if n == 0:
            return dict(n=0)
        sa = sum(abs(r["_F"] - r["thuc_te"]) for r in rs)
        sb = sum(abs(f_moc(r) - r["thuc_te"]) for r in rs)
        st = sum(r["thuc_te"] for r in rs)
        return dict(n=n, tong_thuc_te=st, mae_cong_thuc=sa / n, mae_moc=sb / n,
                    wape_cong_thuc=(sa / st if st else None), wape_moc=(sb / st if st else None),
                    so_ma_cong_thuc_tot_hon=sum(1 for r in rs if abs(r["_F"] - r["thuc_te"]) < abs(f_moc(r) - r["thuc_te"])),
                    so_ma_moc_tot_hon=sum(1 for r in rs if abs(r["_F"] - r["thuc_te"]) > abs(f_moc(r) - r["thuc_te"])))
    out = {}
    thang_list = sorted({r["thang"] for r in rows})
    for nhom, loc in [("tat_ca", lambda r: True)] + [(t, (lambda r, t=t: r["thang"] == t)) for t in thang_list]:
        rs = [r for r in rows if r["tinh_duoc"] == "CO" and loc(r)]
        out[nhom] = dict(moc_tho=chi_so(rs, lambda r: r["moc_thang_truoc"]),
                         moc_sach=chi_so(rs, lambda r: r["moc_thang_truoc_sach"]))
    return out


def de_xuat_nhap(kq):
    dm, ds_ma, pc, lop, ts = kq["danh_muc"], kq["ds_ma"], kq["pc"], kq["lop"], kq["ts"]
    ngan_sach = ts["ngan_sach_nhap_vnd"]
    dv_ve = defaultdict(list)
    for r in kq["dang_ve_rows"]:
        dv_ve[r["ma_hang"]].append(r["ngay_du_kien_ve"])
    ds_cnq = dong_can_nguoi_quyet_theo_ma(kq["ev"])
    doi = {r["ma_hang"]: r for r in kq["doi_chieu"]}
    cuoi_thang_de_xuat = ts["thang_de_xuat"] + "-31"
    items = []
    for ma in ds_ma:
        p, r = pc[ma], dm[ma]
        boi, gia = int(r["quy_cach_dat_boi_so"]), int(r["gia_von_hien_tai"])
        F, tk, dv = p["F"], kq["kiem_ke"][ma], kq["dang_ve"].get(ma, 0)
        can = 0 if F is None else lam_tron_len_boi_so(F + p["SS"] - tk - dv, boi)
        cover = ((tk + dv) / (F / 30.0)) if (F and F > 0) else 9999.0
        items.append(dict(ma=ma, boi=boi, gia=gia, F=F, SS=p["SS"], tk=tk, dv=dv, can=can, lop=lop[ma],
                          cb=p["canh_bao"], cover=cover, trang_thai=r["trang_thai"], co=list(p["co"]),
                          cnq=[], de_xuat=0, uu_tien=""))
    for it in items:
        ma = it["ma"]
        if ds_cnq.get(ma):
            it["cnq"].append("du lieu chua chac: " + ",".join(sorted({k for _, k in ds_cnq[ma]})))
        if "DU_LIEU_NGAN" in it["co"]:
            it["cnq"].append("du lieu ngan (DU_LIEU_NGAN)")
        if it["F"] is None:
            it["cnq"].append("khong co thang hop le de du bao")
        if any(d > cuoi_thang_de_xuat for d in dv_ve.get(ma, [])):
            it["cnq"].append("hang dang ve du kien sau %s (%s) nhung van bi tru khoi so can nhap"
                             % (ts["thang_de_xuat"], ",".join(dv_ve[ma])))
        if abs(doi[ma]["chenh_con_lai"]) >= max(5, 0.2 * (it["F"] or 0)):
            it["cnq"].append("ton he thong lech kiem ke %+d chua giai thich het" % doi[ma]["chenh_con_lai"])
    # uu tien: (1) het/sap het, (2) lop ABC, (3) so ngay con hang tang dan
    nhom = lambda it: 0 if it["cb"] in ("HET_HANG", "SAP_HET") else 1
    can_nhap = [it for it in items if it["can"] > 0 and it["trang_thai"] == "dang_ban"]
    can_nhap.sort(key=lambda it: (nhom(it), it["lop"], it["cover"], it["ma"]))
    con = ngan_sach
    for rank, it in enumerate(can_nhap, 1):
        it["uu_tien"] = rank
        if it["can"] * it["gia"] <= con:
            it["de_xuat"] = it["can"]
        else:
            it["de_xuat"] = int(con // (it["gia"] * it["boi"])) * it["boi"]
        con -= it["de_xuat"] * it["gia"]
        if it["de_xuat"] < it["can"]:
            it["cnq"].append("bi cat do ngan sach: can %d, de xuat %d" % (it["can"], it["de_xuat"]))
    for it in items:
        it["thanh_tien"] = it["de_xuat"] * it["gia"]
    return items, ngan_sach - con


def main():
    kq = chay()
    phan_loai(kq)
    kq["doi_chieu"] = doi_chieu(kq)
    ts, ds_ma, pc, nc = kq["ts"], kq["ds_ma"], kq["pc"], kq["nc"]

    # --- loi-du-lieu.csv (kem chenh kiem ke cua ma lam bang chung cho ca CAN_NGUOI_QUYET) ---
    chenh = {r["ma_hang"]: r["chenh_kiem_ke"] for r in kq["doi_chieu"]}
    rows_loi = []
    for e in kq["ev"]:
        for (lk, xl, ld) in e["loi"]:
            ghi = ld
            if xl == "CAN_NGUOI_QUYET" and e["ma"]:
                ghi += " | chenh kiem ke cua ma %s: %+d" % (e["ma"], chenh[e["ma"]])
            rows_loi.append(dict(ma_phieu=e["ma_phieu"], loai_loi=lk, ma_hang=e["ma"], xu_ly=xl,
                                 ly_do="[dong %d] %s" % (e["stt"], ghi)))
    ghi_csv("loi-du-lieu.csv", ["ma_phieu", "loai_loi", "ma_hang", "xu_ly", "ly_do"], rows_loi)

    items, tong_tien = de_xuat_nhap(kq)
    assert tong_tien <= ts["ngan_sach_nhap_vnd"], "Vuot ngan sach!"

    # --- phan-loai-tinh-toan.csv ---
    rows_pc = []
    for ma in ds_ma:
        p = pc[ma]
        F = p["F"]
        rows_pc.append(dict(
            ma_hang=ma, lop_abc=kq["lop"][ma], gia_tri_tieu_thu_nam=round(kq["gia_tri"][ma]),
            so_thang_hop_le=len(p["hop_le"]), thang_cut_hang=";".join(kq["cut"][ma]),
            nhu_cau_du_bao_thang="" if F is None else round(F, 2),
            do_lech_chuan="" if p["sigma"] is None else round(p["sigma"], 2),
            ton_an_toan="" if p["SS"] is None else p["SS"],
            diem_dat_lai="" if p["ROP"] is None else p["ROP"],
            ton_kiem_ke=kq["kiem_ke"][ma], ton_he_thong=kq["ton_he_thong"][ma],
            chenh_kiem_ke=kq["kiem_ke"][ma] - kq["ton_he_thong"][ma],
            hang_dang_ve=kq["dang_ve"].get(ma, 0),
            so_ngay_ton="" if p["so_ngay_ton"] is None else round(p["so_ngay_ton"], 1),
            cung_ky_nam_truoc_2025_11=nc[ma]["2025-11"], canh_bao=p["canh_bao"]))
    ghi_csv("phan-loai-tinh-toan.csv",
            ["ma_hang", "lop_abc", "gia_tri_tieu_thu_nam", "so_thang_hop_le", "thang_cut_hang", "nhu_cau_du_bao_thang",
             "do_lech_chuan", "ton_an_toan", "diem_dat_lai", "ton_kiem_ke", "ton_he_thong", "chenh_kiem_ke",
             "hang_dang_ve", "so_ngay_ton", "cung_ky_nam_truoc_2025_11", "canh_bao"], rows_pc)

    # --- de-xuat-nhap.csv ---
    rows_dx = []
    for it in items:
        F = it["F"]
        if it["trang_thai"] != "dang_ban":
            ld = "Mat hang '%s': khong de xuat nhap. Ton kiem ke %d." % (it["trang_thai"], it["tk"])
        elif F is None:
            ld = "Khong co thang hop le de du bao"
        else:
            ld = "F=%.1f + an toan %d - ton %d - dang ve %d = %.1f -> %d (boi %d). Canh bao %s, lop %s, con hang ~%s ngay" % (
                F, it["SS"], it["tk"], it["dv"], F + it["SS"] - it["tk"] - it["dv"], it["can"], it["boi"],
                it["cb"], it["lop"], "n/a" if it["cover"] >= 9999 else "%.0f" % it["cover"])
            if it["can"] == 0:
                ld += ". Khong can nhap thang nay"
            else:
                ld += ". Uu tien #%s" % it["uu_tien"]
        if it["cnq"] and it["trang_thai"] == "dang_ban":
            ld += ". CAN NGUOI QUYET: " + "; ".join(it["cnq"])
        rows_dx.append(dict(ma_hang=it["ma"], sl_can_chua_xet_ngan_sach=it["can"] if it["trang_thai"] == "dang_ban" else 0,
                            sl_de_xuat=it["de_xuat"], quy_cach=it["boi"], don_gia_von=it["gia"],
                            thanh_tien=it["thanh_tien"], uu_tien=it["uu_tien"],
                            can_nguoi_quyet="CO" if (it["cnq"] and it["trang_thai"] == "dang_ban") else "KHONG", ly_do=ld))
    ghi_csv("de-xuat-nhap.csv", ["ma_hang", "sl_can_chua_xet_ngan_sach", "sl_de_xuat", "quy_cach", "don_gia_von",
                                 "thanh_tien", "uu_tien", "can_nguoi_quyet", "ly_do"], rows_dx)

    # --- giu-lai-do-loi.csv ---
    gl = giu_lai(kq)
    ghi_csv("giu-lai-do-loi.csv", ["ma_hang", "thang", "thuc_te", "du_bao", "moc_thang_truoc", "tinh_duoc"], gl)
    do = do_loi(gl)

    ghi_csv("kiem-tra-doi-chieu.csv",
            ["ma_hang", "ton_he_thong", "ton_kiem_ke", "chenh_kiem_ke", "dong_loi_lien_quan",
             "chenh_giai_thich_boi_gia_thuyet", "chenh_con_lai", "ghi_chu"], kq["doi_chieu"])

    # --- tu kiem ---
    kiem = [
        ("Tong tien <= ngan sach", tong_tien <= ts["ngan_sach_nhap_vnd"]),
        ("Moi sl_de_xuat la boi so quy cach", all(it["de_xuat"] % it["boi"] == 0 for it in items)),
        ("Moi ma co dung 1 nhan canh bao", all(pc[m]["canh_bao"] in ("HET_HANG", "SAP_HET", "TON_LAU", "BAN_CHAM", "OK") for m in ds_ma)),
        ("60 ma moi file (120 dong giu lai)", len(rows_pc) == 60 and len(rows_dx) == 60 and len(gl) == 120),
        ("Khong de xuat nhap hang ngung_nhap", all(it["de_xuat"] == 0 for it in items if it["trang_thai"] != "dang_ban")),
        ("Thanh tien = sl x gia von", all(it["thanh_tien"] == it["de_xuat"] * it["gia"] for it in items)),
        ("Tong thanh_tien trong file = tong tien", sum(r["thanh_tien"] for r in rows_dx) == tong_tien),
    ]
    tom_tat = dict(
        tong_tien_de_xuat=tong_tien, ngan_sach=ts["ngan_sach_nhap_vnd"],
        tong_tien_chua_xet_ngan_sach=sum(it["can"] * it["gia"] for it in items if it["trang_thai"] == "dang_ban"),
        phan_cat=[dict(ma=it["ma"], can=it["can"], de_xuat=it["de_xuat"], gia=it["gia"],
                       cat_tien=(it["can"] - it["de_xuat"]) * it["gia"], lop=it["lop"], cb=it["cb"], uu_tien=it["uu_tien"])
                  for it in items if it["trang_thai"] == "dang_ban" and it["de_xuat"] < it["can"]],
        so_ma_de_xuat=sum(1 for it in items if it["de_xuat"] > 0),
        canh_bao={k: sorted(m for m in ds_ma if pc[m]["canh_bao"] == k) for k in ("HET_HANG", "SAP_HET", "TON_LAU", "BAN_CHAM", "OK")},
        lop_abc={k: sorted(m for m in ds_ma if kq["lop"][m] == k) for k in "ABC"},
        giu_lai=do, tu_kiem=kiem, lam_sach=kq["st_lam_sach"],
        so_loi={k: sum(1 for r in rows_loi if r["loai_loi"] == k) for k in sorted({r["loai_loi"] for r in rows_loi})},
        thieu_du_lieu={m: dict(so_thang_hop_le=len(pc[m]["hop_le"]), co=pc[m]["co"]) for m in ds_ma if pc[m]["co"] or len(pc[m]["hop_le"]) < 3},
        chenh_kiem_ke={r["ma_hang"]: r["chenh_kiem_ke"] for r in kq["doi_chieu"] if r["chenh_kiem_ke"] != 0},
    )
    with open(HERE / "tom-tat-ket-qua.json", "w", encoding="utf-8") as f:
        json.dump(tom_tat, f, ensure_ascii=False, indent=1, default=str)

    print("=== TU KIEM ===")
    for k, v in kiem:
        print(("OK   " if v else "LOI  ") + k)
    print("Tong tien de xuat: {:,} / ngan sach {:,} (chua xet ngan sach: {:,})".format(
        tong_tien, ts["ngan_sach_nhap_vnd"], tom_tat["tong_tien_chua_xet_ngan_sach"]))
    print("So ma co de xuat > 0:", tom_tat["so_ma_de_xuat"], "| ma bi cat:", len(tom_tat["phan_cat"]))
    print("Canh bao:", {k: len(v) for k, v in tom_tat["canh_bao"].items()}, "| ABC:", {k: len(v) for k, v in tom_tat["lop_abc"].items()})
    print("Ma chenh kiem ke:", len(tom_tat["chenh_kiem_ke"]))
    print("Da ghi: loi-du-lieu.csv, phan-loai-tinh-toan.csv, de-xuat-nhap.csv, giu-lai-do-loi.csv, "
          "kiem-tra-doi-chieu.csv, tom-tat-ket-qua.json")
    if not all(v for _, v in kiem):
        sys.exit(1)


if __name__ == "__main__":
    main()
