"""Dựng lại 10 ảnh trong anh/ từ log đã che và file thật của bài.

Dùng:  python -X utf8 dung_anh.py [--term-dir <thư mục chứa term.py>]
Cần:   Python 3, playwright (Edge), openpyxl, và term.py (công cụ dựng ảnh terminal từ log, có sẵn scrub_text).
       term.py được tìm theo thứ tự: --term-dir, biến môi trường TERM_DIR, rồi thư mục cạnh bài (../../../../siptech-video/agentlab).
Ảnh terminal dựng từ logs/*.json; ảnh bảng dựng từ du-lieu/ và ket-qua/. Mọi chữ lấy từ log hoặc đường dẫn đều qua scrub_text.
Đường dẫn trong script là tương đối so với vị trí file này.
"""
import argparse, csv, html, json, os, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent            # thư mục bài
ap = argparse.ArgumentParser(); ap.add_argument("--term-dir", default=None)
args = ap.parse_args()
cands = [args.term_dir, os.environ.get("TERM_DIR"), str(ROOT.parents[3] / "siptech-video" / "agentlab")]
for c in cands:
    if c and (Path(c) / "term.py").exists(): sys.path.insert(0, c); break
else: raise SystemExit("Không tìm thấy term.py; dùng --term-dir")
from term import render_blocks, shot_html, scrub_text, CSS as TERM_CSS
import openpyxl

ANH, LOGS, KQ, DL = ROOT / "anh", ROOT / "logs", ROOT / "ket-qua", ROOT / "du-lieu"
S = scrub_text

# ---------------------------------------------------------------- ảnh terminal từ log
NOISE = re.compile(r"^(Line \||\s+\d+ \||\s+\|)")
def load(name):
    t = json.loads((LOGS / f"{name}.json").read_text(encoding="utf-8"))
    for b in t["blocks"]:   # bỏ dòng nhiễu do profile PowerShell của máy chạy (giữ nguyên ý nghĩa ảnh)
        if isinstance(b.get("output"), str):
            b["output"] = "\n".join(l for l in b["output"].split("\n")
                                    if "profile.ps1" not in l and "OneDrive" not in l and not NOISE.match(l) and not l.startswith(".: "))
    return t

def term_img(name, out, a, b, title, maxlines):
    t = load(name)
    h = render_blocks(t["blocks"][a:b], title, None, maxlines, 1280, False)
    shot_html(h, str(ANH / out), 1320, ".win")

term_img("claude-1", "04-claude-lam-viec.png", 6, 10, "Claude Code · lần chạy claude-1", 8)
n = len(load("claude-1")["blocks"]); term_img("claude-1", "05-claude-ket-qua-cuoi.png", n - 1, n, "Claude Code · kết quả cuối (claude-1)", 40)
term_img("agy-2", "06-agy-lam-viec.png", 57, 59, "Antigravity (agy) · lần chạy agy-2", 34)
n = len(load("agy-2")["blocks"]); term_img("agy-2", "07-agy-ket-qua-cuoi.png", n - 1, n, "Antigravity (agy) · kết quả cuối (agy-2)", 40)

# ---------------------------------------------------------------- ảnh prompt
p = (KQ / "prompt-giao-viec.txt").read_text(encoding="utf-8")
body = ""
for ln in S(p).splitlines():
    if ln.startswith("# "): body += f'<div class="tool"><span class="n">{html.escape(ln)}</span></div>'
    else: body += f'<div class="u" style="color:#e2e8f0">{html.escape(ln)}</div>'
shot_html(f'<!doctype html><meta charset="utf-8"><style>{TERM_CSS}.body{{font-size:13.5px;line-height:1.45}}</style><div style="padding:18px;width:1400px"><div class="win">'
          f'<div class="bar"><span class="dot r"></span><span class="dot y"></span><span class="dot g"></span><span class="t">prompt-giao-viec.txt (nội dung giao việc, 6 phần)</span></div><div class="body">{body}</div></div></div>',
          str(ANH / "01-prompt-giao-viec.png"), 1440, ".win")

# ---------------------------------------------------------------- ảnh bảng
CSS = """body{margin:0;background:#f1f5f9;font-family:'Segoe UI',Arial,sans-serif}.w{padding:16px;width:1180px}
h3{margin:0 0 4px;font-size:18px;color:#0f172a}.sub{color:#b91c1c;font-size:13px;margin-bottom:8px;font-weight:600}
table{border-collapse:collapse;width:100%;background:#fff;font-size:13.5px}th{background:#1e3a8a;color:#fff;text-align:left;padding:6px 8px}
td{border:1px solid #cbd5e1;padding:5px 8px;vertical-align:top}td.r{text-align:right;white-space:nowrap}td.nd{font-family:Consolas,monospace}
tr.pre td{background:#fef9c3}tr.hl td{background:#fee2e2}tr.ft td{background:#dcfce7}.n{color:#64748b;font-size:12px;margin-top:6px}
.cnq{background:#fee2e2}.tb{background:#fef9c3}.cao{background:#dcfce7}.bad{background:#fecaca;font-weight:600}.ok{background:#dcfce7}.mid{background:#fef9c3}"""
E = lambda x: html.escape(S(str(x)))
def rd(p): return list(csv.DictReader(open(p, encoding="utf-8-sig")))
def vn(x): return f"{int(x):,}".replace(",", ".") if str(x).strip() else ""

# 02 sao kê mẫu
rows = list(csv.reader(open(DL / "sao-ke-t10-2026.csv", encoding="utf-8-sig")))
hdr = rows.index(["Ngày GD", "Số CT", "Ghi nợ", "Ghi có", "Số dư", "Nội dung chi tiết"])
t = "<table>"
for r in rows[:6]: t += f"<tr class='pre'><td colspan='6'>{E(' : '.join(x for x in r if x))}</td></tr>"
t += "<tr>" + "".join(f"<th>{E(h)}</th>" for h in rows[hdr]) + "</tr>"
for r in rows[hdr + 1: hdr + 26]:
    t += "<tr>" + "".join(f"<td class='{'r' if i in (2,3,4) else ('nd' if i==5 else '')}'>{E(c)}</td>" for i, c in enumerate(r)) + "</tr>"
t += "<tr><td colspan='6' style='text-align:center;color:#64748b'>… (còn 119 dòng giao dịch)</td></tr>"
for r in rows[-3:]: t += f"<tr class='ft'><td colspan='6'>{E(' : '.join(x for x in r if x))}</td></tr>"
t += "</table>"
shot_html(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style><div class='w'><h3>sao-ke-t10-2026.csv (mô phỏng sao kê ngân hàng)</h3><div class='sub'>DỮ LIỆU GIẢ ĐỂ HỌC — không phải dữ liệu của doanh nghiệp nào. Vàng: dòng thông tin đầu file; xanh: dòng tổng cuối file (không phải giao dịch).</div>{t}<div class='n'>Dựng từ file du-lieu/sao-ke-t10-2026.csv, 25 dòng giao dịch đầu.</div></div>",
         str(ANH / "02-sao-ke-mau.png"), 1220, ".w")

# 03 sổ đơn mẫu
data = list(openpyxl.load_workbook(DL / "so-don-hang-t10-2026.xlsx").active.iter_rows(values_only=True))
def fmt(v):
    if v is None: return ""
    if hasattr(v, "strftime"): return v.strftime("%d/%m/%Y")
    if isinstance(v, int) and v >= 1000: return f"{v:,}"
    return str(v)
pick = list(range(1, 11)) + [i for i, r in enumerate(data) if i > 10 and (isinstance(r[1], str) or isinstance(r[8], str))][:3]
t = "<table><tr>" + "".join(f"<th>{E(h)}</th>" for h in data[0]) + "</tr>"
for i in pick:
    r = data[i]; cls = "hl" if (isinstance(r[1], str) or isinstance(r[8], str)) else ""
    t += f"<tr class='{cls}'>" + "".join(f"<td class='{'r' if j in (5,6,7,8) else ''}'>{E(fmt(c))}</td>" for j, c in enumerate(r)) + "</tr>"
t += "</table>"
shot_html(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style><div class='w' style='width:1380px'><h3>so-don-hang-t10-2026.xlsx (sổ đơn hàng)</h3><div class='sub'>DỮ LIỆU GIẢ ĐỂ HỌC. Hồng: dòng có ngày hoặc tổng tiền nhập dạng chữ (định dạng lẫn lộn cố ý).</div>{t}<div class='n'>128 đơn; 13 dòng đầu + 3 dòng định dạng lẫn lộn.</div></div>",
         str(ANH / "03-so-don-hang-mau.png"), 1440, ".w")

# 08 trích bảng ghép của claude-1
ans = json.load(open(KQ / "dap-an.json", encoding="utf-8"))["dong"]
bg = {r["so_ct"]: r for r in rd(KQ / "claude-1" / "bang_ghep.csv")}
first = lambda loai: [k for k, v in ans.items() if v["loai"] == loai]
want = [k for k in first("khop_du") if ans[k]["muc"] == "ro"][:2]
for l, n_ in (("thieu", 1), ("thua", 1), ("trung", 1), ("nhieu_don", 1), ("cod_gop", 1), ("khong_ro_nguon", 1), ("phi_lai_ngan_hang", 1), ("chi_khac", 1)):
    want += first(l)[:n_]
want.insert(6, first("hoan_tien")[2]); want += [k for k, v in ans.items() if "that" in v][:1]
t = "<table><tr><th>so_ct</th><th>so_tien</th><th>ma_don</th><th>loai</th><th>muc_chac_chan</th><th>ly_do (agent viết)</th></tr>"
for k in want:
    r = bg[k]; c = {"CAO": "cao", "TRUNG BINH": "tb", "CAN NGUOI QUYET": "cnq"}.get(r["muc_chac_chan"], "")
    ly = r["ly_do"]; ly = ly if len(ly) < 150 else ly[:147] + "…"
    t += f"<tr><td>{E(k)}</td><td class='r'>{vn(r['so_tien'])}</td><td>{E(r['ma_don'])}</td><td>{E(r['loai'])}</td><td class='{c}'>{E(r['muc_chac_chan'])}</td><td>{E(ly)}</td></tr>"
t += "</table>"
shot_html(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style><div class='w' style='width:1300px'><h3>bang_ghep.csv do Claude Code tạo (lần chạy claude-1) — trích {len(want)}/144 dòng</h3><div class='sub'>Dữ liệu giả để học. Đỏ nhạt: CAN NGUOI QUYET; vàng: TRUNG BINH; xanh: CAO.</div>{t}<div class='n'>Trích từ ket-qua/claude-1/bang_ghep.csv, chọn mỗi loại một vài dòng.</div></div>",
         str(ANH / "08-bang-ghep-claude.png"), 1360, ".w")

# 09 bảng chấm
rep = json.load(open(KQ / "bao-cao-cham.json", encoding="utf-8"))
cols = [("claude-1", "Claude Code\nlần có log"), ("agy-2", "agy\nlần có log"), ("lan0-claude", "Claude Code\nlần 0 (không log)"), ("lan0-agy", "agy\nlần 0 (không log)")]
rows_ = [("Dòng sao kê có đáp án xác định: đúng đơn + đúng loại", lambda r: r["tom_tat"]["dong_ro_dung"]),
         ("Dòng mơ hồ: có ghi CAN NGUOI QUYET / đưa vào ngoại lệ", lambda r: r["tom_tat"]["dong_mo_ho_da_bao"]),
         ("Dòng mơ hồ: ghép bừa sai, không báo", lambda r: str(r["tom_tat"]["chac_sai_trong_mo_ho"])),
         ("Ngoại lệ thật bắt được", lambda r: r["tom_tat"]["ngoai_le_bat_duoc"]),
         ("Dòng báo ngoại lệ thừa (đáp án không coi là ngoại lệ)", lambda r: str(r["tom_tat"]["ngoai_le_bao_thua"])),
         ("Đơn CK chưa thu: bắt đủ 10 đơn / liệt kê thừa", lambda r: r["tom_tat"]["don_chua_thu"]),
         ("Tổng kiểm (6 số) đúng", lambda r: r["tom_tat"]["tong_kiem_dung"]),
         ("Mã đơn không có trong sổ (bịa)", lambda r: str(r["tom_tat"]["ma_don_khong_ton_tai"]))]
t = "<table><tr><th>Chỉ số (144 dòng sao kê; 130 xác định, 14 mơ hồ)</th>" + "".join(f"<th>{E(n_).replace(chr(10), '<br>')}</th>" for _, n_ in cols) + "</tr>"
for name, f in rows_: t += f"<tr><td>{E(name)}</td>" + "".join(f"<td class='r'>{E(f(rep[c]))}</td>" for c, _ in cols) + "</tr>"
t += "</table>"
shot_html(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style><div class='w' style='width:1300px'><h3>Kết quả chấm bằng đáp án (ket-qua/cham.py)</h3><div class='sub'>Dữ liệu giả để học. n = 1 lần chạy mỗi agent có log (+ 1 lần 0 không có log): chỉ mô tả quan sát, chưa đo được độ ổn định.</div>{t}<div class='n'>Nguồn: ket-qua/bao-cao-cham.json, chạy ngày 2026-11-20.</div></div>",
         str(ANH / "09-bang-cham.png"), 1360, ".w")

# 10 ca hai agent xử lý khác nhau
cases = ["41577584", "90908337", "53645124", "82598235", "31446908", "66381589"]
bc, ba = {r["so_ct"]: r for r in rd(KQ / "claude-1" / "bang_ghep.csv")}, {r["so_ct"]: r for r in rd(KQ / "agy-2" / "bang_ghep.csv")}
exc, exa = {r["so_ct"] for r in rd(KQ / "claude-1" / "ngoai_le.csv")}, {r["so_ct"] for r in rd(KQ / "agy-2" / "ngoai_le.csv")}
dap = {"41577584": "mơ hồ: gộp COD, cần bảng kê hãng VC", "90908337": "mơ hồ: gộp COD, cần bảng kê hãng VC",
       "53645124": "mơ hồ: 2 khách trùng tên, 2 đơn cùng tiền", "82598235": "mơ hồ: 2 khách trùng tên, 2 đơn cùng tiền",
       "31446908": "mơ hồ: không ghi mã, tổng của 2 đơn cùng khách", "66381589": "rõ: mã + tiền đúng; người chuyển khác tên là bình thường"}
def cell(r, ex, k):
    f = r["muc_chac_chan"] == "CAN NGUOI QUYET" or k in ex
    cls = "ok" if f and ans[k]["muc"] == "mo_ho" else ("mid" if (not f and ans[k]["muc"] == "mo_ho") else ("bad" if f else "ok"))
    return f"<td class='{cls}'>{E(r['loai'])} / {E(r['muc_chac_chan'])}<br>→ {E(r['ma_don'] or '—')}<br>{'đưa vào ngoại lệ' if f else 'không đưa vào ngoại lệ'}</td>"
t = "<table><tr><th>so_ct</th><th>Nội dung sao kê</th><th>Tiền</th><th>Đáp án</th><th>Claude Code (claude-1)</th><th>agy (agy-2)</th></tr>"
for k in cases:
    t += f"<tr><td>{k}</td><td>{E(ans[k]['nd'])}</td><td class='r'>{vn(ans[k]['so_tien'])}</td><td>{E(dap[k])}</td>{cell(bc[k], exc, k)}{cell(ba[k], exa, k)}</tr>"
t += "</table>"
shot_html(f"<!doctype html><meta charset='utf-8'><style>{CSS}</style><div class='w' style='width:1300px'><h3>Những dòng hai agent xử lý khác nhau hoặc chưa đúng ý</h3><div class='sub'>Dữ liệu giả để học. Xanh: xử lý như đáp án mong muốn; vàng: ghép cụ thể nhưng không báo người quyết; đỏ: báo thừa.</div>{t}<div class='n'>Nguồn: ket-qua/claude-1, ket-qua/agy-2, đáp án ket-qua/dap-an.json.</div></div>",
         str(ANH / "10-ca-khac-nhau.png"), 1360, ".w")
print("đã dựng 10 ảnh trong", ANH)
