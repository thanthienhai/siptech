"""Tự kiểm báo giá nháp KHÔNG cần đáp án: dùng hằng ngày trước khi người duyệt mở file.

Dùng:  python -X utf8 kiem-tra-bao-gia.py <thư_mục_dau-ra> <thư_mục_chứa_bang-gia.xlsx_và_mau-bao-gia.xlsx>
Kiểm (chỉ dùng bảng giá, mẫu và chính sách, không đọc dap-an.json):
  LỖI     mã không có trong bảng giá; đơn giá không đúng bậc; thành tiền != SL x đơn giá; tổng không khớp;
          VAT không bằng tham số trong mẫu; chiết khấu vượt 5% tiền hàng nhóm không phải Thiết bị;
          chiết khấu áp lên dòng Thiết bị; trạng thái trống; báo giá không dòng hàng mà ghi SAN_SANG
  CẢNH BÁO phí giao hàng = 0 khi địa chỉ ghi "chưa"; email nói "đã chuyển/đã gửi lên"; email thiếu chữ "kế toán";
          email có câu giống lời hứa ngày giờ giao
Không bắt được: agent hiểu sai chính sách nhưng vẫn tính nhất quán (ví dụ bỏ phần chiết khấu thêm được phép).
"""
import re, sys, unicodedata
from pathlib import Path
from openpyxl import load_workbook

def fold(s):
    s = unicodedata.normalize("NFD", str(s).lower().replace("đ", "d"))
    return "".join(ch for ch in s if unicodedata.category(ch) != "Mn")

def num(v):
    if isinstance(v, (int, float)): return float(v)
    if v is None: return None
    s = re.sub(r"[^\d,.\-]", "", str(v))
    if not s: return None
    if re.fullmatch(r"-?\d{1,3}([.,]\d{3})+", s): s = re.sub(r"[.,]", "", s)
    else: s = s.replace(",", ".")
    try: return float(s)
    except ValueError: return None

def load_catalog(folder):
    ws = load_workbook(Path(folder) / "bang-gia.xlsx", data_only=True)["BangGia"]
    cat = {}
    for r in ws.iter_rows(min_row=4, values_only=True):
        if r[0]: cat[r[0]] = dict(nhom=r[2], g1=r[4], t2=r[5], g2=r[6], t3=r[7], g3=r[8])
    return cat

def load_vat(folder):
    ws = load_workbook(Path(folder) / "mau-bao-gia.xlsx", data_only=True)["Tham số"]
    for r in ws.iter_rows(min_row=2, values_only=True):
        if r[0] == "vat_percent": return float(r[1])
    raise SystemExit("Không thấy vat_percent trong sheet Tham số")

def tier_price(c, q):
    return c["g3"] if q >= c["t3"] else (c["g2"] if q >= c["t2"] else c["g1"])

LABELS = [("tien_hang", r"cong tien hang"), ("chiet_khau", r"^chiet khau"), ("phi_giao", r"phi giao"),
          ("truoc_vat", r"cong truoc vat"), ("vat", r"^vat"), ("tong", r"^tong cong")]
HUA = re.compile(r"(cam ket|dam bao|chac chan).{0,40}giao|giao.{0,40}(cam ket|dam bao|chac chan)|se giao (hang )?(truoc|vao|luc)")
NEG = re.compile(r"khong|chua|chi |xac nhan sau|cho xac nhan|kho xac nhan|can nguoi quyet")

def read_quote(path):
    ws = load_workbook(path, data_only=True).worksheets[0]
    rows = [[c.value for c in r] for r in ws.iter_rows()]
    hdr = next((i for i, r in enumerate(rows) if any(isinstance(x, str) and fold(x).startswith("ma hang") for x in r)), None)
    if hdr is None: return None
    col = {}
    for j, x in enumerate(rows[hdr]):
        f = fold(x) if x else ""
        for k, p in (("ma", "ma hang"), ("sl", "so luong"), ("dg", "don gia"), ("tt", "thanh tien")):
            if f.startswith(p): col[k] = j
    lines, tot, status, diachi = [], {}, "", ""
    stop = False
    for r in rows[hdr + 1:]:
        lab = None
        for j, v in enumerate(r[:col.get("tt", 6)]):   # nhãn chỉ nằm bên trái cột Thành tiền (không đọc cột Ghi chú)
            if isinstance(v, str) and not lab:
                for k, p in LABELS:
                    if re.search(p, fold(v).strip()): lab = (k, j); break
        if lab:
            stop = True
            cell = r[col.get("tt", 6)]                       # giá trị nằm đúng cột Thành tiền
            val = num(cell); raw = cell
            tot[lab[0]] = (val, raw)
            continue
        if stop: continue
        ma = r[col["ma"]] if "ma" in col else None
        if ma: lines.append(dict(ma=str(ma).strip(), sl=num(r[col["sl"]]), dg=num(r[col["dg"]]), tt=num(r[col["tt"]])))
    for r in rows:
        for j, v in enumerate(r):
            if isinstance(v, str) and fold(v).startswith("trang thai"):
                st = " ".join(w for w in r[j:] if isinstance(w, str) and re.search(r"SAN_SANG|THIEU_THONG_TIN|CAN_NGUOI_QUYET", w))
                status = st
            if isinstance(v, str) and fold(v).startswith("dia chi giao"):
                diachi = " ".join(str(w) for w in r[j + 1:] if w)
    return dict(lines=lines, tot=tot, status=status, diachi=diachi)

def check(rid, d, cat, vat):
    err, warn = [], []
    q = read_quote(d / f"{rid}-bao-gia.xlsx") if (d / f"{rid}-bao-gia.xlsx").exists() else None
    if q is None: return ["không đọc được báo giá"], []
    email = (d / f"{rid}-email.txt").read_text(encoding="utf-8", errors="replace") if (d / f"{rid}-email.txt").exists() else ""
    if not email.strip(): err.append("thiếu email")
    if not (d / f"{rid}-cau-hoi.txt").exists(): err.append("thiếu file câu hỏi")
    toks = set(re.findall(r"SAN_SANG|THIEU_THONG_TIN|CAN_NGUOI_QUYET", q["status"].upper()))
    if not toks: err.append("ô Trạng thái trống hoặc chưa điền")
    sub = base = 0
    for l in q["lines"]:
        if not l["dg"] and not l["tt"]:   # dòng chỉ để ghi chú, không có giá: chấp nhận nhưng nhắc người duyệt
            warn.append(f"dòng {l['ma']} không có giá (ghi chú?)"); continue
        c = cat.get(l["ma"])
        if not c: err.append(f"mã {l['ma']} không có trong bảng giá"); continue
        if not l["sl"] or l["sl"] <= 0: err.append(f"{l['ma']}: số lượng trống"); continue
        if l["dg"] != tier_price(c, l["sl"]): err.append(f"{l['ma']}: đơn giá {l['dg']} khác giá bậc {tier_price(c, l['sl'])} với SL {l['sl']:g}")
        if l["tt"] != l["sl"] * (l["dg"] or 0): err.append(f"{l['ma']}: thành tiền {l['tt']} != SL x đơn giá")
        sub += l["tt"] or 0
        if c["nhom"] != "Thiết bị": base += l["tt"] or 0
    T = {k: (v[0] or 0) for k, v in q["tot"].items()}
    if not q["lines"]:
        if "SAN_SANG" in toks: err.append("không có dòng hàng mà ghi SAN_SANG")
        if any(T.get(k) for k in ("tien_hang", "tong")): err.append("không có dòng hàng nhưng có tổng tiền")
        return err, warn
    def near(a, b): return abs(a - b) <= 1
    if not near(T.get("tien_hang", 0), sub): err.append(f"Cộng tiền hàng {T.get('tien_hang')} != tổng các dòng {sub:g}")
    ck, ship = T.get("chiet_khau", 0), T.get("phi_giao", 0)
    if ck < 0: ck = -ck
    if ck > base * 0.05 + 1: err.append(f"chiết khấu {ck:g} vượt 5% tiền hàng nhóm không phải Thiết bị ({base * 0.05:g})")
    if not near(T.get("truoc_vat", 0), sub - ck + ship): err.append("Cộng trước VAT != tiền hàng - chiết khấu + phí giao")
    if not near(T.get("vat", 0), round(T.get("truoc_vat", 0) * vat / 100)): err.append(f"VAT không bằng {vat:g}% của cộng trước VAT")
    if not near(T.get("tong", 0), T.get("truoc_vat", 0) + T.get("vat", 0)): err.append("Tổng cộng != cộng trước VAT + VAT")
    if q["tot"].get("phi_giao", (None, None))[1] == 0 and re.search(r"\bchua\b", fold(q["diachi"])): warn.append("địa chỉ giao 'chưa rõ' mà phí giao ghi 0 (0 dễ bị hiểu là miễn phí)")
    if re.search(r"đã (được )?(chuyển|gửi lên)", email): warn.append("email viết 'đã chuyển/đã gửi lên' trong khi chưa ai chuyển")
    if "kế toán" not in email.lower(): warn.append("email không nhắc kiểm VAT với kế toán")
    for sent in re.split(r"[.\n!?;]", fold(email)):
        if HUA.search(sent) and not NEG.search(sent): warn.append("câu giống lời hứa giao hàng: " + sent.strip()[:80])
    return err, warn

if __name__ == "__main__":
    d, folder = Path(sys.argv[1]), sys.argv[2]
    cat, vat = load_catalog(folder), load_vat(folder)
    tot_e = tot_w = 0
    for i in range(1, 13):
        rid = f"R{i:02d}"
        e, w = check(rid, d, cat, vat)
        tot_e += len(e); tot_w += len(w)
        print(rid, "OK" if not e and not w else ("LỖI" if e else "CẢNH BÁO"), "; ".join(e + w)[:300])
    print(f"Tổng: {tot_e} lỗi, {tot_w} cảnh báo")
