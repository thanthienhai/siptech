# BÁO CÁO KIỂM TRA DỮ LIỆU CHẤM CÔNG THÁNG 09/2026

**Người thực hiện:** Trợ lý kiểm tra bảng chấm công  
**Kỳ chấm công:** 01/09/2026 – 30/09/2026 (30 ngày)  
**Phạm vi:** 25 nhân viên (15 nhân viên Chi nhánh A, 10 nhân viên Chi nhánh B; 16 nhân viên ca Hành chính, 9 nhân viên ca Xoay).

---

## 1. Số liệu tóm tắt toàn công ty

- **Tổng số nhân viên theo dõi:** 25 nhân viên (`nhan_vien.csv`).
- **Tổng số ngày - nhân viên:** 750 ngày công danh nghĩa (25 nhân viên × 30 ngày).
- **Phân bổ trạng thái ngày công:**
  - `OK` (Đã tính đủ giờ công): **501 ngày** (tổng cộng **3.985,83 giờ công** chuẩn).
  - `NGHI` (Ngày nghỉ cuối tuần, nghỉ ca xoay, nghỉ lễ hợp lệ không phát sinh quẹt): **207 ngày**.
  - `PHEP` (Nghỉ phép/nghỉ ốm đã duyệt, không phát sinh quẹt thẻ): **12 ngày**.
  - `CHO_XAC_NHAN` (Cần quản lý xác nhận trước khi tính lương): **30 ngày**.
- **Tổng số trường hợp bất thường phát hiện:** **61 trường hợp** (thuộc 14 nhóm mã bất thường).
  - Không cần quản lý quyết định (hệ thống tự động xử lý theo quy định): **24 trường hợp** (12 `DI_TRE`, 6 `VE_SOM`, 6 `QUET_TRUNG`).
  - Cần quản lý xác nhận (`can_nguoi_quyet = CO`): **37 trường hợp**.

---

## 2. Danh sách các việc quản lý cần xác nhận (Gom theo nhóm)

### Nhóm 1: Quẹt thẻ đơn lẻ – Thiếu giờ vào hoặc giờ ra (11 trường hợp)
*Nhân viên chỉ quẹt 1 lần trong ngày, chưa đủ cặp vào/ra để tính giờ công tự động.*
- **Thiếu quẹt ra (`THIEU_RA` - 5 ca):** NV-011 (14/09 ca C), NV-013 (05/09 ca C), NV-025 (28/09 ca HC), NV-026 (10/09, 25/09 ca HC).
  - *Việc cần làm:* Quản lý xác nhận giờ rời ca thực tế của nhân viên để hoàn thiện giờ công.
- **Thiếu quẹt vào (`THIEU_VAO` - 3 ca):** NV-011 (24/09 ca S), NV-013 (13/09 ca S), NV-021 (10/09 ca HC).
  - *Việc cần làm:* Quản lý xác nhận giờ đến làm việc thực tế của nhân viên.
- **Quẹt giữa ca không rõ chiều (`THIEU_KHONG_RO` - 3 ca):** NV-013 (06/09 lúc 18:12), NV-023 (30/09 lúc 13:21), NV-025 (11/09 lúc 13:21).
  - *Việc cần làm:* Quản lý đối chiếu lịch trình thực tế, xác nhận cả giờ đến và giờ về trong ngày.

### Nhóm 2: Vắng mặt trong ca làm việc chưa có đơn nghỉ phép (`VANG_CHUA_GHI` - 6 trường hợp)
- **Danh sách:** NV-002 (22/09 ca C), NV-003 (28/09 ca S), NV-010 (21/09 ca HC), NV-023 (11/09 ca HC), NV-024 (21/09 ca HC), NV-026 (24/09 ca HC).
- *Việc cần làm:* Kiểm tra lý do vắng mặt, hướng dẫn nhân viên nộp bổ sung đơn phép nếu hợp lệ hoặc xác nhận ngày nghỉ không hưởng lương.

### Nhóm 3: Có đơn nghỉ phép đã duyệt nhưng vẫn phát sinh quẹt thẻ (`CO_PHEP_NHUNG_QUET` - 2 trường hợp)
- **Danh sách:** NV-010 (23/09 quẹt 07:41 – 17:24), NV-023 (23/09 quẹt 07:42 – 17:16).
- *Việc cần làm:* Xác nhận nhân viên thực tế có đi làm trọn vẹn cả ngày hay không; nếu đi làm thì hủy đơn nghỉ phép để tính ngày công, nếu không thì giữ nguyên trạng thái phép. Quy định nghỉ phép cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.

### Nhóm 4: Phát sinh quẹt thẻ làm việc ngày nghỉ và ngày lễ (7 trường hợp)
- **Làm việc ngày lễ (`LAM_NGAY_LE` - 3 ca):** NV-007 (01/09 quẹt 08:00 – 16:41), NV-010 (02/09 quẹt 08:06 – 16:42), NV-018 (02/09 quẹt 07:58 – 17:09).
- **Làm việc ngày nghỉ/cuối tuần (`LAM_NGAY_NGHI` - 4 ca):** NV-013 (12/09 ca xoay OFF), NV-014 (24/09 ca xoay OFF), NV-016 (12/09 T7 ca HC), NV-022 (27/09 CN ca HC).
- *Việc cần làm:* Xác nhận việc huy động nhân sự làm thêm ngoài lịch ca/ngày lễ để làm căn cứ tính đãi ngộ; chế độ làm ngày nghỉ, ngày lễ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.

### Nhóm 5: Dấu hiệu quẹt thẻ tại 2 máy khác chi nhánh trong thời gian ngắn (`NGHI_QUET_HO` - 4 trường hợp)
- **Danh sách:**
  - NV-015 (20/09): quẹt MAY-B1 lúc 05:54 và MAY-A1 lúc 06:01 (cách nhau 7 phút).
  - NV-009 (23/09): quẹt MAY-A1 lúc 07:59 và MAY-B1 lúc 08:05 (cách nhau 6 phút).
  - NV-022 (24/09): quẹt MAY-A1 lúc 07:52 và MAY-B1 lúc 07:54 (cách nhau 2 phút).
  - NV-016 (24/09): quẹt MAY-A1 lúc 07:56 và MAY-B1 lúc 08:04 (cách nhau 8 phút).
- *Việc cần làm:* Đề nghị người có thẩm quyền xác minh sự có mặt thực tế của nhân sự, rà soát camera hoặc thẻ chấm công; không tự ý kết luận nhân viên gian lận hay quẹt hộ.

### Nhóm 6: Làm thêm giờ vượt ngưỡng cảnh báo (4 trường hợp)
- **Vượt ngưỡng ngày > 180 phút (`OT_VUOT_NGUONG` - 3 ca):** NV-001 (16/09: 191 phút), NV-004 (23/09: 201 phút), NV-010 (28/09: 227 phút).
- **Vượt ngưỡng tháng > 2.400 phút / 40 giờ (`OT_THANG_VUOT` - 1 ca):** NV-001 đạt 2.697 phút làm thêm thường (44,95 giờ). *(Lưu ý: NV-004 cũng đạt mức cao: 2.171 phút / 36,18 giờ).*
- *Việc cần làm:* Quản lý xác nhận phê duyệt thời gian làm thêm giờ; quy định làm thêm giờ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.

### Nhóm 7: Bản ghi dữ liệu lỗi thiết bị chấm công (`DU_LIEU_LOI` - 3 trường hợp)
- **Mã nhân viên lạ:** NV-005 phát sinh quẹt lúc 09:20 ngày 11/09 tại MAY-A1 (không có trong `nhan_vien.csv`).
- **Thời gian bị trống:** NV-007 có 1 bản ghi thời gian `NaN` tại MAY-A1 (dòng 296).
- **Thời gian không hợp lệ:** NV-023 có bản ghi ghi nhận `31/09/2026 08:00` tại MAY-B1 (dòng 895, tháng 9 chỉ có 30 ngày).
- *Việc cần làm:* Yêu cầu bộ phận IT kiểm tra phần mềm kết nối máy chấm công, pin CMOS hoặc bộ nhớ đệm máy quẹt; kiểm tra hồ sơ xem NV-005 có phải nhân sự mới/thử việc chưa khai báo.

---

## 3. Các giả định kỹ thuật đã áp dụng

1. **Chuẩn hóa thời gian:** Toàn bộ so sánh giờ bỏ phần giây (08:05:59 tính là 08:05).
2. **Khử trùng quẹt (`QUET_TRUNG`):** Các lượt quẹt liên tiếp trên cùng một máy cách nhau $\le 3$ phút được giữ lượt đầu tiên, loại bỏ lượt sau và không tính là lỗi của nhân viên.
3. **Cơ chế tính giờ công:** Chỉ tính thời gian nằm trong khung ca quy định; nếu vào/ra trong dung sai 5 phút thì mốc tính tính từ giờ vào/ra chuẩn của ca. Ca HC tự động trừ 60 phút nghỉ trưa (12:00–13:00). Các quẹt giữa giờ (ăn trưa) được bỏ qua hợp lệ.
4. **Phân định ngày nghỉ và ngày phép:**
   - Ngày 01/09 và 02/09 là ngày nghỉ lễ chung (LE) cho toàn bộ nhân sự.
   - Đối với đơn nghỉ phép dài ngày bao trùm ngày nghỉ cuối tuần (OFF của ca HC như NV-009 từ 03/09–07/09) hoặc ngày nghỉ ca xoay (NV-020 ngày 30/09): Ngày OFF được giữ đúng bản chất là ngày nghỉ định kỳ (`NGHI`), chỉ các ngày làm việc thực tế nằm trong đơn mới tính trạng thái `PHEP`.
5. **Thống kê bảng tổng hợp:** Cột `so_ngay_cho_xac_nhan` phản ánh chính xác số ngày mang trạng thái `CHO_XAC_NHAN` trong tháng. Cột `so_ngay_vang_chua_ghi` thống kê riêng số lượt vắng mặt không phép để quản lý nắm bắt trọng điểm.

---

## 4. Các điểm chưa chắc chắn và khuyến nghị quản lý

1. **Chế độ nghỉ ốm kéo dài qua ngày nghỉ tuần:** Trường hợp NV-009 có giấy nghỉ ốm từ 03/09 đến 07/09 (gồm cả T7, CN 05-06/09): Cách ghi nhận chế độ BHXH đối với ngày nghỉ tuần cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.
2. **Chế độ thù lao làm thêm giờ và làm ngày lễ:** Các trường hợp làm việc ngày 01-02/09 (NV-007, NV-010, NV-018) và các ca OT cao (NV-001, NV-004): Việc áp dụng hệ số trả lương hay bố trí nghỉ bù cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.
3. **Trường hợp di chuyển giữa 2 chi nhánh:** NV-012 (ngày 22/09) và NV-025 (ngày 29/09) có lượt quẹt vào đầu ca ở một chi nhánh và quẹt ra cuối ca ở chi nhánh khác (cách nhau $>9$ tiếng). Chương trình ghi nhận hợp lệ vì không vi phạm ngưỡng 10 phút, nhưng quản lý nên xác nhận xem công ty có điều chuyển công tác trong ngày không.
