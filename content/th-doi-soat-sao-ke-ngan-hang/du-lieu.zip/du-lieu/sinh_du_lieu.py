"""Sinh dữ liệu GIẢ để học: sao kê ngân hàng tháng 10/2026 + sổ đơn hàng + đáp án.

Chạy:  python -X utf8 sinh_du_lieu.py
Ra:    sao-ke-t10-2026.csv, so-don-hang-t10-2026.xlsx   (đưa cho agent)
       ../ket-qua/dap-an.json                            (ĐÁP ÁN, không đưa cho agent)
Hạt giống cố định (20261120) nên chạy lại ra đúng bản cũ.
100% là dữ liệu bịa: tên người ghép ngẫu nhiên từ họ/đệm/tên phổ biến, SĐT dãy 0900000xxx,
số tài khoản 0000123456789, công ty và nhà cung cấp là tên giả. Không phải dữ liệu của doanh nghiệp nào.
Cột của sao kê mô phỏng các cột phổ biến của sao kê ngân hàng VN (ngày, số chứng từ, ghi nợ, ghi có, số dư, nội dung);
chỉ là tham chiếu định dạng, không chép sao kê thật của ngân hàng nào.
"""
import csv, json, random, sys, unicodedata
from datetime import date, timedelta
from pathlib import Path

# Dùng:  python -X utf8 sinh_du_lieu.py                      -> bản gốc (hạt giống 20261120), ghi cạnh script
#        python -X utf8 sinh_du_lieu.py 20261121 thu_muc_ra   -> bản khác để kiểm tái lập, ghi vào thu_muc_ra/
SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 20261120
HERE = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).parent
HERE.mkdir(parents=True, exist_ok=True)
OUT_ANSWER = (HERE / "dap-an.json") if len(sys.argv) > 2 else (HERE.parent / "ket-qua" / "dap-an.json")
rng = random.Random(SEED)

def unaccent(s):
    s = s.replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")

def vnd(n): return f"{n:,}"           # 1,250,000  (kiểu số của sao kê)
def vnd_dot(n): return f"{n:,}".replace(",", ".")

# ---------------- khách hàng ----------------
HO = ["Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Vũ", "Đặng", "Bùi", "Đỗ", "Ngô", "Dương", "Lý"]
MALE = ["An", "Bình", "Dũng", "Hùng", "Nam", "Phúc", "Quân", "Tú", "Long", "Khánh", "Hải", "Sơn", "Việt", "Đạt"]
FEMALE = ["Chi", "Hà", "Hoa", "Lan", "Linh", "Mai", "Thảo", "Trang", "Vy", "Yến", "Ngân", "Nhung", "Phương", "Quỳnh"]
MID_M = ["Văn", "Hữu", "Minh", "Quốc"]
MID_F = ["Thị", "Ngọc", "Thanh", "Kim"]

def make_customers(n):
    seen_full, seen_hg, seen_ini, out = set(), set(), set(), []
    while len(out) < n:
        ho = rng.choice(HO)
        if rng.random() < 0.5: mid, giv = rng.choice(MID_M), rng.choice(MALE)
        else: mid, giv = rng.choice(MID_F), rng.choice(FEMALE)
        full = f"{ho} {mid} {giv}"
        k_hg = (unaccent(ho), unaccent(giv)); k_ini = (unaccent(ho)[0], unaccent(mid)[0], unaccent(giv))
        if full in seen_full or k_hg in seen_hg or k_ini in seen_ini: continue
        seen_full.add(full); seen_hg.add(k_hg); seen_ini.add(k_ini)
        out.append({"ten": full, "ho": ho, "mid": mid, "giv": giv})
    for i, c in enumerate(out):
        c["sdt"] = f"0900000{(i * 7 + 11) % 1000:03d}"
    return out

customers = make_customers(78)
# cặp trùng tên (bẫy mơ hồ): hai người khác nhau, cùng tên đầy đủ, khác SĐT
twin_name = "Trần Văn Bình"
for c in customers:   # không để ai khác trùng (ho, giv) với cặp này
    if unaccent(c["ho"]) == "Tran" and unaccent(c["giv"]) == "Binh": c["giv"] = "Bảo"; c["ten"] = f'{c["ho"]} {c["mid"]} Bảo'
twin_a = {"ten": twin_name, "ho": "Trần", "mid": "Văn", "giv": "Bình", "sdt": "0900000901"}
twin_b = {"ten": twin_name, "ho": "Trần", "mid": "Văn", "giv": "Bình", "sdt": "0900000902"}
customers += [twin_a, twin_b]

PRODUCTS = [("Nồi chiên không dầu 5L", 1290000), ("Bộ nồi inox 3 món", 890000), ("Máy xay sinh tố mini", 450000),
            ("Ấm siêu tốc 1.8L", 250000), ("Bình giữ nhiệt 750ml", 180000), ("Bộ dao nhà bếp 6 món", 350000),
            ("Chảo chống dính 26cm", 220000), ("Hộp cơm điện cắm", 390000), ("Quạt mini để bàn", 150000),
            ("Máy ép chậm", 1650000), ("Bộ hộp thực phẩm 10 cái", 280000), ("Lò vi sóng 20L", 1850000),
            ("Cân nhà bếp điện tử", 120000), ("Nồi áp suất 6L", 760000)]

N = 128
# ngày đặt: tăng dần từ 01/10 đến 31/10
days = sorted(rng.randint(1, 31) for _ in range(N)); days[-1] = 31; days[0] = 1
orders = []
for i in range(1, N + 1):
    prod, price = rng.choice(PRODUCTS); qty = rng.choice([1, 1, 1, 2, 2, 3])
    ship = rng.choice([0, 0, 20000, 30000])
    orders.append({"i": i, "ma": f"DH2610-{i:03d}", "ngay": date(2026, 10, days[i - 1]), "kh": rng.choice(customers[:78]),
                   "sp": prod, "sl": qty, "tien_hang": price * qty, "ship": ship, "tt": "CK", "trang_thai": "Đã giao", "ghi_chu": ""})
for o in orders: o["tong"] = o["tien_hang"] + o["ship"]
by_ma = {o["ma"]: o for o in orders}

idx_all = list(range(N))
# COD: 20 đơn (không nằm trong 14 đơn cuối)
cod_idx = sorted(rng.sample(range(0, 112), 20))
for k in cod_idx: orders[k]["tt"] = "COD"
ck_idx = [k for k in idx_all if k not in cod_idx]
unpaid_late = ck_idx[-8:]
rest = ck_idx[:-8]
unpaid_old = rng.sample(rest[:70], 2); rest = [k for k in rest if k not in unpaid_old]
cancelled = rng.sample(rest[:80], 3); rest = [k for k in rest if k not in cancelled]
for k in unpaid_late: orders[k]["trang_thai"] = "Đang giao"
for k in cancelled: orders[k]["trang_thai"] = "Hủy"; orders[k]["ghi_chu"] = "khách hủy trước khi chuyển khoản"
for k in cod_idx:
    if orders[k]["ngay"] >= date(2026, 10, 27): orders[k]["trang_thai"] = "Đang giao"

pool = rest[:]; rng.shuffle(pool)
def take(n):
    global pool
    got, pool = pool[:n], pool[n:]
    return got
# đưa 2 cặp khách sinh đôi vào đơn
twin_idx = take(2)
for k, tw in zip(twin_idx, (twin_a, twin_b)):
    o = orders[k]; o["kh"] = tw; o["sp"], o["sl"], o["tien_hang"], o["ship"] = "Bộ nồi inox 3 món", 1, 890000, 30000; o["tong"] = 920000
h_groups = [take(s) for s in (3, 3, 3, 3, 2)]
for g in h_groups:               # cùng một khách trả nhiều đơn
    kh = orders[g[0]]["kh"]
    for k in g: orders[k]["kh"] = kh
sum2 = take(2)
kh = orders[sum2[0]]["kh"]
for k in sum2: orders[k]["kh"] = kh
cats = {"A": take(42), "B": take(14), "C": take(10), "D": take(3), "E": take(4), "F": take(4)}
assert not pool, len(pool)
# khách của đơn C phải có tên không nhập nhằng (đã đảm bảo duy nhất theo (họ,tên) và viết tắt)
used_names_elsewhere = {}
# làm trống các đơn COD/đơn chưa thu khỏi khách trùng sinh đôi
for o in orders:
    if o["kh"] in (twin_a, twin_b) and o["i"] - 1 not in twin_idx: o["kh"] = rng.choice(customers[:78])

# ---------------- chọn đơn đặc biệt trong nhóm A ----------------
A = cats["A"][:]
refund_idx = A[:3]; dbl_idx = A[3:6]; wrong_target = A[6:9]
A_plain = A[9:]
ship_orders = [k for k in A if orders[k]["ship"] > 0]
# refund: 2 hoàn đủ + 1 hoàn một phần (trừ phí ship) -> cần đơn có ship cho ca một phần
partial = next(k for k in ship_orders if k not in dbl_idx and k not in wrong_target)
refund_idx = [k for k in refund_idx if k != partial][:2] + [partial]
dbl_idx = [k for k in A if k not in refund_idx][:3]
wrong_target = [k for k in A if k not in refund_idx and k not in dbl_idx][:3]
for k in refund_idx: orders[k]["trang_thai"] = "Hoàn tiền"
# đơn D: mã trong nội dung chỉ sang đơn khác (khác số tiền)
for k, tgt in zip(cats["D"], wrong_target):
    assert orders[k]["tong"] != orders[tgt]["tong"] or True
d_pairs = []
for k in cats["D"]:
    for t in wrong_target:
        if orders[t]["tong"] != orders[k]["tong"] and t not in [p[1] for p in d_pairs] and orders[t]["kh"] is not orders[k]["kh"]:
            d_pairs.append((k, t)); break
assert len(d_pairs) == 3

# ---------------- dòng sao kê ----------------
lines = []   # mỗi dòng: dict(ngay, no, co, nd, truth)
def add(ngay, co, no, nd, **truth):
    lines.append({"ngay": ngay, "co": co, "no": no, "nd": nd, "truth": truth})

def lag_day(o, lo=0, hi=3):
    d = o["ngay"] + timedelta(days=rng.randint(lo, hi))
    return min(d, date(2026, 10, 31))

def code_clean(o):
    return o["ma"]
def code_variant(o):
    n = o["i"]; m = o["ma"]
    return rng.choice([f"DH 2610 {n:03d}", f"DH2610{n:03d}", f"dh2610-{n}", f"DH-2610-{n:03d}", f"don {n:03d}", f"DH261O-{n:03d}",
                       f"DH2610-O{n % 100:02d}" if n >= 10 and n < 100 else f"dh2610 {n:03d}", f"don hang so {n}"])
def payer(o, other=False):
    if other and rng.random() < 0.5:
        c = rng.choice(customers[:78]); return unaccent(c["ten"]).upper()
    return unaccent(o["kh"]["ten"]).upper()
def abbr(o):
    c = o["kh"]; ho, mid, giv = (unaccent(c[x]).upper() for x in ("ho", "mid", "giv"))
    return rng.choice([f"{ho} {mid} {giv}", f"{ho} {mid[0]} {giv}", f"{ho[0]} {mid[0]} {giv}", f"{ho} {giv}", f"{giv} {ho}".replace(f"{giv} {ho}", f"{ho} {giv}")])

def tmpl_clean(o):
    return rng.choice([f"{payer(o)} CK {o['ma']}", f"{o['ma']} {payer(o)}", f"{payer(o)} chuyen tien {o['ma']}", f"TT {o['ma']} {payer(o).title()}",
                       f"{o['ma']} thanh toan don hang", f"{payer(o)} thanh toan {o['ma']}"])
def tmpl_variant(o):
    c = code_variant(o); name = payer(o, other=True)
    return rng.choice([f"{name} CK {c}", f"{c} {name}", f"{name.lower()} thanh toan {c}", f"CK {c}", f"{c} ck"])

def pay_line(o, nd, amount=None, **truth):
    add(lag_day(o), amount or o["tong"], 0, nd, **truth)

for k in A_plain + refund_idx + dbl_idx + wrong_target:
    o = orders[k]
    pay_line(o, tmpl_clean(o), loai="khop_du", orders=[o["ma"]], muc="ro", ngoai_le=False, ghi_chu="mã đơn đúng, tiền đủ")
for k in cats["B"]:
    o = orders[k]
    pay_line(o, tmpl_variant(o), loai="khop_du", orders=[o["ma"]], muc="ro", ngoai_le=False, ghi_chu="mã đơn viết sai/biến thể (khoảng trắng, chữ O thay số 0, thiếu số 0...), tiền đủ")
for k in cats["C"]:
    o = orders[k]
    pay_line(o, rng.choice([f"{abbr(o)} CK", f"{abbr(o)} chuyen tien mua hang", f"{abbr(o)} thanh toan", f"CK mua hang {abbr(o)}"]),
             loai="khop_du", orders=[o["ma"]], muc="ro", ngoai_le=False, ghi_chu="không có mã đơn; khớp theo tên (không dấu/viết tắt, duy nhất) + đúng số tiền")
for k, t in d_pairs:
    o, tg = orders[k], orders[t]
    nm = payer(o)
    pay_line(o, f"{nm} CK {tg['ma']}", loai="khop_du", orders=[o["ma"]], muc="mo_ho", ngoai_le=True,
             ghi_chu=f"nội dung ghi mã {tg['ma']} (đơn của khách khác, khác số tiền); tên và số tiền khớp {o['ma']}")
for k in cats["E"]:
    o = orders[k]; delta = rng.choice([20000, 30000, 50000, 100000]); delta = min(delta, o["tong"] - 10000)
    pay_line(o, tmpl_clean(o), amount=o["tong"] - delta, loai="thieu", orders=[o["ma"]], muc="ro", ngoai_le=True, thieu=delta,
             ghi_chu=f"chuyển thiếu {delta}")
for k in cats["F"]:
    o = orders[k]; delta = rng.choice([10000, 20000, 50000, 100000, 200000])
    pay_line(o, tmpl_clean(o), amount=o["tong"] + delta, loai="thua", orders=[o["ma"]], muc="ro", ngoai_le=True, thua=delta,
             ghi_chu=f"chuyển thừa {delta}")
# chuyển hai lần
first_by_ma = {}
for ln in lines:
    for m in ln["truth"].get("orders", []): first_by_ma.setdefault(m, ln)
for k in dbl_idx:
    o = orders[k]; f = first_by_ma[o["ma"]]
    d2 = min(f["ngay"] + timedelta(days=rng.randint(1, 4)), date(2026, 10, 31))
    add(d2, o["tong"], 0, rng.choice([f"{payer(o)} CK LAI {o['ma']}", f"{o['ma']} {payer(o)}", f"{payer(o)} chuyen tien {o['ma']}"]),
        loai="trung", orders=[o["ma"]], muc="ro", ngoai_le=True, ghi_chu="chuyển lần hai, cùng số tiền, đơn đã được trả đủ ở dòng trước")
# hoàn tiền (ghi nợ)
for n_, k in enumerate(refund_idx):
    o = orders[k]; f = first_by_ma[o["ma"]]
    d = f["ngay"] + timedelta(days=rng.randint(3, 6))
    if d > date(2026, 10, 31): d = date(2026, 10, 31)
    full = n_ < 2; amt = o["tong"] if full else o["tong"] - o["ship"]
    nd = [f"HOAN TIEN {o['ma']} KHACH HUY", f"hoan tien {code_variant(o)} cho {payer(o).title()}", f"HOAN TIEN {o['ma']} TRU PHI SHIP"][n_]
    add(d, 0, amt, nd, loai="hoan_tien", orders=[o["ma"]], muc="ro", ngoai_le=(not full),
        ghi_chu="hoàn đủ" if full else f"hoàn một phần (trừ phí ship {o['ship']}), người duyệt xác nhận")
# trả nhiều đơn một lần
h_styles = [lambda g: "DH2610-" + " ".join(f"{orders[k]['i']:03d}" for k in g),
            lambda g: "TT " + ", ".join(orders[k]["ma"] for k in g),
            lambda g: f"TT {len(g)} don " + " ".join(f"{orders[k]['i']:03d}" for k in g),
            lambda g: " ".join(orders[k]["ma"] for k in g) + " " + payer(orders[g[0]]),
            lambda g: payer(orders[g[0]]) + " CK " + " va ".join(f"DH2610{orders[k]['i']:03d}" for k in g)]
for g, st in zip(h_groups, h_styles):
    amt = sum(orders[k]["tong"] for k in g)
    d = max(lag_day(orders[k], 0, 3) for k in g)
    add(d, amt, 0, st(g), loai="nhieu_don", orders=[orders[k]["ma"] for k in g], muc="ro", ngoai_le=False,
        phan_bo={orders[k]["ma"]: orders[k]["tong"] for k in g}, ghi_chu="một lần chuyển trả nhiều đơn, mã đơn nằm trong nội dung")
# trả hai đơn không ghi mã (mơ hồ)
o1, o2 = orders[sum2[0]], orders[sum2[1]]
add(max(lag_day(o1), lag_day(o2)), o1["tong"] + o2["tong"], 0, f"{abbr(o1)} CK 2 don",
    loai="nhieu_don", orders=[o1["ma"], o2["ma"]], muc="mo_ho", ngoai_le=True,
    phan_bo={o1["ma"]: o1["tong"], o2["ma"]: o2["tong"]}, ghi_chu="không ghi mã đơn; tổng bằng hai đơn của cùng khách, cần người xác nhận")
# hai khách trùng tên, cùng số tiền, cùng chỉ ghi tên
for k in twin_idx:
    o = orders[k]
    add(lag_day(o, 0, 2), o["tong"], 0, rng.choice(["TRAN VAN BINH CK", "TRAN VAN BINH chuyen tien mua hang"]), loai="khop_du",
        orders=[orders[x]["ma"] for x in twin_idx], muc="mo_ho", ngoai_le=True, that=o["ma"],
        ghi_chu="hai khách khác nhau cùng tên Trần Văn Bình, hai đơn cùng số tiền; không biết dòng nào của đơn nào")
# COD gộp: hãng vận chuyển trả gộp
cod_delivered = [k for k in cod_idx if orders[k]["trang_thai"] == "Đã giao"]
b1, b2 = cod_delivered[:5], cod_delivered[5:11]
for n_, (grp, ds) in enumerate(((b1, "DOT 1"), (b2, "DOT 2"))):
    d = max(orders[k]["ngay"] for k in grp) + timedelta(days=rng.randint(3, 6)); d = min(d, date(2026, 10, 31))
    add(d, sum(orders[k]["tong"] for k in grp), 0, f"DV VAN CHUYEN XANH DOI SOAT COD {ds} T10", loai="cod_gop",
        orders=[orders[k]["ma"] for k in grp], muc="mo_ho", ngoai_le=True,
        ghi_chu="hãng vận chuyển trả gộp tiền thu hộ COD, không ghi mã đơn; tổng bằng tổng các đơn COD đã giao đã liệt kê")
cod_after = [orders[k]["ma"] for k in cod_idx if k not in b1 + b2]
# tiền không rõ nguồn
late_unpaid_total = orders[unpaid_late[0]]["tong"]
unk = [("CHUYEN KHOAN", 700000), ("TRA TIEN", 1530000), ("PHAM QUOC TOAN CK", 2440000), ("TT HD 0087", 3200000),
       ("MUA HANG ZALO", late_unpaid_total), ("LE TRUNG KIEN gui tien", 980000)]
for nd, amt in unk:
    add(date(2026, 10, rng.randint(2, 29)), amt, 0, nd, loai="khong_ro_nguon", orders=[], muc="mo_ho", ngoai_le=True,
        ghi_chu="không có mã đơn, tên không có trong sổ đơn" + ("; số tiền trùng đơn chưa thu " + orders[unpaid_late[0]]["ma"] + " nhưng không có bằng chứng khác" if amt == late_unpaid_total and nd == "MUA HANG ZALO" else ""))
# phí và lãi ngân hàng
add(date(2026, 10, 5), 0, 11000, "PHI SMS BANKING T10", loai="phi_lai_ngan_hang", orders=[], muc="ro", ngoai_le=False, ghi_chu="phí ngân hàng")
add(date(2026, 10, 20), 0, 55000, "PHI DUY TRI TAI KHOAN QUY 4", loai="phi_lai_ngan_hang", orders=[], muc="ro", ngoai_le=False, ghi_chu="phí ngân hàng")
add(date(2026, 10, 27), 0, 22000, "PHI CHUYEN KHOAN LIEN NGAN HANG", loai="phi_lai_ngan_hang", orders=[], muc="ro", ngoai_le=False, ghi_chu="phí ngân hàng")
add(date(2026, 10, 31), 18650, 0, "LAI TIEN GUI KY HAN KHONG KY HAN T10", loai="phi_lai_ngan_hang", orders=[], muc="ro", ngoai_le=False, ghi_chu="lãi tiền gửi")
# chi khác (ghi nợ không liên quan đơn)
chi = [("THANH TOAN TIEN HANG CTY NCC DEMO 01", (3, 9)), ("THANH TOAN TIEN HANG CTY NCC DEMO 02", (3, 9)), ("TIEN DIEN T9", (1, 2)),
       ("TIEN INTERNET FTTH T10", (1, 1)), ("TIEN THUE MAT BANG T10", (8, 8)), ("NAP TIEN QUANG CAO MXH", (1, 4)),
       ("MUA VAN PHONG PHAM", (1, 1)), ("DONG BHXH T9", (2, 3)), ("DONG GOI BAO BI CTY BAO BI DEMO", (1, 3))]
for nm in ["TRAN THI NHAN VIEN A", "LE VAN NHAN VIEN B", "PHAM THI NHAN VIEN C", "HOANG VAN NHAN VIEN D"]: chi.append((f"LUONG T9 {nm}", (4, 6)))
for _ in range(28): chi.append((rng.choice(["MUA THUNG CARTON", "TIEN SHIP NOI THANH", "GUI HANG TRA NHA XE", "TIEN XANG GIAO HANG", "PHI SAN TMDT T10", "MUA BANG DINH"]), (0.2, 1.2)))
for nd, (lo, hi) in chi:
    amt = int(rng.uniform(lo, hi) * 1_000_000 // 1000 * 1000)
    add(date(2026, 10, rng.randint(1, 31)), 0, amt, nd, loai="chi_khac", orders=[], muc="ro", ngoai_le=False, ghi_chu="chi không liên quan đến đơn hàng")

# kiểm: đơn nhóm C (chỉ tên + tiền) phải duy nhất theo (khách, số tiền) trong các đơn CK còn hiệu lực
for k in cats["C"]:
    o = orders[k]
    same = [x for x in orders if x["kh"] is o["kh"] and x["tt"] == "CK" and x["trang_thai"] != "Hủy" and x["tong"] == o["tong"]]
    assert len(same) == 1, ("C mơ hồ", o["ma"], [x["ma"] for x in same])

# ---------------- sắp xếp, số dư, số chứng từ ----------------
lines.sort(key=lambda l: (l["ngay"], rng.random()))
opening = 40_000_000
bal = opening
used = set()
for ln in lines:
    while True:
        so_ct = f"{rng.randint(10_000_000, 99_999_999)}"
        if so_ct not in used: used.add(so_ct); break
    ln["so_ct"] = so_ct; bal += ln["co"] - ln["no"]; ln["du"] = bal
assert min(l["du"] for l in lines) > 0, "số dư âm"
closing = bal
tot_co = sum(l["co"] for l in lines); tot_no = sum(l["no"] for l in lines)

with open(HERE / "sao-ke-t10-2026.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["SAO KE TAI KHOAN (DU LIEU GIA DE HOC)"])
    w.writerow(["Chu tai khoan", "CONG TY TNHH MOCHI DEMO"]); w.writerow(["So tai khoan", "0000123456789"])
    w.writerow(["Tu ngay", "01/10/2026"]); w.writerow(["Den ngay", "31/10/2026"]); w.writerow(["So du dau ky", vnd(opening)]); w.writerow([])
    w.writerow(["Ngày GD", "Số CT", "Ghi nợ", "Ghi có", "Số dư", "Nội dung chi tiết"])
    for ln in lines:
        w.writerow([ln["ngay"].strftime("%d/%m/%Y"), ln["so_ct"], vnd(ln["no"]) if ln["no"] else "", vnd(ln["co"]) if ln["co"] else "",
                    vnd(ln["du"]), ln["nd"]])
    w.writerow([]); w.writerow(["Tong phat sinh no", vnd(tot_no)]); w.writerow(["Tong phat sinh co", vnd(tot_co)]); w.writerow(["So du cuoi ky", vnd(closing)])

# ---------------- sổ đơn hàng (Excel, định dạng lẫn lộn cố ý) ----------------
import openpyxl
from openpyxl.styles import Font
wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Don hang T10"
ws.append(["Mã đơn", "Ngày đặt", "Khách hàng", "SĐT", "Sản phẩm", "SL", "Tiền hàng", "Phí ship", "Tổng phải thu", "Hình thức TT", "Trạng thái", "Ghi chú"])
for c in ws[1]: c.font = Font(bold=True)
text_total = set(rng.sample(range(N), 8)); text_date = set(rng.sample(range(N), 10))
notes_extra = {k: "khách báo CK sáng nay" for k in rng.sample(cats["B"], 2)}
notes_extra.update({k: "khách ck hộ chị gái" for k in rng.sample(cats["A"], 1)})
for o in orders:
    k = o["i"] - 1
    if k in notes_extra and not o["ghi_chu"]: o["ghi_chu"] = notes_extra[k]
    ngay = o["ngay"].strftime("%d-%m-%Y") if k in text_date else o["ngay"]
    tong = f"{vnd_dot(o['tong'])} đ" if k in text_total else o["tong"]
    ws.append([o["ma"], ngay, o["kh"]["ten"], o["kh"]["sdt"], o["sp"], o["sl"], o["tien_hang"], o["ship"], tong, o["tt"], o["trang_thai"], o["ghi_chu"]])
for r in ws.iter_rows(min_row=2):
    if isinstance(r[1].value, date): r[1].number_format = "DD/MM/YYYY"
    for c in (r[6], r[7], r[8]):
        if isinstance(c.value, int): c.number_format = "#,##0"
for col, wd in zip("ABCDEFGHIJKL", (12, 12, 22, 13, 28, 5, 12, 10, 14, 12, 12, 26)): ws.column_dimensions[col].width = wd
wb.save(HERE / "so-don-hang-t10-2026.xlsx")

# ---------------- đáp án ----------------
ans_lines = {l["so_ct"]: {"ngay": l["ngay"].isoformat(), "chieu": "co" if l["co"] else "no", "so_tien": l["co"] or l["no"], "nd": l["nd"], **l["truth"]} for l in lines}
tot_by_loai = {}
for l in lines:
    if l["co"]: tot_by_loai[l["truth"]["loai"]] = tot_by_loai.get(l["truth"]["loai"], 0) + l["co"]
paid_orders = {m for l in lines if l["co"] for m in l["truth"]["orders"]}
unpaid = [orders[k]["ma"] for k in unpaid_old + unpaid_late]
answer = {
    "meta": {"seed": SEED, "ky": "10/2026", "so_dong": len(lines), "so_don": N, "so_don_ck": len(ck_idx), "so_don_cod": len(cod_idx)},
    "so_du_dau": opening, "so_du_cuoi": closing, "tong_ghi_co": tot_co, "tong_ghi_no": tot_no,
    "tong_co_theo_loai_goc": tot_by_loai,
    "don_chua_thu_ck": sorted(unpaid), "don_huy_khong_thu": sorted(orders[k]["ma"] for k in cancelled),
    "don_cod_chua_doi_soat": sorted(cod_after), "dong": ans_lines,
    "don_hoan_tien": sorted(orders[k]["ma"] for k in refund_idx),
}
OUT_ANSWER.parent.mkdir(parents=True, exist_ok=True)
OUT_ANSWER.write_text(json.dumps(answer, ensure_ascii=False, indent=1), encoding="utf-8")
from collections import Counter
print("dòng sao kê:", len(lines), "| ghi có:", sum(1 for l in lines if l["co"]), "| ghi nợ:", sum(1 for l in lines if l["no"]))
print("theo loại:", dict(Counter(l["truth"]["loai"] for l in lines)))
print("cần người (ngoại lệ):", sum(1 for l in lines if l["truth"]["ngoai_le"]), "| mơ hồ:", sum(1 for l in lines if l["truth"]["muc"] == "mo_ho"))
print("tổng có", tot_co, "nợ", tot_no, "đầu", opening, "cuối", closing, "| đơn chưa thu:", unpaid)
