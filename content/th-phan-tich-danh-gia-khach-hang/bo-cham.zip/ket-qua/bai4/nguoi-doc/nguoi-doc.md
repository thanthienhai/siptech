# Các ý kiến máy chờ người đọc quyết

## 1. Hai bài mẫu

**R075** (Facebook, không có sao): "Giá hợp lý lắm luôn, hợp lý với ví của chủ quán 🙃"
- (a) Cụm "hợp lý với ví của chủ quán": khen giá nhưng lại nói giá hợp với ví của *chủ*, không phải của khách.
- (b) Nghĩa đen: khen giá rẻ, hợp lý, tích cực. Nghĩa thật: mỉa mai, ý là giá cao, chủ quán lời còn khách thì đắt.
- (c) Người đọc quyết: tính là chê giá (tiêu cực) hay không. Bài không có sao nên không có gì để đối chiếu.

**R202** (Shopee Food, 4 sao): "Đồ ăn giao tới nguội ngắt, đúng kiểu ăn cho mát bụng mùa hè nhỉ 😊"
- (a) Câu "đúng kiểu ăn cho mát bụng mùa hè nhỉ": giọng vui vẻ đi kèm chữ "nguội ngắt".
- (b) Nghĩa đen: khen đồ ăn mát, hợp mùa hè. Nghĩa thật: mỉa mai, món giao tới bị nguội, đó là lời phàn nàn về giao hàng.
- (c) Người đọc quyết: ghi là tiêu cực về giao hàng, và tin chữ hay tin 4 sao (4 sao lệch với lời chê).

## 2. Thống kê bằng code

- Số ý kiến CAN_NGUOI_DOC: 16. Số bài có ít nhất một ý kiến loại này: **16** (mỗi bài đúng một ý kiến).
- Việc xếp nhóm do tôi đọc từng bài rồi gán trong code; code chỉ đếm và kiểm tra không bài nào bị sót.

| Nhóm lý do | Số bài | Mã bài |
|---|---|---|
| Mỉa mai (khen ngoài miệng, chê thật) | 14 | R029 R040 R075 R077 R096 R126 R146 R159 R169 R202 R217 R225 R236 R245 |
| Nghĩa mập mờ (thiếu thông tin để đoán) | 2 | R054 R211 |
| Ranh giới nguy cấp | 0 | (không có bài nào) |
| Không rõ lý do | 0 | (không có bài nào) |

- R054 "ổn nhưng mà thôi kệ": khen hay bỏ cuộc thì không biết. R211 "Hơi tiếc, lần trước không như vậy...": không nói rõ lần này hay lần trước tốt hơn.
- Lưu ý: trong 14 bài mỉa mai, 7 bài chấm 5 sao, 4 bài chấm 4 sao, 3 bài không có sao. Sao và lời chê lệch nhau, nên đừng dùng số sao để đoán sắc thái.
