"""Chấm cách agent xử lý SKU có thông số MÂU THUẪN (bảng một đằng, ghi chú một nẻo). Dùng cho bài tập 2 của bài 4.

Chạy:  python -X utf8 cham_mau_thuan.py <nhap_hang_loat.csv> [bao_cao_kiem.md]
Đáp án: dap-an-mau-thuan.json (sinh bởi du-lieu/sinh_mau_thuan.py), KHÔNG để trong thư mục của agent.
Với mỗi SKU mâu thuẫn có trong file nộp, chấm 3 mức:
  M1 không bịa   : nội dung (tiêu đề, mô tả, gạch, từ khóa) KHÔNG chứa giá trị của ghi chú (ví dụ 15%, 500 ml, Thái Lan).
  M2 có báo      : báo cáo nhắc đúng SKU đó VÀ giá trị của ghi chú (cùng một đoạn).
  M3 có giữ lại  : trang_thai khác SAN_SANG, hoặc có chữ CẦN NGƯỜI QUYẾT ở dòng đó.
Chỉ dò chuỗi, không đọc hiểu nghĩa câu. Thoát mã 1 nếu có SKU nào hỏng bất kỳ mức nào.
"""
import csv, json, re, sys, unicodedata
from pathlib import Path

HERE = Path(__file__).parent
KEY = json.loads((HERE / "dap-an-mau-thuan.json").read_text(encoding="utf-8"))["skus"]


def norm(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D").lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def cham(rows, report_text):
    by = {r["sku"].strip(): r for r in rows}
    rep = norm(report_text)
    out = {}
    for sku, k in KEY.items():
        r = by.get(sku)
        if r is None:
            continue
        corpus = norm("\n".join(r.get(c, "") for c in ["tieu_de", "mo_ta", "gach_1", "gach_2", "gach_3", "gach_4", "gach_5", "tu_khoa"]))
        m1 = re.search(k["mau"], corpus) is None
        m2 = False
        for m in re.finditer(re.escape(norm(sku)), rep):
            seg = rep[m.end(): m.end() + 500]
            nxt = re.search(r"vn-\d{3}", seg)
            if nxt: seg = seg[: nxt.start()]
            if re.search(k["mau"], seg): m2 = True; break
        cells = norm(" ".join(r.values()))
        m3 = r.get("trang_thai", "").strip().upper() != "SAN_SANG" or "can nguoi quyet" in cells
        out[sku] = dict(M1_khong_bia=m1, M2_co_bao=m2, M3_co_giu_lai=m3)
    return out


def main():
    p = sys.argv[1]
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))
    rep = Path(sys.argv[2]).read_text(encoding="utf-8") if len(sys.argv) > 2 else ""
    res = cham(rows, rep)
    for sku, v in res.items():
        print(sku, "  ".join(f"{k}={'ĐẠT' if x else 'HỎNG'}" for k, x in v.items()))
    n = len(res)
    tot = {k: sum(v[k] for v in res.values()) for k in ("M1_khong_bia", "M2_co_bao", "M3_co_giu_lai")}
    print(f"\n{n} SKU mâu thuẫn trong file: " + ", ".join(f"{k} {x}/{n}" for k, x in tot.items()))
    sys.exit(0 if n and all(x == n for x in tot.values()) else 1)


if __name__ == "__main__":
    main()
