"""Sinh thêm 20 đánh giá GIẢ về ĐÓNG GÓI cho quán cà phê hư cấu "Mây Lưng Chừng" (bài tập 1, bài 4).

Chạy trong thư mục du-lieu:  python -X utf8 sinh_them_dong_goi.py
Ra:    them-dong-goi.csv       20 bài mới (R251..R270), cùng cột với danh-gia.csv. Cho agent.
       danh-gia-270.csv        250 bài cũ + 20 bài mới. Cho agent (nếu muốn chạy cả bộ).
       ../ket-qua/bo-vang-dong-goi.csv   đáp án của 20 bài mới (cột ma, chu_de, sac_thai). KHÔNG đưa vào thư mục agent.

Hạt giống cố định => chạy lại ra đúng bản cũ. Mọi nội dung là bịa; không có tên người hay doanh nghiệp thật.
Chủ đề mới: dong_goi (đóng gói: nắp ly, túi, hộp, ống hút, niêm phong). Các chủ đề khác như bài 1.
Sắc thái: tich_cuc, tieu_cuc, trung_tinh, CAN_NGUOI_DOC (bài mỉa mai: đáp án yêu cầu để cho người đọc).
"""
import csv
import random
from pathlib import Path

SEED = 20261121
R = random.Random(SEED)
HERE = Path(__file__).resolve().parent
OUT_GOLD = HERE.parent / "ket-qua" / "bo-vang-dong-goi.csv"

POS, NEG, NEU, HOAN = "tich_cuc", "tieu_cuc", "trung_tinh", "CAN_NGUOI_DOC"

# (nội dung, [(chu_de, sac_thai), ...], ghi chú của người soạn - không đưa vào csv)
BAI = [
    ("Đóng gói rất kỹ, ly có nắp dán kín, mở ra không đổ giọt nào", [("dong_goi", POS)], "thuần đóng gói"),
    ("Nắp ly lỏng, vừa cầm lên là nước tràn ra túi", [("dong_goi", NEG)], "thuần đóng gói"),
    ("Bánh được bọc hộp cứng nên tới nơi vẫn nguyên hình", [("dong_goi", POS)], "thuần đóng gói"),
    ("Túi giấy mỏng quá, đựng hai ly mà rách đáy", [("dong_goi", NEG)], "thuần đóng gói"),
    ("dong goi so sai, banh bi bep dum", [("dong_goi", NEG)], "không dấu"),
    ("Hộp đựng bánh móp méo hết, nhìn mất cả hứng ăn", [("dong_goi", NEG)], "thuần đóng gói"),
    ("Ống hút bọc riêng, có kèm khăn giấy, gọn gàng", [("dong_goi", POS)], "thuần đóng gói"),
    ("Đóng gói bình thường, không có gì đặc biệt", [("dong_goi", NEU)], "trung tính"),
    ("Đóng gói kỹ nhưng shipper giao trễ gần một tiếng", [("dong_goi", POS), ("giao_hang", NEG)], "hai chủ đề"),
    ("Nước ngon, tiếc là nắp lỏng nên đổ ra một ít", [("chat_luong", POS), ("dong_goi", NEG)], "hai chủ đề"),
    ("Giá ok, đóng gói đẹp, còn tặng kèm thiệp nhỏ dễ thương", [("gia", POS), ("dong_goi", POS)], "hai chủ đề"),
    ("Giao nhanh thật, mà hộp bánh bị bẹp một góc", [("giao_hang", POS), ("dong_goi", NEG)], "hai chủ đề"),
    ("Bạn nhân viên gói hàng cẩn thận, còn dặn mình để ly đứng thẳng", [("phuc_vu", POS), ("dong_goi", POS)], "hai chủ đề"),
    ("Giao chậm, đồ nguội, hộp thì móp", [("giao_hang", NEG), ("dong_goi", NEG)], "hai chủ đề"),
    ("Đóng gói kỹ ghê, mở ra còn nửa ly, nửa kia nằm trong túi 👏", [("dong_goi", HOAN)], "MỈA MAI"),
    ("Cảm ơn quán đã gói chắc lắm, ly nước bay hết ra ngoài túi luôn 😊", [("dong_goi", HOAN)], "MỈA MAI"),
    ("Mua gói cà phê rang xay về pha, thơm lắm, sẽ mua lại", [("chat_luong", POS)], "BẪY TỪ KHÓA: 'gói' không phải đóng gói"),
    ("Đóng gói sạch sẽ, có dán tem niêm phong, mở ra yên tâm hơn hẳn", [("dong_goi", POS)], "thuần đóng gói"),
    ("Dùng hộp xốp với túi nilon hơi nhiều, tiếc môi trường, quán nên đổi sang giấy", [("dong_goi", NEG)], "thuần đóng gói"),
    ("dong goi ok, ly ko bi do, giao dc nhanh nx 👍", [("dong_goi", POS), ("giao_hang", POS)], "teen code"),
]

NEN_TANG = ["Google Maps", "Shopee Food", "Facebook"]
EMOJI = {"pos": ["", "", " 👍", " 😍"], "neg": ["", "", " 👎", " 😞"], "mix": ["", "", " 😐"]}
NGAY = [(2026, 11, d) for d in (16, 17, 18, 19, 20, 21)]


def ngay_str(nen, y, m, d):
    # Google Maps: DD/MM/YYYY; Shopee Food: YYYY-MM-DD; Facebook: lẫn cả hai (giống bộ cũ)
    kieu = {"Google Maps": "vn", "Shopee Food": "iso"}.get(nen, R.choice(["vn", "iso"]))
    return f"{d:02d}/{m:02d}/{y}" if kieu == "vn" else f"{y}-{m:02d}-{d:02d}"


def loai_emoji(gold):
    s = {x[1] for x in gold}
    return "pos" if s == {POS} else "neg" if s == {NEG} else "mix"


def sao_cho(gold):
    s = {x[1] for x in gold}
    if HOAN in s:
        return R.choice([4, 5])  # mỉa mai: sao cao, đúng kiểu bẫy
    if s == {POS}:
        return R.choice([4, 5])
    if s == {NEG}:
        return R.choice([1, 2])
    return R.choice([2, 3, 4])


def main():
    rows, gold_rows = [], []
    for i, (nd, gold, _) in enumerate(BAI):
        ma = f"R{251 + i}"
        nen = R.choice(NEN_TANG)
        y, m, d = R.choice(NGAY)
        sao = "" if nen == "Facebook" else sao_cho(gold)
        e = R.choice(EMOJI[loai_emoji(gold)])
        text = nd if nd[-1] in "👏😊👍" else nd + e
        rows.append({"ma": ma, "nen_tang": nen, "ngay": ngay_str(nen, y, m, d), "sao": sao, "noi_dung": text})
        for cd, st in gold:
            gold_rows.append({"ma": ma, "chu_de": cd, "sac_thai": st})
    cols = ["ma", "nen_tang", "ngay", "sao", "noi_dung"]
    with open(HERE / "them-dong-goi.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    cu = list(csv.DictReader(open(HERE / "danh-gia.csv", encoding="utf-8-sig")))
    with open(HERE / "danh-gia-270.csv", "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(cu); w.writerows(rows)
    OUT_GOLD.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT_GOLD, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["ma", "chu_de", "sac_thai"]); w.writeheader(); w.writerows(gold_rows)
    n_dg = sum(1 for g in gold_rows if g["chu_de"] == "dong_goi")
    print(f"them-dong-goi.csv: {len(rows)} bài | danh-gia-270.csv: {len(cu) + len(rows)} bài")
    print(f"bo-vang-dong-goi.csv: {len(gold_rows)} cặp (bài, chủ đề), trong đó dong_goi: {n_dg}, "
          f"mỉa mai: {sum(1 for g in gold_rows if g['sac_thai'] == HOAN)}")


if __name__ == "__main__":
    main()
