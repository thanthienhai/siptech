"""Sinh bo du lieu GIA cho bai 07: xuat-nhap-ton 12 thang cua mot cua hang tap hoa/ vat tu/ my pham (60 ma hang).

Chay:  python -X utf8 sinh_du_lieu.py
Ra (cung thu muc nay):
  danh-muc-hang.csv, nhat-ky-xuat-nhap.csv, ton-dau-ky-2025-11-01.csv, ton-kiem-ke-2026-10-31.csv,
  hang-dang-ve.csv, tham-so.json, quy-uoc.md
Ra (thu muc ../ket-qua/, KHONG dua vao thu muc agent lam viec):
  dap-an.json  (ke ca danh sach loi da cai va ket qua tham chieu tinh tu du lieu sach)
Moi ten hang, ten nha cung cap, so lieu la BIA. Hat giong co dinh -> chay lai ra y het.
Luu y: file nay chua logic cai loi + dap an. Neu muon tu thu lam, dung mo no truoc.
"""
import csv, json, math, datetime as dt, unicodedata, statistics
from pathlib import Path
import numpy as np

SEED = 20261120
HERE = Path(__file__).parent
OUT_ANS = HERE.parent / "ket-qua"
START = dt.date(2025, 11, 1)
NDAYS = 365                      # 2025-11-01 .. 2026-10-31
END = START + dt.timedelta(days=NDAYS - 1)
rng = np.random.default_rng(SEED)

def midx(d):                      # 0 = 2025-11 ... 11 = 2026-10
    return (d.year - 2025) * 12 + d.month - 11
MONTHS = [f"{2025 + (10 + i) // 12}-{(10 + i) % 12 + 1:02d}" for i in range(12)]

def unaccent(s):
    s = s.replace("đ", "d").replace("Đ", "D")
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")

# he so mua vu theo thang (Nov25 ... Oct26)
SEASON = {
    "flat":   [1] * 12,
    "tet":    [1.0, 1.25, 1.7, 1.5, 0.8, 0.85, 0.9, 0.9, 0.9, 0.95, 1.0, 1.0],
    "tetpeak": [0.25, 1.6, 4.0, 2.4, 0.1, 0.05, 0.05, 0.05, 0.05, 0.05, 0.1, 0.2],
    "summer": [0.7, 0.65, 0.7, 0.8, 1.1, 1.4, 1.6, 1.7, 1.6, 1.4, 1.0, 0.8],
    "rain":   [1.1, 0.7, 0.6, 0.6, 0.7, 0.8, 1.0, 1.3, 1.5, 1.6, 1.5, 1.3],
    "cold":   [1.1, 1.4, 1.5, 1.3, 0.9, 0.7, 0.6, 0.6, 0.6, 0.7, 0.9, 1.0],
    "school": [0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 0.9, 1.0, 1.2, 1.8, 1.6, 0.9],
    "dead":   [1, 1, 1, 0.8, 0.5, 0.2, 0.05, 0, 0, 0, 0, 0],
}
# ma|ten|nhom|gia_von|bien_loi_nhuan|don_vi|quy_cach|giao_ngay|nhu_cau_co_so/thang|mua|nhieu|loai|them
RAW = """
TH001|Gạo thơm túi 5kg|Tạp hóa|92000|0.12|túi|4|5|60|tet|0.15|normal|
TH002|Dầu ăn đậu nành chai 1L|Tạp hóa|46000|0.12|chai|12|5|90|tet|0.15|normal|
TH003|Nước mắm chai 500ml|Tạp hóa|32000|0.18|chai|12|5|70|tet|0.15|normal|
TH004|Đường cát trắng gói 1kg|Tạp hóa|21000|0.12|gói|20|5|80|tet|0.15|normal|
TH005|Muối i-ốt gói 500g|Tạp hóa|4500|0.25|gói|50|7|40|flat|0.2|normal|
TH006|Mì gói thùng 30 gói|Tạp hóa|98000|0.10|thùng|6|5|25|flat|0.2|normal|
TH007|Mì gói vị tôm (gói)|Tạp hóa|3600|0.14|gói|30|5|700|flat|0.12|normal|bulk
TH008|Nước ngọt có ga lon 330ml|Tạp hóa|7500|0.16|lon|24|5|600|summer|0.15|normal|
TH009|Nước suối chai 500ml|Tạp hóa|3200|0.25|chai|24|5|900|summer|0.15|normal|
TH010|Trà xanh đóng chai 455ml|Tạp hóa|6200|0.20|chai|24|5|350|summer|0.18|normal|
TH011|Sữa tươi hộp 1L|Tạp hóa|29000|0.10|hộp|12|4|150|flat|0.12|normal|expire
TH012|Sữa đặc có đường lon 380g|Tạp hóa|24000|0.12|lon|24|5|120|tet|0.15|normal|
TH013|Cà phê hòa tan hộp 20 gói|Tạp hóa|38000|0.18|hộp|12|7|60|cold|0.2|normal|
TH014|Trà túi lọc hộp 25 túi|Tạp hóa|26000|0.20|hộp|24|7|45|cold|0.2|normal|
TH015|Bánh quy hộp thiếc 500g|Tạp hóa|55000|0.20|hộp|6|7|40|tet|0.2|normal|
TH016|Mứt tết hộp 400g|Tạp hóa|62000|0.25|hộp|6|7|15|tetpeak|0.2|normal|
TH017|Kẹo dẻo gói 100g|Tạp hóa|8500|0.25|gói|48|7|200|school|0.2|normal|
TH018|Snack khoai tây gói 52g|Tạp hóa|7000|0.20|gói|48|7|260|flat|0.15|normal|
TH019|Hạt dưa gói 200g|Tạp hóa|18000|0.25|gói|20|7|30|tetpeak|0.2|normal|
TH020|Bột ngọt gói 400g|Tạp hóa|28000|0.12|gói|20|5|50|flat|0.15|normal|
TH021|Nước tương chai 500ml (mã cũ)|Tạp hóa|17000|0.20|chai|12|5|55|flat|0.2|dead|ngung
TH022|Tương ớt chai 250ml|Tạp hóa|11000|0.22|chai|24|5|80|flat|0.15|normal|
TH023|Trứng gà vỉ 10 quả|Tạp hóa|28000|0.10|vỉ|10|3|120|flat|0.2|normal|expire
TH024|Bột nêm gói 400g|Tạp hóa|29000|0.15|gói|20|5|65|flat|0.15|normal|
VT001|Bóng đèn LED 9W|Vật tư|22000|0.30|cái|20|10|70|flat|0.2|normal|
VT002|Pin AA vỉ 4 viên|Vật tư|18000|0.30|vỉ|20|10|60|flat|0.2|normal|
VT003|Băng keo trong cuộn 48mm|Vật tư|9500|0.30|cuộn|36|10|90|flat|0.2|normal|
VT004|Túi rác cuộn trung|Vật tư|14000|0.25|cuộn|30|7|80|flat|0.15|normal|
VT005|Giấy vệ sinh lốc 10 cuộn|Vật tư|52000|0.14|lốc|12|7|95|flat|0.12|normal|
VT006|Khăn giấy hộp|Vật tư|4800|0.30|hộp|48|7|150|flat|0.15|normal|
VT007|Nước rửa chén chai 750ml|Vật tư|24000|0.18|chai|12|7|110|flat|0.12|normal|bulk
VT008|Bột giặt túi 3kg|Vật tư|98000|0.12|túi|6|7|45|flat|0.15|normal|bulk
VT009|Nước lau sàn chai 1L|Vật tư|31000|0.18|chai|12|7|40|flat|0.15|normal|
VT010|Nước xả vải túi 1.6L|Vật tư|58000|0.15|túi|4|7|3|flat|0.4|slow|
VT011|Thuốc xịt muỗi chai 600ml|Vật tư|52000|0.20|chai|12|7|35|rain|0.2|normal|
VT012|Áo mưa bộ|Vật tư|36000|0.35|bộ|20|10|25|rain|0.25|normal|
VT013|Ô gấp|Vật tư|85000|0.30|cái|10|10|12|rain|0.3|normal|
VT014|Găng tay cao su đôi|Vật tư|14000|0.30|đôi|24|7|50|flat|0.2|normal|
VT015|Khẩu trang y tế hộp 50 cái|Vật tư|24000|0.25|hộp|20|7|40|cold|0.2|normal|bulk
VT016|Dây điện nối dài ổ cắm 5m|Vật tư|95000|0.25|cái|2|10|2|flat|0.5|slow|
VT017|Bóng đèn tròn sợi đốt 40W|Vật tư|8000|0.35|cái|50|10|30|flat|0.2|dead|ngung
VT018|Keo dán đa năng tuýp|Vật tư|28000|0.30|tuýp|4|10|2.5|flat|0.5|slow|
VT019|Tập học sinh 96 trang|Vật tư|7500|0.25|cuốn|100|10|150|school|0.2|normal|
VT020|Bút bi hộp 20 cây|Vật tư|28000|0.30|hộp|20|10|40|school|0.2|normal|
MP001|Kem chống nắng tuýp 50g|Mỹ phẩm|128000|0.35|tuýp|12|10|35|summer|0.2|normal|
MP002|Sữa rửa mặt tuýp 100g|Mỹ phẩm|62000|0.35|tuýp|12|10|40|flat|0.15|normal|
MP003|Dầu gội chai 650ml|Mỹ phẩm|88000|0.22|chai|12|7|50|flat|0.15|normal|
MP004|Dầu xả chai 650ml|Mỹ phẩm|92000|0.22|chai|3|7|2|flat|0.45|slow|
MP005|Sữa tắm chai 900ml|Mỹ phẩm|98000|0.22|chai|12|7|45|flat|0.15|normal|
MP006|Son dưỡng môi thỏi|Mỹ phẩm|45000|0.40|thỏi|24|10|70|cold|0.2|normal|expire
MP007|Kem dưỡng ẩm hũ 100g|Mỹ phẩm|105000|0.38|hũ|12|10|25|cold|0.25|normal|expire
MP008|Nước tẩy trang chai 300ml|Mỹ phẩm|82000|0.35|chai|12|10|30|flat|0.2|normal|
MP009|Mặt nạ giấy hộp 10 miếng|Mỹ phẩm|68000|0.35|hộp|24|10|40|flat|0.2|normal|
MP010|Toner pad hộp 60 miếng|Mỹ phẩm|74000|0.38|hộp|12|10|18|flat|0.3|new10|
MP011|Lăn khử mùi chai 50ml|Mỹ phẩm|52000|0.30|chai|24|10|45|summer|0.2|normal|
MP012|Kem đánh răng tuýp 180g|Mỹ phẩm|31000|0.20|tuýp|24|7|130|flat|0.12|normal|bulk
MP013|Bàn chải đánh răng (cây)|Mỹ phẩm|12000|0.35|cây|48|7|150|flat|0.15|normal|
MP014|Dầu dưỡng tóc chai 100ml|Mỹ phẩm|115000|0.38|chai|12|10|12|flat|0.3|new7|
MP015|Serum vitamin C chai 30ml|Mỹ phẩm|185000|0.40|chai|6|10|8|flat|0.35|new9|
MP016|Gel rửa tay khô chai 500ml|Mỹ phẩm|42000|0.30|chai|12|7|20|dead|0.2|dead|
"""
SUPPLIERS = {"Tạp hóa": ["NCC Giả A", "NCC Giả B", "NCC Giả C"], "Vật tư": ["NCC Giả D", "NCC Giả E"], "Mỹ phẩm": ["NCC Giả F", "NCC Giả G"]}

# cua so NCC het hang (ngay bat dau, ngay ket thuc): moi don hang du kien ve trong cua so bi doi sang ngay ket thuc+1
OUTAGE = {"TH002": (65, 115), "TH008": (145, 195), "TH011": (205, 250), "VT002": (95, 140), "VT005": (240, 290),
          "VT008": (25, 75), "MP001": (180, 230), "MP002": (322, 420), "MP003": (300, 345), "MP012": (215, 260)}
# don si 1 lan: (ma, ngay thu may, so luong, co ghi chu khong)
BULK = {"TH007": (142, 2500, True), "VT007": (201, 140, False), "VT008": (95, 90, True), "VT015": (258, 260, False), "MP012": (170, 420, True)}
NEWLAUNCH = {"new7": 7, "new9": 9, "new10": 10}

def parse():
    skus = []
    for ln in RAW.strip().splitlines():
        c = ln.split("|")
        skus.append(dict(code=c[0], name=c[1], group=c[2], cost=int(c[3]), margin=float(c[4]), unit=c[5], pack=int(c[6]),
                         lead=int(c[7]), base=float(c[8]), season=c[9], noise=float(c[10]), kind=c[11], extra=c[12]))
    # co dan nhu cau: phan bo gia tri tieu thu theo luat Zipf de ABC co hinh dang that (it ma chiem phan lon gia tri)
    normal = sorted([x for x in skus if x["kind"] == "normal"], key=lambda x: -x["base"] * x["cost"])
    for k, x in enumerate(normal, start=1):
        v = 24_000_000 * k ** -1.0 * (1 if k < 4 else (4 / k) ** 0.45)
        x["base"] = float(max(6, round(v / x["cost"])))
    return skus

def simulate(sk, i):
    """Tra ve (events, truth). events: dict(day, type, qty, tag, note). truth: so lieu thang."""
    code, pack, L, base = sk["code"], sk["pack"], sk["lead"], sk["base"]
    kind = sk["kind"]
    launch = NEWLAUNCH.get(kind, 0)
    seas = SEASON["dead" if kind == "dead" else sk["season"] if not kind.startswith("new") else "flat"]
    trend = 1 + rng.uniform(-0.01, 0.015) * np.arange(12) if kind == "normal" else np.ones(12)
    noise = np.exp(rng.normal(0, sk["noise"], 12))
    mu = base * np.array(seas) * trend * noise
    if kind.startswith("new"):
        mu[:launch] = 0
    if kind == "dead" and code == "TH021":   # doi ma: ban binh thuong den thang 3 roi dung han
        mu = base * np.array([1, 1, 1, 1, 0.6, 0.3, 0.1, 0, 0, 0, 0, 0]) * noise
    wd = np.array([1.0, 0.9, 0.9, 0.95, 1.1, 1.4, 1.5])
    days = [START + dt.timedelta(days=d) for d in range(NDAYS)]
    lam = np.zeros(NDAYS)
    for m in range(12):
        idx = [d for d in range(NDAYS) if midx(days[d]) == m]
        w = np.array([wd[days[d].weekday()] for d in idx]); w = w / w.sum()
        for d, wi in zip(idx, w): lam[d] = mu[m] * wi
    if kind.startswith("new"):
        ldays = [d for d in range(NDAYS) if midx(days[d]) == launch]
        first_day = ldays[0]
    else:
        first_day = 0
    stock = 0 if kind.startswith("new") else int(math.ceil(base * SEASON[sk["season"]][0] * rng.uniform(0.7, 1.4) / pack) * pack)
    if kind == "dead": stock = int(math.ceil(base * 3.0 / pack) * pack)
    opening = stock
    arrivals = []           # (day, qty)
    events = []
    sold_hist = []
    out = OUTAGE.get(code)
    stop_order_day = 100 if kind == "dead" else 10**9
    if kind.startswith("new"):
        arrivals.append((first_day - 2, int(math.ceil(mu[launch] * 1.3 / pack) * pack)))
    if kind == "dead":
        arrivals.append((90, int(math.ceil(3.0 * base / pack) * pack)))   # dot nhap cuoi truoc khi ngung ban
    sold_m = np.zeros(12); ret_m = np.zeros(12); bulk_m = np.zeros(12); lost_m = np.zeros(12)
    zero_days = np.zeros(12, dtype=int)
    last_sale_day = None
    bulk = BULK.get(code)
    cost_up = None
    for d in range(NDAYS):
        m = midx(days[d])
        # giao hang
        for a in [a for a in arrivals if a[0] <= d]:
            arrivals.remove(a); stock += a[1]
            events.append(dict(day=d, type="NHAP", qty=a[1], tag="nhap", note=""))
        # don si
        if bulk and d == bulk[0]:
            q = bulk[1]
            if stock < q:                       # nhap them cho don si
                extra = int(math.ceil((q - stock + 20) / pack) * pack); stock += extra
                events.append(dict(day=d, type="NHAP", qty=extra, tag="nhap", note="nhap cho don si"))
            stock -= q; bulk_m[m] += q
            events.append(dict(day=d, type="XUAT", qty=q, tag="bulk", note="Khach si - DH dai ly" if bulk[2] else ""))
            last_sale_day = d
        # nhu cau ngay
        D = int(rng.poisson(lam[d])) if d >= (first_day if kind.startswith("new") else 0) else 0
        sold = min(D, stock); lost = D - sold
        if sold > 0:
            stock -= sold; sold_m[m] += sold; last_sale_day = d
            parts = [sold]
            if sold >= 4 and rng.random() < 0.5:
                a = int(rng.integers(1, sold)); parts = [a, sold - a]
            for q in parts:
                events.append(dict(day=d, type="XUAT", qty=q, tag="sale", note=""))
        lost_m[m] += lost
        sold_hist.append(sold)
        # tra hang, huy, noi bo, dieu chinh
        if sold > 0 and kind == "normal" and rng.random() < 0.0035 and stock >= 0:
            q = int(rng.integers(1, 3)); stock += q; ret_m[m] += q
            events.append(dict(day=d, type="XUAT", qty=-q, tag="return", note="khach tra"))
        if "expire" in sk["extra"] and rng.random() < 0.012 and stock > 6:
            q = int(rng.integers(2, 6)); stock -= q
            events.append(dict(day=d, type="XUAT", qty=q, tag="huy", note="huy hang het han"))
        if sk["group"] == "Tạp hóa" and sk["base"] < 130 and rng.random() < 0.004 and stock > 6:
            q = int(rng.integers(2, 5)); stock -= q
            events.append(dict(day=d, type="XUAT", qty=q, tag="noi_bo", note="xuat dung tai quan"))
        if rng.random() < 0.0035 and stock > 5:
            q = int(rng.integers(1, 4)); stock -= q
            events.append(dict(day=d, type="DIEU_CHINH", qty=-q, tag="dieu_chinh", note=str(rng.choice(["kiem ke hao hut", "vo/ hu hong"]))))
        if stock <= 0: zero_days[m] += 1
        # dat hang cua chu tiem
        if d < stop_order_day and d + L < NDAYS + 20:
            on_order = sum(a[1] for a in arrivals)
            recent = sum(sold_hist[-30:]) / max(1, min(30, len(sold_hist)))
            if kind.startswith("new") and d < first_day: recent = mu[launch] / 30
            avg = max(recent, base * SEASON[sk["season"]][min(m, 11)] / 30 * 0.4 if not kind.startswith("new") else recent, 0.05)
            if kind == "slow": avg = max(recent, base / 30)
            if stock + on_order <= avg * (L + 7) and (d >= first_day - L) and not (kind == "dead" and d > stop_order_day):
                q = int(max(pack, math.ceil(avg * 30 / pack) * pack))
                arr = d + L + int(rng.integers(0, 5))
                if out and out[0] <= arr <= out[1]: arr = out[1] + 1
                arrivals.append((arr, q))
    if code == "TH021":
        pass
    truth = dict(opening=opening, closing=stock, sold=sold_m.tolist(), returns=ret_m.tolist(), bulk=bulk_m.tolist(),
                 lost=lost_m.tolist(), zero_days=zero_days.tolist(), launch=launch, last_sale_day=last_sale_day,
                 on_order=[(a[0], a[1]) for a in arrivals])
    return events, truth

def make_prices(sk):
    # mot so ma tang gia von giua nam
    inc = 0.0; day = None
    if rng.random() < 0.3:
        inc = float(rng.uniform(0.05, 0.12)); day = int(rng.integers(120, 260))
    return inc, day

def ref_calc(sk, tr, params):
    z = params["z"]; L = sk["lead"]; pack = sk["pack"]
    net = [tr["sold"][m] - tr["returns"][m] for m in range(12)]
    cut = [tr["zero_days"][m] >= 7 for m in range(12)]
    active = [m >= tr["launch"] for m in range(12)]
    def forecast(t):                 # nguon: cac thang <= t
        valid = [m for m in range(t + 1) if active[m] and not cut[m]]
        last3 = valid[-3:]
        F = float(np.mean([net[m] for m in last3])) if last3 else 0.0
        last6 = valid[-6:]
        if len(last6) >= 3:
            sd = float(np.std([net[m] for m in last6], ddof=1))
        else:
            sd = 0.5 * F
        return F, sd, len(valid)
    F, sd, nv = forecast(11)
    ss = int(math.ceil(z * sd * math.sqrt(L / 30)))
    rop = int(math.ceil(F / 30 * L + ss))
    I = tr["closing"]; P = sum(q for _, q in tr["on_order"])
    need = F + ss - I - P
    qty = int(math.ceil(max(0, need) / pack) * pack) if need > 0 else 0
    # canh bao
    avg12 = float(np.mean([net[m] for m in range(12) if active[m]])) if any(active) else 0.0
    dcover = (I / (F / 30)) if F > 0 else float("inf")
    no_sale90 = tr["last_sale_day"] is None or tr["last_sale_day"] < NDAYS - 90
    if I <= 0: al = "HET_HANG"
    elif I <= rop: al = "SAP_HET"
    elif dcover > params["nguong_ton_lau_ngay"] or (no_sale90 and I > 0): al = "TON_LAU"
    elif avg12 < params["nguong_ban_cham_thang"]: al = "BAN_CHAM"
    else: al = "OK"
    # hold-out
    ho = {}
    for h in (10, 11):
        Fh, _, nvh = forecast(h - 1)
        ho[MONTHS[h]] = dict(actual=net[h], f_ref=Fh, naive=float(tr["sold"][h - 1]), eligible=bool((not cut[h]) and nvh >= 3 and active[h - 1]))
    return dict(F=F, sd=sd, n_valid=nv, ss=ss, rop=rop, ton=I, dang_ve=P, qty=qty, canh_bao=al, ngay_ton=(None if F <= 0 else round(dcover, 1)),
                ban_cham_avg12=avg12, cut_months=[MONTHS[m] for m in range(12) if cut[m] and active[m]], holdout=ho, net=net)

def main():
    skus = parse()
    assert len(skus) == 60 - 0 or True
    all_events = []; truths = {}
    price_info = {}
    for i, sk in enumerate(skus):
        ev, tr = simulate(sk, i)
        for e in ev: e["code"] = sk["code"]
        all_events += ev; truths[sk["code"]] = tr
        price_info[sk["code"]] = make_prices(sk)
    # ---- ma phieu theo thu tu ngay
    all_events.sort(key=lambda e: (e["day"], e["type"], e["code"]))
    cnt = {"PX": 0, "PN": 0, "DC": 0}
    sk_by = {s["code"]: s for s in skus}
    rows = []
    for e in all_events:
        sk = sk_by[e["code"]]
        pre = {"XUAT": "PX", "NHAP": "PN", "DIEU_CHINH": "DC"}[e["type"]]
        cnt[pre] += 1
        inc, iday = price_info[e["code"]]
        cost = sk["cost"]; price = round(sk["cost"] * (1 + sk["margin"]) / 500) * 500
        if inc and e["day"] < iday:
            cost = round(sk["cost"] / (1 + inc) / 100) * 100; price = round(price / (1 + inc) / 500) * 500
        unit_price = cost if e["type"] == "NHAP" else price
        if e["type"] == "DIEU_CHINH": unit_price = ""
        if e["type"] == "XUAT" and e["tag"] in ("huy", "noi_bo"): unit_price = ""
        if e["type"] == "XUAT" and e["tag"] == "sale" and rng.random() < 0.05: unit_price = round(unit_price * 0.9 / 500) * 500
        note = e["note"]
        if e["type"] == "NHAP" and not note: note = f"PO-{cnt['PN']:04d} {rng.choice(SUPPLIERS[sk['group']])}"
        rows.append(dict(ma_phieu=f"{pre}{cnt[pre]:05d}" if pre == "PX" else f"{pre}{cnt[pre]:04d}", day=e["day"], loai=e["type"], ma_hang=e["code"],
                         ten_hang=sk["name"], so_luong=e["qty"], don_gia=unit_price, ghi_chu=note, tag=e["tag"], true_qty=e["qty"]))
    # ---- cai loi
    errors = []     # moi phan tu: ma_phieu, loai_loi, xu_ly_dung, mo_ta
    by_tag = lambda t: [r for r in rows if r["tag"] == t]
    sales = [r for r in rows if r["tag"] == "sale" and r["so_luong"] >= 3 and sk_by[r["ma_hang"]]["base"] <= 150]
    ids = rng.permutation(len(sales)); used = set()
    def take(n, pred=lambda r: True):
        out = []
        for j in ids:
            r = sales[j]
            if id(r) in used or not pred(r): continue
            used.add(id(r)); out.append(r)
            if len(out) == n: break
        return out
    for r in take(6, lambda r: r["so_luong"] >= 3):          # dau am khong ghi chu
        r["so_luong"] = -r["so_luong"]; r["tag"] = "err_sign"
        errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="so_am_khong_ghi_chu", xu_ly_dung="sua dau (+) hoac CAN NGUOI QUYET; khong tinh nhu tra hang", ma_hang=r["ma_hang"], dung=r["true_qty"]))
    for r in take(6, lambda r: r["so_luong"] >= 3):          # go thua so 0
        r["so_luong"] = r["so_luong"] * 10; r["tag"] = "err_x10"
        errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="so_luong_gap_10_lan", xu_ly_dung="sua ve so dung hoac bo/ CAN NGUOI QUYET; khong dua vao nhu cau", ma_hang=r["ma_hang"], dung=r["true_qty"]))
    for r in take(3, lambda r: True):                          # thieu so luong
        r["so_luong"] = ""; r["tag"] = "err_blank"
        errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="thieu_so_luong", xu_ly_dung="CAN NGUOI QUYET (hoac uoc luong co ghi ro); khong tu dien 0", ma_hang=r["ma_hang"], dung=r["true_qty"]))
    deleted = take(5, lambda r: True)
    for r in deleted:
        r["tag"] = "err_deleted"
        errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="dong_bi_mat", xu_ly_dung="khong the thay trong nhat ky; chi lo ra qua lech ton he thong vs kiem ke", ma_hang=r["ma_hang"], dung=r["true_qty"], khong_cham_phat_hien=True))
    # nhap ttre hon ngay cuoi: 2 phieu nhap thang 10 bi go thang 12
    late_nhap = [r for r in rows if r["loai"] == "NHAP" and r["day"] >= 330 and r["tag"] == "nhap"]
    for r in late_nhap[:2]:
        r["future"] = True
        errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="ngay_nhap_o_tuong_lai", xu_ly_dung="sua ngay (nhieu kha nang go nham thang) / CAN NGUOI QUYET; hang da co trong kiem ke", ma_hang=r["ma_hang"], dung=r["true_qty"]))
    # trung dong
    dup_src = [r for r in rows if r["tag"] in ("sale",) and r["so_luong"] != "" and id(r) not in used]
    dups = []
    for j in rng.permutation(len(dup_src))[:8]:
        dups.append(dict(dup_src[j]))
        errors.append(dict(ma_phieu=dup_src[j]["ma_phieu"], loai_loi="trung_dong", xu_ly_dung="bo dong thua", ma_hang=dup_src[j]["ma_hang"], dung=dup_src[j]["true_qty"]))
    nh = [r for r in rows if r["loai"] == "NHAP" and r["tag"] == "nhap" and not r.get("future")]
    for j in rng.permutation(len(nh))[:3]:
        dups.append(dict(nh[j]))
        errors.append(dict(ma_phieu=nh[j]["ma_phieu"], loai_loi="trung_dong", xu_ly_dung="bo dong thua", ma_hang=nh[j]["ma_hang"], dung=nh[j]["true_qty"]))
    # truth phi-loi nhung de nham
    for r in rows:
        if r["tag"] == "return":
            errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="khach_tra_hang_hop_le", xu_ly_dung="HOP LE: tru vao doanh so thang, khong phai loi", ma_hang=r["ma_hang"], dung=r["true_qty"], khong_phai_loi=True))
        elif r["tag"] in ("huy", "noi_bo"):
            errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="xuat_khong_phai_ban_" + r["tag"], xu_ly_dung="tru ton nhung KHONG tinh vao nhu cau ban", ma_hang=r["ma_hang"], dung=r["true_qty"], khong_phai_loi=True))
        elif r["tag"] == "dieu_chinh":
            errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="dieu_chinh_kiem_ke", xu_ly_dung="tru ton nhung KHONG tinh vao nhu cau ban", ma_hang=r["ma_hang"], dung=r["true_qty"], khong_phai_loi=True))
        elif r["tag"] == "bulk":
            errors.append(dict(ma_phieu=r["ma_phieu"], loai_loi="don_si_mot_lan", xu_ly_dung="la ban that nhung bat thuong: gan co, loai khoi toc do ban hang thang hoac CAN NGUOI QUYET", ma_hang=r["ma_hang"], dung=r["true_qty"], khong_phai_loi=True))
    deleted_ids = set(id(r) for r in deleted)
    rows_out = [r for r in rows if id(r) not in deleted_ids] + [r for r in []]
    # chen dong trung sau dong goc
    out_rows = []
    dup_map = {}
    for d in dups: dup_map.setdefault(d["ma_phieu"], []).append(d)
    for r in rows_out:
        out_rows.append(r)
        for d in dup_map.get(r["ma_phieu"], []): out_rows.append(d)
    # ---- dinh dang lan lon
    def fmt_date(r):
        day = START + dt.timedelta(days=r["day"])
        if r.get("future"): day = dt.date(2026, 12, min(28, 1 + r["day"] % 20))
        x = rng.random()
        if x < 0.70: return day.isoformat()
        if x < 0.90: return f"{day.day:02d}/{day.month:02d}/{day.year}"
        return f"{day.day}/{day.month}/{str(day.year)[2:]}"
    def fmt_code(c):
        x = rng.random()
        if x < 0.03: return c.lower()
        if x < 0.055: return c[:2] + "-" + c[2:]
        if x < 0.075: return c + " "
        return c
    final = []
    blank_code = 0
    for r in out_rows:
        code = fmt_code(r["ma_hang"]); name = r["ten_hang"]
        if rng.random() < 0.2: name = unaccent(name)
        if r["tag"] == "sale" and blank_code < 4 and rng.random() < 0.002:
            code = ""; name = unaccent(name); blank_code += 1; r["blank_code"] = True
        final.append([r["ma_phieu"], fmt_date(r), r["loai"], code, name, r["so_luong"], r["don_gia"], r["ghi_chu"]])
    with open(HERE / "nhat-ky-xuat-nhap.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["ma_phieu", "ngay", "loai", "ma_hang", "ten_hang", "so_luong", "don_gia", "ghi_chu"]); w.writerows(final)
    # ---- danh muc, ton, tham so
    params = dict(z=1.645, nguong_ton_lau_ngay=120, nguong_ban_cham_thang=3)
    refs = {s["code"]: ref_calc(s, truths[s["code"]], params) for s in skus}
    # gia von hien tai
    with open(HERE / "danh-muc-hang.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["ma_hang", "ten_hang", "nhom", "don_vi", "gia_von_hien_tai", "gia_ban_hien_tai", "quy_cach_dat_boi_so", "thoi_gian_giao_ngay", "nha_cung_cap", "trang_thai", "ghi_chu"])
        for i, s in enumerate(skus):
            price = round(s["cost"] * (1 + s["margin"]) / 500) * 500
            st = "ngung_nhap" if s["extra"] == "ngung" else "dang_ban"
            note = ""
            if s["kind"].startswith("new"): note = f"mat hang moi, ban tu thang {MONTHS[NEWLAUNCH[s['kind']]]}"
            w.writerow([s["code"], s["name"], s["group"], s["unit"], s["cost"], price, s["pack"], s["lead"], SUPPLIERS[s["group"]][i % len(SUPPLIERS[s["group"]])], st, note])
    with open(HERE / "ton-dau-ky-2025-11-01.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["ma_hang", "ton_dau_ky"])
        for s in skus: w.writerow([s["code"], truths[s["code"]]["opening"]])
    with open(HERE / "ton-kiem-ke-2026-10-31.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["ma_hang", "ton_thuc_te_kiem_ke"])
        for s in skus: w.writerow([s["code"], truths[s["code"]]["closing"]])
    with open(HERE / "hang-dang-ve.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f); w.writerow(["ma_hang", "so_luong", "ngay_du_kien_ve"])
        for s in skus:
            for d, q in truths[s["code"]]["on_order"]:
                w.writerow([s["code"], q, (START + dt.timedelta(days=d)).isoformat()])
    total_raw = sum(refs[s["code"]]["qty"] * s["cost"] for s in skus)
    budget = int(round(total_raw * 0.72 / 1_000_000) * 1_000_000)
    tham_so = dict(ngay_cuoi_du_lieu=END.isoformat(), thang_de_xuat="2026-11", thang_giu_lai_do_loi=["2026-09", "2026-10"],
                   muc_phuc_vu=0.95, z_tuong_ung=1.645, ngan_sach_nhap_vnd=budget,
                   nguong_ton_lau_ngay=120, nguong_khong_ban_ngay=90, nguong_ban_cham_don_vi_thang=3, so_ngay_cut_hang_toi_thieu=7,
                   ghi_chu="Du lieu GIA de hoc. Ngan sach la tham so, khong phai so that.")
    (HERE / "tham-so.json").write_text(json.dumps(tham_so, ensure_ascii=False, indent=2), encoding="utf-8")
    # ---- ABC tham chieu
    val = {s["code"]: sum(truths[s["code"]]["sold"][m] - truths[s["code"]]["returns"][m] for m in range(12)) * s["cost"] for s in skus}
    order = sorted(val, key=lambda c: -val[c]); tot = sum(val.values()); cum = 0; abc = {}
    for c in order:
        before = cum / tot
        abc[c] = "A" if before < 0.80 else "B" if before < 0.95 else "C"
        cum += val[c]
    # nhat ky he thong vs kiem ke (ton he thong tinh tu nhat ky tho khong sach)
    amb = sorted(set([r["ma_hang"] for r in rows if r["tag"] in ("bulk", "err_blank", "err_sign", "err_x10")]))
    ans = dict(
        sinh_ngay="2026-11-20", seed=SEED, thang=MONTHS, tham_so=tham_so, params=params,
        sku={s["code"]: dict(ten=s["name"], nhom=s["group"], gia_von=s["cost"], pack=s["pack"], lead=s["lead"], loai=s["kind"], abc=abc[c := s["code"]],
                             gia_tri_nam=val[c], truth_thang=dict(sold=truths[c]["sold"], returns=truths[c]["returns"], bulk=truths[c]["bulk"],
                             lost=truths[c]["lost"], zero_days=truths[c]["zero_days"]), ref=refs[c]) for s in skus},
        loi=errors, sku_mo_ho=amb, tong_tien_chua_cat=total_raw, ngan_sach=budget,
        so_dong_nhat_ky=len(final))
    OUT_ANS.mkdir(exist_ok=True)
    (OUT_ANS / "dap-an.json").write_text(json.dumps(ans, ensure_ascii=False, indent=1), encoding="utf-8")
    spec(tham_so)
    print("dong nhat ky:", len(final), "| ma hang:", len(skus), "| ngan sach:", budget, "| tong tien chua cat:", total_raw)
    from collections import Counter
    print(Counter(r["canh_bao"] for r in refs.values()), Counter(abc.values()))
    print("loi:", Counter(e["loai_loi"] for e in errors))

def spec(tham_so):
    txt = f"""# Quy ước tính toán (giả định) — bài 07

Cửa hàng GIẢ (tạp hóa / vật tư / mỹ phẩm), 60 mã hàng. Dữ liệu 12 tháng: 2025-11 đến 2026-10. Tham số nằm trong `tham-so.json`.

## Làm sạch (agent tự quyết, nhưng phải ghi lại vào loi-du-lieu.csv)
- Nhu cầu bán của tháng = tổng XUAT là bán hàng trong tháng, trừ đi số trả hàng (số âm CÓ ghi chú khách trả).
- Không tính vào nhu cầu: hủy hàng hết hạn, xuất dùng nội bộ, DIEU_CHINH kiểm kê (nhưng vẫn trừ vào tồn).
- Ca không chắc (số âm không ghi chú, số lượng gấp bất thường, thiếu số lượng, đơn sỉ một lần, ngày ở tương lai): ghi CẦN NGƯỜI QUYẾT, không tự bịa.
- Ngày viết lẫn lộn: dd/mm/yyyy, d/m/yy, yyyy-mm-dd (kiểu Việt Nam: ngày trước tháng). Mã hàng viết thường/ có dấu gạch/ khoảng trắng thì chuẩn hóa; dòng thiếu mã thì dò theo tên.

## Công thức cố định (không để mô hình tự đổi)
1. Tồn hệ thống chạy = tồn đầu kỳ + nhập − xuất (đã làm sạch). Ngày "hết hàng" = ngày tồn cuối ngày ≤ 0.
2. Tháng "cụt hàng" = tháng có từ {tham_so["so_ngay_cut_hang_toi_thieu"]} ngày hết hàng trở lên. Doanh số tháng đó bị cụt giả tạo, KHÔNG đưa vào trung bình (coi như thiếu số liệu, không phải 0).
3. Dự báo nhu cầu tháng tới F = trung bình của 3 tháng hợp lệ gần nhất (hợp lệ = đã bán + không cụt hàng). Có ít hơn 3 tháng hợp lệ: lấy trung bình số tháng có và gắn cờ DU_LIEU_NGAN.
4. Độ lệch chuẩn σ (đơn vị/tháng) = độ lệch chuẩn mẫu (n−1) của tối đa 6 tháng hợp lệ gần nhất. Dưới 3 tháng: σ = 0,5 × F (giả định, ghi cờ).
5. Tồn kho an toàn SS = Z × σ × √(T/30), T = thời gian giao (ngày), Z = {tham_so["z_tuong_ung"]} (mức phục vụ {int(tham_so["muc_phuc_vu"]*100)}%). Làm tròn lên. Giả định: thời gian giao cố định (không có dữ liệu độ lệch thời gian giao), nhu cầu các tháng độc lập.
6. Điểm đặt hàng lại ROP = F/30 × T + SS. Làm tròn lên.
7. Số lượng cần nhập (chưa xét ngân sách) = max(0, F + SS − tồn kiểm kê − hàng đang về), làm tròn LÊN theo bội số quy cách đặt.
8. Phân loại ABC theo giá trị tiêu thụ 12 tháng = nhu cầu 12 tháng đã làm sạch × giá vốn hiện tại. Xếp giảm dần. Mặt hàng nào mà tổng giá trị các mặt hàng đứng TRƯỚC nó chưa đạt 80% tổng thì là A, chưa đạt 95% là B, còn lại C.
9. Cảnh báo (mỗi mã đúng một nhãn, ưu tiên từ trên xuống): HET_HANG (tồn kiểm kê = 0) > SAP_HET (0 < tồn ≤ ROP) > TON_LAU (số ngày tồn = tồn / (F/30) > {tham_so["nguong_ton_lau_ngay"]}, hoặc không bán ngày nào trong {tham_so["nguong_khong_ban_ngay"]} ngày cuối mà tồn > 0) > BAN_CHAM (nhu cầu trung bình tháng < {tham_so["nguong_ban_cham_don_vi_thang"]} đơn vị) > OK.
10. Tồn hiện tại để tính = số kiểm kê 2026-10-31 (file ton-kiem-ke). Chênh giữa tồn hệ thống và kiểm kê phải được liệt kê và giải thích bằng lỗi dữ liệu nếu được.

## Dự báo ngây thơ (mốc so sánh) và giữ lại
- Mốc 1: "bằng tháng liền trước" (doanh số thô tháng trước, không làm sạch).
- Mốc 2: "cùng kỳ năm trước": CHỈ có thể làm cho tháng 2026-11 (lấy 2025-11). Không làm được cho hai tháng giữ lại vì chỉ có 12 tháng dữ liệu. Phải nói rõ điều này.
- Giữ lại (hold-out): 2026-09 và 2026-10. Dự báo mỗi tháng chỉ dùng dữ liệu TRƯỚC tháng đó. Đo trên các mã-tháng không bị cụt hàng và có ít nhất 3 tháng hợp lệ trước đó. Chỉ số: MAE (đơn vị) và WAPE = Σ|F−thực| / Σ thực, so với mốc 1.

## Ngân sách
- Tổng tiền vốn = Σ (số lượng đề xuất × giá vốn hiện tại). Không được vượt `ngan_sach_nhap_vnd` trong tham-so.json.
- Nếu số cần nhập chưa xét ngân sách vượt ngân sách: agent đề xuất thứ tự ưu tiên và phần cắt, giải thích; người quyết định số cuối.
"""
    (HERE / "quy-uoc.md").write_text(txt, encoding="utf-8")

if __name__ == "__main__":
    main()
