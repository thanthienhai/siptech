#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
tinh_cong.py - kiểm tra chấm công tháng 09/2026 theo quy_dinh_cong_ty.md.

Đọc (trong thư mục hiện tại): cham_cong.csv, nhan_vien.csv, lich_ca_xoay.csv, nghi_phep.csv
Ghi   (trong thư mục hiện tại): bang_cong_ngay.csv, bat_thuong.csv, tong_hop_nguoi.csv
Không sửa dữ liệu gốc. Mọi phép tính giờ nằm trong tệp này.

Cách dùng:  python tinh_cong.py
"""
import csv
import re
import sys
from collections import defaultdict, Counter
from datetime import datetime, date, timedelta

# ----------------------------------------------------------------------------
# THAM SỐ - nguồn duy nhất là quy_dinh_cong_ty.md (số mục ghi bên cạnh)
# ----------------------------------------------------------------------------
KY_TU = date(2026, 9, 1)                       # mục 1
KY_DEN = date(2026, 9, 30)
NGAY_LE = {date(2026, 9, 1), date(2026, 9, 2)}  # mục 2
CA = {                                          # mục 2: (giờ vào, giờ ra) tính bằng phút từ 00:00
    "HC": (8 * 60, 17 * 60),
    "S": (6 * 60, 14 * 60),
    "C": (14 * 60, 22 * 60),
}
NGHI_TRUA = (12 * 60, 13 * 60)                  # mục 2: chỉ trừ ở ca HC
DUNG_SAI = 5                                    # mục 4: trễ/sớm ĐÚNG 5 phút vẫn đủ
TRUNG_PHUT = 3                                  # mục 4: quẹt trùng cùng máy <= 3 phút
QUET_HO_PHUT = 10                               # mục 4: hai máy khác nhau <= 10 phút
OT_TOI_THIEU = 30                               # mục 4: ra muộn >= 30 phút mới tính
OT_NGAY_MAX = 180                               # mục 4: > 180 phút thì cảnh báo
OT_THANG_MAX = 2400                             # mục 4: > 2400 phút thì cảnh báo
DON_LE_PHUT = 120                               # mục 4: quẹt đơn lẻ, cửa sổ 120 phút

TRANG_THAI_HOP_LE = {"OK", "PHEP", "NGHI", "CHO_XAC_NHAN"}
LOAI_KHONG_CAN_QUYET = {"QUET_TRUNG", "DI_TRE", "VE_SOM"}   # mục 7
CAN_NGUOI_QUYET = "CẦN NGƯỜI QUYẾT"

F_CHAM_CONG = "cham_cong.csv"
F_NHAN_VIEN = "nhan_vien.csv"
F_LICH = "lich_ca_xoay.csv"
F_PHEP = "nghi_phep.csv"
OUT_NGAY = "bang_cong_ngay.csv"
OUT_BT = "bat_thuong.csv"
OUT_TH = "tong_hop_nguoi.csv"


# ----------------------------------------------------------------------------
# Tiện ích
# ----------------------------------------------------------------------------
def hm(phut):
    """Số phút từ 00:00 -> 'HH:MM'."""
    return "%02d:%02d" % (phut // 60, phut % 60)


def daterange(a, b):
    d = a
    while d <= b:
        yield d
        d += timedelta(days=1)


def doc_csv(ten):
    with open(ten, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def phan_tich_gio(s):
    """Trả về datetime (đã bỏ giây) hoặc None nếu trống / không hợp lệ.
    Hai định dạng: yyyy-mm-dd hh:mm:ss (máy A), dd/mm/yyyy hh:mm (máy B)."""
    s = (s or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M"):
        try:
            return datetime.strptime(s, fmt).replace(second=0, microsecond=0)
        except ValueError:
            continue
    return None


def phan_tich_ngay_phep(s):
    try:
        return datetime.strptime((s or "").strip(), "%d/%m/%Y").date()
    except ValueError:
        return None


def phut_trong_ngay(dt):
    return dt.hour * 60 + dt.minute


# ----------------------------------------------------------------------------
# Tính giờ công một ngày làm việc có >= 2 quẹt (mục 5, bước 3-5)
# ----------------------------------------------------------------------------
def tinh_ngay(loai, vao, ra):
    """vao, ra: phút trong ngày. Trả về dict phut_tre, phut_ve_som, ot_phut, gio_cong (phút)."""
    ca_vao, ca_ra = CA[loai]
    tre = vao - ca_vao
    phut_tre = tre if tre > DUNG_SAI else 0
    som = ca_ra - ra
    phut_ve_som = som if som > DUNG_SAI else 0
    ot = ra - ca_ra
    ot_phut = ot if ot >= OT_TOI_THIEU else 0

    bat_dau = ca_vao if vao <= ca_vao + DUNG_SAI else vao
    ket_thuc = ca_ra if ra >= ca_ra - DUNG_SAI else min(ra, ca_ra)
    phut_cong = max(0, ket_thuc - bat_dau)
    if loai == "HC" and phut_cong > 0:
        giao = min(ket_thuc, NGHI_TRUA[1]) - max(bat_dau, NGHI_TRUA[0])
        if giao > 0:
            phut_cong -= giao
    return {"phut_tre": phut_tre, "phut_ve_som": phut_ve_som,
            "ot_phut": ot_phut, "phut_cong": phut_cong}


# ----------------------------------------------------------------------------
# Giải thích cho quản lý (tiếng Việt, không đoán nguyên nhân)
# ----------------------------------------------------------------------------
KIEM_VAN_BAN = "Cách tính cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."


def giai_thich(loai, ma, **k):
    if loai == "THIEU_RA":
        return ("%s chỉ có một quẹt trong ngày, nằm trong khung đầu ca nên được coi là quẹt vào; không có quẹt ra. "
                "Nên hỏi người quản lý trực tiếp giờ ra thực tế rồi bổ sung, chương trình chưa tính giờ công ngày này." % ma)
    if loai == "THIEU_VAO":
        return ("%s chỉ có một quẹt trong ngày, nằm trong khung cuối ca nên được coi là quẹt ra; không có quẹt vào. "
                "Nên hỏi người quản lý trực tiếp giờ vào thực tế rồi bổ sung, chương trình chưa tính giờ công ngày này." % ma)
    if loai == "THIEU_KHONG_RO":
        return ("%s chỉ có một quẹt và giờ quẹt không rơi vào khung đầu ca hay cuối ca, nên chương trình không xác định được là quẹt vào hay quẹt ra. "
                "Cần người có thẩm quyền xác nhận giờ vào/ra thực tế." % ma)
    if loai == "QUET_TRUNG":
        return ("%s có các quẹt cùng máy cách nhau không quá %d phút; chương trình giữ quẹt đầu và bỏ quẹt sau theo quy định. "
                "Chỉ để quản lý biết, không cần xử lý." % (ma, TRUNG_PHUT))
    if loai == "DI_TRE":
        return ("%s vào muộn hơn giờ vào ca quá dung sai %d phút. Chỉ ghi nhận số liệu; "
                "nếu có lý do đã được duyệt thì quản lý ghi chú vào bảng công." % (ma, DUNG_SAI))
    if loai == "VE_SOM":
        return ("%s ra sớm hơn giờ ra ca quá dung sai %d phút. Chỉ ghi nhận số liệu; "
                "nếu có lý do đã được duyệt thì quản lý ghi chú vào bảng công." % (ma, DUNG_SAI))
    if loai == "OT_VUOT_NGUONG":
        return ("%s có số phút làm thêm trong ngày vượt ngưỡng %d phút của công ty. Nên kiểm xem ngày này có phê duyệt làm thêm giờ chưa. %s"
                % (ma, OT_NGAY_MAX, KIEM_VAN_BAN))
    if loai == "OT_THANG_VUOT":
        return ("Tổng phút làm thêm của các ngày làm việc thường (đã tính giờ) của %s trong tháng vượt ngưỡng %d phút của công ty; "
                "chưa gồm các ngày đang chờ xác nhận. Nên kiểm lại phê duyệt làm thêm giờ cả tháng. %s" % (ma, OT_THANG_MAX, KIEM_VAN_BAN))
    if loai == "VANG_CHUA_GHI":
        return ("%s không có quẹt nào trong ngày làm việc này và không có đơn nghỉ đã duyệt. "
                "Nên kiểm với quản lý trực tiếp xem ngày này có đi làm không, rồi bổ sung giờ hoặc đơn nghỉ nếu cần." % ma)
    if loai == "LAM_NGAY_LE":
        return ("%s có quẹt vào ngày lễ công ty đã khai báo; chương trình không tính giờ công thường cho ngày này. "
                "Nên xác nhận ngày này có được phân công làm không. %s" % (ma, KIEM_VAN_BAN))
    if loai == "LAM_NGAY_NGHI":
        return ("%s có quẹt vào ngày nghỉ theo ca/lịch; chương trình không tính giờ công thường cho ngày này. "
                "Nên xác nhận ngày này có được phân công làm không. %s" % (ma, KIEM_VAN_BAN))
    if loai == "NGHI_QUET_HO":
        return ("%s có hai quẹt ở hai máy khác nhau cách nhau không quá %d phút. Đây chỉ là dấu hiệu cần kiểm; chương trình không kết luận gì về nguyên nhân. "
                "Đề nghị người có thẩm quyền xác minh, chương trình chưa tính giờ công ngày này." % (ma, QUET_HO_PHUT))
    if loai == "CO_PHEP_NHUNG_QUET":
        return ("%s có đơn nghỉ phép đã duyệt cho ngày này nhưng vẫn có quẹt; chương trình chưa tính giờ. "
                "Cần xác nhận ngày này tính là nghỉ hay đi làm. %s" % (ma, KIEM_VAN_BAN))
    if loai == "DU_LIEU_LOI":
        return k["noi_dung"]
    raise ValueError(loai)


# ----------------------------------------------------------------------------
# Chương trình chính
# ----------------------------------------------------------------------------
def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    nhan_vien = doc_csv(F_NHAN_VIEN)
    ds_ma = [r["ma_nv"].strip() for r in nhan_vien]
    nv = {r["ma_nv"].strip(): {"chi_nhanh": r["chi_nhanh"].strip(), "loai_ca": r["loai_ca"].strip()} for r in nhan_vien}

    # --- lịch xoay ---------------------------------------------------------
    lich = {}
    for r in doc_csv(F_LICH):
        d = phan_tich_ngay_phep(r["ngay"])
        ca = r["ca"].strip()
        if d is None or ca not in ("S", "C", "OFF"):
            print("CẢNH BÁO: dòng lịch xoay không hợp lệ, bỏ qua:", r)
            continue
        lich[(r["ma_nv"].strip(), d)] = ca

    # --- đơn nghỉ phép đã duyệt -------------------------------------------
    nghi_phep = defaultdict(set)   # ma_nv -> tập ngày
    for r in doc_csv(F_PHEP):
        if r["trang_thai"].strip() != "Đã duyệt":
            print("CẢNH BÁO: đơn nghỉ chưa ở trạng thái 'Đã duyệt', bỏ qua:", r)
            continue
        a, b = phan_tich_ngay_phep(r["tu_ngay"]), phan_tich_ngay_phep(r["den_ngay"])
        if a is None or b is None or b < a:
            print("CẢNH BÁO: đơn nghỉ có ngày không hợp lệ, bỏ qua:", r)
            continue
        for d in daterange(a, b):
            nghi_phep[r["ma_nv"].strip()].add(d)

    # --- đọc quẹt, tách dữ liệu lỗi ---------------------------------------
    bat_thuong = {}   # (ma_nv, ngay, loai) -> {"chi_tiet": [..], "giai_thich": str}

    def them_bt(ma, ngay, loai, chi_tiet, gt=None):
        key = (ma, ngay, loai)
        if key not in bat_thuong:
            bat_thuong[key] = {"chi_tiet": [], "giai_thich": gt}
        bat_thuong[key]["chi_tiet"].append(chi_tiet)

    quet = defaultdict(list)   # (ma_nv, date) -> [ {t, may, dong} ]
    with open(F_CHAM_CONG, encoding="utf-8-sig", newline="") as f:
        for i, r in enumerate(csv.DictReader(f), start=2):  # dòng 1 là tiêu đề
            ma = (r["ma_nv"] or "").strip()
            raw = (r["thoi_gian"] or "")
            t = phan_tich_gio(raw)
            if t is None:
                lydo = "thời gian trống" if not raw.strip() else "thời gian '%s' không phải ngày giờ hợp lệ" % raw.strip()
                them_bt(ma, "", "DU_LIEU_LOI",
                        "dòng %d của cham_cong.csv (%s): %s; không dùng để tính; %s" % (i, r["ma_may"], lydo, CAN_NGUOI_QUYET),
                        "Có một dòng quẹt của %s với %s nên không xác định được ngày giờ. Cần kiểm lại dữ liệu gốc từ máy chấm công, chương trình không dùng dòng này." % (ma, lydo))
                continue
            if ma not in nv:
                them_bt(ma, t.strftime("%Y-%m-%d"), "DU_LIEU_LOI",
                        "dòng %d của cham_cong.csv (%s, %s): mã %s không có trong nhan_vien.csv; không dùng để tính; %s"
                        % (i, r["ma_may"], t.strftime("%H:%M"), ma, CAN_NGUOI_QUYET),
                        "Có quẹt mang mã %s không nằm trong danh sách nhân viên. Cần kiểm lại mã trên máy chấm công hoặc danh sách nhân viên; chương trình không dùng quẹt này." % ma)
                continue
            if not (KY_TU <= t.date() <= KY_DEN):
                them_bt(ma, t.strftime("%Y-%m-%d"), "DU_LIEU_LOI",
                        "dòng %d của cham_cong.csv: ngày %s nằm ngoài kỳ 2026-09-01..2026-09-30; không dùng để tính; %s"
                        % (i, t.strftime("%Y-%m-%d"), CAN_NGUOI_QUYET),
                        "Có quẹt của %s nằm ngoài kỳ chấm công tháng 09/2026. Cần kiểm lại dữ liệu gốc; chương trình không dùng quẹt này." % ma)
                continue
            quet[(ma, t.date())].append({"t": t, "may": r["ma_may"].strip(), "dong": i})

    # --- thông tin phụ: quẹt ở máy khác chi nhánh (quy định không coi là lỗi) ---
    may_chi_nhanh = {"MAY-A1": "A", "MAY-B1": "B"}
    khac_chi_nhanh = []
    for (ma, d), ds in sorted(quet.items()):
        for q in ds:
            if may_chi_nhanh.get(q["may"]) not in (None, nv[ma]["chi_nhanh"]):
                khac_chi_nhanh.append((ma, d.isoformat(), q["may"], q["t"].strftime("%H:%M"), nv[ma]["chi_nhanh"]))

    # --- bảng công từng ngày ----------------------------------------------
    rows_ngay = []
    for ma in ds_ma:
        loai_ca = nv[ma]["loai_ca"]
        for d in daterange(KY_TU, KY_DEN):
            # 1) loại ngày
            if d in NGAY_LE:
                loai = "LE"
            elif loai_ca == "HC":
                loai = "HC" if d.weekday() < 5 else "OFF"
            else:
                loai = lich.get((ma, d))   # S / C / OFF / None
            ngay = d.isoformat()
            row = {"ma_nv": ma, "ngay": ngay, "loai_ngay": loai or "", "gio_vao": "", "gio_ra": "",
                   "gio_cong": "", "phut_tre": "", "phut_ve_som": "", "ot_phut": "", "trang_thai": ""}

            # 2) bỏ quẹt trùng (cùng máy, <= 3 phút so với quẹt đang giữ), ghi QUET_TRUNG
            ds = sorted(quet.get((ma, d), []), key=lambda q: (q["t"], q["dong"]))
            giu, bo = [], []
            for q in ds:
                truoc = [g for g in giu if g["may"] == q["may"]]
                if truoc and (q["t"] - truoc[-1]["t"]) <= timedelta(minutes=TRUNG_PHUT):
                    bo.append((q, truoc[-1]))
                else:
                    giu.append(q)
            for q, g in bo:
                them_bt(ma, ngay, "QUET_TRUNG",
                        "%s quẹt lúc %s bị bỏ vì cách quẹt giữ lại lúc %s %d phút" %
                        (q["may"], q["t"].strftime("%H:%M"), g["t"].strftime("%H:%M"),
                         int((q["t"] - g["t"]).total_seconds() // 60)))
            gio = [phut_trong_ngay(q["t"]) for q in giu]
            tom_tat_quet = ", ".join("%s %s" % (q["may"], q["t"].strftime("%H:%M")) for q in giu)

            # 3) nghi quẹt hộ: hai máy khác nhau, <= 10 phút, cùng ngày
            cap_ho = []
            for a in range(len(giu)):
                for b in range(a + 1, len(giu)):
                    if giu[a]["may"] != giu[b]["may"]:
                        kc = int((giu[b]["t"] - giu[a]["t"]).total_seconds() // 60)
                        if kc <= QUET_HO_PHUT:
                            cap_ho.append((giu[a], giu[b], kc))

            def ghi_quet_ho():
                for a, b, kc in cap_ho:
                    them_bt(ma, ngay, "NGHI_QUET_HO",
                            "quẹt %s lúc %s và %s lúc %s, cách nhau %d phút; %s" %
                            (a["may"], a["t"].strftime("%H:%M"), b["may"], b["t"].strftime("%H:%M"), kc, CAN_NGUOI_QUYET))

            def dien_gio_vao_ra():
                if len(gio) >= 2 and not cap_ho:
                    row["gio_vao"], row["gio_ra"] = hm(gio[0]), hm(gio[-1])

            # 4) phân loại
            if loai is None:
                # lịch xoay thiếu ngày này: không đoán
                row["trang_thai"] = "CHO_XAC_NHAN"
                them_bt(ma, ngay, "DU_LIEU_LOI",
                        "lich_ca_xoay.csv không có dòng cho %s ngày %s; %s" % (ma, ngay, CAN_NGUOI_QUYET),
                        "Không tìm thấy ca của %s ngày này trong lịch ca xoay nên không xác định được ca. Cần bổ sung lịch ca." % ma)
                rows_ngay.append(row)
                continue

            if loai in ("LE", "OFF"):
                if giu:
                    ten = "LAM_NGAY_LE" if loai == "LE" else "LAM_NGAY_NGHI"
                    them_bt(ma, ngay, ten, "ngày %s có %d quẹt: %s; không tính giờ công thường; %s" %
                            ("lễ" if loai == "LE" else "nghỉ", len(giu), tom_tat_quet, CAN_NGUOI_QUYET))
                    ghi_quet_ho()
                    dien_gio_vao_ra()
                    row["trang_thai"] = "CHO_XAC_NHAN"
                else:
                    row["trang_thai"] = "NGHI"
                rows_ngay.append(row)
                continue

            # ngày làm việc (HC, S, C)
            ca_vao, ca_ra = CA[loai]
            co_phep = d in nghi_phep.get(ma, set())
            if co_phep:
                if giu:
                    them_bt(ma, ngay, "CO_PHEP_NHUNG_QUET",
                            "ngày thuộc đơn nghỉ phép đã duyệt nhưng có %d quẹt: %s; không tính giờ; %s" %
                            (len(giu), tom_tat_quet, CAN_NGUOI_QUYET))
                    ghi_quet_ho()
                    dien_gio_vao_ra()
                    row["trang_thai"] = "CHO_XAC_NHAN"
                else:
                    row["trang_thai"] = "PHEP"
                rows_ngay.append(row)
                continue

            if not giu:
                them_bt(ma, ngay, "VANG_CHUA_GHI",
                        "ngày làm việc ca %s không có quẹt và không có đơn nghỉ đã duyệt" % loai)
                row["trang_thai"] = "CHO_XAC_NHAN"
                rows_ngay.append(row)
                continue

            if cap_ho:
                ghi_quet_ho()
                row["trang_thai"] = "CHO_XAC_NHAN"
                rows_ngay.append(row)
                continue

            if len(giu) == 1:
                g = gio[0]
                sau_trung = " (sau khi bỏ quẹt trùng)" if bo else ""
                if g <= ca_vao + DON_LE_PHUT:
                    them_bt(ma, ngay, "THIEU_RA",
                            "chỉ có quẹt lúc %s%s, coi là quẹt vào (<= %s); thiếu quẹt ra" % (hm(g), sau_trung, hm(ca_vao + DON_LE_PHUT)))
                    row["gio_vao"] = hm(g)
                elif g >= ca_ra - DON_LE_PHUT:
                    them_bt(ma, ngay, "THIEU_VAO",
                            "chỉ có quẹt lúc %s%s, coi là quẹt ra (>= %s); thiếu quẹt vào" % (hm(g), sau_trung, hm(ca_ra - DON_LE_PHUT)))
                    row["gio_ra"] = hm(g)
                else:
                    them_bt(ma, ngay, "THIEU_KHONG_RO",
                            "chỉ có quẹt lúc %s%s, nằm giữa %s và %s nên không xác định vào hay ra; %s" %
                            (hm(g), sau_trung, hm(ca_vao + DON_LE_PHUT), hm(ca_ra - DON_LE_PHUT), CAN_NGUOI_QUYET))
                row["trang_thai"] = "CHO_XAC_NHAN"
                rows_ngay.append(row)
                continue

            # >= 2 quẹt: tính giờ
            vao, ra = gio[0], gio[-1]
            kq = tinh_ngay(loai, vao, ra)
            row.update({"gio_vao": hm(vao), "gio_ra": hm(ra),
                        "gio_cong": "%.2f" % round(kq["phut_cong"] / 60.0, 2),
                        "phut_tre": kq["phut_tre"], "phut_ve_som": kq["phut_ve_som"],
                        "ot_phut": kq["ot_phut"], "trang_thai": "OK"})
            if kq["phut_tre"] > 0:
                them_bt(ma, ngay, "DI_TRE", "vào %s, trễ %d phút (ca %s vào %s)" % (hm(vao), kq["phut_tre"], loai, hm(ca_vao)))
            if kq["phut_ve_som"] > 0:
                them_bt(ma, ngay, "VE_SOM", "ra %s, về sớm %d phút (ca %s ra %s)" % (hm(ra), kq["phut_ve_som"], loai, hm(ca_ra)))
            if kq["ot_phut"] > OT_NGAY_MAX:
                them_bt(ma, ngay, "OT_VUOT_NGUONG",
                        "ra %s, làm thêm %d phút (%.2f giờ), vượt ngưỡng %d phút" %
                        (hm(ra), kq["ot_phut"], kq["ot_phut"] / 60.0, OT_NGAY_MAX))
            rows_ngay.append(row)

    # --- làm thêm trong tháng (chỉ ngày làm việc thường đã tính giờ) --------
    ot_thang = defaultdict(int)
    for r in rows_ngay:
        if r["trang_thai"] == "OK":
            ot_thang[r["ma_nv"]] += r["ot_phut"]
    for ma in ds_ma:
        if ot_thang[ma] > OT_THANG_MAX:
            them_bt(ma, "THANG", "OT_THANG_VUOT",
                    "tổng làm thêm %d phút (%.2f giờ) trong tháng, vượt ngưỡng %d phút" %
                    (ot_thang[ma], ot_thang[ma] / 60.0, OT_THANG_MAX))

    # --- kiểm tính nhất quán trước khi ghi ---------------------------------
    assert len(rows_ngay) == len(ds_ma) * 30, "thiếu dòng bảng công"
    assert all(r["trang_thai"] in TRANG_THAI_HOP_LE for r in rows_ngay)

    # --- ghi bang_cong_ngay.csv --------------------------------------------
    cot_ngay = ["ma_nv", "ngay", "loai_ngay", "gio_vao", "gio_ra", "gio_cong",
                "phut_tre", "phut_ve_som", "ot_phut", "trang_thai"]
    with open(OUT_NGAY, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cot_ngay, lineterminator="\n")
        w.writeheader()
        w.writerows(rows_ngay)

    # --- ghi bat_thuong.csv ------------------------------------------------
    def khoa_sap(k):
        ma, ngay, loai = k
        if ngay == "THANG":
            n = "9999"
        elif ngay == "":
            n = "9998"
        else:
            n = ngay
        return (ma, n, loai)

    cot_bt = ["ma_nv", "ngay", "loai", "chi_tiet", "can_nguoi_quyet", "giai_thich"]
    ds_bt = []
    for k in sorted(bat_thuong, key=khoa_sap):
        ma, ngay, loai = k
        v = bat_thuong[k]
        chi_tiet = "; ".join(v["chi_tiet"])
        if v["giai_thich"] is not None:
            gt = v["giai_thich"]
        else:
            gt = giai_thich(loai, ma, noi_dung="")
        ds_bt.append({"ma_nv": ma, "ngay": ngay, "loai": loai, "chi_tiet": chi_tiet,
                      "can_nguoi_quyet": "KHONG" if loai in LOAI_KHONG_CAN_QUYET else "CO",
                      "giai_thich": gt})
    with open(OUT_BT, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cot_bt, lineterminator="\n")
        w.writeheader()
        w.writerows(ds_bt)

    # --- ghi tong_hop_nguoi.csv --------------------------------------------
    cot_th = ["ma_nv", "ngay_cong", "tong_gio_cong", "so_lan_tre", "tong_phut_tre", "so_lan_ve_som",
              "tong_phut_ve_som", "tong_ot_gio", "so_ngay_phep", "so_ngay_vang_chua_ghi",
              "so_ngay_cho_xac_nhan", "so_bat_thuong"]
    vang = Counter(b["ma_nv"] for b in ds_bt if b["loai"] == "VANG_CHUA_GHI")
    so_bt = Counter(b["ma_nv"] for b in ds_bt)
    ds_th = []
    for ma in ds_ma:
        rs = [r for r in rows_ngay if r["ma_nv"] == ma]
        ok = [r for r in rs if r["trang_thai"] == "OK"]
        # gio_cong cộng từ số đã làm tròn 2 chữ số của từng ngày, để khớp bảng công ngày
        tong_cong = sum(round(float(r["gio_cong"]) * 100) for r in ok) / 100.0
        ds_th.append({
            "ma_nv": ma,
            "ngay_cong": len(ok),
            "tong_gio_cong": "%.2f" % tong_cong,
            "so_lan_tre": sum(1 for r in ok if r["phut_tre"] > 0),
            "tong_phut_tre": sum(r["phut_tre"] for r in ok),
            "so_lan_ve_som": sum(1 for r in ok if r["phut_ve_som"] > 0),
            "tong_phut_ve_som": sum(r["phut_ve_som"] for r in ok),
            "tong_ot_gio": "%.2f" % round(sum(r["ot_phut"] for r in ok) / 60.0, 2),
            "so_ngay_phep": sum(1 for r in rs if r["trang_thai"] == "PHEP"),
            "so_ngay_vang_chua_ghi": vang[ma],
            "so_ngay_cho_xac_nhan": sum(1 for r in rs if r["trang_thai"] == "CHO_XAC_NHAN"),
            "so_bat_thuong": so_bt[ma],
        })
    with open(OUT_TH, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cot_th, lineterminator="\n")
        w.writeheader()
        w.writerows(ds_th)

    # --- tóm tắt ra màn hình -------------------------------------------------
    print("=== TÓM TẮT (số dòng dữ liệu, không tính dòng tiêu đề) ===")
    print("%-22s %d" % (OUT_NGAY, len(rows_ngay)))
    print("%-22s %d" % (OUT_BT, len(ds_bt)))
    print("%-22s %d" % (OUT_TH, len(ds_th)))
    print("\n=== SỐ BẤT THƯỜNG THEO LOẠI ===")
    dem = Counter(b["loai"] for b in ds_bt)
    for loai in ["THIEU_RA", "THIEU_VAO", "THIEU_KHONG_RO", "QUET_TRUNG", "DI_TRE", "VE_SOM", "OT_VUOT_NGUONG",
                 "OT_THANG_VUOT", "VANG_CHUA_GHI", "LAM_NGAY_LE", "LAM_NGAY_NGHI", "NGHI_QUET_HO",
                 "CO_PHEP_NHUNG_QUET", "DU_LIEU_LOI"]:
        print("%-22s %d" % (loai, dem.get(loai, 0)))
    print("%-22s %d" % ("TỔNG", len(ds_bt)))
    print("\n=== TRẠNG THÁI NGÀY ===")
    for k, v in sorted(Counter(r["trang_thai"] for r in rows_ngay).items()):
        print("%-22s %d" % (k, v))
    print("\n=== THÔNG TIN PHỤ (quy định không coi là lỗi, không ghi vào bat_thuong.csv) ===")
    print("Quẹt ở máy khác chi nhánh của nhân viên: %d" % len(khac_chi_nhanh))
    for x in khac_chi_nhanh:
        print("  %s %s %s %s (chi nhánh của NV: %s)" % x)
    print("Tổng phút làm thêm trong tháng, người cao nhất: %s" %
          ", ".join("%s=%d" % (m, p) for m, p in sorted(ot_thang.items(), key=lambda x: -x[1])[:3]))


if __name__ == "__main__":
    main()
