"""Giả danh (pseudonymize) danh bạ trước khi đưa cho agent đám mây. Chạy trên MÁY BẠN.

Chạy:  python -X utf8 an_danh.py <danh-ba-goc.xlsx> <thư_mục_ra>
Ra:    <thư_mục_ra>/danh-ba-goc.xlsx   bản đã giả danh (cùng cột, cùng Mã dòng) — chỉ file này được đưa cho agent
       <thư_mục_ra>/bang-tra-nguoc.csv  bảng thật <-> giả — GIỮ Ở MÁY BẠN, KHÔNG đưa cho agent

Cách giả danh (có chủ đích giữ lại "quan hệ" để script gộp vẫn chạy được):
  Họ tên   từng từ (bỏ dấu, hoa/thường) -> một từ giả, giữ chữ cái đầu, giữ nguyên danh xưng đầu tên
           (anh/chị/cô/chú/bác/a/c) và chữ viết tắt một chữ cái ("K.")
  SĐT      cùng một số thật -> cùng một số giả; giữ nguyên "hình dạng" (+84, dấu cách, số 0 đầu, độ dài)
  Email    cùng email thật (không phân biệt hoa/thường) -> cùng phần tên giả; giữ nguyên tên miền và các lỗi (@@, .con)
  Địa chỉ  đổi số và tên đường thành từ/số giả, giữ nguyên P., Q., TP, HCM, HN...
  Ghi chú  chỉ đổi SĐT/email nằm trong ghi chú; chữ còn lại giữ nguyên (HÃY ĐỌC LẠI trước khi dùng với dữ liệu thật)
Không dùng số ngẫu nhiên: đánh số theo thứ tự xuất hiện, nên chạy lại ra đúng kết quả cũ.
Giới hạn: bản giả danh mất dấu tiếng Việt trong tên, mất dạng Unicode NFD; địa chỉ còn tên thành phố.
"""
import csv, re, sys, unicodedata
from pathlib import Path
import openpyxl

KEEP_DANH_XUNG = {"anh", "chi", "co", "chu", "bac", "a", "c"}
KEEP_DIA_CHI = {"p", "q", "f", "tp", "tphcm", "hcm", "hn", "dn", "ct", "hp", "phuong", "quan", "thanh", "pho",
                "duong", "d", "so", "ho", "chi", "minh", "ha", "noi", "da", "nang", "can", "tho", "hai", "phong"}
CV = ("bcdfghklmnprstvz", "aeiou")  # 16 phụ âm x 5 nguyên âm x 16 x 5 = 6400 từ giả khác nhau


def strip_dia(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def code4(i):
    """Số thứ tự -> từ giả 4 chữ cái (phụ âm, nguyên âm, phụ âm, nguyên âm), tối đa 6.400 từ khác nhau."""
    c1, v1, c2, v2 = i % 16, (i // 16) % 5, (i // 80) % 16, (i // 1280) % 5
    return CV[0][c1] + CV[1][v1] + CV[0][c2] + CV[1][v2]


class Map:
    """Cùng khóa -> cùng giá trị giả; đánh số theo thứ tự xuất hiện."""
    def __init__(self, kind, rows):
        self.kind, self.d, self.rows = kind, {}, rows

    def get(self, key, make):
        if key not in self.d:
            self.d[key] = make(len(self.d) + 1)
            self.rows.append((self.kind, key, self.d[key]))
        return self.d[key]


rows_tra = []
M = {k: Map(k, rows_tra) for k in ("tu", "sdt", "email", "so")}


def case_like(src, new):
    if src.isupper() and len(src) > 1:
        return new.upper()
    if src.islower():
        return new.lower()
    return new[:1].upper() + new[1:].lower()


def fake_word(w):
    k = strip_dia(w).lower()
    first = strip_dia(w)[:1].lower() or "x"
    return case_like(w, M["tu"].get(k, lambda i: first + code4(i)))


def an_ten(s):
    s = unicodedata.normalize("NFC", s)
    parts = re.split(r"(\s+)", s)
    words = [i for i, p in enumerate(parts) if p.strip()]
    out = list(parts)
    for n, i in enumerate(words):
        w = parts[i]
        base = strip_dia(w).lower().strip(".")
        if len(base) <= 1:
            continue                                   # chữ viết tắt một chữ cái ("K.")
        if n == 0 and len(words) >= 2 and base in KEEP_DANH_XUNG:
            continue                                   # danh xưng đầu tên
        out[i] = re.sub(r"[^\W\d_]+", lambda m: fake_word(m.group(0)), w)
    return "".join(out)


def an_sdt_chuoi(s):
    digits = re.sub(r"\D", "", s)
    if len(digits) < 6:
        return s
    p = "0084" if digits.startswith("0084") else "84" if (digits.startswith("84") and len(digits) >= 11) else "0" if digits.startswith("0") else ""
    core = digits[len(p):]

    def make(i):
        n = len(core) - 1                               # giữ chữ số đầu (đầu số) và độ dài
        return core[:1] + (str((i * 7919 + 1000003) % 10 ** n).zfill(n) if n > 0 else "")
    fake = p + M["sdt"].get(core, make)
    it = iter(fake)
    return re.sub(r"\d", lambda m: next(it), s)


PHONE_RE = re.compile(r"\+?\d[\d .\-]{6,}\d")


def an_email_chuoi(s):
    m = re.search(r"(example[.,]\w+)\s*$", s, re.I) if "@" not in s else None
    if "@" in s:
        local, rest = s.split("@", 1)
        rest = "@" + rest
    elif m:
        local, rest = s[:m.start()], s[m.start():]
    else:
        return s
    lead = local[:len(local) - len(local.lstrip())]
    core = local.strip()
    new = M["email"].get(core.lower(), lambda i: "u" + code4(i) + str(i))
    return lead + case_like(core, new) + rest


def an_dia_chi(s):
    def tok(m):
        t = m.group(0)
        if t.isdigit():
            return M["so"].get(t, lambda i: str((int(t) * 37 + i * 11) % (10 ** len(t))).zfill(len(t)))
        b = strip_dia(t).lower()
        if b in KEEP_DIA_CHI or len(b) <= 1:
            return t
        return fake_word(t)
    return re.sub(r"[^\W\d_]+|\d+", tok, unicodedata.normalize("NFC", s))


def an_o(col, v):
    if v is None or str(v).strip() == "":
        return v
    s = str(v)
    if col == "Họ tên":
        return an_dia_chi(s) if re.search(r"\d", s) else an_ten(s)    # tên-địa chỉ đổi chỗ: ô tên chứa địa chỉ
    if col in ("SĐT", "Email", "Ghi chú"):
        if re.search(r"example[.,]", s, re.I) or "@" in s:
            return an_email_chuoi(s)
        return PHONE_RE.sub(lambda m: an_sdt_chuoi(m.group(0)), s)
    if col == "Địa chỉ":
        return an_ten(s) if not re.search(r"\d", s) and "," not in s and len(s.split()) <= 4 else an_dia_chi(s)
    return v


def main(src, out):
    out = Path(out); out.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.load_workbook(src); ws = wb.active
    rows = list(ws.iter_rows(values_only=True)); head = list(rows[0])
    new = openpyxl.Workbook(); w = new.active; w.title = ws.title; w.append(head)
    for r in rows[1:]:
        if not r[0]:
            continue
        w.append([r[i] if head[i] in ("Mã dòng", "Nguồn") else an_o(head[i], r[i]) for i in range(len(head))])
    new.save(out / "danh-ba-goc.xlsx")
    with open(out / "bang-tra-nguoc.csv", "w", encoding="utf-8-sig", newline="") as f:
        cw = csv.writer(f); cw.writerow(["loai", "gia_tri_that", "gia_tri_gia"]); cw.writerows(rows_tra)
    print(f"Đã ghi {out / 'danh-ba-goc.xlsx'} ({len(rows) - 1} dòng) và {out / 'bang-tra-nguoc.csv'} ({len(rows_tra)} cặp)")
    print("CHỈ đưa danh-ba-goc.xlsx cho agent. bang-tra-nguoc.csv ở lại máy bạn.")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
