import pandas as pd
import openpyxl, re, csv, unicodedata

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

# Load orders
df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
df_orders['amount'] = df_orders['Tổng phải thu'].apply(clean_amount)
df_orders['kh_clean'] = df_orders['Khách hàng'].apply(strip_accents).str.upper()

# Load sao ke
with open('sao-ke-t10-2026.csv', encoding='utf-8-sig') as f:
    rows = list(csv.reader(f))

txs = [r for r in rows[8:] if r and r[0] and 'Tong phat sinh' not in r[0] and 'So du cuoi' not in r[0]]

# Let's write full matching logic and inspect all unmatched orders
print("Running complete matching analysis...")
