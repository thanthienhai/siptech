"""So hai bản bao-cao.md (hai lần chạy) bằng code (bài tập 3, bài 4).

Dùng:  python -X utf8 so-bao-cao.py <bao-cao-A.md> <bao-cao-B.md> [--dap-an dap-an.json]

In ra, cho mỗi báo cáo: tiêu đề từng "## Việc N" và các mã bằng chứng ("> [Rxxx]"). Rồi so hai bản:
  * số mã bằng chứng chung (chỉ đọc từ dòng trích dẫn);
  * nếu có dap-an.json: mỗi việc chạm vấn đề nào trong 5 vấn đề cài (I1..I5), và việc nào của A
    cùng chủ đề (cùng vấn đề cài) với việc nào của B.
Không đánh giá việc nào "hay hơn". Hai lần chạy chỉ cho thấy báo cáo dao động đến đâu (n rất nhỏ).
"""
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
VAN_DE = ("I1", "I2", "I3", "I4", "I5")


def doc_viec(duong_dan):
    text = Path(duong_dan).read_text(encoding="utf-8")
    parts = re.split(r"^##\s*Việc\s*(\d+)\s*[:.\-]?\s*", text, flags=re.M)
    viec = []
    for i in range(1, len(parts), 2):
        noi_dung = parts[i + 1]
        tieu_de = noi_dung.strip().splitlines()[0].strip() if noi_dung.strip() else ""
        ma = re.findall(r"^\s*>\s*\[?(R\d{3})", noi_dung, flags=re.M)
        viec.append({"so": int(parts[i]), "tieu_de": tieu_de, "ma": ma})
    return viec


def main():
    a = sys.argv[1:]
    dap_an = None
    if "--dap-an" in a:
        i = a.index("--dap-an")
        dap_an = json.loads(Path(a[i + 1]).read_text(encoding="utf-8"))
        del a[i:i + 2]
    if len(a) != 2:
        raise SystemExit(__doc__)
    tag = {}
    if dap_an:
        tag = {r["ma"]: [v for v in r.get("van_de", []) if v in VAN_DE] for r in dap_an["reviews"]}
    bao = {"A": doc_viec(a[0]), "B": doc_viec(a[1])}
    for k in ("A", "B"):
        print(f"== Báo cáo {k}: {Path(a[0 if k == 'A' else 1]).parent.parent.name or Path(a[0 if k == 'A' else 1]).name} ({len(bao[k])} việc)")
        for v in bao[k]:
            v["van_de"] = sorted({t for m in v["ma"] for t in tag.get(m, [])})
            vd = f" | vấn đề cài: {','.join(v['van_de']) or '-'}" if dap_an else ""
            print(f"  Việc {v['so']}: {v['tieu_de'][:70]}")
            print(f"           bằng chứng: {', '.join(v['ma'])}{vd}")
    ma_a = {m for v in bao["A"] for m in v["ma"]}
    ma_b = {m for v in bao["B"] for m in v["ma"]}
    print(f"\nMã bằng chứng: A dùng {len(ma_a)}, B dùng {len(ma_b)}, chung {len(ma_a & ma_b)}: {', '.join(sorted(ma_a & ma_b)) or '-'}")
    if dap_an:
        cua_a = {t for v in bao["A"] for t in v["van_de"]}
        cua_b = {t for v in bao["B"] for t in v["van_de"]}
        print(f"Vấn đề cài được chạm: A {len(cua_a)}/5 {sorted(cua_a)}, B {len(cua_b)}/5 {sorted(cua_b)}")
        print("Ghép việc cùng vấn đề cài:")
        for va in bao["A"]:
            kq = [f"Việc {vb['so']}" for vb in bao["B"] if set(va["van_de"]) & set(vb["van_de"])]
            print(f"  A-Việc {va['so']} ({','.join(va['van_de']) or '-'}) <-> B: {', '.join(kq) or 'không có việc cùng vấn đề'}")
        thieu_b = sorted(set(VAN_DE) - cua_b)
        thieu_a = sorted(set(VAN_DE) - cua_a)
        print(f"Chỉ A có: {sorted(cua_a - cua_b)} | chỉ B có: {sorted(cua_b - cua_a)} | cả hai thiếu: {sorted(set(thieu_a) & set(thieu_b))}")


if __name__ == "__main__":
    main()
