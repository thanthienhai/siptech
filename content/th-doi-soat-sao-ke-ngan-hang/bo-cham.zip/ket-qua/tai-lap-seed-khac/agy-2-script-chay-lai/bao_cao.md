# Báo cáo đối soát tài khoản tháng 10/2026
- Tổng số dòng sao kê đối soát: 144 dòng (97 ghi có: 125,248,650đ; 47 ghi nợ: 73,416,000đ).
- Số dư đối chiếu: Đầu kỳ 40,000,000đ, Cuối kỳ 91,832,650đ -> Khớp số dư 100%.
- Đã đối soát gộp đơn: 11 đơn COD thu hộ qua 2 đợt (9,420,000đ) và 6 giao dịch trả nhiều đơn (0đ).
- Lệch tiền phát hiện: 4 ca chuyển thiếu (0đ), 4 ca chuyển thừa (0đ), 3 ca chuyển trùng (0đ).
- Số ca cần người quyết: 23 giao dịch trên sao kê (3 ca gõ nhầm mã đơn, 6 ca tiền vào không rõ nguồn/lệch hóa đơn).
- Đơn hàng chưa thu tiền (CK): 40 đơn (2 đơn đã giao trị giá 1.640.000đ; 8 đơn đang giao trị giá 4.800.000đ).
- Hoàn tiền: 3 ca ghi nợ (450,000đ), trong đó có 1 ca hoàn tiền một phần đơn DH2610-037.
- Điều chưa chắc chắn: 6 khoản tiền vào chưa rõ nguồn gốc (tổng 9.410.000đ) bao gồm khoản 3.200.000đ ghi HD 0087 và 560.000đ mua hàng Zalo;
  và 3 khoản chuyển khoản sai mã đơn cần xác nhận lại với khách trước khi hoàn tất hạch toán.
