"""Kiểm y-kien-moi.csv so với them-dong-goi.csv.

Kiểm: mã tồn tại, chu_de/sac_thai hợp lệ, trich_dan là chuỗi con NGUYÊN VĂN
của noi_dung đúng bài (so khớp từng ký tự, không chuẩn hóa), mỗi bài có >= 1 ý kiến.
Rồi đếm số ý kiến theo chủ đề và sắc thái.
"""
import csv
import sys
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")  # console Windows mặc định không in được tiếng Việt

DIR = Path(__file__).resolve().parent
CHU_DE = {"dong_goi", "gia", "phuc_vu", "chat_luong", "giao_hang", "khong_gian", "ve_sinh", "khac"}
SAC_THAI = {"tich_cuc", "tieu_cuc", "trung_tinh", "CAN_NGUOI_DOC"}


def doc(ten):
    with open(DIR / ten, encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


bai = {r["ma"]: r["noi_dung"] for r in doc("them-dong-goi.csv")}
y_kien = doc("y-kien-moi.csv")

loi = []
for i, r in enumerate(y_kien, start=2):  # dòng 1 là tiêu đề
    ma, td, st, tr = r["ma"], r["chu_de"], r["sac_thai"], r["trich_dan"]
    if ma not in bai:
        loi.append(f"dòng {i}: mã {ma} không có trong them-dong-goi.csv")
        continue
    if td not in CHU_DE:
        loi.append(f"dòng {i} ({ma}): chu_de không hợp lệ: {td!r}")
    if st not in SAC_THAI:
        loi.append(f"dòng {i} ({ma}): sac_thai không hợp lệ: {st!r}")
    if not tr:
        loi.append(f"dòng {i} ({ma}): trich_dan rỗng")
    elif tr not in bai[ma]:
        loi.append(f"dòng {i} ({ma}): trich_dan KHÔNG nguyên văn trong bài: {tr!r}")

thieu = sorted(set(bai) - {r["ma"] for r in y_kien})
if thieu:
    loi.append(f"bài chưa có ý kiến nào: {', '.join(thieu)}")

trung = [k for k, n in Counter((r["ma"], r["chu_de"], r["trich_dan"]) for r in y_kien).items() if n > 1]
for k in trung:
    loi.append(f"dòng trùng lặp: {k}")

print(f"Số bài: {len(bai)} | số ý kiến: {len(y_kien)}")
if loi:
    print(f"\nLỖI ({len(loi)}):")
    for m in loi:
        print(" -", m)
else:
    print(f"OK: cả {len(y_kien)} trich_dan đều nguyên văn trong đúng bài, các cột hợp lệ.")

print("\nSố ý kiến theo chủ đề:")
dem = Counter(r["chu_de"] for r in y_kien)
for td in sorted(CHU_DE, key=lambda x: (-dem[x], x)):
    print(f"  {td:<11} {dem[td]}")
print(f"  {'TỔNG':<11} {sum(dem.values())}")

print("\nSố ý kiến theo chủ đề x sắc thái:")
ct = Counter((r["chu_de"], r["sac_thai"]) for r in y_kien)
for td in sorted(CHU_DE, key=lambda x: (-dem[x], x)):
    if dem[td]:
        print(f"  {td:<11}", ", ".join(f"{s}={ct[(td, s)]}" for s in sorted(SAC_THAI) if ct[(td, s)]))

sys.exit(1 if loi else 0)
