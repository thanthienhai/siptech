"""Sinh dữ liệu GIẢ cho bài 08: 6 chi nhánh gửi 6 file Excel doanh thu tháng, mỗi nơi một kiểu.

Chạy:  python -X utf8 sinh_du_lieu.py
Ra:
  thang-10/goc/            6 file .xlsx tháng 10/2026 (để giao cho agent)  + danh_muc_*.csv
  thang-11/goc/            6 file tháng 11/2026, CÙNG định dạng (bài 3: chạy lại script)
  thang-11-doi-dinh-dang/  6 file tháng 11/2026, riêng chi nhánh NT đổi định dạng (bài 3: định dạng mới)
  ../ket-qua/dap-an-*.json đáp án (KHÔNG đưa vào thư mục agent làm việc)

Toàn bộ là dữ liệu giả: công ty, chi nhánh, mã hàng, số chứng từ, số tiền đều bịa. Hạt giống cố định.
Các bẫy cài sẵn (mỗi bẫy có ghi trong đáp án):
  HN: ô gộp theo ngày (ngày chỉ ghi ở dòng đầu), tổng cuối bảng gõ tay SAI +100.000
  HP: số dạng chữ "1.250.000đ", ngày chữ dd/mm/yyyy, dòng thứ tự lộn xộn, 3 dòng TRÙNG số HĐ,
      4 dòng đơn tháng trước nhập trễ (ngoài kỳ), 3 dòng ngày gõ kiểu mm/dd -> NGÀY MƠ HỒ (CẦN NGƯỜI QUYẾT)
  DN: tiêu đề tiếng Anh, ngày chữ mm/dd/yyyy cả file, có 1 dòng trả hàng (số âm)
  CT: hàng tiêu đề nằm ở dòng 7 (có dòng giới thiệu phía trên), thiếu cả 1 tuần, 2 dòng sản phẩm lạ, tổng là công thức
  BH: ô ngày là ngày thật nhưng 3 dòng bị đảo ngày/tháng (suy ra được nhờ số phiếu tăng dần), có dòng "Cộng tuần"
  NT: tiêu đề 2 tầng ô gộp, ngày dd-mm-yy, số chữ "1,250,000", 2 dòng thành tiền lệch SL x giá, 2 dòng trùng
"""
import json, random, calendar, datetime as dt, shutil
from pathlib import Path
import xlsxwriter

AQUI = Path(__file__).resolve().parent
KQ = AQUI.parent / "ket-qua"

SP = [  # mã, tên chuẩn, giá gốc
    ("SP01", "Gạo ST25 túi 5kg", 165000),
    ("SP02", "Nước mắm truyền thống chai 500ml", 68000),
    ("SP03", "Cà phê rang xay 500g", 145000),
    ("SP04", "Trà sen 200g", 120000),
    ("SP05", "Mật ong rừng 250ml", 185000),
    ("SP06", "Hạt điều rang muối 500g", 210000),
    ("SP07", "Bánh tráng muối tôm 250g", 38000),
    ("SP08", "Dầu dừa ép lạnh 250ml", 95000),
]
ALIAS = {
    "SP01": ["Gạo ST25 túi 5kg", "Gao ST25 5kg", "GẠO ST25 5KG", "Gạo ST25 (5kg)", "ST25 5kg"],
    "SP02": ["Nước mắm truyền thống chai 500ml", "Nuoc mam truyen thong 500ml", "Nước mắm 500ml", "N.mắm TT 500ml", "NƯỚC MẮM TRUYỀN THỐNG 500ML"],
    "SP03": ["Cà phê rang xay 500g", "Ca phe rang xay 500g", "Cafe rang xay 500g", "CF rang xay 500gr", "Cà phê rang xay 500g "],
    "SP04": ["Trà sen 200g", "Tra sen 200g", "Trà sen (200g)", "TRÀ SEN 200G", "Trà sen 200 g"],
    "SP05": ["Mật ong rừng 250ml", "Mat ong rung 250ml", "Mật ong 250ml", "Mật ong rừng 250 ml", "MẬT ONG RỪNG 250ML"],
    "SP06": ["Hạt điều rang muối 500g", "Hat dieu rang muoi 500g", "Hạt điều 500g", "Điều rang muối 500g", "HẠT ĐIỀU RANG MUỐI 500G"],
    "SP07": ["Bánh tráng muối tôm 250g", "Banh trang muoi tom 250g", "B.tráng muối tôm 250g", "Bánh tráng MT 250g", "BÁNH TRÁNG MUỐI TÔM 250G"],
    "SP08": ["Dầu dừa ép lạnh 250ml", "Dau dua ep lanh 250ml", "Dầu dừa 250ml", "Dầu dừa ép lạnh 250 ml", "DẦU DỪA ÉP LẠNH 250ML"],
}
CN = [("HN", "Hà Nội"), ("HP", "Hải Phòng"), ("DN", "Đà Nẵng"), ("CT", "Cần Thơ"), ("BH", "Biên Hòa"), ("NT", "Nha Trang")]
UNKNOWN = "Combo quà Tết 2026"
CHUA_XD = "CHUA_XAC_DINH"


def vnd_dot(n, suffix="đ"):
    return f"{n:,}".replace(",", ".") + suffix


def vnd_comma(n):
    return f"{n:,}"


def gen_rows(rng, code, year, month, skip_days=()):
    """Các dòng bán 'thật' của một chi nhánh (đã biết đúng). Mỗi dòng 1 số chứng từ."""
    nd = calendar.monthrange(year, month)[1]
    rows, seq = [], 0
    names = {c: rng.sample(ALIAS[c], 3) for c, _, _ in SP}
    for d in range(1, nd + 1):
        if d in skip_days:
            continue
        for _ in range(rng.randint(3, 7)):
            seq += 1
            c, ten, base = rng.choice(SP)
            price = int(round(base * rng.choice([1, 1, 1, 0.95, 1.05]) / 1000) * 1000)
            qty = rng.choice([1, 2, 3, 5, 6, 8, 10, 12, 15, 20, 24, 30, 40])
            rows.append(dict(branch=code, date=dt.date(year, month, d), seq=seq, prod=c,
                             label=rng.choice(names[c]), qty=qty, price=price, amount=qty * price, flags=[]))
    return rows


def inv_id(code, seq, rng=None, style="seq"):
    if style == "seq":
        return f"{code}-{seq:04d}"
    return f"HD{rng.randint(10000, 99999)}"


def build(month_year, seed, outdir, truth_path, drift=False):
    year, month = month_year
    rng = random.Random(seed)
    outdir = Path(outdir); (outdir / "goc").mkdir(parents=True, exist_ok=True)
    prev_y, prev_m = (year, month - 1) if month > 1 else (year - 1, 12)
    prev_nd = calendar.monthrange(prev_y, prev_m)[1]
    mm = f"{month:02d}"
    truth = {"thang": f"{year}-{mm}", "ghi_chu": "DỮ LIỆU GIẢ. Đáp án để chấm, không đưa cho agent.",
             "files": {}, "rows": [], "ask_rows": [], "oop_rows": [], "dup_rows": [], "subtotal_rows": [],
             "missing_days": {}, "tong_chi_nhanh_xac_nhan": {}, "tong_chi_nhanh_neu_tinh_ca_mo_ho": {},
             "tong_san_pham_xac_nhan": {}, "tong_chi_nhanh_san_pham": {}}

    def add_truth(r, status, src_row, fname, extra_flags=()):
        t = dict(branch=r["branch"], inv=r["inv"], date=r["date"].isoformat(), prod=r["prod"], qty=r["qty"],
                 price=r["price"], amount=r["amount"], status=status, flags=list(r["flags"]) + list(extra_flags),
                 file=fname, src_row=src_row)
        truth["rows"].append(t); return t

    def finish_file(code, fname, written_total, raw_sum, notes):
        truth["files"][code] = dict(file=fname, tong_file_ghi=written_total, tong_moi_dong_doc_duoc=raw_sum, ghi_chu=notes)

    def xl(name):
        return xlsxwriter.Workbook(str(outdir / "goc" / name))

    # ---------------- HN: ô gộp theo ngày, tổng gõ tay sai ----------------
    rows = gen_rows(rng, "HN", year, month)
    for r in rows: r["inv"] = inv_id("HN", r["seq"])
    fname = f"BC doanh thu T{mm} - HN.xlsx"
    wb = xl(fname); ws = wb.add_worksheet(f"Tháng {month}")
    fb = wb.add_format({"bold": True, "align": "center", "valign": "vcenter", "font_size": 13})
    fh = wb.add_format({"bold": True, "bg_color": "#DDEBF7", "border": 1, "text_wrap": True, "align": "center"})
    fd = wb.add_format({"num_format": "dd/mm/yyyy", "border": 1, "align": "center", "valign": "vcenter"})
    fn = wb.add_format({"num_format": "#,##0", "border": 1}); ft = wb.add_format({"border": 1})
    ws.merge_range(0, 0, 0, 5, "CÔNG TY TNHH MẪU AN PHÁT (dữ liệu giả để học)", fb)
    ws.merge_range(1, 0, 1, 5, f"BÁO CÁO DOANH THU THÁNG {month}/{year} - CHI NHÁNH HÀ NỘI", fb)
    for j, h in enumerate(["Ngày", "Số HĐ", "Tên hàng", "SL", "Đơn giá", "Thành tiền"]): ws.write(3, j, h, fh)
    r0 = 4; i = 0
    while i < len(rows):
        j = i
        while j + 1 < len(rows) and rows[j + 1]["date"] == rows[i]["date"]: j += 1
        d = dt.datetime.combine(rows[i]["date"], dt.time())
        if j > i: ws.merge_range(r0 + i, 0, r0 + j, 0, d, fd)
        else: ws.write_datetime(r0 + i, 0, d, fd)
        i = j + 1
    for k, r in enumerate(rows):
        x = r0 + k
        ws.write(x, 1, r["inv"], ft); ws.write(x, 2, r["label"], ft); ws.write_number(x, 3, r["qty"], fn)
        ws.write_number(x, 4, r["price"], fn); ws.write_number(x, 5, r["amount"], fn)
        add_truth(r, "OK", x + 1, fname)
    tot = sum(r["amount"] for r in rows)
    x = r0 + len(rows)
    ws.merge_range(x, 0, x, 4, "TỔNG CỘNG", fh); ws.write_number(x, 5, tot + 100000, fn)  # gõ tay sai
    ws.write(x + 2, 0, "Ghi chú: Giá đã gồm VAT. Số liệu chưa trừ hàng trả lại.")
    ws.write(x + 3, 0, "Người lập: Kế toán chi nhánh (giả)      Ngày lập: 02/%02d/%d" % (month % 12 + 1, year if month < 12 else year + 1))
    ws.set_column(0, 0, 12); ws.set_column(1, 1, 11); ws.set_column(2, 2, 34); ws.set_column(3, 5, 13)
    wb.close()
    finish_file("HN", fname, tot + 100000, tot, "Tổng cuối bảng gõ tay, lệch +100.000 so với tổng các dòng.")

    # ---------------- HP: số chữ, ngày dd/mm, trùng, ngoài kỳ, ngày mơ hồ ----------------
    rows = gen_rows(rng, "HP", year, month)
    for r in rows: r["inv"] = inv_id("HP", r["seq"], rng, "rand")
    # 3 dòng ngày mơ hồ: ngày thật = (month, D) với D = month-1, gõ kiểu mm/dd -> "MM/DD/yyyy"; đọc dd/mm thành ngày D... tháng trước
    D = month - 1 if month > 1 else 12
    cand = [r for r in rows if r["date"].day == D]
    ask = rng.sample(cand, min(3, len(cand)))
    for r in ask: r["flags"].append("ngay_mo_ho")
    # 4 dòng tháng trước nhập trễ
    oop = []
    for k, d in enumerate([prev_nd - 4, prev_nd - 3, prev_nd - 1, prev_nd]):
        c, ten, base = rng.choice(SP); qty = rng.choice([5, 10, 12, 20]); price = base
        oop.append(dict(branch="HP", date=dt.date(prev_y, prev_m, d), seq=900 + k, prod=c, label=rng.choice(ALIAS[c][:3]),
                        qty=qty, price=price, amount=qty * price, flags=["ngoai_ky"], inv=inv_id("HP", 0, rng, "rand")))
    dups = rng.sample([r for r in rows if r not in ask], 3)
    lines = [(r, "main") for r in rows] + [(r, "oop") for r in oop] + [(r, "dup") for r in dups]
    rng.shuffle(lines)
    fname = f"DoanhThu_HP_{mm}{year}.xlsx"
    wb = xl(fname); ws = wb.add_worksheet("Sheet1")
    fb = wb.add_format({"bold": True}); fh = wb.add_format({"bold": True, "bg_color": "#FCE4D6", "border": 1})
    ws.write(0, 0, f"Chi nhánh Hải Phòng - Doanh thu bán hàng T{month}/{year}", fb)
    for j, h in enumerate(["Ngày bán", "Số HĐ", "Mặt hàng", "Số lượng", "Giá bán", "Thành tiền"]): ws.write(2, j, h, fh)
    raw = 0; seen = set()
    for k, (r, kind) in enumerate(lines):
        x = 3 + k
        if r in ask:  # gõ kiểu mm/dd
            dtxt = f"{r['date'].month:02d}/{r['date'].day:02d}/{r['date'].year}"
        else:
            dtxt = f"{r['date'].day:02d}/{r['date'].month:02d}/{r['date'].year}"
        ws.write_string(x, 0, dtxt); ws.write(x, 1, r["inv"]); ws.write(x, 2, r["label"]); ws.write_number(x, 3, r["qty"])
        ws.write_string(x, 4, vnd_dot(r["price"])); ws.write_string(x, 5, vnd_dot(r["amount"]))
        raw += r["amount"]
        if kind == "main":
            if r in ask:
                t = add_truth(r, "ASK", x + 1, fname); truth["ask_rows"].append(dict(branch="HP", inv=r["inv"], amount=r["amount"],
                    doc_ngay_theo_dd_mm=f"{prev_y}-{prev_m:02d}-{month:02d}", doc_ngay_theo_mm_dd=r["date"].isoformat(), src_row=x + 1))
            else:
                add_truth(r, "OK", x + 1, fname)
        elif kind == "oop":
            truth["oop_rows"].append(dict(branch="HP", inv=r["inv"], date=r["date"].isoformat(), amount=r["amount"], src_row=x + 1))
        else:
            truth["dup_rows"].append(dict(branch="HP", inv=r["inv"], amount=r["amount"], src_row=x + 1))
    x = 3 + len(lines)
    ws.write(x, 4, "Tổng cộng:", fb); ws.write_string(x, 5, vnd_dot(raw), fb)
    ws.write(x + 2, 0, f"* Gồm 4 đơn tháng {prev_m} nhập trễ (từ {prev_nd-4}/{prev_m:02d} đến {prev_nd}/{prev_m:02d}).")
    ws.set_column(0, 1, 13); ws.set_column(2, 2, 34); ws.set_column(3, 5, 15)
    wb.close()
    finish_file("HP", fname, raw, raw, "Tổng gõ tay gồm cả dòng trùng, đơn tháng trước và dòng ngày mơ hồ.")

    # ---------------- DN: tiếng Anh, ngày mm/dd/yyyy, có trả hàng ----------------
    rows = gen_rows(rng, "DN", year, month)
    for r in rows: r["inv"] = inv_id("DN", r["seq"])
    ret = rng.choice([r for r in rows if r["qty"] >= 5 and 8 <= r["date"].day <= 25])
    rr = dict(ret); rr.update(inv=f"RT-{ret['seq']:04d}", seq=ret["seq"], qty=-3, amount=-3 * ret["price"], flags=["tra_hang"],
              date=dt.date(year, month, ret["date"].day))
    rows.insert(rows.index(ret) + 1, rr)
    fname = f"Bao cao thang {mm} - DN (final).xlsx"
    wb = xl(fname); ws = wb.add_worksheet("Oct" if month == 10 else "Nov")
    fh = wb.add_format({"bold": True, "bg_color": "#E2EFDA", "border": 1}); fb = wb.add_format({"bold": True})
    fn = wb.add_format({"num_format": "#,##0"})
    ws.write(0, 0, f"DA NANG BRANCH - SALES {calendar.month_abbr[month].upper()} {year}", fb)
    for j, h in enumerate(["Date", "Invoice", "Product", "Qty", "Unit price (VND)", "Amount"]): ws.write(1, j, h, fh)
    tot = 0
    for k, r in enumerate(rows):
        x = 2 + k
        ws.write_string(x, 0, f"{r['date'].month:02d}/{r['date'].day:02d}/{r['date'].year}")
        ws.write(x, 1, r["inv"]); ws.write(x, 2, r["label"]); ws.write_number(x, 3, r["qty"])
        ws.write_number(x, 4, r["price"], fn); ws.write_number(x, 5, r["amount"], fn)
        tot += r["amount"]
        add_truth(r, "OK", x + 1, fname, extra_flags=["ngay_mm_dd"])
    x = 2 + len(rows)
    ws.write(x, 4, "Total", fb); ws.write_number(x, 5, tot, fn)
    ws.write(x + 2, 0, "Prepared by: Accounting (fake)")
    ws.set_column(0, 1, 12); ws.set_column(2, 2, 34); ws.set_column(3, 5, 15)
    wb.close()
    finish_file("DN", fname, tot, tot, "Ngày cả file kiểu mm/dd/yyyy; có 1 dòng trả hàng số âm; tổng đúng.")

    # ---------------- CT: tiêu đề ở dòng 7, thiếu 1 tuần, sản phẩm lạ, tổng công thức ----------------
    miss = list(range(15, 22))
    rows = gen_rows(rng, "CT", year, month, skip_days=miss)
    for r in rows: r["inv"] = inv_id("CT", r["seq"])
    for r in rng.sample([r for r in rows if r["date"].day not in (1, 31)], 2):
        r["label"] = UNKNOWN; r["prod"] = CHUA_XD; r["flags"].append("san_pham_la"); r["qty"] = 10; r["price"] = 650000; r["amount"] = 6500000
    fname = f"CT_T{mm}_DoanhThu.xlsx"
    wb = xl(fname); ws = wb.add_worksheet("DT")
    fb = wb.add_format({"bold": True, "align": "center", "font_size": 14}); fh = wb.add_format({"bold": True, "bg_color": "#FFF2CC", "border": 1})
    fd = wb.add_format({"num_format": "dd/mm/yyyy"}); fn = wb.add_format({"num_format": "#,##0"}); fbold = wb.add_format({"bold": True, "num_format": "#,##0"})
    ws.merge_range(0, 0, 0, 5, "CHI NHÁNH CẦN THƠ - SỔ DOANH THU BÁN HÀNG", fb)
    ws.write(1, 0, "Địa chỉ: (bịa) 12 Đường Mẫu, Cần Thơ"); ws.write(2, 0, f"Kỳ báo cáo: 01/{mm}/{year} - {calendar.monthrange(year, month)[1]}/{mm}/{year}")
    ws.write(3, 0, "Đơn vị tính: đồng")
    for j, h in enumerate(["Ngày", "Mã đơn", "Sản phẩm", "Số lượng", "Đơn giá", "Doanh thu"]): ws.write(6, j, h, fh)
    tot = 0
    for k, r in enumerate(rows):
        x = 7 + k
        ws.write_datetime(x, 0, dt.datetime.combine(r["date"], dt.time()), fd); ws.write(x, 1, r["inv"]); ws.write(x, 2, r["label"])
        ws.write_number(x, 3, r["qty"]); ws.write_number(x, 4, r["price"], fn); ws.write_number(x, 5, r["amount"], fn)
        tot += r["amount"]
        add_truth(r, "OK", x + 1, fname)
    x = 7 + len(rows)
    ws.write(x, 4, "Cộng", fb); ws.write_formula(x, 5, f"=SUM(F8:F{x})", fbold, tot)
    ws.write(x + 2, 0, "Ghi chú: Số liệu lấy từ phần mềm bán hàng.")
    ws.set_column(0, 1, 12); ws.set_column(2, 2, 34); ws.set_column(3, 5, 14)
    wb.close()
    finish_file("CT", fname, tot, tot, "Hàng tiêu đề ở dòng 7. Thiếu dữ liệu ngày 15-21. 2 dòng sản phẩm 'Combo quà Tết 2026' không có trong danh mục.")
    truth["missing_days"]["CT"] = [f"{year}-{mm}-{d:02d}" for d in miss]

    # ---------------- BH: ngày bị đảo, dòng Cộng tuần ----------------
    rows = gen_rows(rng, "BH", year, month)
    for r in rows: r["inv"] = f"PX-{r['seq']:04d}"
    cand = [r for r in rows if r["date"].day in range(2, 10) and r["date"].day != month]
    sw = rng.sample(cand, 3)
    for r in sw: r["flags"].append("ngay_bi_dao")
    fname = f"BienHoa-{mm}{year}.xlsx"
    wb = xl(fname); ws = wb.add_worksheet("DoanhThu")
    fb = wb.add_format({"bold": True}); fh = wb.add_format({"bold": True, "bg_color": "#D9E1F2", "border": 1})
    fd = wb.add_format({"num_format": "dd/mm/yyyy"}); fn = wb.add_format({"num_format": "#,##0"}); fbold = wb.add_format({"bold": True, "num_format": "#,##0", "bg_color": "#EDEDED"})
    ws.write(0, 0, f"BIÊN HÒA - DOANH THU THÁNG {month}/{year}", fb)
    for j, h in enumerate(["Ngày", "Số phiếu", "Tên SP", "SL", "Giá", "Tiền"]): ws.write(1, j, h, fh)
    x = 2; wk_end = {7, 14, 21, 28, calendar.monthrange(year, month)[1]}; wk_amt = 0; wk_qty = 0; wk_n = 0; sub_cells = []; tot = 0
    for k, r in enumerate(rows):
        d = r["date"]
        shown = dt.date(year, r["date"].day, month) if r in sw else d   # đảo ngày <-> tháng
        ws.write_datetime(x, 0, dt.datetime.combine(shown, dt.time()), fd); ws.write(x, 1, r["inv"]); ws.write(x, 2, r["label"])
        ws.write_number(x, 3, r["qty"]); ws.write_number(x, 4, r["price"], fn); ws.write_number(x, 5, r["amount"], fn)
        t = add_truth(r, "INFER" if r in sw else "OK", x + 1, fname)
        if r in sw: t["ngay_hien_trong_file"] = shown.isoformat()
        wk_amt += r["amount"]; wk_qty += r["qty"]; tot += r["amount"]; x += 1
        nxt = rows[k + 1]["date"].day if k + 1 < len(rows) else None
        if d.day in wk_end and nxt != d.day:
            wk_n += 1
            ws.write(x, 2, f"Cộng tuần {wk_n}", fb); ws.write_number(x, 3, wk_qty, fbold); ws.write_number(x, 5, wk_amt, fbold)
            truth["subtotal_rows"].append(dict(branch="BH", label=f"Cộng tuần {wk_n}", amount=wk_amt, src_row=x + 1))
            sub_cells.append(f"F{x+1}"); wk_amt = 0; wk_qty = 0; x += 1
    ws.write(x, 2, "TỔNG THÁNG", fb); ws.write_formula(x, 5, "=" + "+".join(sub_cells), fbold, tot)
    ws.set_column(0, 1, 12); ws.set_column(2, 2, 34); ws.set_column(3, 5, 13)
    wb.close()
    finish_file("BH", fname, tot, tot, "Có 5 dòng 'Cộng tuần' xen giữa dữ liệu. 3 dòng ngày bị đảo ngày/tháng (ô ngày thật). Tổng đúng.")

    # ---------------- NT: tiêu đề 2 tầng, dd-mm-yy, số chữ, thành tiền lệch, trùng ----------------
    rows = gen_rows(rng, "NT", year, month)
    for r in rows: r["inv"] = f"NT/{r['seq']:04d}"
    mism = rng.sample([r for r in rows if r["qty"] >= 5], 2)
    for r in mism:
        r["written"] = r["amount"] + 50000; r["flags"].append("lech_thanh_tien")
    for r in rows: r.setdefault("written", r["amount"])
    for r in rows: r["amount_true_calc"] = r["qty"] * r["price"]
    dups = rng.sample([r for r in rows if r not in mism], 2)
    lines = []
    for r in rows:
        lines.append((r, "main"))
        if r in dups: lines.append((r, "dup"))
    fname = f"NhaTrang_doanhthu_T{mm}.xlsx"
    wb = xl(fname); ws = wb.add_worksheet("data")
    fb = wb.add_format({"bold": True, "align": "center", "bg_color": "#C6E0B4", "border": 1}); fh = wb.add_format({"bold": True, "border": 1, "bg_color": "#E2EFDA"})
    fbold = wb.add_format({"bold": True, "num_format": "#,##0"})
    ws.write(0, 0, f"NHA TRANG - T{month}/{year}")
    drift_cols = drift
    if not drift_cols:
        ws.merge_range(1, 0, 1, 2, "THÔNG TIN BÁN HÀNG", fb); ws.merge_range(1, 3, 1, 5, "SỐ LIỆU", fb)
        heads = ["Ngày GD", "Chứng từ", "Hàng hóa", "SL", "Đơn giá", "Thành tiền"]; hrow = 2
    else:  # định dạng MỚI: đổi tên cột, thêm cột Kênh, đảo thứ tự, ngày ISO, số thật, không còn tiêu đề 2 tầng
        heads = ["Mã chứng từ", "Ngày", "Kênh bán", "Hàng hóa", "Số lượng", "Giá niêm yết", "Doanh số (VNĐ)"]; hrow = 1
    for j, h in enumerate(heads): ws.write(hrow, j, h, fh)
    raw = 0
    for k, (r, kind) in enumerate(lines):
        x = hrow + 1 + k; w = r["written"]
        if not drift_cols:
            ws.write_string(x, 0, f"{r['date'].day:02d}-{r['date'].month:02d}-{str(r['date'].year)[2:]}")
            ws.write(x, 1, r["inv"]); ws.write(x, 2, r["label"]); ws.write_number(x, 3, r["qty"])
            ws.write_string(x, 4, vnd_comma(r["price"])); ws.write_string(x, 5, vnd_comma(w))
        else:
            ws.write(x, 0, r["inv"]); ws.write_string(x, 1, r["date"].isoformat()); ws.write(x, 2, rng.choice(["Tại quầy", "Đại lý", "Online"]))
            ws.write(x, 3, r["label"]); ws.write_number(x, 4, r["qty"]); ws.write_number(x, 5, r["price"]); ws.write_number(x, 6, w)
        raw += w
        if kind == "main":
            rr = dict(r); rr["amount"] = w
            add_truth(rr, "OK", x + 1, fname, extra_flags=(["lech_thanh_tien"] if r in mism else []))
            if r in mism: truth["rows"][-1]["amount_tinh_lai"] = r["amount_true_calc"]
        else:
            truth["dup_rows"].append(dict(branch="NT", inv=r["inv"], amount=w, src_row=x + 1))
    x = hrow + 1 + len(lines)
    last = 6 if drift_cols else 5
    ws.write(x, last - 1, "Tổng:", fbold); ws.write_number(x, last, raw, fbold)
    ws.write(x + 2, 0, "Lưu ý: file xuất từ phần mềm cũ, mọi thắc mắc liên hệ kế toán CN.")
    ws.set_column(0, 6, 14); ws.set_column(2, 3, 30)
    wb.close()
    finish_file("NT", fname, raw, raw, "2 dòng thành tiền lệch SL x đơn giá (+50.000, ghi theo số trong file). 2 dòng trùng chứng từ. Tổng gồm cả dòng trùng."
                + (" [ĐỊNH DẠNG MỚI]" if drift_cols else ""))

    # ---------------- đáp án tổng hợp ----------------
    conf = [r for r in truth["rows"] if r["status"] in ("OK", "INFER")]
    for code, _ in CN:
        truth["tong_chi_nhanh_xac_nhan"][code] = sum(r["amount"] for r in conf if r["branch"] == code)
        truth["tong_chi_nhanh_neu_tinh_ca_mo_ho"][code] = truth["tong_chi_nhanh_xac_nhan"][code] + sum(a["amount"] for a in truth["ask_rows"] if a["branch"] == code)
    for r in conf:
        truth["tong_san_pham_xac_nhan"][r["prod"]] = truth["tong_san_pham_xac_nhan"].get(r["prod"], 0) + r["amount"]
        k = f"{r['branch']}|{r['prod']}"; truth["tong_chi_nhanh_san_pham"][k] = truth["tong_chi_nhanh_san_pham"].get(k, 0) + r["amount"]
    truth["tong_xac_nhan"] = sum(truth["tong_chi_nhanh_xac_nhan"].values())
    Path(truth_path).parent.mkdir(parents=True, exist_ok=True)
    Path(truth_path).write_text(json.dumps(truth, ensure_ascii=False, indent=1), encoding="utf-8")
    return truth


def write_catalog(folder):
    folder = Path(folder)
    (folder / "danh_muc_san_pham.csv").write_text("ma_san_pham,ten_san_pham\n" + "".join(f"{c},{t}\n" for c, t, _ in SP), encoding="utf-8-sig")
    (folder / "danh_muc_chi_nhanh.csv").write_text("ma,ten\n" + "".join(f"{c},{t}\n" for c, t in CN), encoding="utf-8-sig")


if __name__ == "__main__":
    for sub in ("thang-10", "thang-11", "thang-11-doi-dinh-dang"):
        shutil.rmtree(AQUI / sub, ignore_errors=True)
    t = build((2026, 10), 20261020, AQUI / "thang-10", KQ / "dap-an-T10.json")
    write_catalog(AQUI / "thang-10")
    t2 = build((2026, 11), 20261121, AQUI / "thang-11", KQ / "dap-an-T11.json")
    write_catalog(AQUI / "thang-11")
    t3 = build((2026, 11), 20261121, AQUI / "thang-11-doi-dinh-dang", KQ / "dap-an-T11-doi-dinh-dang.json", drift=True)
    write_catalog(AQUI / "thang-11-doi-dinh-dang")
    # T11 (cùng định dạng) không thiếu tuần: dùng CT thiếu 15-21 như cũ là hợp lý, giữ nguyên để bài 3 thấy cảnh báo lại
    for name, tr in (("T10", t), ("T11", t2), ("T11 đổi định dạng", t3)):
        print(name, "dòng xác nhận:", sum(1 for r in tr["rows"] if r["status"] in ("OK", "INFER")), "| tổng xác nhận:", f"{tr['tong_xac_nhan']:,}",
              "| mơ hồ:", len(tr["ask_rows"]), "| trùng:", len(tr["dup_rows"]), "| ngoài kỳ:", len(tr["oop_rows"]))
