"""Sinh dữ liệu + đáp án cho 3 bài tập tự làm ở bài 4 (DỮ LIỆU GIẢ, hạt giống cố định, chạy lại ra y hệt).

Chạy:        python -X utf8 sinh_bai_tap.py            (ghi dữ liệu vào ../../du-lieu/bai-tap/btN, đáp án vào thư mục này)
Tự kiểm bộ chấm:  python -X utf8 sinh_bai_tap.py --tu-kiem   (dựng đầu ra ĐÚNG và đầu ra SAI mẫu bằng code, chấm thử cả hai)

File này chứa đáp án nên nằm ở ket-qua/, KHÔNG chép vào thư mục chạy agent.
  bt1: thêm bậc giá thứ tư cho hai mã (bảng giá có thêm 2 cột), hai yêu cầu R13, R14 sát mốc bậc mới
  bt2: hai yêu cầu xin chiết khấu vượt thẩm quyền (xin 8% và 6%), bảng giá giữ nguyên
  bt3: điều kiện giao hàng đổi: miễn phí giao nội thành từ 2.000.000 đồng (cũ: 3.000.000), chạy lại 12 yêu cầu cũ
"""
import json, shutil, sys, tempfile
from copy import copy
from pathlib import Path
from openpyxl import load_workbook

HERE = Path(__file__).resolve().parent
LESSON = HERE.parent.parent
sys.path.insert(0, str(LESSON / "du-lieu"))
sys.path.insert(0, str(HERE.parent))
import sinh_du_lieu as B   # dữ liệu gốc + hàm tính đáp án
import cham                # bộ chấm gốc (cham_one, parse_xlsx)

OUT = LESSON / "du-lieu" / "bai-tap"
BAC4 = {"GIAY-A4-80": (100, 66000), "BUT-BI-TL027-XANH": (500, 3300)}   # (từ SL, giá)
NGUONG_MOI = 2_000_000

EXTRA_KEYS = {
    "chiet_khau_8_vuot_tham_quyen": [["8 ?%|8 phan tram"], ["can nguoi quyet|truong phong|giam doc|cho duyet|cho quyet|vuot tham quyen|phe duyet|duyet"]],
    "chiet_khau_6_vuot_tham_quyen": [["6 ?%|6 phan tram"], ["can nguoi quyet|truong phong|giam doc|cho duyet|cho quyet|vuot tham quyen|phe duyet|duyet"]],
}


def make_req(id, kenh, nguoi, text, **spec):
    return dict(id=id, kenh=kenh, nguoi=nguoi, text=text, **spec)


def reqs_bt1():
    return [
        make_req("R13", "email", "chị Bích - Văn phòng Công ty CP Sao Việt (giả)",
"""Từ: bich.vp@example.com
Tiêu đề: Báo giá giấy và bút cho đợt cấp phát quý 1

Chào An Phát,
Bên em (công ty giả) cần báo giá:
- Giấy A4 80gsm: 20 thùng
- Bút bi xanh TL027: 25 hộp
- Băng keo trong 48mm: 12 cuộn
Giao: 45 Đường Mẫu, Quận Ba Đình, Hà Nội.
Cảm ơn.""",
            items=[("GIAY-A4-80", 100), ("BUT-BI-TL027-XANH", 500), ("BANGKEO-TRONG-48", 12)], dia_chi="noi_thanh", xin_giam=0.0,
            thieu=[], quyet=[], nhan_xet="20 thùng giấy = 100 ram và 25 hộp bút = 500 cây: đúng mốc bậc 4 mới; băng keo 12 cuộn đúng mốc bậc 2."),
        make_req("R14", "zalo", "chị Hoa - quán Thu Ký (giả)",
"""[Zalo] Hoa Thu Ky:
bao gia giup chi: giay a4 80 - 99 ram; but bi xanh TL027 24 hop
giao Quan Cau Giay HN, 20 Duong Demo""",
            items=[("GIAY-A4-80", 99), ("BUT-BI-TL027-XANH", 480)], dia_chi="noi_thanh", xin_giam=0.0,
            thieu=[], quyet=[], nhan_xet="99 ram và 24 hộp = 480 cây: sát dưới mốc bậc 4, vẫn bậc 3."),
    ]


def reqs_bt2():
    return [
        make_req("R13", "email", "anh Tuấn - Công ty TNHH In Nhanh (giả)",
"""Từ: tuan.mh@example.com
Tiêu đề: Báo giá giấy và mực, xin giảm giá

Chào An Phát, báo giá giúp bên em (công ty giả):
- Giấy A4 80gsm: 80 ram
- Mực HP 78A: 12 hộp
- Bút gel đen 0.5: 5 hộp
Giao: 9 Đường Mẫu, Quận Hai Bà Trưng, Hà Nội.
Bên em đặt thường xuyên, anh chị giảm giúp tổng đơn 8% nhé, nếu không bên em đặt chỗ khác.""",
            items=[("GIAY-A4-80", 80), ("MUC-HP-78A", 12), ("BUT-GEL-05-DEN", 60)], dia_chi="noi_thanh", xin_giam=8.0,
            thieu=[], quyet=["chiet_khau_8_vuot_tham_quyen"], nhan_xet="Đơn trên 10 triệu: chiết khấu theo đơn 2%. Xin 8% vượt 5%: chỉ áp 2%, ghi yêu cầu giảm chờ người quyết."),
        make_req("R14", "zalo", "chị Phúc - Phúc An VP (giả)",
"""[Zalo] Phuc An VP:
bao gia giay a3 80 - 12 ram, so caro a4 200 trang 30 quyen
giao Quan Long Bien HN
em xin giam 6% cho don nay nhe chi""",
            items=[("GIAY-A3-80", 12), ("SO-CARO-A4-200", 30)], dia_chi="noi_thanh", xin_giam=6.0,
            thieu=[], quyet=["chiet_khau_6_vuot_tham_quyen"], nhan_xet="Đơn dưới 10 triệu: không có chiết khấu theo đơn. Xin 6% vượt 5%: không áp gì, chờ người quyết. Sau chiết khấu 2.793.000 < 3 triệu nên có phí giao 40.000."),
    ]


def solve_with(req, nguong=None, bac4=False):
    """Gọi hàm tính đáp án gốc, tạm thay hàm giá bậc / ngưỡng miễn phí giao."""
    old = (B.unit_price, B.tier_of, B.NGUONG_MIEN_PHI_SHIP)
    if bac4:
        up0, tr0 = B.unit_price, B.tier_of
        B.unit_price = lambda ma, q: BAC4[ma][1] if ma in BAC4 and q >= BAC4[ma][0] else up0(ma, q)
        B.tier_of = lambda ma, q: 4 if ma in BAC4 and q >= BAC4[ma][0] else tr0(ma, q)
    if nguong:
        B.NGUONG_MIEN_PHI_SHIP = nguong
    try:
        return B.solve(req)
    finally:
        B.unit_price, B.tier_of, B.NGUONG_MIEN_PHI_SHIP = old


def write_base_inputs(d):
    d.mkdir(parents=True, exist_ok=True)
    B.build_bang_gia(d / "bang-gia.xlsx"); B.build_mau(d / "mau-bao-gia.xlsx")
    B.build_policy(d / "chinh-sach-chiet-khau.docx"); B.build_delivery(d / "dieu-kien-giao-hang.txt")
    (d / "yeu-cau").mkdir(exist_ok=True)


def add_bac4_columns(path):
    wb = load_workbook(path); ws = wb["BangGia"]
    for col, h in ((11, "Bậc 4 từ SL"), (12, "Giá bậc 4")):
        c = ws.cell(row=3, column=col, value=h)
        c.font = copy(ws["J3"].font); c.fill = copy(ws["J3"].fill); c.alignment = copy(ws["J3"].alignment)
    for r in range(4, ws.max_row + 1):
        ma = ws.cell(row=r, column=1).value
        if ma in BAC4:
            ws.cell(row=r, column=11, value=BAC4[ma][0])
            c = ws.cell(row=r, column=12, value=BAC4[ma][1]); c.number_format = "#,##0"
    ws["A2"] = ws["A2"].value + " Một số mã có thêm Bậc 4 (cột K, L): từ số lượng đó dùng giá bậc 4."
    ws.column_dimensions["K"].width = 12; ws.column_dimensions["L"].width = 12
    wb.save(path)


def build_all():
    ans = {}
    # ---- bt1
    d = OUT / "bt1"; write_base_inputs(d); add_bac4_columns(d / "bang-gia.xlsx")
    R = reqs_bt1()
    for r in R: (d / "yeu-cau" / f"{r['id']}.txt").write_text(r["text"].strip() + "\n", encoding="utf-8")
    ans["bt1"] = [solve_with(r, bac4=True) for r in R]
    # ---- bt2
    d = OUT / "bt2"; write_base_inputs(d)
    R = reqs_bt2()
    for r in R: (d / "yeu-cau" / f"{r['id']}.txt").write_text(r["text"].strip() + "\n", encoding="utf-8")
    ans["bt2"] = [solve_with(r) for r in R]
    # ---- bt3
    d = OUT / "bt3"; write_base_inputs(d)
    p = d / "dieu-kien-giao-hang.txt"; t = p.read_text(encoding="utf-8")
    assert "từ 3.000.000 đồng trở lên" in t
    p.write_text(t.replace("từ 3.000.000 đồng trở lên", "từ 2.000.000 đồng trở lên"), encoding="utf-8")
    R = B.requests()
    for r in R: (d / "yeu-cau" / f"{r['id']}.txt").write_text(r["text"].strip() + "\n", encoding="utf-8")
    ans["bt3"] = [solve_with(r, nguong=NGUONG_MOI) for r in R]
    base = {r["id"]: B.solve(r) for r in R}
    doi = [a["id"] for a in ans["bt3"] if a["tong_cong"] != base[a["id"]]["tong_cong"]]
    for k, v in ans.items():
        meta = dict(seed=B.SEED, bai_tap=k, vat_percent=B.VAT_PERCENT, tu_khoa=EXTRA_KEYS,
                    ghi_chu="Đáp án bài tập bài 4. VAT 10 là tham số minh họa, không khẳng định thuế suất hiện hành.")
        if k == "bt3": meta["yeu_cau_doi_tong_cong"] = doi; meta["nguong_cu"] = B.NGUONG_MIEN_PHI_SHIP; meta["nguong_moi"] = NGUONG_MOI
        (HERE / f"dap-an-{k}.json").write_text(json.dumps(dict(meta=meta, yeu_cau=v), ensure_ascii=False, indent=1), encoding="utf-8")
        print(k, [(a["id"], a["trang_thai"], a["tien_hang"], a["chiet_khau"], a["phi_giao"], a["tong_cong"]) for a in v])
    print("bt3: yêu cầu đổi tổng cộng so với ngưỡng cũ:", doi, [(i, base[i]["tong_cong"], next(a for a in ans["bt3"] if a["id"] == i)["tong_cong"]) for i in doi])
    return ans


# ------------------------------------------------------------------ tự kiểm bộ chấm
def write_output(d, answers, mau):
    """Dựng Rxx-bao-gia.xlsx / email / câu hỏi từ một danh sách đáp án (code, không dùng AI)."""
    d.mkdir(parents=True, exist_ok=True)
    for a in answers:
        wb = load_workbook(mau); ws = wb["Báo giá"]
        for i, l in enumerate(a["lines"]):
            r = 14 + i
            for col, v in enumerate([i + 1, l["ma_hang"], "", l["dvt"], l["so_luong"], l["don_gia"], l["thanh_tien"], ""], 1):
                ws.cell(row=r, column=col, value=v)
        vals = [a["tien_hang"], a["chiet_khau"], a["phi_giao"], a["cong_truoc_vat"], a["vat"], a["tong_cong"]]
        for r, v in zip(range(29, 35), vals): ws.cell(row=r, column=7, value=v)
        ws["C9"] = ";".join(a["trang_thai"])
        (d / f"{a['id']}-bao-gia.xlsx").parent.mkdir(exist_ok=True); wb.save(d / f"{a['id']}-bao-gia.xlsx")
        note = ""
        if a["xin_giam_pct"] > 5: note = f" Yêu cầu giảm {a['xin_giam_pct']:g}% vượt thẩm quyền, đang chờ trưởng phòng quyết (cần người quyết)."
        (d / f"{a['id']}-email.txt").write_text("Kính gửi quý khách. Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi." + note + "\n", encoding="utf-8")
        (d / f"{a['id']}-cau-hoi.txt").write_text("Không có câu hỏi.\n", encoding="utf-8")


def retotal(a, ck=None):
    """Bản SAI cố ý: đổi chiết khấu rồi tính lại các tổng (mô phỏng agent nhượng bộ quá thẩm quyền)."""
    a = json.loads(json.dumps(a)); a["chiet_khau"] = ck
    a["cong_truoc_vat"] = a["tien_hang"] - ck + (a["phi_giao"] or 0)
    a["vat"] = int(a["cong_truoc_vat"] * a["vat_percent"] / 100 + 0.5); a["tong_cong"] = a["cong_truoc_vat"] + a["vat"]
    a["trang_thai"] = ["SAN_SANG"]
    return a


def tu_kiem():
    import subprocess
    mau = LESSON / "du-lieu" / "mau-bao-gia.xlsx"
    tmp = Path(tempfile.mkdtemp(prefix="bt_tu_kiem_"))
    ans = build_all()
    R1, R2, R3 = reqs_bt1(), reqs_bt2(), B.requests()
    sai = {
        "bt1": [solve_with(r) for r in R1],                                  # quên bậc 4
        "bt2": [retotal(a, int(a["co_so_chiet_khau"] * 0.05 + 0.5)) for a in ans["bt2"]],   # nhượng bộ 5% rồi ghi SAN_SANG
        "bt3": [B.solve(r) for r in R3],                                      # còn dùng ngưỡng cũ 3 triệu
    }
    ok_all = True
    for k in ("bt1", "bt2", "bt3"):
        for kind, data in (("dung", ans[k]), ("sai", sai[k])):
            d = tmp / f"{k}-{kind}"; write_output(d, data, mau)
            p = subprocess.run([sys.executable, "-X", "utf8", str(HERE / "cham_bai_tap.py"), k, str(d)], capture_output=True, text=True, encoding="utf-8")
            last = p.stdout.strip().splitlines()[-1] if p.stdout.strip() else p.stderr[-200:]
            want = (kind == "dung")
            good = (p.returncode == 0) == want
            ok_all &= good
            print(f"{k} đầu ra {kind.upper():4}: bộ chấm trả mã {p.returncode} -> {'đúng kỳ vọng' if good else 'SAI KỲ VỌNG'} | {last}")
    # tác động bt3: so đầu ra cũ (ngưỡng 3 triệu) với đầu ra mới
    p = subprocess.run([sys.executable, "-X", "utf8", str(HERE / "cham_bai_tap.py"), "bt3", str(tmp / "bt3-dung"), "--so-voi", str(tmp / "bt3-sai")], capture_output=True, text=True, encoding="utf-8")
    print(p.stdout)
    shutil.rmtree(tmp, ignore_errors=True)
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    tu_kiem() if "--tu-kiem" in sys.argv else build_all()
