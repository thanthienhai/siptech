# GHI CHÚ VỀ ĐỊNH DẠNG MỚI CỦA CHI NHÁNH NHA TRANG (THÁNG 11/2026)

**Người lập:** Trợ lý Kế toán Quản trị  
**Đơn vị:** Công ty TNHH Mẫu An Phát  
**Đối tượng phân tích:** File `goc/NhaTrang_doanhthu_T11.xlsx` (phần mềm mới) so với `thang-truoc/goc/NhaTrang_doanhthu_T10.xlsx` (phần mềm cũ).

---

## 1. So sánh chi tiết cấu trúc file mới và file cũ

Qua kiểm tra dữ liệu thô (raw data) của 2 file Excel từ chi nhánh Nha Trang, các điểm khác biệt cơ bản được ghi nhận như sau:

| Tiêu chí | File cũ (Tháng 10/2026) | File mới (Tháng 11/2026) | Chi tiết sai khác |
| :--- | :--- | :--- | :--- |
| **Vị trí dòng tiêu đề** | Dòng 3 (dòng 1 là tiêu đề báo cáo, dòng 2 là nhóm gộp `THÔNG TIN BÁN HÀNG` & `SỐ LIỆU`) | Dòng 2 (dòng 1 là tiêu đề báo cáo, không còn dòng gộp phân nhóm) | Dòng tiêu đề đẩy lên sớm hơn 1 dòng; dữ liệu bắt đầu từ dòng 3 thay vì dòng 4. |
| **Số lượng cột** | 6 cột | 7 cột | Thêm 1 cột mới (`Kênh bán`). |
| **Thứ tự các cột** | 1. Ngày GD<br>2. Chứng từ<br>3. Hàng hóa<br>4. SL<br>5. Đơn giá<br>6. Thành tiền | 1. Mã chứng từ<br>2. Ngày<br>3. Kênh bán<br>4. Hàng hóa<br>5. Số lượng<br>6. Giá niêm yết<br>7. Doanh số (VNĐ) | Đổi vị trí cột ngày và cột chứng từ; chèn thêm cột Kênh bán vào giữa. |
| **Tên các cột** | `Ngày GD`, `Chứng từ`, `Hàng hóa`, `SL`, `Đơn giá`, `Thành tiền` | `Mã chứng từ`, `Ngày`, `Kênh bán`, `Hàng hóa`, `Số lượng`, `Giá niêm yết`, `Doanh số (VNĐ)` | Đổi tên 5 cột; thêm 1 cột mới; chỉ giữ nguyên tên cột `Hàng hóa`. |
| **Kiểu dữ liệu ngày** | Chuỗi ký tự (String) dạng `DD-MM-YY` (ví dụ: `'01-10-26'`) | Chuỗi ký tự (String) dạng chuẩn ISO 8601 `YYYY-MM-DD` (ví dụ: `'2026-11-01'`) | Định dạng mới chuẩn hóa quốc tế, rõ ràng, không bị đảo ngày/tháng, năm đủ 4 chữ số. |
| **Kiểu dữ liệu số (SL)** | Số nguyên (`int`) | Số nguyên (`int`) | Không thay đổi về bản chất kiểu dữ liệu. |
| **Kiểu dữ liệu số tiền (Đơn giá, Thành tiền)** | Chuỗi ký tự (String) có định dạng dấu phẩy phân cách hàng nghìn (ví dụ: `'68,000'`, `'680,000'`) | Số nguyên thuần túy (`int`) không chứa dấu phẩy (ví dụ: `68000`, `544000`) | Phần mềm mới xuất số trực tiếp dạng numeric thay vì lưu chuỗi text. |
| **Dòng tổng cộng cuối file** | Dòng 170: nhãn `'Tổng cộng'` ở cột `Hàng hóa`, số tiền ở cột `Thành tiền` | Dòng 160: nhãn `'Tổng:'` ở cột `Giá niêm yết`, số tiền ở cột `Doanh số (VNĐ)` | Nhãn tổng cộng đổi từ `'Tổng cộng'` sang `'Tổng:'`, vị trí nhãn đổi sang cột 6. |

---

## 2. Quyết định xử lý và ánh xạ cho từng cột

Dưới đây là quyết định ánh xạ từ các cột trong file mới của Nha Trang vào cấu trúc bảng dữ liệu hợp nhất chuẩn của công ty (`hop_nhat.csv`), kèm theo căn cứ và lý do kế toán:

### 2.1. Cột `Mã chứng từ` (Đổi tên từ `Chứng từ`, vị trí cột 1)
- **Quyết định:** Ánh xạ vào trường `so_chung_tu`.
- **Lý do:** Đây là mã định danh chứng từ/hóa đơn bán hàng, có quy tắc đánh số `NT/xxxx` (từ `NT/0001` đến `NT/0155`) hoàn toàn tương đồng với tháng trước.

### 2.2. Cột `Ngày` (Đổi tên từ `Ngày GD`, vị trí cột 2)
- **Quyết định:** Ánh xạ vào trường `ngay`. Nhận diện chuỗi ngày `YYYY-MM-DD`, xác thực trong kỳ tháng 11/2026 (`2026-11-01` đến `2026-11-30`), gán trạng thái `OK`.
- **Lý do:** Định dạng ISO 8601 `YYYY-MM-DD` có năm 4 chữ số, tháng 2 chữ số, ngày 2 chữ số, hoàn toàn chuẩn xác và không gây hiểu lầm ngày/tháng như định dạng cũ.

### 2.3. Cột `Kênh bán` (Cột mới thêm, vị trí cột 3)
- **Quyết định:** **KHÔNG đưa vào doanh thu** và **KHÔNG đưa vào bảng hợp nhất chuẩn `hop_nhat.csv`** (giữ đúng cấu trúc 11 trường dữ liệu chuẩn toàn công ty).
- **Lý do:** Cột này chứa các giá trị phân loại kênh bán lẻ: `'Tại quầy'`, `'Online'`, `'Đại lý'`. Đây là chiều phân tích quản trị (dimension), không phải cột số tiền hay doanh thu. Bảng hợp nhất toàn công ty hiện tại chỉ áp dụng chuẩn chung cho 6 chi nhánh (5 chi nhánh còn lại không có cột này).
- **Đánh giá & Kiến nghị:** Cột này rất có giá trị cho công tác quản trị bán hàng đa kênh. Đề xuất Ban Giám đốc xem xét áp dụng quy chuẩn cột này cho toàn bộ 5 chi nhánh còn lại trong kỳ tới.

### 2.4. Cột `Hàng hóa` (Giữ nguyên tên, vị trí cột 4)
- **Quyết định:** Ánh xạ vào trường `ma_san_pham` thông qua hàm chuẩn hóa `normalize_product()`.
- **Lý do:** Tên các mặt hàng vẫn tuân thủ cách gọi thông thường (ví dụ: `'NƯỚC MẮM TRUYỀN THỐNG 500ML'`, `'Bánh tráng muối tôm 250g'`, `'GẠO ST25 5KG'`,...), ánh xạ khớp 100% về 8 mã sản phẩm chuẩn SP01 đến SP08 của công ty.

### 2.5. Cột `Số lượng` (Đổi tên từ `SL`, vị trí cột 5)
- **Quyết định:** Ánh xạ vào trường `so_luong`.
- **Lý do:** Là số lượng sản phẩm bán ra thực tế trong từng giao dịch.

### 2.6. Cột `Giá niêm yết` (Đổi tên từ `Đơn giá`, vị trí cột 6)
- **Quyết định:** Ánh xạ vào trường `don_gia`.
- **Lý do:** Thể hiện đơn giá bán của sản phẩm. Kiểm tra đối chiếu số học cho thấy 155/157 dòng đều có `Số lượng * Giá niêm yết = Doanh số (VNĐ)`. Do đó, "Giá niêm yết" ở đây chính là đơn giá thực tế dùng để tính doanh thu, không có chiết khấu ẩn trên từng dòng.

### 2.7. Cột `Doanh số (VNĐ)` (Đổi tên từ `Thành tiền`, vị trí cột 7)
- **Quyết định:** Ánh xạ vào trường `doanh_thu`.
- **Lý do:** Đây là số tiền bán hàng thực tế thu được từ từng dòng giao dịch, tương đương với trường `Thành tiền` ở các chi nhánh khác.

---

## 3. Các điểm nghi vấn và đề xuất người có thẩm quyền quyết định (CẦN NGƯỜI QUYẾT)

### 3.1. Vấn đề 1: Tên cột `Giá niêm yết` thay vì `Đơn giá thực bán`
- **Tình trạng:** Tiêu đề cột ghi là "Giá niêm yết". Trong nghiệp vụ thương mại, giá niêm yết có thể khác giá thực bán nếu có chính sách giảm giá, voucher hoặc chiết khấu thương mại mà phần mềm mới không xuất cột chiết khấu.
- **Trạng thái:** **CẦN NGƯỜI QUYẾT** (Kế toán trưởng / Giám đốc bán hàng).
- **Tạm xử lý:** 
  - Qua kiểm toán số học tự động: 155/157 dòng có tích số `Số lượng x Giá niêm yết` bằng chính xác 100% số tiền tại `Doanh số (VNĐ)`.
  - Có 2 dòng phát sinh chênh lệch:
    + Dòng 70 đơn `NT/0068` ('Mat ong rung 250ml'): SL 20 x 194.000đ = 3.880.000đ, nhưng Doanh số ghi 3.930.000đ (lệch +50.000đ).
    + Dòng 147 đơn `NT/0143` ('Điều rang muối 500g'): SL 30 x 220.000đ = 6.600.000đ, nhưng Doanh số ghi 6.650.000đ (lệch +50.000đ).
  - Tạm thời ghi nhận `Giá niêm yết` là `don_gia` và giữ nguyên số tiền chi nhánh ghi nhận tại `doanh_thu` (3.930.000đ và 6.650.000đ) theo nguyên tắc thận trọng.
  - Đồng thời đưa 2 giao dịch này vào file `ra/viec_can_hoi.csv` (loại `LECH_THANH_TIEN`) để yêu cầu chi nhánh Nha Trang giải trình nguyên nhân tính lệch +50.000đ mỗi đơn.

### 3.2. Vấn đề 2: Dữ liệu cột `Kênh bán`
- **Tình trạng:** Chi nhánh Nha Trang cung cấp thêm dữ liệu phân loại kênh bán lẻ (Online, Tại quầy, Đại lý), trong khi 5 chi nhánh còn lại chưa có thông tin này.
- **Trạng thái:** **CẦN NGƯỜI QUYẾT** (Ban Giám đốc).
- **Tạm xử lý:** Không đưa cột này vào file hợp nhất `ra/hop_nhat.csv` trong kỳ này để đảm bảo toàn bộ hệ thống file đầu ra đồng nhất 100% định dạng với tháng trước và khớp chuẩn giữa 6 chi nhánh. Đề xuất kỳ sau ban hành quy định bắt buộc toàn công ty báo cáo thêm cột Kênh bán.

### 3.3. Vấn đề 3: Trùng lặp chứng từ tại chi nhánh Nha Trang
- **Tình trạng:** Phát hiện 2 chứng từ bị nhập đúp 2 lần liên tiếp:
  - Dòng 90 trùng hoàn toàn dòng 89 (đơn `NT/0087`, Cafe rang xay 500g, SL 24, giá trị **3.480.000 VNĐ**).
  - Dòng 146 trùng hoàn toàn dòng 145 (đơn `NT/0142`, Trà sen (200g), SL 20, giá trị **2.400.000 VNĐ**).
- **Trạng thái:** **CẦN NGƯỜI QUYẾT** (Chi nhánh Nha Trang & Kế toán trưởng xác nhận hủy dòng trùng).
- **Tạm xử lý:** Theo nguyên tắc thận trọng và phòng chống ghi khống doanh thu, hệ thống script tự động loại bỏ 2 dòng trùng lặp này khỏi doanh thu hợp nhất (tổng giảm trừ **5.880.000 VNĐ**) và đưa vào danh sách kiểm tra `ra/viec_can_hoi.csv`.
