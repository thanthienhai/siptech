import pandas as pd
import openpyxl, re, csv, unicodedata

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
df_orders['amount'] = df_orders['Tổng phải thu'].apply(clean_amount)
df_orders['kh_clean'] = df_orders['Khách hàng'].apply(strip_accents).str.upper()

with open('sao-ke-t10-2026.csv', encoding='utf-8-sig') as f:
    rows = list(csv.reader(f))

txs = [r for r in rows[8:] if r and r[0] and 'Tong phat sinh' not in r[0] and 'So du cuoi' not in r[0]]

# Let's check:
# 1. TX #77: 91910299 | 18/10/2026 | co | 2,440,000 | PHAM QUOC TOAN CK
print("=== Checking PHAM QUOC TOAN and 2,440,000 ===")
print("Orders for Pham Quoc Toan:")
print(df_orders[df_orders['kh_clean'].str.contains('TOAN')])
print("Orders with amount 2,440,000:")
print(df_orders[df_orders['amount'] == 2440000])

# 2. TX #65: 62820400 | 16/10/2026 | co | 3,200,000 | TT HD 0087
print("\n=== Checking TT HD 0087 and 3,200,000 ===")
print("Orders with 3,200,000:")
print(df_orders[df_orders['amount'] == 3200000])
print("Orders around 087:")
print(df_orders[df_orders['Mã đơn'].isin(['DH2610-086', 'DH2610-087', 'DH2610-088'])])

# 3. TX #136: 90546478 | 29/10/2026 | co | 980,000 | LE TRUNG KIEN gui tien
print("\n=== Checking LE TRUNG KIEN and 980,000 ===")
print("Orders with KIEN:")
print(df_orders[df_orders['kh_clean'].str.contains('KIEN')])
print("Orders with 980,000:")
print(df_orders[df_orders['amount'] == 980000])

# 4. TX #118: 72253631 | 27/10/2026 | co | 560,000 | MUA HANG ZALO
print("\n=== Checking 560,000 orders ===")
print(df_orders[df_orders['amount'] == 560000])

# 5. TX #44: 32051028 | 11/10/2026 | co | 700,000 | CHUYEN KHOAN
print("\n=== Checking 700,000 orders ===")
print(df_orders[df_orders['amount'] == 700000])

# 6. TX #7: 28058043 | 03/10/2026 | co | 1,530,000 | TRA TIEN
print("\n=== Checking 1,530,000 orders ===")
print(df_orders[df_orders['amount'] == 1530000])
