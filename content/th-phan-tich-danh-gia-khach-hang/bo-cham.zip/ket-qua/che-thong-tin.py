"""Che số điện thoại, email, đường link trong cột noi_dung TRƯỚC khi đưa đánh giá cho agent/dịch vụ đám mây.

Dùng:  python -X utf8 che-thong-tin.py <vao.csv> <ra.csv>
Chỉ che được mẫu có hình dạng rõ (số điện thoại 9-11 chữ số, email, link). KHÔNG che được tên người, địa chỉ viết tự do:
phần đó cần người đọc lướt qua. Đây là bước giảm rủi ro, không phải bảo đảm tuyệt đối.
"""
import csv, re, sys
PAT = [(re.compile(r"(?<!\d)(?:\+?84|0)(?:[\s.\-]?\d){8,10}(?!\d)"), "[SĐT]"),
       (re.compile(r"[\w.+\-]+@[\w\-]+\.[\w.\-]+"), "[EMAIL]"),
       (re.compile(r"(?:https?://|www\.)\S+|\b[\w\-]+\.(?:com|vn|me|ly)/\S*"), "[LINK]")]
def che(s):
    n = 0
    for p, rep in PAT: s, k = p.subn(rep, s); n += k
    return s, n
rows = list(csv.DictReader(open(sys.argv[1], encoding="utf-8-sig"))); tong = 0
for r in rows: r["noi_dung"], k = che(r["noi_dung"]); tong += k
w = csv.DictWriter(open(sys.argv[2], "w", encoding="utf-8", newline=""), list(rows[0])); w.writeheader(); w.writerows(rows)
print(f"đã che {tong} chỗ trong {len(rows)} dòng")
