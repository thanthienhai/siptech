import pandas as pd
import openpyxl, re, csv, unicodedata

def clean_amount(val):
    if pd.isna(val): return 0
    if isinstance(val, (int, float)): return int(val)
    s = str(val).replace('.', '').replace(',', '').replace('đ', '').replace('VND', '').replace(' ', '')
    return int(s)

def strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFD', str(s)) if unicodedata.category(c) != 'Mn').replace('đ', 'd').replace('Đ', 'D')

# 1. Load orders
df_orders = pd.read_excel('so-don-hang-t10-2026.xlsx')
df_orders['amount'] = df_orders['Tổng phải thu'].apply(clean_amount)
df_orders['kh_clean'] = df_orders['Khách hàng'].apply(strip_accents).str.upper()

orders_dict = {}
for idx, r in df_orders.iterrows():
    orders_dict[r['Mã đơn']] = {
        'ma_don': r['Mã đơn'],
        'ngay': str(r['Ngày đặt'])[:10],
        'kh': r['Khách hàng'],
        'kh_clean': r['kh_clean'],
        'amount': r['amount'],
        'pttt': r['Hình thức TT'],
        'trang_thai': r['Trạng thái'],
        'ghi_chu': str(r['Ghi chú']) if pd.notna(r['Ghi chú']) else ''
    }

# 2. Load sao ke
with open('sao-ke-t10-2026.csv', encoding='utf-8-sig') as f:
    rows = list(csv.reader(f))

# Find header
start = None
for i, r in enumerate(rows):
    if len(r) >= 6 and r[0] == 'Ngày GD':
        start = i
        break

txs = [r for r in rows[start+1:] if r and r[0] and 'Tong phat sinh' not in r[0] and 'So du cuoi' not in r[0]]

print(f"Total transactions: {len(txs)}")

# Let's write extraction logic for order candidates from description
def extract_orders(text):
    text_up = text.upper()
    # Normalize O to 0 in DH261O
    text_up = re.sub(r'DH261O', 'DH2610', text_up)
    # DH 2610 xxx -> DH2610-xxx
    text_up = re.sub(r'DH\s*2610\s*[-]?\s*(\d+)', r'DH2610-\1', text_up)
    text_up = re.sub(r'DH-2610-(\d+)', r'DH2610-\1', text_up)
    text_up = re.sub(r'DH2610(\d{3})', r'DH2610-\1', text_up)
    
    # Standard matches
    m = re.findall(r'DH2610-(\d+)', text_up)
    found = []
    for num_str in m:
        num = int(num_str)
        code = f"DH2610-{num:03d}"
        if code in orders_dict and code not in found:
            found.append(code)
            
    # Phrases like "don 003", "don hang so 33", "don hang so 58", "don hang so 81", "don hang so 89"
    m_so = re.findall(r'(?:DON HANG SO|DON HANG|DON|HD)\s*(\d+)', text_up)
    for num_str in m_so:
        num = int(num_str)
        code = f"DH2610-{num:03d}"
        if code in orders_dict and code not in found:
            found.append(code)
            
    # Sequences like "TT 3 don 116 024 097" or "DH2610-098 105 090"
    m_seq = re.findall(r'\b(\d{3})\b', text_up)
    for num_str in m_seq:
        num = int(num_str)
        code = f"DH2610-{num:03d}"
        if code in orders_dict and code not in found:
            # Check if text suggests multi orders: "TT 3 don" or "DH2610-xxx yyy zzz"
            if "TT 3 DON" in text_up or re.search(r'DH2610-\d{3}\s+\d{3}', text_up):
                found.append(code)

    return found

print("\n--- Testing extraction on all transactions ---")
for idx, r in enumerate(txs):
    ngay, so_ct, no, co, du, nd = r[0], r[1], r[2], r[3], r[4], r[5]
    chieu = 'no' if no.strip() else 'co'
    st = int(no.replace(',', '')) if chieu == 'no' else int(co.replace(',', ''))
    cands = extract_orders(nd)
    if cands:
        # Check amount
        expected_total = sum(orders_dict[c]['amount'] for c in cands)
        diff = st - expected_total
        print(f"[{so_ct}] {ngay} {chieu} {st:>10,d} | cands: {cands} (exp: {expected_total:,d}, diff: {diff}) | {nd}")
    else:
        print(f"[{so_ct}] {ngay} {chieu} {st:>10,d} | NO CANDIDATE | {nd}")
