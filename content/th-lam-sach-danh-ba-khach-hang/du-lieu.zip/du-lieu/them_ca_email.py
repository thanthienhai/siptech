"""Thêm vào danh bạ giả 5 dòng "email trùng nhưng tên khác hẳn" để tập bài tập 2 (bài 4).

Chạy:  python -X utf8 them_ca_email.py [danh-ba-goc.xlsx] [thư_mục_ra]
Mặc định: đọc danh-ba-goc.xlsx cạnh script, ghi vào thư mục bai-tap-email/ cạnh script:
  bai-tap-email/danh-ba-goc.xlsx   400 dòng gốc + 5 dòng mới R401..R405 (đưa cho agent)
  ../ket-qua/bai-tap/ca-email-dap-an.json   5 cặp (dòng cũ, dòng mới) — KHÔNG đưa cho agent
Hạt giống cố định (20261221): chạy lại ra đúng bản cũ. 100% dữ liệu giả.
Mỗi dòng mới: cùng email với một dòng cũ (đổi hoa/thường), tên của một người khác hẳn, SĐT mới (dãy 555 kiểu phim).
"""
import json, random, re, sys, unicodedata
from pathlib import Path
import openpyxl

SEED = 20261221
HERE = Path(__file__).resolve().parent
SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "danh-ba-goc.xlsx"
OUT = Path(sys.argv[2]) if len(sys.argv) > 2 else HERE / "bai-tap-email"
ANS = (OUT.parent.parent / "ket-qua" / "bai-tap" / "ca-email-dap-an.json") if len(sys.argv) <= 2 else OUT / "ca-email-dap-an.json"
EMAIL = re.compile(r"^[a-z0-9._%+-]+@[a-z0-9-]+(\.[a-z0-9-]+)+$")

def key(s):
    s = unicodedata.normalize("NFD", (s or "").replace("đ", "d").replace("Đ", "D"))
    return re.sub(r"\s+", " ", "".join(c for c in s if unicodedata.category(c) != "Mn").lower()).strip()

wb = openpyxl.load_workbook(SRC)
ws = wb.active
rows = [list(r) for r in ws.iter_rows(values_only=True)]
head, body = rows[0], [r for r in rows[1:] if r[0]]
rng = random.Random(SEED)

emails = {}
for r in body:
    e = (r[4] or "").strip().lower()
    emails[e] = emails.get(e, 0) + 1
phones = {re.sub(r"\D", "", str(r[3] or "")) for r in body}
names = [r[2] for r in body if r[2] and len(key(r[2]).split()) >= 3]
# dòng đích: email hợp lệ, chỉ xuất hiện 1 lần trong file
cands = [r for r in body if EMAIL.match((r[4] or "").strip().lower()) and emails[(r[4] or "").strip().lower()] == 1]
targets = rng.sample(cands, 5)

pairs, new_rows = [], []
for i, t in enumerate(targets, start=1):
    while True:
        nm = rng.choice(names)
        if not set(key(nm).split()) & set(key(t[2]).split()):
            break
    while True:
        ph = "0" + rng.choice("3579") + str(rng.randint(0, 9)) + "5550" + f"{rng.randint(0, 999):03d}"
        if ph not in phones:
            phones.add(ph); break
    em = t[4].strip()
    em = em[0].upper() + em[1:]  # Chỉ đổi hoa/thường: chuẩn hóa chữ thường phải đưa về cùng email
    rid = f"R{400 + i}"
    new_rows.append([rid, "Zalo", nm, f"{ph[:4]} {ph[4:7]} {ph[7:]}", em, None, None])
    pairs.append({"dong_cu": t[0], "dong_moi": rid, "email": t[4].strip().lower(), "ten_cu": t[2], "ten_moi": nm})

OUT.mkdir(parents=True, exist_ok=True)
wb2 = openpyxl.Workbook(); w2 = wb2.active; w2.title = ws.title
w2.append(head)
for r in body + new_rows: w2.append(r)
wb2.save(OUT / "danh-ba-goc.xlsx")
ANS.parent.mkdir(parents=True, exist_ok=True)
ANS.write_text(json.dumps({"hat_giong": SEED, "so_dong": len(body) + 5, "cap_email_trung_ten_khac": pairs}, ensure_ascii=False, indent=1), encoding="utf-8")
print(f"Đã ghi {OUT / 'danh-ba-goc.xlsx'} ({len(body) + 5} dòng) và {ANS}")
for p in pairs: print(" ", p["dong_cu"], p["dong_moi"], p["email"])
