"""Đo lại sai số hai tháng giữ lại từ file giu-lai-do-loi.csv (không dùng agent, không dùng đáp án).

Dùng:  python -X utf8 do_giu_lai.py <thu-muc-chua-giu-lai-do-loi.csv>
In, với mỗi tháng và với gộp các tháng: n (số mã-tháng tính được), MAE và WAPE của
công thức (cột du_bao) và của mốc "bằng tháng trước" (cột moc_thang_truoc), so với thuc_te.
WAPE = tổng |dự báo - thực tế| / tổng thực tế. Chỉ tính các dòng có tinh_duoc = CO.
"""
import csv
import sys
from collections import defaultdict
from pathlib import Path


def doc(thu_muc):
    with open(Path(thu_muc) / "giu-lai-do-loi.csv", encoding="utf-8-sig", newline="") as f:
        return [r for r in csv.DictReader(f) if r["tinh_duoc"] == "CO"]


def do(rows):
    n = len(rows)
    tong = sum(float(r["thuc_te"]) for r in rows)
    out = {"n": n}
    for ten, cot in (("cong_thuc", "du_bao"), ("moc_thang_truoc", "moc_thang_truoc")):
        sai = [abs(float(r[cot]) - float(r["thuc_te"])) for r in rows]
        out[ten] = {"mae": sum(sai) / n, "wape": sum(sai) / tong}
    return out


def main():
    rows = doc(sys.argv[1] if len(sys.argv) > 1 else ".")
    theo_thang = defaultdict(list)
    for r in rows:
        theo_thang[r["thang"]].append(r)
    cac = [(t, v) for t, v in sorted(theo_thang.items())] + [("gop", rows)]
    print(f"{'thang':8} {'n':>4} {'WAPE cong thuc':>15} {'WAPE moc thang truoc':>21} {'MAE ct':>8} {'MAE moc':>8}  ket luan")
    for ten, v in cac:
        d = do(v)
        ct, mc = d["cong_thuc"], d["moc_thang_truoc"]
        kl = "cong thuc THUA moc" if ct["wape"] > mc["wape"] else "cong thuc THANG moc"
        print(f"{ten:8} {d['n']:>4} {ct['wape']*100:>14.1f}% {mc['wape']*100:>20.1f}% {ct['mae']:>8.1f} {mc['mae']:>8.1f}  {kl}")


if __name__ == "__main__":
    main()
