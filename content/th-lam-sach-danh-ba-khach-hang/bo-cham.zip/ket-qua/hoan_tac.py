"""Hoàn tác một lần gộp: cho mã khách (KH...) -> in ra đúng các dòng GỐC đã bị gộp vào khách đó.

Dùng:  python -X utf8 hoan_tac.py <thư_mục_kết_quả> <ma_khach> [--ghi tach.csv]
Không sửa file nào của agent; chỉ đọc nhat-ky-gop.csv và danh-ba-goc.xlsx. Với --ghi, lưu các dòng gốc ra một CSV
để bạn dán lại thành các khách riêng trong công cụ của bạn.
"""
import sys, csv
from pathlib import Path
import openpyxl

def main():
    d = Path(sys.argv[1]); kh = sys.argv[2]
    gop = list(csv.DictReader((d / "nhat-ky-gop.csv").read_text(encoding="utf-8-sig").splitlines()))
    ids = [g for g in gop if g["ma_khach"].strip() == kh]
    if not ids: sys.exit(f"Không thấy {kh} trong nhat-ky-gop.csv")
    ws = openpyxl.load_workbook(d / "danh-ba-goc.xlsx").active
    rows = list(ws.iter_rows(values_only=True)); head = rows[0]; by = {str(r[0]): r for r in rows[1:]}
    out = []
    print(f"{kh} gồm {len(ids)} dòng gốc:")
    for g in ids:
        r = by[g["ma_dong_goc"].strip()]; out.append(r)
        print(f"  {g['ma_dong_goc']}  [{g['hanh_dong']}, {g['quy_tac']}]  " + " | ".join("" if v is None else str(v) for v in r[1:]))
        print(f"      vì sao gộp: {g['bang_chung']}")
    if "--ghi" in sys.argv:
        p = Path(sys.argv[sys.argv.index("--ghi") + 1])
        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f); w.writerow(head); w.writerows(out)
        print("Đã ghi", p)

if __name__ == "__main__":
    main()
