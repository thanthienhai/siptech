"""Chấm kết quả của bài 4 (nhóm 00) bằng code. Đáp án được TÍNH LẠI từ don-hang-thu.csv, không có file đáp án.

Chạy:  python -X utf8 cham_bai_4.py <thư mục agent đã làm việc>
File này và don-hang-thu.csv gốc nằm trong du-lieu, KHÔNG chép vào thư mục của agent.
"""
import csv
import hashlib
import re
import sys
from collections import defaultdict
from pathlib import Path

goc = Path(__file__).parent / "don-hang-thu.csv"
run = Path(sys.argv[1])
ket = []


def kiem(ten, ok, chi_tiet=""):
    ket.append(ok)
    print(("ĐẠT    " if ok else "KHÔNG  ") + ten + (f"  ({chi_tiet})" if chi_tiet else ""))


def doc_csv(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


# đáp án tính lại từ file gốc
don = defaultdict(set)
tien = defaultdict(int)
for r in doc_csv(goc):
    don[r["khach"]].add(r["ma_don"])
    tien[r["khach"]] += int(r["so_luong"]) * int(r["don_gia"])
tong_goc = sum(tien.values())
nhat = max(tien, key=tien.get)

kiem("có tong_hop.py", (run / "tong_hop.py").exists())
f_in = run / "don-hang-thu.csv"
kiem("không sửa don-hang-thu.csv", f_in.exists() and hashlib.sha256(f_in.read_bytes()).digest() == hashlib.sha256(goc.read_bytes()).digest())

out = run / "tong_theo_khach.csv"
if out.exists():
    rows = doc_csv(out)
    kiem("cột đúng: khach, so_don, tong_tien", rows and list(rows[0].keys()) == ["khach", "so_don", "tong_tien"])
    try:
        got = {r["khach"]: (int(r["so_don"]), int(r["tong_tien"])) for r in rows}
        want = {k: (len(don[k]), tien[k]) for k in tien}
        kiem("số khách và số đơn, tổng tiền từng khách khớp", got == want, f"{sum(got.get(k) == v for k, v in want.items())}/{len(want)} khách khớp")
        ds = [int(r["tong_tien"]) for r in rows]
        kiem("xếp tổng tiền giảm dần", ds == sorted(ds, reverse=True))
        kiem("tổng các khách bằng tổng toàn file", sum(ds) == tong_goc, f"{sum(ds):,} so với {tong_goc:,}")
    except (ValueError, KeyError) as e:
        kiem("đọc được số trong tong_theo_khach.csv", False, repr(e))
else:
    kiem("có tong_theo_khach.csv", False)

bc = run / "bao_cao.md"
if bc.exists():
    t = bc.read_text(encoding="utf-8")
    dong = [l for l in t.splitlines() if l.strip()]
    kiem("bao_cao.md tối đa 8 dòng", len(dong) <= 8, f"{len(dong)} dòng")
    kiem("bao_cao.md nêu đúng khách mua nhiều nhất", nhat in t, nhat)
    so = re.sub(r"[.,\s]", "", t)
    kiem("bao_cao.md nêu đúng tổng doanh thu", str(tong_goc) in so, f"{tong_goc:,}")
else:
    kiem("có bao_cao.md", False)

print(f"\n{sum(ket)}/{len(ket)} tiêu chí đạt")
sys.exit(0 if all(ket) else 1)
