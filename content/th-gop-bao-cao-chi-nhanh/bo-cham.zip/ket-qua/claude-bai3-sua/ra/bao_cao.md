# Báo cáo doanh thu tháng 11/2026 - Công ty Mẫu An Phát

_Tạo tự động bởi `gop.py` từ 6 file chi nhánh trong `goc/`. Mọi số liệu do script tính, đơn vị đồng, không làm tròn._

## 1. Tóm tắt cho giám đốc

- **Tổng doanh thu tháng 11/2026: 1.503.750.000 đ** (877 dòng bán hàng đã xác định: 761 dòng OK, 116 dòng SUY_RA).
- Chưa tính vì cần người quyết: **7.640.000 đ** (3 dòng CAN_NGUOI_QUYET).
- Đã loại khỏi bảng hợp nhất: 5 dòng trùng (7.495.000 đ) và 4 dòng ngoài kỳ (5.526.000 đ).
- Tổng các chi nhánh tự ghi ở cuối bảng: 1.524.511.000 đ; tổng các dòng đọc được: 1.524.411.000 đ; tổng bảng hợp nhất: 1.503.750.000 đ.
- Việc cần hỏi lại chi nhánh: **25 mục** (KHAC: 2, LECH_THANH_TIEN: 2, NGAY_MO_HO: 8, NGOAI_KY: 4, SAI_TONG: 1, SAN_PHAM_LA: 2, THIEU_DU_LIEU: 1, TRUNG: 5).

## 2. Doanh thu theo chi nhánh

| Mã | Chi nhánh | Số dòng | Doanh thu (đ) | Tỷ trọng |
|---|---|---:|---:|---:|
| HN | Hà Nội | 151 | 224.799.000 | 14.95% |
| HP | Hải Phòng | 142 | 253.599.000 | 16.86% |
| DN | Đà Nẵng | 161 | 285.924.000 | 19.01% |
| CT | Cần Thơ | 118 | 214.846.000 | 14.29% |
| BH | Biên Hòa | 150 | 269.037.000 | 17.89% |
| NT | Nha Trang | 155 | 255.545.000 | 16.99% |
| **Tổng** |  | 877 | **1.503.750.000** | 100.00% |

## 3. Doanh thu theo sản phẩm

| Mã | Sản phẩm | Số lượng | Doanh thu (đ) | Tỷ trọng |
|---|---|---:|---:|---:|
| SP01 | Gạo ST25 túi 5kg | 1.389 | 228.313.000 | 15.18% |
| SP02 | Nước mắm truyền thống chai 500ml | 1.323 | 89.616.000 | 5.96% |
| SP03 | Cà phê rang xay 500g | 1.698 | 246.427.000 | 16.39% |
| SP04 | Trà sen 200g | 1.531 | 184.668.000 | 12.28% |
| SP05 | Mật ong rừng 250ml | 1.246 | 230.101.000 | 15.30% |
| SP06 | Hạt điều rang muối 500g | 1.441 | 304.630.000 | 20.26% |
| SP07 | Bánh tráng muối tôm 250g | 1.617 | 61.410.000 | 4.08% |
| SP08 | Dầu dừa ép lạnh 250ml | 1.539 | 145.585.000 | 9.68% |
| CHUA_XAC_DINH | Chưa xác định (ngoài danh mục) | 20 | 13.000.000 | 0.86% |
| **Tổng** |  | 11.804 | **1.503.750.000** | 100.00% |

_Dòng `CHUA_XAC_DINH` là hàng ngoài danh mục sản phẩm; vẫn tính vào doanh thu vì ngày và số tiền rõ ràng, chỉ mã sản phẩm chưa xác định._

## 4. Đối chiếu tổng từng file với bảng hợp nhất

| Chi nhánh | Tổng file ghi | Tổng dòng đọc được | Tổng hợp nhất | Chênh lệch (ghi - hợp nhất) |
|---|---:|---:|---:|---:|
| HN | 224.899.000 | 224.799.000 | 224.799.000 | 100.000 |
| HP | 268.380.000 | 268.380.000 | 253.599.000 | 14.781.000 |
| DN | 285.924.000 | 285.924.000 | 285.924.000 | 0 |
| CT | 214.846.000 | 214.846.000 | 214.846.000 | 0 |
| BH | 269.037.000 | 269.037.000 | 269.037.000 | 0 |
| NT | 261.425.000 | 261.425.000 | 255.545.000 | 5.880.000 |
| **Tổng** | 1.524.511.000 | 1.524.411.000 | 1.503.750.000 | 20.761.000 |

Giải thích chênh lệch:

- **HN**: Chênh lệch 100.000 = Tổng chi nhánh ghi (ô F156) cao hơn 100.000 so với tổng các dòng đọc được (224.799.000): lệch 100.000. CHƯA GIẢI THÍCH (không do dòng trùng/ngoài kỳ/lệch thành tiền; cần chi nhánh xác nhận, xem SAI_TONG trong viec_can_hoi.csv)
- **HP**: Chênh lệch 14.781.000 = Dòng trùng bị loại: 3 dòng, tổng 1.615.000 [HD89632 (dòng 50: 825.000), HD45618 (dòng 123: 220.000), HD17042 (dòng 149: 570.000)]; Dòng ngoài kỳ 11/2026 bị loại: 4 dòng, tổng 5.526.000 [HD58742 (dòng 56: 816.000), HD39293 (dòng 62: 1.440.000), HD58928 (dòng 121: 1.050.000), HD85100 (dòng 129: 2.220.000)]; Dòng CAN_NGUOI_QUYET chưa tính vào tổng hợp: 3 dòng, tổng 7.640.000 [HD50789 (dòng 28: 1.850.000), HD24384 (dòng 73: 4.350.000), HD37988 (dòng 132: 1.440.000)]
- **DN**: Khớp: tổng chi nhánh ghi bằng tổng bảng hợp nhất
- **CT**: Khớp: tổng chi nhánh ghi bằng tổng bảng hợp nhất
- **BH**: Khớp: tổng chi nhánh ghi bằng tổng bảng hợp nhất
- **NT**: Chênh lệch 5.880.000 = Dòng trùng bị loại: 2 dòng, tổng 5.880.000 [NT/0087 (dòng 90: 3.480.000), NT/0142 (dòng 146: 2.400.000)]

## 5. Vấn đề dữ liệu (theo loại)

| Loại | Số mục | Chi nhánh (số mục) |
|---|---:|---|
| SAI_TONG | 1 | HN (1) |
| KHAC | 2 | HN (1), HP (1) |
| NGAY_MO_HO | 8 | HP (4), DN (1), BH (3) |
| NGOAI_KY | 4 | HP (4) |
| TRUNG | 5 | HP (3), NT (2) |
| THIEU_DU_LIEU | 1 | CT (1) |
| SAN_PHAM_LA | 2 | CT (2) |
| LECH_THANH_TIEN | 2 | NT (2) |

## 6. Việc cần hỏi lại chi nhánh


### HN - Hà Nội

- **SAI_TONG** [dòng 156] - 100.000 đ: Tổng cuối bảng chi nhánh ghi 224.899.000 (ô F156) khác tổng 151 dòng đọc được 224.799.000: lệch 100.000  
  Câu hỏi: Tổng cuối bảng 224.899.000 khác tổng các dòng chi tiết 224.799.000 (chênh 100.000). Vui lòng kiểm tra lại: thiếu/thừa dòng hay gõ sai tổng?
- **KHAC** [dòng 158]: Ghi chú của chi nhánh (dòng 158): "Ghi chú: Giá đã gồm VAT. Số liệu chưa trừ hàng trả lại."  
  Câu hỏi: Ghi chú này ảnh hưởng thế nào đến số liệu tháng 11/2026 (số tiền, chứng từ liên quan)? Xin gửi bản điều chỉnh nếu cần.

### HP - Hải Phòng

- **NGAY_MO_HO** [HD50789, dòng 28] - 1.850.000 đ: Ngày bán mơ hồ, chưa tính vào tổng hợp: ô '11/10/2026' đọc được 2 cách: 2026-10-11 (ngày/tháng) hoặc 2026-11-10 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-10-11 nhưng cách còn lại 2026-11-10 nằm trong kỳ, không có căn cứ chắc chắn để chọn  
  Câu hỏi: Chứng từ HD50789 (dòng Excel 28): ngày bán đúng là ngày nào? (ô '11/10/2026' đọc được 2 cách: 2026-10-11 (ngày/tháng) hoặc 2026-11-10 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-10-11 nhưng cách còn lại 2026-11-10 nằm trong kỳ, không có căn cứ chắc chắn để chọn)
- **NGAY_MO_HO** [HD24384, dòng 73] - 4.350.000 đ: Ngày bán mơ hồ, chưa tính vào tổng hợp: ô '11/10/2026' đọc được 2 cách: 2026-10-11 (ngày/tháng) hoặc 2026-11-10 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-10-11 nhưng cách còn lại 2026-11-10 nằm trong kỳ, không có căn cứ chắc chắn để chọn  
  Câu hỏi: Chứng từ HD24384 (dòng Excel 73): ngày bán đúng là ngày nào? (ô '11/10/2026' đọc được 2 cách: 2026-10-11 (ngày/tháng) hoặc 2026-11-10 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-10-11 nhưng cách còn lại 2026-11-10 nằm trong kỳ, không có căn cứ chắc chắn để chọn)
- **NGAY_MO_HO** [HD37988, dòng 132] - 1.440.000 đ: Ngày bán mơ hồ, chưa tính vào tổng hợp: ô '11/10/2026' đọc được 2 cách: 2026-10-11 (ngày/tháng) hoặc 2026-11-10 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-10-11 nhưng cách còn lại 2026-11-10 nằm trong kỳ, không có căn cứ chắc chắn để chọn  
  Câu hỏi: Chứng từ HD37988 (dòng Excel 132): ngày bán đúng là ngày nào? (ô '11/10/2026' đọc được 2 cách: 2026-10-11 (ngày/tháng) hoặc 2026-11-10 (tháng/ngày); theo quy ước của file (dd/mm) ra 2026-10-11 nhưng cách còn lại 2026-11-10 nằm trong kỳ, không có căn cứ chắc chắn để chọn)
- **NGAY_MO_HO** - 106.873.000 đ: File ghi ngày dạng chữ theo dd/mm/yyyy; 54 dòng có ngày đọc được 2 cách (ngày <= 12) đã được đọc theo dd/mm/yyyy (căn cứ: 87 ô chỉ đọc được là ngày/tháng, 0 ô chỉ đọc được là tháng/ngày)  
  Câu hỏi: Xin xác nhận file dùng định dạng ngày dd/mm/yyyy cho toàn bộ cột ngày. Từ kỳ sau đề nghị nhập ngày dạng ngày thật của Excel hoặc yyyy-mm-dd.
- **NGOAI_KY** [HD58742, dòng 56] - 816.000 đ: Dòng có ngày 2026-10-27, ngoài kỳ báo cáo 2026-11; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD58742 ngày 27/10/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 11/2026 không?
- **NGOAI_KY** [HD39293, dòng 62] - 1.440.000 đ: Dòng có ngày 2026-10-31, ngoài kỳ báo cáo 2026-11; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD39293 ngày 31/10/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 11/2026 không?
- **NGOAI_KY** [HD58928, dòng 121] - 1.050.000 đ: Dòng có ngày 2026-10-30, ngoài kỳ báo cáo 2026-11; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD58928 ngày 30/10/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 11/2026 không?
- **NGOAI_KY** [HD85100, dòng 129] - 2.220.000 đ: Dòng có ngày 2026-10-28, ngoài kỳ báo cáo 2026-11; không đưa vào bảng hợp nhất  
  Câu hỏi: Chứng từ HD85100 ngày 28/10/2026 thuộc kỳ khác. Đã hạch toán ở kỳ nào? Có cần chuyển vào tháng 11/2026 không?
- **TRUNG** [HD89632, dòng 50] - 825.000 đ: Dòng trùng hoàn toàn với dòng 10 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 10  
  Câu hỏi: Chứng từ HD89632 xuất hiện 2 lần (dòng 10 và 50). Xin xác nhận chỉ tính 1 lần?
- **TRUNG** [HD45618, dòng 123] - 220.000 đ: Dòng trùng hoàn toàn với dòng 69 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 69  
  Câu hỏi: Chứng từ HD45618 xuất hiện 2 lần (dòng 69 và 123). Xin xác nhận chỉ tính 1 lần?
- **TRUNG** [HD17042, dòng 149] - 570.000 đ: Dòng trùng hoàn toàn với dòng 8 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 8  
  Câu hỏi: Chứng từ HD17042 xuất hiện 2 lần (dòng 8 và 149). Xin xác nhận chỉ tính 1 lần?
- **KHAC** [dòng 158]: Ghi chú của chi nhánh (dòng 158): "* Gồm 4 đơn tháng 10 nhập trễ (từ 27/10 đến 31/10)."  
  Câu hỏi: Ghi chú này ảnh hưởng thế nào đến số liệu tháng 11/2026 (số tiền, chứng từ liên quan)? Xin gửi bản điều chỉnh nếu cần.

### DN - Đà Nẵng

- **NGAY_MO_HO** - 110.892.000 đ: File ghi ngày dạng chữ theo mm/dd/yyyy; 59 dòng có ngày đọc được 2 cách (ngày <= 12) đã được đọc theo mm/dd/yyyy (căn cứ: 0 ô chỉ đọc được là ngày/tháng, 97 ô chỉ đọc được là tháng/ngày)  
  Câu hỏi: Xin xác nhận file dùng định dạng ngày mm/dd/yyyy cho toàn bộ cột ngày. Từ kỳ sau đề nghị nhập ngày dạng ngày thật của Excel hoặc yyyy-mm-dd.

### CT - Cần Thơ

- **THIEU_DU_LIEU**: Không có dòng bán hàng nào có ngày xác định trong khoảng 2026-11-15 đến 2026-11-21; số chứng từ liền kề khoảng thiếu là CT-0071 (dòng 78) và CT-0072 (dòng 79) liên tục nên không thấy chỗ nhảy số  
  Câu hỏi: Chi nhánh có bán hàng trong khoảng 15/11/2026 - 21/11/2026 không? Nếu có xin gửi bổ sung dữ liệu (không tự điền số).
- **SAN_PHAM_LA** [CT-0038, dòng 45] - 6.500.000 đ: Sản phẩm 'Combo quà Tết 2026' không có trong danh mục; ghi CHUA_XAC_DINH, vẫn tính vào doanh thu chi nhánh  
  Câu hỏi: Chứng từ CT-0038 bán 'Combo quà Tết 2026': đây là sản phẩm gì, có mã chuẩn nào trong danh mục không?
- **SAN_PHAM_LA** [CT-0056, dòng 63] - 6.500.000 đ: Sản phẩm 'Combo quà Tết 2026' không có trong danh mục; ghi CHUA_XAC_DINH, vẫn tính vào doanh thu chi nhánh  
  Câu hỏi: Chứng từ CT-0056 bán 'Combo quà Tết 2026': đây là sản phẩm gì, có mã chuẩn nào trong danh mục không?

### BH - Biên Hòa

- **NGAY_MO_HO** [PX-0016, dòng 18] - 1.260.000 đ: Ô ngày lưu 2026-03-11 (ngoài kỳ) đã được đọc là 2026-11-03 (đảo ngày/tháng) và tính vào tháng; căn cứ: file sắp theo thứ tự ngày; dòng trước (PX-0015) là 2026-11-03 và dòng sau (PX-0017) là 2026-11-04 nên chỉ cách đọc 2026-11-03 hợp lý  
  Câu hỏi: Chứng từ PX-0016 (dòng Excel 18): xin xác nhận ngày bán đúng là 03/11/2026, không phải 11/03/2026?
- **NGAY_MO_HO** [PX-0019, dòng 21] - 720.000 đ: Ô ngày lưu 2026-04-11 (ngoài kỳ) đã được đọc là 2026-11-04 (đảo ngày/tháng) và tính vào tháng; căn cứ: file sắp theo thứ tự ngày; dòng trước (PX-0018) là 2026-11-04 và dòng sau (PX-0020) là 2026-11-04 nên chỉ cách đọc 2026-11-04 hợp lý  
  Câu hỏi: Chứng từ PX-0019 (dòng Excel 21): xin xác nhận ngày bán đúng là 04/11/2026, không phải 11/04/2026?
- **NGAY_MO_HO** [PX-0043, dòng 46] - 3.300.000 đ: Ô ngày lưu 2026-09-11 (ngoài kỳ) đã được đọc là 2026-11-09 (đảo ngày/tháng) và tính vào tháng; căn cứ: file sắp theo thứ tự ngày; dòng trước (PX-0042) là 2026-11-09 và dòng sau (PX-0044) là 2026-11-09 nên chỉ cách đọc 2026-11-09 hợp lý  
  Câu hỏi: Chứng từ PX-0043 (dòng Excel 46): xin xác nhận ngày bán đúng là 09/11/2026, không phải 11/09/2026?

### NT - Nha Trang

- **LECH_THANH_TIEN** [NT/0068, dòng 70] - 50.000 đ: Thành tiền 3.930.000 khác SL x đơn giá (20 x 194.000 = 3.880.000), lệch 50.000; giữ số chi nhánh ghi  
  Câu hỏi: Chứng từ NT/0068: SL 20 x giá 194.000 = 3.880.000 nhưng thành tiền ghi 3.930.000. Số nào đúng (SL, giá hay thành tiền)?
- **LECH_THANH_TIEN** [NT/0143, dòng 147] - 50.000 đ: Thành tiền 6.650.000 khác SL x đơn giá (30 x 220.000 = 6.600.000), lệch 50.000; giữ số chi nhánh ghi  
  Câu hỏi: Chứng từ NT/0143: SL 30 x giá 220.000 = 6.600.000 nhưng thành tiền ghi 6.650.000. Số nào đúng (SL, giá hay thành tiền)?
- **TRUNG** [NT/0087, dòng 90] - 3.480.000 đ: Dòng trùng hoàn toàn với dòng 89 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 89  
  Câu hỏi: Chứng từ NT/0087 xuất hiện 2 lần (dòng 89 và 90). Xin xác nhận chỉ tính 1 lần?
- **TRUNG** [NT/0142, dòng 146] - 2.400.000 đ: Dòng trùng hoàn toàn với dòng 145 (cùng số chứng từ, cùng nội dung); đã loại bản lặp, giữ dòng 145  
  Câu hỏi: Chứng từ NT/0142 xuất hiện 2 lần (dòng 145 và 146). Xin xác nhận chỉ tính 1 lần?

## 7. Cách xử lý và giả định

- Mỗi dòng bán hàng một dòng trong `hop_nhat.csv`; trạng thái `OK` (đọc rõ), `SUY_RA` (ngày đọc được 2 cách nhưng có căn cứ, căn cứ ghi ở cột ghi_chu), `CAN_NGUOI_QUYET` (không chắc, để trống ngày nếu liên quan ngày, không tính vào tổng hợp).
- Số tiền giữ đúng thành tiền chi nhánh ghi (kể cả dòng âm); dòng lệch SL x đơn giá giữ số chi nhánh ghi và đưa vào việc cần hỏi.
- Dòng trùng (cùng chi nhánh, cùng số chứng từ, cùng nội dung): chỉ giữ dòng đầu. Dòng ngoài kỳ 11/2026 không đưa vào bảng hợp nhất.
- Tên sản phẩm được quy về mã chuẩn theo quy tắc trong `gop.py` (bỏ dấu, chữ hoa/thường, viết tắt, kèm quy cách); không khớp thì ghi `CHUA_XAC_DINH`.
- Dòng trả hàng (số âm) giữ nguyên và trừ vào doanh thu: 1 dòng, tổng -495.000 đ (DN RT-0130).
- 5 nhóm dòng cùng chi nhánh, cùng ngày, cùng sản phẩm, SL, đơn giá và thành tiền nhưng KHÁC số chứng từ (HD97829 / HD97581; HD29861 / HD40834; HD26562 / HD78096; DN-0105 / DN-0108; NT/0060 / NT/0065). Theo quy tắc dòng trùng phải cùng số chứng từ nên vẫn tính là giao dịch riêng; chưa có căn cứ để cho là nhập hai lần.
- NT: bỏ qua cột không phải số liệu bán hàng: Kênh bán (cột C) (không đưa vào doanh thu, không đổi bảng đầu ra).
- DN: 59 dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`).
- BH: 3 dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`).
- HP: 54 dòng có ngày được suy ra (xem ghi_chu từng dòng trong `hop_nhat.csv`).
