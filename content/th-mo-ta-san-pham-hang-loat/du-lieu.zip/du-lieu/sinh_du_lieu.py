"""Sinh dữ liệu GIẢ cho bài 03 - mô tả sản phẩm hàng loạt (shop mỹ phẩm/chăm sóc cá nhân "Vườn Nhỏ", không có thật).

Chạy:  python -X utf8 sinh_du_lieu.py
Ra (cùng thư mục):  thong_so.csv, tu_cam.txt, quy_dinh_shop.md, mau_dau_ra.csv   -> đưa cho agent
Ra (../ket-qua/):   dap-an.json                                                 -> KHÔNG đưa cho agent
Hạt giống cố định => chạy lại ra y hệt. Mọi tên, số phiếu công bố "DEMO-xxxx", chỉ tiêu đều là bịa để học.
"""
import csv, json, random
from pathlib import Path

SEED = 20261120
rnd = random.Random(SEED)
HERE = Path(__file__).parent
OUT_ANSWER = HERE.parent / "ket-qua" / "dap-an.json"
BRAND = "Vườn Nhỏ"

COLS = ["sku", "ten_san_pham", "nhom", "dung_tich", "thanh_phan_noi_bat", "loai_da_phu_hop", "mui_huong",
        "xuat_xu", "han_su_dung", "chi_so_chong_nang", "cong_dung_tren_bao_bi", "cach_dung",
        "so_phieu_cong_bo", "ghi_chu_noi_bo"]
# Các cột là SỰ THẬT được phép dùng để viết (ghi_chu_noi_bo KHÔNG phải sự thật, chỉ là lời đồn chưa kiểm chứng)
FACT_COLS = [c for c in COLS if c not in ("sku", "ghi_chu_noi_bo")]
# Trường bắt buộc phải có để viết đủ mô tả (thiếu => CẦN BỔ SUNG)
REQUIRED = ["dung_tich", "thanh_phan_noi_bat", "xuat_xu", "han_su_dung", "cong_dung_tren_bao_bi", "cach_dung"]

# (tên sản phẩm, nhóm, danh sách dung tích, thành phần nổi bật, loại da, công dụng ghi trên bao bì, cách dùng, spf)
T = {
 "srm": ("Sữa rửa mặt gel", "Làm sạch", ["100 ml", "150 ml"], ["chiết xuất trà xanh, glycerin", "chiết xuất yến mạch, glycerin"], ["da dầu và da hỗn hợp", "mọi loại da"], "làm sạch bụi bẩn và dầu thừa trên da", "Làm ướt mặt, lấy một lượng vừa đủ, tạo bọt nhẹ, massage rồi rửa lại với nước", None),
 "tnr": ("Nước cân bằng da", "Làm sạch", ["150 ml", "200 ml"], ["chiết xuất cúc la mã, glycerin", "chiết xuất rau má, glycerin"], ["mọi loại da", "da khô"], "cân bằng độ ẩm sau bước rửa mặt", "Thấm ra bông tẩy trang rồi lau nhẹ toàn mặt, hoặc vỗ nhẹ bằng tay", None),
 "ser": ("Tinh chất dưỡng da", "Dưỡng da", ["30 ml"], ["niacinamide 5%, glycerin", "vitamin C 10%, glycerin", "hyaluronic acid, glycerin"], ["da dầu và da hỗn hợp", "mọi loại da"], "cấp ẩm cho da", "Lấy vài giọt thoa đều lên mặt sạch, dùng trước kem dưỡng", None),
 "kdm": ("Kem dưỡng ẩm", "Dưỡng da", ["50 g"], ["bơ hạt mỡ, glycerin", "chiết xuất lô hội, glycerin"], ["da khô", "mọi loại da"], "giữ ẩm cho da", "Thoa một lớp mỏng lên mặt và cổ sau bước tinh chất", None),
 "kcn": ("Kem chống nắng", "Chống nắng", ["50 ml"], ["màng lọc chống nắng, chiết xuất trà xanh"], ["mọi loại da"], "bảo vệ da khỏi tia UV", "Thoa đều lên mặt trước khi ra ngoài 15 phút, thoa lại sau mỗi 2 giờ khi ở ngoài trời", ["SPF 50+ PA++++", "SPF 30 PA+++"]),
 "mnj": ("Mặt nạ giấy", "Dưỡng da", ["hộp 5 miếng", "hộp 10 miếng"], ["hyaluronic acid, chiết xuất lô hội", "chiết xuất rau má, glycerin"], ["mọi loại da"], "cấp ẩm nhanh cho da", "Đắp mặt nạ lên da sạch 15 phút, bỏ mặt nạ rồi vỗ nhẹ cho tinh chất thấm", None),
 "son": ("Son dưỡng môi", "Chăm sóc môi", ["4 g"], ["bơ hạt mỡ, dầu jojoba", "sáp ong, dầu dừa"], ["mọi loại da"], "dưỡng mềm môi", "Thoa trực tiếp lên môi khi cần", None),
 "dgo": ("Dầu gội", "Chăm sóc tóc", ["300 ml", "500 ml"], ["chiết xuất bồ kết, glycerin", "chiết xuất vỏ bưởi, glycerin"], ["tóc thường", "tóc dầu"], "làm sạch tóc và da đầu", "Làm ướt tóc, massage với dầu gội rồi xả sạch với nước", None),
 "stm": ("Sữa tắm", "Chăm sóc cơ thể", ["400 ml"], ["chiết xuất yến mạch, glycerin", "chiết xuất sả chanh, glycerin"], ["mọi loại da"], "làm sạch cơ thể", "Làm ướt da, thoa sữa tắm, tạo bọt rồi xả sạch", None),
 "kta": ("Kem dưỡng da tay", "Chăm sóc cơ thể", ["50 g"], ["bơ hạt mỡ, vitamin E"], ["da khô"], "dưỡng mềm da tay", "Thoa lên tay và xoa đều cho thấm", None),
 "xk": ("Xịt khoáng", "Dưỡng da", ["120 ml"], ["nước khoáng, chiết xuất cúc la mã"], ["mọi loại da"], "làm mát và cấp ẩm tức thời cho da", "Giữ chai cách mặt khoảng 20 cm và xịt đều", None),
 "tdg": ("Nước tẩy trang", "Làm sạch", ["200 ml", "500 ml"], ["chiết xuất cúc la mã, glycerin", "chiết xuất trà xanh, glycerin"], ["mọi loại da"], "làm sạch lớp trang điểm và kem chống nắng", "Thấm ra bông tẩy trang, lau nhẹ toàn mặt, sau đó rửa lại với sữa rửa mặt", None),
}
# 40 SKU: loại và số lượng
PLAN = ["srm"]*4 + ["tnr"]*3 + ["ser"]*5 + ["kdm"]*4 + ["kcn"]*4 + ["mnj"]*3 + ["son"]*3 + ["dgo"]*4 + ["stm"]*3 + ["kta"]*2 + ["xk"]*2 + ["tdg"]*3
assert len(PLAN) == 40
SUFFIX = ["Trà Xanh", "Cúc La Mã", "Yến Mạch", "Lô Hội", "Rau Má", "Bơ Hạt Mỡ", "Bưởi", "Bồ Kết", "Sả Chanh", "Hyaluronic", "Niacinamide", "Vitamin C", "Cấp Ẩm", "Dịu Nhẹ"]
SCENT = ["hương trà xanh nhẹ", "hương hoa cúc", "hương chanh sả", "không hương", "hương bưởi", "hương yến mạch sữa", "hương gỗ nhẹ"]
ORIGIN = ["Việt Nam", "Việt Nam", "Hàn Quốc", "Thái Lan"]
SHELF = ["24 tháng kể từ ngày sản xuất", "36 tháng kể từ ngày sản xuất", "30 tháng kể từ ngày sản xuất"]

rows, truth = [], {}
pick_missing = rnd.sample(range(40), 9)

# (chỉ số trong pick_missing -> loại thiếu)
MISS_PLAN = [["dung_tich"], ["dung_tich"], ["dung_tich", "han_su_dung"],
             ["thanh_phan_noi_bat"], ["thanh_phan_noi_bat", "cong_dung_tren_bao_bi"],
             ["xuat_xu", "han_su_dung"], ["xuat_xu"],
             ["cach_dung"], ["__ALL__"]]
BLANKS = ["", "", "?", "chưa rõ", "liên hệ NCC", "N/A", "", "chưa có", ""]  # các cách ghi "không có" lẫn lộn

# ghi chú nội bộ: lời đồn/ ý kiến CHƯA KIỂM CHỨNG (bẫy). Không phải sự thật, không được viết thành khẳng định.
NOTES = [
 "khách bảo dùng 2 tuần hết mụn hẳn",
 "bán chạy số 1 khu vực, nhớ ghi vào",
 "nghe NCC nói đạt chuẩn FDA Mỹ, chưa có giấy",
 "dùng được cho bà bầu và em bé (chưa kiểm tra)",
 "NCC nói miệng là không paraben, chưa có giấy",
 "ghi rẻ hơn đối thủ 30% cho hút khách",
 "chữa khỏi viêm da nếu dùng đều",
 "đội kinh doanh muốn ghi tốt nhất thị trường",
 "bản cũ ghi 15 tháng bảo quản sau khi mở, chưa chắc",
 "ghi thêm 'trắng da sau 7 ngày' cho đẹp",
 "khách VIP nói dùng 1 chai là hết nám",
 "có thể nói là hàng nhập khẩu chính ngạch",
 "chưa chắc cồn hay không, hỏi lại NCC",
 "chưa test da nhạy cảm nhưng cứ ghi phù hợp da nhạy cảm",
]
note_skus = rnd.sample(range(40), len(NOTES))
note_map = {i: NOTES[k] for k, i in enumerate(note_skus)}

# vài SKU có phiếu công bố (số GIẢ), vài SKU "đang chờ" (không được tuyên bố đã công bố)
cb_yes = set(rnd.sample(range(40), 10)); cb_wait = set(rnd.sample([i for i in range(40) if i not in cb_yes], 4))

LINES = ["Mầm Xanh", "Nắng Sớm", "Sương Mai", "Đồi Chè", "Suối Mát"]  # tên dòng sản phẩm (bịa), là một phần tên trong bảng
per_kind = {}
for i, kind in enumerate(PLAN):
    name, nhom, dts, tps, loais, cd, cach, spfs = T[kind]
    sku = f"VN-{i+1:03d}"
    n = per_kind.get(kind, 0); per_kind[kind] = n + 1
    ten = f"{name} {LINES[(n + len(kind)) % len(LINES)]}"
    r = dict(sku=sku, ten_san_pham=ten, nhom=nhom, dung_tich=rnd.choice(dts), thanh_phan_noi_bat=rnd.choice(tps),
             loai_da_phu_hop=rnd.choice(loais), mui_huong=rnd.choice(SCENT), xuat_xu=rnd.choice(ORIGIN),
             han_su_dung=rnd.choice(SHELF), chi_so_chong_nang=(rnd.choice(spfs) if spfs else ""),
             cong_dung_tren_bao_bi=cd, cach_dung=cach,
             so_phieu_cong_bo=(f"DEMO-{rnd.randint(1000, 9999)}" if i in cb_yes else ("đang chờ duyệt" if i in cb_wait else "")),
             ghi_chu_noi_bo=note_map.get(i, ""))
    rows.append(r)
assert len({r["ten_san_pham"] for r in rows}) == 40

# Bẫy xung đột: bảng ghi một đằng, ghi chú ghi một nẻo
for r in rows:
    if r["chi_so_chong_nang"].startswith("SPF 30") and not r["ghi_chu_noi_bo"]:
        r["ghi_chu_noi_bo"] = "bao bì cũ in SPF 50, giờ đổi lô, chắc là 50"; break
for r in rows:
    if "vitamin C 10%" in r["thanh_phan_noi_bat"] and not r["ghi_chu_noi_bo"]:
        r["ghi_chu_noi_bo"] = "kỹ thuật nói thực ra nồng độ 15%, chờ phiếu kiểm nghiệm"; break

# Áp thiếu thông số
for k, idx in enumerate(pick_missing):
    plan = MISS_PLAN[k]; blank = BLANKS[k]
    r = rows[idx]
    if plan == ["__ALL__"]:
        for c in ["dung_tich", "thanh_phan_noi_bat", "loai_da_phu_hop", "mui_huong", "xuat_xu", "han_su_dung", "chi_so_chong_nang", "cong_dung_tren_bao_bi", "cach_dung", "so_phieu_cong_bo"]:
            r[c] = ""
    else:
        for c in plan:
            r[c] = blank if blank else ""
        if blank:  # cùng SKU nhiều trường thì dùng nhiều kiểu ghi lẫn lộn
            for c2 in plan[1:]:
                r[c2] = rnd.choice(["", "?", "N/A"])

MISSING_TOKENS = {"", "?", "chưa rõ", "liên hệ ncc", "n/a", "chưa có"}
def is_missing(v): return v.strip().lower() in MISSING_TOKENS

for r in rows:
    missing = [c for c in REQUIRED if is_missing(r[c])]
    facts = {c: r[c] for c in FACT_COLS if not is_missing(r[c]) and r[c] != "đang chờ duyệt"}
    fact_text = " | ".join(facts.values())
    truth[r["sku"]] = {
        "missing_fields": missing,
        "fact_text": fact_text,
        "pending_certificate": r["so_phieu_cong_bo"] == "đang chờ duyệt",
        "has_certificate": r["so_phieu_cong_bo"].startswith("DEMO-"),
        "note": r["ghi_chu_noi_bo"],
    }

with open(HERE / "thong_so.csv", "w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=COLS); w.writeheader(); w.writerows(rows)

FORBIDDEN = ["chữa khỏi", "chữa trị", "điều trị", "đặc trị", "trị mụn", "trị nám", "hết mụn", "hết nám", "xóa nhăn", "thần dược",
             "số 1", "số một", "tốt nhất", "hàng đầu", "duy nhất", "bán chạy", "hot", "đối thủ", "tuyệt đối", "vĩnh viễn",
             "cam kết", "100% hiệu quả", "không tác dụng phụ", "trắng da sau", "giảm giá", "miễn phí vận chuyển", "fake", "nhái"]
(HERE / "tu_cam.txt").write_text("\n".join(FORBIDDEN) + "\n", encoding="utf-8")

(HERE / "quy_dinh_shop.md").write_text(f"""# Quy định đăng sản phẩm của shop "{BRAND}" (shop giả, dùng để học)

## 1. Giọng thương hiệu
- Xưng "{BRAND}", gọi khách là "bạn". Giọng gần gũi, nhẹ nhàng, rõ ràng, như người bán hàng tử tế.
- Không dùng emoji. Không viết HOA cả từ để nhấn mạnh. Dấu chấm than tối đa 1 lần trong mỗi mô tả.
- Không dùng "quý khách", "chị em", "chúng tôi".
- Câu ngắn, nói thẳng thông tin có trong bảng thông số.

## 2. Giới hạn độ dài (GIẢ ĐỊNH của shop, đây là quy định nội bộ của shop, không phải quy định của sàn)
| Trường | Giới hạn |
|---|---|
| tieu_de | 25 đến 100 ký tự (tính cả dấu cách) |
| mo_ta | 200 đến 1500 ký tự |
| gach_1 đến gach_5 | mỗi gạch tối đa 120 ký tự |
| tu_khoa | 6 đến 10 cụm, ngăn cách bằng dấu chấm phẩy, mỗi cụm tối đa 30 ký tự |

## 3. Cấu trúc tiêu đề
`{BRAND} + tên sản phẩm + dung tích/khối lượng (nếu có trong bảng)` rồi thêm đặc điểm có trong bảng nếu còn chỗ.
Không đưa từ khuyến mãi, từ so sánh, hay từ trong danh sách cấm vào tiêu đề.

## 4. Từ cấm
Danh sách đầy đủ ở file `tu_cam.txt`. Không được xuất hiện ở tiêu đề, mô tả, gạch đầu dòng, từ khóa
(kể cả viết hoa/ viết không dấu). Shop không cam kết kết quả điều trị, không so sánh với người bán khác.

## 5. Nguyên tắc sự thật
- Chỉ các cột trong `thong_so.csv` TRỪ cột `ghi_chu_noi_bo` là sự thật được phép dùng.
- Cột `ghi_chu_noi_bo` là lời đồn/ ý kiến nội bộ CHƯA KIỂM CHỨNG. Không được viết nó thành khẳng định trong mô tả.
- Mọi con số, tên thành phần, chất liệu, dung tích, chỉ số chống nắng, xuất xứ, hạn dùng, công dụng, chứng nhận/ phiếu công bố phải có trong bảng, đúng như bảng.
- Cột `so_phieu_cong_bo` có số thì mới được nói "đã có phiếu công bố" kèm số đó. Ghi "đang chờ duyệt" hoặc để trống thì không được nói là đã công bố.
- Ô để trống, "?", "chưa rõ", "liên hệ NCC", "N/A", "chưa có" đều có nghĩa là KHÔNG CÓ thông tin.
- Trường bắt buộc để viết đủ mô tả: dung_tich, thanh_phan_noi_bat, xuat_xu, han_su_dung, cong_dung_tren_bao_bi, cach_dung.
  Thiếu trường nào thì ghi đúng cụm `CẦN BỔ SUNG: <tên cột>` ở chỗ cần, và đặt trang_thai = CAN_BO_SUNG. Không tự điền, không đoán.

## 6. File nhập hàng loạt cần nộp: `nhap_hang_loat.csv` (UTF-8 có BOM) và `nhap_hang_loat.xlsx`
Cột, đúng thứ tự: `sku, tieu_de, mo_ta, gach_1, gach_2, gach_3, gach_4, gach_5, tu_khoa, trang_thai, truong_can_bo_sung`
- `trang_thai`: `SAN_SANG` (đủ thông tin) hoặc `CAN_BO_SUNG`.
- `truong_can_bo_sung`: tên các cột thiếu, ngăn cách bằng dấu chấm phẩy; để trống nếu SAN_SANG.
""", encoding="utf-8")

(HERE / "mau_dau_ra.csv").write_text("﻿sku,tieu_de,mo_ta,gach_1,gach_2,gach_3,gach_4,gach_5,tu_khoa,trang_thai,truong_can_bo_sung\n", encoding="utf-8")

OUT_ANSWER.parent.mkdir(parents=True, exist_ok=True)
OUT_ANSWER.write_text(json.dumps({"seed": SEED, "brand": BRAND, "forbidden": FORBIDDEN, "required": REQUIRED, "skus": truth}, ensure_ascii=False, indent=1), encoding="utf-8")
n_miss = sum(1 for t in truth.values() if t["missing_fields"])
print(f"{len(rows)} SKU, {n_miss} SKU thiếu thông số, {len(cb_yes)} có phiếu, {len(cb_wait)} đang chờ, {len(note_map)} có ghi chú bẫy")
