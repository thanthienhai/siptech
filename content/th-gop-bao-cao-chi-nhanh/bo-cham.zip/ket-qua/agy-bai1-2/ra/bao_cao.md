# BÁO CÁO TỔNG HỢP DOANH THU BÁN HÀNG THÁNG 10/2026

**Kính gửi:** Ban Giám đốc Công ty TNHH Mẫu An Phát  
**Người lập:** Trợ lý Kế toán Quản trị  
**Kỳ báo cáo:** Tháng 10/2026 (01/10/2026 - 31/10/2026)  
**Ngày lập báo cáo:** 20/11/2026  

---

## 1. TỔNG QUAN KẾT QUẢ KINH DOANH THÁNG 10/2026

- **Tổng doanh thu hợp nhất toàn công ty:** **1,523,468,000 VNĐ**
- **Tổng số lượt giao dịch bán hàng hợp lệ:** **901 giao dịch** (chỉ tính các dòng trạng thái `OK` và `SUY_RA`)
- **Số chi nhánh gửi báo cáo:** 6/6 chi nhánh (Hà Nội, Hải Phòng, Đà Nẵng, Cần Thơ, Biên Hòa, Nha Trang)
- **Số giao dịch cần người quyết định (tạm giữ ngoài tổng hợp):** 3 giao dịch tại chi nhánh Hải Phòng (tổng giá trị **2.391.000 VNĐ** do ngày tháng mơ hồ `10/09/2026`)
- **Số giao dịch trùng lặp đã loại bỏ:** 5 giao dịch (Hải Phòng 3 dòng = 7.196.000 VNĐ; Nha Trang 2 dòng = 2.145.000 VNĐ)
- **Số giao dịch ngoài kỳ (tháng 9) đã bóc tách:** 4 giao dịch tại Hải Phòng (tổng giá trị **7.800.000 VNĐ**)

## 2. BÁO CÁO DOANH THU THEO CHI NHÁNH

| Mã CN | Tên chi nhánh | Số dòng GD | Doanh thu hợp nhất (VNĐ) | Tỷ trọng | Ghi chú |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **HN** | Hà Nội | 146 | 262,936,000 | 17.26% | Số thực tính khớp dòng chi tiết (file ghi sai tổng +100k) |
| **HP** | Hải Phòng | 161 | 279,155,000 | 18.32% | Đã trừ 3 dòng trùng, 4 đơn tháng 9, tạm giữ 3 đơn mơ hồ |
| **DN** | Đà Nẵng | 159 | 278,248,000 | 18.26% | Gồm 1 đơn trả lại (-120k); ngày chuẩn hóa MM/DD/YYYY |
| **CT** | Cần Thơ | 114 | 184,408,000 | 12.10% | Gồm 13 tr Combo quà Tết; thiếu dữ liệu 15-21/10 |
| **BH** | Biên Hòa | 157 | 270,321,000 | 17.74% | Đã loại 5 dòng cộng tuần; chuẩn hóa 3 ngày Excel đảo |
| **NT** | Nha Trang | 164 | 248,400,000 | 16.30% | Đã trừ 2 dòng trùng; giữ nguyên 2 đơn lệch thành tiền |
| **TỔNG** | **Toàn công ty** | **901** | **1,523,468,000** | **100.00%** | |

## 3. BÁO CÁO DOANH THU THEO SẢN PHẨM

| Mã SP | Tên sản phẩm | Số lượng bán | Doanh thu (VNĐ) | Tỷ trọng | Nhận xét |
| :--- | :--- | :---: | :---: | :---: | :--- |
| **CHUA_XAC_DINH** | Chưa xác định | 20 | 13,000,000 | 0.85% | Sản phẩm lạ bán tại Cần Thơ (cần làm rõ) |
| **SP01** | Gạo ST25 túi 5kg | 1,190 | 195,958,000 | 12.86% | Sản phẩm danh mục chuẩn |
| **SP02** | Nước mắm truyền thống chai 500ml | 1,667 | 112,858,000 | 7.41% | Sản phẩm danh mục chuẩn |
| **SP03** | Cà phê rang xay 500g | 1,634 | 236,664,000 | 15.53% | Sản phẩm danh mục chuẩn |
| **SP04** | Trà sen 200g | 1,448 | 173,610,000 | 11.40% | Sản phẩm danh mục chuẩn |
| **SP05** | Mật ong rừng 250ml | 1,489 | 275,092,000 | 18.06% | Sản phẩm danh mục chuẩn |
| **SP06** | Hạt điều rang muối 500g | 1,694 | 354,330,000 | 23.26% | Sản phẩm danh mục chuẩn |
| **SP07** | Bánh tráng muối tôm 250g | 1,213 | 45,916,000 | 3.01% | Sản phẩm danh mục chuẩn |
| **SP08** | Dầu dừa ép lạnh 250ml | 1,228 | 116,040,000 | 7.62% | Sản phẩm danh mục chuẩn |
| **TỔNG** | | | **1,523,468,000** | **100.00%** | |

## 4. KẾT QUẢ ĐỐI CHIẾU VÀ GIẢI TRÌNH CHÊNH LỆCH DỮ LIỆU

Bảng đối chiếu giữa số tổng do chi nhánh tự ghi, tổng toàn bộ dòng dữ liệu đọc được và tổng đưa vào báo cáo hợp nhất:

| Chi nhánh | Tổng file ghi (VNĐ) | Tổng dòng đọc được (VNĐ) | Tổng hợp nhất (VNĐ) | Chênh lệch (VNĐ) | Nguyên nhân chênh lệch |
| :--- | :---: | :---: | :---: | :---: | :--- |
| **HN** | 263,036,000 | 262,936,000 | 262,936,000 | 100,000 | File ghi cao hơn thực tế chi tiết 100,000đ do kế toán chi nhánh gõ tay sai tổng cộng cuối bảng (dòng 151 ghi 263.036.000đ nhưng thực tính 146 dòng là 262.936.000đ). |
| **HP** | 296,542,000 | 296,542,000 | 279,155,000 | 17,387,000 | File ghi cao hơn hợp nhất 17,387,000đ do: 3 dòng trùng (7.196.000đ) + 4 đơn tháng 9 nhập trễ (7.800.000đ) + 3 đơn ngày 10/09 mơ hồ tạm treo (2.391.000đ). |
| **DN** | 278,248,000 | 278,248,000 | 278,248,000 | 0 | Khớp 100%. File tự động tính đúng tổng, bao gồm cả đơn hàng trả lại RT-0119 (-120.000đ). |
| **CT** | 184,408,000 | 184,408,000 | 184,408,000 | 0 | Khớp 100%. Doanh thu hợp nhất phản ánh toàn bộ 114 dòng bán hàng thực tế (bao gồm 2 đơn Combo quà Tết 2026 tổng 13.000.000đ). |
| **BH** | 270,321,000 | 270,321,000 | 270,321,000 | 0 | Khớp 100%. File có 5 dòng cộng tuần trung gian và tổng tháng 270.321.000đ khớp chuẩn với tổng 157 dòng bán hàng. |
| **NT** | 250,545,000 | 250,545,000 | 248,400,000 | 2,145,000 | File ghi cao hơn hợp nhất 2,145,000đ do chi nhánh nhập trùng 2 dòng (NT/0060 và NT/0138). Riêng 2 đơn tính sai thành tiền (+100.000đ) giữ nguyên theo số chi nhánh ghi. |

## 5. CÁC VẤN ĐỀ DỮ LIỆU VÀ RỦI RO PHÁT HIỆN

Qua quá trình rà soát và kiểm toán chi tiết dữ liệu 6 file Excel, trợ lý kế toán quản trị phát hiện các vấn đề nghiêm trọng sau:

1. **Rủi ro trùng lặp hóa đơn (Hải Phòng, Nha Trang):**
   - Hải Phòng có 3 hóa đơn trùng lặp (HD59200, HD37858, HD64385) làm đội khống doanh thu **7.196.000 VNĐ**.
   - Nha Trang có 2 chứng từ trùng lặp (NT/0060, NT/0138) làm đội khống doanh thu **2.145.000 VNĐ**.
   -> *Đề nghị:* Cần kiểm tra lại hệ thống xuất dữ liệu hoặc quy trình nhập liệu thủ công tại 2 chi nhánh này để tránh ghi nhận khống doanh thu.

2. **Đơn hàng ngoài kỳ hạch toán (Hải Phòng):**
   - Chi nhánh đưa 4 đơn hàng phát sinh từ 26/09 đến 30/09/2026 vào báo cáo tháng 10 với lý do 'nhập trễ', giá trị **7.800.000 VNĐ**.
   -> *Đề nghị:* Phải hạch toán bổ sung vào kỳ tháng 9/2026, không được gộp vào doanh thu tháng 10 làm sai lệch số liệu kỳ hiện tại.

3. **Ngày tháng mơ hồ, có dấu hiệu nhầm lẫn định dạng MM/DD và DD/MM:**
   - Hải Phòng có 3 đơn hàng ghi ngày `10/09/2026` (tổng **2.391.000 VNĐ**). Không rõ là ngày 10 tháng 9 (ngoài kỳ) hay ngày 09 tháng 10 (trong kỳ) bị gõ theo chuẩn Mỹ MM/DD. Đang tạm treo trạng thái `CAN_NGUOI_QUYET`.
   - Biên Hòa có 3 dòng bị phần mềm Excel tự động hiểu lộn thành ngày tháng 4, tháng 5, tháng 8 (`2026-04-10`, `2026-05-10`, `2026-08-10`). Đã suy luận được ngày đúng nhờ số thứ tự phiếu và dòng cộng tuần.
   - Đà Nẵng lập toàn bộ theo chuẩn `MM/DD/YYYY`, Nha Trang lập theo `DD-MM-YY`.

4. **Lỗi tính toán sai số học và gõ tay số tổng cộng:**
   - Hà Nội gõ tay số tổng cộng cuối bảng lệch thừa **100.000 VNĐ** so với tổng chi tiết.
   - Nha Trang có 2 đơn hàng có Thành tiền lệch so với SL x Đơn giá (+50.000 VNĐ mỗi đơn, tổng lệch **+100.000 VNĐ** ở đơn NT/0132 và NT/0160). Kế toán giữ nguyên số tiền chi nhánh ghi theo nguyên tắc thận trọng nhưng yêu cầu giải trình.

5. **Thiếu dữ liệu nghiêm trọng và bán hàng ngoài danh mục (Cần Thơ):**
   - Chi nhánh Cần Thơ hoàn toàn không có dữ liệu bán hàng trong 7 ngày liên tiếp từ ngày **15/10/2026 đến 21/10/2026**.
   - Xuất hiện mặt hàng lạ **'Combo quà Tết 2026'** tại 2 đơn hàng CT-0070 và CT-0072 với tổng giá trị **13.000.000 VNĐ** chưa có trong danh mục sản phẩm của công ty.

## 6. DANH SÁCH VIỆC CẦN HỎI LẠI CHI NHÁNH VÀ KIẾN NGHỊ

Chi tiết các câu hỏi đã được kết xuất tại file `ra/viec_can_hoi.csv`. Tóm tắt nội dung trọng tâm cần làm việc ngay:

1. **Chi nhánh Hà Nội:** Xác nhận lại con số tổng doanh thu chính xác là **262.936.000 VNĐ** (theo 146 dòng chi tiết), điều chỉnh số tổng gõ tay 263.036.000 VNĐ.
2. **Chi nhánh Hải Phòng:**
   - Xác nhận xóa 3 hóa đơn trùng (HD59200, HD37858, HD64385) giá trị 7.196.000 VNĐ.
   - Xác nhận chuyển 4 đơn tháng 9 (7.800.000 VNĐ) về hạch toán bổ sung cho tháng 9.
   - Xác nhận ngày thực tế của 3 đơn ghi `10/09/2026` (HD89953, HD50470, HD47118): nếu là 09/10/2026 thì bổ sung vào doanh thu tháng 10 (**+2.391.000 VNĐ**); nếu là 10/09/2026 thì chuyển sang tháng 9.
3. **Chi nhánh Cần Thơ:**
   - Giải trình lý do gián đoạn bán hàng từ ngày 15/10 đến 21/10/2026 (chi nhánh đóng cửa hay sót file bán hàng?).
   - Giải trình cơ cấu thành phần của mặt hàng 'Combo quà Tết 2026' (đơn giá 650.000đ) để kế toán quản trị bóc tách phân bổ về 8 sản phẩm chuẩn, hoặc trình Ban Giám đốc phê duyệt mã sản phẩm mới.
4. **Chi nhánh Nha Trang:**
   - Xác nhận xóa 2 chứng từ trùng (NT/0060 và NT/0138) giá trị 2.145.000 VNĐ.
   - Kiểm tra và giải trình tại sao đơn NT/0132 (thực tính 1.110.000đ) lại ghi thành tiền 1.160.000đ và đơn NT/0160 (thực tính 1.260.000đ) lại ghi thành tiền 1.310.000đ.
5. **Chi nhánh Biên Hòa & Đà Nẵng:** Nhắc nhở quy chuẩn lại định dạng ngày tháng theo chuẩn quốc gia `DD/MM/YYYY` hoặc `YYYY-MM-DD` để tránh nhầm lẫn khi tổng hợp tự động.

---
*Báo cáo được tạo tự động bởi hệ thống script `gop.py` dựa trên dữ liệu kế toán thực tế.*  
