"""Dung anh bang du lieu dau vao (HTML->PNG). Du lieu GIA."""
import csv, json, sys, html
from pathlib import Path
import os
sys.path.insert(0, os.environ.get("AGENTLAB_DIR") or str(Path(__file__).resolve().parents[5] / "siptech-video" / "agentlab"))
from term import shot_html as _shot_html, scrub_text
def shot_html(h, *a, **k): return _shot_html(scrub_text(h), *a, **k)   # che duong dan/ ten to chuc truoc khi dung anh
ROOT = Path(__file__).resolve().parent.parent
ans = json.loads((ROOT / "ket-qua/dap-an.json").read_text(encoding="utf-8"))
rows = list(csv.reader(open(ROOT / "du-lieu/nhat-ky-xuat-nhap.csv", encoding="utf-8-sig")))
hdr, body = rows[0], rows[1:]
CSS = """body{margin:0;background:#fff;font-family:'Segoe UI',Arial,sans-serif}.w{padding:16px;width:1180px}
h3{margin:0 0 8px;font-size:17px;color:#0f172a}p{margin:6px 0;color:#475569;font-size:13px}
table{border-collapse:collapse;width:100%;font-size:14px}th{background:#e8edf5;border:1px solid #c5cedb;padding:5px 8px;text-align:left}
td{border:1px solid #d6dce6;padding:4px 8px;font-family:Consolas,monospace;font-size:13px}.r{background:#fde2e2}.y{background:#fff3c4}.g{background:#dff3e0}.b{background:#dbeafe}
.tag{font:12px 'Segoe UI';color:#7f1d1d}.f{color:#64748b;font-size:12px;margin-top:8px}"""
def table(sel, notes, title, sub):
    out = f"<h3>{html.escape(title)}</h3><p>{html.escape(sub)}</p><table><tr>" + "".join(f"<th>{h}</th>" for h in hdr) + "<th>ghi chú của chúng ta (không có trong file)</th></tr>"
    for r, (cls, note) in zip(sel, notes):
        out += f'<tr class="{cls}">' + "".join(f"<td>{html.escape(c)}</td>" for c in r) + f'<td class="tag">{html.escape(note)}</td></tr>'
    return out + "</table>"
by = {}
for i, r in enumerate(body): by.setdefault(r[0], []).append(i)
def pick(loai, n=1):
    return [e["ma_phieu"] for e in ans["loi"] if e["loai_loi"] == loai][:n]
sel = []; notes = []
def add(mp, cls, note, k=0):
    i = by[mp][k]; sel.append(body[i]); notes.append((cls, note))
def datefmt(d):
    if "/" not in d: return "ngày kiểu yyyy-mm-dd"
    return "ngày kiểu dd/mm/yyyy" if len(d.split("/")[2]) == 4 else "ngày kiểu d/m/yy"
seen = set()
for r in body[:40]:
    f = datefmt(r[1])
    if f not in seen and len(seen) < 3:
        seen.add(f); sel.append(r); notes.append(("", "dòng bình thường, " + f))
add(pick("so_am_khong_ghi_chu")[0], "r", "số lượng ÂM, không ghi chú (khách trả hay gõ sai?)")
add(pick("so_luong_gap_10_lan")[0], "r", "số lượng gấp 10 lần bình thường (gõ thừa số 0?)")
add(pick("thieu_so_luong")[0], "r", "thiếu số lượng")
mp = pick("trung_dong")[0]; add(mp, "y", "dòng trùng (lần 1)", 0); add(mp, "y", "dòng trùng (lần 2), cùng mã phiếu", 1)
add(pick("ngay_nhap_o_tuong_lai")[0], "r", "ngày nhập là tháng 12/2026, sau ngày cuối dữ liệu")
add(pick("khach_tra_hang_hop_le")[0], "g", "số âm CÓ ghi chú: trả hàng hợp lệ")
add(pick("xuat_khong_phai_ban_huy")[0], "b", "xuất nhưng không phải bán (hủy hết hạn)")
add(pick("don_si_mot_lan")[0], "b", "đơn sỉ một lần, số lượng rất lớn")
for r in body:
    if r[3] == "" and len(sel) < 16:
        sel.append(r); notes.append(("y", "thiếu mã hàng, chỉ có tên không dấu")); break
for r in body:
    if r[3] != r[3].upper().strip() or "-" in r[3]:
        if len(sel) < 17:
            why = "viết thường" if r[3] != r[3].upper() else "có khoảng trắng thừa" if r[3] != r[3].strip() else "có dấu gạch"
            rr = list(r); rr[3] = '"' + r[3] + '"'; sel.append(rr); notes.append(("y", "mã hàng " + why + " (ví dụ này hiện thêm dấu nháy để thấy khoảng trắng)"))
h = f"<!doctype html><meta charset=utf-8><style>{CSS}</style><div class=w id=w>" + table(sel, notes, "nhat-ky-xuat-nhap.csv (trích các dòng có bẫy)", f"Dữ liệu GIẢ để học · tổng {len(body):,} dòng · cột cuối là chú thích của chúng ta, file thật không có") + "<div class=f>Màu: đỏ = lỗi cần xử lý, vàng = trùng/ định dạng, xanh lá = hợp lệ dễ nhầm, xanh dương = xuất không phải bán/ bất thường thật.</div></div>"
shot_html(h, ROOT / "anh/04-du-lieu-nhat-ky.png", 1230, "#w")
# danh muc + kiem ke
dm = list(csv.DictReader(open(ROOT / "du-lieu/danh-muc-hang.csv", encoding="utf-8-sig")))
kk = {r["ma_hang"]: r["ton_thuc_te_kiem_ke"] for r in csv.DictReader(open(ROOT / "du-lieu/ton-kiem-ke-2026-10-31.csv", encoding="utf-8-sig"))}
pick_codes = ["TH001", "TH008", "VT005", "MP001", "MP012", "TH016", "VT017", "MP014", "MP015", "MP016"]
t = "<h3>danh-muc-hang.csv + ton-kiem-ke (trích 10 / 60 mã)</h3><p>Dữ liệu GIẢ để học. Giá vốn là giá bịa.</p><table><tr><th>ma_hang</th><th>ten_hang</th><th>nhom</th><th>gia_von</th><th>quy cách (bội số)</th><th>giao (ngày)</th><th>trang_thai</th><th>ghi_chu</th><th>tồn kiểm kê 31/10</th></tr>"
for r in dm:
    if r["ma_hang"] in pick_codes:
        t += f"<tr><td>{r['ma_hang']}</td><td>{html.escape(r['ten_hang'])}</td><td>{r['nhom']}</td><td>{int(r['gia_von_hien_tai']):,}</td><td>{r['quy_cach_dat_boi_so']}</td><td>{r['thoi_gian_giao_ngay']}</td><td>{r['trang_thai']}</td><td>{html.escape(r['ghi_chu'])}</td><td>{kk[r['ma_hang']]}</td></tr>"
t += "</table>"
shot_html(f"<!doctype html><meta charset=utf-8><style>{CSS}</style><div class=w id=w style='width:1180px'>{t}</div>", ROOT / "anh/05-du-lieu-danh-muc.png", 1230, "#w")
print("ok")
