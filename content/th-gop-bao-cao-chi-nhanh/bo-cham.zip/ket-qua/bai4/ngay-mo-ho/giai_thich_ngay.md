# Vì sao HD89953 (Hải Phòng) bị coi là "ngày mơ hồ"

**Ô gốc** (`goc/DoanhThu_HP_102026.xlsx`, ô A47): chữ `10/09/2026`. Đây là chữ gõ vào, không phải ngày thật của Excel. Dòng này là HD89953, nước mắm truyền thống 500ml, 3 × 65.000đ = 195.000đ.

**Hai cách đọc**
- Ngày/tháng (dd/mm): 10/9/2026, **ngoài** kỳ tháng 10.
- Tháng/ngày (mm/dd): 9/10/2026, **trong** kỳ tháng 10.

**Vì sao dòng này bị đánh dấu mà phần lớn dòng khác thì không**
Cả hai số đầu đều không quá 12 nên đọc kiểu nào cũng ra ngày hợp lệ. Trong 171 dòng bán hàng của HP:
- 107 dòng có số đầu lớn hơn 12, ví dụ A4 `24/10/2026` (HD67052): không có tháng 24 nên chắc chắn là ngày 24/10.
- 7 dòng là `10/10/2026`, ví dụ A21 (HD60521): đảo lại vẫn là 10/10. Còn A25 `30/09/2026` (HD60907) chắc chắn là 30/9 vì không có tháng 30.
- 54 dòng dạng `05/10/2026` cũng đọc được 2 cách. Nhưng cách dd/mm ra ngày trong tháng 10, hợp với tiêu đề "T10/2026". Cách kia ra 10/5, 10/12... xa kỳ nên không ai đọc theo hướng đó.
- 3 dòng dạng `10/09/2026` (HD89953, HD50470, HD47118): hai cách đọc rơi vào hai phía ranh giới tháng 9/tháng 10, nên ảnh hưởng thẳng đến số tháng 10 (tổng 2.391.000đ).

**Trong file có căn cứ để chọn không?** Có hai hướng ngược nhau, đều chỉ là gián tiếp:
- Nghiêng về 10/9: cả cột có 107 ô chỉ đọc được kiểu dd/mm và 0 ô chỉ đọc được kiểu mm/dd, nên file có vẻ ghi dd/mm.
- Nghiêng về 9/10: (1) ghi chú dòng 177 nói chỉ có "4 đơn tháng 9 nhập trễ (26/09 đến 30/09)", và đúng 4 dòng đó có trong file. Nếu 3 dòng này là 10/9 thì thành 7 đơn tháng 9, lệch ghi chú. (2) Ngày 9/10 là ngày duy nhất trong 1-31/10 không có dòng nào (các ngày khác 3-8 dòng).
- Chưa cái nào chứng minh được, và (2) cũng có thể chỉ là ngày không bán hàng.

**Kết luận:** chưa chọn ngày. Cần chi nhánh HP đối chiếu hóa đơn gốc để xác nhận ngày của HD89953 (và 2 dòng kia). Trong lúc chờ, dòng này đang chưa tính vào tổng tháng 10.
