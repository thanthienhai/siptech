# BÁO CÁO PHÂN TÍCH ĐÁNH GIÁ KHÁCH HÀNG VÀ ĐỀ XUẤT CẢI THIỆN

**Kính gửi:** Chủ quán cà phê  
**Người thực hiện:** Chuyên viên Chăm sóc Khách hàng  
**Thời gian phân tích dữ liệu:** Tháng 08/2026 – Tháng 11/2026 (12 tuần)  

---

## 1. Tổng quan dữ liệu đánh giá

- **Tổng số đánh giá thu thập được:** 250 đánh giá (từ Google Maps, Shopee Food và Facebook).
- **Số bài loại bỏ không đưa vào phân tích:** 7 bài (chiếm 2.8%), ghi nhận chi tiết tại [loai-bo.csv](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/04/runs/agy-3/dau-ra/loai-bo.csv), bao gồm:
  - **4 bài trùng lặp nguyên văn (trung_lap):** R117 (trùng R055), R171 (trùng R111), R177 (trùng R142), R205 (trùng R132) — hệ thống giữ lại bài có ngày sớm nhất.
  - **2 bài quảng cáo/spam (spam):** R070 (dịch vụ tăng like Facebook), R122 (link tặng quà lừa đảo).
  - **1 bài không phải đánh giá (khong_phai_danh_gia):** R228 (câu hỏi về giờ mở cửa).
- **Số đánh giá hợp lệ đưa vào phân tích:** 243 đánh giá.
- **Tổng số ý kiến phân rã được:** 402 ý kiến (trung bình 1.65 ý kiến/đánh giá), lưu trữ đầy đủ tại [y-kien.csv](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/04/runs/agy-3/dau-ra/y-kien.csv).

---

## 2. Bảng phân bố Chủ đề x Sắc thái

Số liệu được đếm và tổng hợp tự động bằng mã nguồn từ tệp [tong-hop.py](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/04/runs/agy-3/dau-ra/tong-hop.py):

| Chủ đề | Tích cực | Tiêu cực | Trung tính | Cần người đọc | Tổng cộng |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **gia** (Giá cả, khuyến mãi, phụ thu) | 14 | 43 | 11 | 3 | **71** |
| **phuc_vu** (Nhân viên, tốc độ, thái độ) | 38 | 29 | 9 | 3 | **79** |
| **chat_luong** (Đồ uống, đồ ăn, hương vị) | 56 | 25 | 10 | 6 | **97** |
| **giao_hang** (Vận chuyển, đóng gói, shipper) | 19 | 30 | 6 | 2 | **57** |
| **khong_gian** (Chỗ ngồi, nhạc, wifi, xe) | 31 | 19 | 6 | 3 | **59** |
| **ve_sinh** (Sạch sẽ, nhà vệ sinh, côn trùng) | 4 | 19 | 4 | 1 | **28** |
| **khac** (Khác, nhận xét chung) | 4 | 0 | 2 | 5 | **11** |
| **TỔNG CỘNG** | **166** | **165** | **48** | **23** | **402** |

---

## 3. Nhận xét xu hướng theo tuần

Bảng chi tiết xu hướng theo tuần được lưu tại [xu-huong-tuan.csv](file:///C:/Users/user/Coding/nguoi-dung/siptech-video/agentlab/04/runs/agy-3/dau-ra/xu-huong-tuan.csv). Qua theo dõi 12 tuần liên tục, diễn biến tâm lý khách hàng có những bước ngoặt rõ rệt:

1. **Giai đoạn 1 (Tuần 24/08/2026 – 21/09/2026): Tích cực chiếm ưu thế**  
   - Trong 5 tuần đầu, quán nhận được phản hồi rất tốt với tỷ lệ khen vượt trội (tổng 79 ý kiến tích cực so với 54 tiêu cực). Khách hàng đánh giá cao hương vị bánh tươi mềm, các món signature như cà phê muối, trà đào cam sả, không gian làm việc có ổ cắm, wifi tốt và thái độ nhân viên dễ thương.

2. **Giai đoạn 2 (Tuần 28/09/2026 – 12/10/2026): Bùng nổ phản ứng tiêu cực vì tăng giá**  
   - Bắt đầu từ tuần 28/09, các phản ánh tiêu cực về giá tăng đột biến (nhảy vọt từ 0–2 ý kiến tiêu cực/tuần lên 6–7 ý kiến/tuần). Khách bức xúc vì quán tăng giá 10k/món nhưng không thông báo trước, kích thước ly không tăng thậm chí có cảm giác nhỏ đi, làm mất đi lợi thế cạnh tranh so với các quán lân cận.

3. **Giai đoạn 3 (Tuần 19/10/2026 – 02/11/2026): Khủng hoảng an toàn thực phẩm và sự cố giao hàng**  
   - Đây là giai đoạn đáng báo động nhất: liên tiếp xảy ra các vụ nghi ngộ độc thực phẩm nặng (hai vợ chồng đi cấp cứu sau khi ăn bánh mì chả ngày 20/10, trẻ em nôn sốt sau khi ăn tiramisu ngày 21/10, sữa chua cacao hỏng gây đau bụng quặn ngày 26/10) và phát hiện dị vật (gián nổi trong ly nước ép cam ngày 22/10).  
   - Cùng thời điểm, khi lượng đặt món giao hàng trực tuyến tăng thì phát sinh hàng loạt lỗi nghiêm trọng: giao trễ gần 1 tiếng, đổ nước ướt túi, giao thiếu món, shipper không nghe máy. Ý kiến tiêu cực áp đảo hoàn toàn ý kiến tích cực (đỉnh điểm tuần 26/10 chỉ có 5 tích cực nhưng có tới 17 tiêu cực).

4. **Giai đoạn 4 (Tuần 09/11/2026): Tạm lắng nhưng tiềm ẩn rủi ro vệ sinh**  
   - Tuần cuối cùng ghi nhận phản hồi dần cân bằng (12 tích cực, 11 tiêu cực), tuy nhiên vấn đề vệ sinh (ly còn dính son môi, ruồi quanh quầy bánh, sàn ướt) vẫn tiếp tục bị phàn nàn.

---

## Việc 1: Kiểm soát an toàn vệ sinh thực phẩm và xử lý dứt điểm các ca nghi ngộ độc, dị vật

- **Vì sao:** Đây là vấn đề nguy cấp mức độ cao nhất (loại `ngo_doc`). Quán đã ghi nhận các trường hợp khách hàng phải nhập viện cấp cứu nghi ngộ độc thực phẩm sau khi ăn bánh mì chả, trẻ em nôn sốt sau khi ăn bánh tiramisu, khách đau bụng quặn do sữa chua hỏng và phát hiện gián trong nước ép cam. Nếu không can thiệp ngay lập tức, quán đối diện nguy cơ bị cơ quan chức năng đình chỉ hoạt động, phạt hành chính nặng và khủng hoảng truyền thông tẩy chay diện rộng.
- **Đề xuất hành động:**  
  1. *Ngừng phục vụ và kiểm định ngay lập tức:* Niêm phong, kiểm tra toàn bộ lô nguyên liệu chả lụa, phô mai/kem làm tiramisu, sữa chua và trái cây tươi; rà soát hạn sử dụng và điều kiện bảo quản nhiệt độ tủ mát/tủ đông.  
  2. *Chủ động liên hệ khách hàng bị ảnh hưởng:* Gọi điện thăm hỏi sức khỏe, nhận trách nhiệm, chi trả viện phí và có giải pháp bồi hoàn chân thành để xoa dịu khủng hoảng.  
  3. *Tổng vệ sinh và diệt côn trùng định kỳ:* Thuê đơn vị khử trùng, diệt gián, ruồi tại khu vực quầy bar và tủ trưng bày bánh; lắp chụp kính chắn côn trùng cho tủ bánh; siết chặt quy trình rửa và sấy tiệt trùng ly tách để loại bỏ hoàn toàn vết son môi.
- **Bằng chứng:**  
> [R170] "Ăn bánh mì chả ở đây trưa thứ Ba, tối cả hai vợ chồng nôn mửa với tiêu chảy, phải đi cấp cứu. Bác sĩ nói nghi ngộ độc thực phẩm. Quán kiểm tra lại nguồn chả giùm."  
> [R175] "Đặt trà sữa với bánh tiramisu giao tận nhà, con mình 6 tuổi ăn xong 2 tiếng sau nôn và sốt. Hoang mang quá, ai ăn tiramisu hôm đó nhớ để ý."  
> [R178] "mình thấy 1 con gián nhỏ nổi trong ly nước ép cam, chụp hình rồi. ghê quá, hết dám uống luôn"  

---

## Việc 2: Chấn chỉnh đạo đức, thái độ giao tiếp của nhân viên và văn hóa ứng xử với khách hàng

- **Vì sao:** Thuộc nhóm nguy cấp nghiêm trọng (loại `thai_do`). Dù quán có nhiều bạn nhân viên dễ thương, nhưng một số ca làm việc xuất hiện nhân viên (kể cả quản lý) có hành vi thô lỗ, chửi bới xúc phạm khách ("mù hả không đọc menu à"), ném menu xuống bàn, liếc xéo và đuổi khách ra khỏi quán ("không mua thì ra"). Hành vi này phá hủy trực tiếp trải nghiệm và uy tín của quán, khiến khách bức xúc thề không quay lại.
- **Đề xuất hành động:**  
  1. *Xử lý kỷ luật nghiêm khắc:* Xác minh ca làm việc của các sự việc được nêu (thu ngân xúc phạm khách tại R039, nhân viên nam ca tối tại R057, nhân viên ca R066 và quản lý tại R083); tạm đình chỉ hoặc chấm dứt hợp đồng với nhân viên có hành vi lăng mạ, đuổi khách.  
  2. *Ban hành bộ quy chuẩn ứng xử dịch vụ (SOP):* Đào tạo lại toàn bộ đội ngũ về văn hóa giao tiếp: luôn tươi cười, tôn trọng khách hàng trong mọi tình huống; quy định rõ nhân viên không được to tiếng, cãi vã hay thể hiện thái độ khinh miệt khách.  
  3. *Bố trí nhân sự giờ cao điểm:* Bổ sung nhân sự cho các ca trưa và cuối tuần để giảm áp lực cho nhân viên, hạn chế việc nhân viên quá tải dẫn đến cáu gắt với khách.
- **Bằng chứng:**  
> [R039] "Mình hỏi lại giá ly bạc xỉu thì bạn thu ngân chửi luôn 'mù hả không đọc menu à' trước mặt cả quán. Nói chuyện kiểu đó với khách thì thôi, khỏi quay lại."  
> [R057] "Bạn nam ca tối ném menu xuống bàn rồi quay đi, hỏi gì cũng trả lời trống không. Xin thêm ly nước lọc thì liếc xéo nói 'không mua thì ra'."  
> [R066] "báo hết chỗ nhưng mình thấy rõ còn 3 bàn trống, mình thắc mắc thì bị nhân viên đuổi ra khỏi quán, giọng rất hách dịch"  

---

## Việc 3: Rà soát tính minh bạch hóa đơn, phụ thu và chấm dứt các dấu hiệu gian lận

- **Vì sao:** Thuộc nhóm nguy cấp về tính trung thực kinh doanh (loại `lua_dao`). Khách hàng phản ánh các hành vi gian lận rất nghiêm trọng: tính khống thêm món trên bill nhưng ép khách trả vì "máy tính tự tính", tự cộng 10% phí dịch vụ không niêm yết trên menu và không báo trước, tính tiền size L nhưng phục vụ ly size M, nhận tiền đơn Shopee Food nhưng tự bấm hoàn thành mà không giao hàng rồi cúp máy. Điều này tạo cảm giác quán đang lừa đảo, "móc túi" khách hàng.
- **Đề xuất hành động:**  
  1. *Chuẩn hóa quy trình in và kiểm tra bill:* Yêu cầu nhân viên thu ngân đọc lại tên món và đưa hóa đơn cho khách kiểm tra trước khi quẹt thẻ hoặc nhận tiền mặt; nghiêm cấm nhân viên tự ý thu thêm bất kỳ khoản phí nào ngoài menu.  
  2. *Rà soát hệ thống POS và công khai giá/phí:* Cài đặt lại phần mềm bán hàng chính xác; niêm yết rõ ràng chính sách phí (nếu có VAT hoặc phí dịch vụ phải ghi rõ trên bảng menu lớn và trang mạng xã hội, không được thu ngầm).  
  3. *Quy định kích cỡ ly và giám sát đơn hàng online:* Dán vạch định mức hoặc chuẩn hóa mẫu ly phân biệt rõ ràng giữa size M và size L; xử lý ngay đơn hàng Shopee Food bị lỗi, bồi thường đầy đủ 189k cho khách hàng ở đơn R197 và chấn chỉnh bộ phận trực máy đơn online.
- **Bằng chứng:**  
> [R149] "Bill ghi 2 ly bạc xỉu mà mình chỉ gọi 1, báo thì nhân viên bảo máy tính tự tính nên cứ trả đủ. Mình thấy như bị móc túi, ai thanh toán nhớ soi bill kỹ."  
> [R197] "Đặt Shopee Food đã trả tiền xong, quán bấm hoàn thành đơn mà không giao, gọi lại thì cúp máy. Mất 189k. Lừa đảo!"  
> [R216] "Cuối bill tự cộng 10% phí dịch vụ, menu không ghi chỗ nào, hỏi thì nói quy định mới. Báo trước một câu cũng không."  

---

## Việc 4: Đánh giá lại chiến lược giá bán và truyền thông minh bạch về chính sách giá

- **Vì sao:** Đây là vấn đề có mức độ ảnh hưởng diện rộng lớn nhất trong toàn bộ dữ liệu (chiếm 43 ý kiến tiêu cực, bắt đầu bùng nổ từ cuối tháng 9). Khách hàng bức xúc việc quán tăng giá đồng loạt khoảng 10k/món, trà sữa lên 49k, bạc xỉu lên 65k, cà phê muối lên 55k nhưng chất lượng và dung tích ly không đổi (thậm chí có phản ánh ly nhỏ lại). Tăng giá đột ngột không báo trước khiến khách hàng trung thành, sinh viên cảm thấy bị "xót ví" và bỏ sang quán đối thủ cạnh tranh.
- **Đề xuất hành động:**  
  1. *Truyền thông giải thích rõ ràng nếu điều chỉnh giá:* Khi có sự thay đổi giá, quán cần có thông báo trước trên fanpage và tại quầy, nêu rõ lý do nâng cấp nguyên liệu hoặc chất lượng phục vụ để nhận được sự đồng cảm từ khách.  
  2. *Cân đối cấu trúc giá sản phẩm:* Xem xét đưa ra các dòng sản phẩm cơ bản với mức giá sinh viên/bình dân (ví dụ duy trì trà đào/trà sữa size chuẩn 35k–40k như trước đây); giữ mức giá cao cấp đi kèm dung tích lớn hoặc topping phong phú.  
  3. *Xây dựng chương trình khách hàng thân thiết:* Áp dụng tích điểm, combo tiết kiệm hoặc ưu đãi giảm giá thực chất cho khách quen để giữ chân tệp khách hàng cốt lõi.
- **Bằng chứng:**  
> [R118] "lên giá mà không báo trước, thấy hơi tiếc"  
> [R119] "Giá lên hoài, giờ đắt hơn quán bên cạnh, trà sữa ngọt gắt, uống một ngụm là ngán"  
> [R151] "Giá lên mà ly thì nhỏ lại?? 55k 1 ly cf muối mà uống 3 ngụm hết, ko đáng tiền, nhưng cf thì vẫn ngon"  

---

## Việc 5: Cải thiện quy trình đóng gói và nâng cao chất lượng dịch vụ giao hàng trực tuyến

- **Vì sao:** Giao hàng trực tuyến (Shopee Food) là kênh doanh thu quan trọng nhưng đang phải nhận tới 30 ý kiến tiêu cực. Các lỗi tái diễn liên tục với tần suất cao gồm: nước uống bị đổ tràn ra túi dính đầy do đóng gói sơ sài (chiếm tới 7 đánh giá), đồ ăn giao tới nguội ngắt và giao thiếu món (chiếm 7 đánh giá), giao trễ gần 1 tiếng khiến khách không kịp giờ nghỉ trưa.  
- **Đề xuất hành động:**  
  1. *Đổi mới quy cách đóng gói chống tràn:* Đầu tư máy dập màng nắp ly nhựa thay vì dùng nắp rời dễ bật; sử dụng khay định hình hoặc túi giữ cốc chuyên dụng có vách ngăn chống xô lệch; bọc kín nắp bằng băng keo niêm phong.  
  2. *Thiết lập checklist kiểm đơn hàng trước khi bàn giao:* Nhân viên bếp/quầy bar phải đánh dấu đối chiếu từng món trên bill trước khi đóng túi, dán hóa đơn bên ngoài túi để shipper và khách dễ kiểm tra, chấm dứt triệt để tình trạng giao thiếu món.  
  3. *Tối ưu hóa thời gian chuẩn bị món trên ứng dụng:* Cài đặt thời gian chuẩn bị món trên app phù hợp vào giờ cao điểm, phối hợp chọn đối tác giao hàng nhanh để tránh việc đồ ăn nguội ngắt hoặc giao trễ quá giờ của khách.
- **Bằng chứng:**  
> [R013] "giao chậm hơn dự kiến gần 1 tiếng"  
> [R101] "Nước giao tới bị đổ ra túi, dính đầy 👎"  
> [R144] "Đồ ăn tới nguội và thiếu một món"  
