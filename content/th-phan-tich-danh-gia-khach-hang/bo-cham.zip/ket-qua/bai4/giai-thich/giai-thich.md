# File `tong-hop.py` làm gì?

File này đọc các lời đánh giá của khách và đếm xem mỗi tuần, mỗi chủ đề (giá, phục vụ, chất lượng...) có bao nhiêu ý khen, chê, bình thường.

## 1. File chạy qua các bước nào (theo thứ tự)

1. Mở file đánh giá gốc `danh-gia.csv` (file CSV là bảng giống Excel nhưng lưu bằng chữ thuần) và ghi lại ngày của từng bài đánh giá.
2. Mở danh sách bài bị loại (`loai-bo.csv`: bài rác quảng cáo, bài đăng trùng, bài không phải đánh giá) để lát nữa bỏ qua các bài này.
3. Mở bảng ý kiến (`y-kien.csv`): mỗi dòng là một ý lấy ra từ một bài, đã gắn chủ đề và gắn nhãn khen, chê, bình thường hoặc "CẦN NGƯỜI ĐỌC" (máy chưa chắc, cần người xem).
4. Đi qua từng ý một: ý thuộc bài bị loại thì bỏ qua; nếu gặp mã bài lạ hoặc nhãn viết sai thì dừng lại và báo lỗi.
5. Với mỗi ý còn lại, đổi ngày của bài thành ngày thứ Hai của tuần đó, rồi cộng thêm 1 vào ô đếm của "tuần đó, chủ đề đó, nhãn đó".
6. Ghi kết quả ra file mới `xu-huong-tuan.csv`: mỗi tuần liên tục từ đầu đến cuối, mỗi chủ đề một dòng, chỗ nào không có ý nào thì ghi số 0.
7. In ra màn hình các số tổng: tổng số đánh giá, số bài bị loại, số bài được phân tích, tổng số ý kiến, số tuần.
8. In bảng đếm theo chủ đề và nhãn, cùng danh sách các bài cần người đọc lại.

## 2. Chạy thử và một ví dụ có số thật

Đã chạy `python -X utf8 dau-ra/tong-hop.py`, chạy được, không báo lỗi, và tạo ra `dau-ra/xu-huong-tuan.csv` (84 dòng số liệu = 12 tuần x 7 chủ đề). Các số chính: 250 đánh giá, 8 bài bị loại, 242 bài được phân tích, 404 ý kiến.

Một dòng trong bảng đếm:

| chu_de | tich_cuc | tieu_cuc | trung_tinh | CAN_NGUOI_DOC | tong |
|---|---:|---:|---:|---:|---:|
| gia | 14 | 44 | 11 | 2 | 71 |

Nghĩa là: có 71 ý kiến nhắc đến **giá**. Trong đó 14 ý khen giá hợp lý, **44 ý chê giá** (ví dụ R041: "giá hơi cao so với cái ly nhỏ xíu"), 11 ý nói giá bình thường, 2 ý máy chưa chắc nên cần người đọc. Giá là chủ đề bị chê nhiều nhất (44 trên 71).

Lưu ý: bảng đếm **ý kiến**, không đếm **bài**. Một bài có thể chứa nhiều ý (ví dụ R003 vừa nói về giá, vừa chê chỗ ngồi), nên có 404 ý nhưng chỉ có 242 bài. Đừng đọc 404 thành "404 khách".

Tôi đã kiểm lại con số 44 bằng cách khác (đếm thẳng các dòng "gia, tieu_cuc" trong `y-kien.csv`, và cộng cột chê của chủ đề giá trong `xu-huong-tuan.csv`): cả hai đều ra 44. Tổng mọi ô trong `xu-huong-tuan.csv` cũng ra đúng 404.

## 3. Hai chỗ viết sai thì số đếm sai mà khó nhận ra

### Chỗ 1: đổi ngày thành tuần (dòng 26 đến 34 của file)

File gốc ghi ngày theo **hai kiểu lẫn lộn**: 101 bài ghi kiểu `2026-08-25`, 149 bài ghi kiểu `24/08/2026` (ngày/tháng/năm). Trong số kiểu thứ hai, 68 bài có ngày từ 1 đến 12, ví dụ `02/10/2026`: nếu file đọc nhầm thành tháng/ngày thì đó là ngày 10 tháng 2, vẫn là một ngày hợp lệ, **không báo lỗi**, bài chỉ lặng lẽ rơi vào sai tuần. Việc chọn "thứ Hai" làm đầu tuần (dòng 33 đến 34) cũng vậy: lệch một ngày là cả tuần bị chia khác đi.

Hiện tại file đang đọc đúng (tôi đã kiểm). Cách kiểm lại mỗi khi có người sửa file:
- Nhìn dòng "So tuan" khi chạy: phải là **12 tuần, từ 2026-08-24 đến 2026-11-09**. Nếu ra 40 tuần hay ngày bắt đầu lạ, tức là có ngày bị đọc nhầm ngày với tháng.
- Mở `xu-huong-tuan.csv`, cột `tuan` phải toàn thứ Hai (kiểm với lịch).
- Chọn tay vài bài có ngày dễ nhầm. Ví dụ R110 ngày 02/10/2026 (thứ Sáu) phải được tính vào tuần bắt đầu **2026-09-28**, vì thứ Hai gần nhất trước đó là 28/9.
- Trong `danh-gia.csv`, mã bài càng lớn thì ngày càng muộn. Đã kiểm: không có chỗ nào lùi ngày. Nếu có bài ngày nhảy lùi so với bài trước nó thì ngày đó đáng nghi.

### Chỗ 2: danh sách bài bị loại (dòng 38, 42 và 51 của file)

File chỉ bỏ những bài **có mã nằm trong `loai-bo.csv`**, đúng từng ký tự. Nó không tự kiểm bài đó có thật là rác hay là bài trùng hay không. Nếu một dòng trong danh sách loại bị gõ sai mã, hoặc loại nhầm một bài thật, hoặc sót một bài trùng, file vẫn chạy bình thường và vẫn in ra con số trông hợp lý. Lúc này ý kiến bị đếm hai lần hoặc bị mất mà không ai thấy.

Một điều đáng biết: dòng in "y kien bi bo qua do bai bi loai" hiện là **0**. Nghĩa là bước loại bỏ trong file lần này thực ra chưa phải làm gì, vì `y-kien.csv` đã được làm sạch từ trước. Tức là việc loại đúng hay sai nằm hết ở file danh sách chứ không nằm ở chương trình.

Cách kiểm:
- Mở `loai-bo.csv` (8 dòng). Với mỗi bài "trùng lặp", mở bài gốc ghi ở cột `ma_goc` trong `danh-gia.csv` và so nội dung. Ví dụ R117 bị loại vì trùng R055; cả hai là "Shipper thân thiện, tới đúng giờ" trên Shopee Food. Với bài "spam" và "không phải đánh giá" thì đọc thử bài đó.
- Kiểm theo chiều ngược lại: có những bài giống hệt chữ của bài khác mà **không** nằm trong danh sách loại, ví dụ R101 và R147 giống R015 (nước giao bị đổ), R173 và R210 giống R144 (đồ ăn nguội, thiếu món). Có thể đó là khách khác nhau gặp cùng một chuyện, cũng có thể là bài đăng lại. Chủ quán nên xem rồi quyết định, vì file sẽ đếm cả ba lần.
- Sau khi sửa danh sách loại, chạy lại và so hai số trên cùng một dòng: "So bai phan tich" và "bai co it nhat 1 y kien" (hiện cùng là 242). Nếu hai số lệch nhau, có bài chưa được gắn ý kiến hoặc danh sách loại đang sai.
