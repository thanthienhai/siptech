# -*- coding: utf-8 -*-
"""
Script tính toán báo giá tự động cho Công ty TNHH An Phát Demo.
Đọc bảng giá, quy đổi đơn vị, tham số báo giá và lập báo giá chuẩn cho 12 yêu cầu (R01 - R12).
"""

import os
import math
import openpyxl
from openpyxl.styles import Alignment

def round_vnd(val):
    """Làm tròn số tiền đến đồng theo quy định (0.5 làm tròn lên)."""
    if val is None:
        return None
    return int(math.floor(val + 0.5))

class BangGiaManager:
    """Quản lý bảng giá, quy đổi đơn vị và tham số báo giá."""
    def __init__(self, bang_gia_path='bang-gia.xlsx', mau_path='mau-bao-gia.xlsx'):
        self.bang_gia_path = bang_gia_path
        self.mau_path = mau_path
        self.items = {}
        self.conversions = {}
        self.params = {}
        self._load_data()

    def _load_data(self):
        # Đọc sheet BangGia và QuyDoi từ bang-gia.xlsx
        wb_bg = openpyxl.load_workbook(self.bang_gia_path)
        ws_bg = wb_bg['BangGia']
        for row in list(ws_bg.iter_rows(values_only=True))[3:]:
            if row[0]:
                code = str(row[0]).strip()
                self.items[code] = {
                    'ma': code,
                    'ten': row[1],
                    'nhom': row[2],
                    'dvt': row[3],
                    'gia1': row[4],
                    'bac2_sl': row[5],
                    'gia2': row[6],
                    'bac3_sl': row[7],
                    'gia3': row[8],
                    'tinh_trang': row[9]
                }

        if 'QuyDoi' in wb_bg.sheetnames:
            ws_qd = wb_bg['QuyDoi']
            for row in list(ws_qd.iter_rows(values_only=True))[2:]:
                if row[0] and row[1]:
                    code = str(row[0]).strip()
                    unit_other = str(row[1]).strip().lower()
                    factor = row[2]
                    self.conversions[(code, unit_other)] = factor

        # Đọc sheet Tham số từ mau-bao-gia.xlsx
        wb_mau = openpyxl.load_workbook(self.mau_path)
        if 'Tham số' in wb_mau.sheetnames:
            ws_ts = wb_mau['Tham số']
            for row in list(ws_ts.iter_rows(values_only=True))[1:]:
                if row[0]:
                    param_name = str(row[0]).strip()
                    self.params[param_name] = row[1]

    def get_tier_price(self, code, qty):
        """Tra đơn giá theo bậc số lượng của chính mã hàng."""
        if code not in self.items:
            raise ValueError(f"Mã hàng '{code}' không tồn tại trong bảng giá.")
        item = self.items[code]
        if qty >= item['bac3_sl']:
            return item['gia3']
        elif qty >= item['bac2_sl']:
            return item['gia2']
        else:
            return item['gia1']

    def convert_quantity(self, code, qty, from_unit):
        """Quy đổi số lượng từ đơn vị khác sang ĐVT gốc."""
        unit_clean = str(from_unit).strip().lower()
        if code not in self.items:
            return None, "Mã hàng không có trong bảng giá"
        base_unit = self.items[code]['dvt'].lower()
        if unit_clean == base_unit:
            return qty, ""
        key = (code, unit_clean)
        if key in self.conversions:
            factor = self.conversions[key]
            return qty * factor, f"{qty} {from_unit} = {qty * factor} {self.items[code]['dvt']}"
        return None, f"Không có quy đổi đơn vị cho '{from_unit}'"


def tinh_bao_gia(lines_input, req_meta, bg_manager):
    """
    Tính tiền cho một yêu cầu báo giá:
    lines_input: danh sách tuple (ma_hang, so_luong, ghi_chu)
    req_meta: dict chứa customer, address, is_inner, has_address, extra_discount, status
    """
    total_goods = 0
    non_equip_goods = 0
    calculated_lines = []

    for idx, (code, qty, custom_note) in enumerate(lines_input, start=1):
        item_info = bg_manager.items[code]
        unit_price = bg_manager.get_tier_price(code, qty)
        line_amount = qty * unit_price
        total_goods += line_amount
        if item_info['nhom'] != 'Thiết bị':
            non_equip_goods += line_amount

        calculated_lines.append({
            'stt': idx,
            'ma_hang': code,
            'ten_hang': item_info['ten'],
            'dvt': item_info['dvt'],
            'so_luong': qty,
            'don_gia': unit_price,
            'thanh_tien': line_amount,
            'ghi_chu': custom_note,
            'nhom': item_info['nhom']
        })

    # 1. Chiết khấu theo giá trị đơn hàng (áp dụng tự động theo mục 2)
    auto_disc_pct = 0
    if total_goods >= 30000000:
        auto_disc_pct = 4
    elif total_goods >= 10000000:
        auto_disc_pct = 2

    # 2. Chiết khấu thêm do NVKD duyệt (mục 3)
    extra_disc_pct = req_meta.get('extra_discount', 0)
    total_disc_pct = auto_disc_pct + extra_disc_pct

    # Chiết khấu chỉ tính trên các dòng KHÔNG thuộc nhóm Thiết bị
    if non_equip_goods > 0 and total_disc_pct > 0:
        discount_amount = round_vnd(non_equip_goods * total_disc_pct / 100)
    else:
        discount_amount = 0

    after_disc_before_vat = total_goods - discount_amount

    # 3. Phí giao hàng theo điều kiện giao hàng
    has_address = req_meta.get('has_address', True)
    is_inner = req_meta.get('is_inner', True)

    if not has_address:
        delivery_fee = None
        delivery_note = "Chưa có địa chỉ giao hàng"
    elif not is_inner:
        delivery_fee = None
        delivery_note = "Theo thỏa thuận (ngoại tỉnh)"
    else:
        if after_disc_before_vat >= 3000000:
            delivery_fee = 0
            delivery_note = "Miễn phí giao hàng (nội thành >= 3.000.000đ)"
        else:
            delivery_fee = 40000
            delivery_note = "Phí giao hàng nội thành (< 3.000.000đ)"

    # 4. Cộng trước VAT
    if delivery_fee is not None:
        subtotal_before_vat = after_disc_before_vat + delivery_fee
    else:
        subtotal_before_vat = after_disc_before_vat

    # 5. Thuế VAT (lấy theo tham số)
    vat_percent = bg_manager.params.get('vat_percent', 10)
    vat_amount = round_vnd(subtotal_before_vat * vat_percent / 100)

    # 6. Tổng cộng
    grand_total = subtotal_before_vat + vat_amount

    return {
        'lines': calculated_lines,
        'total_goods': total_goods,
        'non_equip_goods': non_equip_goods,
        'auto_disc_pct': auto_disc_pct,
        'extra_disc_pct': extra_disc_pct,
        'total_disc_pct': total_disc_pct,
        'discount_amount': discount_amount,
        'after_disc_before_vat': after_disc_before_vat,
        'delivery_fee': delivery_fee,
        'delivery_note': delivery_note,
        'subtotal_before_vat': subtotal_before_vat,
        'vat_percent': vat_percent,
        'vat_amount': vat_amount,
        'grand_total': grand_total
    }


def fill_quote_template(calc_result, req_id, req_meta, bg_manager, template_path, output_path):
    """Điền kết quả tính toán vào bản sao template mau-bao-gia.xlsx."""
    wb = openpyxl.load_workbook(template_path)
    ws = wb['Báo giá']

    # Header metadata
    ws['B5'] = req_meta.get('customer', '')
    ws['B6'] = req_meta.get('address', '')
    ws['B7'] = req_id
    quote_date = bg_manager.params.get('ngay_bao_gia', '2026-11-20')
    valid_days = bg_manager.params.get('hieu_luc_ngay', 7)
    ws['B8'] = f"{quote_date} (hiệu lực {valid_days} ngày)"
    ws['B9'] = req_meta.get('status', 'SAN_SANG')
    ws['C9'] = None  # Xóa text hướng dẫn mẫu để hiển thị ô B9 rõ ràng

    # Điền bảng dòng hàng (bắt đầu từ dòng 14)
    start_row = 14
    for idx, line in enumerate(calc_result['lines']):
        r = start_row + idx
        ws.cell(row=r, column=1, value=line['stt'])
        ws.cell(row=r, column=2, value=line['ma_hang'])
        ws.cell(row=r, column=3, value=line['ten_hang'])
        ws.cell(row=r, column=4, value=line['dvt'])
        ws.cell(row=r, column=5, value=line['so_luong'])
        ws.cell(row=r, column=6, value=line['don_gia'])
        ws.cell(row=r, column=7, value=line['thanh_tien'])
        ws.cell(row=r, column=8, value=line['ghi_chu'])

        # Căn lề và định dạng số
        ws.cell(row=r, column=1).alignment = Alignment(horizontal='center')
        ws.cell(row=r, column=4).alignment = Alignment(horizontal='center')
        ws.cell(row=r, column=5).alignment = Alignment(horizontal='right')
        ws.cell(row=r, column=6).number_format = '#,##0'
        ws.cell(row=r, column=7).number_format = '#,##0'

    # Dòng tổng:
    # Row 29: Cộng tiền hàng
    ws['G29'] = calc_result['total_goods']
    ws['G29'].number_format = '#,##0'

    # Row 30: Chiết khấu
    ws['G30'] = calc_result['discount_amount']
    ws['G30'].number_format = '#,##0'
    disc_str = f"{calc_result['total_disc_pct']}%"
    if calc_result['total_disc_pct'] > 0:
        disc_str += " (chỉ áp dụng cho dòng không thuộc Thiết bị)"
    ws['H30'] = disc_str

    # Row 31: Phí giao hàng
    if calc_result['delivery_fee'] is not None:
        ws['G31'] = calc_result['delivery_fee']
        ws['G31'].number_format = '#,##0'
    else:
        ws['G31'] = None
    ws['H31'] = calc_result['delivery_note']

    # Row 32: Cộng trước VAT
    ws['G32'] = calc_result['subtotal_before_vat']
    ws['G32'].number_format = '#,##0'

    # Row 33: VAT
    ws['G33'] = calc_result['vat_amount']
    ws['G33'].number_format = '#,##0'
    ws['H33'] = f"{calc_result['vat_percent']}% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi)"

    # Row 34: Tổng cộng
    ws['G34'] = calc_result['grand_total']
    ws['G34'].number_format = '#,##0'
    if calc_result['delivery_fee'] is None:
        if not req_meta.get('has_address', True):
            ws['H34'] = "Chưa bao gồm phí giao hàng"
        elif not req_meta.get('is_inner', True):
            ws['H34'] = "Chưa bao gồm cước vận chuyển ngoại tỉnh"

    # Lưu file
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb.save(output_path)


# Dữ liệu 12 yêu cầu
ALL_REQUESTS = {
    'R01': {
        'customer': 'Chị Lan - Phòng Hành chính, Công ty TNHH Cơ khí Ánh Dương (ĐT: 0900 000 101)',
        'address': '12 Đường Số 5, Quận Hà Đông, Hà Nội',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 2,  # Khách xin 2%, nhân viên duyệt theo thẩm quyền (tổng 2% <= 5%)
        'status': 'SAN_SANG',
        'items': [
            ('GIAY-A4-80', 25, ''),
            ('BUT-BI-TL027-XANH', 60, '3 hộp = 60 cây'),
            ('BANGKEO-TRONG-48', 10, '')
        ],
        'questions': [],  # Không có câu hỏi
        'email_notes': {
            'quoted_summary': 'Giấy A4 80gsm (25 ram), Bút bi xanh TL027 (3 hộp = 60 cây), Băng keo trong 48mm (10 cuộn).',
            'unquoted_summary': 'Không có.',
            'special_points': 'Đã áp dụng chiết khấu 2% theo thẩm quyền nhân viên kinh doanh dành cho khách quen.'
        }
    },
    'R02': {
        'customer': 'Anh Dũng (Dung Phat)',
        'address': 'Chưa cung cấp',
        'is_inner': None,
        'has_address': False,
        'extra_discount': 0,
        'status': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
        'items': [
            ('MUC-HP-12A', 6, '')
        ],
        'questions': [
            'Quý khách vui lòng cho biết số lượng cụ thể cho mặt hàng Giấy A4 80gsm (theo ram hoặc theo thùng)?',
            'Quý khách vui lòng cung cấp địa chỉ giao hàng cụ thể để An Phát xác định khu vực và tính phí giao hàng?',
            'Về yêu cầu giao gấp trong buổi chiều, An Phát cần chuyển thông tin sang bộ phận kho kiểm tra lịch vận chuyển và sẽ có xác nhận bằng văn bản, nhân viên không thể cam kết giao ngay theo giờ yêu cầu.'
        ],
        'email_notes': {
            'quoted_summary': 'Hộp mực HP 12A (6 hộp).',
            'unquoted_summary': 'Giấy A4 80gsm (do chưa có số lượng cụ thể).',
            'special_points': 'Yêu cầu giao gấp trong chiều nay đã chuyển kho kiểm tra và sẽ có xác nhận bằng văn bản.'
        }
    },
    'R03': {
        'customer': 'Hạnh (hanh.vp@example.com)',
        'address': 'Tòa nhà Mẫu số 3 đường Demo, Quận Cầu Giấy, Hà Nội',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 0,
        'status': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
        'items': [
            ('GIAY-A4-80', 10, ''),
            ('MUC-HP-12A', 3, '')
        ],
        'questions': [
            'Mã hàng "MUC-HP-12C" hiện không có trong bảng giá của An Phát. Quý khách vui lòng kiểm tra lại xem có phải là mã hộp mực HP 12A (MUC-HP-12A) hay mã sản phẩm nào khác không ạ?',
            'Mặt hàng bút gel mực xanh (BUT-GEL-05-XANH) hiện chưa có trong danh mục bảng giá (bên em chỉ có bút gel mực đen BUT-GEL-05-DEN hoặc bút bi bấm mực xanh BUT-BI-TL027-XANH). Quý khách có muốn đổi sang sản phẩm tương đương có sẵn hay để An Phát chuyển phòng Mua hàng tìm nguồn nhập và báo giá sau ạ?'
        ],
        'email_notes': {
            'quoted_summary': 'Giấy A4 80gsm (10 ram), Hộp mực HP 12A (3 hộp).',
            'unquoted_summary': 'Mực MUC-HP-12C (sai/không có mã trong bảng giá, cần xác nhận lại); Bút gel xanh 2 hộp (chưa có trong bảng giá, đã chuyển phòng Mua hàng).',
            'special_points': 'Cần khách làm rõ mã mực MUC-HP-12C và nhu cầu đổi loại bút gel.'
        }
    },
    'R04': {
        'customer': 'Chị Mai - Phòng Hành chính (mai.hanhchinh@example.com)',
        'address': '25 Đường Mẫu, Quận 7, TP. Hồ Chí Minh',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 0,
        'status': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
        'items': [
            ('GIAY-A4-70', 30, '')
        ],
        'questions': [
            'Quý trường vui lòng cung cấp thông tin chi tiết hơn về thương hiệu, model hoặc cấu hình kỹ thuật mong muốn cho Máy photocopy A3 đa năng và Máy chiếu độ phân giải 4K để phòng Mua hàng của An Phát tìm nguồn nhập và báo giá chính xác ạ?',
            'Về yêu cầu cần hàng gấp trong tuần, thời gian giao hàng cụ thể sẽ do bộ phận kho xác nhận bằng văn bản sau khi đơn hàng được duyệt, nhân viên kinh doanh không cam kết ngày giờ cụ thể trước.'
        ],
        'email_notes': {
            'quoted_summary': 'Giấy A4 70gsm (30 ram).',
            'unquoted_summary': 'Máy photocopy A3 đa năng (1 cái) và Máy chiếu 4K (2 cái) chưa có trong bảng giá hiện hành, đã chuyển phòng Mua hàng.',
            'special_points': 'Yêu cầu cần gấp trong tuần đã chuyển kho và sẽ có xác nhận bằng văn bản.'
        }
    },
    'R05': {
        'customer': 'Anh Quân (quan.vt@example.com)',
        'address': '88 Đường Demo, Quận Thanh Xuân, Hà Nội',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 0,  # Xin giảm 25% toàn đơn -> vượt thẩm quyền, chỉ áp chiết khấu chuẩn 2%
        'status': 'CAN_NGUOI_QUYET',
        'items': [
            ('MAY-IN-LASER-3100', 3, ''),
            ('MUC-HP-78A', 10, ''),
            ('GIAY-A4-80', 40, '')
        ],
        'questions': [],  # Đủ thông tin hàng hóa, không có câu hỏi
        'email_notes': {
            'quoted_summary': 'Máy in laser đen trắng 3100 (3 cái), Mực HP 78A (10 hộp), Giấy A4 80gsm (40 ram).',
            'unquoted_summary': 'Không có.',
            'special_points': 'Đề nghị giảm giá 25% toàn đơn vượt thẩm quyền và vi phạm quy định không giảm giá Thiết bị; đã chuyển lên Ban Giám đốc xem xét và sẽ có phản hồi sau. Báo giá gửi kèm tạm thời áp dụng chiết khấu chuẩn 2% cho nhóm mực và giấy.'
        }
    },
    'R06': {
        'customer': 'Chị Thu - NT Phú Gia (Zalo)',
        'address': '5 Đường Mẫu, Quận 10, TP. Hồ Chí Minh',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 0,
        'status': 'THIEU_THONG_TIN',
        'items': [
            ('GIAY-A4-70', 10, '2 thùng = 10 ram'),
            ('BUT-BI-TL027-XANH', 60, '5 tá = 60 cây'),
            ('BANGKEO-2MAT-24', 18, '3 lốc = 18 cuộn'),
            ('BUT-GEL-05-DEN', 24, '2 hộp = 24 cây')
        ],
        'questions': [
            'Quý khách vui lòng cho biết 1 thùng mực HP 12A có quy cách bao nhiêu hộp (hoặc số lượng hộp mực cụ thể Quý khách cần đặt) để An Phát áp giá chính xác theo bảng giá hiện hành, do bảng quy đổi hiện chưa có đơn vị thùng cho mã hàng này?'
        ],
        'email_notes': {
            'quoted_summary': 'Giấy A4 70gsm (2 thùng = 10 ram), Bút bi xanh TL027 (5 tá = 60 cây), Băng keo 2 mặt 24mm (3 lốc = 18 cuộn), Bút gel đen (2 hộp = 24 cây).',
            'unquoted_summary': 'Mực HP 12A (1 thùng) chưa có quy đổi chuẩn từ thùng sang hộp trong bảng quy đổi nên chưa thể báo giá.',
            'special_points': 'Cần khách cung cấp số hộp mực cụ thể.'
        }
    },
    'R07': {
        'customer': 'Anh Kiên - Bộ phận Kho (kien.kho@example.com)',
        'address': '15 Đường Mẫu, Quận Gò Vấp, TP. Hồ Chí Minh',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 0,
        'status': 'CAN_NGUOI_QUYET',
        'items': [
            ('BUT-BI-TL027-XANH', 50, 'Báo theo bảng giá hiện hành; giá cũ 3.500đ chờ TPKD duyệt'),
            ('SO-CARO-A4-200', 49, ''),
            ('FILE-COC-7P', 100, '')
        ],
        'questions': [],  # Không có câu hỏi
        'email_notes': {
            'quoted_summary': 'Bút bi xanh TL027 (50 cây), Sổ caro A4 200 trang (49 quyển), File còng 7cm (100 cái).',
            'unquoted_summary': 'Không có.',
            'special_points': 'Khách đòi giữ giá cũ 3.500đ/cây cho bút bi TL027; theo quy định công ty báo giá theo bảng giá hiện hành (4.000đ/cây) và đã chuyển Trưởng phòng kinh doanh quyết định, sẽ có xác nhận sau.'
        }
    },
    'R08': {
        'customer': 'Anh/chị Phương - Quản lý xưởng (phuong.xuong@example.com)',
        'address': 'Lô B2, Khu công nghiệp Mẫu, Bắc Ninh',
        'is_inner': False,  # Ngoại tỉnh
        'has_address': True,
        'extra_discount': 0,
        'status': 'CAN_NGUOI_QUYET',
        'items': [
            ('THUNG-CARTON-30X20X20', 300, ''),
            ('MANG-BOC-PE-50CM', 24, ''),
            ('BANGKEO-TRONG-48', 72, '')
        ],
        'questions': [],  # Đủ thông tin hàng hóa, không có câu hỏi
        'email_notes': {
            'quoted_summary': 'Thùng carton 30x20x20 (300 cái), Màng bọc PE 50cm (24 cuộn), Băng keo trong 48mm (72 cuộn).',
            'unquoted_summary': 'Không có.',
            'special_points': 'Địa chỉ giao ngoại tỉnh Bắc Ninh nên phí giao hàng theo thỏa thuận (chờ điều phối báo cước); yêu cầu giao trước 10h sáng thứ Sáu đã chuyển Trưởng kho xem xét và sẽ có văn bản xác nhận.'
        }
    },
    'R09': {
        'customer': 'Chú Sơn (Zalo)',
        'address': 'Chưa cung cấp',
        'is_inner': None,
        'has_address': False,
        'extra_discount': 0,
        'status': 'THIEU_THONG_TIN',
        'items': [],
        'questions': [
            'Chú Sơn vui lòng cung cấp thông tin tên công ty/đơn vị hoặc số điện thoại đã đặt hàng đợt trước để An Phát tra cứu hồ sơ đơn hàng cũ ạ?',
            'Chú vui lòng cung cấp lại danh sách chi tiết các mặt hàng và số lượng đợt trước chú đã đặt để bên cháu nhân đôi số lượng chính xác ạ?',
            'Địa chỉ giao hàng cụ thể cho đợt hàng này ở đâu để An Phát kiểm tra điều kiện và phí vận chuyển ạ?'
        ],
        'email_notes': {
            'quoted_summary': 'Chưa thể báo giá mặt hàng nào do thiếu thông tin đơn hàng cũ.',
            'unquoted_summary': 'Toàn bộ đơn hàng (chưa có danh mục mặt hàng, số lượng và địa chỉ cụ thể).',
            'special_points': 'Cần chú Sơn cung cấp thông tin đơn vị, mặt hàng và địa chỉ giao hàng.'
        }
    },
    'R10': {
        'customer': 'Bạn Ngọc SaoMai (Zalo)',
        'address': '30 Đường Demo, Quận Cầu Giấy, Hà Nội',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 2,  # Xin giảm thêm 2%, tổng chiết khấu = 2% tự động + 2% duyệt = 4% <= 5%, trong thẩm quyền
        'status': 'SAN_SANG',
        'items': [
            ('MUC-HP-78A', 6, '4 hộp + 2 hộp = 6 hộp'),
            ('GIAY-A4-70', 15, '10 ram + 1 thùng (5 ram) = 15 ram'),
            ('MAY-HUY-GIAY-S12', 1, ''),
            ('GHE-XOAY-LUOI-01', 6, ''),
            ('MUC-EPS-664-DEN', 12, '')
        ],
        'questions': [],  # Không có câu hỏi
        'email_notes': {
            'quoted_summary': 'Mực HP 78A (6 hộp), Giấy A4 70gsm (15 ram), Máy hủy giấy 12 tờ (1 cái), Ghế xoay lưới (6 cái), Mực Epson 664 đen (12 chai).',
            'unquoted_summary': 'Không có.',
            'special_points': 'Đã duyệt giảm thêm 2% theo thẩm quyền nhân viên kinh doanh (tổng chiết khấu 4% trên dòng phi thiết bị).'
        }
    },
    'R11': {
        'customer': 'Anh Hùng - Phòng Mua hàng (hung.mua@example.com)',
        'address': '200 Đường Mẫu, Quận Hoàng Mai, Hà Nội',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 0,  # Xin giảm 10% toàn đơn và mua 10 tặng 1 -> vượt thẩm quyền, chỉ áp chiết khấu chuẩn 4%
        'status': 'CAN_NGUOI_QUYET',
        'items': [
            ('MAY-IN-LASER-3100', 6, ''),
            ('MAY-SCAN-A4-100', 2, ''),
            ('CC-VANTAY-01', 4, ''),
            ('GIAY-A4-80', 60, ''),
            ('MUC-CANON-325', 12, '')
        ],
        'questions': [],  # Không có câu hỏi
        'email_notes': {
            'quoted_summary': 'Máy in laser 3100 (6 cái), Máy scan A4 100 (2 cái), Máy chấm công vân tay (4 cái), Giấy A4 80gsm (60 ram), Mực Canon 325 (12 hộp).',
            'unquoted_summary': 'Không có.',
            'special_points': 'Yêu cầu giảm 10% toàn đơn và mua 10 tặng 1 ram giấy vượt thẩm quyền nhân viên kinh doanh; đã chuyển Ban Giám đốc xem xét và sẽ có xác nhận sau. Báo giá gửi kèm áp dụng chiết khấu chuẩn 4% trên dòng phi thiết bị.'
        }
    },
    'R12': {
        'customer': 'Bạn Vy (Vy Sohong - Zalo)',
        'address': '7 Đường Mẫu, Quận Bắc Từ Liêm, Hà Nội',
        'is_inner': True,
        'has_address': True,
        'extra_discount': 0,
        'status': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
        'items': [
            ('GIAY-A4-70', 25, '5 thùng = 25 ram'),
            ('BUT-BI-TL027-XANH', 24, '2 tá = 24 cây'),
            ('DECAL-A4-100', 3, ''),
            ('MANG-BOC-PE-50CM', 2, ''),
            ('KEP-BUOM-32', 4, '')
        ],
        'questions': [
            'Quý khách vui lòng cung cấp đầy đủ thông tin xuất hóa đơn công ty (Tên công ty, Mã số thuế, Địa chỉ trụ sở đăng ký kinh doanh) để bộ phận kế toán kiểm tra và xác nhận?'
        ],
        'email_notes': {
            'quoted_summary': 'Giấy A4 70gsm (5 thùng = 25 ram), Bút bi xanh TL027 (2 tá = 24 cây), Decal A4 (3 xấp), Màng PE 50cm (2 cuộn), Kẹp bướm 32mm (4 hộp).',
            'unquoted_summary': 'Không có.',
            'special_points': 'Thiếu thông tin công ty để xuất hóa đơn; xin công nợ 30 ngày thuộc thẩm quyền Giám đốc duyệt, đã chuyển cấp trên xem xét và sẽ có thông báo xác nhận.'
        }
    }
}


def generate_email_text(req_id, req_data, calc_result):
    """Tạo nội dung email nháp chuyên nghiệp, lịch sự, đúng quy định."""
    customer = req_data['customer']
    meta = req_data['email_notes']
    
    email_lines = [
        f"Kính gửi Quý khách ({customer}),",
        "",
        f"Công ty TNHH An Phát Demo xin trân trọng cảm ơn Quý khách đã gửi yêu cầu báo giá ({req_id}). Chúng tôi xin gửi phản hồi và bản báo giá nháp chi tiết như sau:",
        "",
        "1. Các mặt hàng đã lập báo giá:"
    ]

    if calc_result['lines']:
        for line in calc_result['lines']:
            line_str = f"- {line['ten_hang']} (mã {line['ma_hang']}): {line['so_luong']} {line['dvt']} x {line['don_gia']:,} VNĐ = {line['thanh_tien']:,} VNĐ"
            if line['ghi_chu']:
                line_str += f" ({line['ghi_chu']})"
            email_lines.append(line_str)
        email_lines.append("")
        email_lines.append("Tóm tắt giá trị đơn hàng:")
        email_lines.append(f"- Cộng tiền hàng: {calc_result['total_goods']:,} VNĐ")
        if calc_result['discount_amount'] > 0:
            email_lines.append(f"- Chiết khấu ({calc_result['total_disc_pct']}% trên dòng phi Thiết bị): -{calc_result['discount_amount']:,} VNĐ")
        else:
            email_lines.append(f"- Chiết khấu: 0 VNĐ")
        
        if calc_result['delivery_fee'] is not None:
            email_lines.append(f"- Phí giao hàng: {calc_result['delivery_fee']:,} VNĐ ({calc_result['delivery_note']})")
        else:
            email_lines.append(f"- Phí giao hàng: {calc_result['delivery_note']}")
            
        email_lines.append(f"- Cộng trước VAT: {calc_result['subtotal_before_vat']:,} VNĐ")
        email_lines.append(f"- Thuế VAT ({calc_result['vat_percent']}%): {calc_result['vat_amount']:,} VNĐ")
        email_lines.append(f"- Tổng cộng: {calc_result['grand_total']:,} VNĐ")
    else:
        email_lines.append("- Hiện tại chưa có mặt hàng nào đủ điều kiện để tính giá chi tiết do thiếu thông tin.")

    email_lines.append("")
    email_lines.append("2. Các mặt hàng/nội dung chưa thể báo giá và lý do:")
    email_lines.append(f"{meta['unquoted_summary']}")

    email_lines.append("")
    email_lines.append("3. Về các yêu cầu đặc biệt và thẩm quyền giải quyết:")
    email_lines.append(f"{meta['special_points']}")

    if req_data['questions']:
        email_lines.append("")
        email_lines.append("4. Câu hỏi cần Quý khách làm rõ/bổ sung:")
        for q in req_data['questions']:
            email_lines.append(f"- {q}")

    email_lines.append("")
    email_lines.append("LƯU Ý QUAN TRỌNG VỀ ĐIỀU KIỆN THƯƠNG MẠI:")
    email_lines.append("- Mức thuế VAT 10% trong báo giá được tính theo tham số tạm tính, cần kiểm tra lại với bộ phận kế toán trước khi xuất hóa đơn và thanh toán; đây không phải là khẳng định về thuế suất hiện hành.")
    email_lines.append("- Thời gian giao hàng cụ thể do bộ phận kho xác nhận bằng văn bản sau khi đơn hàng được duyệt; nhân viên kinh doanh không cam kết ngày hoặc giờ giao hàng cụ thể.")
    email_lines.append("- Báo giá có hiệu lực trong vòng 07 ngày kể từ ngày 20/11/2026.")
    email_lines.append("")
    email_lines.append("Trân trọng,")
    email_lines.append("Bộ phận Hỗ trợ Kinh doanh - Công ty TNHH An Phát Demo")
    email_lines.append("Địa chỉ: 10 Đường Mẫu, Quận Demo, Hà Nội | ĐT: 0900 000 000 | Email: baogia@example.com")

    return "\n".join(email_lines)


def generate_questions_text(questions):
    """Tạo nội dung file Rxx-cau-hoi.txt."""
    if not questions:
        return "Không có câu hỏi."
    lines = []
    for idx, q in enumerate(questions, start=1):
        lines.append(f"{idx}. {q}")
    return "\n".join(lines)


def main():
    print("=== BẮT ĐẦU TÍNH BÁO GIÁ VÀ XUẤT FILE CHO 12 YÊU CẦU ===")
    bg_manager = BangGiaManager('bang-gia.xlsx', 'mau-bao-gia.xlsx')
    output_dir = 'dau-ra'
    os.makedirs(output_dir, exist_ok=True)

    summary_table = []
    validation_errors = []

    for req_id, req_data in sorted(ALL_REQUESTS.items()):
        # 1. Tính toán giá trị
        calc_result = tinh_bao_gia(req_data['items'], req_data, bg_manager)

        # 2. Xuất file Excel Rxx-bao-gia.xlsx
        excel_path = os.path.join(output_dir, f"{req_id}-bao-gia.xlsx")
        fill_quote_template(calc_result, req_id, req_data, bg_manager, 'mau-bao-gia.xlsx', excel_path)

        # 3. Xuất file Email Rxx-email.txt
        email_path = os.path.join(output_dir, f"{req_id}-email.txt")
        email_content = generate_email_text(req_id, req_data, calc_result)
        with open(email_path, 'w', encoding='utf-8') as f:
            f.write(email_content)

        # 4. Xuất file Câu hỏi Rxx-cau-hoi.txt
        cauhoi_path = os.path.join(output_dir, f"{req_id}-cau-hoi.txt")
        cauhoi_content = generate_questions_text(req_data['questions'])
        with open(cauhoi_path, 'w', encoding='utf-8') as f:
            f.write(cauhoi_content)

        # 5. Kiểm tra tính chính xác của các phép tính (Validation Check)
        # Check số dòng
        if len(calc_result['lines']) != len(req_data['items']):
            validation_errors.append(f"[{req_id}] Số dòng tính toán ({len(calc_result['lines'])}) != Số dòng đầu vào ({len(req_data['items'])})")

        # Check thành tiền = số lượng x đơn giá
        calculated_sum = 0
        for line in calc_result['lines']:
            if line['thanh_tien'] != line['so_luong'] * line['don_gia']:
                validation_errors.append(f"[{req_id}] Dòng {line['ma_hang']}: thành tiền {line['thanh_tien']} != {line['so_luong']} * {line['don_gia']}")
            calculated_sum += line['thanh_tien']

        if calculated_sum != calc_result['total_goods']:
            validation_errors.append(f"[{req_id}] Tổng cộng tiền hàng không khớp: {calculated_sum} != {calc_result['total_goods']}")

        # Check cộng trước VAT, VAT, tổng cộng
        expected_subtotal = calc_result['total_goods'] - calc_result['discount_amount']
        if calc_result['delivery_fee'] is not None:
            expected_subtotal += calc_result['delivery_fee']
        if expected_subtotal != calc_result['subtotal_before_vat']:
            validation_errors.append(f"[{req_id}] Cộng trước VAT không khớp: {expected_subtotal} != {calc_result['subtotal_before_vat']}")

        expected_vat = round_vnd(calc_result['subtotal_before_vat'] * 0.10)
        if expected_vat != calc_result['vat_amount']:
            validation_errors.append(f"[{req_id}] VAT không khớp: {expected_vat} != {calc_result['vat_amount']}")

        expected_grand = calc_result['subtotal_before_vat'] + calc_result['vat_amount']
        if expected_grand != calc_result['grand_total']:
            validation_errors.append(f"[{req_id}] Tổng cộng không khớp: {expected_grand} != {calc_result['grand_total']}")

        summary_table.append({
            'req_id': req_id,
            'status': req_data['status'],
            'total_goods': calc_result['total_goods'],
            'discount': calc_result['discount_amount'],
            'delivery_fee': calc_result['delivery_fee'],
            'grand_total': calc_result['grand_total']
        })

    print("\n=== KẾT QUẢ KIỂM TRA (VALIDATION) ===")
    if not validation_errors:
        print("TẤT CẢ 12 YÊU CẦU ĐỀU VƯỢT QUA KIỂM TRA TOÁN HỌC & ĐỊNH DẠNG: 100% CHÍNH XÁC!")
    else:
        print(f"CÓ {len(validation_errors)} LỖI:")
        for err in validation_errors:
            print(" -", err)

    print("\n=== BẢNG TÓM TẮT 12 YÊU CẦU BÁO GIÁ ===")
    print(f"{'Mã YC':<8} | {'Trạng thái':<35} | {'Tiền hàng (VNĐ)':<15} | {'Chiết khấu':<12} | {'Phí giao':<10} | {'Tổng cộng (VNĐ)':<15}")
    print("-" * 105)
    for row in summary_table:
        ship_str = f"{row['delivery_fee']:,}" if row['delivery_fee'] is not None else "Thỏa thuận"
        print(f"{row['req_id']:<8} | {row['status']:<35} | {row['total_goods']:<15,} | {row['discount']:<12,} | {ship_str:<10} | {row['grand_total']:<15,}")


if __name__ == '__main__':
    main()
