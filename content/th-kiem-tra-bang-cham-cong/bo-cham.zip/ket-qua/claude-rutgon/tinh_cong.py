#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tính công tháng 09/2026 theo quy_dinh_cong_ty.md.

Đọc: cham_cong.csv, nhan_vien.csv, lich_ca_xoay.csv, nghi_phep.csv (không sửa).
Ghi: bang_cong_ngay.csv, bat_thuong.csv, tong_hop_nguoi.csv, bao_cao.md
Mọi số liệu do chương trình này tính; không có số nhập tay.
"""
import csv
import datetime as dt
import os
from collections import Counter, defaultdict

import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")  # console Windows mặc định cp1252

BASE = os.path.dirname(os.path.abspath(__file__))


def P(name):
    return os.path.join(BASE, name)


# ---------------------------------------------------------------- tham số (quy_dinh_cong_ty.md mục 2, 4)
KY_TU, KY_DEN = dt.date(2026, 9, 1), dt.date(2026, 9, 30)
NGAY_LE = {dt.date(2026, 9, 1), dt.date(2026, 9, 2)}
CA = {"HC": (8 * 60, 17 * 60), "S": (6 * 60, 14 * 60), "C": (14 * 60, 22 * 60)}  # phút từ 00:00
NGHI_TRUA = (12 * 60, 13 * 60)  # chỉ trừ cho ca HC
DUNG_SAI = 5            # trễ/sớm <= 5 phút vẫn đủ
TRUNG_PHUT = 3          # cùng máy cách <= 3 phút: quẹt trùng
QUET_HO_PHUT = 10       # hai máy khác nhau cách <= 10 phút
OT_TOI_THIEU = 30       # ra muộn >= 30 phút mới tính OT
OT_NGAY_MAX = 180       # > 180 phút: cảnh báo
OT_THANG_MAX = 2400     # > 2400 phút/tháng: cảnh báo
DON_LE_PHUT = 120       # quẹt đơn lẻ: ± 120 phút quanh giờ vào/ra
FMT_MAY = {"MAY-A1": "%Y-%m-%d %H:%M:%S", "MAY-B1": "%d/%m/%Y %H:%M"}
KHONG_CAN_QUYET = {"QUET_TRUNG", "DI_TRE", "VE_SOM"}
LOAI_BT = ["THIEU_RA", "THIEU_VAO", "THIEU_KHONG_RO", "QUET_TRUNG", "DI_TRE", "VE_SOM", "OT_VUOT_NGUONG",
           "OT_THANG_VUOT", "VANG_CHUA_GHI", "LAM_NGAY_LE", "LAM_NGAY_NGHI", "NGHI_QUET_HO",
           "CO_PHEP_NHUNG_QUET", "DU_LIEU_LOI"]


def hhmm(m):
    return "%02d:%02d" % (m // 60, m % 60)


def doc_csv(name):
    with open(P(name), encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def ngay_vn(s):
    return dt.datetime.strptime(s.strip(), "%d/%m/%Y").date()


# ---------------------------------------------------------------- bất thường
bat_thuong = {}  # (ma_nv, ngay_str, loai) -> {"chi_tiet": [..], "giai_thich": str}


def them_bt(nv, ngay, loai, chi_tiet, giai_thich):
    ngay_s = ngay.isoformat() if isinstance(ngay, dt.date) else (ngay or "")
    k = (nv, ngay_s, loai)
    if k in bat_thuong:
        bat_thuong[k]["chi_tiet"].append(chi_tiet)
    else:
        bat_thuong[k] = {"chi_tiet": [chi_tiet], "giai_thich": giai_thich}


# ---------------------------------------------------------------- đọc dữ liệu
nhan_vien = doc_csv("nhan_vien.csv")
NV = {r["ma_nv"].strip(): r for r in nhan_vien}
lich = {}
for r in doc_csv("lich_ca_xoay.csv"):
    try:
        lich[(r["ma_nv"].strip(), ngay_vn(r["ngay"]))] = r["ca"].strip()
    except ValueError:
        them_bt(r["ma_nv"].strip(), "", "DU_LIEU_LOI", "lich_ca_xoay.csv: ngày không hợp lệ '%s'" % r["ngay"],
                "Một dòng lịch ca xoay có ngày không hợp lệ nên không dùng được. Nên kiểm lại tệp lịch ca.")

nghi_phep = {}  # (ma_nv, ngay) -> loai phép
for r in doc_csv("nghi_phep.csv"):
    if r["trang_thai"].strip() != "Đã duyệt":
        continue
    try:
        d1, d2 = ngay_vn(r["tu_ngay"]), ngay_vn(r["den_ngay"])
    except ValueError:
        them_bt(r["ma_nv"].strip(), "", "DU_LIEU_LOI", "nghi_phep.csv: ngày không hợp lệ", "Một đơn nghỉ có ngày không hợp lệ nên không dùng được. Nên kiểm lại đơn.")
        continue
    d = d1
    while d <= d2:
        nghi_phep[(r["ma_nv"].strip(), d)] = r["loai"].strip()
        d += dt.timedelta(days=1)

# cham_cong: phân tích từng dòng, lỗi -> DU_LIEU_LOI, không đưa vào tính toán
quet = defaultdict(list)  # (ma_nv, ngay) -> [(datetime, ma_may)]
so_dong_cc = 0
so_dong_loi = 0
quet_khac_chi_nhanh = []  # (ma_nv, ngay, ma_may) để đưa vào báo cáo (không phải bất thường theo quy định)
with open(P("cham_cong.csv"), encoding="utf-8-sig", newline="") as f:
    for so_dong, r in enumerate(csv.DictReader(f), start=2):  # dòng 1 là tiêu đề
        so_dong_cc += 1
        may, nv, tg = r["ma_may"].strip(), r["ma_nv"].strip(), r["thoi_gian"].strip()
        t = None
        if may not in FMT_MAY:
            loi = "mã máy '%s' không nằm trong quy định" % may
        elif not tg:
            loi = "không có thời gian"
        else:
            try:
                t = dt.datetime.strptime(tg, FMT_MAY[may])
                loi = None
            except ValueError:
                loi = "thời gian '%s' không phải ngày giờ hợp lệ theo định dạng của %s" % (tg, may)
        if t is not None and not (KY_TU <= t.date() <= KY_DEN):
            loi = "thời gian %s nằm ngoài kỳ 09/2026" % tg
        if loi is None and nv not in NV:
            loi = "mã %s không có trong nhan_vien.csv" % nv
        if loi:
            so_dong_loi += 1
            ngay = t.date() if (t is not None and KY_TU <= t.date() <= KY_DEN) else ""
            them_bt(nv, ngay, "DU_LIEU_LOI", "cham_cong.csv dòng %d (%s, %s): %s" % (so_dong, may, nv, loi),
                    "Dòng chấm công này không dùng được nên chương trình bỏ qua, không tính vào ngày nào. "
                    "Nên đối chiếu với bản ghi gốc của máy chấm công để xác định đây là quẹt thật hay lỗi xuất dữ liệu.")
            continue
        quet[(nv, t.date())].append((t, may))
        if may[-2] != NV[nv]["chi_nhanh"]:
            quet_khac_chi_nhanh.append((nv, t.date(), may))


def phut(t):
    return t.hour * 60 + t.minute  # bỏ giây


# ---------------------------------------------------------------- tính từng ngày
ngay_ky = [KY_TU + dt.timedelta(days=i) for i in range((KY_DEN - KY_TU).days + 1)]
rows_ngay = []
so_quet_trung_bo = 0
ngay_quet_thua = []  # ngày còn >2 quẹt sau khi bỏ trùng, quẹt giữa nằm ngoài khoảng nghỉ trưa (chỉ để báo cáo)
ngay_kep_3_quet_hc = 0


def loai_ngay(nv, d):
    if d in NGAY_LE:
        return "LE"
    if NV[nv]["loai_ca"].strip() == "HC":
        return "HC" if d.weekday() < 5 else "OFF"
    return lich.get((nv, d))  # S, C, OFF hoặc None nếu thiếu lịch


for r_nv in nhan_vien:
    nv = r_nv["ma_nv"].strip()
    for d in ngay_ky:
        lt = loai_ngay(nv, d)
        row = {"ma_nv": nv, "ngay": d.isoformat(), "loai_ngay": lt or "", "gio_vao": "", "gio_ra": "", "gio_cong": "",
               "phut_tre": "", "phut_ve_som": "", "ot_phut": "", "trang_thai": "", "_work": None, "_ot": 0}
        raw = sorted(quet.get((nv, d), []))
        # 1) bỏ quẹt trùng: cùng máy, cách quẹt đã giữ <= 3 phút
        kept, last = [], {}
        for t, may in raw:
            if may in last and phut(t) - phut(last[may]) <= TRUNG_PHUT:
                so_quet_trung_bo += 1
                them_bt(nv, d, "QUET_TRUNG",
                        "%s: quẹt %s bị bỏ (cách quẹt %s %d phút)" % (may, t.strftime("%H:%M:%S"), last[may].strftime("%H:%M:%S"),
                                                                     phut(t) - phut(last[may])),
                        "Máy ghi hai lần quẹt sát nhau; chương trình giữ quẹt đầu, bỏ quẹt sau, không ảnh hưởng giờ công. Không cần quản lý xử lý.")
                continue
            kept.append((t, may))
            last[may] = t
        n = len(kept)
        # 2) nghi quẹt hộ: hai quẹt ở hai máy khác nhau cách <= 10 phút
        trong_cap = set()
        for i in range(n):
            for j in range(i + 1, n):
                if kept[i][1] != kept[j][1] and abs(phut(kept[j][0]) - phut(kept[i][0])) <= QUET_HO_PHUT:
                    trong_cap.update((i, j))
                    them_bt(nv, d, "NGHI_QUET_HO",
                            "%s %s và %s %s, cách %d phút. CẦN NGƯỜI QUYẾT" % (kept[i][1], hhmm(phut(kept[i][0])), kept[j][1],
                                                                              hhmm(phut(kept[j][0])), abs(phut(kept[j][0]) - phut(kept[i][0]))),
                            "Hai quẹt của %s ở hai máy khác nhau trong vòng 10 phút; đây chỉ là dấu hiệu theo quy tắc, chưa kết luận gì. "
                            "Đề nghị người có thẩm quyền xác minh với %s và kiểm bản ghi hai máy; ngày này chưa tính giờ." % (nv, nv))
        co_cho = bool(trong_cap)
        phep = nghi_phep.get((nv, d))

        if lt is None:
            row["trang_thai"] = "CHO_XAC_NHAN"
            them_bt(nv, d, "DU_LIEU_LOI", "lich_ca_xoay.csv không có dòng cho %s ngày %s. CẦN NGƯỜI QUYẾT" % (nv, d.isoformat()),
                    "Không có lịch ca xoay cho ngày này nên không biết ca nào; ngày chưa tính. Nên bổ sung lịch ca.")
        elif lt in ("OFF", "LE"):
            if n == 0:
                row["trang_thai"] = "NGHI"
            else:
                row["trang_thai"] = "CHO_XAC_NHAN"
                if n >= 2:
                    row["gio_vao"], row["gio_ra"] = hhmm(phut(kept[0][0])), hhmm(phut(kept[-1][0]))
                dsq = ", ".join("%s %s" % (m, hhmm(phut(t))) for t, m in kept)
                if lt == "LE":
                    them_bt(nv, d, "LAM_NGAY_LE", "ngày lễ công ty khai báo nhưng có %d quẹt: %s. CẦN NGƯỜI QUYẾT" % (n, dsq),
                            "Có quẹt vào ngày lễ công ty đã khai báo. Cần xác nhận %s có được phân công làm hay không; cách tính ngày lễ cần kiểm với "
                            "văn bản hiện hành hoặc chuyên gia nhân sự." % nv)
                else:
                    them_bt(nv, d, "LAM_NGAY_NGHI", "ngày nghỉ theo lịch (OFF) nhưng có %d quẹt: %s. CẦN NGƯỜI QUYẾT" % (n, dsq),
                            "Có quẹt vào ngày nghỉ theo lịch. Cần xác nhận %s có được phân công hoặc đổi ca không; cách tính cần kiểm với "
                            "văn bản hiện hành hoặc chuyên gia nhân sự." % nv)
        else:  # ngày làm việc HC / S / C
            si, so_ = CA[lt]
            if n == 0:
                if phep:
                    row["trang_thai"] = "PHEP"
                else:
                    row["trang_thai"] = "CHO_XAC_NHAN"
                    them_bt(nv, d, "VANG_CHUA_GHI", "ngày làm việc theo lịch (ca %s) nhưng không có quẹt và không có đơn nghỉ đã duyệt. CẦN NGƯỜI QUYẾT" % lt,
                            "Ngày có lịch làm việc nhưng không có quẹt và không có đơn nghỉ đã duyệt. Nên hỏi %s hoặc quản lý trực tiếp "
                            "về ngày này; chưa tính công." % nv)
            elif phep:
                row["trang_thai"] = "CHO_XAC_NHAN"
                if n >= 2:
                    row["gio_vao"], row["gio_ra"] = hhmm(phut(kept[0][0])), hhmm(phut(kept[-1][0]))
                them_bt(nv, d, "CO_PHEP_NHUNG_QUET",
                        "có đơn '%s' đã duyệt nhưng ngày này có %d quẹt: %s. CẦN NGƯỜI QUYẾT" % (
                            phep, n, ", ".join("%s %s" % (m, hhmm(phut(t))) for t, m in kept)),
                        "Có đơn nghỉ đã duyệt nhưng ngày này vẫn có quẹt. Cần xác nhận %s thực tế nghỉ hay đi làm; chưa tính công. "
                        "Cách tính phép cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự." % nv)
            elif n == 1:
                row["trang_thai"] = "CHO_XAC_NHAN"
                t, may = kept[0]
                m = phut(t)
                la_vao, la_ra = m <= si + DON_LE_PHUT, m >= so_ - DON_LE_PHUT
                mo_ta = "chỉ có 1 quẹt (%s lúc %s), ca %s %s-%s" % (may, hhmm(m), lt, hhmm(si), hhmm(so_))
                if la_vao and not la_ra:
                    row["gio_vao"] = hhmm(m)
                    them_bt(nv, d, "THIEU_RA", mo_ta + ": quẹt <= giờ vào + 120 phút nên coi là quẹt vào, thiếu quẹt ra",
                            "Ngày này chỉ có một quẹt (quẹt vào), không thấy quẹt ra. Nên hỏi %s hoặc quản lý ca giờ ra thực tế và kiểm bản ghi máy; chưa tính giờ." % nv)
                elif la_ra and not la_vao:
                    row["gio_ra"] = hhmm(m)
                    them_bt(nv, d, "THIEU_VAO", mo_ta + ": quẹt >= giờ ra - 120 phút nên coi là quẹt ra, thiếu quẹt vào",
                            "Ngày này chỉ có một quẹt (quẹt ra), không thấy quẹt vào. Nên hỏi %s hoặc quản lý ca giờ vào thực tế và kiểm bản ghi máy; chưa tính giờ." % nv)
                else:
                    them_bt(nv, d, "THIEU_KHONG_RO", mo_ta + ": nằm giữa ca, không xác định là quẹt vào hay ra. CẦN NGƯỜI QUYẾT",
                            "Ngày này chỉ có một quẹt nằm giữa ca nên không biết là quẹt vào hay quẹt ra. Cần xác minh với %s hoặc quản lý ca; chưa tính giờ." % nv)
            else:  # n >= 2
                if n > 2 and not co_cho:
                    giua = [t for t, _ in kept[1:-1]]
                    if lt == "HC" and all(NGHI_TRUA[0] - 60 <= phut(t) <= NGHI_TRUA[1] + 60 for t in giua) and n == 4:
                        pass  # mẫu bình thường: 2 quẹt nghỉ trưa
                    else:
                        ngay_quet_thua.append((nv, d, ", ".join("%s %s" % (m, hhmm(phut(t))) for t, m in kept)))
                vao, ra = phut(kept[0][0]), phut(kept[-1][0])
                if co_cho:
                    row["trang_thai"] = "CHO_XAC_NHAN"
                    if 0 not in trong_cap:
                        row["gio_vao"] = hhmm(vao)
                    if (n - 1) not in trong_cap:
                        row["gio_ra"] = hhmm(ra)
                else:
                    tre = vao - si
                    som = so_ - ra
                    ot = ra - so_
                    row["trang_thai"] = "OK"
                    row["gio_vao"], row["gio_ra"] = hhmm(vao), hhmm(ra)
                    row["phut_tre"] = tre if tre > DUNG_SAI else 0
                    row["phut_ve_som"] = som if som > DUNG_SAI else 0
                    row["ot_phut"] = ot if ot >= OT_TOI_THIEU else 0
                    eff_in = vao if tre > DUNG_SAI else si
                    eff_out = ra if som > DUNG_SAI else so_
                    w = eff_out - eff_in
                    if lt == "HC":
                        w -= max(0, min(eff_out, NGHI_TRUA[1]) - max(eff_in, NGHI_TRUA[0]))
                    row["_work"] = max(0, w)
                    row["gio_cong"] = "%.2f" % (row["_work"] / 60.0)
                    row["_ot"] = row["ot_phut"]
                    if row["phut_tre"]:
                        them_bt(nv, d, "DI_TRE", "vào %s, ca %s bắt đầu %s, trễ %d phút" % (hhmm(vao), lt, hhmm(si), tre),
                                "Quẹt vào muộn hơn giờ ca quá dung sai 5 phút; số phút trễ đã được ghi vào bảng công. Không cần quản lý quyết.")
                    if row["phut_ve_som"]:
                        them_bt(nv, d, "VE_SOM", "ra %s, ca %s kết thúc %s, sớm %d phút" % (hhmm(ra), lt, hhmm(so_), som),
                                "Quẹt ra sớm hơn giờ kết thúc ca quá dung sai 5 phút; số phút về sớm đã được ghi vào bảng công. Không cần quản lý quyết.")
                    if row["ot_phut"] > OT_NGAY_MAX:
                        them_bt(nv, d, "OT_VUOT_NGUONG",
                                "ra %s, làm thêm %d phút (%.2f giờ) > ngưỡng %d phút" % (hhmm(ra), ot, ot / 60.0, OT_NGAY_MAX),
                                "Làm thêm trong ngày vượt ngưỡng công ty đặt ra. Nên kiểm việc làm thêm này có được duyệt không; "
                                "cách tính cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.")
        rows_ngay.append(row)

# OT_THANG_VUOT: tổng OT của các ngày làm việc thường đã tính (trang_thai OK)
ot_thang = defaultdict(int)
for r in rows_ngay:
    ot_thang[r["ma_nv"]] += r["_ot"]
for nv, tong in ot_thang.items():
    if tong > OT_THANG_MAX:
        them_bt(nv, "THANG", "OT_THANG_VUOT", "tổng làm thêm ngày thường %d phút (%.2f giờ) > ngưỡng %d phút" % (tong, tong / 60.0, OT_THANG_MAX),
                "Tổng giờ làm thêm trong tháng vượt ngưỡng công ty đặt ra. Nên kiểm các ngày làm thêm có được duyệt không; "
                "cách tính cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.")

# ---------------------------------------------------------------- ghi CSV
CSV_OPT = dict(lineterminator="\n")
COT_NGAY = ["ma_nv", "ngay", "loai_ngay", "gio_vao", "gio_ra", "gio_cong", "phut_tre", "phut_ve_som", "ot_phut", "trang_thai"]
with open(P("bang_cong_ngay.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=COT_NGAY, extrasaction="ignore", **CSV_OPT)
    w.writeheader()
    w.writerows(rows_ngay)


def khoa_sap(k):
    nv, ngay, loai = k
    return (nv, ngay == "", ngay == "THANG", ngay, LOAI_BT.index(loai))


bt_rows = []
for k in sorted(bat_thuong, key=khoa_sap):
    nv, ngay, loai = k
    v = bat_thuong[k]
    bt_rows.append({"ma_nv": nv, "ngay": ngay, "loai": loai, "chi_tiet": "; ".join(v["chi_tiet"]),
                    "can_nguoi_quyet": "KHONG" if loai in KHONG_CAN_QUYET else "CO", "giai_thich": v["giai_thich"]})
with open(P("bat_thuong.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["ma_nv", "ngay", "loai", "chi_tiet", "can_nguoi_quyet", "giai_thich"], **CSV_OPT)
    w.writeheader()
    w.writerows(bt_rows)

bt_theo_nv = Counter(r["ma_nv"] for r in bt_rows)
tong_rows = []
for r_nv in nhan_vien:
    nv = r_nv["ma_nv"].strip()
    rs = [r for r in rows_ngay if r["ma_nv"] == nv]
    ok = [r for r in rs if r["trang_thai"] == "OK"]
    tong_rows.append({
        "ma_nv": nv,
        "ngay_cong": len(ok),
        "tong_gio_cong": "%.2f" % (sum(r["_work"] for r in ok) / 60.0),
        "so_lan_tre": sum(1 for r in ok if r["phut_tre"]),
        "tong_phut_tre": sum(r["phut_tre"] for r in ok),
        "so_lan_ve_som": sum(1 for r in ok if r["phut_ve_som"]),
        "tong_phut_ve_som": sum(r["phut_ve_som"] for r in ok),
        "tong_ot_gio": "%.2f" % (sum(r["_ot"] for r in ok) / 60.0),
        "so_ngay_phep": sum(1 for r in rs if r["trang_thai"] == "PHEP"),
        "so_ngay_vang_chua_ghi": sum(1 for k in bat_thuong if k[0] == nv and k[2] == "VANG_CHUA_GHI"),
        "so_ngay_cho_xac_nhan": sum(1 for r in rs if r["trang_thai"] == "CHO_XAC_NHAN"),
        "so_bat_thuong": bt_theo_nv.get(nv, 0),
    })
COT_TONG = ["ma_nv", "ngay_cong", "tong_gio_cong", "so_lan_tre", "tong_phut_tre", "so_lan_ve_som", "tong_phut_ve_som", "tong_ot_gio",
            "so_ngay_phep", "so_ngay_vang_chua_ghi", "so_ngay_cho_xac_nhan", "so_bat_thuong"]
with open(P("tong_hop_nguoi.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=COT_TONG, **CSV_OPT)
    w.writeheader()
    w.writerows(tong_rows)

# ---------------------------------------------------------------- bao_cao.md (số liệu lấy từ kết quả vừa tính)
dem_loai = Counter(r["loai"] for r in bt_rows)
dem_tt = Counter(r["trang_thai"] for r in rows_ngay)
tong_gio = sum(r["_work"] for r in rows_ngay if r["trang_thai"] == "OK") / 60.0
tong_ot = sum(r["_ot"] for r in rows_ngay) / 60.0


def ds_ngay(loai, toi_da=14):
    muc = []
    for r in bt_rows:
        if r["loai"] == loai:
            ng = r["ngay"]
            muc.append("%s %s" % (r["ma_nv"], ("%s/%s" % (ng[8:10], ng[5:7])) if len(ng) == 10 else (ng or "không rõ ngày")))
    s = ", ".join(muc[:toi_da])
    return s + (", … (còn %d, xem bat_thuong.csv)" % (len(muc) - toi_da) if len(muc) > toi_da else "")


NHOM_CO = [
    ("Thiếu quẹt (THIEU_RA / THIEU_VAO / THIEU_KHONG_RO)", ["THIEU_RA", "THIEU_VAO", "THIEU_KHONG_RO"]),
    ("Vắng chưa ghi (VANG_CHUA_GHI)", ["VANG_CHUA_GHI"]),
    ("Làm ngày lễ / ngày nghỉ (LAM_NGAY_LE, LAM_NGAY_NGHI)", ["LAM_NGAY_LE", "LAM_NGAY_NGHI"]),
    ("Nghi quẹt hộ (NGHI_QUET_HO)", ["NGHI_QUET_HO"]),
    ("Có phép nhưng có quẹt (CO_PHEP_NHUNG_QUET)", ["CO_PHEP_NHUNG_QUET"]),
    ("Làm thêm vượt ngưỡng (OT_VUOT_NGUONG, OT_THANG_VUOT)", ["OT_VUOT_NGUONG", "OT_THANG_VUOT"]),
    ("Dữ liệu lỗi (DU_LIEU_LOI)", ["DU_LIEU_LOI"]),
]
L = []
L.append("# Báo cáo kiểm tra chấm công 09/2026")
L.append("_Do `tinh_cong.py` sinh từ dữ liệu. Quản lý xác nhận; chương trình không quyết lương hay kỷ luật._")
L.append("")
L.append("## 1. Số liệu tóm tắt")
L.append("- %d nhân viên × %d ngày = %d dòng công: OK %d, PHEP %d, NGHI %d, CHO_XAC_NHAN %d. Giờ công (ngày OK) %.2f giờ; làm thêm %.2f giờ."
         % (len(nhan_vien), len(ngay_ky), len(rows_ngay), dem_tt["OK"], dem_tt["PHEP"], dem_tt["NGHI"], dem_tt["CHO_XAC_NHAN"], tong_gio, tong_ot))
L.append("- Đọc %d dòng quẹt: %d dòng lỗi bị bỏ, %d quẹt trùng bị bỏ." % (so_dong_cc, so_dong_loi, so_quet_trung_bo))
L.append("- Bất thường %d dòng: %s. Chỉ ghi nhận, không cần người quyết: QUET_TRUNG, DI_TRE, VE_SOM."
         % (len(bt_rows), "; ".join("%s %d" % (k, dem_loai[k]) for k in LOAI_BT if dem_loai[k])))
L.append("")
L.append("## 2. Việc quản lý cần xác nhận (chi tiết: bat_thuong.csv; ngày CHO_XAC_NHAN chưa tính giờ)")
for ten, cac_loai in NHOM_CO:
    so = sum(dem_loai[k] for k in cac_loai)
    if so:
        ds = "; ".join(("%s: %s" % (k, ds_ngay(k))) if len(cac_loai) > 1 else ds_ngay(k) for k in cac_loai if dem_loai[k])
        L.append("- **%s** (%d): %s" % (ten, so, ds))
L.append("- Giờ làm thêm, ngày lễ, nghỉ phép: cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự.")
L.append("")
L.append("## 3. Giả định đã dùng (mục 5 quy định chưa viết chi tiết)")
L.append("- Giờ công = thời gian nằm trong khung ca (sớm trước giờ vào hoặc muộn sau giờ ra không cộng); ca HC trừ phần giao với 12:00-13:00, ca S/C không trừ. Làm thêm ghi riêng (ot_phut), không cộng vào gio_cong.")
L.append("- Trễ/sớm ≤ 5 phút: tính đủ, ghi 0. Từ 6 phút: ghi toàn bộ số phút lệch so với giờ ca, giờ công tính từ giờ quẹt thực.")
L.append("- Từ 2 quẹt (sau khi bỏ trùng): quẹt đầu = vào, quẹt cuối = ra, quẹt giữa (gồm quẹt nghỉ trưa ca HC) bỏ qua. Quẹt trùng so với quẹt cùng máy đã giữ gần nhất, so theo phút.")
L.append("- Ngày CHO_XAC_NHAN để trống giờ công, trễ, sớm, làm thêm; gio_vao/gio_ra chỉ điền khi xác định rõ. Ngày lễ ghi LE kể cả khi lịch xoay có ca. Ngày OFF/LE không quẹt = NGHI.")
L.append("- Làm thêm tháng chỉ cộng ngày OK. Nghỉ không lương cũng ghi PHEP. so_ngay_phep chỉ đếm ngày làm việc (ngày OFF/LE trong kỳ nghỉ = NGHI).")
L.append("")
L.append("## 4. Điều chưa chắc")
if quet_khac_chi_nhanh:
    L.append("- %d quẹt ở máy khác chi nhánh (%s). Quy định không coi là bất thường; chỉ cặp cách ≤ 10 phút bị gắn NGHI_QUET_HO."
             % (len(quet_khac_chi_nhanh), ", ".join("%s %s/%s" % (nv, d.strftime("%d"), d.strftime("%m")) for nv, d, _ in quet_khac_chi_nhanh)))
if ngay_quet_thua:
    L.append("- Ngày có quẹt giữa ca không phải quẹt trùng và không phải quẹt nghỉ trưa: %s. Đã bỏ qua khi tính giờ, quy định không có mã riêng nên không gắn cờ. CẦN NGƯỜI QUYẾT có xem lại không."
             % ", ".join("%s %s/%s" % (nv, d.strftime("%d"), d.strftime("%m")) for nv, d, _ in ngay_quet_thua))
L.append("- Dòng DU_LIEU_LOI bị bỏ có thể thuộc ngày nào đó của nhân viên nêu trong dòng; chương trình không đoán. Cách tính ở mục 3 là diễn giải của tôi, CẦN NGƯỜI QUYẾT xác nhận.")
L.append("- CSV là UTF-8 không BOM; mở bằng Excel cần chọn nhập UTF-8 để đúng tiếng Việt.")
with open(P("bao_cao.md"), "w", encoding="utf-8", newline="") as f:
    f.write("\n".join(L) + "\n")

# ---------------------------------------------------------------- in tóm tắt
print("Số dòng (không tính tiêu đề): bang_cong_ngay.csv=%d, bat_thuong.csv=%d, tong_hop_nguoi.csv=%d"
      % (len(rows_ngay), len(bt_rows), len(tong_rows)))
print("Số bất thường theo loại:")
for k in LOAI_BT:
    print("  %-20s %d" % (k, dem_loai[k]))
print("  %-20s %d" % ("TỔNG", len(bt_rows)))
