#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Chương trình tính công và phát hiện bất thường tháng 09/2026.
Tạo 3 tệp kết quả:
  1. bang_cong_ngay.csv
  2. bat_thuong.csv
  3. tong_hop_nguoi.csv
"""

import pandas as pd
import datetime

def main():
    # 1. Đọc dữ liệu đầu vào
    nv_df = pd.read_csv('nhan_vien.csv')
    np_df = pd.read_csv('nghi_phep.csv')
    lc_df = pd.read_csv('lich_ca_xoay.csv')
    cc_df = pd.read_csv('cham_cong.csv')

    employees = nv_df['ma_nv'].tolist()
    emp_branch = dict(zip(nv_df['ma_nv'], nv_df['chi_nhanh']))
    emp_type = dict(zip(nv_df['ma_nv'], nv_df['loai_ca']))

    # Ánh xạ lịch ca xoay
    lc_df['date_str'] = pd.to_datetime(lc_df['ngay'], format='%d/%m/%Y').dt.strftime('%Y-%m-%d')
    shift_map = {(r['ma_nv'], r['date_str']): r['ca'] for _, r in lc_df.iterrows()}

    # Ánh xạ đơn nghỉ phép đã duyệt
    leave_map = {}
    for _, r in np_df.iterrows():
        m_nv = r['ma_nv']
        start = pd.to_datetime(r['tu_ngay'], format='%d/%m/%Y')
        end = pd.to_datetime(r['den_ngay'], format='%d/%m/%Y')
        curr = start
        while curr <= end:
            d_str = curr.strftime('%Y-%m-%d')
            leave_map[(m_nv, d_str)] = r['loai']
            curr += datetime.timedelta(days=1)

    # Định nghĩa ca làm việc
    SHIFT_HOURS = {
        'HC': ('08:00', '17:00', 480),
        'S': ('06:00', '14:00', 480),
        'C': ('14:00', '22:00', 480),
    }

    anomalies = []

    def parse_time_str(val):
        if pd.isna(val) or str(val).strip() in ['', 'nan']:
            return None
        s = str(val).strip()
        for fmt in ['%Y-%m-%d %H:%M:%S', '%d/%m/%Y %H:%M', '%d/%m/%Y %H:%M:%S', '%Y-%m-%d %H:%M']:
            try:
                return datetime.datetime.strptime(s, fmt)
            except ValueError:
                pass
        return None

    valid_swipes = []
    for idx, r in cc_df.iterrows():
        m_may = r['ma_may']
        m_nv = r['ma_nv']
        raw_time = r['thoi_gian']
        
        # Kiểm tra mã nhân viên có trong danh sách
        if m_nv not in employees:
            dt = parse_time_str(raw_time)
            d_str = dt.strftime('%Y-%m-%d') if dt else ''
            anomalies.append({
                'ma_nv': m_nv,
                'ngay': d_str,
                'loai': 'DU_LIEU_LOI',
                'chi_tiet': f"Mã nhân viên {m_nv} không có trong danh sách nhân viên công ty; quẹt thẻ tại máy {m_may} lúc {raw_time}",
                'can_nguoi_quyet': 'CO',
                'giai_thich': f"Dữ liệu chấm công xuất hiện mã {m_nv} không thuộc danh sách nhân sự; cần kiểm tra lại thẻ hoặc cập nhật hồ sơ nhân sự mới/nghỉ việc."
            })
            continue
            
        dt = parse_time_str(raw_time)
        if dt is None:
            anomalies.append({
                'ma_nv': m_nv,
                'ngay': '',
                'loai': 'DU_LIEU_LOI',
                'chi_tiet': f"Dữ liệu thời gian bị lỗi hoặc để trống: '{raw_time}' tại máy {m_may}",
                'can_nguoi_quyet': 'CO',
                'giai_thich': f"Bản ghi chấm công của nhân viên {m_nv} bị thiếu hoặc sai định dạng thời gian; cần bộ phận kỹ thuật kiểm tra nhật ký máy {m_may}."
            })
            continue
            
        # Bỏ phần giây của giờ quẹt theo quy định
        dt_min = dt.replace(second=0, microsecond=0)
        valid_swipes.append({
            'ma_may': m_may,
            'ma_nv': m_nv,
            'raw_time': raw_time,
            'dt': dt,
            'dt_min': dt_min,
            'date': dt_min.strftime('%Y-%m-%d'),
            'time': dt_min.strftime('%H:%M')
        })

    # Gom nhóm quẹt theo (ma_nv, date)
    swipes_by_emp_date = {}
    for s in valid_swipes:
        key = (s['ma_nv'], s['date'])
        swipes_by_emp_date.setdefault(key, []).append(s)

    def diff_minutes(t_later, t_earlier):
        dt_later = datetime.datetime.strptime(t_later, '%H:%M')
        dt_earlier = datetime.datetime.strptime(t_earlier, '%H:%M')
        return int((dt_later - dt_earlier).total_seconds() / 60)

    all_dates = [f'2026-09-{d:02d}' for d in range(1, 31)]
    bang_cong_rows = []
    emp_monthly_ot = {emp: 0 for emp in employees}

    for m_nv in employees:
        e_type = emp_type[m_nv]
        
        for d_str in all_dates:
            dt_obj = datetime.datetime.strptime(d_str, '%Y-%m-%d')
            
            # Xác định loại ngày
            if d_str in ['2026-09-01', '2026-09-02']:
                loai_ngay = 'LE'
            elif e_type == 'HC':
                loai_ngay = 'OFF' if dt_obj.weekday() >= 5 else 'HC'
            else: # XOAY
                loai_ngay = shift_map.get((m_nv, d_str), 'OFF')
                
            raw_day_swipes = swipes_by_emp_date.get((m_nv, d_str), [])
            raw_day_swipes.sort(key=lambda x: x['dt_min'])
            
            # 1. Kiểm tra nghi quẹt hộ: hai quẹt ở hai máy khác nhau cách nhau <= 10 phút trong cùng ngày
            nghi_quet_ho_detected = False
            nghi_quet_ho_detail = ""
            for i in range(len(raw_day_swipes)):
                for j in range(i + 1, len(raw_day_swipes)):
                    s1 = raw_day_swipes[i]
                    s2 = raw_day_swipes[j]
                    if s1['ma_may'] != s2['ma_may']:
                        gap = abs(int((s2['dt_min'] - s1['dt_min']).total_seconds() / 60))
                        if gap <= 10:
                            nghi_quet_ho_detected = True
                            nghi_quet_ho_detail = f"quẹt tại {s1['ma_may']} lúc {s1['time']} và {s2['ma_may']} lúc {s2['time']}, cách nhau {gap} phút"
                            break
                if nghi_quet_ho_detected:
                    break
                    
            if nghi_quet_ho_detected:
                anomalies.append({
                    'ma_nv': m_nv,
                    'ngay': d_str,
                    'loai': 'NGHI_QUET_HO',
                    'chi_tiet': nghi_quet_ho_detail,
                    'can_nguoi_quyet': 'CO',
                    'giai_thich': f"Phát hiện 2 lần quẹt thẻ ở 2 chi nhánh khác nhau trong vòng 10 phút của {m_nv}; đề nghị người có thẩm quyền xác minh lịch trình hoặc camera."
                })
                
            # 2. Kiểm tra quẹt trùng: hai quẹt cùng máy cách nhau <= 3 phút (giữ đầu, bỏ sau)
            filtered_swipes = []
            quet_trung_details = []
            for s in raw_day_swipes:
                if not filtered_swipes:
                    filtered_swipes.append(s)
                else:
                    last_s = filtered_swipes[-1]
                    if s['ma_may'] == last_s['ma_may']:
                        gap = int((s['dt_min'] - last_s['dt_min']).total_seconds() / 60)
                        if gap <= 3:
                            quet_trung_details.append(f"bỏ quẹt {s['time']} trùng quẹt {last_s['time']} trên {s['ma_may']} (cách {gap} phút)")
                            continue
                    filtered_swipes.append(s)
                    
            if quet_trung_details:
                anomalies.append({
                    'ma_nv': m_nv,
                    'ngay': d_str,
                    'loai': 'QUET_TRUNG',
                    'chi_tiet': "; ".join(quet_trung_details),
                    'can_nguoi_quyet': 'KHONG',
                    'giai_thich': f"Nhân viên {m_nv} quẹt thẻ nhiều lần liên tiếp cùng máy trong vòng 3 phút; hệ thống tự động giữ lượt đầu và loại bỏ lượt trùng."
                })
                
            has_approved_leave = (m_nv, d_str) in leave_map
            
            gio_vao = ""
            gio_ra = ""
            gio_cong = ""
            phut_tre = ""
            phut_ve_som = ""
            ot_phut = ""
            trang_thai = ""
            
            # Trường hợp 1: Ngày nghỉ hoặc Lễ (OFF hoặc LE)
            if loai_ngay in ['LE', 'OFF']:
                if len(filtered_swipes) > 0:
                    trang_thai = 'CHO_XAC_NHAN'
                    times = [s['time'] for s in filtered_swipes]
                    gio_vao = times[0]
                    gio_ra = times[-1] if len(times) > 1 else ""
                    
                    if loai_ngay == 'LE':
                        anomalies.append({
                            'ma_nv': m_nv,
                            'ngay': d_str,
                            'loai': 'LAM_NGAY_LE',
                            'chi_tiet': f"làm việc ngày nghỉ lễ, quẹt vào {gio_vao}" + (f", ra {gio_ra}" if gio_ra else ""),
                            'can_nguoi_quyet': 'CO',
                            'giai_thich': f"Nhân viên {m_nv} phát sinh quẹt thẻ vào ngày nghỉ lễ theo lịch công ty; cần quản lý xác nhận phân công làm thêm lễ, chế độ cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
                        })
                    else: # OFF
                        anomalies.append({
                            'ma_nv': m_nv,
                            'ngay': d_str,
                            'loai': 'LAM_NGAY_NGHI',
                            'chi_tiet': f"làm việc ngày nghỉ ({loai_ngay}), quẹt vào {gio_vao}" + (f", ra {gio_ra}" if gio_ra else ""),
                            'can_nguoi_quyet': 'CO',
                            'giai_thich': f"Nhân viên {m_nv} phát sinh quẹt thẻ vào ngày nghỉ hàng tuần/lịch nghỉ ca; cần quản lý xác nhận phân công đi làm ngày nghỉ để tính chế độ."
                        })
                else:
                    trang_thai = 'NGHI'
                    
            # Trường hợp 2: Ngày làm việc (HC, S, C)
            else:
                shift_in_str, shift_out_str, std_mins = SHIFT_HOURS[loai_ngay]
                
                if has_approved_leave:
                    if len(filtered_swipes) > 0:
                        trang_thai = 'CHO_XAC_NHAN'
                        times = [s['time'] for s in filtered_swipes]
                        gio_vao = times[0]
                        gio_ra = times[-1] if len(times) > 1 else ""
                        anomalies.append({
                            'ma_nv': m_nv,
                            'ngay': d_str,
                            'loai': 'CO_PHEP_NHUNG_QUET',
                            'chi_tiet': f"có đơn nghỉ phép ({leave_map[(m_nv, d_str)]}) nhưng vẫn quẹt thẻ vào {gio_vao}" + (f", ra {gio_ra}" if gio_ra else ""),
                            'can_nguoi_quyet': 'CO',
                            'giai_thich': f"Nhân viên {m_nv} có đơn phép đã duyệt nhưng vẫn tới công ty làm việc và quẹt thẻ; cần quản lý xác nhận thực tế để hủy đơn phép và tính công hoặc giữ nguyên phép."
                        })
                    else:
                        trang_thai = 'PHEP'
                else:
                    if len(filtered_swipes) == 0:
                        trang_thai = 'CHO_XAC_NHAN'
                        anomalies.append({
                            'ma_nv': m_nv,
                            'ngay': d_str,
                            'loai': 'VANG_CHUA_GHI',
                            'chi_tiet': f"vắng mặt cả ngày ca {loai_ngay}, không có quẹt thẻ và không có đơn phép",
                            'can_nguoi_quyet': 'CO',
                            'giai_thich': f"Nhân viên {m_nv} không có mặt làm việc theo lịch và chưa ghi nhận đơn nghỉ phép; cần quản lý kiểm tra lý do vắng mặt và bổ sung đơn phép nếu có."
                        })
                    elif len(filtered_swipes) == 1:
                        trang_thai = 'CHO_XAC_NHAN'
                        t_swipe = filtered_swipes[0]['time']
                        
                        diff_from_in = diff_minutes(t_swipe, shift_in_str)
                        diff_to_out = diff_minutes(shift_out_str, t_swipe)
                        
                        if diff_from_in <= 120:
                            gio_vao = t_swipe
                            anomalies.append({
                                'ma_nv': m_nv,
                                'ngay': d_str,
                                'loai': 'THIEU_RA',
                                'chi_tiet': f"quẹt vào lúc {t_swipe}, thiếu quẹt ra ca {loai_ngay}",
                                'can_nguoi_quyet': 'CO',
                                'giai_thich': f"Nhân viên {m_nv} chỉ có quẹt vào ca mà quên quẹt ra; cần quản lý xác nhận giờ ra ca thực tế để bổ sung giờ công."
                            })
                        elif diff_to_out <= 120:
                            gio_ra = t_swipe
                            anomalies.append({
                                'ma_nv': m_nv,
                                'ngay': d_str,
                                'loai': 'THIEU_VAO',
                                'chi_tiet': f"quẹt ra lúc {t_swipe}, thiếu quẹt vào ca {loai_ngay}",
                                'can_nguoi_quyet': 'CO',
                                'giai_thich': f"Nhân viên {m_nv} chỉ có quẹt ra ca mà quên quẹt đầu ca; cần quản lý xác nhận giờ vào ca thực tế để tính công."
                            })
                        else:
                            anomalies.append({
                                'ma_nv': m_nv,
                                'ngay': d_str,
                                'loai': 'THIEU_KHONG_RO',
                                'chi_tiet': f"chỉ có 1 lần quẹt lúc {t_swipe} giữa ca {loai_ngay} (không rõ vào hay ra)",
                                'can_nguoi_quyet': 'CO',
                                'giai_thich': f"Nhân viên {m_nv} chỉ quẹt một lần vào giữa giờ làm, không xác định được là vào hay ra; cần quản lý xác minh thời gian làm việc thực tế."
                            })
                    else:
                        times = [s['time'] for s in filtered_swipes]
                        gio_vao = times[0]
                        gio_ra = times[-1]
                        
                        if nghi_quet_ho_detected:
                            trang_thai = 'CHO_XAC_NHAN'
                        else:
                            # Tính đi trễ
                            diff_in = diff_minutes(gio_vao, shift_in_str)
                            if diff_in >= 6:
                                p_tre = diff_in
                                anomalies.append({
                                'ma_nv': m_nv,
                                'ngay': d_str,
                                'loai': 'DI_TRE',
                                'chi_tiet': f"vào {gio_vao}, trễ {p_tre} phút ca {loai_ngay}",
                                'can_nguoi_quyet': 'KHONG',
                                'giai_thich': f"Nhân viên {m_nv} vào ca muộn {p_tre} phút (đã trừ dung sai 5 phút); hệ thống tự động ghi nhận theo quy chế công ty."
                            })
                            else:
                                p_tre = 0
                            phut_tre = p_tre
                            
                            # Tính về sớm
                            diff_out = diff_minutes(shift_out_str, gio_ra)
                            if diff_out >= 6:
                                p_ve_som = diff_out
                                anomalies.append({
                                'ma_nv': m_nv,
                                'ngay': d_str,
                                'loai': 'VE_SOM',
                                'chi_tiet': f"ra {gio_ra}, về sớm {p_ve_som} phút ca {loai_ngay}",
                                'can_nguoi_quyet': 'KHONG',
                                'giai_thich': f"Nhân viên {m_nv} về sớm {p_ve_som} phút so với giờ hết ca; hệ thống tự động ghi nhận theo quy chế công ty."
                            })
                            else:
                                p_ve_som = 0
                            phut_ve_som = p_ve_som
                            
                            # Tính làm thêm giờ
                            diff_ot = diff_minutes(gio_ra, shift_out_str)
                            if diff_ot >= 30:
                                ot_p = diff_ot
                            else:
                                ot_p = 0
                            ot_phut = ot_p
                            
                            # Kiểm tra ngưỡng OT ngày > 180 phút
                            if ot_p > 180:
                                anomalies.append({
                                'ma_nv': m_nv,
                                'ngay': d_str,
                                'loai': 'OT_VUOT_NGUONG',
                                'chi_tiet': f"làm thêm {ot_p} phút ({ot_p/60:.2f} giờ), vượt ngưỡng 180 phút/ngày",
                                'can_nguoi_quyet': 'CO',
                                'giai_thich': f"Nhân viên {m_nv} làm thêm {ot_p} phút, vượt trần 3 giờ/ngày; cần quản lý phê duyệt lý do làm thêm đột xuất, cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
                            })
                                trang_thai = 'CHO_XAC_NHAN'
                            else:
                                trang_thai = 'OK'
                                work_mins = std_mins - p_tre - p_ve_som
                                gio_cong = f"{work_mins / 60.0:.2f}"
                                emp_monthly_ot[m_nv] += ot_p
                                
            bang_cong_rows.append({
                'ma_nv': m_nv,
                'ngay': d_str,
                'loai_ngay': loai_ngay,
                'gio_vao': gio_vao,
                'gio_ra': gio_ra,
                'gio_cong': gio_cong,
                'phut_tre': phut_tre if phut_tre != "" else "",
                'phut_ve_som': phut_ve_som if phut_ve_som != "" else "",
                'ot_phut': ot_phut if ot_phut != "" else "",
                'trang_thai': trang_thai
            })

    # Kiểm tra ngưỡng làm thêm trong tháng: > 2400 phút
    for m_nv, total_ot_m in emp_monthly_ot.items():
        if total_ot_m > 2400:
            anomalies.append({
                'ma_nv': m_nv,
                'ngay': 'THANG',
                'loai': 'OT_THANG_VUOT',
                'chi_tiet': f"tổng làm thêm {total_ot_m} phút ({total_ot_m/60:.2f} giờ), vượt ngưỡng 2400 phút (40 giờ)/tháng",
                'can_nguoi_quyet': 'CO',
                'giai_thich': f"Tổng giờ làm thêm tháng của {m_nv} vượt ngưỡng 40 giờ; cần đối chiếu kế hoạch làm thêm và kiểm với văn bản hiện hành hoặc chuyên gia nhân sự."
            })

    # Xuất tệp 1: bang_cong_ngay.csv
    bang_cong_df = pd.DataFrame(bang_cong_rows)
    bang_cong_cols = ['ma_nv', 'ngay', 'loai_ngay', 'gio_vao', 'gio_ra', 'gio_cong', 'phut_tre', 'phut_ve_som', 'ot_phut', 'trang_thai']
    bang_cong_df = bang_cong_df[bang_cong_cols]
    bang_cong_df.to_csv('bang_cong_ngay.csv', index=False, encoding='utf-8')

    # Xuất tệp 2: bat_thuong.csv
    anom_df = pd.DataFrame(anomalies)
    bat_thuong_cols = ['ma_nv', 'ngay', 'loai', 'chi_tiet', 'can_nguoi_quyet', 'giai_thich']
    anom_df = anom_df[bat_thuong_cols]
    # Sắp xếp theo mã nv, ngày, loại
    anom_df = anom_df.sort_values(by=['ma_nv', 'ngay', 'loai'])
    anom_df.to_csv('bat_thuong.csv', index=False, encoding='utf-8')

    # Xuất tệp 3: tong_hop_nguoi.csv
    summary_rows = []
    for m_nv in employees:
        emp_bc = bang_cong_df[bang_cong_df['ma_nv'] == m_nv]
        emp_anoms = anom_df[anom_df['ma_nv'] == m_nv]
        
        ok_days = emp_bc[emp_bc['trang_thai'] == 'OK']
        ngay_cong = len(ok_days)
        tong_gio_cong = sum([float(x) for x in ok_days['gio_cong'] if x != ''])
        
        tre_days = ok_days[ok_days['phut_tre'].apply(lambda x: x != '' and int(x) > 0)]
        so_lan_tre = len(tre_days)
        tong_phut_tre = sum([int(x) for x in tre_days['phut_tre']])
        
        som_days = ok_days[ok_days['phut_ve_som'].apply(lambda x: x != '' and int(x) > 0)]
        so_lan_ve_som = len(som_days)
        tong_phut_ve_som = sum([int(x) for x in som_days['phut_ve_som']])
        
        tong_ot_phut = sum([int(x) for x in ok_days['ot_phut'] if x != '' and int(x) > 0])
        tong_ot_gio = f"{tong_ot_phut / 60.0:.2f}"
        
        so_ngay_phep = len(emp_bc[emp_bc['trang_thai'] == 'PHEP'])
        so_ngay_vang_chua_ghi = len(emp_anoms[emp_anoms['loai'] == 'VANG_CHUA_GHI'])
        so_ngay_cho_xac_nhan = len(emp_bc[emp_bc['trang_thai'] == 'CHO_XAC_NHAN'])
        so_bat_thuong = len(emp_anoms)
        
        summary_rows.append({
            'ma_nv': m_nv,
            'ngay_cong': ngay_cong,
            'tong_gio_cong': f"{tong_gio_cong:.2f}",
            'so_lan_tre': so_lan_tre,
            'tong_phut_tre': tong_phut_tre,
            'so_lan_ve_som': so_lan_ve_som,
            'tong_phut_ve_som': tong_phut_ve_som,
            'tong_ot_gio': tong_ot_gio,
            'so_ngay_phep': so_ngay_phep,
            'so_ngay_vang_chua_ghi': so_ngay_vang_chua_ghi,
            'so_ngay_cho_xac_nhan': so_ngay_cho_xac_nhan,
            'so_bat_thuong': so_bat_thuong
        })

    tong_hop_df = pd.DataFrame(summary_rows)
    tong_hop_cols = [
        'ma_nv', 'ngay_cong', 'tong_gio_cong', 'so_lan_tre', 'tong_phut_tre',
        'so_lan_ve_som', 'tong_phut_ve_som', 'tong_ot_gio', 'so_ngay_phep',
        'so_ngay_vang_chua_ghi', 'so_ngay_cho_xac_nhan', 'so_bat_thuong'
    ]
    tong_hop_df = tong_hop_df[tong_hop_cols]
    tong_hop_df.to_csv('tong_hop_nguoi.csv', index=False, encoding='utf-8')

    # In kết quả tóm tắt ra màn hình
    print("=" * 60)
    print("HOÀN THÀNH TÍNH CÔNG VÀ XUẤT CÁC TỆP DỮ LIỆU THÁNG 09/2026")
    print("=" * 60)
    print(f"1. bang_cong_ngay.csv : {len(bang_cong_df) + 1} dòng (gồm tiêu đề)")
    print(f"2. bat_thuong.csv     : {len(anom_df) + 1} dòng (gồm tiêu đề)")
    print(f"3. tong_hop_nguoi.csv : {len(tong_hop_df) + 1} dòng (gồm tiêu đề)")
    print("-" * 60)
    print(f"TỔNG SỐ BẤT THƯỜNG PHÁT HIỆN: {len(anom_df)}")
    print("Thống kê chi tiết theo loại bất thường:")
    counts = anom_df['loai'].value_counts()
    for loai, cnt in counts.items():
        can_quyet = "CẦN QUYẾT" if loai not in ['QUET_TRUNG', 'DI_TRE', 'VE_SOM'] else "TỰ ĐỘNG"
        print(f"  - {loai:<20}: {cnt:>2} trường hợp ({can_quyet})")
    print("=" * 60)

if __name__ == '__main__':
    main()
