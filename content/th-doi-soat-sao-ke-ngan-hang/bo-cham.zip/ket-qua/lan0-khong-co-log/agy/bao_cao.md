# Báo cáo đối soát tháng 10/2026
1. Tổng giao dịch sao kê: 144 dòng (97 có, 47 nợ). Số dư đầu kỳ: 40,000,000đ, cuối kỳ: 95,782,650đ (khớp tuyệt đối).
2. Tổng phát sinh có: 130,898,650đ. Trong đó đã ghép đơn: 112,810,000đ (90,310,000đ khớp đủ, 10,280,000đ ghép nhiều đơn).
3. Đã đối soát 2 đợt COD gộp: 7,750,000đ khớp 11 đơn COD; lãi ngân hàng: 18,650đ.
4. Phát sinh ngoại lệ: 4 đơn thiếu (3,280,000đ), 4 đơn thừa (6,060,000đ), 3 giao dịch chuyển trùng (2,880,000đ).
5. Có 1 ca hoàn tiền một phần (DH2610-037 trừ 30.000đ ship) và 4 khoản tiền không rõ nguồn (5.650.000đ).
6. Có 5 ca chuyển khoản CẦN NGƯỜI QUYẾT (4.670.000đ) do mâu thuẫn nội dung/số tiền (CT 30136693, 35586667, 81794057, 62820400, 72253631).
7. Có 13 đơn CK chưa thu tiền (10 đơn hoàn toàn chưa có tiền về gồm 012, 050 và 8 đơn cuối tháng; 3 đơn nghi vấn chờ duyệt).
8. Điều chưa chắc chắn 1: Khoản TT HD 0087 (3.200.000đ ngày 16/10) và MUA HANG ZALO (560.000đ ngày 27/10) chưa rõ đơn hàng thực tế.
9. Điều chưa chắc chắn 2: Ba giao dịch khách gõ nhầm mã đơn (Đặng Kim Mai, Lý Thị Linh, Đặng Quốc Sơn) cần liên hệ khách xác nhận trước khi gán chính thức.
10. Tổng số ca ngoại lệ cần xử lý trong ngoai_le.csv: 34 ca.
