import os
import csv
from datetime import datetime, timedelta
from collections import defaultdict

def parse_date(d_str):
    d_str = d_str.strip()
    if '-' in d_str:
        return datetime.strptime(d_str, '%Y-%m-%d').date()
    else:
        return datetime.strptime(d_str, '%d/%m/%Y').date()

def get_monday(d):
    return d - timedelta(days=d.weekday())

def find_file(filename):
    # Check current directory, dau-ra directory, or parent directory
    candidates = [
        filename,
        os.path.join('dau-ra', filename),
        os.path.join('..', filename),
        os.path.join(os.path.dirname(__file__), filename),
        os.path.join(os.path.dirname(__file__), '..', filename)
    ]
    for c in candidates:
        if os.path.exists(c):
            return os.path.abspath(c)
    raise FileNotFoundError(f"Cannot find {filename}")

def main():
    path_danh_gia = find_file('danh-gia.csv')
    path_loai_bo = find_file('loai-bo.csv')
    path_y_kien = find_file('y-kien.csv')

    # Read loai-bo
    excluded_mas = set()
    with open(path_loai_bo, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            if r['ma'].strip():
                excluded_mas.add(r['ma'].strip())

    # Read danh-gia
    review_dates = {}
    with open(path_danh_gia, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            ma = r['ma'].strip()
            if ma not in excluded_mas:
                d = parse_date(r['ngay'])
                review_dates[ma] = d

    # Read y-kien
    # Aggregate by (tuan, chu_de) and overall by (chu_de)
    # sac_thai: tich_cuc, tieu_cuc, trung_tinh, can_nguoi_doc
    weekly_counts = defaultdict(lambda: {'tich_cuc': 0, 'tieu_cuc': 0, 'trung_tinh': 0, 'can_nguoi_doc': 0})
    overall_counts = defaultdict(lambda: {'tich_cuc': 0, 'tieu_cuc': 0, 'trung_tinh': 0, 'can_nguoi_doc': 0})
    total_opinions = 0
    total_reviews_with_can_nguoi_doc = set()

    with open(path_y_kien, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            ma = r['ma'].strip()
            if ma in excluded_mas:
                continue
            if ma not in review_dates:
                continue
            
            chu_de = r['chu_de'].strip()
            sac_thai = r['sac_thai'].strip().lower()
            if sac_thai not in ['tich_cuc', 'tieu_cuc', 'trung_tinh', 'can_nguoi_doc']:
                continue

            if sac_thai == 'can_nguoi_doc':
                total_reviews_with_can_nguoi_doc.add(ma)

            d = review_dates[ma]
            monday = get_monday(d)
            tuan = monday.strftime('%Y-%m-%d')

            weekly_counts[(tuan, chu_de)][sac_thai] += 1
            overall_counts[chu_de][sac_thai] += 1
            total_opinions += 1

    # Output xu-huong-tuan.csv
    # Determine all weeks and all topics
    all_weeks = sorted(list(set(tuan for (tuan, _) in weekly_counts.keys())))
    all_topics = ['chat_luong', 'gia', 'giao_hang', 'khac', 'khong_gian', 'phuc_vu', 've_sinh']

    out_dir = os.path.dirname(os.path.abspath(__file__))
    if not out_dir.endswith('dau-ra'):
        out_dir = os.path.join(out_dir, 'dau-ra')
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, 'xu-huong-tuan.csv')

    with open(out_path, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['tuan', 'chu_de', 'tich_cuc', 'tieu_cuc', 'trung_tinh', 'can_nguoi_doc'])
        for tuan in all_weeks:
            for chu_de in all_topics:
                counts = weekly_counts[(tuan, chu_de)]
                writer.writerow([
                    tuan,
                    chu_de,
                    counts['tich_cuc'],
                    counts['tieu_cuc'],
                    counts['trung_tinh'],
                    counts['can_nguoi_doc']
                ])

    print(f"Ghi thanh cong: {out_path}")
    print("\n--- TONG KET CHU DE X SAC THAI ---")
    print(f"{'chu_de':<15} | {'tich_cuc':<10} | {'tieu_cuc':<10} | {'trung_tinh':<10} | {'can_nguoi_doc':<15} | {'tong':<10}")
    print("-" * 80)
    grand_totals = {'tich_cuc': 0, 'tieu_cuc': 0, 'trung_tinh': 0, 'can_nguoi_doc': 0}
    for cd in sorted(all_topics):
        c = overall_counts[cd]
        row_total = sum(c.values())
        for k in grand_totals:
            grand_totals[k] += c[k]
        print(f"{cd:<15} | {c['tich_cuc']:<10} | {c['tieu_cuc']:<10} | {c['trung_tinh']:<10} | {c['can_nguoi_doc']:<15} | {row_total:<10}")
    print("-" * 80)
    print(f"{'TONG CONG':<15} | {grand_totals['tich_cuc']:<10} | {grand_totals['tieu_cuc']:<10} | {grand_totals['trung_tinh']:<10} | {grand_totals['can_nguoi_doc']:<15} | {sum(grand_totals.values()):<10}")

    print(f"\nTong so y kien hop le: {total_opinions}")
    print(f"So bai danh gia can nguoi doc (distinct ma): {len(total_reviews_with_can_nguoi_doc)}")

    print("\n--- XU HUONG THEO TUAN (TONG Y KIEN TIEU CUC & TICH CUC MOI TUAN) ---")
    for tuan in all_weeks:
        t_pos = sum(weekly_counts[(tuan, cd)]['tich_cuc'] for cd in all_topics)
        t_neg = sum(weekly_counts[(tuan, cd)]['tieu_cuc'] for cd in all_topics)
        t_neu = sum(weekly_counts[(tuan, cd)]['trung_tinh'] for cd in all_topics)
        t_cnd = sum(weekly_counts[(tuan, cd)]['can_nguoi_doc'] for cd in all_topics)
        print(f"Tuan {tuan}: Tich cuc={t_pos:2d}, Tieu cuc={t_neg:2d}, Trung tinh={t_neu:2d}, Can doc={t_cnd:2d}")

if __name__ == '__main__':
    main()
