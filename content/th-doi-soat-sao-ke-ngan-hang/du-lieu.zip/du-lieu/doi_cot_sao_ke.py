"""Giả lập "ngân hàng đổi định dạng sao kê": đọc sao-ke-t10-2026.csv, ghi sao-ke-moi.csv cùng dữ liệu, khác định dạng.
(Định dạng mới là do chúng tôi bịa để tập sửa script; không phải định dạng của ngân hàng nào. Dữ liệu vẫn là dữ liệu giả.)

Chạy trong thư mục du-lieu/:   python -X utf8 doi_cot_sao_ke.py

Khác với bản cũ:
  1. Dấu phân cách cột là chấm phẩy (;) thay vì phẩy.
  2. Số tiền kiểu 1.250.000 (dấu chấm) thay vì 1,250,000.
  3. Tên cột đổi và thứ tự cột đổi: Ngày giao dịch; Mã giao dịch; Diễn giải; Số tiền ghi có; Số tiền ghi nợ; Số dư.
  4. Nhãn dòng thông tin đầu file và dòng tổng cuối file đổi tên.
Số chứng từ (mã giao dịch), ngày, số tiền, nội dung của từng dòng không đổi, nên chấm được bằng cham.py như cũ.
"""
import csv
from pathlib import Path

HERE = Path(__file__).resolve().parent


def cham(s):
    """1,250,000 -> 1.250.000 (chuỗi rỗng giữ nguyên)."""
    return s.replace(",", ".") if s else s


rows = list(csv.reader(open(HERE / "sao-ke-t10-2026.csv", encoding="utf-8-sig", newline="")))
h = next(i for i, r in enumerate(rows) if r and r[0] == "Ngày GD")
out = [["SAO KE TAI KHOAN (DU LIEU GIA DE HOC)"]]
nhan = {"Chu tai khoan": "Tên tài khoản", "So tai khoan": "Số tài khoản", "Tu ngay": "Từ ngày", "Den ngay": "Đến ngày",
        "So du dau ky": "Số dư đầu kỳ"}
for r in rows[1:h]:
    if r:
        out.append([nhan[r[0]], cham(r[1])] if r[0] == "So du dau ky" else [nhan[r[0]], r[1]])
    else:
        out.append([])
out.append(["Ngày giao dịch", "Mã giao dịch", "Diễn giải", "Số tiền ghi có", "Số tiền ghi nợ", "Số dư"])
nhan_cuoi = {"Tong phat sinh no": "Tổng ghi nợ", "Tong phat sinh co": "Tổng ghi có", "So du cuoi ky": "Số dư cuối kỳ"}
for r in rows[h + 1:]:
    if not r:
        out.append([])
    elif r[0] in nhan_cuoi:
        out.append([nhan_cuoi[r[0]], cham(r[1])])
    else:
        ngay, so_ct, no, co, du, nd = r
        out.append([ngay, so_ct, nd, cham(co), cham(no), cham(du)])
with open(HERE / "sao-ke-moi.csv", "w", encoding="utf-8-sig", newline="") as f:
    csv.writer(f, delimiter=";").writerows(out)
print("Đã ghi sao-ke-moi.csv:", len(out), "dòng (gồm dòng đầu, dòng tiêu đề, dòng tổng)")
