import os
import csv
import re
import sys

def find_file(filename):
    candidates = [
        filename,
        os.path.join('dau-ra', filename),
        os.path.join('..', filename),
        os.path.join(os.path.dirname(__file__), filename),
        os.path.join(os.path.dirname(__file__), '..', filename)
    ]
    for c in candidates:
        if os.path.exists(c):
            return os.path.abspath(c)
    raise FileNotFoundError(f"Cannot find {filename}")

def main():
    path_danh_gia = find_file('danh-gia.csv')
    path_y_kien = find_file('y-kien.csv')
    path_nguy_cap = find_file('nguy-cap.csv')
    path_bao_cao = find_file('bao-cao.md')

    # Load danh-gia.csv
    danh_gia = {}
    with open(path_danh_gia, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            danh_gia[r['ma'].strip()] = r['noi_dung']

    all_passed = True

    # 1. Check y-kien.csv
    print("=== KIEM TRA Y-KIEN.CSV ===")
    y_kien_total = 0
    y_kien_pass = 0
    with open(path_y_kien, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for i, r in enumerate(reader, 1):
            y_kien_total += 1
            ma = r['ma'].strip()
            td = r['trich_dan']
            if ma not in danh_gia:
                print(f"[FAIL] Dòng {i}: Mã {ma} không tồn tại trong danh-gia.csv")
                all_passed = False
            elif td not in danh_gia[ma]:
                print(f"[FAIL] Dòng {i} (Mã {ma}): Trích dẫn không khớp nguyên văn!")
                print(f"  Trích dẫn: '{td}'")
                print(f"  Gốc      : '{danh_gia[ma]}'")
                all_passed = False
            else:
                y_kien_pass += 1

    print(f"Ket qua y-kien.csv: {y_kien_pass}/{y_kien_total} dong hop le.\n")

    # 2. Check nguy-cap.csv
    print("=== KIEM TRA NGUY-CAP.CSV ===")
    nguy_cap_total = 0
    nguy_cap_pass = 0
    with open(path_nguy_cap, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for i, r in enumerate(reader, 1):
            nguy_cap_total += 1
            ma = r['ma'].strip()
            td = r['trich_dan']
            if ma not in danh_gia:
                print(f"[FAIL] Dòng {i}: Mã {ma} không tồn tại trong danh-gia.csv")
                all_passed = False
            elif td not in danh_gia[ma]:
                print(f"[FAIL] Dòng {i} (Mã {ma}): Trích dẫn không khớp nguyên văn!")
                print(f"  Trích dẫn: '{td}'")
                print(f"  Gốc      : '{danh_gia[ma]}'")
                all_passed = False
            else:
                nguy_cap_pass += 1

    print(f"Ket qua nguy-cap.csv: {nguy_cap_pass}/{nguy_cap_total} dong hop le.\n")

    # 3. Check bao-cao.md
    print("=== KIEM TRA BAO-CAO.MD ===")
    quote_pattern = re.compile(r'>\s*\[([A-Za-z0-9_]+)\]\s*"([^"]+)"')
    bao_cao_total = 0
    bao_cao_pass = 0
    with open(path_bao_cao, encoding='utf-8') as f:
        content = f.read()

    matches = quote_pattern.findall(content)
    for ma, td in matches:
        bao_cao_total += 1
        ma = ma.strip()
        if ma not in danh_gia:
            print(f"[FAIL] Báo cáo: Mã {ma} không tồn tại trong danh-gia.csv")
            all_passed = False
        elif td not in danh_gia[ma]:
            print(f"[FAIL] Báo cáo (Mã {ma}): Trích dẫn không khớp nguyên văn!")
            print(f"  Trích dẫn: '{td}'")
            print(f"  Gốc      : '{danh_gia[ma]}'")
            all_passed = False
        else:
            bao_cao_pass += 1

    print(f"Ket qua bao-cao.md: {bao_cao_pass}/{bao_cao_total} trich dan hop le.\n")

    if all_passed:
        print(">>> TAT CA TRICH DAN TRONG Y-KIEN.CSV, NGUY-CAP.CSV VA BAO-CAO.MD DEU HOP LE NGUYEN VAN 100%! <<<")
        sys.exit(0)
    else:
        print(">>> CO DONG KHONG QUA KIEM TRA! VUI LONG KIEM TRA CAC DONG LOI O TREN. <<<")
        sys.exit(1)

if __name__ == '__main__':
    main()
