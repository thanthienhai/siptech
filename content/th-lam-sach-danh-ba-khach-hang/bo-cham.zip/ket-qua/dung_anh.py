"""Dựng lại TOÀN BỘ ảnh trong ../anh/ từ log đã che và file kết quả/ dữ liệu trong thư mục bài.

Chạy:  python -X utf8 dung_anh.py [--agentlab <thư_mục_chứa_term.py>]
Mặc định tìm term.py ở siptech-video/agentlab (5 cấp trên thư mục bài). term.py tự che đường dẫn máy, tên tổ chức, email
(hàm scrub_text); mọi chuỗi lấy từ log/ file trong script này cũng đi qua scrub_text trước khi vào HTML.
Ảnh terminal là bản dựng lại từ log thật (logs/*.json), không phải ảnh chụp cửa sổ TUI.
"""
import sys, html, json, csv, re
from pathlib import Path
import openpyxl

HERE = Path(__file__).resolve().parent
B = HERE.parent                                   # thư mục bài
AL = Path(sys.argv[sys.argv.index("--agentlab") + 1]) if "--agentlab" in sys.argv else B.parents[3] / "siptech-video" / "agentlab"
sys.path.insert(0, str(AL))
from term import render_blocks, shot_html, scrub_text, CSS as TCSS
ANH = B / "anh"; ANH.mkdir(exist_ok=True)

_FAKE_MAIL = re.compile(r"[\w.+-]+@+[\w-]+[.,](?:com|org|net)\b", re.I)   # email GIẢ của bộ dữ liệu (tên miền example.*): giữ nguyên

def esc(v):
    """Che đường dẫn/ tên tổ chức/ email thật bằng scrub_text, nhưng giữ email giả của bộ dữ liệu để bảng còn đọc được."""
    s = "" if v is None else str(v); out, pos = [], 0
    for m in _FAKE_MAIL.finditer(s):
        if "example" in m.group(0).lower():
            out.append(scrub_text(s[pos:m.start()])); out.append(m.group(0)); pos = m.end()
    out.append(scrub_text(s[pos:]))
    return html.escape("".join(out))

# ======================================================= ảnh terminal từ logs/*.json (đã che)
def extra_scrub(o):
    """Che thêm trên từng chuỗi: bỏ hẳn chữ OneDrive (term.scrub_text giữ lại 'OneDrive - [đã che]')."""
    if isinstance(o, str):
        return re.sub(r"~?[\\/]*OneDrive - \[đã che\]", "~", o)
    if isinstance(o, list): return [extra_scrub(x) for x in o]
    if isinstance(o, dict): return {k: extra_scrub(v) for k, v in o.items()}
    return o

def terminal(log, out, title, blocks, maxlines, width=1280):
    t = extra_scrub(json.loads((B / "logs" / log).read_text(encoding="utf-8")))
    s, e = blocks.split(":"); bl = t["blocks"][int(s or 0): int(e) if e else None]
    h = render_blocks(bl, title, t["prompt"], maxlines, width, False)
    shot_html(h, str(ANH / out), width + 40, ".win")
    print("ảnh:", out)

terminal("claude-1.json", "02-claude-dang-lam.png", "claude · runs/claude-1 (khởi động và viết script)", "7:12", 7)
terminal("agy-1.json", "03-agy-dang-lam.png", "agy · runs/agy-1 (viết và chạy lam_sach.py)", "63:65", 22)
terminal("claude-1.json", "06-claude-ket-qua-cuoi.png", "claude · kết quả cuối", "25:", 40)
terminal("agy-1.json", "07-agy-ket-qua-cuoi.png", "agy · kết quả cuối", "71:", 30)

# ======================================================= ảnh 01: prompt
txt = (B / "du-lieu" / "prompt-giao-viec.txt").read_text(encoding="utf-8")
parts = []
for sec in re.split(r"(?m)^# ", txt)[1:]:
    head, _, body = sec.partition("\n"); body = body.strip("\n"); lines = body.splitlines()
    parts.append(f'<div class="a" style="color:#fcd34d;font-weight:700">## {esc(head)}</div>')
    if head.startswith(("Quy tắc", "Định dạng")):
        keep = lines[:5]; rest = len(lines) - len(keep)
        more = f'\n<span class="more">… (còn {rest} dòng, xem đủ trong du-lieu/prompt-giao-viec.txt)</span>' if rest > 0 else ""
        parts.append(f'<div class="out" style="color:#cbd5e1">{esc(chr(10).join(keep))}{more}</div>')
    else:
        parts.append(f'<div class="out" style="color:#cbd5e1">{esc(body)}</div>')
h = (f'<!doctype html><meta charset="utf-8"><style>{TCSS}.a:before{{content:""}}</style><div style="padding:18px;width:1300px"><div class="win" id="w"><div class="bar"><span class="dot r"></span><span class="dot y"></span><span class="dot g"></span>'
     f'<span class="t">prompt giao việc (khung 6 phần) · trích, rút gọn mục Quy tắc</span></div><div class="body">{"".join(parts)}</div></div></div>')
shot_html(h, str(ANH / "01-prompt-giao-viec.png"), 1340, ".win"); print("ảnh: 01")

# ======================================================= dữ liệu
A = json.loads((B / "ket-qua" / "dap-an.json").read_text(encoding="utf-8"))
REP = json.loads((B / "ket-qua" / "bao-cao-cham.json").read_text(encoding="utf-8"))["ket_qua"]
REP2 = json.loads((B / "ket-qua" / "bao-cao-cham-dot2.json").read_text(encoding="utf-8"))["ket_qua"]
GOC = {r[0]: r for r in openpyxl.load_workbook(B / "du-lieu" / "danh-ba-goc.xlsx").active.iter_rows(values_only=True)}
CSS = """body{margin:0;background:#fff;font-family:'Segoe UI',sans-serif}.w{padding:16px;width:1500px}
h3{margin:0 0 4px;font-size:18px;color:#0b1f4d}.s{color:#555;font-size:13px;margin-bottom:10px}
table{border-collapse:collapse;width:100%;font-size:13.5px;margin-bottom:6px}th{background:#1f3a68;color:#fff;text-align:left;padding:6px 8px}
td{border:1px solid #d5dbe8;padding:5px 8px;vertical-align:top;white-space:pre-wrap;word-break:break-word}
tr.g1 td{background:#fff7d6}tr.g2 td{background:#e3f1ff}tr.g3 td{background:#ffe3e3}tr.g4 td{background:#e5f7e5}tr.g5 td{background:#f0e6ff}
tr.bad td,td.bad{background:#ffd6d6!important;font-weight:600}tr.ok td,td.ok{background:#dcf5dc!important}.k{font:12px Consolas;color:#555}
.foot{font-size:12px;color:#666;margin-top:8px}h4{margin:14px 0 4px;color:#0b1f4d}"""
def table(head, rows, cls=None):
    o = "<table><tr>" + "".join(f"<th>{esc(x)}</th>" for x in head) + "</tr>"
    for i, r in enumerate(rows):
        c = f' class="{cls[i]}"' if cls and cls[i] else ""
        o += f"<tr{c}>" + "".join(f"<td>{esc(v)}</td>" for v in r) + "</tr>"
    return o + "</table>"
def page(title, sub, body, foot):
    return f'<style>{CSS}</style><div class="w" id="w"><h3>{esc(title)}</h3><div class="s">{esc(sub)}</div>{body}<div class="foot">{esc(foot)}</div></div>'
def clean(run):
    ws = openpyxl.load_workbook(B / "ket-qua" / run / "danh-ba-sach.xlsx")["KhachHang"]; rows = list(ws.iter_rows(values_only=True)); hd = rows[0]
    return [dict(zip(hd, r)) for r in rows[1:]]
def kh(run, rid): return next(d for d in clean(run) if rid in (d["ma_dong_goc"] or "").split(";"))
def shot(page_html, name, w): shot_html(page_html, str(ANH / name), w, "#w"); print("ảnh:", name)

# ---------- 05 + 04: dữ liệu đầu vào
def tbl_goc(title, sub, groups):
    h = f"<style>{CSS}</style><div class=\"w\" id=\"w\"><h3>{esc(title)}</h3><div class=\"s\">{esc(sub)}</div><table><tr>" + "".join(f"<th>{c}</th>" for c in ["Mã dòng", "Nguồn", "Họ tên", "SĐT", "Email", "Địa chỉ", "Ghi chú", "(Ghi chú của người soạn)"]) + "</tr>"
    for i, (ids, note) in enumerate(groups, 1):
        for j, rid in enumerate(ids):
            h += f'<tr class="g{i}">' + "".join(f"<td>{esc(v)}</td>" for v in GOC[rid]) + f'<td class="k">{esc(note) if j == 0 else ""}</td></tr>'
    return h + '</table><div class="foot">Dữ liệu GIẢ để học (sinh bằng sinh_du_lieu.py, hạt giống cố định). Tô màu = các dòng cùng nhóm, cột cuối do người soạn đáp án thêm; file thật KHÔNG có màu hay cột này.</div></div>'
def find(loai, sect, n=0): return [g for g in A[sect] if g["loai"] == loai][n]["rows"]
g1 = [(find("A", "gop_chac", 0), "Cùng SĐT, khác định dạng/ cách viết tên -> gộp"),
      (find("A-chain", "gop_chac", 0), "Bắc cầu: SĐT trùng, rồi email trùng -> gộp 3 dòng"),
      (find("H1", "can_nguoi_quyet", 0), "Cùng SĐT, tên khác hẳn -> CẦN NGƯỜI QUYẾT"),
      (find("T1", "khong_gop", 0), "Trùng tên, khác SĐT & địa chỉ -> KHÔNG gộp"),
      (find("T3", "khong_gop", 0), "Tên gần giống (Hùng/Hưng), SĐT sát nhau -> KHÔNG gộp")]
shot(tbl_goc("Danh bạ gốc (trích 12 dòng, file thật có 400 dòng)", "Các dòng trong cùng một màu là các nhóm mà đáp án biết trước", g1), "05-du-lieu-nhom-trung.png", 1520)
seen, pick = set(), []
for r, v in A["rows"].items():
    for t in v["tags"]:
        if t.startswith("lan_cot") and t not in seen: seen.add(t); pick.append(([r], t.replace("lan_cot:", "Lẫn cột: ")))
bad = [r for r, v in A["rows"].items() if v["email_sai_goc"]][:1] + [r for r, v in A["rows"].items() if v["sdt_sai_goc"]][:2]
pick += [([bad[0]], "Email sai (không tự sửa)"), ([bad[1]], "SĐT sai/che số"), ([bad[2]], "SĐT sai/che số")]
shot(tbl_goc("Danh bạ gốc (trích): ô lẫn cột và giá trị sai", "Mỗi dòng là một kiểu lỗi khác nhau", pick), "04-du-lieu-lan-cot.png", 1520)

# ---------- 08: danh bạ sạch
rows, seen = [], []
for rid in ["R127", "R001", "R080", "R305", "R004", "R018", "R007", "R109"]:
    d = kh("claude-1", rid)
    if d["ma_khach"] in seen: continue
    seen.append(d["ma_khach"]); rows.append([d[k] for k in ["ma_khach", "ho_ten", "sdt", "sdt_khac", "email", "dia_chi", "ma_dong_goc", "ghi_chu"]])
shot(page("Kết quả: danh-ba-sach.xlsx (lần chạy claude-1), trích các khách tương ứng với ảnh dữ liệu đầu vào",
          "Cột ma_dong_goc cho biết khách này gồm những dòng gốc nào: nhờ đó hoàn tác được. R080 và R305 (cùng SĐT, khác tên) KHÔNG bị gộp; R004/R018 và R007/R109 cũng không.",
          table(["ma_khach", "ho_ten", "sdt", "sdt_khac", "email", "dia_chi", "ma_dong_goc", "ghi_chu"], rows),
          "Dữ liệu GIẢ để học. Dựng lại từ file kết quả thật của lần chạy claude-1 (ket-qua/claude-1/danh-ba-sach.xlsx), cắt chọn vài dòng."), "08-ket-qua-danh-ba-sach.png", 1540)

# ---------- 09: danh sách cần quyết
rv = list(csv.DictReader((B / "ket-qua/claude-1/nghi-trung-can-quyet.csv").read_text(encoding="utf-8-sig").splitlines()))
pk = [rv[0], rv[2]] + [r for r in rv if r["quy_tac"] == "Q2"][:3]
shot(page("Kết quả: nghi-trung-can-quyet.csv (claude-1), trích 5 trong 25 nhóm",
          "Đây là việc cần NGƯỜI làm: script không tự gộp, chỉ nêu lý do và gợi ý. Người duyệt gọi điện/ hỏi khách rồi mới quyết.",
          table(["nhom", "ma_dong_goc", "quy_tac", "ly_do", "goi_y"], [[r["nhom"], r["ma_dong_goc"], r["quy_tac"], r["ly_do"], r["goi_y"]] for r in pk]),
          "Dữ liệu GIẢ để học. Trích từ ket-qua/claude-1/nghi-trung-can-quyet.csv."), "09-ket-qua-nghi-trung.png", 1540)

# ---------- 10: bảng chấm
labs = [("claude-1", "claude lần 1 (có log)"), ("agy-1", "agy lần 1 (có log)"), ("claude-0-mat-log", "claude lần 0 (mất log gốc)"), ("agy-0-mat-log", "agy lần 0 (mất log gốc)")]
tab = [
    ("Nhóm gộp chắc đúng trọn vẹn / 52", lambda r: f"{r['gop_chac']['gop_dung_tron_ven']}/52", "52/52"),
    ("Cặp bị gộp nhầm (người khác nhau)", lambda r: str(r["gop_nham"]["tong_cap_nham"]), "0"),
    ("Ca CẦN NGƯỜI QUYẾT báo đúng và không tự gộp / 25", lambda r: f"{r['ca_can_nguoi_quyet']['bao_dung_va_khong_gop']}/25", "25/25"),
    ("Ca cần quyết bị bỏ sót (không báo)", lambda r: str(len(r["ca_can_nguoi_quyet"]["bo_sot_khong_bao"])), "0"),
    ("SĐT đúng trong bản sạch", lambda r: r["truong"]["sdt_dung"], "ALL"),
    ("Email đúng trong bản sạch", lambda r: r["truong"]["email_dung"], "ALL"),
    ("Địa chỉ khớp sau khi mở viết tắt", lambda r: r["truong"]["dia_chi_khop_sau_mo_viet_tat"], "ALL"),
    ("Tên đúng (bỏ dấu, hoa/thường)", lambda r: r["truong"]["ten_dung_chu_khong_dau"], "ALL"),
    ('SĐT / email "lạ" (bịa hoặc đoán)', lambda r: f"{r['bia_hoac_doan']['sdt_la']} / {r['bia_hoac_doan']['email_la']}", "0 / 0"),
    ("Mỗi dòng gốc có đúng 1 dòng trong nhật ký gộp", lambda r: "đạt" if not (r["phu_dong"]["thieu"] or r["phu_dong"]["trung"]) else "trượt", "đạt"),
    ("Chạy lại lam_sach.py ra file giống từng byte", lambda r: "đạt" if all(r["chay_lai_script"]["giong_het"].values()) else "trượt", "đạt"),
    ("File gốc không bị sửa", lambda r: "đạt" if r["file_goc_nguyen_ven"] else "trượt", "đạt"),
]
def score_table(first, cols, tab):
    body = f"<table><tr><th>{esc(first)}</th>" + "".join(f"<th>{esc(l)}</th>" for _, l, _r in cols) + "</tr>"
    for name, f, good in tab:
        body += f"<tr><td>{esc(name)}</td>"
        for _, _l, rep in cols:
            v = f(rep)
            ok = (v.split("/")[0] == v.split("/")[1]) if good == "ALL" else v == good
            body += f'<td class="{"ok" if ok else "bad"}">{esc(v)}</td>'
        body += "</tr>"
    return body + "</table>"
cols10 = [(k, l, REP[k]) for k, l in labs]
shot(page('Bảng chấm 4 lần chạy (n = 2 mỗi agent; 2 lần "mất log" chỉ còn file kết quả)',
          "Ô đỏ = chưa đúng đáp án. Ô xanh = khớp đáp án. Không dùng để xếp hạng hai agent: chỉ 1-2 lần chạy mỗi bên.",
          score_table("Chỉ số (chấm bằng cham.py + dap-an.json)", cols10, tab),
          "Dữ liệu GIẢ: 400 dòng, 52 nhóm gộp chắc (đáp án còn 342 dòng khách), 25 ca cần quyết, 23 cặp không được gộp. Chấm bằng ket-qua/cham.py, ngày 2026-11-20."), "10-bang-cham.png", 1540)

# ---------- 11: hai lỗi thật
r322 = GOC["R322"]; a = kh("agy-1", "R322"); c = kh("claude-1", "R322")
sua = [x for x in csv.DictReader((B / "ket-qua/agy-1/nhat-ky-sua.csv").read_text(encoding="utf-8-sig").splitlines()) if x["ma_dong_goc"] == "R322"]
b1 = ("<h4>Lỗi 1 (agy lần 1): mất một SĐT hợp lệ</h4>" + table(["Dòng gốc", "SĐT gốc", "Email gốc"], [["R322", r322[3], r322[4]]]) +
      table(["Bản sạch", "ho_ten", "sdt", "email"], [["agy-1 (KH284)", a["ho_ten"], a["sdt"], a["email"]], ["claude-1", c["ho_ten"], c["sdt"], c["email"]]], ["bad", "ok"]) +
      "<h4>Các dòng nhật ký sửa của agy cho R322 (nhờ nhật ký mà truy ra được nguyên nhân)</h4>" +
      table(["ma_dong_goc", "cot", "gia_tri_cu", "gia_tri_moi", "quy_tac"], [[x["ma_dong_goc"], x["cot"], x["gia_tri_cu"], x["gia_tri_moi"], x["quy_tac"]] for x in sua]))
d = kh("claude-1", "R203"); d2 = kh("agy-1", "R203")
b2 = ('<h4>Lỗi 2 (claude lần 1): "DN" (ĐN không dấu) không được mở thành Đà Nẵng</h4>' + table(["Dòng gốc R203", "Địa chỉ gốc"], [["Shopee", GOC["R203"][5]]]) +
      table(["Bản sạch", "dia_chi"], [["claude-1", d["dia_chi"]], ["agy-1", d2["dia_chi"]]], ["bad", "ok"]))
shot(page("Hai lỗi thật gặp khi chấm (dữ liệu giả)", 'Mỗi lỗi nhỏ, nhưng đúng loại mà "đọc lướt báo cáo" sẽ không thấy.', b1 + b2,
          "Dựng lại từ ket-qua/agy-1, ket-qua/claude-1; không phải ảnh chụp cửa sổ TUI."), "11-loi-that.png", 1540)

# ---------- 12: đợt dữ liệu mới
rows12 = [
    ("Nhóm gộp chắc đúng trọn vẹn / 52", lambda r: f"{r['gop_chac']['gop_dung_tron_ven']}/52", "52/52"),
    ("Cặp bị gộp nhầm", lambda r: str(r["gop_nham"]["tong_cap_nham"]), "0"),
    ("Ca cần người quyết được báo / 25", lambda r: f"{r['ca_can_nguoi_quyet']['bao_dung_va_khong_gop']}/25", "25/25"),
    ("SĐT đúng trong bản sạch", lambda r: r["truong"]["sdt_dung"], "ALL"),
    ("Email đúng", lambda r: r["truong"]["email_dung"], "ALL"),
    ("Địa chỉ khớp sau khi mở viết tắt", lambda r: r["truong"]["dia_chi_khop_sau_mo_viet_tat"], "ALL"),
    ('SĐT/email "lạ" (bịa hoặc đoán)', lambda r: f"{r['bia_hoac_doan']['sdt_la']} / {r['bia_hoac_doan']['email_la']}", "0 / 0"),
]
cols12 = [("", "Đợt 1: claude", REP["claude-1"]), ("", "Đợt 1: agy", REP["agy-1"]), ("", "Đợt 2 (dữ liệu mới): claude", REP2["claude-1"]), ("", "Đợt 2 (dữ liệu mới): agy", REP2["agy-1"])]
shot(page("Chạy lại đúng script cũ trên một đợt dữ liệu mới (hạt giống 20261201)", "Không sửa script, không gọi lại agent. Ô đỏ = chưa đúng đáp án của đợt đó.",
          score_table("Chỉ số", cols12, rows12), "Dữ liệu GIẢ. Chấm bằng cham.py với đáp án của từng đợt. Mỗi script chạy 1 lần trên đợt 2; chưa đo độ ổn định."), "12-dot-2-du-lieu-moi.png", 1440)
