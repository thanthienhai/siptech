# -*- coding: utf-8 -*-
"""
tinh_bao_gia.py - Lập báo giá NHÁP cho 12 yêu cầu R01..R12 (công ty giả An Phát Demo).

Mọi phép tính tiền do code này làm (số nguyên + Decimal, làm tròn 0,5 lên):
  tra bậc giá -> thành tiền -> chiết khấu -> phí giao -> VAT -> tổng cộng
rồi điền GIÁ TRỊ SỐ (không công thức) vào bản sao của mau-bao-gia.xlsx.
Cùng script cũng sinh Rxx-email.txt, Rxx-cau-hoi.txt và chạy kiểm tra cuối (hàm kiem_tra).

Chạy:  python tinh_bao_gia.py            (lập + kiểm tra + in bảng tóm tắt)
       python tinh_bao_gia.py --kiem-tra (chỉ kiểm tra các file đã có)
Chỉ đọc/ghi trong thư mục chứa script; không gửi gì ra ngoài.
"""
import re
import sys
import math
import datetime
import unicodedata
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import openpyxl
from openpyxl.styles import Alignment

BASE = Path(__file__).resolve().parent
OUT = BASE / "dau-ra"

# ---------------------------------------------------------------- hằng số chính sách
# (lấy từ chinh-sach-chiet-khau.docx và dieu-kien-giao-hang.txt; không có dạng máy đọc được)
NHOM_THIET_BI = "Thiết bị"
CK_THEO_DON = [(30_000_000, 4), (10_000_000, 2)]   # (từ giá trị đơn, % chiết khấu) - sắp giảm dần
NV_THEM_TOI_DA = 2                                  # % NV được đồng ý thêm
NV_TONG_TOI_DA = 5                                  # % tổng (theo đơn + thêm) NV được tự quyết
NGUONG_MIEN_PHI = 3_000_000                         # nội thành: sau chiết khấu, trước VAT
PHI_NOI_THANH = 40_000
HIEU_LUC_VAT_GHI_CHU = "mức VAT theo tham số, cần kiểm với kế toán trước khi gửi"
VAT_TXT = None  # gán sau khi đọc tham số
HANG_DOI_XAC_NHAN = ("Đặt hàng", "Tạm hết hàng, chờ nhập")


# ---------------------------------------------------------------- tiện ích
def lam_tron(x):
    """Làm tròn đến đồng, 0,5 làm tròn lên."""
    return int(Decimal(x).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def fmt(n):
    return f"{int(n):,}".replace(",", ".")


def bo_dau(s):
    s = unicodedata.normalize("NFD", s.replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


# ---------------------------------------------------------------- đọc dữ liệu gốc
def doc_bang_gia():
    ws = openpyxl.load_workbook(BASE / "bang-gia.xlsx", data_only=True)["BangGia"]
    bg = {}
    for r in ws.iter_rows(min_row=4, values_only=True):
        if not r[0]:
            continue
        ma, ten, nhom, dvt, g1, t2, g2, t3, g3, kho = r[:10]
        bg[ma] = dict(ma=ma, ten=ten, nhom=nhom, dvt=dvt, kho=kho,
                      bac=[(1, g1), (t2, g2), (t3, g3)])
    return bg


def doc_quy_doi():
    ws = openpyxl.load_workbook(BASE / "bang-gia.xlsx", data_only=True)["QuyDoi"]
    qd = {}
    for r in ws.iter_rows(min_row=3, values_only=True):
        if r[0]:
            qd[(r[0], r[1].strip().lower())] = int(r[2])
    return qd


def doc_tham_so():
    ws = openpyxl.load_workbook(BASE / "mau-bao-gia.xlsx", data_only=True)["Tham số"]
    ts = {r[0]: r[1] for r in ws.iter_rows(min_row=2, values_only=True) if r[0]}
    ngay = datetime.date.fromisoformat(str(ts["ngay_bao_gia"])[:10])
    return dict(vat=Decimal(str(ts["vat_percent"])), ngay=ngay, hieu_luc=int(ts["hieu_luc_ngay"]))


def doc_khu_vuc_noi_thanh():
    """Đọc danh sách quận nội thành từ dieu-kien-giao-hang.txt (không tự bịa)."""
    txt = (BASE / "dieu-kien-giao-hang.txt").read_text(encoding="utf-8")
    hn, hcm = [], []
    for line in txt.splitlines():
        s = line.strip()
        if s.startswith("Hà Nội:"):
            s = s.split("các quận", 1)[1].strip().rstrip(".")
            hn = [x.strip() for x in s.split(",")]
        elif s.startswith("TP. Hồ Chí Minh:"):
            s = s.split(":", 1)[1].strip().rstrip(".")
            hcm = [x.strip() for x in s.split(",")]
    return hn, hcm


BANG_GIA = doc_bang_gia()
QUY_DOI = doc_quy_doi()
THAM_SO = doc_tham_so()
HN, HCM = doc_khu_vuc_noi_thanh()
VAT_TXT = format(THAM_SO["vat"].normalize(), "f")


def phan_loai_khu_vuc(dia_chi):
    """'noi_thanh' | 'ngoai_tinh' | 'chua_biet' theo danh sách trong dieu-kien-giao-hang.txt."""
    if not dia_chi:
        return "chua_biet"
    s = " " + bo_dau(dia_chi) + " "
    in_hn = re.search(r"ha noi|\bhn\b", s) is not None
    in_hcm = re.search(r"ho chi minh|\bhcm\b|tphcm|tp\.hcm", s) is not None

    def khop(ten):
        t = bo_dau(ten)
        m = re.match(r"quan (\d+)$", t)
        if m:  # "Quận 1" không được khớp "Quận 10"
            return re.search(rf"quan {m.group(1)}(?!\d)", s) is not None
        return re.search(rf"(?<![a-z]){re.escape(t)}(?![a-z])", s) is not None

    if in_hn and any(khop(q) for q in HN):
        return "noi_thanh"
    if in_hcm and any(khop(q) for q in HCM):
        return "noi_thanh"
    return "ngoai_tinh"


# ---------------------------------------------------------------- lõi tính tiền
def tra_bac(ma, sl):
    """Trả về (đơn giá, số bậc, ngưỡng bậc) theo số lượng CỦA CHÍNH MÃ ĐÓ (đơn vị gốc)."""
    bac = BANG_GIA[ma]["bac"]
    chon = 0
    for i, (tu, _gia) in enumerate(bac):
        if sl >= tu:
            chon = i
    return bac[chon][1], chon + 1, bac[chon][0]


def quy_doi(ma, sl, dvt):
    """Quy đổi về ĐVT gốc; chỉ khi sheet QuyDoi có. Trả về (sl_gốc, hệ_số hoặc None)."""
    goc = BANG_GIA[ma]["dvt"]
    d = dvt.strip().lower()
    if d == goc.lower():
        return sl, None
    if (ma, d) in QUY_DOI:
        h = QUY_DOI[(ma, d)]
        return sl * h, h
    raise ValueError(f"{ma}: không có quy đổi '{dvt}' -> '{goc}' trong sheet QuyDoi")


def tinh_bao_gia(dong, dia_chi=None, xin=None):
    """
    dong: [(mã, số lượng, đơn vị khách ghi, ghi chú thêm?)]  - số lượng theo đơn vị khách ghi.
    xin : None | ('them', pct) | ('tong', pct)  - khách xin giảm.
    """
    gop = {}   # gộp dòng trùng theo mã, SAU khi quy đổi về ĐVT gốc
    for d in dong:
        ma, sl, dvt = d[0], d[1], d[2]
        ghi = d[3] if len(d) > 3 else ""
        sl_goc, he_so = quy_doi(ma, sl, dvt)
        g = gop.setdefault(ma, dict(ma=ma, sl=0, tp=[], ghi=[]))
        g["sl"] += sl_goc
        g["tp"].append((sl, dvt, he_so))
        if ghi:
            g["ghi"].append(ghi)

    ds = []
    for g in gop.values():
        b = BANG_GIA[g["ma"]]
        don_gia, bac, tu = tra_bac(g["ma"], g["sl"])
        thanh_tien = g["sl"] * don_gia
        goc = b["dvt"]
        # ghi chú dòng
        ghi = []
        if len(g["tp"]) > 1:
            phan = [f"{sl} {dvt}" if he_so is None else f"{sl} {dvt} (= {sl * he_so} {goc})"
                    for sl, dvt, he_so in g["tp"]]
            ghi.append(f"Gộp: {' + '.join(phan)} = {g['sl']} {goc}")
        elif g["tp"][0][2] is not None:
            sl, dvt, he_so = g["tp"][0]
            ghi.append(f"{sl} {dvt} = {sl * he_so} {goc}")
        ghi.append(f"Giá bậc {bac}" + (f" (từ {tu} {goc})" if bac > 1 else ""))
        if b["kho"] != "Còn hàng":
            ghi.append(f"Kho: {b['kho']} - ngày có hàng do kho/phòng mua hàng xác nhận")
        ghi += g["ghi"]
        ds.append(dict(ma=g["ma"], ten=b["ten"], dvt=goc, sl=g["sl"], don_gia=don_gia,
                       thanh_tien=thanh_tien, nhom=b["nhom"], ghi="; ".join(ghi)))

    cong_tien_hang = sum(x["thanh_tien"] for x in ds)
    co_ck = sum(x["thanh_tien"] for x in ds if x["nhom"] != NHOM_THIET_BI)
    co_thiet_bi = any(x["nhom"] == NHOM_THIET_BI for x in ds)

    # --- chiết khấu
    pct_don = next((p for nguong, p in CK_THEO_DON if cong_tien_hang >= nguong), 0)
    cho_phep_them = max(0, min(NV_THEM_TOI_DA, NV_TONG_TOI_DA - pct_don))
    them, cho_quyet_pct = 0, 0
    if xin:
        kieu, p = xin
        if kieu == "them":
            them = min(p, cho_phep_them)
            cho_quyet_pct = p - them
        elif kieu == "tong":
            if p <= NV_TONG_TOI_DA:
                raise NotImplementedError("chưa có ca khách xin tổng <= 5%")
            them, cho_quyet_pct = 0, p   # vượt thẩm quyền: chỉ áp phần theo đơn
    pct_ap = pct_don + them
    chiet_khau = lam_tron(Decimal(co_ck) * Decimal(pct_ap) / Decimal(100))  # làm tròn MỘT lần

    # --- phí giao
    khu_vuc = phan_loai_khu_vuc(dia_chi)
    sau_ck = cong_tien_hang - chiet_khau
    if khu_vuc == "noi_thanh":
        phi = 0 if sau_ck >= NGUONG_MIEN_PHI else PHI_NOI_THANH
    else:
        phi = None   # ngoại tỉnh: theo thỏa thuận; chưa biết địa chỉ: chưa tính

    cong_truoc_vat = sau_ck + (phi or 0)
    vat = lam_tron(Decimal(cong_truoc_vat) * THAM_SO["vat"] / Decimal(100))
    tong = cong_truoc_vat + vat
    return dict(dong=ds, cong_tien_hang=cong_tien_hang, co_ck=co_ck, co_thiet_bi=co_thiet_bi,
                pct_don=pct_don, them=them, cho_quyet_pct=cho_quyet_pct, pct_ap=pct_ap,
                chiet_khau=chiet_khau, khu_vuc=khu_vuc, phi=phi, cong_truoc_vat=cong_truoc_vat,
                vat=vat, tong=tong, xin=xin)


# ---------------------------------------------------------------- dữ liệu 12 yêu cầu
# chua_bao   : [(câu cho báo giá xlsx, câu cho email)]  hàng chưa lập dòng
# cau_hoi    : [câu hỏi làm rõ]  ({xh} = cách xưng hô với khách)
# nguoi_quyet: [(lý do nội bộ cho xlsx, câu cho email - chỉ "sẽ có xác nhận", không hứa)]
# Trạng thái suy ra: có cau_hoi -> THIEU_THONG_TIN; có nguoi_quyet -> CAN_NGUOI_QUYET; không có -> SAN_SANG
YEU_CAU = {
    "R01": dict(
        nguon='Email lan.mua.hang@example.com - "Đề nghị báo giá VPP tháng 12"',
        tieu_de="Đề nghị báo giá VPP tháng 12",
        kinh_gui="Chị Lan - Phòng Hành chính, Công ty TNHH Cơ khí Ánh Dương",
        chao="chị Lan", xh="chị",
        dia_chi="12 Đường Số 5, Quận Hà Đông, Hà Nội",
        dong=[("GIAY-A4-80", 25, "ram"), ("BUT-BI-TL027-XANH", 3, "hộp"), ("BANGKEO-TRONG-48", 10, "cuộn")],
        xin=("them", 2),
        ghi_xin="Khách quen xin giảm 2%: nằm trong thẩm quyền nhân viên (tối đa 2%, tổng không quá 5%)",
        chua_bao=[], cau_hoi=[], nguoi_quyet=[],
    ),
    "R02": dict(
        nguon="Zalo - Dung Phat (anh)",
        tieu_de="Zalo - báo giá giấy A4 80 và mực HP 12A",
        kinh_gui="Anh Dung Phat (Zalo)",
        chao="anh Dung Phat", xh="anh",
        dia_chi=None,
        dong=[("MUC-HP-12A", 6, "hộp")],
        thieu_hang=True,
        chua_bao=[("GIAY-A4-80: khách chưa nêu số lượng - chưa lập dòng, chưa tính tiền",
                   "Giấy A4 80 gsm (mã GIAY-A4-80): {xh} chưa cho biết số lượng nên bên em chưa tính tiền được.")],
        cau_hoi=["{xh} cần bao nhiêu ram giấy A4 80 gsm (mã GIAY-A4-80)?",
                 "{xh} cho bên em xin địa chỉ giao hàng (số nhà, đường, quận/huyện, tỉnh/thành) để bên em tính phí giao?",
                 "{xh} cần báo giá trước chiều nay, hay cần nhận hàng trong chiều nay? (Nếu cần nhận hàng gấp thì bên em phải chuyển kho/quản lý xác nhận, chưa thể hứa thời gian.)"],
        nguoi_quyet=[("Khách ghi 'nhanh giúp anh, chiều anh cần' - nếu là giao gấp trong chiều nay thì phải do trưởng kho/giám đốc quyết (chờ khách trả lời câu hỏi 3)",
                      "Nếu {xh} cần nhận hàng gấp trong chiều nay: bên em đã ghi nhận và sẽ có xác nhận của kho; hiện chưa thể hứa thời gian giao.")],
    ),
    "R03": dict(
        nguon='Email hanh.vp@example.com - "bao gia"',
        tieu_de="bao gia",
        kinh_gui="Anh/chị (hanh.vp@example.com)",
        chao="anh/chị", xh="anh/chị",
        dia_chi="Tòa nhà Mẫu số 3 đường Demo, Quận Cầu Giấy, Hà Nội",
        dong=[("GIAY-A4-80", 10, "ram"), ("MUC-HP-12A", 3, "hộp")],
        thieu_hang=True,
        chua_bao=[("MUC-HP-12C (4 hộp): mã không có trong bảng giá - không tự đoán, hỏi lại khách",
                   "MUC-HP-12C (4 hộp): mã này không có trong bảng giá của bên em nên chưa báo giá."),
                  ("BUT-GEL-05-XANH (2 hộp): mã không có trong bảng giá (chỉ có BUT-GEL-05-DEN) - không tự thay hàng, hỏi lại khách",
                   "BUT-GEL-05-XANH (2 hộp, mực xanh): mã này không có trong bảng giá của bên em nên chưa báo giá.")],
        cau_hoi=["Mã MUC-HP-12C (4 hộp) không có trong bảng giá; {xh} đã đặt riêng MUC-HP-12A ở dòng 3 nên bên em không tự đoán thay mã. {xh} kiểm tra lại giúp bên em mã/dòng máy in cần mua?",
                 "Mã BUT-GEL-05-XANH (2 hộp) không có trong bảng giá; bên em hiện chỉ có bút gel mực đen 0.5 mm (BUT-GEL-05-DEN). {xh} xác nhận lại mã/màu mực giúp bên em, hoặc cho biết có muốn đổi sang mực đen không?"],
        nguoi_quyet=[],
    ),
    "R04": dict(
        nguon='Email mai.hanhchinh@example.com - "Báo giá thiết bị cho năm học mới"',
        tieu_de="Báo giá thiết bị cho năm học mới",
        kinh_gui="Anh/chị Mai - Hành chính (đơn vị trường học, mai.hanhchinh@example.com)",
        chao="anh/chị Mai", xh="anh/chị",
        dia_chi="25 Đường Mẫu, Quận 7, TP. Hồ Chí Minh",
        dong=[("GIAY-A4-70", 30, "ram")],
        thieu_hang=True,
        chua_bao=[("Máy photocopy A3 đa năng (1 cái) và máy chiếu 4K (2 cái): chưa có trong bảng giá - không tự đặt giá, không thay hàng khác",
                   "Máy photocopy A3 đa năng (1 cái) và máy chiếu độ phân giải 4K (2 cái): hiện chưa có trong bảng giá của bên em nên chưa báo giá được.")],
        cau_hoi=[],
        nguoi_quyet=[("Máy photocopy A3, máy chiếu 4K ngoài bảng giá - chuyển phòng mua hàng xem có nhập được không",
                      "Với máy photocopy A3 và máy chiếu 4K: bên em sẽ chuyển phòng mua hàng xem xét và sẽ có phản hồi/xác nhận sau."),
                     ("Khách 'cần gấp trong tuần' - giao gấp phải do trưởng kho/giám đốc quyết",
                      "Về yêu cầu cần gấp trong tuần: bên em đã ghi nhận và sẽ có xác nhận lịch giao của kho bằng văn bản; hiện chưa thể hứa.")],
    ),
    "R05": dict(
        nguon='Email quan.vt@example.com - "RE: báo giá máy in + vật tư"',
        tieu_de="RE: báo giá máy in + vật tư",
        kinh_gui="Anh/chị Quân (quan.vt@example.com)",
        chao="anh/chị", xh="anh/chị",
        dia_chi="88 Đường Demo, Quận Thanh Xuân, Hà Nội",
        dong=[("MAY-IN-LASER-3100", 3, "cái"), ("MUC-HP-78A", 10, "hộp"), ("GIAY-A4-80", 40, "ram")],
        xin=("tong", 25),
        ghi_xin="Khách xin giảm 25% tổng đơn (và chốt trong tuần): vượt thẩm quyền, chưa đồng ý",
        chua_bao=[], cau_hoi=[],
        nguoi_quyet=[("Khách xin giảm 25% tổng đơn (>5%, gồm cả dòng Thiết bị) - vượt thẩm quyền; báo giá chỉ áp chiết khấu theo đơn; chờ trưởng phòng/giám đốc quyết",
                      "Về đề nghị giảm 25% tổng đơn: bên em chưa thể đồng ý ở mức này; báo giá chỉ áp chiết khấu theo chính sách. Đề nghị của {xh} đã được ghi nhận, chuyển trưởng phòng/giám đốc xem xét và sẽ có xác nhận.")],
    ),
    "R06": dict(
        nguon="Zalo - Chị Thu (NT Phu Gia)",
        tieu_de="Zalo - báo giá văn phòng phẩm",
        kinh_gui="Chị Thu (NT Phu Gia, Zalo)",
        chao="chị Thu", xh="chị",
        dia_chi="5 Đường Mẫu, Quận 10, TP. Hồ Chí Minh",
        dong=[("GIAY-A4-70", 2, "thùng"), ("BUT-BI-TL027-XANH", 5, "tá"), ("BANGKEO-2MAT-24", 3, "lốc"),
              ("BUT-GEL-05-DEN", 2, "hộp")],
        thieu_hang=True,
        chua_bao=[("MUC-HP-12A (1 thùng): bảng quy đổi không có 'thùng' cho mã này - không tự suy ra, chưa lập dòng",
                   "Mực HP 12A (1 thùng): bên em chưa có quy đổi 'thùng' sang hộp cho mã MUC-HP-12A nên chưa tính được.")],
        cau_hoi=["1 thùng mực HP 12A là bao nhiêu hộp? (Bên em bán theo hộp và không có quy đổi 'thùng' cho mã MUC-HP-12A nên không tự suy ra.) {xh} cho bên em số hộp cần mua."],
        nguoi_quyet=[],
    ),
    "R07": dict(
        nguon='Email kien.kho@example.com - "Báo giá lại đợt trước"',
        tieu_de="Báo giá lại đợt trước",
        kinh_gui="Anh/chị Kiên - Kho (kien.kho@example.com)",
        chao="anh/chị Kiên", xh="anh/chị",
        dia_chi="15 Đường Mẫu, Quận Gò Vấp, TP. Hồ Chí Minh",
        dong=[("BUT-BI-TL027-XANH", 50, "cây"), ("SO-CARO-A4-200", 49, "quyển"), ("FILE-COC-7P", 100, "cái")],
        chua_bao=[], cau_hoi=[],
        nguoi_quyet=[("Khách đòi giữ giá cũ bút bi TL027 3.500đ/cây (anh Hùng báo tháng trước) - không tự giữ giá cũ; báo theo bảng giá hiện hành; chờ trưởng phòng kinh doanh quyết",
                      "Về mức giá 3.500đ/cây đã báo trước đó: bên em báo theo bảng giá hiện hành nêu trên; đề nghị giữ giá cũ của {xh} đã được ghi nhận, chuyển trưởng phòng kinh doanh xem xét và sẽ có xác nhận.")],
    ),
    "R08": dict(
        nguon='Email phuong.xuong@example.com - "Báo giá vật tư đóng gói - gấp"',
        tieu_de="Báo giá vật tư đóng gói - gấp",
        kinh_gui="Anh/chị Phương - Xưởng (phuong.xuong@example.com)",
        chao="anh/chị Phương", xh="anh/chị",
        dia_chi="Lô B2, Khu công nghiệp Mẫu, Bắc Ninh",
        dong=[("THUNG-CARTON-30X20X20", 300, "cái"), ("MANG-BOC-PE-50CM", 24, "cuộn"),
              ("BANGKEO-TRONG-48", 72, "cuộn")],
        chua_bao=[], cau_hoi=[],
        nguoi_quyet=[("Giao ngoại tỉnh (KCN Bắc Ninh): phí theo cước đơn vị vận chuyển, điều phối báo sau - không tự đặt số",
                      "Phí giao hàng đến Bắc Ninh: theo thỏa thuận, tính theo cước của đơn vị vận chuyển; bộ phận điều phối sẽ báo sau. Tổng cộng ở trên chưa gồm phí giao hàng."),
                     ("Khách đòi giao TRƯỚC 10 giờ sáng thứ Sáu, nếu không kịp sẽ huỷ đơn - giao đúng giờ/gấp do trưởng kho/giám đốc quyết, không hứa",
                      "Về yêu cầu giao trước 10 giờ sáng thứ Sáu: bên em đã ghi nhận nhưng chưa thể xác nhận; kho sẽ có xác nhận lịch giao bằng văn bản.")],
    ),
    "R09": dict(
        nguon="Zalo - Chu Son (chú)",
        tieu_de="Zalo - báo giá như đợt trước",
        kinh_gui="Chú Chu Son (Zalo)",
        chao="chú", xh="chú",
        dia_chi=None, ghi_dia_chi="Khách ghi 'giao cho chỗ cũ' - chưa có địa chỉ cụ thể, cần hỏi lại",
        dong=[],
        thieu_hang=True,
        chua_bao=[("Chưa có mặt hàng, số lượng, địa chỉ giao: khách chỉ ghi 'như đợt trước, số lượng tăng gấp đôi' - không có dữ liệu đợt trước nên chưa lập dòng nào",
                   "Bên em chưa có thông tin đợt trước trong yêu cầu này nên chưa thể lập báo giá dòng hàng nào.")],
        cau_hoi=["{xh} cho bên em biết danh sách mặt hàng cần báo giá (mã hàng hoặc tên hàng)?",
                 "Số lượng từng mặt hàng là bao nhiêu (đợt này tăng gấp đôi so với đợt trước thì cụ thể là bao nhiêu)?",
                 "Địa chỉ giao hàng cụ thể (số nhà, đường, quận/huyện, tỉnh/thành) ở đâu? Bên em chưa xác định được 'chỗ cũ'.",
                 "{xh} muốn báo theo bảng giá hiện hành, hay muốn giữ mức giá đợt trước? (Bên em báo theo bảng giá hiện hành; việc giữ giá cũ phải do trưởng phòng kinh doanh quyết.)"],
        nguoi_quyet=[],
    ),
    "R10": dict(
        nguon="Zalo - Ngọc SaoMai",
        tieu_de="Zalo - list báo giá",
        kinh_gui="Anh/chị Ngọc SaoMai (Zalo)",
        chao="anh/chị Ngọc SaoMai", xh="anh/chị",
        dia_chi="30 Đường Demo, Cầu Giấy, Hà Nội",
        dong=[("MUC-HP-78A", 4, "hộp"), ("MUC-HP-78A", 2, "hộp"), ("GIAY-A4-70", 10, "ram"),
              ("MAY-HUY-GIAY-S12", 1, "cái"), ("GHE-XOAY-LUOI-01", 6, "cái"),
              ("MUC-EPS-664-DEN", 12, "chai", "Khách ghi 'mực epson 664 đen 12 chai', khớp mã dòng 664 màu đen"),
              ("GIAY-A4-70", 1, "thùng")],
        xin=("them", 2),
        ghi_xin="Khách xin giảm thêm 2%: trong thẩm quyền (2% theo đơn + 2% thêm = 4%, không quá 5%); chỉ áp cho dòng không thuộc nhóm Thiết bị",
        luu_y=["Mực nước máy in phun đen 70ml (dòng 664, mã MUC-EPS-664-DEN): bên em hiểu là mực Epson 664 đen {xh} cần; nếu khác xin báo lại giúp bên em."],
        chua_bao=[], cau_hoi=[], nguoi_quyet=[],
    ),
    "R11": dict(
        nguon='Email hung.mua@example.com - "Báo giá trang bị văn phòng mới (đợt lớn)"',
        tieu_de="Báo giá trang bị văn phòng mới (đợt lớn)",
        kinh_gui="Anh/chị Hùng (hung.mua@example.com)",
        chao="anh/chị Hùng", xh="anh/chị",
        dia_chi="200 Đường Mẫu, Quận Hoàng Mai, Hà Nội",
        dong=[("MAY-IN-LASER-3100", 6, "cái"), ("MAY-SCAN-A4-100", 2, "cái"),
              ("CC-VANTAY-01", 4, "cái", "Khách ghi 'máy chấm công vân tay' (không nêu mẫu); bảng giá chỉ có mẫu 01"),
              ("GIAY-A4-80", 60, "ram"), ("MUC-CANON-325", 12, "hộp")],
        xin=("tong", 10),
        ghi_xin="Khách xin giảm 10% toàn đơn (vượt 5%, gồm dòng Thiết bị): chưa đồng ý",
        luu_y=["Máy chấm công vân tay: bảng giá hiện chỉ có mẫu 01 nên bên em báo giá theo mẫu này; nếu {xh} cần mẫu khác xin cho bên em biết."],
        chua_bao=[], cau_hoi=[],
        nguoi_quyet=[("Khách xin giảm 10% toàn đơn (>5%, gồm cả dòng Thiết bị) - vượt thẩm quyền; báo giá chỉ áp chiết khấu theo đơn; chờ trưởng phòng/giám đốc quyết",
                      "Về đề nghị giảm 10% toàn đơn: bên em chưa thể đồng ý ở mức này; báo giá chỉ áp chiết khấu theo chính sách. Đề nghị của {xh} đã được ghi nhận, chuyển trưởng phòng/giám đốc xem xét và sẽ có xác nhận."),
                     ("Khách xin mua 10 ram giấy tặng 1 ram - quà tặng/khuyến mại chỉ giám đốc quyết",
                      "Về đề nghị mua 10 ram tặng 1 ram: bên em đã ghi nhận, chuyển giám đốc xem xét và sẽ có xác nhận; hiện chưa thể đồng ý.")],
    ),
    "R12": dict(
        nguon="Zalo - Vy Sohong",
        tieu_de="Zalo - báo giá giấy, bút, decal...",
        kinh_gui="Anh/chị Vy Sohong (Zalo)",
        chao="anh/chị Vy Sohong", xh="anh/chị",
        dia_chi="7 Đường Mẫu, Quận Bắc Từ Liêm, Hà Nội",
        dong=[("GIAY-A4-70", 5, "thùng"), ("BUT-BI-TL027-XANH", 2, "tá"), ("DECAL-A4-100", 3, "xấp"),
              ("MANG-BOC-PE-50CM", 2, "cuộn"), ("KEP-BUOM-32", 4, "hộp")],
        chua_bao=[],
        cau_hoi=["Để xuất hóa đơn công ty, {xh} vui lòng cung cấp tên công ty, mã số thuế và địa chỉ xuất hóa đơn."],
        nguoi_quyet=[("Khách xin công nợ 30 ngày - chỉ giám đốc duyệt; điều kiện mặc định là chuyển khoản trước khi giao",
                      "Về đề nghị công nợ 30 ngày: bên em đã ghi nhận, chuyển cấp có thẩm quyền xem xét và sẽ có xác nhận; hiện chưa thể đồng ý. Điều kiện mặc định là chuyển khoản trước khi giao hàng.")],
    ),
}


def trang_thai(yc):
    t = []
    if yc["cau_hoi"]:
        t.append("THIEU_THONG_TIN")
    if yc["nguoi_quyet"]:
        t.append("CAN_NGUOI_QUYET")
    return t or ["SAN_SANG"]


def xh(s, yc):
    s = s.replace("{xh}", yc["xh"])
    return re.sub(r"(^|[.?!]\)? )(anh/chị|chị|anh|chú)", lambda m: m.group(1) + m.group(2)[0].upper() + m.group(2)[1:], s)


# ---------------------------------------------------------------- ghi chú các dòng tổng
def ghi_chu_tong(yc, kq):
    n = {}
    n["hang"] = ""
    if yc.get("chua_bao"):
        n["hang"] = "Chưa gồm các mục chưa báo giá (xem phần ghi chú phía trên bảng)"
    # chiết khấu
    parts = []
    if kq["pct_don"]:
        khoang = "từ 30.000.000 đ" if kq["pct_don"] == 4 else "từ 10.000.000 đến dưới 30.000.000 đ"
        parts.append(f"{kq['pct_don']}% theo giá trị đơn ({khoang}; đơn của khách {fmt(kq['cong_tien_hang'])} đ)")
    if kq["them"]:
        parts.append(f"{kq['them']}% thêm theo đề nghị của khách (trong thẩm quyền nhân viên)")
    if kq["pct_ap"]:
        s = (f"Tổng {kq['pct_ap']}% = " if len(parts) > 1 else "") + " + ".join(parts) + f", tính trên {fmt(kq['co_ck'])} đ tiền hàng các dòng không thuộc nhóm Thiết bị"
        if kq["co_thiet_bi"]:
            s += "; dòng Thiết bị giữ giá bảng giá"
    else:
        s = "Không có chiết khấu: đơn dưới 10.000.000 đ"
        if not kq["co_ck"] and kq["co_thiet_bi"]:
            s += " / chỉ có dòng Thiết bị"
    if kq["cho_quyet_pct"] and kq["xin"]:
        kieu, p = kq["xin"]
        s += f". Khách xin {'thêm ' if kieu == 'them' else ''}{p}%: phần vượt thẩm quyền chưa đồng ý, CHỜ NGƯỜI QUYẾT"
    elif kq["them"]:
        s += f". Khách xin giảm {kq['xin'][1]}%: nằm trong thẩm quyền nhân viên (mỗi lần thêm tối đa 2%, tổng không quá 5%)"
    n["ck"] = s
    # phí giao
    k = kq["khu_vuc"]
    if k == "noi_thanh":
        if kq["phi"]:
            s = f"Nội thành; đơn sau chiết khấu dưới 3.000.000 đ nên thu {fmt(PHI_NOI_THANH)} đ/đơn"
        else:
            s = "Nội thành; đơn sau chiết khấu từ 3.000.000 đ nên miễn phí giao hàng"
        if yc.get("thieu_hang"):
            s += "; tạm tính theo phần hàng đã báo giá, sẽ tính lại khi đủ hàng"
        s += "; kế toán kiểm cách tính thuế cho dòng phí"
    elif k == "ngoai_tinh":
        s = "Phí giao hàng theo thỏa thuận (ngoại tỉnh, theo cước đơn vị vận chuyển) - CHỜ NGƯỜI QUYẾT; chưa tính vào tổng cộng"
    else:
        s = "Chưa biết địa chỉ giao hàng nên chưa tính phí giao hàng - cần hỏi khách"
    n["phi"] = s
    n["truoc_vat"] = "Cộng tiền hàng - chiết khấu + phí giao hàng" + ("" if kq["phi"] is not None else " (chưa có phí giao hàng)")
    n["vat"] = f"{VAT_TXT}% - {HIEU_LUC_VAT_GHI_CHU}"
    n["tong"] = "Giá trị sau VAT" + ("; chưa gồm phí giao hàng" if kq["phi"] is None else "")
    return n


# ---------------------------------------------------------------- điền mẫu xlsx
def dong_cao(text, rong):
    return max(1, math.ceil(len(text) / rong))


def lap_xlsx(rid, yc, kq, tt):
    wb = openpyxl.load_workbook(BASE / "mau-bao-gia.xlsx")   # bản sao của mẫu
    ws = wb["Báo giá"]
    ngay = THAM_SO["ngay"]
    ws["B5"] = yc["kinh_gui"]
    ws["B6"] = yc["dia_chi"] or yc.get("ghi_dia_chi") or "(chưa có - cần hỏi khách)"
    ws["B7"] = f"{rid} - {yc['nguon']}"
    ws["B8"] = f"{ngay.strftime('%d/%m/%Y')} / hiệu lực {THAM_SO['hieu_luc']} ngày kể từ ngày báo giá"
    ws["B9"] = ";".join(tt)
    ws["C9"] = None            # bỏ dòng hướng dẫn của mẫu để trạng thái không bị che
    # dòng hàng: mẫu có sẵn 15 dòng (14..28)
    assert len(kq["dong"]) <= 15, "nhiều hơn 15 dòng hàng - cần mở rộng mẫu"
    for i, d in enumerate(kq["dong"]):
        r = 14 + i
        ws.cell(r, 1, i + 1)
        ws.cell(r, 2, d["ma"])
        ws.cell(r, 3, d["ten"])
        ws.cell(r, 4, d["dvt"])
        ws.cell(r, 5, d["sl"]).number_format = "#,##0"
        ws.cell(r, 6, d["don_gia"]).number_format = "#,##0"
        ws.cell(r, 7, d["thanh_tien"]).number_format = "#,##0"
        ws.cell(r, 8, d["ghi"])
        for c in (2, 3, 8):
            ws.cell(r, c).alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[r].height = 15 * max(dong_cao(d["ghi"], 38), dong_cao(d["ten"], 42))
    # ghi chú các mục chưa báo giá / chờ người quyết / cần hỏi (hai dòng trống 11, 12 của mẫu)
    a11 = "; ".join(x[0] for x in yc["chua_bao"])
    a12 = []
    if yc["nguoi_quyet"]:
        a12.append("CHỜ NGƯỜI QUYẾT: " + " | ".join(x[0] for x in yc["nguoi_quyet"]))
    if yc["cau_hoi"]:
        a12.append(f"CẦN HỎI KHÁCH: {len(yc['cau_hoi'])} câu (xem {rid}-cau-hoi.txt)")
    for r, txt, pre in ((11, a11, "Chưa báo giá: "), (12, " ; ".join(a12), "")):
        if txt:
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=8)
            ws.cell(r, 1, pre + txt).alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[r].height = 15 * dong_cao(pre + txt, 150)
    # dòng tổng (số, không công thức)
    n = ghi_chu_tong(yc, kq)
    tong = {29: (kq["cong_tien_hang"], n["hang"]), 30: (kq["chiet_khau"], n["ck"]),
            31: (kq["phi"], n["phi"]), 32: (kq["cong_truoc_vat"], n["truoc_vat"]),
            33: (kq["vat"], n["vat"]), 34: (kq["tong"], n["tong"])}
    for r, (val, ghi) in tong.items():
        c = ws.cell(r, 7, val)
        c.number_format = "#,##0"
        if ghi:
            ws.cell(r, 8, ghi).alignment = Alignment(wrap_text=True, vertical="top")
            ws.row_dimensions[r].height = 15 * dong_cao(ghi, 38)
    OUT.mkdir(exist_ok=True)
    wb.save(OUT / f"{rid}-bao-gia.xlsx")


# ---------------------------------------------------------------- email + câu hỏi
def lap_email(rid, yc, kq, tt):
    xhd = yc["xh"]
    L = []
    L.append(f"Tiêu đề: Báo giá - phản hồi yêu cầu {rid} (RE: {yc['tieu_de']})")
    L.append("[EMAIL NHÁP - chờ người duyệt, CHƯA GỬI]")
    L.append("")
    L.append(f"Chào {yc['chao']},")
    L.append("")
    L.append(f"Cảm ơn {xhd} đã gửi yêu cầu báo giá cho An Phát. Bên em xin phản hồi như sau.")
    muc = iter(range(1, 9))
    if kq["dong"]:
        L.append("")
        L.append(f"{next(muc)}) Phần đã báo giá (giá chưa gồm VAT):")
        for d in kq["dong"]:
            L.append(f"- {d['ten']} ({d['ma']}): {d['sl']} {d['dvt']} x {fmt(d['don_gia'])} = {fmt(d['thanh_tien'])} đ")
        L.append(f"Cộng tiền hàng: {fmt(kq['cong_tien_hang'])} đ")
        if kq["pct_ap"]:
            L.append(f"Chiết khấu {kq['pct_ap']}%: -{fmt(kq['chiet_khau'])} đ")
        else:
            L.append("Chiết khấu: 0 đ")
        if kq["phi"] is None:
            L.append("Phí giao hàng: " + ("theo thỏa thuận (chưa tính vào tổng cộng)" if kq["khu_vuc"] == "ngoai_tinh"
                                         else "chưa tính vì chưa có địa chỉ giao hàng"))
        else:
            L.append(f"Phí giao hàng: {fmt(kq['phi'])} đ" + (" (miễn phí)" if kq["phi"] == 0 else ""))
        L.append(f"Cộng trước VAT: {fmt(kq['cong_truoc_vat'])} đ")
        L.append(f"VAT {VAT_TXT}% [{HIEU_LUC_VAT_GHI_CHU}]: {fmt(kq['vat'])} đ")
        L.append(f"Tổng cộng: {fmt(kq['tong'])} đ")
        # câu về chiết khấu
        if kq["them"]:
            tb = " Máy/thiết bị trong đơn giữ giá bảng giá theo chính sách." if kq["co_thiet_bi"] else ""
            gom = (f" (gồm {kq['pct_don']}% theo giá trị đơn và {kq['them']}% theo đề nghị của {xhd})"
                   if kq["pct_don"] else f" theo đề nghị của {xhd}")
            L.append(f"Về chiết khấu: bên em áp tổng {kq['pct_ap']}%{gom}, tính trên các mặt hàng không thuộc nhóm thiết bị.{tb}")
        elif kq["pct_don"]:
            tb = " Thiết bị giữ giá bảng giá theo chính sách." if kq["co_thiet_bi"] else ""
            L.append(f"Về chiết khấu: {kq['pct_don']}% theo giá trị đơn, tính trên các mặt hàng không thuộc nhóm thiết bị.{tb}")
        if kq["khu_vuc"] == "noi_thanh" and kq["phi"] and yc.get("thieu_hang"):
            L.append("Phí giao hàng tạm tính theo phần hàng đã báo giá, sẽ tính lại khi đủ danh mục.")
        for lu in yc.get("luu_y", []):
            L.append(xh(lu, yc))
        ds_cho = [d for d in kq["dong"] if BANG_GIA[d["ma"]]["kho"] in HANG_DOI_XAC_NHAN]
        if ds_cho:
            ten = ", ".join(f"{d['ma']} ({BANG_GIA[d['ma']]['kho'].lower()})" for d in ds_cho)
            L.append(f"Lưu ý tình trạng kho: {ten}. Ngày có hàng sẽ do kho/phòng mua hàng xác nhận bằng văn bản.")
    if yc["chua_bao"]:
        L.append("")
        L.append(f"{next(muc)}) Phần chưa báo giá và lý do:")
        for x in yc["chua_bao"]:
            L.append("- " + xh(x[1], yc))
    if yc["cau_hoi"]:
        L.append("")
        L.append(f"{next(muc)}) Bên em cần {xhd} cho biết thêm:")
        for i, q in enumerate(yc["cau_hoi"], 1):
            L.append(f"{i}. {xh(q, yc)}")
    if yc["nguoi_quyet"]:
        L.append("")
        L.append(f"{next(muc)}) Các nội dung sẽ có xác nhận sau (bên em chưa thể hứa):")
        for x in yc["nguoi_quyet"]:
            L.append("- " + xh(x[1], yc))
    L.append("")
    L.append("Lưu ý chung:")
    vat_txt = f"{VAT_TXT}% [{HIEU_LUC_VAT_GHI_CHU}]"
    L.append(f"- Giá chưa gồm VAT; VAT tính theo mức {vat_txt}.")
    L.append(f"- Báo giá có hiệu lực {THAM_SO['hieu_luc']} ngày kể từ ngày báo giá {THAM_SO['ngay'].strftime('%d/%m/%Y')}.")
    L.append("- Thời gian giao hàng cụ thể sẽ có xác nhận của kho bằng văn bản; báo giá này không phải cam kết ngày giao.")
    L.append("- Thanh toán theo điều kiện mặc định của công ty: chuyển khoản trước khi giao hàng.")
    L.append("")
    L.append("Trân trọng,")
    L.append("Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (công ty giả, dữ liệu học)")
    (OUT / f"{rid}-email.txt").write_text("\n".join(L) + "\n", encoding="utf-8")


def lap_cau_hoi(rid, yc):
    if yc["cau_hoi"]:
        txt = "\n".join(f"{i}. {xh(q, yc)}" for i, q in enumerate(yc["cau_hoi"], 1))
    else:
        txt = "Không có câu hỏi"
    (OUT / f"{rid}-cau-hoi.txt").write_text(txt + "\n", encoding="utf-8")


# ---------------------------------------------------------------- kiểm tra cuối (độc lập với phần tính)
def kiem_tra():
    """Đọc lại các file đã ghi và tự tính lại bằng cách khác (số nguyên thuần, đọc lại bang-gia.xlsx)."""
    loi = []
    wsbg = openpyxl.load_workbook(BASE / "bang-gia.xlsx", data_only=True)["BangGia"]
    gia = {r[0]: r for r in wsbg.iter_rows(min_row=4, values_only=True) if r[0]}
    vat = THAM_SO["vat"]
    tom_tat = []
    for rid, yc in YEU_CAU.items():
        f = OUT / f"{rid}-bao-gia.xlsx"
        for suffix in ("email.txt", "cau-hoi.txt"):
            if not (OUT / f"{rid}-{suffix}").exists():
                loi.append(f"{rid}: thiếu file {suffix}")
        if not f.exists():
            loi.append(f"{rid}: thiếu file báo giá")
            continue
        wb = openpyxl.load_workbook(f)           # không data_only: để phát hiện công thức
        if "Tham số" not in wb.sheetnames:
            loi.append(f"{rid}: mất sheet Tham số")
        ws = wb["Báo giá"]
        for row in ws.iter_rows():
            for c in row:
                if c.data_type == "f":
                    loi.append(f"{rid}: ô {c.coordinate} là công thức")
        # tiêu đề cột và nhãn các dòng tổng giữ nguyên mẫu
        if [ws.cell(13, c).value for c in range(1, 9)] != ["STT", "Mã hàng", "Tên hàng", "ĐVT", "Số lượng", "Đơn giá (VNĐ)", "Thành tiền (VNĐ)", "Ghi chú"]:
            loi.append(f"{rid}: tiêu đề cột bị đổi")
        if [ws.cell(r, 6).value for r in range(29, 35)] != ["Cộng tiền hàng", "Chiết khấu", "Phí giao hàng", "Cộng trước VAT", "VAT", "Tổng cộng"]:
            loi.append(f"{rid}: nhãn dòng tổng bị đổi")
        dong = [(ws.cell(r, 1).value, ws.cell(r, 2).value, ws.cell(r, 5).value, ws.cell(r, 6).value, ws.cell(r, 7).value)
                for r in range(14, 29) if ws.cell(r, 1).value is not None]
        # số dòng = số mã khác nhau sau khi gộp
        ma_khac = {d[0] for d in yc["dong"]}
        if len(dong) != len(ma_khac):
            loi.append(f"{rid}: số dòng {len(dong)} != {len(ma_khac)}")
        if [d[0] for d in dong] != list(range(1, len(dong) + 1)):
            loi.append(f"{rid}: STT không liên tục")
        tong_hang, co_ck = 0, 0
        for stt, ma, sl, dg, tt_ in dong:
            if ma not in gia:
                loi.append(f"{rid}: mã {ma} không có trong bảng giá")
                continue
            r = gia[ma]
            exp = r[8] if sl >= r[7] else (r[6] if sl >= r[5] else r[4])
            if dg != exp:
                loi.append(f"{rid}: {ma} đơn giá {dg} != bậc giá đúng {exp} cho SL {sl}")
            if tt_ != sl * dg:
                loi.append(f"{rid}: {ma} thành tiền {tt_} != {sl}x{dg}")
            tong_hang += sl * dg
            if r[2] != NHOM_THIET_BI:
                co_ck += sl * dg
        g = {k: ws.cell(r, 7).value for k, r in zip(("hang", "ck", "phi", "truoc", "vat", "tong"), range(29, 35))}
        if g["hang"] != tong_hang:
            loi.append(f"{rid}: Cộng tiền hàng {g['hang']} != tổng thành tiền {tong_hang}")
        pct = 4 if tong_hang >= 30_000_000 else (2 if tong_hang >= 10_000_000 else 0)
        xin = yc.get("xin")
        if xin and xin[0] == "them":
            pct += min(xin[1], max(0, min(2, 5 - pct)))
        bp = pct * 100
        ck_exp = (co_ck * bp + 5000) // 10000     # làm tròn nửa lên bằng số nguyên
        if g["ck"] != ck_exp:
            loi.append(f"{rid}: chiết khấu {g['ck']} != {ck_exp}")
        phi = g["phi"] or 0
        truoc = tong_hang - g["ck"] + phi
        if g["truoc"] != truoc:
            loi.append(f"{rid}: Cộng trước VAT {g['truoc']} != {truoc}")
        vat_exp = int((Decimal(truoc) * vat / 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))
        if g["vat"] != vat_exp:
            loi.append(f"{rid}: VAT {g['vat']} != {vat_exp}")
        if g["tong"] != g["truoc"] + g["vat"]:
            loi.append(f"{rid}: Tổng cộng {g['tong']} != trước VAT + VAT")
        for k, v in g.items():
            if k == "phi" and v is None:
                continue
            if not isinstance(v, int):
                loi.append(f"{rid}: ô tổng '{k}' không phải số nguyên: {v!r}")
        stt_txt = ws["B9"].value
        if stt_txt != ";".join(trang_thai(yc)):
            loi.append(f"{rid}: trạng thái '{stt_txt}'")
        # email / câu hỏi
        em = (OUT / f"{rid}-email.txt").read_text(encoding="utf-8")
        if HIEU_LUC_VAT_GHI_CHU not in em:
            loi.append(f"{rid}: email thiếu câu về mức VAT")
        if HIEU_LUC_VAT_GHI_CHU not in str(ws["H33"].value):
            loi.append(f"{rid}: báo giá thiếu ghi chú mức VAT")
        if dong and fmt(g["tong"]) not in em:
            loi.append(f"{rid}: email không chứa tổng cộng {fmt(g['tong'])}")
        if yc["nguoi_quyet"] and "sẽ có xác nhận" not in em:
            loi.append(f"{rid}: email thiếu 'sẽ có xác nhận'")
        ch = (OUT / f"{rid}-cau-hoi.txt").read_text(encoding="utf-8").splitlines()
        if yc["cau_hoi"]:
            if len(ch) != len(yc["cau_hoi"]) or not all(re.match(rf"{i}\. ", l) for i, l in enumerate(ch, 1)):
                loi.append(f"{rid}: file câu hỏi sai định dạng")
        elif ch != ["Không có câu hỏi"]:
            loi.append(f"{rid}: file câu hỏi phải đúng một dòng 'Không có câu hỏi'")
        tom_tat.append((rid, stt_txt, g["tong"], len(dong)))
    return loi, tom_tat


# ---------------------------------------------------------------- main
def main():
    if "--kiem-tra" not in sys.argv:
        for rid, yc in YEU_CAU.items():
            kq = tinh_bao_gia(yc["dong"], yc["dia_chi"], yc.get("xin"))
            tt = trang_thai(yc)
            # ràng buộc nhất quán: phần xin giảm vượt thẩm quyền / ngoại tỉnh phải có người quyết
            if kq["cho_quyet_pct"] or kq["khu_vuc"] == "ngoai_tinh":
                assert "CAN_NGUOI_QUYET" in tt, f"{rid}: thiếu CAN_NGUOI_QUYET"
            lap_xlsx(rid, yc, kq, tt)
            lap_email(rid, yc, kq, tt)
            lap_cau_hoi(rid, yc)
            print(f"{rid}: khu vực={kq['khu_vuc']:<10} dòng={len(kq['dong'])} tiền hàng={fmt(kq['cong_tien_hang']):>12} "
                  f"CK={kq['pct_ap']}% ({fmt(kq['chiet_khau'])}) phí={kq['phi']} tổng={fmt(kq['tong'])}")
    loi, tom_tat = kiem_tra()
    print()
    print("KIỂM TRA:", "OK - không có lỗi" if not loi else f"{len(loi)} lỗi")
    for l in loi:
        print("  -", l)
    print()
    print(f"{'Mã':<5} {'Trạng thái':<34} {'Dòng':>4} {'Tổng cộng (VNĐ)':>16}")
    for rid, st, tong, n in tom_tat:
        print(f"{rid:<5} {st:<34} {n:>4} {fmt(tong):>16}")
    return 1 if loi else 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.exit(main())
