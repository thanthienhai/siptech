"""Dựng lại TOÀN BỘ ảnh trong ../anh/ từ log và file kết quả đã che.

Chạy:  python -X utf8 dung_anh.py [--term-dir <thư mục chứa term.py>]
- Ảnh terminal: dựng từ ../logs/*.json (transcript đã che) bằng render_blocks của term.py (tự che đường dẫn máy, tên tổ chức, email).
- Ảnh bảng/file: dựng từ ../du-lieu, ./<lần chạy>/dau-ra, ./bao-cao-cham.json, ./dap-an.json; mọi chuỗi đều qua scrub_text.
Cần: Edge + playwright (term.shot_html). Đường dẫn tính tương đối theo vị trí file này.
"""
import sys, json, html, argparse, os
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--term-dir", default=os.environ.get("TERM_DIR"), required="TERM_DIR" not in os.environ,
                help="thư mục chứa term.py (hoặc đặt biến môi trường TERM_DIR)")
args = ap.parse_args()
sys.path.insert(0, args.term_dir)
from term import render_blocks, shot_html, scrub_text, CSS as TCSS
from openpyxl import load_workbook
from docx import Document

K = Path(__file__).resolve().parent          # ket-qua/
B = K.parent                                  # thư mục bài
A = B / "anh"; A.mkdir(exist_ok=True)
S = scrub_text
E = lambda x: html.escape(S(str(x)))

# ------------------------------------------------------------------ ảnh terminal (từ logs đã che)
import re
_SEP = r'(?:\\|/)'          # trong JSON một dấu \ được viết thành \
_OD = 'One' + 'Drive'
_PRE = [  # che thêm những gì scrub_text của term.py chưa xóa hết: tên dịch vụ đồng bộ còn lại, thư mục chạy cô lập trong %TEMP%
    (re.compile(r'[A-Za-z]:' + _SEP + 'Users' + _SEP + r'[^\/"]+' + _SEP + _OD + r' - \[đã che\]'), '~'),
    (re.compile(r'[A-Za-z]:' + _SEP + 'Users' + _SEP + r'[^\/"]+' + _SEP + 'AppData' + _SEP + 'Local' + _SEP + 'Temp' + _SEP + r'al05-(\w+)' + _SEP + 'run'), r'~/bai-toan/\1-2'),
    (re.compile(_OD + r' - \[đã che\]'), '[đã che]'),
]
def pre_scrub(obj):
    s = json.dumps(obj, ensure_ascii=False)
    for p, r in _PRE: s = p.sub(r, s)
    return json.loads(s)

def term_img(log, out, title, blocks, maxlines, width=1280):
    t = pre_scrub(json.loads((B / "logs" / log).read_text(encoding="utf-8")))
    s, e = blocks
    h = render_blocks(t["blocks"][s:e], title, t["prompt"], maxlines, width, False)
    shot_html(h, A / out, width + 40, ".win")

term_img("claude-1.json", "02-claude-dang-lam.png", "claude (Claude Code) · lần chạy claude-1 · các bước làm", (5, 12), 7)
term_img("claude-1.json", "03-claude-ket-qua-cuoi.png", "claude · bước kiểm tra cuối và câu trả lời", (15, 18), 12)
term_img("agy-2.json", "04-agy-dang-lam.png", "agy (Antigravity) · lần chạy agy-2 · các bước làm", (15, 23), 6)
term_img("agy-1.json", "09-agy-doc-dap-an.png", "agy (Antigravity) · lần chạy agy-1 · đọc file NGOÀI thư mục làm việc", (14, 27), 3)

# 01: prompt nguyên văn
p = S((K / "prompt-giao-viec.txt").read_text(encoding="utf-8"))
h = (f'<!doctype html><meta charset="utf-8"><style>{TCSS}</style><div style="padding:18px;width:1240px"><div class="win"><div class="bar">'
     f'<span class="dot r"></span><span class="dot y"></span><span class="dot g"></span><span class="t">ket-qua/prompt-giao-viec.txt  (nguyên văn, khung 6 phần)</span></div>'
     f'<div class="body" style="font-size:14px;line-height:1.45">{html.escape(p)}</div></div></div>')
shot_html(h, A / "01-prompt-giao-viec.png", 1280, ".win")

# ------------------------------------------------------------------ ảnh bảng / file
CSS = """body{margin:0;background:#eef1f6;font-family:'Segoe UI',Arial,sans-serif;color:#1b2430}
.box{margin:16px;background:#fff;border:1px solid #cfd6e2;border-radius:8px;overflow:hidden;box-shadow:0 4px 14px rgba(20,40,80,.12);width:1180px}
.cap{background:#1F4E78;color:#fff;padding:8px 14px;font-weight:600;font-size:15px}
table{border-collapse:collapse;width:100%;font-size:13.5px}td,th{padding:4px 7px;border:1px solid #d5dbe6;vertical-align:top}
th{background:#dce6f2;text-align:left}.n{text-align:right;font-variant-numeric:tabular-nums}.ok{background:#e6f5e6}.bad{background:#fde3e3}
.note{padding:7px 14px;font-size:13px;color:#a33;background:#fff4f4;border-top:1px solid #f0c9c9}.h{font-weight:600}
pre{margin:0;padding:12px 16px;font:14px/1.5 Consolas,monospace;white-space:pre-wrap;background:#fbfcfe}.chat{background:#e8f0e8}"""
FOOT = '<div class="note">Dữ liệu GIẢ để học (công ty, người, địa chỉ, SĐT đều bịa), sinh bằng du-lieu/sinh_du_lieu.py.</div>'
def page(inner): return f'<!doctype html><meta charset="utf-8"><style>{CSS}</style>{inner}'
def fmt(v):
    if v is None: return ""
    if isinstance(v, float) and v.is_integer(): v = int(v)
    if isinstance(v, int) and abs(v) >= 1000: return f"{v:,}".replace(",", ".")
    return E(v)
def tbl(rows, hdr, num=()):
    h = "".join(f"<th>{E(x)}</th>" for x in hdr)
    b = "".join("<tr>" + "".join(f'<td class="{"n" if i in num else ""}">{fmt(v) if i in num else E(v)}</td>' for i, v in enumerate(r)) + "</tr>" for r in rows)
    return f"<table><tr>{h}</tr>{b}</table>"

# 10 bảng giá
ws = load_workbook(B / "du-lieu/bang-gia.xlsx")["BangGia"]
rows = [[c.value for c in r][:10] for r in ws.iter_rows(min_row=4, max_row=19)]
hdr = [c.value for c in ws[3]][:10]
shot_html(page(f'<div class="box" style="width:1240px"><div class="cap">bang-gia.xlsx - sheet BangGia (16 dòng đầu / 29 mã)</div>{tbl(rows, hdr, num=(4,5,6,7,8))}{FOOT}</div>'), A / "10-du-lieu-bang-gia.png", 1300, ".box")
# 11 yêu cầu mẫu
rd = lambda n: (B / f"du-lieu/yeu-cau/{n}.txt").read_text(encoding="utf-8")
inner = (f'<div style="width:1240px"><div class="box"><div class="cap">yeu-cau/R05.txt - email xin giảm 25%</div><pre>{E(rd("R05"))}</pre></div>'
         f'<div class="box"><div class="cap">yeu-cau/R10.txt - tin nhắn Zalo, dòng trùng, "thêm"</div><pre class="chat">{E(rd("R10"))}</pre></div>'
         f'<div class="box"><div class="cap">yeu-cau/R06.txt - đơn vị lẫn lộn</div><pre class="chat">{E(rd("R06"))}</pre>{FOOT}</div></div>')
shot_html(page(inner), A / "11-du-lieu-yeu-cau.png", 1300, "div[style]")
# 12 chính sách
d = Document(B / "du-lieu/chinh-sach-chiet-khau.docx")
ptxt = "\n\n".join(p.text for p in d.paragraphs[2:12])
dl = (B / "du-lieu/dieu-kien-giao-hang.txt").read_text(encoding="utf-8").split("3. Thời gian giao")[0]
shot_html(page(f'<div style="width:1240px"><div class="box"><div class="cap">chinh-sach-chiet-khau.docx (trích mục 1-3)</div><pre>{E(ptxt[:1900])}</pre></div>'
               f'<div class="box"><div class="cap">dieu-kien-giao-hang.txt (trích mục 1-2)</div><pre>{E(dl)}</pre>{FOOT}</div></div>'), A / "12-du-lieu-chinh-sach.png", 1300, "div[style]")

# 05 báo giá R10 của claude-2
def sheet_html(path, title, note):
    wb = load_workbook(path, data_only=True)
    ws = wb["Báo giá"] if "Báo giá" in wb.sheetnames else wb.worksheets[0]
    out = []
    for r in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 45)):
        vals = [c.value for c in r][:8]
        if all(v is None for v in vals): continue
        if any(v is None for v in vals) and not any(isinstance(v, (int, float)) for v in vals):
            out.append(f'<tr><td colspan="8" class="h">{E(" ".join(str(v) for v in vals if v is not None))}</td></tr>'); continue
        out.append("<tr>" + "".join(f'<td class="{"n" if isinstance(v,(int,float)) else ""}">{fmt(v)}</td>' for v in vals) + "</tr>")
    return f'<div class="box"><div class="cap">{E(title)}</div><table>{"".join(out)}</table><div class="note">{E(note)}</div></div>'
shot_html(page(sheet_html(K / "claude-2/dau-ra/R10-bao-gia.xlsx", "R10-bao-gia.xlsx (claude-2)",
          "Kết quả thật của lần chạy claude-2 (file ket-qua/claude-2/dau-ra/R10-bao-gia.xlsx dựng lại bằng HTML). Dữ liệu giả để học.")), A / "05-claude-bao-gia-R10.png", 1240, ".box")
# 06 email R08
em = (K / "claude-2/dau-ra/R08-email.txt").read_text(encoding="utf-8")
shot_html(page(f'<div class="box"><div class="cap">R08-email.txt (claude-2) - khách đòi giao trước 10h sáng thứ Sáu, giao Bắc Ninh</div><pre>{E(em)}</pre></div>'
               '<div class="box"><div class="note">Kết quả thật, ngày 2026-11-20. Dữ liệu giả để học.</div></div>'), A / "06-claude-email-R08.png", 1240, "body")
# 07 so sánh R10
ans = {y["id"]: y for y in json.loads((K / "dap-an.json").read_text(encoding="utf-8"))["yeu_cau"]}["R10"]
def get(a):
    ws = load_workbook(K / f"{a}/dau-ra/R10-bao-gia.xlsx", data_only=True)["Báo giá"]
    out = {}
    for r in ws.iter_rows(min_row=29, max_row=34):
        lab = [c.value for c in r if isinstance(c.value, str)]; val = [c.value for c in r if isinstance(c.value, (int, float))]
        if lab and val: out[lab[0]] = val[0]
    return out
g0, g2 = get("agy-0"), get("claude-2")
exp = [("Cộng tiền hàng", ans["tien_hang"]), ("Chiết khấu", ans["chiet_khau"]), ("Phí giao hàng", ans["phi_giao"]),
       ("Cộng trước VAT", ans["cong_truoc_vat"]), ("VAT", ans["vat"]), ("Tổng cộng", ans["tong_cong"])]
trs = ""
for lab, e in exp:
    a0, a2 = g0.get(lab), g2.get(lab)
    trs += f'<tr><td>{lab}</td><td class="n">{fmt(e)}</td><td class="n {"ok" if a2 == e else "bad"}">{fmt(a2)}</td><td class="n {"ok" if a0 == e else "bad"}">{fmt(a0)}</td></tr>'
tb = (f'<div class="box"><div class="cap">Yêu cầu R10: dòng tổng của đáp án so với hai lần chạy</div><table><tr><th>Dòng tổng</th><th>Đáp án (code)</th><th>claude-2</th>'
      f'<th>agy-0 (lần chạy mất log)</th></tr>{trs}</table><div class="note">agy-0 chỉ chiết khấu 2% (theo đơn), bỏ phần 2% nhân viên được cấp thêm vì cho rằng "đơn có Thiết bị nên chờ duyệt"; '
      f'chính sách nói phần thêm tính trên các dòng KHÔNG thuộc nhóm Thiết bị. Dữ liệu giả để học.</div></div>')
shot_html(page(tb), A / "07-so-sanh-R10.png", 1240, ".box")
# 08 bảng điểm
rep = json.loads((K / "bao-cao-cham.json").read_text(encoding="utf-8"))
names = [("claude-1", "claude-1 (có log)"), ("claude-2", "claude-2 (có log, thư mục cô lập)"), ("claude-0", "claude-0 (mất log)"),
         ("agy-2", "agy-2 (có log, thư mục cô lập)"), ("agy-0", "agy-0 (mất log)"), ("agy-1-NHIEM-DAP-AN", "agy-1 (ĐÃ ĐỌC ĐÁP ÁN - không tính)")]
trs = ""
for k, lab in names:
    t = rep[k]["tom_tat"]
    trs += (f'<tr class="{"bad" if "NHIEM" in k else ""}"><td>{lab}</td><td>{t["files"]}</td><td>{t["dong_dung"]}/{t["dong_ky_vong"]}</td><td>{t["dong_bia_co_gia"]}</td>'
            f'<td>{t["tong_dung_het"]}</td><td>{t["trang_thai_dung"]}</td><td>{t["nhan_nhan_dien"]}</td></tr>')
tb = (f'<div class="box"><div class="cap">Chấm bằng code (cham.py, đáp án v2), 12 yêu cầu</div><table><tr><th>Lần chạy</th><th>File</th><th>Dòng hàng đúng</th><th>Dòng bịa có giá</th>'
      f'<th>Yêu cầu đúng cả 6 dòng tổng</th><th>Trạng thái khớp</th><th>Nhãn hỏi/cần quyết nhận ra</th></tr>{trs}</table>'
      f'<div class="note">n = 1-2 lần mỗi agent, chưa đo được độ ổn định; không kết luận agent nào tốt hơn. Nhãn: so khớp từ khóa, chỉ là ước lượng. Dữ liệu giả để học.</div></div>')
shot_html(page(tb), A / "08-bang-diem.png", 1240, ".box")
print("Đã dựng", len(list(A.glob("*.png"))), "ảnh trong", A)
