import os
import re
import copy
from pathlib import Path
import openpyxl

# Đường dẫn thư mục hiện tại
CURRENT_DIR = Path(__file__).resolve().parent
BANG_GIA_PATH = CURRENT_DIR / "bang-gia.xlsx"
MAU_BAO_GIA_PATH = CURRENT_DIR / "mau-bao-gia.xlsx"
DAU_RA_DIR = CURRENT_DIR / "dau-ra"

def load_bang_gia():
    wb = openpyxl.load_workbook(BANG_GIA_PATH, data_only=True)
    ws_bg = wb["BangGia"]
    items = {}
    for r in range(4, ws_bg.max_row + 1):
        code = ws_bg.cell(r, 1).value
        if code:
            code = str(code).strip()
            items[code] = {
                "ma_hang": code,
                "ten_hang": ws_bg.cell(r, 2).value,
                "nhom": ws_bg.cell(r, 3).value,
                "dvt": ws_bg.cell(r, 4).value,
                "p1": ws_bg.cell(r, 5).value,
                "t2": ws_bg.cell(r, 6).value,
                "p2": ws_bg.cell(r, 7).value,
                "t3": ws_bg.cell(r, 8).value,
                "p3": ws_bg.cell(r, 9).value,
                "tinh_trang": ws_bg.cell(r, 10).value,
            }

    ws_qd = wb["QuyDoi"]
    conversions = {}
    for r in range(3, ws_qd.max_row + 1):
        c = ws_qd.cell(r, 1).value
        u = ws_qd.cell(r, 2).value
        factor = ws_qd.cell(r, 3).value
        if c and u and factor:
            conversions[(str(c).strip(), str(u).strip().lower())] = int(factor)

    return items, conversions

def load_tham_so():
    wb = openpyxl.load_workbook(MAU_BAO_GIA_PATH, data_only=True)
    ws_ts = wb["Tham số"]
    params = {}
    for r in range(2, ws_ts.max_row + 1):
        k = ws_ts.cell(r, 1).value
        v = ws_ts.cell(r, 2).value
        if k:
            params[str(k).strip()] = v
    return params

def tra_bac_gia(item_info, so_luong):
    """Tra đơn giá theo bậc số lượng của chính mã hàng."""
    t3 = item_info["t3"]
    p3 = item_info["p3"]
    t2 = item_info["t2"]
    p2 = item_info["p2"]
    p1 = item_info["p1"]

    if t3 is not None and so_luong >= t3:
        return 3, p3
    elif t2 is not None and so_luong >= t2:
        return 2, p2
    else:
        return 1, p1

def tinh_toan_bao_gia(lines_input, xin_giam_pct, dia_chi_loai, vat_percent=10):
    """
    Tính tiền cho đơn hàng theo đúng chính sách và điều kiện:
    - lines_input: list các tuple (ma_hang, so_luong_goc, ghi_chu_line)
    - xin_giam_pct: % khách xin giảm thêm (0 nếu không xin)
    - dia_chi_loai: 'noi_thanh', 'ngoai_tinh', hoặc 'chua_biet'
    - vat_percent: mức VAT lấy từ Tham số
    """
    items_bg, _ = load_bang_gia()

    priced_lines = []
    tien_hang = 0
    co_so_chiet_khau = 0

    for item in lines_input:
        ma = item["ma_hang"]
        sl = item["so_luong"]
        note = item.get("ghi_chu", "")

        info = items_bg[ma]
        bac, don_gia = tra_bac_gia(info, sl)
        thanh_tien = sl * don_gia

        priced_lines.append({
            "ma_hang": ma,
            "ten_hang": info["ten_hang"],
            "nhom": info["nhom"],
            "dvt": info["dvt"],
            "so_luong": sl,
            "bac": bac,
            "don_gia": don_gia,
            "thanh_tien": thanh_tien,
            "ghi_chu": note,
            "tinh_trang": info["tinh_trang"]
        })

        tien_hang += thanh_tien
        if info["nhom"] != "Thiết bị":
            co_so_chiet_khau += thanh_tien

    # Chiết khấu tự động theo giá trị đơn hàng
    if tien_hang >= 30000000:
        ck_theo_don_pct = 4.0
    elif tien_hang >= 10000000:
        ck_theo_don_pct = 2.0
    else:
        ck_theo_don_pct = 0.0

    # Chiết khấu thêm do nhân viên kinh doanh quyết:
    # Tối đa 2% trên dòng không thuộc Thiết bị, tổng không vượt 5%.
    # Nếu khách xin > 5% hoặc xin cho Thiết bị -> không tự quyết, chỉ áp ck theo đơn.
    ck_them_duoc_cap = 0.0
    if xin_giam_pct > 0:
        if xin_giam_pct <= 2.0 and (ck_theo_don_pct + xin_giam_pct) <= 5.0:
            ck_them_duoc_cap = float(xin_giam_pct)
        else:
            ck_them_duoc_cap = 0.0

    ck_ap_dung_pct = ck_theo_don_pct + ck_them_duoc_cap

    # Số tiền chiết khấu (làm tròn đến đồng, 0.5 làm tròn lên)
    if ck_ap_dung_pct > 0:
        chiet_khau = int(round(co_so_chiet_khau * ck_ap_dung_pct / 100.0 + 1e-9))
    else:
        chiet_khau = 0

    # Phí giao hàng
    # Giá trị đơn sau chiết khấu, trước VAT
    tien_sau_ck = tien_hang - chiet_khau

    if dia_chi_loai == "noi_thanh":
        if tien_sau_ck >= 3000000:
            phi_giao = 0
            phi_giao_note = "Nội thành, đơn sau chiết khấu từ 3.000.000đ: Miễn phí giao hàng"
        else:
            phi_giao = 40000
            phi_giao_note = "Nội thành, đơn sau chiết khấu dưới 3.000.000đ: 40.000đ/đơn"
    elif dia_chi_loai == "ngoai_tinh":
        phi_giao = None
        phi_giao_note = "Ngoại thành / ngoại tỉnh: phí giao hàng theo thỏa thuận, chuyển người quyết"
    else: # chua_biet
        phi_giao = None
        phi_giao_note = "Chưa biết địa chỉ giao: chưa tính phí giao hàng, hỏi lại khách"

    # Cộng trước VAT
    cong_truoc_vat = tien_sau_ck + (phi_giao if phi_giao is not None else 0)

    # VAT (10% theo tham số)
    vat = int(round(cong_truoc_vat * vat_percent / 100.0 + 1e-9))

    # Tổng cộng
    tong_cong = cong_truoc_vat + vat

    return {
        "lines": priced_lines,
        "tien_hang": tien_hang,
        "co_so_chiet_khau": co_so_chiet_khau,
        "ck_theo_don_pct": ck_theo_don_pct,
        "ck_them_duoc_cap": ck_them_duoc_cap,
        "ck_ap_dung_pct": ck_ap_dung_pct,
        "chiet_khau": chiet_khau,
        "phi_giao": phi_giao,
        "phi_giao_note": phi_giao_note,
        "cong_truoc_vat": cong_truoc_vat,
        "vat_percent": vat_percent,
        "vat": vat,
        "tong_cong": tong_cong,
    }

def dien_vao_mau_excel(req_meta, calc_res, output_path):
    """Điền kết quả tính toán vào bản sao của mau-bao-gia.xlsx."""
    wb = openpyxl.load_workbook(MAU_BAO_GIA_PATH)
    ws = wb["Báo giá"]

    # Header metadata
    ws["C5"] = req_meta.get("kinh_gui", "")
    ws["C6"] = req_meta.get("dia_chi_giao", "")
    ws["C7"] = req_meta.get("theo_yeu_cau_so", "")
    ws["C8"] = req_meta.get("ngay_bao_gia", "2026-11-20 / hiệu lực 7 ngày (đến hết 27/11/2026)")
    
    # Trạng thái: xóa chỉ dẫn template ở C9 và ghi trạng thái
    trang_thai_str = "; ".join(req_meta["trang_thai"])
    ws["B9"] = trang_thai_str
    ws["C9"] = trang_thai_str
    ws["B10"] = None # Để trống cho người thật ký duyệt

    # Dòng hàng: ghi từ dòng 14 đến 28
    lines = calc_res["lines"]
    for idx, item in enumerate(lines):
        row = 14 + idx
        ws.cell(row, 1, idx + 1)                # STT
        ws.cell(row, 2, item["ma_hang"])        # Mã hàng
        ws.cell(row, 3, item["ten_hang"])       # Tên hàng
        ws.cell(row, 4, item["dvt"])            # ĐVT
        ws.cell(row, 5, item["so_luong"])        # Số lượng
        ws.cell(row, 6, item["don_gia"])         # Đơn giá
        ws.cell(row, 7, item["thanh_tien"])      # Thành tiền
        
        note_parts = []
        if item.get("ghi_chu"):
            note_parts.append(item["ghi_chu"])
        if item.get("tinh_trang") and item["tinh_trang"] != "Còn hàng":
            note_parts.append(f"Kho: {item['tinh_trang']}")
        ws.cell(row, 8, "; ".join(note_parts) if note_parts else None) # Ghi chú

    # Xóa trắng các dòng còn lại trong bảng nếu số dòng < 15
    for r in range(14 + len(lines), 29):
        for c in range(1, 9):
            ws.cell(r, c, None)

    # Dòng tổng cộng (từ dòng 29 đến 34)
    # Row 29: Cộng tiền hàng
    ws.cell(29, 7, calc_res["tien_hang"])
    
    # Row 30: Chiết khấu
    ws.cell(30, 7, calc_res["chiet_khau"])
    if calc_res["ck_ap_dung_pct"] > 0:
        ck_note = f"{int(calc_res['ck_ap_dung_pct']) if calc_res['ck_ap_dung_pct'].is_integer() else calc_res['ck_ap_dung_pct']}% trên tiền hàng không thuộc nhóm Thiết bị ({calc_res['co_so_chiet_khau']:,}đ)".replace(",", ".")
        if req_meta.get("ghi_chu_ck"):
            ck_note += f"; {req_meta['ghi_chu_ck']}"
        ws.cell(30, 8, ck_note)
    else:
        if req_meta.get("ghi_chu_ck"):
            ws.cell(30, 8, req_meta["ghi_chu_ck"])
        else:
            ws.cell(30, 8, "0% (đơn dưới 10.000.000đ)")

    # Row 31: Phí giao hàng
    if calc_res["phi_giao"] is not None:
        ws.cell(31, 7, calc_res["phi_giao"])
        ws.cell(31, 8, calc_res["phi_giao_note"])
    else:
        ws.cell(31, 7, None)
        ws.cell(31, 8, calc_res["phi_giao_note"])

    # Row 32: Cộng trước VAT
    ws.cell(32, 7, calc_res["cong_truoc_vat"])
    ws.cell(32, 8, "Gồm tiền hàng sau chiết khấu + phí giao hàng (nếu đã tính)")

    # Row 33: VAT
    ws.cell(33, 7, calc_res["vat"])
    ws.cell(33, 8, f"{calc_res['vat_percent']}% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi)")

    # Row 34: Tổng cộng
    ws.cell(34, 7, calc_res["tong_cong"])
    if calc_res["phi_giao"] is None:
        ws.cell(34, 8, "Tạm tính (chưa bao gồm phí giao hàng)")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)

def chay_tat_ca():
    """Hàm chạy toàn bộ 12 yêu cầu R01-R12 và xuất file."""
    DAU_RA_DIR.mkdir(parents=True, exist_ok=True)
    
    # Định nghĩa dữ liệu đầu vào cho 12 yêu cầu dựa trên phân tích chính xác
    ds_yeu_cau = [
        {
            "id": "R01",
            "kinh_gui": "Công ty TNHH Cơ khí Ánh Dương (chị Lan - Phòng Hành chính, ĐT 0900 000 101, lan.mua.hang@example.com)",
            "dia_chi_giao": "12 Đường Số 5, Quận Hà Đông, Hà Nội (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R01 - email 'Đề nghị báo giá VPP tháng 12'",
            "trang_thai": ["SAN_SANG"],
            "lines": [
                {"ma_hang": "GIAY-A4-80", "so_luong": 25, "ghi_chu": "Giá bậc 3"},
                {"ma_hang": "BUT-BI-TL027-XANH", "so_luong": 60, "ghi_chu": "Quy đổi: 3 hộp = 60 cây (giá bậc 2)"},
                {"ma_hang": "BANGKEO-TRONG-48", "so_luong": 10, "ghi_chu": "Giá bậc 1"},
            ],
            "xin_giam_pct": 2.0,
            "ghi_chu_ck": "giảm thêm 2% trong thẩm quyền cho khách quen",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: SAN_SANG. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: Re: Đề nghị báo giá VPP tháng 12

Kính gửi: Chị Lan - Phòng Hành chính, Công ty TNHH Cơ khí Ánh Dương,

Công ty An Phát Demo xin cảm ơn chị đã gửi yêu cầu báo giá vật tư văn phòng phẩm tháng 12.
Chúng tôi xin gửi bảng báo giá nháp chi tiết cho các mặt hàng chị yêu cầu như sau:

1. Mặt hàng báo giá:
- Giấy A4 định lượng 80 gsm: 25 ram, đơn giá bậc 3 (từ 20 ram) là 69.000 đ/ram, thành tiền: 1.725.000 đ.
- Bút bi xanh TL027: 3 hộp quy đổi theo bảng quy đổi là 60 cây, đơn giá bậc 2 (từ 50 cây) là 4.000 đ/cây, thành tiền: 240.000 đ.
- Băng keo trong 48 mm x 100 yard: 10 cuộn, đơn giá bậc 1 là 14.500 đ/cuộn, thành tiền: 145.000 đ.

2. Chiết khấu:
- Tổng tiền hàng: 2.110.000 đ.
- Do bên mình là khách quen và có đề nghị giảm 2%, công ty xin áp dụng mức chiết khấu 2% trong thẩm quyền nhân viên kinh doanh tự quyết đối với các mặt hàng văn phòng phẩm, số tiền chiết khấu là 42.200 đ.

3. Giao hàng và Thanh toán:
- Địa chỉ giao hàng: 12 Đường Số 5, Quận Hà Đông, Hà Nội (thuộc khu vực nội thành Hà Nội). Do giá trị đơn sau chiết khấu trước thuế (2.067.800 đ) dưới 3.000.000 đ nên phí giao hàng nội thành là 40.000 đ/đơn.
- Thời gian giao hàng: Các mặt hàng hiện đều còn hàng trong kho. Tuy nhiên, thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi đơn hàng được chốt và thanh toán, công ty không cam kết ngày giờ giao cụ thể trong báo giá.
- Mức thuế VAT: Thuế suất VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi).
- Hiệu lực báo giá: 7 ngày kể từ ngày 20/11/2026.

Trân trọng kính gửi chị duyệt trước.

Người lập báo giá: Nhân viên hỗ trợ kinh doanh
Công ty An Phát Demo""",
            "cau_hoi": "Không có câu hỏi."
        },
        {
            "id": "R02",
            "kinh_gui": "Anh Dung Phat (Zalo)",
            "dia_chi_giao": "Chưa cung cấp địa chỉ giao hàng cụ thể",
            "dia_chi_loai": "chua_biet",
            "theo_yeu_cau_so": "R02 - tin nhắn Zalo 09:12",
            "trang_thai": ["THIEU_THONG_TIN"],
            "lines": [
                {"ma_hang": "MUC-HP-12A", "so_luong": 6, "ghi_chu": "Giá bậc 2 (từ 3 hộp)"},
            ],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Đơn dưới 10.000.000đ, không có chiết khấu",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: THIEU_THONG_TIN. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: (Trả lời tin nhắn Zalo) Báo giá giấy A4 80 và hộp mực HP 12A

Chào anh Dung Phat,

Công ty An Phát Demo xin cảm ơn anh đã liên hệ.
Do tin nhắn của anh còn thiếu số lượng giấy và địa chỉ giao hàng, bên em xin gửi báo giá phần đã đủ thông tin trước, các phần còn lại cần làm rõ như sau:

1. Mặt hàng đã báo giá:
- Hộp mực tương thích máy in dòng HP 12A: 6 hộp, áp dụng đơn giá bậc 2 (từ 3 hộp) là 385.000 đ/hộp, thành tiền: 2.310.000 đ. Tình trạng: Còn hàng.

2. Mặt hàng chưa báo giá và thông tin cần làm rõ:
- Giấy A4 80gsm: Anh chưa cho biết số lượng cụ thể cần đặt là bao nhiêu ram giấy. Bảng giá giấy A4 80 có 3 bậc giá theo số lượng (dưới 5 ram, 5-19 ram và từ 20 ram trở lên), nên nhờ anh báo giúp số lượng giấy A4 80 anh cần mua là bao nhiêu ram để bên em áp đúng bậc giá và báo giá chính xác.
- Địa chỉ giao hàng: Anh chưa cung cấp địa chỉ giao hàng cụ thể (giao về đâu, quận/huyện nào) nên bên em chưa thể xác định khu vực và chưa tính phí giao hàng.

3. Về thời gian giao hàng:
- Anh có nhắn cần gấp trong chiều nay, tuy nhiên theo quy định công ty, nhân viên kinh doanh không được hứa hay cam kết ngày giờ giao cụ thể. Thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi chốt đơn và thanh toán.

4. Tham số thuế và hiệu lực:
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực báo giá: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": """1. Quý khách vui lòng cho biết số lượng giấy A4 80 gsm cần mua cụ thể là bao nhiêu ram để công ty áp đúng bậc giá và tính tiền?
2. Quý khách vui lòng cung cấp địa chỉ giao hàng cụ thể (số nhà, đường, quận/huyện, tỉnh/thành phố) để công ty xác định khu vực và tính phí giao hàng."""
        },
        {
            "id": "R03",
            "kinh_gui": "Anh/chị Hạnh (hanh.vp@example.com)",
            "dia_chi_giao": "Tòa nhà Mẫu số 3 đường Demo, Quận Cầu Giấy, Hà Nội (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R03 - email 'bao gia'",
            "trang_thai": ["THIEU_THONG_TIN"],
            "lines": [
                {"ma_hang": "GIAY-A4-80", "so_luong": 10, "ghi_chu": "Giá bậc 2 (từ 5 ram)"},
                {"ma_hang": "MUC-HP-12A", "so_luong": 3, "ghi_chu": "Giá bậc 2 (từ 3 hộp)"},
            ],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Đơn dưới 10.000.000đ, không có chiết khấu",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: THIEU_THONG_TIN. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: Re: bao gia

Chào bạn Hạnh,

Công ty An Phát Demo cảm ơn bạn đã gửi yêu cầu báo giá.
Chúng tôi xin gửi bảng báo giá nháp cho các mặt hàng đúng mã hiện có trong bảng giá, đồng thời làm rõ một số mã hàng chưa có trong bảng giá như sau:

1. Mặt hàng đã báo giá:
- Giấy A4 80gsm (mã GIAY-A4-80): 10 ram, đơn giá bậc 2 là 72.000 đ/ram, thành tiền: 720.000 đ.
- Hộp mực HP 12A (mã MUC-HP-12A): 3 hộp, đơn giá bậc 2 là 385.000 đ/hộp, thành tiền: 1.155.000 đ.
- Tổng tiền hàng đã báo giá: 1.875.000 đ. Phí giao hàng nội thành Quận Cầu Giấy (đơn dưới 3.000.000 đ) là 40.000 đ.

2. Mặt hàng chưa báo giá do mã hàng không có trong bảng giá (cần xác nhận lại):
- Mã MUC-HP-12C (4 hộp): Hiện tại trong bảng giá của công ty không có mã hộp mực 12C (chỉ có mã hộp mực MUC-HP-12A). Bạn vui lòng xác nhận lại xem có bị nhầm mã không, hoặc mã chính xác bạn cần đặt là mã nào?
- Mã BUT-GEL-05-XANH (2 hộp màu xanh): Hiện tại bảng giá của công ty không có bút gel màu xanh (mã BUT-GEL-05-XANH không tồn tại trong bảng giá), công ty chỉ có bút gel 0.5mm mực đen (mã BUT-GEL-05-DEN). Bạn vui lòng xác nhận xem có thể đổi sang bút gel mực đen không, hoặc để bên mình kiểm tra khả năng nhập hàng ngoài bảng giá?

3. Giao hàng và Tham số:
- Thời gian giao hàng: Thời gian giao hàng cụ thể sẽ do bộ phận kho xác nhận bằng văn bản sau khi đơn hàng được chốt và thanh toán, công ty không cam kết ngày giờ giao cụ thể.
- Mức VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": """1. Mã hộp mực MUC-HP-12C (số lượng 4 hộp) không có trong bảng giá hiện hành của công ty (chỉ có mã MUC-HP-12A). Quý khách vui lòng kiểm tra và xác nhận lại mã hộp mực chính xác cần đặt có phải là MUC-HP-12A không hay là mã nào khác?
2. Mã bút gel BUT-GEL-05-XANH (2 hộp màu xanh) không có trong bảng giá (công ty chỉ có bút gel mực đen BUT-GEL-05-DEN). Quý khách vui lòng xác nhận có thể đổi sang bút gel đen BUT-GEL-05-DEN không, hay cần đặt đúng loại mực xanh để chuyển phòng mua hàng tìm kiếm?"""
        },
        {
            "id": "R04",
            "kinh_gui": "Chị Mai - Phòng Hành chính (mai.hanhchinh@example.com)",
            "dia_chi_giao": "25 Đường Mẫu, Quận 7, TP. Hồ Chí Minh (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R04 - email 'Báo giá thiết bị cho năm học mới'",
            "trang_thai": ["CAN_NGUOI_QUYET"],
            "lines": [
                {"ma_hang": "GIAY-A4-70", "so_luong": 30, "ghi_chu": "Giá bậc 3 (từ 20 ram)"},
            ],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Đơn dưới 10.000.000đ, không có chiết khấu",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: CAN_NGUOI_QUYET. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: Re: Báo giá thiết bị cho năm học mới

Kính gửi: Chị Mai - Phòng Hành chính,

Công ty An Phát Demo cảm ơn nhà trường đã quan tâm và gửi yêu cầu báo giá trang thiết bị cho năm học mới.
Chúng tôi xin phản hồi chi tiết các hạng mục như sau:

1. Mặt hàng đã báo giá:
- Giấy A4 70gsm (mã GIAY-A4-70): 30 ram, áp dụng đơn giá bậc 3 (từ 20 ram) là 58.000 đ/ram, thành tiền: 1.740.000 đ. Tình trạng: Còn hàng.
- Phí giao hàng nội thành Quận 7, TP. HCM (đơn dưới 3.000.000 đ) là 40.000 đ.

2. Mặt hàng chưa có trong bảng giá (CẦN NGƯỜI QUYẾT):
- Máy photocopy A3 đa năng (1 cái) và Máy chiếu độ phân giải 4K (2 cái): Hiện tại hai mặt hàng thiết bị này không có trong bảng giá hiện hành của công ty. Theo chính sách, nhân viên không được tự ý đặt giá hoặc thay thế sang mặt hàng khác. Yêu cầu về máy photocopy và máy chiếu 4K của trường đã được chuyển sang phòng mua hàng và cần người quyết (ban giám đốc duyệt giá nhập và phương án cung ứng). Khi có thông tin chính thức, công ty sẽ có xác nhận bằng văn bản gửi đến trường sau.

3. Về tiến độ giao hàng:
- Nhà trường có yêu cầu cần gấp trong tuần, tuy nhiên nhân viên kinh doanh không được cam kết ngày giờ giao cụ thể. Thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi đơn hàng được chốt và thanh toán.
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "Không có câu hỏi."
        },
        {
            "id": "R05",
            "kinh_gui": "Anh Quân (quan.vt@example.com)",
            "dia_chi_giao": "88 Đường Demo, Quận Thanh Xuân, Hà Nội (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R05 - email 'RE: báo giá máy in + vật tư'",
            "trang_thai": ["CAN_NGUOI_QUYET"],
            "lines": [
                {"ma_hang": "MAY-IN-LASER-3100", "so_luong": 3, "ghi_chu": "Thuộc nhóm Thiết bị - giữ nguyên giá bảng giá (giá bậc 1)"},
                {"ma_hang": "MUC-HP-78A", "so_luong": 10, "ghi_chu": "Giá bậc 3 (từ 10 hộp)"},
                {"ma_hang": "GIAY-A4-80", "so_luong": 40, "ghi_chu": "Giá bậc 3 (từ 20 ram)"},
            ],
            "xin_giam_pct": 25.0,
            "ghi_chu_ck": "Áp dụng 2% theo giá trị đơn (10-30tr) trên dòng không thuộc Thiết bị; yêu cầu giảm 25% vượt thẩm quyền chờ duyệt",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: CAN_NGUOI_QUYET. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: Re: RE: báo giá máy in + vật tư

Chào anh Quân,

Công ty An Phát Demo cảm ơn anh đã gửi danh mục yêu cầu báo giá máy in và vật tư.
Bên em xin gửi bảng báo giá theo bảng giá hiện hành và chính sách chiết khấu của công ty như sau:

1. Chi tiết báo giá các mặt hàng:
- Máy in laser đen trắng A4 mẫu 3100: 3 cái, đơn giá bậc 1 là 3.950.000 đ/cái, thành tiền: 11.850.000 đ. (Hàng đặt hàng).
- Hộp mực HP 78A: 10 hộp, đơn giá bậc 3 (từ 10 hộp) là 385.000 đ/hộp, thành tiền: 3.850.000 đ.
- Giấy A4 80gsm: 40 ram, đơn giá bậc 3 (từ 20 ram) là 69.000 đ/ram, thành tiền: 2.760.000 đ.
- Tổng tiền hàng: 18.460.000 đ.

2. Về đề nghị giảm giá 25% (CẦN NGƯỜI QUYẾT):
- Yêu cầu giảm giá 25% toàn đơn vượt thẩm quyền của nhân viên kinh doanh (thẩm quyền nhân viên tối đa 5% và không áp dụng cho nhóm Thiết bị).
- Theo chính sách công ty, với đơn hàng từ 10.000.000 đ đến dưới 30.000.000 đ, hệ thống tự động áp dụng chiết khấu 2% tính trên các dòng không thuộc nhóm Thiết bị (Mực và Giấy: 6.610.000 đ), số tiền chiết khấu là 132.200 đ. Dòng máy in thuộc nhóm Thiết bị giữ nguyên giá bảng giá.
- Về mức chiết khấu 25% anh đề nghị, bên em đã chuyển yêu cầu lên trưởng phòng kinh doanh và giám đốc để xem xét phê duyệt. Khi có quyết định phê duyệt chính thức từ ban giám đốc, bên em sẽ có xác nhận bằng văn bản gửi anh.

3. Giao hàng và Thanh toán:
- Giao về Quận Thanh Xuân, Hà Nội (nội thành). Đơn hàng sau chiết khấu trước VAT đạt 18.327.800 đ (trên 3.000.000 đ) nên được miễn phí giao hàng.
- Thời gian giao hàng: Máy in laser mẫu 3100 là hàng đặt hàng, thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi đơn hàng được xác nhận và thanh toán, công ty không cam kết ngày giờ giao cụ thể.
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực báo giá: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "Không có câu hỏi."
        },
        {
            "id": "R06",
            "kinh_gui": "Chị Thu - NT Phú Gia (Zalo)",
            "dia_chi_giao": "5 Đường Mẫu, Quận 10, TP. Hồ Chí Minh (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R06 - tin nhắn Zalo",
            "trang_thai": ["THIEU_THONG_TIN"],
            "lines": [
                {"ma_hang": "GIAY-A4-70", "so_luong": 10, "ghi_chu": "Quy đổi: 2 thùng = 10 ram (giá bậc 2)"},
                {"ma_hang": "BUT-BI-TL027-XANH", "so_luong": 60, "ghi_chu": "Quy đổi: 5 tá = 60 cây (giá bậc 2)"},
                {"ma_hang": "BANGKEO-2MAT-24", "so_luong": 18, "ghi_chu": "Quy đổi: 3 lốc = 18 cuộn (giá bậc 2)"},
                {"ma_hang": "BUT-GEL-05-DEN", "so_luong": 24, "ghi_chu": "Quy đổi: 2 hộp = 24 cây (giá bậc 2)"},
            ],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Đơn dưới 10.000.000đ, không có chiết khấu",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: THIEU_THONG_TIN. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: (Trả lời tin nhắn Zalo) Báo giá vật tư văn phòng phẩm

Chào chị Thu (NT Phú Gia),

Công ty An Phát Demo cảm ơn chị đã gửi danh sách vật tư.
Bên em xin gửi báo giá nháp cho các mặt hàng đã có quy đổi đơn vị chuẩn trong bảng giá, đồng thời làm rõ mục mực in như sau:

1. Các mặt hàng đã báo giá (quy đổi theo bảng quy đổi đơn vị gốc):
- Giấy A4 70gsm: 2 thùng = 10 ram (1 thùng = 5 ram), đơn giá bậc 2 là 60.000 đ/ram, thành tiền: 600.000 đ.
- Bút bi xanh TL027: 5 tá = 60 cây (1 tá = 12 cây), đơn giá bậc 2 là 4.000 đ/cây, thành tiền: 240.000 đ.
- Băng keo 2 mặt 24mm: 3 lốc = 18 cuộn (1 lốc = 6 cuộn), đơn giá bậc 2 là 8.800 đ/cuộn, thành tiền: 158.400 đ.
- Bút gel đen 0.5mm: 2 hộp = 24 cây (1 hộp = 12 cây), đơn giá bậc 2 là 6.000 đ/cây, thành tiền: 144.000 đ.
- Tổng tiền hàng đã tính: 1.142.400 đ.
- Phí giao hàng nội thành Quận 10, TP. HCM (đơn dưới 3.000.000 đ): 40.000 đ.

2. Mặt hàng chưa báo giá (cần làm rõ quy đổi):
- Mục '1 thùng mực HP 12A': Trong bảng quy đổi của công ty chỉ có quy đổi giấy, bút, băng keo và thùng carton, chưa có quy đổi đơn vị 'thùng' cho mực in HP 12A (đơn vị gốc trong bảng giá là hộp). Chị vui lòng cho bên em biết 1 thùng mực HP 12A chị cần đặt là bao nhiêu hộp (quy cách thùng mấy hộp) hoặc số lượng hộp cụ thể chị cần mua là bao nhiêu hộp để bên em áp giá chính xác ạ.

3. Giao hàng và Tham số:
- Thời gian giao hàng: Thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi đơn hàng được chốt và thanh toán, công ty không cam kết ngày giờ giao cụ thể.
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "1. Đối với mặt hàng mực HP 12A: do đơn vị 'thùng' chưa có quy định quy đổi trong bảng quy đổi của công ty, chị vui lòng cho biết 1 thùng mực HP 12A quy đổi bằng bao nhiêu hộp (quy cách đóng gói là mấy hộp/thùng) hoặc số lượng hộp cụ thể chị cần đặt là bao nhiêu hộp để công ty báo giá chính xác?"
        },
        {
            "id": "R07",
            "kinh_gui": "Anh Kiên (kien.kho@example.com)",
            "dia_chi_giao": "15 Đường Mẫu, Quận Gò Vấp, TP. HCM (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R07 - email 'Báo giá lại đợt trước'",
            "trang_thai": ["CAN_NGUOI_QUYET"],
            "lines": [
                {"ma_hang": "BUT-BI-TL027-XANH", "so_luong": 50, "ghi_chu": "Giá bậc 2 (từ 50 cây: 4.000đ; khách yêu cầu giữ giá cũ 3.500đ)"},
                {"ma_hang": "SO-CARO-A4-200", "so_luong": 49, "ghi_chu": "Giá bậc 2 (từ 10 đến 49 quyển)"},
                {"ma_hang": "FILE-COC-7P", "so_luong": 100, "ghi_chu": "Giá bậc 3 (từ 50 cái trở lên)"},
            ],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Đơn dưới 10.000.000đ, không có chiết khấu theo đơn",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: CAN_NGUOI_QUYET. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: Re: Báo giá lại đợt trước

Chào anh Kiên,

Công ty An Phát Demo cảm ơn anh đã tiếp tục liên hệ đặt hàng.
Về yêu cầu báo giá của anh, chúng tôi xin gửi báo giá theo bảng giá hiện hành như sau:

1. Báo giá theo bảng giá hiện hành:
- Bút bi xanh TL027 (mã BUT-BI-TL027-XANH): 50 cây, đơn giá bậc 2 hiện hành (áp dụng từ 50 đến 199 cây) là 4.000 đ/cây, thành tiền: 200.000 đ.
- Sổ kẻ caro A4 200 trang (mã SO-CARO-A4-200): 49 quyển, đơn giá bậc 2 (từ 10 đến 49 quyển) là 35.500 đ/quyển, thành tiền: 1.739.500 đ. (Lưu ý: từ 50 quyển đơn giá là 33.000 đ/quyển).
- File còng bìa 7 cm (mã FILE-COC-7P): 100 cái, đơn giá bậc 3 (từ 50 cái trở lên) là 31.000 đ/cái, thành tiền: 3.100.000 đ.
- Tổng tiền hàng: 5.039.500 đ.
- Giao tại Quận Gò Vấp, TP. HCM (nội thành). Đơn hàng trên 3.000.000 đ nên được miễn phí giao hàng.

2. Về đề nghị giữ giá cũ 3.500 đ/cây cho bút bi TL027 (CẦN NGƯỜI QUYẾT):
- Theo chính sách giá của công ty, công ty không tự động giữ giá cũ đã báo từ lần trước mà phải áp dụng theo bảng giá hiện hành mới nhất (áp dụng từ 01/11/2026, giá bậc 2 là 4.000 đ/cây). Nhân viên kinh doanh không có thẩm quyền tự đồng ý giá cũ 3.500 đ.
- Yêu cầu giữ lại mức giá cũ 3.500 đồng/cây của anh đã được chuyển lên trưởng phòng kinh doanh để xem xét phê duyệt. Khi có quyết định phê duyệt từ trưởng phòng, bên em sẽ có xác nhận bằng văn bản gửi anh.

3. Thời gian giao hàng và Thuế:
- Thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi đơn hàng được chốt và thanh toán, công ty không cam kết ngày giờ giao cụ thể.
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực báo giá: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "Không có câu hỏi."
        },
        {
            "id": "R08",
            "kinh_gui": "Anh/chị Phương - Quản lý Xưởng (phuong.xuong@example.com)",
            "dia_chi_giao": "Lô B2, Khu công nghiệp Mẫu, Bắc Ninh (ngoại tỉnh)",
            "dia_chi_loai": "ngoai_tinh",
            "theo_yeu_cau_so": "R08 - email 'Báo giá vật tư đóng gói - gấp'",
            "trang_thai": ["CAN_NGUOI_QUYET"],
            "lines": [
                {"ma_hang": "THUNG-CARTON-30X20X20", "so_luong": 300, "ghi_chu": "Giá bậc 3 (từ 200 cái)"},
                {"ma_hang": "MANG-BOC-PE-50CM", "so_luong": 24, "ghi_chu": "Giá bậc 3 (từ 20 cuộn)"},
                {"ma_hang": "BANGKEO-TRONG-48", "so_luong": 72, "ghi_chu": "Giá bậc 3 (từ 72 cuộn trở lên)"},
            ],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Đơn dưới 10.000.000đ, không có chiết khấu",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: CAN_NGUOI_QUYET. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: Re: Báo giá vật tư đóng gói - gấp

Chào anh/chị Phương,

Công ty An Phát Demo cảm ơn xưởng đã gửi yêu cầu báo giá vật tư đóng gói.
Chúng tôi xin gửi bảng báo giá tiền hàng chi tiết như sau:

1. Báo giá tiền hàng vật tư:
- Thùng carton 5 lớp 30x20x20 cm: 300 cái, đơn giá bậc 3 (từ 200 cái) là 8.200 đ/cái, thành tiền: 2.460.000 đ.
- Màng bọc PE khổ 50 cm: 24 cuộn, đơn giá bậc 3 (từ 20 cuộn) là 116.000 đ/cuộn, thành tiền: 2.784.000 đ.
- Băng keo trong 48 mm x 100 yard: 72 cuộn, đơn giá bậc 3 (từ 72 cuộn trở lên) là 12.500 đ/cuộn, thành tiền: 900.000 đ.
- Tổng tiền hàng: 6.144.000 đ. Mức thuế VAT tạm tính 10% là 614.400 đ. Tổng cộng tiền hàng gồm VAT: 6.758.400 đ.

2. Phí vận chuyển ngoại tỉnh (CẦN NGƯỜI QUYẾT):
- Địa chỉ nhận hàng tại Khu công nghiệp Mẫu, Bắc Ninh thuộc khu vực ngoại tỉnh. Theo điều kiện giao hàng, chi phí vận chuyển / giao hàng theo thỏa thuận cước thực tế của đơn vị vận chuyển, do nhân viên điều phối báo sau và cần người quyết, nhân viên kinh doanh không được tự đặt con số phí ship ngoại tỉnh trong báo giá.

3. Yêu cầu giao hàng gấp trước 10 giờ sáng thứ Sáu (CẦN NGƯỜI QUYẾT):
- Về yêu cầu cam kết giao hàng trước 10 giờ sáng thứ Sáu: Theo quy định công ty, nhân viên kinh doanh không cam kết ngày giờ giao cụ thể. Việc khách đòi giao đúng giờ hoặc giao gấp phải chuyển người quyết (trưởng kho hoặc giám đốc duyệt điều phối chuyến xe riêng). Lịch giao hàng cụ thể sẽ do bộ phận kho xác nhận bằng văn bản sau khi đơn hàng và phương án vận chuyển được phê duyệt.
- Mức thuế VAT theo tham số, cần kiểm với kế toán trước khi gửi. Hiệu lực báo giá: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "Không có câu hỏi."
        },
        {
            "id": "R09",
            "kinh_gui": "Chú Sơn (Zalo)",
            "dia_chi_giao": "Chưa có địa chỉ giao hàng cụ thể ('giao cho cho cu')",
            "dia_chi_loai": "chua_biet",
            "theo_yeu_cau_so": "R09 - tin nhắn Zalo",
            "trang_thai": ["THIEU_THONG_TIN"],
            "lines": [],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Chưa có thông tin đơn hàng",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: THIEU_THONG_TIN. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: (Trả lời tin nhắn Zalo) Báo giá như đợt trước

Chào chú Sơn,

Công ty An Phát Demo cảm ơn chú đã nhắn tin liên hệ đặt hàng.
Về yêu cầu 'báo giá như đợt trước, số lượng tăng gấp đôi, giao chỗ cũ' của chú, do tin nhắn chưa có thông tin chi tiết và nhân viên không được tự ý phỏng đoán dữ liệu, bên cháu chưa thể lập bảng báo giá tiền hàng ngay được. Cháu xin phép hỏi lại chú các thông tin cần thiết sau:

1. Chú vui lòng gửi lại danh sách mặt hàng cụ thể của đợt trước gồm những mặt hàng nào (hoặc mã hàng, tên hàng, mã đơn hàng cũ) để bên cháu kiểm tra lại chính xác danh mục hàng hóa.
2. Chú vui lòng xác nhận số lượng cụ thể của từng món hàng cần đặt lần này là bao nhiêu để bên cháu áp đúng bậc giá số lượng ưu đãi cho chú.
3. Chú vui lòng cung cấp lại địa chỉ giao hàng cụ thể (địa chỉ giao đến số nhà, đường, quận/huyện nào) để bên cháu kiểm tra khu vực và tính toán phương án giao hàng.

Khi nhận được thông tin chi tiết từ chú, bên cháu sẽ lập bảng báo giá đầy đủ gửi chú ngay ạ.
Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi. Thời gian giao hàng sẽ do kho xác nhận bằng văn bản sau khi chốt đơn.

Kính chúc chú sức khỏe!""",
            "cau_hoi": """1. Chú vui lòng gửi lại danh sách mặt hàng cụ thể của đợt trước (tên hàng, mã hàng hoặc thông tin đơn hàng cũ) để công ty tra cứu chính xác mặt hàng cần báo giá.
2. Chú vui lòng cho biết số lượng cụ thể cần đặt của từng mặt hàng là bao nhiêu để công ty áp đúng bậc giá theo số lượng.
3. Chú vui lòng cung cấp lại địa chỉ giao hàng cụ thể (số nhà, đường, quận/huyện, tỉnh/thành phố) để công ty xác định phí vận chuyển và phương án giao hàng."""
        },
        {
            "id": "R10",
            "kinh_gui": "Chị Ngọc - SaoMai (Zalo)",
            "dia_chi_giao": "30 Đường Demo, Quận Cầu Giấy, Hà Nội (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R10 - tin nhắn Zalo",
            "trang_thai": ["SAN_SANG"],
            "lines": [
                {"ma_hang": "MUC-HP-78A", "so_luong": 6, "ghi_chu": "Gộp dòng: 4 hộp + 2 hộp = 6 hộp (giá bậc 2)"},
                {"ma_hang": "GIAY-A4-70", "so_luong": 15, "ghi_chu": "Gộp dòng & quy đổi: 10 ram + 1 thùng (5 ram) = 15 ram (giá bậc 2)"},
                {"ma_hang": "MAY-HUY-GIAY-S12", "so_luong": 1, "ghi_chu": "Thuộc nhóm Thiết bị - giữ giá bảng giá (giá bậc 1)"},
                {"ma_hang": "GHE-XOAY-LUOI-01", "so_luong": 6, "ghi_chu": "Thuộc nhóm Thiết bị - giữ giá bảng giá (giá bậc 2)"},
                {"ma_hang": "MUC-EPS-664-DEN", "so_luong": 12, "ghi_chu": "Giá bậc 2 (từ 6 chai)"},
            ],
            "xin_giam_pct": 2.0,
            "ghi_chu_ck": "Tổng chiết khấu 4% (2% theo đơn 10-30tr + 2% nhân viên duyệt thêm), tính trên dòng không thuộc Thiết bị",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: SAN_SANG. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: (Trả lời tin nhắn Zalo) Báo giá vật tư và thiết bị văn phòng

Chào chị Ngọc (SaoMai),

Công ty An Phát Demo cảm ơn chị đã gửi danh sách đặt hàng.
Bên em đã tổng hợp, gộp các dòng trùng theo yêu cầu và lập báo giá chi tiết như sau:

1. Chi tiết các mặt hàng (đã gộp số lượng và quy đổi):
- Hộp mực HP 78A: 4 hộp + 2 hộp thêm = 6 hộp, áp dụng đơn giá bậc 2 là 398.000 đ/hộp, thành tiền: 2.388.000 đ.
- Giấy A4 70gsm: 10 ram + 1 thùng (5 ram) = 15 ram, đơn giá bậc 2 là 60.000 đ/ram, thành tiền: 900.000 đ.
- Máy hủy giấy 12 tờ/lần (mã MAY-HUY-GIAY-S12): 1 cái, đơn giá bậc 1 là 2.850.000 đ/cái, thành tiền: 2.850.000 đ.
- Ghế xoay lưng lưới mẫu 01: 6 cái, đơn giá bậc 2 (từ 5 cái) là 1.100.000 đ/cái, thành tiền: 6.600.000 đ.
- Mực nước Epson 664 đen: 12 chai, đơn giá bậc 2 (từ 6 chai) là 94.000 đ/chai, thành tiền: 1.128.000 đ.
- Tổng tiền hàng: 13.866.000 đ.

2. Chiết khấu:
- Đơn hàng đạt 13.866.000 đ (từ 10 đến dưới 30 triệu đồng), theo chính sách công ty được hưởng chiết khấu 2% theo giá trị đơn.
- Chị có xin giảm thêm 2%, nhân viên kinh doanh đồng ý duyệt thêm 2% trong thẩm quyền cho phép. Tổng mức chiết khấu là 4% (≤ 5% trong thẩm quyền nhân viên tự quyết).
- Theo quy định, chiết khấu tính trên các dòng không thuộc nhóm Thiết bị (Mực và Giấy: 4.416.000 đ), số tiền chiết khấu là 176.640 đ. Nhóm Thiết bị (máy hủy giấy, ghế xoay) giữ nguyên giá bảng giá.

3. Giao hàng và Thanh toán:
- Giao về 30 Đường Demo, Quận Cầu Giấy, Hà Nội (nội thành). Đơn hàng trên 3.000.000 đ nên được miễn phí giao hàng.
- Thời gian giao hàng: Thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi đơn hàng được chốt và thanh toán, công ty không cam kết ngày giờ giao cụ thể.
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực báo giá: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "Không có câu hỏi."
        },
        {
            "id": "R11",
            "kinh_gui": "Anh Hùng - Phòng Mua hàng (hung.mua@example.com)",
            "dia_chi_giao": "200 Đường Mẫu, Quận Hoàng Mai, Hà Nội (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R11 - email 'Báo giá trang bị văn phòng mới (đợt lớn)'",
            "trang_thai": ["CAN_NGUOI_QUYET"],
            "lines": [
                {"ma_hang": "MAY-IN-LASER-3100", "so_luong": 6, "ghi_chu": "Thuộc nhóm Thiết bị - giữ giá bảng giá (giá bậc 2)"},
                {"ma_hang": "MAY-SCAN-A4-100", "so_luong": 2, "ghi_chu": "Thuộc nhóm Thiết bị - giữ giá bảng giá (giá bậc 1)"},
                {"ma_hang": "CC-VANTAY-01", "so_luong": 4, "ghi_chu": "Thuộc nhóm Thiết bị - giữ giá bảng giá (giá bậc 1)"},
                {"ma_hang": "GIAY-A4-80", "so_luong": 60, "ghi_chu": "Giá bậc 3 (từ 20 ram)"},
                {"ma_hang": "MUC-CANON-325", "so_luong": 12, "ghi_chu": "Giá bậc 3 (từ 10 hộp); Tình trạng kho: Tạm hết hàng, chờ nhập"},
            ],
            "xin_giam_pct": 10.0,
            "ghi_chu_ck": "Áp dụng 4% theo đơn (≥30tr) trên dòng không thuộc Thiết bị; yêu cầu giảm 10% và quà tặng chờ duyệt",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: CAN_NGUOI_QUYET. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: Re: Báo giá trang bị văn phòng mới (đợt lớn)

Kính gửi: Anh Hùng - Phòng Mua hàng,

Công ty An Phát Demo trân trọng cảm ơn anh đã gửi yêu cầu báo giá trang thiết bị cho văn phòng mới.
Chúng tôi xin gửi bảng báo giá theo bảng giá hiện hành và chính sách của công ty như sau:

1. Báo giá chi tiết các mặt hàng:
- Máy in laser đen trắng A4 mẫu 3100: 6 cái, đơn giá bậc 2 là 3.850.000 đ/cái, thành tiền: 23.100.000 đ. (Tình trạng: Đặt hàng).
- Máy scan A4 hai mặt mẫu 100: 2 cái, đơn giá bậc 1 là 6.200.000 đ/cái, thành tiền: 12.400.000 đ. (Tình trạng: Đặt hàng).
- Máy chấm công vân tay mẫu 01: 4 cái, đơn giá bậc 1 là 2.300.000 đ/cái, thành tiền: 9.200.000 đ.
- Giấy A4 80gsm: 60 ram, đơn giá bậc 3 (từ 20 ram) là 69.000 đ/ram, thành tiền: 4.140.000 đ.
- Hộp mực Canon 325: 12 hộp, đơn giá bậc 3 (từ 10 hộp) là 380.000 đ/hộp, thành tiền: 4.560.000 đ. (Lưu ý: Mặt hàng mực Canon 325 hiện đang trong tình trạng Tạm hết hàng, chờ nhập kho).
- Tổng tiền hàng: 53.400.000 đ.

2. Về đề nghị chiết khấu 10% và Quà tặng (CẦN NGƯỜI QUYẾT):
- Yêu cầu giảm 10% toàn đơn: Mức chiết khấu 10% toàn đơn vượt thẩm quyền tự quyết của nhân viên kinh doanh. Theo chính sách, đơn từ 30.000.000 đ trở lên được chiết khấu 4% tính trên các dòng không thuộc nhóm Thiết bị (Giấy và Mực: 8.700.000 đ), số tiền chiết khấu là 348.000 đ. Các dòng máy thuộc nhóm Thiết bị giữ nguyên giá bảng giá. Đề nghị chiết khấu 10% này cần người quyết (đã được chuyển lên trưởng phòng kinh doanh và giám đốc xem xét duyệt).
- Yêu cầu quà tặng mua 10 ram giấy tặng 1 ram giấy: Theo chính sách công ty, mọi chương trình khuyến mại, quà tặng kèm ngoài chính sách chỉ do giám đốc quyết định, nhân viên không thể hứa trước. Yêu cầu tặng quà này cũng cần người quyết (đã chuyển lên giám đốc phê duyệt).
- Khi có ý kiến phê duyệt chính thức từ ban giám đốc, bên em sẽ có xác nhận bằng văn bản gửi anh.

3. Giao hàng và Thanh toán:
- Giao về 200 Đường Mẫu, Quận Hoàng Mai, Hà Nội (nội thành). Đơn hàng trên 3.000.000 đ nên được miễn phí giao hàng.
- Thời gian giao hàng: Đơn có các mặt hàng 'Đặt hàng' và 'Tạm hết hàng, chờ nhập' (mực Canon 325), ngày có hàng cụ thể do kho và phòng mua hàng xác nhận bằng văn bản, công ty không cam kết ngày giờ giao cụ thể trong báo giá.
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực báo giá: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "Không có câu hỏi."
        },
        {
            "id": "R12",
            "kinh_gui": "Bạn Vy Sohong (Zalo)",
            "dia_chi_giao": "7 Đường Mẫu, Quận Bắc Từ Liêm, Hà Nội (nội thành)",
            "dia_chi_loai": "noi_thanh",
            "theo_yeu_cau_so": "R12 - tin nhắn Zalo",
            "trang_thai": ["THIEU_THONG_TIN", "CAN_NGUOI_QUYET"],
            "lines": [
                {"ma_hang": "GIAY-A4-70", "so_luong": 25, "ghi_chu": "Quy đổi: 5 thùng = 25 ram (giá bậc 3)"},
                {"ma_hang": "BUT-BI-TL027-XANH", "so_luong": 24, "ghi_chu": "Quy đổi: 2 tá = 24 cây (giá bậc 1)"},
                {"ma_hang": "DECAL-A4-100", "so_luong": 3, "ghi_chu": "Giá bậc 1 (dưới 5 xấp)"},
                {"ma_hang": "MANG-BOC-PE-50CM", "so_luong": 2, "ghi_chu": "Giá bậc 1 (dưới 5 cuộn)"},
                {"ma_hang": "KEP-BUOM-32", "so_luong": 4, "ghi_chu": "Giá bậc 1 (dưới 10 hộp)"},
            ],
            "xin_giam_pct": 0,
            "ghi_chu_ck": "Đơn dưới 10.000.000đ, không có chiết khấu",
            "email": """[EMAIL NHÁP - chưa gửi. Trạng thái: THIEU_THONG_TIN; CAN_NGUOI_QUYET. Người duyệt kiểm tra trước khi gửi; mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.]
Tiêu đề: (Trả lời tin nhắn Zalo) Báo giá vật tư văn phòng

Chào bạn Vy Sohong,

Công ty An Phát Demo cảm ơn bạn đã gửi danh sách đặt mua văn phòng phẩm.
Bên mình xin gửi bảng báo giá chi tiết và phản hồi các yêu cầu của bạn như sau:

1. Báo giá chi tiết các mặt hàng (quy đổi theo đơn vị gốc):
- Giấy A4 70gsm: 5 thùng = 25 ram (1 thùng = 5 ram), đơn giá bậc 3 (từ 20 ram) là 58.000 đ/ram, thành tiền: 1.450.000 đ.
- Bút bi xanh TL027: 2 tá = 24 cây (1 tá = 12 cây), đơn giá bậc 1 là 4.500 đ/cây, thành tiền: 108.000 đ.
- Giấy decal A4 trắng: 3 xấp, đơn giá bậc 1 là 85.000 đ/xấp, thành tiền: 255.000 đ.
- Màng bọc PE khổ 50cm: 2 cuộn, đơn giá bậc 1 là 128.000 đ/cuộn, thành tiền: 256.000 đ.
- Kẹp bướm 32 mm: 4 hộp, đơn giá bậc 1 là 21.000 đ/hộp, thành tiền: 84.000 đ.
- Tổng tiền hàng: 2.153.000 đ.
- Giao về Quận Bắc Từ Liêm, Hà Nội (nội thành). Đơn hàng sau chiết khấu trước VAT dưới 3.000.000 đ nên phí giao hàng là 40.000 đ.

2. Về thông tin xuất hóa đơn công ty (THIẾU THÔNG TIN):
- Bạn có yêu cầu xuất hóa đơn công ty nhưng chưa cung cấp thông tin. Để bộ phận kế toán kiểm tra và xuất hóa đơn đúng quy định, bạn vui lòng cung cấp thông tin xuất hóa đơn gồm: Tên đầy đủ của công ty, Mã số thuế (MST) và Địa chỉ đăng ký kinh doanh của công ty.

3. Về yêu cầu công nợ 30 ngày (CẦN NGƯỜI QUYẾT):
- Bạn có xin chính sách thanh toán công nợ 30 ngày. Theo quy chế công ty, hình thức bán nợ, công nợ 30 ngày chỉ do giám đốc có thẩm quyền phê duyệt, nhân viên kinh doanh không được tự hứa hay đồng ý. Yêu cầu công nợ 30 ngày này cần người quyết (bên mình đã chuyển lên giám đốc xem xét duyệt) và sẽ có xác nhận sau. Mặc định phương thức thanh toán là chuyển khoản trước khi giao hàng.

4. Thời gian giao hàng và Thuế:
- Thời gian giao hàng cụ thể sẽ do kho xác nhận bằng văn bản sau khi đơn hàng được chốt và thống nhất thanh toán, công ty không cam kết ngày giờ giao cụ thể.
- Mức thuế VAT tạm tính 10% (mức VAT theo tham số, cần kiểm với kế toán trước khi gửi). Hiệu lực báo giá: 7 ngày kể từ 20/11/2026.

Trân trọng!""",
            "cau_hoi": "1. Để phục vụ việc xuất hóa đơn công ty theo yêu cầu, bạn vui lòng cung cấp đầy đủ thông tin xuất hóa đơn gồm: Tên pháp lý đầy đủ của công ty, Mã số thuế (MST) và Địa chỉ trụ sở chính đăng ký kinh doanh."
        }
    ]

    summary = []

    for req in ds_yeu_cau:
        rid = req["id"]
        calc = tinh_toan_bao_gia(
            lines_input=req["lines"],
            xin_giam_pct=req["xin_giam_pct"],
            dia_chi_loai=req["dia_chi_loai"],
            vat_percent=10
        )

        # 1. Ghi file xlsx
        xlsx_out = DAU_RA_DIR / f"{rid}-bao-gia.xlsx"
        dien_vao_mau_excel(req, calc, xlsx_out)

        # 2. Ghi file email.txt
        email_out = DAU_RA_DIR / f"{rid}-email.txt"
        email_out.write_text(req["email"].strip() + "\n", encoding="utf-8")

        # 3. Ghi file cau-hoi.txt
        cau_hoi_out = DAU_RA_DIR / f"{rid}-cau-hoi.txt"
        cau_hoi_out.write_text(req["cau_hoi"].strip() + "\n", encoding="utf-8")

        summary.append({
            "id": rid,
            "trang_thai": "; ".join(req["trang_thai"]),
            "tong_cong": calc["tong_cong"]
        })

    print(f"{'Mã YC':<8} | {'Trạng thái':<30} | {'Tổng cộng (VNĐ)':>15}")
    print("-" * 60)
    for s in summary:
        print(f"{s['id']:<8} | {s['trang_thai']:<30} | {s['tong_cong']:>15,}".replace(",", "."))

if __name__ == "__main__":
    chay_tat_ca()
