# -*- coding: utf-8 -*-
"""
Script tính tiền báo giá và tạo các file đầu ra cho bài toán An Phát Demo.
Tuân thủ đầy đủ các chính sách chiết khấu, bảng giá, điều kiện giao hàng và mẫu báo giá.
"""

import os
import openpyxl
from decimal import Decimal, ROUND_HALF_UP

def round_vnd(val):
    """Làm tròn số tiền đến đồng, 0.5 đồng làm tròn lên."""
    if val is None:
        return None
    d = Decimal(str(val))
    return int(d.quantize(Decimal('1'), rounding=ROUND_HALF_UP))

def load_bang_gia(filepath='bang-gia.xlsx'):
    """Đọc dữ liệu từ bảng giá và quy đổi đơn vị."""
    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws_bg = wb['BangGia']
    items = {}
    for r in ws_bg.iter_rows(min_row=4, values_only=True):
        if r[0]:
            code = str(r[0]).strip()
            items[code] = {
                'code': code,
                'name': r[1],
                'group': r[2],
                'unit': r[3],
                'p1': r[4],
                't2': r[5],
                'p2': r[6],
                't3': r[7],
                'p3': r[8],
                'stock': r[9]
            }

    ws_qd = wb['QuyDoi']
    conversions = {}
    for r in ws_qd.iter_rows(min_row=3, values_only=True):
        if r[0]:
            code = str(r[0]).strip()
            other_unit = str(r[1]).strip().lower()
            mult = r[2]
            conversions[(code, other_unit)] = mult

    return items, conversions

def load_tham_so(filepath='mau-bao-gia.xlsx'):
    """Đọc tham số tính toán từ sheet Tham số."""
    wb = openpyxl.load_workbook(filepath, data_only=True)
    ws_ts = wb['Tham số']
    params = {}
    for r in ws_ts.iter_rows(min_row=2, values_only=True):
        if r[0]:
            params[str(r[0]).strip()] = r[1]
    return params

def tra_bac_gia(item_info, quantity):
    """
    Tra bậc giá dựa vào số lượng theo đơn vị gốc:
    - SL < Bậc 2: Giá bậc 1
    - Bậc 2 <= SL < Bậc 3: Giá bậc 2
    - SL >= Bậc 3: Giá bậc 3
    """
    if item_info is None or quantity is None or quantity <= 0:
        return None
    t2 = item_info['t2']
    t3 = item_info['t3']
    p1 = item_info['p1']
    p2 = item_info['p2']
    p3 = item_info['p3']
    
    if t2 is not None and quantity < t2:
        return p1
    elif t3 is not None and quantity >= t3:
        return p3
    elif t2 is not None and quantity >= t2:
        return p2
    else:
        return p1

def tinh_bao_gia(lines_input, dia_chi_khu_vuc, yc_chiet_khau_them, bang_gia, quy_doi, vat_percent=10):
    """
    Tính tiền cho một báo giá:
    - lines_input: danh sách dict từng dòng
    - dia_chi_khu_vuc: 'noi_thanh', 'ngoai_tinh', hoặc 'chua_ro'
    - yc_chiet_khau_them: thông tin yêu cầu chiết khấu
    """
    processed_lines = []
    cong_tien_hang = 0
    tien_hang_phi_thiet_bi = 0
    
    for idx, line in enumerate(lines_input, start=1):
        code = line.get('code')
        name = line.get('name')
        unit = line.get('unit')
        qty = line.get('qty')
        note = line.get('note', '')
        
        item_info = bang_gia.get(code) if code else None
        
        if item_info:
            group = item_info['group']
            final_unit = item_info['unit']
            # Kiểm tra nếu cần gán tên chuẩn
            if not name:
                name = item_info['name']
        else:
            group = None
            final_unit = unit
            
        # Tra giá và thành tiền
        if item_info and qty is not None and qty > 0:
            unit_price = tra_bac_gia(item_info, qty)
            thanh_tien = round_vnd(qty * unit_price)
            cong_tien_hang += thanh_tien
            if group != 'Thiết bị':
                tien_hang_phi_thiet_bi += thanh_tien
        else:
            unit_price = None
            thanh_tien = None
            
        processed_lines.append({
            'stt': idx,
            'code': code if code else '',
            'name': name if name else '',
            'unit': final_unit if final_unit else '',
            'qty': qty,
            'unit_price': unit_price,
            'thanh_tien': thanh_tien,
            'note': note,
            'group': group
        })
        
    # Tính chiết khấu
    # Chiết khấu tự động mục 2:
    if cong_tien_hang >= 30000000:
        rate_auto = 0.04
    elif cong_tien_hang >= 10000000:
        rate_auto = 0.02
    else:
        rate_auto = 0.00
        
    # Xử lý chiết khấu thêm theo chính sách
    # yc_chiet_khau_them: dict {
    #   'asked': bool,
    #   'rate_asked': float,
    #   'scope': 'non_equipment' | 'all' | 'specific_item',
    #   'within_authority': bool
    # }
    rate_extra = 0.0
    discount_note = ""
    
    if yc_chiet_khau_them and yc_chiet_khau_them.get('asked'):
        asked_rate = yc_chiet_khau_them.get('rate_asked', 0.0)
        within_auth = yc_chiet_khau_them.get('within_authority', False)
        
        if within_auth:
            rate_extra = asked_rate
            total_rate = rate_auto + rate_extra
            discount_amount = round_vnd(tien_hang_phi_thiet_bi * total_rate)
            pct_display = int(total_rate * 100) if (total_rate * 100).is_integer() else f"{total_rate * 100:.1f}"
            discount_note = f"{pct_display}% ({yc_chiet_khau_them.get('note_text', 'giảm theo đề nghị của khách')})"
        else:
            # Vượt thẩm quyền hoặc xin cho Thiết bị: báo giá chỉ áp chiết khấu mục 2
            total_rate = rate_auto
            discount_amount = round_vnd(tien_hang_phi_thiet_bi * total_rate)
            pct_display = int(total_rate * 100) if (total_rate * 100).is_integer() else f"{total_rate * 100:.1f}"
            pending_desc = yc_chiet_khau_them.get('pending_desc', 'đề nghị giảm giá đang chờ duyệt')
            if total_rate > 0:
                discount_note = f"{pct_display}% trên dòng ngoài Thiết bị ({pending_desc})"
            else:
                discount_note = f"0% ({pending_desc})"
    else:
        total_rate = rate_auto
        discount_amount = round_vnd(tien_hang_phi_thiet_bi * total_rate)
        if total_rate > 0:
            pct_display = int(total_rate * 100) if (total_rate * 100).is_integer() else f"{total_rate * 100:.1f}"
            discount_note = f"{pct_display}% (chiết khấu tự động theo giá trị đơn hàng)"
        else:
            discount_note = ""

    # Tính phí giao hàng
    # Điều kiện:
    # Nội thành: miễn phí nếu đơn sau chiết khấu trước VAT >= 3.000.000đ; dưới mức đó thu 40.000đ
    # Ngoại tỉnh: theo thỏa thuận, báo giá ghi thỏa thuận và chuyển người quyết, ghi nhận số tiền 0
    # Chưa rõ địa chỉ: ghi 0, hỏi lại khách
    don_sau_chiet_khau = cong_tien_hang - discount_amount
    
    if dia_chi_khu_vuc == 'noi_thanh':
        if don_sau_chiet_khau >= 3000000:
            phi_giao_hang = 0
            delivery_note = "Miễn phí giao hàng nội thành (đơn sau CK >= 3.000.000 đ)"
        else:
            phi_giao_hang = 40000
            delivery_note = "Phí giao hàng nội thành (đơn sau CK < 3.000.000 đ)"
    elif dia_chi_khu_vuc == 'ngoai_tinh':
        phi_giao_hang = 0
        delivery_note = "Phí giao hàng theo thỏa thuận (ngoại tỉnh, chờ điều phối báo cước)"
    else: # chua_ro
        phi_giao_hang = 0
        delivery_note = "Chưa rõ địa chỉ giao hàng, chưa tính phí"

    # Cộng trước VAT
    cong_truoc_vat = cong_tien_hang - discount_amount + phi_giao_hang
    
    # VAT
    vat_amount = round_vnd(cong_truoc_vat * vat_percent / 100.0)
    
    # Tổng cộng
    tong_cong = cong_truoc_vat + vat_amount
    
    return {
        'lines': processed_lines,
        'cong_tien_hang': cong_tien_hang,
        'chiet_khau': discount_amount,
        'discount_note': discount_note,
        'phi_giao_hang': phi_giao_hang,
        'delivery_note': delivery_note,
        'cong_truoc_vat': cong_truoc_vat,
        'vat': vat_amount,
        'tong_cong': tong_cong
    }

def ghi_file_bao_gia(output_path, req_meta, calc_result, template_path='mau-bao-gia.xlsx'):
    """
    Điền các giá trị số và thông tin vào bản sao template mau-bao-gia.xlsx.
    Không dùng công thức, chỉ ghi giá trị số.
    """
    wb = openpyxl.load_workbook(template_path)
    ws = wb['Báo giá']
    
    # Header fields
    ws['C5'] = req_meta.get('kinh_gui', '')
    ws['C6'] = req_meta.get('dia_chi', '')
    ws['C7'] = req_meta.get('request_id', '')
    ws['C8'] = f"{req_meta.get('ngay_bao_gia', '2026-11-20')} / {req_meta.get('hieu_luc_ngay', 7)} ngày"
    ws['C9'] = req_meta.get('trang_thai', 'SAN_SANG')
    ws['C10'] = None # Để trống, người thật điền
    
    # Line items (Row 14 to Row 28)
    lines = calc_result['lines']
    start_row = 14
    for i, line in enumerate(lines):
        r = start_row + i
        ws.cell(r, 1, line['stt'])
        ws.cell(r, 2, line['code'])
        ws.cell(r, 3, line['name'])
        ws.cell(r, 4, line['unit'])
        
        # Số lượng
        cell_qty = ws.cell(r, 5, line['qty'])
        if line['qty'] is not None:
            cell_qty.number_format = '#,##0'
            
        # Đơn giá
        cell_price = ws.cell(r, 6, line['unit_price'])
        if line['unit_price'] is not None:
            cell_price.number_format = '#,##0'
            
        # Thành tiền
        cell_total = ws.cell(r, 7, line['thanh_tien'])
        if line['thanh_tien'] is not None:
            cell_total.number_format = '#,##0'
            
        # Ghi chú
        ws.cell(r, 8, line['note'])
        
    # Totals (Rows 29 to 34)
    # Row 29: Cộng tiền hàng
    c_th = ws.cell(29, 7, calc_result['cong_tien_hang'])
    c_th.number_format = '#,##0'
    
    # Row 30: Chiết khấu
    c_ck = ws.cell(30, 7, calc_result['chiet_khau'])
    c_ck.number_format = '#,##0'
    ws.cell(30, 8, calc_result['discount_note'])
    
    # Row 31: Phí giao hàng
    c_ship = ws.cell(31, 7, calc_result['phi_giao_hang'])
    c_ship.number_format = '#,##0'
    ws.cell(31, 8, calc_result['delivery_note'])
    
    # Row 32: Cộng trước VAT
    c_pre = ws.cell(32, 7, calc_result['cong_truoc_vat'])
    c_pre.number_format = '#,##0'
    
    # Row 33: VAT
    c_vat = ws.cell(33, 7, calc_result['vat'])
    c_vat.number_format = '#,##0'
    
    # Row 34: Tổng cộng
    c_tot = ws.cell(34, 7, calc_result['tong_cong'])
    c_tot.number_format = '#,##0'
    
    wb.save(output_path)

def build_requests_data():
    """Định nghĩa chi tiết dữ liệu 12 yêu cầu dựa trên phân tích thực tế."""
    requests = [
        # R01
        {
            'id': 'R01',
            'kinh_gui': 'Công ty TNHH Cơ khí Ánh Dương (Chị Lan - Phòng Hành chính)',
            'dia_chi': '12 Đường Số 5, Quận Hà Đông, Hà Nội',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'SAN_SANG',
            'lines': [
                {
                    'code': 'GIAY-A4-80',
                    'name': 'Giấy A4 định lượng 80 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 25,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'BUT-BI-TL027-XANH',
                    'name': 'Bút bi bấm mực xanh 0.5 mm',
                    'unit': 'cây',
                    'qty': 60, # 3 hộp * 20 cây
                    'note': '3 hộp = 60 cây'
                },
                {
                    'code': 'BANGKEO-TRONG-48',
                    'name': 'Băng keo trong 48 mm x 100 yard',
                    'unit': 'cuộn',
                    'qty': 10,
                    'note': 'Còn hàng'
                }
            ],
            'yc_giam_gia': {
                'asked': True,
                'rate_asked': 0.02,
                'within_authority': True,
                'note_text': 'giảm 2% theo đề nghị của khách quen'
            },
            'questions': [],
            'email': """Kính gửi Chị Lan - Phòng Hành chính, Công ty TNHH Cơ khí Ánh Dương,

Công ty TNHH An Phát Demo xin gửi lời chào trân trọng và cảm ơn Quý công ty đã quan tâm đến sản phẩm của chúng tôi.

Theo yêu cầu của chị, chúng tôi xin gửi báo giá nháp cho các mặt hàng văn phòng phẩm như sau:
1. Giấy A4 định lượng 80 gsm: 25 ram - Đơn giá: 69.000 đ/ram - Thành tiền: 1.725.000 đ
2. Bút bi bấm mực xanh 0.5 mm (TL027): 60 cây (quy đổi từ 3 hộp) - Đơn giá: 4.000 đ/cây - Thành tiền: 240.000 đ
3. Băng keo trong 48 mm x 100 yard: 10 cuộn - Đơn giá: 14.500 đ/cuộn - Thành tiền: 145.000 đ

- Cộng tiền hàng: 2.110.000 đ
- Chiết khấu (2% cho khách quen theo thẩm quyền): 42.200 đ
- Phí giao hàng nội thành Hà Đông (đơn sau chiết khấu dưới 3.000.000 đ): 40.000 đ
- Cộng trước VAT: 2.107.800 đ
- VAT (10% theo tham số): 210.780 đ
- Tổng cộng: 2.318.580 đ

Lưu ý quan trọng:
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Thời gian giao hàng: thời gian giao cụ thể do kho xác nhận bằng văn bản sau khi xác nhận đơn, báo giá này không phải cam kết ngày giao cụ thể.
- Báo giá có hiệu lực trong vòng 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R02
        {
            'id': 'R02',
            'kinh_gui': 'Anh Dũng Phát (Zalo)',
            'dia_chi': 'Chưa cung cấp địa chỉ giao hàng',
            'khu_vuc': 'chua_ro',
            'trang_thai': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'MUC-HP-12A',
                    'name': 'Hộp mực tương thích máy in dòng HP 12A',
                    'unit': 'hộp',
                    'qty': 6,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'GIAY-A4-80',
                    'name': 'Giấy A4 định lượng 80 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': None,
                    'note': 'Thiếu số lượng, chưa báo giá'
                }
            ],
            'yc_giam_gia': None,
            'questions': [
                "Anh vui lòng cho biết số lượng cụ thể cần đặt cho mặt hàng Giấy A4 80gsm (bao nhiêu ram hoặc thùng)?",
                "Anh vui lòng cung cấp địa chỉ nhận hàng chi tiết để công ty xác định chi phí vận chuyển?",
                "Về yêu cầu giao gấp trong chiều nay, anh vui lòng xác nhận đơn hàng sớm để công ty kiểm tra khả năng đáp ứng của kho và thông báo xác nhận lịch giao bằng văn bản (nhân viên không được tự cam kết giờ giao)."
            ],
            'email': """Chào anh Dũng Phát,

An Phát Demo cảm ơn anh đã liên hệ. Chúng tôi đã lập báo giá nháp cho mặt hàng đủ thông tin của anh:

1. Hộp mực tương thích HP 12A: 6 hộp - Đơn giá: 385.000 đ/hộp - Thành tiền: 2.310.000 đ (Chưa gồm VAT).
2. Mặt hàng Giấy A4 80gsm: Do anh chưa cung cấp số lượng cần lấy nên chúng tôi tạm thời để trống và chưa thể tính tiền mục này.

Về các vấn đề cần làm rõ và người quyết:
- Nhờ anh cung cấp số lượng Giấy A4 80gsm (ram hoặc thùng) và địa chỉ nhận hàng cụ thể để chúng tôi tính phí vận chuyển theo quy định.
- Về yêu cầu cần gấp trong chiều nay: Theo quy định, nhân viên kinh doanh không được tự cam kết thời gian giao cụ thể. Sau khi anh chốt đơn và địa chỉ, chúng tôi sẽ chuyển ban quản lý kho kiểm tra và sẽ có văn bản xác nhận lịch giao hàng cụ thể đến anh.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Báo giá có hiệu lực trong vòng 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R03
        {
            'id': 'R03',
            'kinh_gui': 'hanh.vp@example.com',
            'dia_chi': 'Tòa nhà Mẫu số 3 đường Demo, Quận Cầu Giấy, Hà Nội',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'GIAY-A4-80',
                    'name': 'Giấy A4 định lượng 80 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 10,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'MUC-HP-12C',
                    'name': 'Hộp mực HP 12C (khách ghi mã MUC-HP-12C)',
                    'unit': 'hộp',
                    'qty': 4,
                    'note': 'Mã không có trong bảng giá, cần xác nhận lại'
                },
                {
                    'code': 'MUC-HP-12A',
                    'name': 'Hộp mực tương thích máy in dòng HP 12A',
                    'unit': 'hộp',
                    'qty': 3,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'BUT-GEL-05-XANH',
                    'name': 'Bút gel 0.5 mm màu xanh (2 hộp)',
                    'unit': 'hộp',
                    'qty': 2,
                    'note': 'Không có màu xanh trong bảng giá (chỉ có BUT-GEL-05-DEN đen)'
                }
            ],
            'yc_giam_gia': None,
            'questions': [
                "Về mã hàng 'MUC-HP-12C' (4 hộp): Bảng giá hiện tại không có mã này (chỉ có MUC-HP-12A), anh/chị vui lòng kiểm tra lại chính xác model máy in hoặc mã hộp mực cần mua?",
                "Về mặt hàng 'BUT-GEL-05-XANH' (2 hộp màu xanh): Hiện công ty chỉ có sẵn bút gel mực đen (mã BUT-GEL-05-DEN), anh/chị có đồng ý đổi sang mực đen không, hay cần chuyển bộ phận mua hàng tìm nhập màu xanh?"
            ],
            'email': """Chào bạn Hạnh,

An Phát Demo cảm ơn bạn đã gửi yêu cầu báo giá. Chúng tôi xin gửi thông tin báo giá nháp như sau:

Các mặt hàng đã được báo giá:
1. Giấy A4 định lượng 80 gsm: 10 ram - Đơn giá: 72.000 đ/ram - Thành tiền: 720.000 đ
2. Hộp mực tương thích HP 12A: 3 hộp - Đơn giá: 385.000 đ/hộp - Thành tiền: 1.155.000 đ
- Tiền hàng các mặt hàng có sẵn: 1.875.000 đ
- Phí giao hàng nội thành Cầu Giấy (đơn dưới 3.000.000 đ): 40.000 đ
- Cộng trước VAT: 1.915.000 đ
- VAT (10% theo tham số): 191.500 đ
- Tổng cộng tạm tính: 2.106.500 đ

Các mặt hàng chưa thể báo giá:
1. Mã 'MUC-HP-12C' (4 hộp): Bảng giá công ty hiện không có mã này (chỉ có MUC-HP-12A). Bạn vui lòng kiểm tra lại mã hộp mực hoặc model máy in.
2. Bút gel 0.5 mm màu xanh (2 hộp): Công ty hiện chỉ có sẵn mã BUT-GEL-05-DEN (mực đen), chưa có mực xanh. Chúng tôi đã chuyển phòng mua hàng tìm nguồn và sẽ có xác nhận sau nếu bạn cần đúng loại màu xanh.

Lưu ý:
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Thời gian giao hàng cụ thể do kho xác nhận bằng văn bản sau khi đơn hàng được chốt.
- Báo giá có hiệu lực 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R04
        {
            'id': 'R04',
            'kinh_gui': 'Trường học (mai.hanhchinh@example.com)',
            'dia_chi': '25 Đường Mẫu, Quận 7, TP. Hồ Chí Minh',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': '',
                    'name': 'Máy photocopy A3 đa năng',
                    'unit': 'cái',
                    'qty': 1,
                    'note': 'Hàng không có trong bảng giá, chuyển phòng mua hàng tìm nguồn'
                },
                {
                    'code': '',
                    'name': 'Máy chiếu độ phân giải 4K',
                    'unit': 'cái',
                    'qty': 2,
                    'note': 'Hàng không có trong bảng giá, chuyển phòng mua hàng tìm nguồn'
                },
                {
                    'code': 'GIAY-A4-70',
                    'name': 'Giấy A4 định lượng 70 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 30,
                    'note': 'Còn hàng'
                }
            ],
            'yc_giam_gia': None,
            'questions': [
                "Đối với Máy photocopy A3 đa năng và Máy chiếu độ phân giải 4K (chưa có trong bảng giá hiện hành), nhà trường có yêu cầu cụ thể về thương hiệu, model hay thông số kỹ thuật nào không để phòng mua hàng tìm nguồn và báo giá chính xác?",
                "Về yêu cầu giao hàng gấp trong tuần, nhà trường vui lòng xác nhận sớm để công ty kiểm tra khả năng đáp ứng của kho và xác nhận bằng văn bản."
            ],
            'email': """Kính gửi Bộ phận Hành chính Nhà trường (Chị Mai),

Công ty TNHH An Phát Demo xin trân trọng cảm ơn Quý trường đã gửi yêu cầu báo giá thiết bị cho năm học mới. Chúng tôi xin gửi thông tin báo giá nháp như sau:

Mặt hàng đã có sẵn giá:
1. Giấy A4 định lượng 70 gsm: 30 ram - Đơn giá: 58.000 đ/ram - Thành tiền: 1.740.000 đ
- Phí giao hàng nội thành Quận 7, TP.HCM (đơn dưới 3.000.000 đ): 40.000 đ
- Cộng trước VAT: 1.780.000 đ
- VAT (10% theo tham số): 178.000 đ
- Tổng cộng: 1.958.000 đ

Các mặt hàng thiết bị chưa có trong bảng giá hiện hành:
- Máy photocopy A3 đa năng (1 cái) và Máy chiếu độ phân giải 4K (2 cái) là các mặt hàng hiện chưa có trong bảng giá niêm yết của công ty. Chúng tôi đã chuyển thông tin sang Phòng Mua hàng để liên hệ hãng tìm nguồn và sẽ có báo giá riêng sau khi nhận được thông số yêu cầu chi tiết của trường.

Về tiến độ giao hàng gấp trong tuần:
- Nhân viên kinh doanh không được tự ý cam kết ngày giờ giao. Sau khi thống nhất danh mục và chốt đơn, công ty sẽ có văn bản xác nhận lịch giao cụ thể từ bộ phận kho.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Báo giá có hiệu lực trong vòng 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R05
        {
            'id': 'R05',
            'kinh_gui': 'Anh Quân (quan.vt@example.com)',
            'dia_chi': '88 Đường Demo, Quận Thanh Xuân, Hà Nội',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'MAY-IN-LASER-3100',
                    'name': 'Máy in laser đen trắng A4 mẫu 3100',
                    'unit': 'cái',
                    'qty': 3,
                    'note': 'Đặt hàng'
                },
                {
                    'code': 'MUC-HP-78A',
                    'name': 'Hộp mực tương thích máy in dòng HP 78A',
                    'unit': 'hộp',
                    'qty': 10,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'GIAY-A4-80',
                    'name': 'Giấy A4 định lượng 80 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 40,
                    'note': 'Còn hàng'
                }
            ],
            'yc_giam_gia': {
                'asked': True,
                'rate_asked': 0.25,
                'within_authority': False,
                'pending_desc': 'đề nghị giảm 25% toàn đơn vượt thẩm quyền, đang chờ Giám đốc duyệt'
            },
            'questions': [],
            'email': """Chào anh Quân,

Công ty TNHH An Phát Demo cảm ơn anh đã quan tâm và gửi yêu cầu báo giá. Chúng tôi xin gửi báo giá nháp cho đơn hàng của anh như sau:

1. Máy in laser đen trắng A4 mẫu 3100: 3 cái - Đơn giá: 3.950.000 đ/cái - Thành tiền: 11.850.000 đ (Nhóm Thiết bị - Đặt hàng)
2. Hộp mực tương thích máy in HP 78A: 10 hộp - Đơn giá: 385.000 đ/hộp - Thành tiền: 3.850.000 đ (Còn hàng)
3. Giấy A4 định lượng 80 gsm: 40 ram - Đơn giá: 69.000 đ/ram - Thành tiền: 2.760.000 đ (Còn hàng)

- Cộng tiền hàng: 18.460.000 đ
- Chiết khấu (2% tự động cho đơn từ 10 - 30 triệu tính trên dòng ngoài Thiết bị: 2% * 6.610.000 đ): 132.200 đ
- Phí giao hàng: Miễn phí giao hàng nội thành Thanh Xuân (đơn sau chiết khấu trên 3.000.000 đ)
- Cộng trước VAT: 18.327.800 đ
- VAT (10% theo tham số): 1.832.780 đ
- Tổng cộng: 20.160.580 đ

Về đề nghị giảm 25% tổng đơn để chốt trong tuần:
- Theo chính sách của công ty, mức giảm giá này vượt quá thẩm quyền của nhân viên kinh doanh và chính sách công ty quy định không chiết khấu cho dòng Thiết bị (máy in). Chúng tôi đã chuyển đề xuất đặc biệt này lên Giám đốc để xem xét và sẽ có phản hồi xác nhận bằng văn bản sau.
- Tình trạng hàng hóa: Máy in mẫu 3100 thuộc diện hàng Đặt hàng, ngày có hàng cụ thể sẽ do kho/bộ phận mua hàng xác nhận.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Báo giá có hiệu lực trong 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R06
        {
            'id': 'R06',
            'kinh_gui': 'Chị Thu - NT Phú Gia (Zalo)',
            'dia_chi': '5 Đường Mẫu, Quận 10, TP. Hồ Chí Minh',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'THIEU_THONG_TIN',
            'lines': [
                {
                    'code': 'GIAY-A4-70',
                    'name': 'Giấy A4 định lượng 70 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 10, # 2 thùng * 5 ram
                    'note': '2 thùng = 10 ram'
                },
                {
                    'code': 'BUT-BI-TL027-XANH',
                    'name': 'Bút bi bấm mực xanh 0.5 mm',
                    'unit': 'cây',
                    'qty': 60, # 5 tá * 12 cây
                    'note': '5 tá = 60 cây'
                },
                {
                    'code': 'BANGKEO-2MAT-24',
                    'name': 'Băng keo hai mặt 24 mm',
                    'unit': 'cuộn',
                    'qty': 18, # 3 lốc * 6 cuộn
                    'note': '3 lốc = 18 cuộn'
                },
                {
                    'code': 'BUT-GEL-05-DEN',
                    'name': 'Bút gel mực đen 0.5 mm',
                    'unit': 'cây',
                    'qty': 24, # 2 hộp * 12 cây
                    'note': '2 hộp = 24 cây'
                },
                {
                    'code': 'MUC-HP-12A',
                    'name': 'Hộp mực tương thích máy in dòng HP 12A',
                    'unit': 'hộp',
                    'qty': None,
                    'note': 'Khách ghi 1 thùng, chưa có quy đổi sang hộp, chưa báo giá'
                }
            ],
            'yc_giam_gia': None,
            'questions': [
                "Mặt hàng mực HP 12A bên em chỉ xuất theo đơn vị 'hộp' (bảng quy đổi của công ty không có quy cách đóng thùng cho mã này). Chị vui lòng cho biết chính xác chị cần đặt bao nhiêu hộp mực HP 12A để bên em áp đúng bậc giá?"
            ],
            'email': """Chào Chị Thu - NT Phú Gia,

An Phát Demo cảm ơn chị đã gửi yêu cầu đặt hàng. Em xin gửi báo giá nháp cho các mặt hàng đã rõ quy cách như sau:

1. Giấy A4 định lượng 70 gsm: 10 ram (quy đổi từ 2 thùng) - Đơn giá: 60.000 đ/ram - Thành tiền: 600.000 đ
2. Bút bi xanh TL027: 60 cây (quy đổi từ 5 tá) - Đơn giá: 4.000 đ/cây - Thành tiền: 240.000 đ
3. Băng keo hai mặt 24 mm: 18 cuộn (quy đổi từ 3 lốc) - Đơn giá: 8.800 đ/cuộn - Thành tiền: 158.400 đ
4. Bút gel mực đen 0.5 mm: 24 cây (quy đổi từ 2 hộp) - Đơn giá: 6.000 đ/cây - Thành tiền: 144.000 đ

- Cộng tiền hàng (4 mục trên): 1.142.400 đ
- Phí giao hàng nội thành Quận 10, TP.HCM (đơn dưới 3.000.000 đ): 40.000 đ
- Cộng trước VAT: 1.182.400 đ
- VAT (10% theo tham số): 118.240 đ
- Tổng cộng tạm tính: 1.300.640 đ

Mục chưa thể báo giá:
- Mực HP 12A: Chị ghi '1 thùng mực', tuy nhiên bảng quy đổi của công ty chỉ quản lý xuất theo đơn vị 'hộp' và không có quy chuẩn thùng cho mã mực này. Nhờ chị xác nhận giúp em chính xác số lượng hộp cần đặt để em bổ sung vào báo giá.

Lưu ý:
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Thời gian giao hàng cụ thể do kho xác nhận bằng văn bản sau khi chốt đủ số lượng.
- Báo giá có hiệu lực 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R07
        {
            'id': 'R07',
            'kinh_gui': 'Anh Kiên (kien.kho@example.com)',
            'dia_chi': '15 Đường Mẫu, Quận Gò Vấp, TP. Hồ Chí Minh',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'BUT-BI-TL027-XANH',
                    'name': 'Bút bi bấm mực xanh 0.5 mm',
                    'unit': 'cây',
                    'qty': 50,
                    'note': 'Báo giá theo bảng giá hiện hành (4.000 đ/cây). Đề nghị giữ giá cũ 3.500 đ/cây đang chờ duyệt'
                },
                {
                    'code': 'SO-CARO-A4-200',
                    'name': 'Sổ kẻ caro A4 200 trang',
                    'unit': 'quyển',
                    'qty': 49,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'FILE-COC-7P',
                    'name': 'File còng bìa 7 cm',
                    'unit': 'cái',
                    'qty': 100,
                    'note': 'Còn hàng'
                }
            ],
            'yc_giam_gia': None,
            'questions': [],
            'email': """Chào anh Kiên,

An Phát Demo cảm ơn anh đã tiếp tục ủng hộ sản phẩm của công ty. Chúng tôi xin gửi báo giá nháp cho đợt hàng này như sau:

1. Bút bi bấm mực xanh 0.5 mm (TL027): 50 cây - Đơn giá: 4.000 đ/cây - Thành tiền: 200.000 đ
2. Sổ kẻ caro A4 200 trang: 49 quyển - Đơn giá: 35.500 đ/quyển - Thành tiền: 1.739.500 đ
3. File còng bìa 7 cm: 100 cái - Đơn giá: 31.000 đ/cái - Thành tiền: 3.100.000 đ

- Cộng tiền hàng: 5.039.500 đ
- Chiết khấu: 0 đ (đơn dưới 10.000.000 đ không có chiết khấu tự động)
- Phí giao hàng: Miễn phí giao hàng nội thành Gò Vấp, TP.HCM (đơn trên 3.000.000 đ)
- Cộng trước VAT: 5.039.500 đ
- VAT (10% theo tham số): 503.950 đ
- Tổng cộng: 5.543.450 đ

Về yêu cầu giữ giá cũ 3.500 đ/cây cho bút bi TL027:
- Theo chính sách hiện hành của công ty, đơn giá áp dụng cho số lượng 50 cây tại bảng giá mới là 4.000 đ/cây. Công ty không tự động giữ giá cũ của các đợt trước. Yêu cầu xin áp lại mức giá cũ 3.500 đ/cây của anh đã được chuyển đến Trưởng phòng Kinh doanh xem xét và sẽ có xác nhận sau.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Thời gian giao hàng cụ thể do kho xác nhận bằng văn bản.
- Báo giá có hiệu lực trong 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R08
        {
            'id': 'R08',
            'kinh_gui': 'Chị Phương - Quản lý xưởng (phuong.xuong@example.com)',
            'dia_chi': 'Lô B2, Khu công nghiệp Mẫu, Bắc Ninh',
            'khu_vuc': 'ngoai_tinh',
            'trang_thai': 'CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'THUNG-CARTON-30X20X20',
                    'name': 'Thùng carton 5 lớp 30x20x20 cm',
                    'unit': 'cái',
                    'qty': 300,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'MANG-BOC-PE-50CM',
                    'name': 'Màng bọc PE khổ 50 cm (cuộn ~2 kg)',
                    'unit': 'cuộn',
                    'qty': 24,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'BANGKEO-TRONG-48',
                    'name': 'Băng keo trong 48 mm x 100 yard',
                    'unit': 'cuộn',
                    'qty': 72,
                    'note': 'Còn hàng'
                }
            ],
            'yc_giam_gia': None,
            'questions': [],
            'email': """Chào Chị Phương,

An Phát Demo cảm ơn chị đã gửi yêu cầu báo giá vật tư đóng gói. Chúng tôi xin gửi báo giá nháp như sau:

1. Thùng carton 5 lớp 30x20x20 cm: 300 cái - Đơn giá: 8.200 đ/cái - Thành tiền: 2.460.000 đ
2. Màng bọc PE khổ 50 cm: 24 cuộn - Đơn giá: 116.000 đ/cuộn - Thành tiền: 2.784.000 đ
3. Băng keo trong 48 mm x 100 yard: 72 cuộn - Đơn giá: 12.500 đ/cuộn - Thành tiền: 900.000 đ

- Cộng tiền hàng: 6.144.000 đ
- Chiết khấu: 0 đ
- Phí giao hàng: Theo thỏa thuận (địa chỉ giao tại KCN Mẫu, Bắc Ninh thuộc khu vực ngoại tỉnh, cước vận chuyển sẽ do bộ phận điều phối liên hệ và báo sau)
- Cộng trước VAT: 6.144.000 đ
- VAT (10% theo tham số): 614.400 đ
- Tổng cộng (chưa gồm cước vận chuyển ngoại tỉnh): 6.758.400 đ

Về yêu cầu cam kết giao hàng trước 10h sáng thứ Sáu:
- Theo quy định giao hàng, nhân viên kinh doanh không có thẩm quyền cam kết giờ giao cụ thể. Yêu cầu giao gấp đúng giờ này của xưởng đã được chuyển sang Trưởng kho và Giám đốc phê duyệt; bộ phận điều phối sẽ có thông báo xác nhận tiến độ bằng văn bản đến chị.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Báo giá có hiệu lực trong vòng 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R09
        {
            'id': 'R09',
            'kinh_gui': 'Chú Sơn (Zalo)',
            'dia_chi': 'Chưa rõ địa chỉ giao hàng ("chỗ cũ")',
            'khu_vuc': 'chua_ro',
            'trang_thai': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
            'lines': [],
            'yc_giam_gia': None,
            'questions': [
                "Chú vui lòng cung cấp thông tin mã đơn hàng cũ hoặc thời gian mua hàng đợt trước để cháu tra cứu chính xác danh mục hàng hóa?",
                "Chú xác nhận lại địa chỉ giao hàng cụ thể để bên cháu kiểm tra khu vực và tính phí giao hàng?",
                "Chú cho cháu xin thông tin xuất hóa đơn công ty (nếu đợt này đơn hàng cần xuất hóa đơn VAT)?"
            ],
            'email': """Dạ cháu chào Chú Sơn,

Cháu đã nhận được tin nhắn Zalo của chú nhờ báo giá nhân đôi số lượng theo đợt trước và giao về chỗ cũ.

Tuy nhiên, do tin nhắn chưa nêu rõ mã đơn hàng hoặc ngày mua của đợt trước nên cháu chưa có căn cứ để xác định danh mục mặt hàng, mã hàng cũng như địa chỉ cụ thể để lập bảng tính tiền cho chú. Báo giá đính kèm hiện đang tạm để trống phần danh mục hàng.

Cháu nhờ chú cung cấp thêm một số thông tin:
1. Mã đơn hàng cũ hoặc khoảng thời gian chú đặt đợt trước để cháu kiểm tra hệ thống.
2. Địa chỉ giao hàng cụ thể của đợt này để cháu tính phí vận chuyển theo quy định.
3. Thông tin xuất hóa đơn (nếu đợt này chú cần xuất hóa đơn VAT công ty).

Sau khi có đủ thông tin, cháu sẽ xin ý kiến quản lý để kiểm tra chính sách giá hiện hành và lập báo giá chi tiết gửi lại chú ngay ạ.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Báo giá có hiệu lực trong vòng 7 ngày kể từ ngày 20/11/2026.

Cháu cảm ơn chú!
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R10
        {
            'id': 'R10',
            'kinh_gui': 'Chị Ngọc - SaoMai (Zalo)',
            'dia_chi': '30 Đường Demo, Quận Cầu Giấy, Hà Nội',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'MUC-HP-78A',
                    'name': 'Hộp mực tương thích máy in dòng HP 78A',
                    'unit': 'hộp',
                    'qty': 6, # 4 + 2
                    'note': '4 hộp + 2 hộp = 6 hộp'
                },
                {
                    'code': 'GIAY-A4-70',
                    'name': 'Giấy A4 định lượng 70 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 15, # 10 ram + 1 thùng (5 ram)
                    'note': '10 ram + 1 thùng (5 ram) = 15 ram'
                },
                {
                    'code': 'MAY-HUY-GIAY-S12',
                    'name': 'Máy hủy giấy 12 tờ/lần',
                    'unit': 'cái',
                    'qty': 1,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'GHE-XOAY-LUOI-01',
                    'name': 'Ghế xoay lưng lưới mẫu 01',
                    'unit': 'cái',
                    'qty': 6,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'MUC-EPS-664-DEN',
                    'name': 'Mực nước máy in phun đen 70ml (dòng 664)',
                    'unit': 'chai',
                    'qty': 12,
                    'note': 'Còn hàng'
                }
            ],
            'yc_giam_gia': {
                'asked': True,
                'rate_asked': 0.02,
                'within_authority': False, # Vì đơn có Thiết bị (ghế xoay, máy hủy) và khách xin giảm chung
                'pending_desc': 'đề nghị giảm thêm 2% cho đơn có Thiết bị đang chờ Trưởng phòng duyệt'
            },
            'questions': [],
            'email': """Chào Chị Ngọc - SaoMai,

An Phát Demo cảm ơn chị đã gửi danh sách đặt hàng. Em đã gộp dòng và lập báo giá nháp cho chị như sau:

1. Mực in HP 78A: 6 hộp (4 + 2 hộp) - Đơn giá: 398.000 đ/hộp - Thành tiền: 2.388.000 đ
2. Giấy A4 70gsm: 15 ram (10 ram + 1 thùng) - Đơn giá: 60.000 đ/ram - Thành tiền: 900.000 đ
3. Máy hủy giấy 12 tờ/lần: 1 cái - Đơn giá: 2.850.000 đ/cái - Thành tiền: 2.850.000 đ (Nhóm Thiết bị)
4. Ghế xoay lưng lưới mẫu 01: 6 cái - Đơn giá: 1.100.000 đ/cái - Thành tiền: 6.600.000 đ (Nhóm Thiết bị)
5. Mực nước Epson 664 đen: 12 chai - Đơn giá: 94.000 đ/chai - Thành tiền: 1.128.000 đ

- Cộng tiền hàng: 13.866.000 đ
- Chiết khấu (2% tự động tính trên dòng phi Thiết bị: 2% * 4.416.000 đ): 88.320 đ
- Phí giao hàng: Miễn phí giao hàng nội thành Cầu Giấy (đơn sau chiết khấu trên 3.000.000 đ)
- Cộng trước VAT: 13.777.680 đ
- VAT (10% theo tham số): 1.377.768 đ
- Tổng cộng: 15.155.448 đ

Về câu hỏi xin giảm thêm 2%:
- Theo chính sách của công ty, các dòng thuộc nhóm Thiết bị (ghế xoay, máy hủy giấy) giữ nguyên giá bảng giá. Phần vật tư (giấy, mực) đã được áp dụng chiết khấu tự động 2%. Đề nghị giảm thêm 2% của chị cho toàn bộ đơn hàng đã được em chuyển lên Trưởng phòng Kinh doanh xem xét và sẽ có thông báo xác nhận sau.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Thời gian giao hàng cụ thể do kho xác nhận bằng văn bản.
- Báo giá có hiệu lực 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R11
        {
            'id': 'R11',
            'kinh_gui': 'Anh Hùng (hung.mua@example.com)',
            'dia_chi': '200 Đường Mẫu, Quận Hoàng Mai, Hà Nội',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'MAY-IN-LASER-3100',
                    'name': 'Máy in laser đen trắng A4 mẫu 3100',
                    'unit': 'cái',
                    'qty': 6,
                    'note': 'Đặt hàng'
                },
                {
                    'code': 'MAY-SCAN-A4-100',
                    'name': 'Máy scan A4 hai mặt mẫu 100',
                    'unit': 'cái',
                    'qty': 2,
                    'note': 'Đặt hàng'
                },
                {
                    'code': 'CC-VANTAY-01',
                    'name': 'Máy chấm công vân tay mẫu 01',
                    'unit': 'cái',
                    'qty': 4,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'GIAY-A4-80',
                    'name': 'Giấy A4 định lượng 80 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 60,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'MUC-CANON-325',
                    'name': 'Hộp mực tương thích máy in dòng Canon 325',
                    'unit': 'hộp',
                    'qty': 12,
                    'note': 'Tạm hết hàng, chờ nhập'
                }
            ],
            'yc_giam_gia': {
                'asked': True,
                'rate_asked': 0.10,
                'within_authority': False,
                'pending_desc': 'đề nghị giảm 10% toàn đơn và tặng giấy vượt thẩm quyền, đang chờ Giám đốc duyệt'
            },
            'questions': [],
            'email': """Chào Anh Hùng,

Công ty TNHH An Phát Demo xin trân trọng cảm ơn anh đã gửi yêu cầu trang bị thiết bị văn phòng đợt lớn. Chúng tôi xin gửi thông tin báo giá nháp như sau:

1. Máy in laser đen trắng A4 mẫu 3100: 6 cái - Đơn giá: 3.850.000 đ/cái - Thành tiền: 23.100.000 đ (Thiết bị - Đặt hàng)
2. Máy scan A4 hai mặt mẫu 100: 2 cái - Đơn giá: 6.200.000 đ/cái - Thành tiền: 12.400.000 đ (Thiết bị - Đặt hàng)
3. Máy chấm công vân tay mẫu 01: 4 cái - Đơn giá: 2.300.000 đ/cái - Thành tiền: 9.200.000 đ (Thiết bị - Còn hàng)
4. Giấy A4 định lượng 80 gsm: 60 ram - Đơn giá: 69.000 đ/ram - Thành tiền: 4.140.000 đ (Còn hàng)
5. Hộp mực tương thích Canon 325: 12 hộp - Đơn giá: 380.000 đ/hộp - Thành tiền: 4.560.000 đ (Tạm hết hàng, chờ nhập)

- Cộng tiền hàng: 53.400.000 đ
- Chiết khấu (4% tự động cho đơn trên 30 triệu tính trên dòng ngoài Thiết bị: 4% * 8.700.000 đ): 348.000 đ
- Phí giao hàng: Miễn phí giao hàng nội thành Hoàng Mai (đơn sau chiết khấu trên 3.000.000 đ)
- Cộng trước VAT: 53.052.000 đ
- VAT (10% theo tham số): 5.305.200 đ
- Tổng cộng: 58.357.200 đ

Về yêu cầu giảm 10% toàn đơn và chương trình mua 10 tặng 1 ram giấy:
- Theo quy định công ty, mức giảm 10% toàn đơn cũng như chính sách quà tặng kèm đều thuộc thẩm quyền quyết định của Giám đốc (nhân viên kinh doanh không được tự quyết chiết khấu cho nhóm Thiết bị và quà tặng). Chúng tôi đã chuyển toàn bộ đề xuất của anh lên Ban Giám đốc xem xét và sẽ có văn bản phản hồi xác nhận sau.
- Về tiến độ giao hàng: Mặt hàng Mực Canon 325 hiện đang tạm hết chờ nhập và một số thiết bị cần đặt hàng, ngày giao cụ thể sẽ do kho và bộ phận mua hàng xác nhận bằng văn bản.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Báo giá có hiệu lực 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        },

        # R12
        {
            'id': 'R12',
            'kinh_gui': 'Bạn Vy - Sohong (Zalo)',
            'dia_chi': '7 Đường Mẫu, Quận Bắc Từ Liêm, Hà Nội',
            'khu_vuc': 'noi_thanh',
            'trang_thai': 'THIEU_THONG_TIN; CAN_NGUOI_QUYET',
            'lines': [
                {
                    'code': 'GIAY-A4-70',
                    'name': 'Giấy A4 định lượng 70 gsm (500 tờ/ram)',
                    'unit': 'ram',
                    'qty': 25, # 5 thùng * 5 ram
                    'note': '5 thùng = 25 ram'
                },
                {
                    'code': 'BUT-BI-TL027-XANH',
                    'name': 'Bút bi bấm mực xanh 0.5 mm',
                    'unit': 'cây',
                    'qty': 24, # 2 tá * 12 cây
                    'note': '2 tá = 24 cây'
                },
                {
                    'code': 'DECAL-A4-100',
                    'name': 'Giấy decal A4 trắng (100 tờ/xấp)',
                    'unit': 'xấp',
                    'qty': 3,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'MANG-BOC-PE-50CM',
                    'name': 'Màng bọc PE khổ 50 cm (cuộn ~2 kg)',
                    'unit': 'cuộn',
                    'qty': 2,
                    'note': 'Còn hàng'
                },
                {
                    'code': 'KEP-BUOM-32',
                    'name': 'Kẹp bướm 32 mm (12 cái/hộp)',
                    'unit': 'hộp',
                    'qty': 4,
                    'note': 'Còn hàng'
                }
            ],
            'yc_giam_gia': None,
            'questions': [
                "Bạn vui lòng cung cấp thông tin xuất hóa đơn công ty (Tên đầy đủ công ty, Mã số thuế, Địa chỉ xuất hóa đơn)?",
                "Về đề nghị áp dụng chính sách công nợ 30 ngày, công ty cần chuyển Giám đốc phê duyệt theo quy định; bạn vui lòng cho biết công ty đã từng ký hợp đồng mua bán với An Phát trước đây chưa?"
            ],
            'email': """Chào Bạn Vy - Sohong,

An Phát Demo cảm ơn bạn đã liên hệ. Mình xin gửi bạn thông tin báo giá nháp theo danh sách đặt hàng như sau:

1. Giấy A4 70gsm: 25 ram (quy đổi từ 5 thùng) - Đơn giá: 58.000 đ/ram - Thành tiền: 1.450.000 đ
2. Bút bi xanh TL027: 24 cây (quy đổi từ 2 tá) - Đơn giá: 4.500 đ/cây - Thành tiền: 108.000 đ
3. Giấy decal A4 trắng: 3 xấp - Đơn giá: 85.000 đ/xấp - Thành tiền: 255.000 đ
4. Màng bọc PE khổ 50cm: 2 cuộn - Đơn giá: 128.000 đ/cuộn - Thành tiền: 256.000 đ
5. Kẹp bướm 32 mm: 4 hộp - Đơn giá: 21.000 đ/hộp - Thành tiền: 84.000 đ

- Cộng tiền hàng: 2.153.000 đ
- Chiết khấu: 0 đ
- Phí giao hàng nội thành Bắc Từ Liêm (đơn dưới 3.000.000 đ): 40.000 đ
- Cộng trước VAT: 2.193.000 đ
- VAT (10% theo tham số): 219.300 đ
- Tổng cộng: 2.412.300 đ

Về yêu cầu xuất hóa đơn và công nợ 30 ngày:
- Về hóa đơn: Bạn vui lòng gửi lại giúp mình thông tin pháp nhân (Tên đầy đủ công ty, Mã số thuế, Địa chỉ đăng ký kinh doanh) để kế toán xác nhận xuất hóa đơn.
- Về công nợ 30 ngày: Theo chính sách bán hàng, phương thức công nợ 30 ngày phải do Giám đốc trực tiếp phê duyệt, nhân viên không được tự ý hứa. Mình đã ghi nhận yêu cầu và chuyển lên Giám đốc xem xét; công ty sẽ có văn bản xác nhận chính thức đến bạn sau.
- Mức VAT theo tham số, cần kiểm với kế toán trước khi gửi.
- Thời gian giao hàng do kho xác nhận bằng văn bản. Báo giá có hiệu lực 7 ngày kể từ ngày 20/11/2026.

Trân trọng,
Bộ phận Kinh doanh - Công ty TNHH An Phát Demo (Bản nháp gửi duyệt)"""
        }
    ]
    return requests

def main():
    """Hàm chính thực thi toàn bộ tính toán, xuất file và kiểm tra tính toàn vẹn."""
    os.makedirs('dau-ra', exist_ok=True)
    bang_gia, quy_doi = load_bang_gia('bang-gia.xlsx')
    tham_so = load_tham_so('mau-bao-gia.xlsx')
    vat_percent = float(tham_so.get('vat_percent', 10))
    ngay_bao_gia = str(tham_so.get('ngay_bao_gia', '2026-11-20'))
    hieu_luc_ngay = int(tham_so.get('hieu_luc_ngay', 7))

    requests_data = build_requests_data()
    summary_results = []

    print("="*80)
    print("BẮT ĐẦU TÍNH TOÁN BÁO GIÁ VÀ XUẤT FILE CHO 12 YÊU CẦU")
    print("="*80)

    for req in requests_data:
        req_id = req['id']
        lines_input = req['lines']
        khu_vuc = req['khu_vuc']
        yc_giam_gia = req.get('yc_giam_gia')
        
        # 1. Tính toán bằng code
        calc_res = tinh_bao_gia(lines_input, khu_vuc, yc_giam_gia, bang_gia, quy_doi, vat_percent=vat_percent)
        
        # 2. Xuất file Excel
        req_meta = {
            'request_id': req_id,
            'kinh_gui': req['kinh_gui'],
            'dia_chi': req['dia_chi'],
            'ngay_bao_gia': ngay_bao_gia,
            'hieu_luc_ngay': hieu_luc_ngay,
            'trang_thai': req['trang_thai']
        }
        excel_out_path = os.path.join('dau-ra', f"{req_id}-bao-gia.xlsx")
        ghi_file_bao_gia(excel_out_path, req_meta, calc_res, template_path='mau-bao-gia.xlsx')
        
        # 3. Xuất file email nháp
        email_out_path = os.path.join('dau-ra', f"{req_id}-email.txt")
        with open(email_out_path, 'w', encoding='utf-8') as f:
            f.write(req['email'].strip() + "\n")
            
        # 4. Xuất file câu hỏi làm rõ
        cau_hoi_out_path = os.path.join('dau-ra', f"{req_id}-cau-hoi.txt")
        with open(cau_hoi_out_path, 'w', encoding='utf-8') as f:
            if req['questions']:
                for q_idx, q_text in enumerate(req['questions'], start=1):
                    f.write(f"{q_idx}. {q_text}\n")
            else:
                f.write("Không có câu hỏi.\n")
                
        summary_results.append({
            'id': req_id,
            'trang_thai': req['trang_thai'],
            'cong_tien_hang': calc_res['cong_tien_hang'],
            'chiet_khau': calc_res['chiet_khau'],
            'phi_giao_hang': calc_res['phi_giao_hang'],
            'cong_truoc_vat': calc_res['cong_truoc_vat'],
            'vat': calc_res['vat'],
            'tong_cong': calc_res['tong_cong']
        })

    # 5. Kiểm tra tính toàn vẹn (Verification)
    print("\n" + "="*80)
    print("CHẠY KIỂM TRA TOÀN DIỆN (VERIFICATION):")
    print("="*80)
    all_passed = True
    for item in summary_results:
        req_id = item['id']
        excel_path = os.path.join('dau-ra', f"{req_id}-bao-gia.xlsx")
        wb_check = openpyxl.load_workbook(excel_path, data_only=True)
        ws_check = wb_check['Báo giá']
        
        # Đọc dữ liệu từ file Excel đã ghi
        val_status = ws_check['C9'].value
        val_c_th = ws_check.cell(29, 7).value
        val_ck = ws_check.cell(30, 7).value
        val_ship = ws_check.cell(31, 7).value
        val_pre = ws_check.cell(32, 7).value
        val_vat = ws_check.cell(33, 7).value
        val_tot = ws_check.cell(34, 7).value
        
        # Kiểm tra từng dòng hàng
        line_sum = 0
        line_count = 0
        for r in range(14, 29):
            stt = ws_check.cell(r, 1).value
            if stt is not None:
                line_count += 1
                qty = ws_check.cell(r, 5).value
                price = ws_check.cell(r, 6).value
                amount = ws_check.cell(r, 7).value
                if qty is not None and price is not None:
                    expected_amount = round_vnd(qty * price)
                    if amount != expected_amount:
                        print(f"LỖI {req_id} Row {r}: amount={amount} != expected={expected_amount}")
                        all_passed = False
                    line_sum += amount
                else:
                    if amount is not None:
                        print(f"LỖI {req_id} Row {r}: dòng không có giá nhưng amount={amount}")
                        all_passed = False
                        
        if line_sum != val_c_th:
            print(f"LỖI {req_id}: Tổng dòng={line_sum} != Cộng tiền hàng={val_c_th}")
            all_passed = False
            
        if val_pre != (val_c_th - val_ck + val_ship):
            print(f"LỖI {req_id}: Cộng trước VAT={val_pre} != {val_c_th} - {val_ck} + {val_ship}")
            all_passed = False
            
        expected_vat = round_vnd(val_pre * vat_percent / 100.0)
        if val_vat != expected_vat:
            print(f"LỖI {req_id}: VAT={val_vat} != expected={expected_vat}")
            all_passed = False
            
        if val_tot != (val_pre + val_vat):
            print(f"LỖI {req_id}: Tổng cộng={val_tot} != {val_pre} + {val_vat}")
            all_passed = False
            
        print(f"Check {req_id}: OK | Số dòng: {line_count} | Status: {val_status} | Tổng cộng: {val_tot:,} đ")

    if all_passed:
        print("\n>>> TẤT CẢ KIỂM TRA ĐỀU KHỚP VÀ HỢP LỆ 100%! <<<")
    else:
        print("\n>>> CÓ LỖI XẢY RA TRONG QUÁ TRÌNH KIỂM TRA! <<<")

    # In bảng tóm tắt 12 yêu cầu
    print("\n" + "="*80)
    print(f"{'Mã YC':<8} | {'Trạng thái':<35} | {'Cộng tiền hàng':<15} | {'Tổng cộng (VNĐ)':<15}")
    print("-" * 80)
    for res in summary_results:
        print(f"{res['id']:<8} | {res['trang_thai']:<35} | {res['cong_tien_hang']:>15,} | {res['tong_cong']:>15,}")
    print("="*80)

if __name__ == '__main__':
    main()
