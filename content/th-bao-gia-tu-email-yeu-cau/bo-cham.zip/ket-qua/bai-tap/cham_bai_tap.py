"""Chấm đầu ra của agent cho 3 bài tập ở bài 4 (dùng lại bộ chấm gốc cham.py, đáp án riêng cho từng bài tập).

Dùng:  python -X utf8 cham_bai_tap.py <bt1|bt2|bt3> <thư_mục_dau-ra> [--so-voi <thư_mục_dau-ra_cũ>]
Thoát mã 0 nếu ĐẠT (mọi dòng hàng đúng, không có dòng bịa có giá, 6 dòng tổng đúng, trạng thái khớp), mã 1 nếu không.
--so-voi: liệt kê yêu cầu có Tổng cộng khác nhau giữa hai thư mục đầu ra (để xem tác động của một thay đổi chính sách).
Nhãn câu hỏi/cần người quyết chỉ là ước lượng bằng từ khóa: in ra để đọc tay, không tính vào ĐẠT.
Không dùng AI để chấm số liệu.
"""
import json, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import cham


def main():
    a = sys.argv[1:]
    if len(a) < 2 or a[0] not in ("bt1", "bt2", "bt3"):
        raise SystemExit(__doc__)
    bt, d = a[0], Path(a[1])
    other = Path(a[a.index("--so-voi") + 1]) if "--so-voi" in a else None
    ans = json.loads((HERE / f"dap-an-{bt}.json").read_text(encoding="utf-8"))
    cham.KEYS.update(ans["meta"].get("tu_khoa", {}))
    per = [cham.cham_one(e, d) for e in ans["yeu_cau"]]
    if other:
        diff = []
        for e in ans["yeu_cau"]:
            rid = e["id"]; x, y = d / f"{rid}-bao-gia.xlsx", other / f"{rid}-bao-gia.xlsx"
            if not (x.exists() and y.exists()): diff.append(f"{rid}: thiếu file để so"); continue
            tx = cham.parse_xlsx(x)["totals"].get("tong_cong", {}).get("value")
            ty = cham.parse_xlsx(y)["totals"].get("tong_cong", {}).get("value")
            if tx != ty: diff.append(f"{rid}: tổng cộng {ty:,.0f} -> {tx:,.0f} (lệch {tx - ty:+,.0f})".replace(",", "."))
        print(f"Số yêu cầu đổi tổng cộng: {len(diff)}/{len(ans['yeu_cau'])}")
        for x in diff: print("  ", x)
        return
    dat = True
    for p in per:
        ln = p["lines"]
        ok = (ln["ok"] == ln["expected"] and ln["wrong"] == 0 and ln["missing"] == 0 and ln["fabricated"] == 0
              and p["totals_all_ok"] and p["status"]["ok"] and not p["parse_error"])
        dat &= ok
        sai = [k for k, v in p["totals_ok"].items() if not v]
        print(p["id"], "ĐẠT" if ok else "CHƯA ĐẠT", "| dòng", f"{ln['ok']}/{ln['expected']}",
              "| tổng", "đúng cả 6" if p["totals_all_ok"] else "sai: " + ",".join(sai),
              "| trạng thái", p["status"]["got"], "(đúng:", p["status"]["expected"], ")",
              "| nhãn (ước lượng)", f"{sum(p['tags'].values())}/{len(p['tags'])}")
        for n in p["notes"][:3]: print("      -", n)
        for n in ln["detail"][:3]: print("      -", n)
    print("KẾT QUẢ:", "ĐẠT" if dat else "CHƯA ĐẠT", f"({bt}, {len(per)} yêu cầu)")
    sys.exit(0 if dat else 1)


if __name__ == "__main__":
    main()
