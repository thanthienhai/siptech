import os
import sys
import re
import unicodedata
import pandas as pd

# -------------------------------------------------------------
# Script kiểm tra tự động file xuất hàng loạt của shop "Vườn Nhỏ"
# Tuân thủ chặt chẽ quy_dinh_shop.md, tu_cam.txt và thong_so.csv
# -------------------------------------------------------------

MISSING_MARKERS = {'', '?', 'chưa rõ', 'liên hệ ncc', 'n/a', 'chưa có', 'nan'}
REQUIRED_COLS = ['dung_tich', 'thanh_phan_noi_bat', 'xuat_xu', 'han_su_dung', 'cong_dung_tren_bao_bi', 'cach_dung']
EXPECTED_COLUMNS = ['sku', 'tieu_de', 'mo_ta', 'gach_1', 'gach_2', 'gach_3', 'gach_4', 'gach_5', 'tu_khoa', 'trang_thai', 'truong_can_bo_sung']

def strip_accents(text):
    text = unicodedata.normalize('NFD', text)
    text = ''.join(c for c in text if unicodedata.category(c) != 'Mn')
    return text.replace('đ', 'd').replace('Đ', 'D')

def load_banned_words(filepath='tu_cam.txt'):
    if not os.path.exists(filepath):
        print(f"LỖI: Không tìm thấy file {filepath}")
        return [], []
    with open(filepath, 'r', encoding='utf-8') as f:
        words = [line.strip().lower() for line in f if line.strip()]
    words_no_accent = [strip_accents(w) for w in words]
    return words, words_no_accent

def check_banned(text, banned_words, banned_words_no_accent):
    t_lower = text.lower()
    t_no_acc = strip_accents(t_lower)
    found = []
    for bw, bw_na in zip(banned_words, banned_words_no_accent):
        # Match whole phrase/word or boundary
        pattern = r'(?:\b|_|^)' + re.escape(bw) + r'(?:\b|_|$)'
        pattern_na = r'(?:\b|_|^)' + re.escape(bw_na) + r'(?:\b|_|$)'
        if re.search(pattern, t_lower) or re.search(pattern_na, t_no_acc):
            found.append(bw)
    return found

def main():
    print("=" * 70)
    print("BẮT ĐẦU KIỂM TRA FILE NHẬP HÀNG LOẠT: nhap_hang_loat.csv & nhap_hang_loat.xlsx")
    print("=" * 70)
    
    csv_file = 'nhap_hang_loat.csv'
    excel_file = 'nhap_hang_loat.xlsx'
    spec_file = 'thong_so.csv'
    banned_file = 'tu_cam.txt'
    
    errors = []
    warnings = []
    
    # 1. Kiểm tra tồn tại file và UTF-8 BOM
    print("\n[1] Kiểm tra định dạng file và BOM...")
    if not os.path.exists(csv_file):
        errors.append(f"Không tìm thấy file {csv_file}")
        print(f"  [X] Không tìm thấy file {csv_file}")
        return 1
    else:
        with open(csv_file, 'rb') as f:
            raw = f.read(3)
            if raw == b'\xef\xbb\xbf':
                print(f"  [OK] {csv_file} có UTF-8 BOM đúng chuẩn.")
            else:
                errors.append(f"{csv_file} không có UTF-8 BOM.")
                print(f"  [X] {csv_file} không có UTF-8 BOM!")
                
    if not os.path.exists(excel_file):
        errors.append(f"Không tìm thấy file {excel_file}")
        print(f"  [X] Không tìm thấy file {excel_file}")
    else:
        print(f"  [OK] File Excel {excel_file} tồn tại.")
        
    # 2. Đọc dữ liệu
    df_spec = pd.read_csv(spec_file)
    df_out = pd.read_csv(csv_file, encoding='utf-8-sig')
    banned_words, banned_words_na = load_banned_words(banned_file)
    
    # 3. Kiểm tra số lượng và danh sách cột
    print("\n[2] Kiểm tra danh sách cột và số lượng sản phẩm...")
    if list(df_out.columns) == EXPECTED_COLUMNS:
        print(f"  [OK] Các cột đúng thứ tự ({len(EXPECTED_COLUMNS)} cột): {list(df_out.columns)}")
    else:
        errors.append(f"Cột không đúng. Hiện tại: {list(df_out.columns)}, mong muốn: {EXPECTED_COLUMNS}")
        print(f"  [X] Cột không đúng: {list(df_out.columns)}")
        
    if len(df_out) == len(df_spec) == 40:
        print(f"  [OK] Số lượng sản phẩm: 40/40 SKU.")
    else:
        errors.append(f"Số lượng dòng không khớp: out={len(df_out)}, spec={len(df_spec)}")
        print(f"  [X] Số lượng dòng không khớp: {len(df_out)}")
        
    # 4. Kiểm tra từng sản phẩm
    print("\n[3] Kiểm tra chi tiết 40 sản phẩm...")
    ready_count = 0
    supplement_count = 0
    
    for idx, row in df_out.iterrows():
        sku = str(row['sku']).strip()
        spec_row = df_spec[df_spec['sku'] == sku]
        if spec_row.empty:
            errors.append(f"SKU {sku} không tìm thấy trong thong_so.csv")
            continue
        spec_row = spec_row.iloc[0]
        
        # a. Độ dài tiêu đề
        tieu_de = str(row['tieu_de']) if pd.notna(row['tieu_de']) else ""
        if len(tieu_de) < 25 or len(tieu_de) > 100:
            errors.append(f"[{sku}] tieu_de độ dài {len(tieu_de)} ngoài khoảng [25, 100]")
        if not tieu_de.startswith("Vườn Nhỏ"):
            warnings.append(f"[{sku}] tieu_de không bắt đầu bằng 'Vườn Nhỏ'")
            
        # b. Độ dài mô tả
        mo_ta = str(row['mo_ta']) if pd.notna(row['mo_ta']) else ""
        if len(mo_ta) < 200 or len(mo_ta) > 1500:
            errors.append(f"[{sku}] mo_ta độ dài {len(mo_ta)} ngoài khoảng [200, 1500]")
            
        # Giọng điệu mô tả
        if "Vườn Nhỏ" not in mo_ta:
            errors.append(f"[{sku}] mo_ta không xưng 'Vườn Nhỏ'")
        if "bạn" not in mo_ta.lower():
            errors.append(f"[{sku}] mo_ta không gọi khách là 'bạn'")
        for forbidden_pronoun in ["quý khách", "chị em", "chúng tôi"]:
            if forbidden_pronoun in mo_ta.lower():
                errors.append(f"[{sku}] mo_ta chứa đại từ bị cấm: '{forbidden_pronoun}'")
        if mo_ta.count("!") > 1:
            errors.append(f"[{sku}] mo_ta chứa quá 1 dấu chấm than ({mo_ta.count('!')} dấu !)")
            
        # c. Đủ 5 gạch đầu dòng & độ dài <= 120
        bullets = [str(row[f'gach_{i}']) if pd.notna(row[f'gach_{i}']) else "" for i in range(1, 6)]
        for i, b in enumerate(bullets, 1):
            if not b:
                errors.append(f"[{sku}] gach_{i} để trống")
            elif len(b) > 120:
                errors.append(f"[{sku}] gach_{i} độ dài {len(b)} > 120 ký tự")
                
        # d. Từ khóa: 6 đến 10 cụm, mỗi cụm <= 30 ký tự, ngăn cách bằng ';'
        tu_khoa = str(row['tu_khoa']) if pd.notna(row['tu_khoa']) else ""
        kws = [k.strip() for k in tu_khoa.split(';') if k.strip()]
        if len(kws) < 6 or len(kws) > 10:
            errors.append(f"[{sku}] tu_khoa có {len(kws)} cụm (yêu cầu 6-10 cụm)")
        for k in kws:
            if len(k) > 30:
                errors.append(f"[{sku}] cụm từ khóa '{k}' có độ dài {len(k)} > 30 ký tự")
                
        # e. Kiểm tra từ cấm trong toàn bộ các trường text
        all_text_to_check = {
            'tieu_de': tieu_de,
            'mo_ta': mo_ta,
            'gach_1': bullets[0],
            'gach_2': bullets[1],
            'gach_3': bullets[2],
            'gach_4': bullets[3],
            'gach_5': bullets[4],
            'tu_khoa': tu_khoa
        }
        for field_name, field_val in all_text_to_check.items():
            banned_found = check_banned(field_val, banned_words, banned_words_na)
            if banned_found:
                errors.append(f"[{sku}] Trường {field_name} chứa từ cấm: {banned_found}")
                
        # f. Kiểm tra mọi con số trong mô tả, tiêu đề, gạch đầu dòng
        spec_text_allowed = " ".join([
            str(spec_row[c]) for c in df_spec.columns if c != 'ghi_chu_noi_bo' and pd.notna(spec_row[c])
        ])
        allowed_nums = set(re.findall(r'\d+', spec_text_allowed))
        
        # Check numbers in mo_ta
        mo_ta_nums = set(re.findall(r'\d+', mo_ta))
        extra_mo_ta_nums = mo_ta_nums - allowed_nums
        if extra_mo_ta_nums:
            errors.append(f"[{sku}] mo_ta chứa số không có trong bảng thông số: {extra_mo_ta_nums}")
            
        # Check numbers in tieu_de
        tieu_de_nums = set(re.findall(r'\d+', tieu_de))
        extra_tieu_de_nums = tieu_de_nums - allowed_nums
        if extra_tieu_de_nums:
            errors.append(f"[{sku}] tieu_de chứa số không có trong bảng thông số: {extra_tieu_de_nums}")
            
        # Check numbers in bullets
        for i, b in enumerate(bullets, 1):
            b_nums = set(re.findall(r'\d+', b))
            extra_b_nums = b_nums - allowed_nums
            if extra_b_nums:
                errors.append(f"[{sku}] gach_{i} chứa số không có trong bảng thông số: {extra_b_nums}")
                
        # g. Kiểm tra trạng thái và các trường thiếu
        missing_in_spec = []
        for req_col in REQUIRED_COLS:
            val = str(spec_row[req_col]).strip().lower() if pd.notna(spec_row[req_col]) else ""
            if val in MISSING_MARKERS:
                missing_in_spec.append(req_col)
                
        trang_thai = str(row['trang_thai']).strip()
        truong_can_bo_sung = str(row['truong_can_bo_sung']).strip() if pd.notna(row['truong_can_bo_sung']) else ""
        
        if missing_in_spec:
            supplement_count += 1
            if trang_thai != 'CAN_BO_SUNG':
                errors.append(f"[{sku}] Thiếu trường {missing_in_spec} nhưng trang_thai là '{trang_thai}' (phải là CAN_BO_SUNG)")
            expected_missing_str = ";".join(missing_in_spec)
            if truong_can_bo_sung != expected_missing_str:
                errors.append(f"[{sku}] truong_can_bo_sung là '{truong_can_bo_sung}', mong muốn '{expected_missing_str}'")
            # Kiểm tra trong mo_ta có ghi rõ "CẦN BỔ SUNG: <tên cột>"
            for col in missing_in_spec:
                expected_tag = f"CẦN BỔ SUNG: {col}"
                if expected_tag not in mo_ta:
                    errors.append(f"[{sku}] mo_ta thiếu nhãn '{expected_tag}' cho trường thiếu {col}")
        else:
            ready_count += 1
            if trang_thai != 'SAN_SANG':
                errors.append(f"[{sku}] Đầy đủ thông tin nhưng trang_thai là '{trang_thai}' (phải là SAN_SANG)")
            if truong_can_bo_sung != "" and truong_can_bo_sung.lower() != "nan":
                errors.append(f"[{sku}] Đầy đủ thông tin nhưng truong_can_bo_sung không để trống: '{truong_can_bo_sung}'")
                
        # h. Kiểm tra nguyên tắc phiếu công bố
        sp_spec = str(spec_row['so_phieu_cong_bo']).strip() if pd.notna(spec_row['so_phieu_cong_bo']) else ""
        if sp_spec in MISSING_MARKERS or "chờ duyệt" in sp_spec.lower():
            if "đã có phiếu công bố" in mo_ta.lower() or "đã công bố" in mo_ta.lower():
                errors.append(f"[{sku}] Bảng chưa có số phiếu duyệt nhưng mô tả khẳng định đã có phiếu công bố")
                
    # 5. In kết quả tổng hợp
    print("\n" + "=" * 70)
    print("KẾT QUẢ KIỂM TRA:")
    print("=" * 70)
    print(f"- Tổng số sản phẩm kiểm tra: {len(df_out)}")
    print(f"- Số sản phẩm SẴN SÀNG (SAN_SANG): {ready_count}")
    print(f"- Số sản phẩm CẦN BỔ SUNG (CAN_BO_SUNG): {supplement_count}")
    print(f"- Tổng số cảnh báo (warnings): {len(warnings)}")
    print(f"- Tổng số lỗi (errors): {len(errors)}")
    
    if warnings:
        print("\nDANH SÁCH CẢNH BÁO:")
        for w in warnings:
            print(f"  [!] {w}")
            
    if errors:
        print("\nDANH SÁCH LỖI:")
        for e in errors:
            print(f"  [X] {e}")
        print("\nKẾT LUẬN: FILE CẦN ĐƯỢC CHỈNH SỬA!")
        return 1
    else:
        print("\nKẾT LUẬN: TẤT CẢ 40 SẢN PHẨM HOÀN TOÀN ĐẠT CHUẨN (SẠCH 100%)!")
        return 0

if __name__ == '__main__':
    sys.exit(main())
