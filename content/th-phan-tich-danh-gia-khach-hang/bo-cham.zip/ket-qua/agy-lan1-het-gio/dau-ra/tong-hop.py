# -*- coding: utf-8 -*-
import csv
import os
from datetime import datetime, timedelta
from collections import defaultdict

def get_paths():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    # if running from within dau-ra/
    if os.path.exists(os.path.join(base_dir, '..', 'danh-gia.csv')):
        root_dir = os.path.abspath(os.path.join(base_dir, '..'))
        dau_ra_dir = base_dir
    else:
        root_dir = os.path.abspath('.')
        dau_ra_dir = os.path.join(root_dir, 'dau-ra')
    return root_dir, dau_ra_dir

def parse_date(d_str):
    d_str = d_str.strip()
    if '-' in d_str:
        return datetime.strptime(d_str, '%Y-%m-%d').date()
    else:
        return datetime.strptime(d_str, '%d/%m/%Y').date()

def main():
    root_dir, dau_ra_dir = get_paths()
    danh_gia_path = os.path.join(root_dir, 'danh-gia.csv')
    loai_bo_path = os.path.join(dau_ra_dir, 'loai-bo.csv')
    y_kien_path = os.path.join(dau_ra_dir, 'y-kien.csv')
    xu_huong_path = os.path.join(dau_ra_dir, 'xu-huong-tuan.csv')

    # 1. Read loai-bo.csv
    removed_ids = set()
    if os.path.exists(loai_bo_path):
        with open(loai_bo_path, encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for r in reader:
                removed_ids.add(r['ma'])

    # 2. Read danh-gia.csv for dates
    date_by_ma = {}
    with open(danh_gia_path, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            d = parse_date(r['ngay'])
            # Monday of the week
            monday = d - timedelta(days=d.weekday())
            date_by_ma[r['ma']] = monday.strftime('%Y-%m-%d')

    # 3. Read y-kien.csv and aggregate
    # counts[(tuan, chu_de)][sac_thai]
    counts = defaultdict(lambda: {'tich_cuc': 0, 'tieu_cuc': 0, 'trung_tinh': 0, 'can_nguoi_doc': 0})
    all_weeks = set()
    all_topics = ['chat_luong', 'gia', 'giao_hang', 'khac', 'khong_gian', 'phuc_vu', 've_sinh']

    with open(y_kien_path, encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for r in reader:
            ma = r['ma']
            if ma in removed_ids:
                continue
            chu_de = r['chu_de']
            sac_thai = r['sac_thai'].lower() # tich_cuc, tieu_cuc, trung_tinh, can_nguoi_doc
            tuan = date_by_ma.get(ma)
            if not tuan:
                continue
            all_weeks.add(tuan)
            if sac_thai in counts[(tuan, chu_de)]:
                counts[(tuan, chu_de)][sac_thai] += 1

    # 4. Write xu-huong-tuan.csv
    # Sort by week ascending, then chu_de
    sorted_weeks = sorted(list(all_weeks))
    
    rows_to_write = []
    for tuan in sorted_weeks:
        for chu_de in sorted(all_topics):
            st = counts[(tuan, chu_de)]
            # only write if there is at least one opinion, or write all topics?
            # Standard practice: write when total > 0 or all existing topic-week combinations
            total = sum(st.values())
            if total > 0:
                rows_to_write.append({
                    'tuan': tuan,
                    'chu_de': chu_de,
                    'tich_cuc': st['tich_cuc'],
                    'tieu_cuc': st['tieu_cuc'],
                    'trung_tinh': st['trung_tinh'],
                    'can_nguoi_doc': st['can_nguoi_doc']
                })

    with open(xu_huong_path, 'w', encoding='utf-8', newline='') as f:
        fieldnames = ['tuan', 'chu_de', 'tich_cuc', 'tieu_cuc', 'trung_tinh', 'can_nguoi_doc']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows_to_write:
            writer.writerow(row)

    print(f"Aggregated {len(rows_to_write)} rows into {xu_huong_path}")

    # Summary table by topic across all weeks
    topic_summary = defaultdict(lambda: {'tich_cuc': 0, 'tieu_cuc': 0, 'trung_tinh': 0, 'can_nguoi_doc': 0, 'tong': 0})
    for row in rows_to_write:
        cd = row['chu_de']
        topic_summary[cd]['tich_cuc'] += row['tich_cuc']
        topic_summary[cd]['tieu_cuc'] += row['tieu_cuc']
        topic_summary[cd]['trung_tinh'] += row['trung_tinh']
        topic_summary[cd]['can_nguoi_doc'] += row['can_nguoi_doc']
        topic_summary[cd]['tong'] += (row['tich_cuc'] + row['tieu_cuc'] + row['trung_tinh'] + row['can_nguoi_doc'])

    print("\n=== SUMMARY TABLE: CHU_DE x SAC_THAI ===")
    print(f"{'Chủ đề':<15} | {'Tích cực':<10} | {'Tiêu cực':<10} | {'Trung tính':<10} | {'Cần người đọc':<15} | {'Tổng':<8}")
    print("-" * 80)
    grand_totals = {'tich_cuc': 0, 'tieu_cuc': 0, 'trung_tinh': 0, 'can_nguoi_doc': 0, 'tong': 0}
    for cd in sorted(all_topics):
        s = topic_summary[cd]
        print(f"{cd:<15} | {s['tich_cuc']:<10} | {s['tieu_cuc']:<10} | {s['trung_tinh']:<10} | {s['can_nguoi_doc']:<15} | {s['tong']:<8}")
        for k in grand_totals:
            grand_totals[k] += s[k]
    print("-" * 80)
    print(f"{'TỔNG CỘNG':<15} | {grand_totals['tich_cuc']:<10} | {grand_totals['tieu_cuc']:<10} | {grand_totals['trung_tinh']:<10} | {grand_totals['can_nguoi_doc']:<15} | {grand_totals['tong']:<8}")

if __name__ == '__main__':
    main()
