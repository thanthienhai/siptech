"""Lời giải bài tập 3 (bài 4): ẩn danh bảng chấm công gốc bằng một script nhỏ. ĐỪNG đưa tệp này cho agent trước khi bạn tự làm.

Chạy (trong thư mục bài toán):
  python -X utf8 ket-qua/bai-tap/loi-giai-an-danh.py du-lieu/goc bai-tap-3/an-danh-cua-toi bai-tap-3/bang-ma-cua-toi.csv
Ra: 4 CSV đã ẩn danh trong thư mục thứ hai; bảng đối chiếu (ma_an_danh, ho_ten) ở tệp thứ ba (NẰM NGOÀI thư mục đưa cho agent).
"""
import csv, random, sys
from pathlib import Path

goc, ra, bang = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
ra.mkdir(parents=True, exist_ok=True); bang.parent.mkdir(parents=True, exist_ok=True)

def doc(ten):
    with open(goc / ten, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))

def ghi(p, rows, cols):
    with open(p, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)

chuan = lambda x: str(int(x)) if x.strip().isdigit() else x.strip()   # "01012" và "1012" là cùng một người
nv = doc("nhan_vien.csv")
may = doc("xuat_may_cham_cong.csv")
ids = [chuan(r["Mã NV"]) for r in nv]
la = sorted({chuan(r["Mã NV"]) for r in may} - set(ids))                  # mã thẻ không có trong danh sách
tat_ca = ids + la
thu_tu = list(range(1, len(tat_ca) + 1)); random.Random(4242).shuffle(thu_tu)  # hạt giống của RIÊNG bạn
ma = {i: f"NV-{n:03d}" for i, n in zip(tat_ca, thu_tu)}
theo_ten = {r["Họ tên"]: chuan(r["Mã NV"]) for r in nv}

ghi(ra / "cham_cong.csv", [dict(ma_may=r["Mã máy"], ma_nv=ma[chuan(r["Mã NV"])], thoi_gian=r["Thời gian"]) for r in may], ["ma_may", "ma_nv", "thoi_gian"])
ghi(ra / "lich_ca_xoay.csv", [dict(ma_nv=ma[theo_ten[r["Họ tên"]]], ngay=r["Ngày"], ca=r["Ca"]) for r in doc("lich_ca_xoay.csv")], ["ma_nv", "ngay", "ca"])
ghi(ra / "nghi_phep.csv", [dict(ma_nv=ma[theo_ten[r["Họ tên"]]], tu_ngay=r["Từ ngày"], den_ngay=r["Đến ngày"], loai=r["Loại nghỉ"], trang_thai=r["Trạng thái"]) for r in doc("don_nghi_phep.csv")],
     ["ma_nv", "tu_ngay", "den_ngay", "loai", "trang_thai"])
ghi(ra / "nhan_vien.csv", sorted([dict(ma_nv=ma[chuan(r["Mã NV"])], chi_nhanh=r["Chi nhánh"], loai_ca=r["Loại ca"]) for r in nv], key=lambda r: r["ma_nv"]), ["ma_nv", "chi_nhanh", "loai_ca"])
ghi(bang, [dict(ma_an_danh=ma[chuan(r["Mã NV"])], ho_ten=r["Họ tên"]) for r in nv] + [dict(ma_an_danh=ma[i], ho_ten="(mã không có trong danh sách)") for i in la], ["ma_an_danh", "ho_ten"])
print("đã ẩn danh", len(ma), "mã;", len(la), "mã lạ")
