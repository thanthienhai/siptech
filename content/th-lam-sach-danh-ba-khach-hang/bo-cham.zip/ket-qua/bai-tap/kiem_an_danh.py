"""Kiểm một bản danh bạ đã giả danh (bài tập 3, bài 4). Không dùng mô hình.

Dùng:  python -X utf8 kiem_an_danh.py <danh-ba-goc.xlsx thật> <danh-ba-goc.xlsx đã giả danh>
Kiểm:
  1. Hình dạng giữ nguyên: cùng cột, cùng số dòng, Mã dòng và Nguồn không đổi.
  2. Không lộ họ tên: không từ nào (>= 3 chữ cái, bỏ dấu) trong tên thật còn trong cột Họ tên, Email, SĐT của bản giả
     (bỏ qua các từ 'anh', 'chi', 'co', 'chu', 'bac' vì vừa là danh xưng vừa là tên; bỏ qua ô tên chứa chữ số).
  3. Không lộ SĐT: không SĐT thật (từ 8 chữ số, bỏ đầu số 84/0) nằm trong chữ số của các cột SĐT, Email, Ghi chú của bản giả.
  4. Không lộ email: phần trước @ của email thật không xuất hiện ở bất kỳ ô nào của bản giả.
  5. Địa chỉ: không từ nào (>= 4 chữ cái, bỏ dấu) của địa chỉ thật còn trong cột Địa chỉ của bản giả,
     trừ tên thành phố/tiền tố hành chính (p, q, tp, phuong, quan, hcm, ha noi, da nang...).
Thoát mã 0 nếu mọi phép đạt, 1 nếu có phép trượt.
"""
import re, sys, unicodedata
import openpyxl

TITLES = {"anh", "chi", "co", "chu", "bac", "a", "c"}
HANH_CHINH = {"phuong", "quan", "thanh", "pho", "duong", "tphcm", "noi", "nang", "can", "tho", "phong", "minh"}


def sd(s):
    s = unicodedata.normalize("NFD", str(s or "").replace("đ", "d").replace("Đ", "D"))
    return "".join(c for c in s if unicodedata.category(c) != "Mn").lower()


def load(p):
    rows = list(openpyxl.load_workbook(p).active.iter_rows(values_only=True))
    return list(rows[0]), [r for r in rows[1:] if r[0]]


def main(that, gia):
    h1, a = load(that); h2, b = load(gia)
    H = {c: i for i, c in enumerate(h1)}
    fails = []

    def check(name, ok, detail=""):
        print(("ĐẠT   " if ok else "TRƯỢT ") + name + (f"  [{detail}]" if detail else ""))
        if not ok: fails.append(name)

    same = h1 == h2 and len(a) == len(b) and all(x[0] == y[0] and x[H["Nguồn"]] == y[H["Nguồn"]] for x, y in zip(a, b))
    check("1. hình dạng giữ nguyên (cột, số dòng, Mã dòng, Nguồn)", same, f"{len(a)} dòng thật, {len(b)} dòng giả")
    if not same: return 1

    def cells(rows, cols): return [str(r[H[c]]) for r in rows for c in cols if r[H[c]] is not None]
    # 2. họ tên
    words = set()
    for v in cells(a, ["Họ tên"]):
        if re.search(r"\d", v): continue      # ô tên đang chứa địa chỉ (dòng nhập nhầm cột): kiểm ở phép 5
        for w in re.findall(r"[^\W\d_]+", sd(v)):
            if len(w) >= 3 and w not in TITLES: words.add(w)   # 'anh', 'chi'... vừa là danh xưng vừa là tên: bỏ qua
    ok_rows = [rb for ra, rb in zip(a, b) if not re.search(r"\d", str(ra[H["Họ tên"]] or ""))]   # bỏ dòng tên-địa chỉ đổi chỗ
    leak = {w for v in cells(ok_rows, ["Họ tên", "Email", "SĐT"]) for w in re.findall(r"[^\W\d_]+", sd(v)) if w in words}
    check("2. không lộ từ nào của họ tên thật", not leak, f"lộ {len(leak)}: {sorted(leak)[:6]}")
    # 3. SĐT
    cores = set()
    for v in cells(a, ["SĐT", "Email", "Ghi chú"]):
        for m in re.findall(r"\+?\d[\d .\-]{6,}\d", v):
            d = re.sub(r"\D", "", m)
            d = d[4:] if d.startswith("0084") else d[2:] if d.startswith("84") and len(d) >= 11 else d[1:] if d.startswith("0") else d
            if len(d) >= 8: cores.add(d)
    digits_b = [re.sub(r"\D", "", v) for v in cells(b, ["SĐT", "Email", "Ghi chú"])]
    leak = {c for c in cores if any(c in x for x in digits_b)}
    check("3. không lộ SĐT thật", not leak, f"{len(cores)} số thật, lộ {len(leak)}")
    # 4. email
    locs = {sd(v).split("@")[0].strip() for v in cells(a, ["SĐT", "Email", "Ghi chú"]) if "@" in v}
    locs = {x for x in locs if len(x) >= 4}
    all_b = [sd(v) for r in b for v in r if v is not None]
    leak = {x for x in locs if any(x in y for y in all_b)}
    check("4. không lộ phần tên của email thật", not leak, f"{len(locs)} email thật, lộ {len(leak)}")
    # 5. địa chỉ
    aw = {w for v in cells(a, ["Địa chỉ"]) for w in re.findall(r"[^\W\d_]+", sd(v)) if len(w) >= 4 and w not in HANH_CHINH}
    leak = {w for v in cells(b, ["Địa chỉ"]) for w in re.findall(r"[^\W\d_]+", sd(v)) if w in aw}
    check("5. không lộ tên đường/phường thật trong địa chỉ", not leak, f"lộ {len(leak)}: {sorted(leak)[:6]}")
    print("\nTỔNG:", "ĐẠT TẤT CẢ" if not fails else f"TRƯỢT {len(fails)} mục")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
