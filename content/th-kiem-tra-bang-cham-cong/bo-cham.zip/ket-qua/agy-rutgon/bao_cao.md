# BÁO CÁO KIỂM TRA DỮ LIỆU CHẤM CÔNG THÁNG 09/2026

**Kính gửi:** Ban Quản lý / Bộ phận Nhân sự  
**Người lập:** Trợ lý kiểm tra chấm công  
**Kỳ dữ liệu:** 01/09/2026 – 30/09/2026 (Công ty gồm 25 nhân viên, 2 chi nhánh A và B)

---

## 1. Số liệu tổng hợp toàn công ty

- **Quy mô nhân sự & ngày công:** 25 nhân viên trong danh sách (16 nhân viên Hành chính - HC, 9 nhân viên Ca xoay - XOAY).
- **Tổng số bản ghi ngày công:** 750 dòng (25 nhân viên × 30 ngày).
  - **Trạng thái OK (đủ điều kiện tính công):** **498** ngày (Tổng giờ công chuẩn: **3,966.86** giờ; Tổng giờ làm thêm hợp lệ: **92.47** giờ).
  - **Trạng thái NGHI (nghỉ hàng tuần/nghỉ lễ không quẹt thẻ):** **207** ngày.
  - **Trạng thái PHEP (nghỉ phép đã duyệt, không quẹt thẻ):** **12** ngày.
  - **Trạng thái CHO_XAC_NHAN (cần quản lý phê duyệt, chưa tính giờ):** **33** ngày.
- **Tổng số bất thường phát hiện:** **61** trường hợp (thuộc 14 loại mã).
  - *Bất thường tự động xử lý theo quy chế (`can_nguoi_quyet = KHONG`):* **24** trường hợp (12 Đi trễ, 6 Về sớm, 6 Quẹt trùng).
  - *Bất thường cần quản lý phê duyệt (`can_nguoi_quyet = CO`):* **37** trường hợp (36 mục theo ngày + 1 mục OT tháng).

---

## 2. Danh sách việc Quản lý cần xác nhận (Gom theo loại bất thường)

1. **Vắng mặt chưa ghi nhận phép (VANG_CHUA_GHI - 6 ca):**  
   - Nhân viên: `NV-002` (22/09, ca C), `NV-003` (28/09, ca S), `NV-010` (21/09, ca HC), `NV-023` (11/09, ca HC), `NV-024` (21/09, ca HC), `NV-026` (24/09, ca HC).  
   - *Việc cần làm:* Xác minh lý do vắng mặt thực tế; hướng dẫn nhân viên nộp bổ sung đơn phép nếu có lý do chính đáng.

2. **Quẹt thẻ đơn lẻ / Thiếu giờ vào - ra (11 ca):**  
   - *Thiếu quẹt ra (`THIEU_RA` - 5 ca):* `NV-011` (14/09), `NV-013` (05/09), `NV-025` (28/09), `NV-026` (10/09, 25/09).  
   - *Thiếu quẹt vào (`THIEU_VAO` - 3 ca):* `NV-011` (24/09), `NV-013` (13/09), `NV-021` (10/09).  
   - *Quẹt giữa ca không rõ chiều (`THIEU_KHONG_RO` - 3 ca):* `NV-013` (06/09 lúc 18:12), `NV-023` (30/09 lúc 13:21), `NV-025` (11/09 lúc 13:21).  
   - *Việc cần làm:* Xác nhận thời gian bắt đầu và kết thúc làm việc thực tế với nhân viên và trưởng bộ phận để bổ sung giờ công.

3. **Làm việc vào ngày Lễ và Ngày nghỉ (7 ca):**  
   - *Làm việc ngày lễ (`LAM_NGAY_LE` - 3 ca):* `NV-007` (01/09), `NV-010` (02/09), `NV-018` (02/09).  
   - *Làm việc ngày nghỉ lịch/tuần (`LAM_NGAY_NGHI` - 4 ca):* `NV-013` (12/09), `NV-014` (24/09), `NV-016` (12/09), `NV-022` (27/09).  
   - *Việc cần làm:* Xác nhận lệnh điều động làm việc; chế độ tiền lương làm thêm ngày lễ/ngày nghỉ **cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự**.

4. **Làm thêm giờ vượt ngưỡng quy định (4 ca):**  
   - *Vượt trần ngày > 180 phút (`OT_VUOT_NGUONG` - 3 ca):* `NV-010` (28/09: làm thêm 227 phút ~ 3.78h), `NV-013` (26/09: 199 phút ~ 3.32h), `NV-025` (10/09: 222 phút ~ 3.70h).  
   - *Vượt trần tháng > 2400 phút (`OT_THANG_VUOT` - 1 ca):* `NV-001` (tổng OT ngày thường trong tháng là 2,697 phút ~ 44.95h).  
   - *Việc cần làm:* Phê duyệt tính hợp lý của công việc phát sinh ngoài giờ; định mức và chính sách chi trả làm thêm giờ **cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự**.

5. **Dấu hiệu quẹt thẻ bất thường ở 2 chi nhánh (`NGHI_QUET_HO` - 4 ca):**  
   - Các trường hợp: `NV-009` (23/09: MAY-A1 07:59 & MAY-B1 08:05, cách 6 phút), `NV-015` (20/09: MAY-B1 05:54 & MAY-A1 06:01, cách 7 phút), `NV-016` (24/09: MAY-A1 07:56 & MAY-B1 08:04, cách 8 phút), `NV-022` (24/09: MAY-A1 07:52 & MAY-B1 07:54, cách 2 phút).  
   - *Việc cần làm:* Đề nghị người có thẩm quyền kiểm tra lịch trình công tác hoặc trích xuất camera để xác nhận tính chính xác của lượt quẹt thẻ. Báo cáo không suy đoán hay kết luận hành vi gian lận.

6. **Có đơn phép đã duyệt nhưng vẫn quẹt thẻ (`CO_PHEP_NHUNG_QUET` - 2 ca):**  
   - Nhân viên: `NV-010` (23/09) và `NV-023` (23/09).  
   - *Việc cần làm:* Xác nhận nhân viên có đi làm thực tế để hoàn trả ngày phép năm và ghi nhận ngày công, hoặc giữ nguyên đơn nghỉ phép.

7. **Dữ liệu chấm công lỗi kỹ thuật (`DU_LIEU_LOI` - 3 ca):**  
   - `NV-005` (11/09 lúc 09:20 tại MAY-A1): Mã nhân viên không tồn tại trong danh sách nhân sự.  
   - `NV-007` (tại MAY-A1): Dòng quẹt bị thiếu thời gian (`NaN`).  
   - `NV-023` (tại MAY-B1): Dòng quẹt ghi ngày không có thực (`31/09/2026 08:00`).  
   - *Việc cần làm:* Bộ phận IT/Kỹ thuật kiểm tra cấu hình thiết bị MAY-A1, MAY-B1; Nhân sự đối chiếu thẻ của `NV-005`.

---

## 3. Các giả định đã áp dụng

1. **Xử lý thời gian:** Toàn bộ so sánh giờ đều bỏ phần giây (ví dụ `08:05:59` lấy là `08:05:00`). Dung sai trễ/sớm đúng 5 phút được tính đủ công; từ 6 phút trở lên mới tính số phút trễ/sớm.
2. **Tính giờ công tiêu chuẩn (`gio_cong`):** Ca chuẩn tính 8.00 giờ (đã trừ 1 giờ nghỉ trưa với ca HC; ca S và C không trừ nghỉ). Nếu trễ hoặc về sớm từ 6 phút trở lên, giờ công chuẩn bị trừ tương ứng: `(480 - phut_tre - phut_ve_som) / 60`.
3. **Phân tách giờ làm thêm (OT):** Giờ làm thêm (quẹt ra muộn >= 30 phút) được tách riêng ở cột `ot_phut` và tổng hợp ở `tong_ot_gio` để phục vụ áp dụng hệ số lương ngoài giờ riêng biệt, không cộng gộp vào `gio_cong` ca chuẩn nhằm tránh trùng lặp khi tính lương.
4. **Nguyên tắc "chưa tính giờ" cho ngày `CHO_XAC_NHAN`:** Tất cả các ngày phát sinh bất thường cần người quyết (`can_nguoi_quyet = CO`) đều để trạng thái `CHO_XAC_NHAN` và để trống ô `gio_cong`. Bảng tổng hợp người chỉ cộng dồn `ngay_cong` và `tong_gio_cong` từ các ngày có trạng thái `OK`.
5. **Nghỉ phép trùng ngày nghỉ tuần:** Đơn nghỉ phép dài ngày bao gồm cả ngày nghỉ hàng tuần (ví dụ `NV-009` nghỉ ốm 03/09-07/09 gồm T7, CN; `NV-020` nghỉ ốm 29/09-30/09 trong đó 30/09 là ca OFF) được xử lý: ngày nghỉ tuần/ca giữ trạng thái `NGHI`, chỉ ghi nhận trạng thái `PHEP` cho các ngày làm việc thực tế theo lịch.

---

## 4. Điều chưa chắc chắn & Cần người quyết định

- **Trường hợp quẹt lặp sát ngưỡng của NV-016 (25/09):** Nhân viên quẹt lúc 07:57:45 và 08:01:10 (cách nhau 3 phút 25 giây, tức > 3 phút). Chương trình không ghi nhận `QUET_TRUNG`, lấy 07:57 làm giờ vào và tính đủ 8.00 giờ công. Trường hợp này **CẦN NGƯỜI QUYẾT** nếu công ty có quy chế làm tròn phút trước khi xét quẹt trùng.
- **Trường hợp NV-012 quẹt vào tại Chi nhánh B (07:40) và quẹt ra tại Chi nhánh A (17:09) ngày 22/09:** Do cách nhau hơn 9 tiếng (> 10 phút) nên không thuộc diện cảnh báo `NGHI_QUET_HO`. Hệ thống vẫn tính đủ 8.00 giờ công, nhưng quản lý cần xác nhận tính chất công tác liên chi nhánh.
- **Quy định pháp lý về làm thêm và nghỉ phép:** Chế độ đãi ngộ, tiền lương làm thêm giờ (đặc biệt các trường hợp vượt trần) và làm việc ngày lễ/nghỉ: **cần kiểm với văn bản hiện hành hoặc chuyên gia nhân sự**.
